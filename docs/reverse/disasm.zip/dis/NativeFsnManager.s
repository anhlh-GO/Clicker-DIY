#### CLASS NativeFsnManager/<>c__DisplayClass16_0 parent= object
#   field onComplete                     System.Action                                      off=0x10 attr=6 
## .ctor() -> void
---- NativeFsnManager/<>c__DisplayClass16_0::.ctor 0x2c9a3b8
02c9a3b8: mov     x1, xzr                                    
02c9a3bc: b       #0x4e53e9c                                 System.Object::.ctor
## <ShowFsnAd>b__0(string errMessage) -> void
---- NativeFsnManager/<>c__DisplayClass16_0::<ShowFsnAd>b__0 0x2c9af64
02c9af64: ldr     x8, [x0, #0x10]                            .onComplete
02c9af68: cbz     x8, #0x2c9af7c                             
02c9af6c: ldr     x0, [x8, #0x40]                            
02c9af70: ldr     x1, [x8, #0x28]                            
02c9af74: ldr     x2, [x8, #0x18]                            
02c9af78: br      x2                                         
02c9af7c: ret                                                
#### CLASS NativeFsnManager/<ReloadCoroutine>d__18 parent= object
#   field <>1__state                     int                                                off=0x10 attr=1 
#   field <>2__current                   object                                             off=0x18 attr=1 
#   field <>4__this                      NativeFsnManager                                   off=0x20 attr=6 
## .ctor(int <>1__state) -> void
---- NativeFsnManager/<ReloadCoroutine>d__18::.ctor 0x2c9a520
02c9a520: str     x30, [sp, #-0x20]!                         
02c9a524: stp     x20, x19, [sp, #0x10]                      
02c9a528: mov     w19, w1                                    
02c9a52c: mov     x1, xzr                                    
02c9a530: mov     x20, x0                                    
02c9a534: bl      #0x4e53e9c                                 System.Object::.ctor
02c9a538: str     w19, [x20, #0x10]                          .<>1__state
02c9a53c: ldp     x20, x19, [sp, #0x10]                      
02c9a540: ldr     x30, [sp], #0x20                           
02c9a544: ret                                                
## System.IDisposable.Dispose() -> void
---- NativeFsnManager/<ReloadCoroutine>d__18::System.IDisposable.Dispose 0x2c9af80
02c9af80: ret                                                
## MoveNext() -> bool
---- NativeFsnManager/<ReloadCoroutine>d__18::MoveNext 0x2c9af84
02c9af84: sub     sp, sp, #0x50                              
02c9af88: str     d8, [sp, #0x10]                            
02c9af8c: stp     x30, x23, [sp, #0x20]                      
02c9af90: stp     x22, x21, [sp, #0x30]                      
02c9af94: stp     x20, x19, [sp, #0x40]                      
02c9af98: adrp    x20, #0x662f000                            
02c9af9c: mov     x19, x0                                    
02c9afa0: ldrb    w8, [x20, #0xa39]                          
02c9afa4: tbnz    w8, #0, #0x2c9afe0                         
02c9afa8: adrp    x0, #0x6263000                             
02c9afac: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c9afb0: bl      #0x2b70db0                                 fn_2b70db0
02c9afb4: adrp    x0, #0x6264000                             
02c9afb8: ldr     x0, [x0, #0xf58]                           T:UnityEngine.WaitForSeconds
02c9afbc: bl      #0x2b70db0                                 fn_2b70db0
02c9afc0: adrp    x0, #0x6265000                             
02c9afc4: ldr     x0, [x0, #0xa48]                           S:'[NativeFull {0}] Max reload attempts reached ({1}). Stopping retries.'
02c9afc8: bl      #0x2b70db0                                 fn_2b70db0
02c9afcc: adrp    x0, #0x6265000                             
02c9afd0: ldr     x0, [x0, #0xa50]                           S:'[NativeFull {0}] Reload in {1}s (attempt {2})'
02c9afd4: bl      #0x2b70db0                                 fn_2b70db0
02c9afd8: mov     w8, #1                                     
02c9afdc: strb    w8, [x20, #0xa39]                          
02c9afe0: ldr     w8, [x19, #0x10]                           .<>1__state
02c9afe4: ldr     x20, [x19, #0x20]                          .<>4__this
02c9afe8: cmp     w8, #1                                     
02c9afec: b.eq    #0x2c9b0e0                                 
02c9aff0: cbnz    w8, #0x2c9b1b0                             
02c9aff4: mov     w8, #-1                                    
02c9aff8: str     w8, [x19, #0x10]                           .<>1__state
02c9affc: cbz     x20, #0x2c9b1cc                            
02c9b000: ldp     w0, w8, [x20, #0x3c]                       
02c9b004: cmp     w0, w8                                     
02c9b008: b.ge    #0x2c9b134                                 
02c9b00c: fmov    s0, #1.00000000                            
02c9b010: bl      #0x5e902b0                                 fn_5e902b0
02c9b014: fmov    s1, #4.00000000                            
02c9b018: adrp    x23, #0x6263000                            
02c9b01c: add     x1, sp, #0x18                              
02c9b020: ldr     x23, [x23, #0x970]                         &6645c70(=0)
02c9b024: ldr     x21, [x20, #0x28]                          [662f028]=6000015 f=2.40742e-35,0
02c9b028: fmul    s8, s0, s1                                 
02c9b02c: ldr     x0, [x23, #0x78]                           &2c498b4(=d65f03c0d503245f)
02c9b030: str     s8, [sp, #0x18]                            
02c9b034: bl      #0x2b70f38                                 fn_2b70f38
02c9b038: ldr     w8, [x20, #0x3c]                           [662f03c]=0 f=0,0
02c9b03c: mov     x22, x0                                    
02c9b040: ldr     x0, [x23, #0x48]                           &6263098(=0)
02c9b044: add     x1, sp, #0xc                               
02c9b048: add     w8, w8, #1                                 
02c9b04c: str     w8, [sp, #0xc]                             
02c9b050: bl      #0x2b70f38                                 fn_2b70f38
02c9b054: adrp    x8, #0x6265000                             
02c9b058: mov     x3, x0                                     
02c9b05c: mov     x1, x21                                    
02c9b060: ldr     x8, [x8, #0xa50]                           S:'[NativeFull {0}] Reload in {1}s (attempt {2})'
02c9b064: mov     x2, x22                                    
02c9b068: mov     x4, xzr                                    
02c9b06c: ldr     x8, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9b070: mov     x0, x8                                     
02c9b074: bl      #0x4ca7764                                 System.String::Format
02c9b078: adrp    x8, #0x6263000                             
02c9b07c: mov     x20, x0                                    
02c9b080: ldr     x8, [x8, #0x928]                           T:UnityEngine.Debug
02c9b084: ldr     x8, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c9b088: ldr     w9, [x8, #0xe4]                            [62630e4]=0 f=0,0
02c9b08c: cbnz    w9, #0x2c9b098                             
02c9b090: mov     x0, x8                                     
02c9b094: bl      #0x2b70f30                                 fn_2b70f30
02c9b098: mov     x0, x20                                    
02c9b09c: mov     x1, xzr                                    
02c9b0a0: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02c9b0a4: adrp    x8, #0x6264000                             
02c9b0a8: ldr     x8, [x8, #0xf58]                           T:UnityEngine.WaitForSeconds
02c9b0ac: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c9b0b0: bl      #0x2b7104c                                 fn_2b7104c
02c9b0b4: fmov    s0, s8                                     
02c9b0b8: mov     x1, xzr                                    
02c9b0bc: mov     x20, x0                                    
02c9b0c0: bl      #0x5b3e5e8                                 UnityEngine.WaitForSeconds::.ctor
02c9b0c4: str     x20, [x19, #0x18]!                         .<>2__current
02c9b0c8: mov     x0, x19                                    
02c9b0cc: mov     x1, x20                                    
02c9b0d0: bl      #0x2b70d54                                 fn_2b70d54
02c9b0d4: mov     w0, #1                                     
02c9b0d8: stur    w0, [x19, #-8]                             
02c9b0dc: b       #0x2c9b1b4                                 
02c9b0e0: mov     w8, #-1                                    
02c9b0e4: str     w8, [x19, #0x10]                           .<>1__state
02c9b0e8: cbz     x20, #0x2c9b1cc                            
02c9b0ec: mov     x19, x20                                   
02c9b0f0: mov     x1, xzr                                    
02c9b0f4: str     xzr, [x19, #0x48]!                         
02c9b0f8: mov     x0, x19                                    
02c9b0fc: bl      #0x2b70d54                                 fn_2b70d54
02c9b100: ldur    w8, [x19, #-0xc]                           
02c9b104: add     w8, w8, #1                                 
02c9b108: stur    w8, [x19, #-0xc]                           
02c9b10c: bl      #0x2c99e54                                 NativeFsnManager::get_IsEnabled
02c9b110: tbz     w0, #0, #0x2c9b1b0                         
02c9b114: ldr     x0, [x20, #0x20]                           &2b706f0(=d65f03c0f9400800) .<>4__this
02c9b118: cbz     x0, #0x2c9b124                             
02c9b11c: bl      #0x2c93a18                                 FsnAd::IsAdReady
02c9b120: tbnz    w0, #0, #0x2c9b1b0                         
02c9b124: ldr     x1, [x20, #0x30]                           &2b706f8(=d65f03c0b9401800)
02c9b128: mov     x0, x20                                    
02c9b12c: bl      #0x2c99edc                                 NativeFsnManager::LoadFsnAd
02c9b130: b       #0x2c9b1b0                                 
02c9b134: adrp    x8, #0x6263000                             
02c9b138: add     x1, sp, #0x1c                              
02c9b13c: ldr     x8, [x8, #0x970]                           &6645c70(=0)
02c9b140: ldr     x19, [x20, #0x28]                          [662f028]=6000015 f=2.40742e-35,0
02c9b144: str     w0, [sp, #0x1c]                            
02c9b148: ldr     x8, [x8, #0x48]                            &6263098(=0)
02c9b14c: mov     x0, x8                                     
02c9b150: bl      #0x2b70f38                                 fn_2b70f38
02c9b154: adrp    x8, #0x6265000                             
02c9b158: mov     x2, x0                                     
02c9b15c: mov     x1, x19                                    
02c9b160: ldr     x8, [x8, #0xa48]                           S:'[NativeFull {0}] Max reload attempts reached ({1}). Stopping retries.'
02c9b164: mov     x3, xzr                                    
02c9b168: ldr     x8, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9b16c: mov     x0, x8                                     
02c9b170: bl      #0x4ca7720                                 System.String::Format
02c9b174: adrp    x8, #0x6263000                             
02c9b178: mov     x19, x0                                    
02c9b17c: ldr     x8, [x8, #0x928]                           T:UnityEngine.Debug
02c9b180: ldr     x8, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c9b184: ldr     w9, [x8, #0xe4]                            [62630e4]=0 f=0,0
02c9b188: cbnz    w9, #0x2c9b194                             
02c9b18c: mov     x0, x8                                     
02c9b190: bl      #0x2b70f30                                 fn_2b70f30
02c9b194: mov     x0, x19                                    
02c9b198: mov     x1, xzr                                    
02c9b19c: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02c9b1a0: str     xzr, [x20, #0x48]!                         
02c9b1a4: mov     x0, x20                                    
02c9b1a8: mov     x1, xzr                                    
02c9b1ac: bl      #0x2b70d54                                 fn_2b70d54
02c9b1b0: mov     w0, wzr                                    
02c9b1b4: ldp     x20, x19, [sp, #0x40]                      
02c9b1b8: ldr     d8, [sp, #0x10]                            
02c9b1bc: ldp     x22, x21, [sp, #0x30]                      
02c9b1c0: ldp     x30, x23, [sp, #0x20]                      
02c9b1c4: add     sp, sp, #0x50                              
02c9b1c8: ret                                                
02c9b1cc: bl      #0x2b7105c                                 fn_2b7105c
## System.Collections.Generic.IEnumerator<System.Object>.get_Current() -> object
---- NativeFsnManager/<ReloadCoroutine>d__18::System.Collections.Generic.IEnumerator<System.Object>.get_Current 0x2c9b1d0
02c9b1d0: ldr     x0, [x0, #0x18]                            .<>2__current
02c9b1d4: ret                                                
## System.Collections.IEnumerator.Reset() -> void
---- NativeFsnManager/<ReloadCoroutine>d__18::System.Collections.IEnumerator.Reset 0x2c9b1d8
02c9b1d8: stp     x30, x19, [sp, #-0x10]!                    
02c9b1dc: adrp    x0, #0x6264000                             
02c9b1e0: ldr     x0, [x0, #0xf60]                           T:System.NotSupportedException
02c9b1e4: bl      #0x2b70dc4                                 fn_2b70dc4
02c9b1e8: bl      #0x2b7104c                                 fn_2b7104c
02c9b1ec: mov     x1, xzr                                    
02c9b1f0: mov     x19, x0                                    
02c9b1f4: bl      #0x4e14238                                 System.NotSupportedException::.ctor
02c9b1f8: adrp    x0, #0x6265000                             
02c9b1fc: ldr     x0, [x0, #0xa58]                           M:NativeFsnManager/<ReloadCoroutine>d__18::System.Collections.IEnumerator.Reset
02c9b200: bl      #0x2b70dc4                                 fn_2b70dc4
02c9b204: mov     x1, x0                                     
02c9b208: mov     x0, x19                                    
02c9b20c: bl      #0x2b70f20                                 fn_2b70f20
## System.Collections.IEnumerator.get_Current() -> object
---- NativeFsnManager/<ReloadCoroutine>d__18::System.Collections.IEnumerator.get_Current 0x2c9b210
02c9b210: ldr     x0, [x0, #0x18]                            .<>2__current
02c9b214: ret                                                
#### CLASS NativeFsnManager parent= UnityEngine.MonoBehaviour
#   field _primaryAd                     FsnAd                                              off=0x20 attr=1 
#   field _logTag                        string                                             off=0x28 attr=1 
#   field _adID                          string                                             off=0x30 attr=1 
#   field _showTime                      int                                                off=0x38 attr=1 
#   field _retryAttempt                  int                                                off=0x3c attr=1 
#   field _maxRetryAttempts              int                                                off=0x40 attr=21 
#   field _reloadCoroutine               UnityEngine.Coroutine                              off=0x48 attr=1 
## get_IsEnabled() -> bool
---- NativeFsnManager::get_IsEnabled 0x2c99e54
02c99e54: str     x30, [sp, #-0x20]!                         
02c99e58: stp     x20, x19, [sp, #0x10]                      
02c99e5c: adrp    x20, #0x662f000                            
02c99e60: adrp    x19, #0x6264000                            
02c99e64: ldrb    w8, [x20, #0xa2e]                          
02c99e68: ldr     x19, [x19, #0xfc0]                         T:RemoteConfigManager
02c99e6c: tbnz    w8, #0, #0x2c99e84                         
02c99e70: adrp    x0, #0x6264000                             
02c99e74: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02c99e78: bl      #0x2b70db0                                 fn_2b70db0
02c99e7c: mov     w8, #1                                     
02c99e80: strb    w8, [x20, #0xa2e]                          
02c99e84: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c99e88: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c99e8c: cbnz    w8, #0x2c99e94                             
02c99e90: bl      #0x2b70f30                                 fn_2b70f30
02c99e94: adrp    x20, #0x662f000                            
02c99e98: ldrb    w8, [x20, #0xa7c]                          
02c99e9c: cbnz    w8, #0x2c99eb4                             
02c99ea0: adrp    x0, #0x6264000                             
02c99ea4: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02c99ea8: bl      #0x2b70db0                                 fn_2b70db0
02c99eac: mov     w8, #1                                     
02c99eb0: strb    w8, [x20, #0xa7c]                          
02c99eb4: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c99eb8: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c99ebc: cbnz    w8, #0x2c99ec8                             
02c99ec0: bl      #0x2b70f30                                 fn_2b70f30
02c99ec4: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c99ec8: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02c99ecc: ldp     x20, x19, [sp, #0x10]                      
02c99ed0: ldrb    w0, [x8, #0x14]                            
02c99ed4: ldr     x30, [sp], #0x20                           
02c99ed8: ret                                                
## get_IsReady() -> bool
---- NativeFsnManager::get_IsReady 0x2c91944
02c91944: ldr     x0, [x0, #0x20]                            ._primaryAd
02c91948: cbz     x0, #0x2c91950                             
02c9194c: b       #0x2c93a18                                 FsnAd::IsAdReady
02c91950: ret                                                
## LoadAd(string adID, string logTag, int showTime) -> void
---- NativeFsnManager::LoadAd 0x2c92600
02c92600: str     x30, [sp, #-0x30]!                         
02c92604: stp     x22, x21, [sp, #0x10]                      
02c92608: stp     x20, x19, [sp, #0x20]                      
02c9260c: mov     x22, x0                                    
02c92610: mov     x21, x0                                    
02c92614: mov     w19, w3                                    
02c92618: str     x1, [x22, #0x30]!                          
02c9261c: mov     x0, x22                                    
02c92620: mov     x20, x2                                    
02c92624: bl      #0x2b70d54                                 fn_2b70d54
02c92628: mov     x0, x21                                    
02c9262c: mov     x1, x20                                    
02c92630: str     x20, [x0, #0x28]!                          ._logTag
02c92634: bl      #0x2b70d54                                 fn_2b70d54
02c92638: ldr     x1, [x22]                                  
02c9263c: stp     w19, wzr, [x21, #0x38]                     ._showTime
02c92640: mov     x0, x21                                    
02c92644: ldp     x20, x19, [sp, #0x20]                      
02c92648: ldp     x22, x21, [sp, #0x10]                      
02c9264c: ldr     x30, [sp], #0x30                           
02c92650: b       #0x2c99edc                                 NativeFsnManager::LoadFsnAd
## LoadFsnAd(string adID) -> void
---- NativeFsnManager::LoadFsnAd 0x2c99edc
02c99edc: str     x30, [sp, #-0x30]!                         
02c99ee0: stp     x22, x21, [sp, #0x10]                      
02c99ee4: stp     x20, x19, [sp, #0x20]                      
02c99ee8: adrp    x21, #0x662f000                            
02c99eec: mov     x20, x1                                    
02c99ef0: mov     x19, x0                                    
02c99ef4: ldrb    w8, [x21, #0xa2f]                          
02c99ef8: tbnz    w8, #0, #0x2c99f28                         
02c99efc: adrp    x0, #0x6265000                             
02c99f00: ldr     x0, [x0, #0x9d8]                           T:FsnAd
02c99f04: bl      #0x2b70db0                                 fn_2b70db0
02c99f08: adrp    x0, #0x6265000                             
02c99f0c: ldr     x0, [x0, #0x488]                           T:KeyTest
02c99f10: bl      #0x2b70db0                                 fn_2b70db0
02c99f14: adrp    x0, #0x6265000                             
02c99f18: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02c99f1c: bl      #0x2b70db0                                 fn_2b70db0
02c99f20: mov     w8, #1                                     
02c99f24: strb    w8, [x21, #0xa2f]                          
02c99f28: bl      #0x2c99e54                                 NativeFsnManager::get_IsEnabled
02c99f2c: tbz     w0, #0, #0x2c9a004                         
02c99f30: adrp    x8, #0x6265000                             
02c99f34: ldr     x8, [x8, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02c99f38: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c99f3c: bl      #0x3be7218                                 fn_3be7218
02c99f40: cbz     x0, #0x2c9a014                             
02c99f44: ldrb    w8, [x0, #0x31]                            
02c99f48: cbz     w8, #0x2c99f70                             
02c99f4c: adrp    x20, #0x6265000                            
02c99f50: ldr     x20, [x20, #0x488]                         T:KeyTest
02c99f54: ldr     x0, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c99f58: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c99f5c: cbnz    w8, #0x2c99f68                             
02c99f60: bl      #0x2b70f30                                 fn_2b70f30
02c99f64: ldr     x0, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c99f68: ldr     x8, [x0, #0xb8]                            T:AdsManager/<>c__DisplayClass42_0
02c99f6c: ldr     x20, [x8, #0x20]                           S:'dev log AdsManager show app open ad'
02c99f70: mov     x0, x19                                    
02c99f74: bl      #0x2c9a018                                 NativeFsnManager::StopReloadCoroutine
02c99f78: mov     x21, x19                                   
02c99f7c: ldr     x0, [x21, #0x20]!                          &2b706f0(=d65f03c0f9400800) ._primaryAd
02c99f80: cbz     x0, #0x2c99f88                             
02c99f84: bl      #0x2c93be0                                 FsnAd::Release
02c99f88: mov     x0, x21                                    
02c99f8c: mov     x1, xzr                                    
02c99f90: str     xzr, [x21]                                 
02c99f94: bl      #0x2b70d54                                 fn_2b70d54
02c99f98: adrp    x8, #0x6265000                             
02c99f9c: ldr     x8, [x8, #0x9d8]                           T:FsnAd
02c99fa0: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c99fa4: bl      #0x2b7104c                                 fn_2b7104c
02c99fa8: mov     x22, x0                                    
02c99fac: bl      #0x2c92ecc                                 FsnAd::.ctor
02c99fb0: mov     x0, x21                                    
02c99fb4: mov     x1, x22                                    
02c99fb8: str     x22, [x21]                                 
02c99fbc: bl      #0x2b70d54                                 fn_2b70d54
02c99fc0: ldr     x0, [x21]                                  &2b706c4(=eb01011ff9400808)
02c99fc4: cbz     x0, #0x2c9a014                             
02c99fc8: ldr     w2, [x19, #0x38]                           ._showTime
02c99fcc: mov     x1, x20                                    
02c99fd0: mov     w3, #1                                     
02c99fd4: mov     w4, wzr                                    
02c99fd8: mov     w5, #1                                     
02c99fdc: bl      #0x2c9300c                                 FsnAd::Init
02c99fe0: ldr     x1, [x19, #0x20]                           ._primaryAd
02c99fe4: mov     x0, x19                                    
02c99fe8: bl      #0x2c9a05c                                 NativeFsnManager::RegisterListener
02c99fec: ldr     x0, [x19, #0x20]                           ._primaryAd
02c99ff0: cbz     x0, #0x2c9a014                             
02c99ff4: ldp     x20, x19, [sp, #0x20]                      
02c99ff8: ldp     x22, x21, [sp, #0x10]                      
02c99ffc: ldr     x30, [sp], #0x30                           
02c9a000: b       #0x2c934b0                                 FsnAd::LoadAd
02c9a004: ldp     x20, x19, [sp, #0x20]                      
02c9a008: ldp     x22, x21, [sp, #0x10]                      
02c9a00c: ldr     x30, [sp], #0x30                           
02c9a010: ret                                                
02c9a014: bl      #0x2b7105c                                 fn_2b7105c
## StopReloadCoroutine() -> void
---- NativeFsnManager::StopReloadCoroutine 0x2c9a018
02c9a018: str     x30, [sp, #-0x20]!                         
02c9a01c: stp     x20, x19, [sp, #0x10]                      
02c9a020: mov     x20, x0                                    
02c9a024: ldr     x1, [x20, #0x48]!                          ._reloadCoroutine
02c9a028: cbz     x1, #0x2c9a050                             
02c9a02c: mov     x2, xzr                                    
02c9a030: mov     x19, x0                                    
02c9a034: bl      #0x5b38c4c                                 UnityEngine.MonoBehaviour::StopCoroutine
02c9a038: mov     x0, x20                                    
02c9a03c: str     xzr, [x19, #0x48]                          ._reloadCoroutine
02c9a040: mov     x1, xzr                                    
02c9a044: ldp     x20, x19, [sp, #0x10]                      
02c9a048: ldr     x30, [sp], #0x20                           
02c9a04c: b       #0x2b70d54                                 
02c9a050: ldp     x20, x19, [sp, #0x10]                      
02c9a054: ldr     x30, [sp], #0x20                           
02c9a058: ret                                                
## RegisterListener(FsnAd ad) -> void
---- NativeFsnManager::RegisterListener 0x2c9a05c
02c9a05c: sub     sp, sp, #0x70                              
02c9a060: stp     x29, x30, [sp, #0x10]                      
02c9a064: stp     x28, x27, [sp, #0x20]                      
02c9a068: stp     x26, x25, [sp, #0x30]                      
02c9a06c: stp     x24, x23, [sp, #0x40]                      
02c9a070: stp     x22, x21, [sp, #0x50]                      
02c9a074: stp     x20, x19, [sp, #0x60]                      
02c9a078: adrp    x21, #0x662f000                            
02c9a07c: mov     x19, x1                                    
02c9a080: mov     x20, x0                                    
02c9a084: ldrb    w8, [x21, #0xa30]                          
02c9a088: tbnz    w8, #0, #0x2c9a10c                         
02c9a08c: adrp    x0, #0x6265000                             
02c9a090: ldr     x0, [x0, #0x870]                           T:type7171(k15)
02c9a094: bl      #0x2b70db0                                 fn_2b70db0
02c9a098: adrp    x0, #0x6265000                             
02c9a09c: ldr     x0, [x0, #0x878]                           T:type7291(k15)
02c9a0a0: bl      #0x2b70db0                                 fn_2b70db0
02c9a0a4: adrp    x0, #0x6264000                             
02c9a0a8: ldr     x0, [x0, #0xf90]                           T:System.Action
02c9a0ac: bl      #0x2b70db0                                 fn_2b70db0
02c9a0b0: adrp    x0, #0x6263000                             
02c9a0b4: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c9a0b8: bl      #0x2b70db0                                 fn_2b70db0
02c9a0bc: adrp    x0, #0x6265000                             
02c9a0c0: ldr     x0, [x0, #0x9e0]                           M:NativeFsnManager::<RegisterListener>b__14_0
02c9a0c4: bl      #0x2b70db0                                 fn_2b70db0
02c9a0c8: adrp    x0, #0x6265000                             
02c9a0cc: ldr     x0, [x0, #0x9e8]                           M:NativeFsnManager::<RegisterListener>b__14_1
02c9a0d0: bl      #0x2b70db0                                 fn_2b70db0
02c9a0d4: adrp    x0, #0x6265000                             
02c9a0d8: ldr     x0, [x0, #0x9f0]                           M:NativeFsnManager::<RegisterListener>b__14_2
02c9a0dc: bl      #0x2b70db0                                 fn_2b70db0
02c9a0e0: adrp    x0, #0x6265000                             
02c9a0e4: ldr     x0, [x0, #0x600]                           S:'[NativeFull '
02c9a0e8: bl      #0x2b70db0                                 fn_2b70db0
02c9a0ec: adrp    x0, #0x6265000                             
02c9a0f0: ldr     x0, [x0, #0x9f8]                           S:'] IsAdReady='
02c9a0f4: bl      #0x2b70db0                                 fn_2b70db0
02c9a0f8: adrp    x0, #0x6265000                             
02c9a0fc: ldr     x0, [x0, #0xa00]                           S:'] RegisterListener called, ad='
02c9a100: bl      #0x2b70db0                                 fn_2b70db0
02c9a104: mov     w8, #1                                     
02c9a108: strb    w8, [x21, #0xa30]                          
02c9a10c: strb    wzr, [sp, #0xc]                            
02c9a110: cbz     x19, #0x2c9a28c                            
02c9a114: adrp    x8, #0x6265000                             
02c9a118: adrp    x10, #0x6265000                            
02c9a11c: adrp    x26, #0x6263000                            
02c9a120: adrp    x24, #0x6265000                            
02c9a124: adrp    x25, #0x6265000                            
02c9a128: adrp    x29, #0x6264000                            
02c9a12c: adrp    x28, #0x6265000                            
02c9a130: adrp    x27, #0x6265000                            
02c9a134: ldr     x8, [x8, #0xa00]                           S:'] RegisterListener called, ad='
02c9a138: ldr     x10, [x10, #0x600]                         S:'[NativeFull '
02c9a13c: ldr     x26, [x26, #0x928]                         T:UnityEngine.Debug
02c9a140: ldr     x24, [x24, #0x870]                         T:type7171(k15)
02c9a144: ldr     x25, [x25, #0x9e0]                         M:NativeFsnManager::<RegisterListener>b__14_0
02c9a148: ldr     x29, [x29, #0xf90]                         T:System.Action
02c9a14c: ldr     x28, [x28, #0x9e8]                         M:NativeFsnManager::<RegisterListener>b__14_1
02c9a150: ldr     x27, [x27, #0x878]                         T:type7291(k15)
02c9a154: ldr     x9, [x19]                                  
02c9a158: ldr     x22, [x8]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9a15c: ldr     x21, [x20, #0x28]                          ._logTag
02c9a160: ldr     x23, [x10]                                 M:AdsManager::<OnApplicationPause>b__26_0
02c9a164: mov     x0, x19                                    
02c9a168: ldp     x8, x1, [x9, #0x168]                       
02c9a16c: blr     x8                                         
02c9a170: mov     x3, x0                                     
02c9a174: mov     x0, x23                                    
02c9a178: mov     x1, x21                                    
02c9a17c: mov     x2, x22                                    
02c9a180: mov     x4, xzr                                    
02c9a184: bl      #0x4ca7320                                 System.String::Concat
02c9a188: ldr     x8, [x26]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9a18c: mov     x21, x0                                    
02c9a190: ldr     w9, [x8, #0xe4]                            [62650e4]=0 f=0,0
02c9a194: cbnz    w9, #0x2c9a1a0                             
02c9a198: mov     x0, x8                                     
02c9a19c: bl      #0x2b70f30                                 fn_2b70f30
02c9a1a0: adrp    x26, #0x6265000                            
02c9a1a4: mov     x0, x21                                    
02c9a1a8: mov     x1, xzr                                    
02c9a1ac: ldr     x26, [x26, #0x9f8]                         S:'] IsAdReady='
02c9a1b0: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02c9a1b4: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9a1b8: bl      #0x2b7104c                                 fn_2b7104c
02c9a1bc: ldr     x2, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9a1c0: mov     x1, x20                                    
02c9a1c4: mov     x3, xzr                                    
02c9a1c8: mov     x21, x0                                    
02c9a1cc: bl      #0x453c1e0                                 fn_453c1e0
02c9a1d0: ldr     x0, [x29]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c9a1d4: bl      #0x2b7104c                                 fn_2b7104c
02c9a1d8: ldr     x2, [x28]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9a1dc: mov     x1, x20                                    
02c9a1e0: mov     x3, xzr                                    
02c9a1e4: mov     x22, x0                                    
02c9a1e8: bl      #0x4d8ddbc                                 System.Action::.ctor
02c9a1ec: ldr     x0, [x27]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9a1f0: bl      #0x2b7104c                                 fn_2b7104c
02c9a1f4: adrp    x8, #0x6265000                             
02c9a1f8: mov     x1, x20                                    
02c9a1fc: mov     x3, xzr                                    
02c9a200: ldr     x8, [x8, #0x9f0]                           M:NativeFsnManager::<RegisterListener>b__14_2
02c9a204: mov     x23, x0                                    
02c9a208: ldr     x2, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9a20c: bl      #0x453ea7c                                 fn_453ea7c
02c9a210: mov     x0, x19                                    
02c9a214: mov     x1, x21                                    
02c9a218: mov     x2, x22                                    
02c9a21c: mov     x3, x23                                    
02c9a220: bl      #0x2c93270                                 FsnAd::SetFsnListener
02c9a224: ldr     x20, [x20, #0x28]                          ._logTag
02c9a228: mov     x0, x19                                    
02c9a22c: bl      #0x2c93a18                                 FsnAd::IsAdReady
02c9a230: adrp    x9, #0x6263000                             
02c9a234: mov     w8, w0                                     
02c9a238: ldr     x9, [x9, #0x970]                           &6645c70(=0)
02c9a23c: and     w8, w8, #1                                 
02c9a240: strb    w8, [sp, #0xc]                             
02c9a244: ldr     x0, [x9, #0x28]                            [6263028]=0 f=0,0
02c9a248: ldr     w9, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c9a24c: cbnz    w9, #0x2c9a254                             
02c9a250: bl      #0x2b70f30                                 fn_2b70f30
02c9a254: add     x0, sp, #0xc                               
02c9a258: mov     x1, xzr                                    
02c9a25c: bl      #0x4d91244                                 System.Boolean::ToString
02c9a260: adrp    x8, #0x6265000                             
02c9a264: mov     x3, x0                                     
02c9a268: mov     x1, x20                                    
02c9a26c: ldr     x8, [x8, #0x600]                           S:'[NativeFull '
02c9a270: ldr     x2, [x26]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9a274: mov     x4, xzr                                    
02c9a278: ldr     x8, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9a27c: mov     x0, x8                                     
02c9a280: bl      #0x4ca7320                                 System.String::Concat
02c9a284: mov     x1, xzr                                    
02c9a288: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02c9a28c: ldp     x20, x19, [sp, #0x60]                      
02c9a290: ldp     x22, x21, [sp, #0x50]                      
02c9a294: ldp     x24, x23, [sp, #0x40]                      
02c9a298: ldp     x26, x25, [sp, #0x30]                      
02c9a29c: ldp     x28, x27, [sp, #0x20]                      
02c9a2a0: ldp     x29, x30, [sp, #0x10]                      
02c9a2a4: add     sp, sp, #0x70                              
02c9a2a8: ret                                                
## ShowAd(System.Action onComplete) -> void
---- NativeFsnManager::ShowAd 0x2c91a0c
02c91a0c: str     x30, [sp, #-0x40]!                         
02c91a10: stp     x24, x23, [sp, #0x10]                      
02c91a14: stp     x22, x21, [sp, #0x20]                      
02c91a18: stp     x20, x19, [sp, #0x30]                      
02c91a1c: adrp    x23, #0x662f000                            
02c91a20: adrp    x22, #0x6265000                            
02c91a24: adrp    x24, #0x6265000                            
02c91a28: adrp    x21, #0x6263000                            
02c91a2c: ldr     x22, [x22, #0x600]                         S:'[NativeFull '
02c91a30: ldrb    w8, [x23, #0xa31]                          
02c91a34: ldr     x24, [x24, #0x608]                         S:'] ShowAdLoading'
02c91a38: ldr     x21, [x21, #0x928]                         T:UnityEngine.Debug
02c91a3c: mov     x19, x1                                    
02c91a40: mov     x20, x0                                    
02c91a44: tbnz    w8, #0, #0x2c91a74                         
02c91a48: adrp    x0, #0x6263000                             
02c91a4c: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c91a50: bl      #0x2b70db0                                 fn_2b70db0
02c91a54: adrp    x0, #0x6265000                             
02c91a58: ldr     x0, [x0, #0x600]                           S:'[NativeFull '
02c91a5c: bl      #0x2b70db0                                 fn_2b70db0
02c91a60: adrp    x0, #0x6265000                             
02c91a64: ldr     x0, [x0, #0x608]                           S:'] ShowAdLoading'
02c91a68: bl      #0x2b70db0                                 fn_2b70db0
02c91a6c: mov     w8, #1                                     
02c91a70: strb    w8, [x23, #0xa31]                          
02c91a74: ldr     x1, [x20, #0x28]                           ._logTag
02c91a78: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c91a7c: mov     x3, xzr                                    
02c91a80: ldr     x2, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c91a84: bl      #0x4ca6dbc                                 System.String::Concat
02c91a88: ldr     x8, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c91a8c: mov     x21, x0                                    
02c91a90: ldr     w9, [x8, #0xe4]                            
02c91a94: cbnz    w9, #0x2c91aa0                             
02c91a98: mov     x0, x8                                     
02c91a9c: bl      #0x2b70f30                                 fn_2b70f30
02c91aa0: mov     x0, x21                                    
02c91aa4: mov     x1, xzr                                    
02c91aa8: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02c91aac: bl      #0x2c99e54                                 NativeFsnManager::get_IsEnabled
02c91ab0: tbz     w0, #0, #0x2c91ad0                         
02c91ab4: ldr     x1, [x20, #0x20]                           ._primaryAd
02c91ab8: mov     x2, x19                                    
02c91abc: ldp     x20, x19, [sp, #0x30]                      
02c91ac0: ldp     x22, x21, [sp, #0x20]                      
02c91ac4: ldp     x24, x23, [sp, #0x10]                      
02c91ac8: ldr     x30, [sp], #0x40                           
02c91acc: b       #0x2c9a2ac                                 NativeFsnManager::ShowFsnAd
02c91ad0: cbz     x19, #0x2c91af4                            
02c91ad4: ldr     x0, [x19, #0x40]                           ._maxRetryAttempts
02c91ad8: ldr     x1, [x19, #0x28]                           ._logTag
02c91adc: ldr     x2, [x19, #0x18]                           
02c91ae0: ldp     x20, x19, [sp, #0x30]                      
02c91ae4: ldp     x22, x21, [sp, #0x20]                      
02c91ae8: ldp     x24, x23, [sp, #0x10]                      
02c91aec: ldr     x30, [sp], #0x40                           
02c91af0: br      x2                                         
02c91af4: ldp     x20, x19, [sp, #0x30]                      
02c91af8: ldp     x22, x21, [sp, #0x20]                      
02c91afc: ldp     x24, x23, [sp, #0x10]                      
02c91b00: ldr     x30, [sp], #0x40                           
02c91b04: ret                                                
## ShowFsnAd(FsnAd ad, System.Action onComplete) -> void
---- NativeFsnManager::ShowFsnAd 0x2c9a2ac
02c9a2ac: str     x30, [sp, #-0x30]!                         
02c9a2b0: stp     x22, x21, [sp, #0x10]                      
02c9a2b4: stp     x20, x19, [sp, #0x20]                      
02c9a2b8: adrp    x21, #0x662f000                            
02c9a2bc: adrp    x22, #0x6265000                            
02c9a2c0: mov     x20, x2                                    
02c9a2c4: ldrb    w8, [x21, #0xa32]                          
02c9a2c8: ldr     x22, [x22, #0xa08]                         T:NativeFsnManager/<>c__DisplayClass16_0
02c9a2cc: mov     x19, x1                                    
02c9a2d0: tbnz    w8, #0, #0x2c9a300                         
02c9a2d4: adrp    x0, #0x6265000                             
02c9a2d8: ldr     x0, [x0, #0x4e0]                           T:type7027(k15)
02c9a2dc: bl      #0x2b70db0                                 fn_2b70db0
02c9a2e0: adrp    x0, #0x6265000                             
02c9a2e4: ldr     x0, [x0, #0xa10]                           M:NativeFsnManager/<>c__DisplayClass16_0::<ShowFsnAd>b__0
02c9a2e8: bl      #0x2b70db0                                 fn_2b70db0
02c9a2ec: adrp    x0, #0x6265000                             
02c9a2f0: ldr     x0, [x0, #0xa08]                           T:NativeFsnManager/<>c__DisplayClass16_0
02c9a2f4: bl      #0x2b70db0                                 fn_2b70db0
02c9a2f8: mov     w8, #1                                     
02c9a2fc: strb    w8, [x21, #0xa32]                          
02c9a300: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9a304: bl      #0x2b7104c                                 fn_2b7104c
02c9a308: mov     x1, xzr                                    
02c9a30c: mov     x21, x0                                    
02c9a310: bl      #0x4e53e9c                                 System.Object::.ctor
02c9a314: cbz     x21, #0x2c9a3b4                            
02c9a318: mov     x22, x21                                   
02c9a31c: mov     x1, x20                                    
02c9a320: str     x20, [x22, #0x10]!                         
02c9a324: mov     x0, x22                                    
02c9a328: bl      #0x2b70d54                                 fn_2b70d54
02c9a32c: cbz     x19, #0x2c9a380                            
02c9a330: mov     x0, x19                                    
02c9a334: bl      #0x2c93a18                                 FsnAd::IsAdReady
02c9a338: tbz     w0, #0, #0x2c9a380                         
02c9a33c: adrp    x8, #0x6265000                             
02c9a340: ldr     x8, [x8, #0x4e0]                           T:type7027(k15)
02c9a344: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9a348: bl      #0x2b7104c                                 fn_2b7104c
02c9a34c: adrp    x8, #0x6265000                             
02c9a350: mov     x1, x21                                    
02c9a354: mov     x3, xzr                                    
02c9a358: ldr     x8, [x8, #0xa10]                           M:NativeFsnManager/<>c__DisplayClass16_0::<ShowFsnAd>b__0
02c9a35c: mov     x20, x0                                    
02c9a360: ldr     x2, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9a364: bl      #0x453418c                                 fn_453418c
02c9a368: mov     x0, x19                                    
02c9a36c: mov     x1, x20                                    
02c9a370: ldp     x20, x19, [sp, #0x20]                      
02c9a374: ldp     x22, x21, [sp, #0x10]                      
02c9a378: ldr     x30, [sp], #0x30                           
02c9a37c: b       #0x2c93634                                 FsnAd::ShowAd
02c9a380: ldr     x8, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9a384: cbz     x8, #0x2c9a3a4                             
02c9a388: ldp     x20, x19, [sp, #0x20]                      
02c9a38c: ldr     x0, [x8, #0x40]                            S:'done_ad'
02c9a390: ldp     x22, x21, [sp, #0x10]                      
02c9a394: ldr     x1, [x8, #0x28]                            T:AdsManager/<ISetAOAInterval>d__33
02c9a398: ldr     x2, [x8, #0x18]                            T:AdsManager/<IEHideAdResume>d__30
02c9a39c: ldr     x30, [sp], #0x30                           
02c9a3a0: br      x2                                         
02c9a3a4: ldp     x20, x19, [sp, #0x20]                      
02c9a3a8: ldp     x22, x21, [sp, #0x10]                      
02c9a3ac: ldr     x30, [sp], #0x30                           
02c9a3b0: ret                                                
02c9a3b4: bl      #0x2b7105c                                 fn_2b7105c
## TryReloadAd() -> void
---- NativeFsnManager::TryReloadAd 0x2c9a3c0
02c9a3c0: str     x30, [sp, #-0x20]!                         
02c9a3c4: stp     x20, x19, [sp, #0x10]                      
02c9a3c8: adrp    x20, #0x662f000                            
02c9a3cc: mov     x19, x0                                    
02c9a3d0: ldrb    w8, [x20, #0xa33]                          
02c9a3d4: tbnz    w8, #0, #0x2c9a404                         
02c9a3d8: adrp    x0, #0x6263000                             
02c9a3dc: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c9a3e0: bl      #0x2b70db0                                 fn_2b70db0
02c9a3e4: adrp    x0, #0x6265000                             
02c9a3e8: ldr     x0, [x0, #0x600]                           S:'[NativeFull '
02c9a3ec: bl      #0x2b70db0                                 fn_2b70db0
02c9a3f0: adrp    x0, #0x6265000                             
02c9a3f4: ldr     x0, [x0, #0xa18]                           S:'] TryReloadAd'
02c9a3f8: bl      #0x2b70db0                                 fn_2b70db0
02c9a3fc: mov     w8, #1                                     
02c9a400: strb    w8, [x20, #0xa33]                          
02c9a404: bl      #0x2c99e54                                 NativeFsnManager::get_IsEnabled
02c9a408: tbz     w0, #0, #0x2c9a478                         
02c9a40c: ldr     x0, [x19, #0x20]                           ._primaryAd
02c9a410: cbz     x0, #0x2c9a41c                             
02c9a414: bl      #0x2c93a18                                 FsnAd::IsAdReady
02c9a418: tbnz    w0, #0, #0x2c9a478                         
02c9a41c: adrp    x8, #0x6265000                             
02c9a420: adrp    x9, #0x6265000                             
02c9a424: mov     x3, xzr                                    
02c9a428: ldr     x8, [x8, #0x600]                           S:'[NativeFull '
02c9a42c: ldr     x9, [x9, #0xa18]                           S:'] TryReloadAd'
02c9a430: ldr     x1, [x19, #0x28]                           ._logTag
02c9a434: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9a438: ldr     x2, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9a43c: bl      #0x4ca6dbc                                 System.String::Concat
02c9a440: adrp    x8, #0x6263000                             
02c9a444: mov     x20, x0                                    
02c9a448: ldr     x8, [x8, #0x928]                           T:UnityEngine.Debug
02c9a44c: ldr     x8, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c9a450: ldr     w9, [x8, #0xe4]                            [62630e4]=0 f=0,0
02c9a454: cbnz    w9, #0x2c9a460                             
02c9a458: mov     x0, x8                                     
02c9a45c: bl      #0x2b70f30                                 fn_2b70f30
02c9a460: mov     x0, x20                                    
02c9a464: mov     x1, xzr                                    
02c9a468: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02c9a46c: mov     x20, x19                                   
02c9a470: ldr     x8, [x20, #0x48]!                          [662f048]=6000017 f=2.40742e-35,0 ._reloadCoroutine
02c9a474: cbz     x8, #0x2c9a484                             
02c9a478: ldp     x20, x19, [sp, #0x10]                      
02c9a47c: ldr     x30, [sp], #0x20                           
02c9a480: ret                                                
02c9a484: mov     x0, x19                                    
02c9a488: bl      #0x2c9a4b4                                 NativeFsnManager::ReloadCoroutine
02c9a48c: mov     x1, x0                                     
02c9a490: mov     x0, x19                                    
02c9a494: mov     x2, xzr                                    
02c9a498: bl      #0x5b389f0                                 UnityEngine.MonoBehaviour::StartCoroutine
02c9a49c: mov     x1, x0                                     
02c9a4a0: mov     x0, x20                                    
02c9a4a4: str     x1, [x19, #0x48]                           ._reloadCoroutine
02c9a4a8: ldp     x20, x19, [sp, #0x10]                      
02c9a4ac: ldr     x30, [sp], #0x20                           
02c9a4b0: b       #0x2b70d54                                 
## ReloadCoroutine() -> System.Collections.IEnumerator
---- NativeFsnManager::ReloadCoroutine 0x2c9a4b4
02c9a4b4: stp     x30, x21, [sp, #-0x20]!                    
02c9a4b8: stp     x20, x19, [sp, #0x10]                      
02c9a4bc: adrp    x20, #0x662f000                            
02c9a4c0: adrp    x21, #0x6265000                            
02c9a4c4: mov     x19, x0                                    
02c9a4c8: ldrb    w8, [x20, #0xa34]                          
02c9a4cc: ldr     x21, [x21, #0xa20]                         T:NativeFsnManager/<ReloadCoroutine>d__18
02c9a4d0: tbnz    w8, #0, #0x2c9a4e8                         
02c9a4d4: adrp    x0, #0x6265000                             
02c9a4d8: ldr     x0, [x0, #0xa20]                           T:NativeFsnManager/<ReloadCoroutine>d__18
02c9a4dc: bl      #0x2b70db0                                 fn_2b70db0
02c9a4e0: mov     w8, #1                                     
02c9a4e4: strb    w8, [x20, #0xa34]                          
02c9a4e8: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9a4ec: bl      #0x2b7104c                                 fn_2b7104c
02c9a4f0: mov     x1, xzr                                    
02c9a4f4: mov     x20, x0                                    
02c9a4f8: bl      #0x4e53e9c                                 System.Object::.ctor
02c9a4fc: mov     x0, x20                                    
02c9a500: mov     x1, x19                                    
02c9a504: str     wzr, [x20, #0x10]                          
02c9a508: str     x19, [x0, #0x20]!                          ._primaryAd
02c9a50c: bl      #0x2b70d54                                 fn_2b70d54
02c9a510: mov     x0, x20                                    
02c9a514: ldp     x20, x19, [sp, #0x10]                      
02c9a518: ldp     x30, x21, [sp], #0x20                      
02c9a51c: ret                                                
## .ctor() -> void
---- NativeFsnManager::.ctor 0x2c9a548
02c9a548: stp     x30, x21, [sp, #-0x20]!                    
02c9a54c: stp     x20, x19, [sp, #0x10]                      
02c9a550: adrp    x20, #0x662f000                            
02c9a554: adrp    x21, #0x6263000                            
02c9a558: mov     x19, x0                                    
02c9a55c: ldrb    w8, [x20, #0xa35]                          
02c9a560: ldr     x21, [x21, #0xa90]                         S:''
02c9a564: tbnz    w8, #0, #0x2c9a57c                         
02c9a568: adrp    x0, #0x6263000                             
02c9a56c: ldr     x0, [x0, #0xa90]                           S:''
02c9a570: bl      #0x2b70db0                                 fn_2b70db0
02c9a574: mov     w8, #1                                     
02c9a578: strb    w8, [x20, #0xa35]                          
02c9a57c: ldr     x1, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9a580: mov     x0, x19                                    
02c9a584: str     x1, [x0, #0x30]!                           ._adID
02c9a588: bl      #0x2b70d54                                 fn_2b70d54
02c9a58c: mov     w8, #3                                     
02c9a590: mov     w9, #0xa                                   
02c9a594: mov     x0, x19                                    
02c9a598: str     w8, [x19, #0x38]                           ._showTime
02c9a59c: mov     x1, xzr                                    
02c9a5a0: str     w9, [x19, #0x40]                           ._maxRetryAttempts
02c9a5a4: ldp     x20, x19, [sp, #0x10]                      
02c9a5a8: ldp     x30, x21, [sp], #0x20                      
02c9a5ac: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
## <RegisterListener>b__14_0(int errCode, string errMessage) -> void
---- NativeFsnManager::<RegisterListener>b__14_0 0x2c9a5b0
02c9a5b0: str     x30, [sp, #-0x40]!                         
02c9a5b4: stp     x24, x23, [sp, #0x10]                      
02c9a5b8: stp     x22, x21, [sp, #0x20]                      
02c9a5bc: stp     x20, x19, [sp, #0x30]                      
02c9a5c0: adrp    x22, #0x662f000                            
02c9a5c4: adrp    x24, #0x6265000                            
02c9a5c8: adrp    x23, #0x6263000                            
02c9a5cc: ldrb    w8, [x22, #0xa36]                          
02c9a5d0: ldr     x24, [x24, #0xa28]                         S:'[NativeFull {0}] On loading completed {{errorCode = {1}, errorMessage '
02c9a5d4: ldr     x23, [x23, #0x928]                         T:UnityEngine.Debug
02c9a5d8: mov     x21, x2                                    
02c9a5dc: mov     w20, w1                                    
02c9a5e0: mov     x19, x0                                    
02c9a5e4: tbnz    w8, #0, #0x2c9a608                         
02c9a5e8: adrp    x0, #0x6263000                             
02c9a5ec: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c9a5f0: bl      #0x2b70db0                                 fn_2b70db0
02c9a5f4: adrp    x0, #0x6265000                             
02c9a5f8: ldr     x0, [x0, #0xa28]                           S:'[NativeFull {0}] On loading completed {{errorCode = {1}, errorMessage '
02c9a5fc: bl      #0x2b70db0                                 fn_2b70db0
02c9a600: mov     w8, #1                                     
02c9a604: strb    w8, [x22, #0xa36]                          
02c9a608: adrp    x8, #0x6263000                             
02c9a60c: add     x1, sp, #0xc                               
02c9a610: ldr     x8, [x8, #0x970]                           &6645c70(=0)
02c9a614: ldr     x22, [x19, #0x28]                          ._logTag
02c9a618: str     w20, [sp, #0xc]                            
02c9a61c: ldr     x0, [x8, #0x48]                            &6263098(=0)
02c9a620: bl      #0x2b70f38                                 fn_2b70f38
02c9a624: ldr     x8, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9a628: mov     x2, x0                                     
02c9a62c: mov     x1, x22                                    
02c9a630: mov     x3, x21                                    
02c9a634: mov     x4, xzr                                    
02c9a638: mov     x0, x8                                     
02c9a63c: bl      #0x4ca7764                                 System.String::Format
02c9a640: ldr     x8, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9a644: mov     x21, x0                                    
02c9a648: ldr     w9, [x8, #0xe4]                            [62630e4]=0 f=0,0
02c9a64c: cbnz    w9, #0x2c9a658                             
02c9a650: mov     x0, x8                                     
02c9a654: bl      #0x2b70f30                                 fn_2b70f30
02c9a658: mov     x0, x21                                    
02c9a65c: mov     x1, xzr                                    
02c9a660: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02c9a664: cbz     w20, #0x2c9a674                            
02c9a668: mov     x0, x19                                    
02c9a66c: bl      #0x2c9a3c0                                 NativeFsnManager::TryReloadAd
02c9a670: b       #0x2c9a678                                 
02c9a674: str     wzr, [x19, #0x3c]                          ._retryAttempt
02c9a678: ldp     x20, x19, [sp, #0x30]                      
02c9a67c: ldp     x22, x21, [sp, #0x20]                      
02c9a680: ldp     x24, x23, [sp, #0x10]                      
02c9a684: ldr     x30, [sp], #0x40                           
02c9a688: ret                                                
## <RegisterListener>b__14_1() -> void
---- NativeFsnManager::<RegisterListener>b__14_1 0x2c9a68c
02c9a68c: stp     x30, x23, [sp, #-0x30]!                    
02c9a690: stp     x22, x21, [sp, #0x10]                      
02c9a694: stp     x20, x19, [sp, #0x20]                      
02c9a698: adrp    x22, #0x662f000                            
02c9a69c: adrp    x21, #0x6265000                            
02c9a6a0: adrp    x23, #0x6265000                            
02c9a6a4: adrp    x20, #0x6263000                            
02c9a6a8: ldr     x21, [x21, #0x600]                         S:'[NativeFull '
02c9a6ac: ldrb    w8, [x22, #0xa37]                          
02c9a6b0: ldr     x23, [x23, #0xa30]                         S:'] On loading started'
02c9a6b4: ldr     x20, [x20, #0x928]                         T:UnityEngine.Debug
02c9a6b8: mov     x19, x0                                    
02c9a6bc: tbnz    w8, #0, #0x2c9a6ec                         
02c9a6c0: adrp    x0, #0x6263000                             
02c9a6c4: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c9a6c8: bl      #0x2b70db0                                 fn_2b70db0
02c9a6cc: adrp    x0, #0x6265000                             
02c9a6d0: ldr     x0, [x0, #0x600]                           S:'[NativeFull '
02c9a6d4: bl      #0x2b70db0                                 fn_2b70db0
02c9a6d8: adrp    x0, #0x6265000                             
02c9a6dc: ldr     x0, [x0, #0xa30]                           S:'] On loading started'
02c9a6e0: bl      #0x2b70db0                                 fn_2b70db0
02c9a6e4: mov     w8, #1                                     
02c9a6e8: strb    w8, [x22, #0xa37]                          
02c9a6ec: ldr     x1, [x19, #0x28]                           ._logTag
02c9a6f0: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9a6f4: mov     x3, xzr                                    
02c9a6f8: ldr     x2, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9a6fc: bl      #0x4ca6dbc                                 System.String::Concat
02c9a700: ldr     x8, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9a704: mov     x19, x0                                    
02c9a708: ldr     w9, [x8, #0xe4]                            
02c9a70c: cbnz    w9, #0x2c9a718                             
02c9a710: mov     x0, x8                                     
02c9a714: bl      #0x2b70f30                                 fn_2b70f30
02c9a718: mov     x0, x19                                    
02c9a71c: ldp     x20, x19, [sp, #0x20]                      
02c9a720: ldp     x22, x21, [sp, #0x10]                      
02c9a724: mov     x1, xzr                                    
02c9a728: ldp     x30, x23, [sp], #0x30                      
02c9a72c: b       #0x5af21f4                                 UnityEngine.Debug::Log
## <RegisterListener>b__14_2(string adSource, string adUnitId, double valueMicros, string currencyCode) -> void
---- NativeFsnManager::<RegisterListener>b__14_2 0x2c9a730
02c9a730: sub     sp, sp, #0x90                              
02c9a734: str     d8, [sp, #0x20]                            
02c9a738: stp     x29, x30, [sp, #0x30]                      
02c9a73c: stp     x28, x27, [sp, #0x40]                      
02c9a740: stp     x26, x25, [sp, #0x50]                      
02c9a744: stp     x24, x23, [sp, #0x60]                      
02c9a748: stp     x22, x21, [sp, #0x70]                      
02c9a74c: stp     x20, x19, [sp, #0x80]                      
02c9a750: fmov    d8, d0                                     
02c9a754: adrp    x24, #0x662f000                            
02c9a758: adrp    x23, #0x6263000                            
02c9a75c: ldrb    w8, [x24, #0xa38]                          
02c9a760: ldr     x23, [x23, #0xa80]                         T:type24502(k1d)
02c9a764: mov     x22, x3                                    
02c9a768: mov     x20, x2                                    
02c9a76c: mov     x19, x1                                    
02c9a770: mov     x21, x0                                    
02c9a774: str     d0, [sp, #0x28]                            
02c9a778: tbnz    w8, #0, #0x2c9a88c                         
02c9a77c: adrp    x0, #0x6265000                             
02c9a780: ldr     x0, [x0, #0x2d0]                           T:AppsFlyerSDK.AFAdRevenueData
02c9a784: bl      #0x2b70db0                                 fn_2b70db0
02c9a788: adrp    x0, #0x6265000                             
02c9a78c: ldr     x0, [x0, #0x210]                           T:AdFormat
02c9a790: bl      #0x2b70db0                                 fn_2b70db0
02c9a794: adrp    x0, #0x6263000                             
02c9a798: ldr     x0, [x0, #0x900]                           T:AppsFlyerSDK.AppsFlyer
02c9a79c: bl      #0x2b70db0                                 fn_2b70db0
02c9a7a0: adrp    x0, #0x6263000                             
02c9a7a4: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c9a7a8: bl      #0x2b70db0                                 fn_2b70db0
02c9a7ac: adrp    x0, #0x6265000                             
02c9a7b0: ldr     x0, [x0, #0x2d8]                           MS:System.Collections.Generic.Dictionary`2::Add
02c9a7b4: bl      #0x2b70db0                                 fn_2b70db0
02c9a7b8: adrp    x0, #0x6265000                             
02c9a7bc: ldr     x0, [x0, #0x2e0]                           MS:System.Collections.Generic.Dictionary`2::.ctor
02c9a7c0: bl      #0x2b70db0                                 fn_2b70db0
02c9a7c4: adrp    x0, #0x6265000                             
02c9a7c8: ldr     x0, [x0, #0x2e8]                           T:type8944(k15)
02c9a7cc: bl      #0x2b70db0                                 fn_2b70db0
02c9a7d0: adrp    x0, #0x6265000                             
02c9a7d4: ldr     x0, [x0, #0x1f8]                           T:Firebase.Analytics.FirebaseAnalytics
02c9a7d8: bl      #0x2b70db0                                 fn_2b70db0
02c9a7dc: adrp    x0, #0x6263000                             
02c9a7e0: ldr     x0, [x0, #0xa80]                           T:type24502(k1d)
02c9a7e4: bl      #0x2b70db0                                 fn_2b70db0
02c9a7e8: adrp    x0, #0x6265000                             
02c9a7ec: ldr     x0, [x0, #0x1f0]                           T:type24519(k1d)
02c9a7f0: bl      #0x2b70db0                                 fn_2b70db0
02c9a7f4: adrp    x0, #0x6265000                             
02c9a7f8: ldr     x0, [x0, #0x200]                           T:Firebase.Analytics.Parameter
02c9a7fc: bl      #0x2b70db0                                 fn_2b70db0
02c9a800: adrp    x0, #0x6265000                             
02c9a804: ldr     x0, [x0, #0xa38]                           S:'[NativeFull {0}] OnAdPaid called with adSource={1}, adUnitId={2}, valu'
02c9a808: bl      #0x2b70db0                                 fn_2b70db0
02c9a80c: adrp    x0, #0x6265000                             
02c9a810: ldr     x0, [x0, #0x600]                           S:'[NativeFull '
02c9a814: bl      #0x2b70db0                                 fn_2b70db0
02c9a818: adrp    x0, #0x6264000                             
02c9a81c: ldr     x0, [x0, #0xd90]                           S:'{0}'
02c9a820: bl      #0x2b70db0                                 fn_2b70db0
02c9a824: adrp    x0, #0x6265000                             
02c9a828: ldr     x0, [x0, #0x280]                           S:'ad_unit_name'
02c9a82c: bl      #0x2b70db0                                 fn_2b70db0
02c9a830: adrp    x0, #0x6265000                             
02c9a834: ldr     x0, [x0, #0x288]                           S:'ad_format'
02c9a838: bl      #0x2b70db0                                 fn_2b70db0
02c9a83c: adrp    x0, #0x6265000                             
02c9a840: ldr     x0, [x0, #0xa40]                           S:'] OnAdPaid = '
02c9a844: bl      #0x2b70db0                                 fn_2b70db0
02c9a848: adrp    x0, #0x6265000                             
02c9a84c: ldr     x0, [x0, #0x2a0]                           S:'value'
02c9a850: bl      #0x2b70db0                                 fn_2b70db0
02c9a854: adrp    x0, #0x6265000                             
02c9a858: ldr     x0, [x0, #0x2a8]                           S:'ad_source'
02c9a85c: bl      #0x2b70db0                                 fn_2b70db0
02c9a860: adrp    x0, #0x6265000                             
02c9a864: ldr     x0, [x0, #0x2b0]                           S:'currency'
02c9a868: bl      #0x2b70db0                                 fn_2b70db0
02c9a86c: adrp    x0, #0x6265000                             
02c9a870: ldr     x0, [x0, #0x2b8]                           S:'USD'
02c9a874: bl      #0x2b70db0                                 fn_2b70db0
02c9a878: adrp    x0, #0x6265000                             
02c9a87c: ldr     x0, [x0, #0x2c0]                           S:'ad_impression'
02c9a880: bl      #0x2b70db0                                 fn_2b70db0
02c9a884: mov     w8, #1                                     
02c9a888: strb    w8, [x24, #0xa38]                          
02c9a88c: ldr     x0, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9a890: mov     w1, #5                                     
02c9a894: str     wzr, [sp, #0x18]                           
02c9a898: bl      #0x2b70ea0                                 fn_2b70ea0
02c9a89c: cbz     x0, #0x2c9ae2c                             
02c9a8a0: ldr     x24, [x21, #0x28]                          ._logTag
02c9a8a4: mov     x23, x0                                    
02c9a8a8: cbz     x24, #0x2c9a8c0                            
02c9a8ac: ldr     x8, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9a8b0: mov     x0, x24                                    
02c9a8b4: ldr     x1, [x8, #0x40]                            
02c9a8b8: bl      #0x2b70f34                                 fn_2b70f34
02c9a8bc: cbz     x0, #0x2c9ae20                             
02c9a8c0: ldr     w8, [x23, #0x18]                           &2c5d934(=d65f03c0d503245f)
02c9a8c4: cbz     w8, #0x2c9ae1c                             
02c9a8c8: mov     x0, x23                                    
02c9a8cc: mov     x1, x24                                    
02c9a8d0: str     x24, [x0, #0x20]!                          ._primaryAd
02c9a8d4: bl      #0x2b70d54                                 fn_2b70d54
02c9a8d8: cbz     x19, #0x2c9a8f0                            
02c9a8dc: ldr     x8, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9a8e0: mov     x0, x19                                    
02c9a8e4: ldr     x1, [x8, #0x40]                            
02c9a8e8: bl      #0x2b70f34                                 fn_2b70f34
02c9a8ec: cbz     x0, #0x2c9ae20                             
02c9a8f0: ldr     w8, [x23, #0x18]                           &2c5d934(=d65f03c0d503245f)
02c9a8f4: tst     w8, #0xfffffffe                            
02c9a8f8: b.eq    #0x2c9ae1c                                 
02c9a8fc: mov     x0, x23                                    
02c9a900: mov     x1, x19                                    
02c9a904: str     x19, [x0, #0x28]!                          ._logTag
02c9a908: bl      #0x2b70d54                                 fn_2b70d54
02c9a90c: cbz     x20, #0x2c9a924                            
02c9a910: ldr     x8, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9a914: mov     x0, x20                                    
02c9a918: ldr     x1, [x8, #0x40]                            
02c9a91c: bl      #0x2b70f34                                 fn_2b70f34
02c9a920: cbz     x0, #0x2c9ae20                             
02c9a924: ldr     w8, [x23, #0x18]                           &2c5d934(=d65f03c0d503245f)
02c9a928: cmp     w8, #2                                     
02c9a92c: b.ls    #0x2c9ae1c                                 
02c9a930: mov     x0, x23                                    
02c9a934: mov     x1, x20                                    
02c9a938: str     x20, [x0, #0x30]!                          ._adID
02c9a93c: bl      #0x2b70d54                                 fn_2b70d54
02c9a940: adrp    x8, #0x6263000                             
02c9a944: add     x1, sp, #8                                 
02c9a948: ldr     x8, [x8, #0x970]                           &6645c70(=0)
02c9a94c: str     d8, [sp, #8]                               
02c9a950: ldr     x0, [x8, #0x80]                            &2c498bc(=aa1f03e0d503245f)
02c9a954: bl      #0x2b70f38                                 fn_2b70f38
02c9a958: mov     x24, x0                                    
02c9a95c: cbz     x0, #0x2c9a974                             
02c9a960: ldr     x8, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9a964: mov     x0, x24                                    
02c9a968: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02c9a96c: bl      #0x2b70f34                                 fn_2b70f34
02c9a970: cbz     x0, #0x2c9ae20                             
02c9a974: ldr     w8, [x23, #0x18]                           &2c5d934(=d65f03c0d503245f)
02c9a978: tst     w8, #0xfffffffc                            
02c9a97c: b.eq    #0x2c9ae1c                                 
02c9a980: mov     x0, x23                                    
02c9a984: mov     x1, x24                                    
02c9a988: str     x24, [x0, #0x38]!                          ._showTime
02c9a98c: bl      #0x2b70d54                                 fn_2b70d54
02c9a990: cbz     x22, #0x2c9a9a8                            
02c9a994: ldr     x8, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9a998: mov     x0, x22                                    
02c9a99c: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02c9a9a0: bl      #0x2b70f34                                 fn_2b70f34
02c9a9a4: cbz     x0, #0x2c9ae20                             
02c9a9a8: ldr     w8, [x23, #0x18]                           &2c5d934(=d65f03c0d503245f)
02c9a9ac: cmp     w8, #4                                     
02c9a9b0: b.ls    #0x2c9ae1c                                 
02c9a9b4: adrp    x25, #0x6265000                            
02c9a9b8: adrp    x24, #0x6263000                            
02c9a9bc: mov     x0, x23                                    
02c9a9c0: ldr     x25, [x25, #0xa38]                         S:'[NativeFull {0}] OnAdPaid called with adSource={1}, adUnitId={2}, valu'
02c9a9c4: ldr     x24, [x24, #0x928]                         T:UnityEngine.Debug
02c9a9c8: mov     x1, x22                                    
02c9a9cc: str     x22, [x0, #0x40]!                          ._maxRetryAttempts
02c9a9d0: bl      #0x2b70d54                                 fn_2b70d54
02c9a9d4: ldr     x0, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9a9d8: mov     x1, x23                                    
02c9a9dc: mov     x2, xzr                                    
02c9a9e0: bl      #0x4ca77a8                                 System.String::Format
02c9a9e4: ldr     x8, [x24]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9a9e8: mov     x22, x0                                    
02c9a9ec: ldr     w9, [x8, #0xe4]                            [62630e4]=0 f=0,0
02c9a9f0: cbnz    w9, #0x2c9a9fc                             
02c9a9f4: mov     x0, x8                                     
02c9a9f8: bl      #0x2b70f30                                 fn_2b70f30
02c9a9fc: mov     x0, x22                                    
02c9aa00: mov     x1, xzr                                    
02c9aa04: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02c9aa08: ldr     x21, [x21, #0x28]                          ._logTag
02c9aa0c: add     x0, sp, #0x28                              
02c9aa10: mov     x1, xzr                                    
02c9aa14: bl      #0x4df8a50                                 System.Double::ToString
02c9aa18: adrp    x8, #0x6265000                             
02c9aa1c: adrp    x9, #0x6265000                             
02c9aa20: mov     x3, x0                                     
02c9aa24: ldr     x8, [x8, #0x600]                           S:'[NativeFull '
02c9aa28: ldr     x9, [x9, #0xa40]                           S:'] OnAdPaid = '
02c9aa2c: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9aa30: ldr     x2, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9aa34: mov     x1, x21                                    
02c9aa38: mov     x4, xzr                                    
02c9aa3c: bl      #0x4ca7320                                 System.String::Concat
02c9aa40: mov     x21, x0                                    
02c9aa44: ldr     x0, [x24]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9aa48: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c9aa4c: cbnz    w8, #0x2c9aa54                             
02c9aa50: bl      #0x2b70f30                                 fn_2b70f30
02c9aa54: mov     x0, x21                                    
02c9aa58: mov     x1, xzr                                    
02c9aa5c: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02c9aa60: adrp    x8, #0x6265000                             
02c9aa64: ldr     x8, [x8, #0x1f0]                           T:type24519(k1d)
02c9aa68: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9aa6c: mov     w1, #5                                     
02c9aa70: bl      #0x2b70ea0                                 fn_2b70ea0
02c9aa74: adrp    x25, #0x6265000                            
02c9aa78: mov     x21, x0                                    
02c9aa7c: ldr     x25, [x25, #0x200]                         T:Firebase.Analytics.Parameter
02c9aa80: ldr     x0, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9aa84: bl      #0x2b7104c                                 fn_2b7104c
02c9aa88: adrp    x24, #0x6265000                            
02c9aa8c: mov     x22, x0                                    
02c9aa90: ldr     x24, [x24, #0x2a8]                         S:'ad_source'
02c9aa94: ldr     x1, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9aa98: mov     x2, x19                                    
02c9aa9c: mov     x3, xzr                                    
02c9aaa0: bl      #0x2e07b48                                 Firebase.Analytics.Parameter::.ctor
02c9aaa4: cbz     x21, #0x2c9ae30                            
02c9aaa8: cbz     x22, #0x2c9aac0                            
02c9aaac: ldr     x8, [x21]                                  
02c9aab0: ldr     x1, [x8, #0x40]                            S:'done_ad'
02c9aab4: mov     x0, x22                                    
02c9aab8: bl      #0x2b70f34                                 fn_2b70f34
02c9aabc: cbz     x0, #0x2c9ae4c                             
02c9aac0: ldr     w8, [x21, #0x18]                           
02c9aac4: cbz     w8, #0x2c9ae34                             
02c9aac8: mov     x0, x21                                    
02c9aacc: str     x22, [x0, #0x20]!                          ._primaryAd
02c9aad0: mov     x1, x22                                    
02c9aad4: bl      #0x2b70d54                                 fn_2b70d54
02c9aad8: ldr     x0, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9aadc: bl      #0x2b7104c                                 fn_2b7104c
02c9aae0: adrp    x27, #0x6265000                            
02c9aae4: mov     x22, x0                                    
02c9aae8: ldr     x27, [x27, #0x280]                         S:'ad_unit_name'
02c9aaec: ldr     x1, [x27]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9aaf0: mov     x2, x20                                    
02c9aaf4: mov     x3, xzr                                    
02c9aaf8: bl      #0x2e07b48                                 Firebase.Analytics.Parameter::.ctor
02c9aafc: cbz     x22, #0x2c9ab14                            
02c9ab00: ldr     x8, [x21]                                  
02c9ab04: ldr     x1, [x8, #0x40]                            S:'done_ad'
02c9ab08: mov     x0, x22                                    
02c9ab0c: bl      #0x2b70f34                                 fn_2b70f34
02c9ab10: cbz     x0, #0x2c9ae58                             
02c9ab14: ldr     w8, [x21, #0x18]                           
02c9ab18: tst     w8, #0xfffffffe                            
02c9ab1c: b.eq    #0x2c9ae38                                 
02c9ab20: mov     x0, x21                                    
02c9ab24: str     x22, [x0, #0x28]!                          ._logTag
02c9ab28: mov     x1, x22                                    
02c9ab2c: bl      #0x2b70d54                                 fn_2b70d54
02c9ab30: adrp    x28, #0x6265000                            
02c9ab34: mov     w8, #8                                     
02c9ab38: ldr     x28, [x28, #0x210]                         T:AdFormat
02c9ab3c: str     w8, [sp, #4]                               
02c9ab40: ldr     x0, [x28]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9ab44: add     x1, sp, #4                                 
02c9ab48: bl      #0x2b70f38                                 fn_2b70f38
02c9ab4c: mov     x1, x0                                     
02c9ab50: adrp    x26, #0x6264000                            
02c9ab54: ldr     x26, [x26, #0xd90]                         S:'{0}'
02c9ab58: ldr     x0, [x26]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c9ab5c: mov     x2, xzr                                    
02c9ab60: bl      #0x4c9d0ec                                 System.String::Format
02c9ab64: mov     x23, x0                                    
02c9ab68: ldr     x0, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9ab6c: bl      #0x2b7104c                                 fn_2b7104c
02c9ab70: adrp    x29, #0x6265000                            
02c9ab74: mov     x22, x0                                    
02c9ab78: ldr     x29, [x29, #0x288]                         S:'ad_format'
02c9ab7c: ldr     x1, [x29]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9ab80: mov     x2, x23                                    
02c9ab84: mov     x3, xzr                                    
02c9ab88: bl      #0x2e07b48                                 Firebase.Analytics.Parameter::.ctor
02c9ab8c: cbz     x22, #0x2c9aba4                            
02c9ab90: ldr     x8, [x21]                                  
02c9ab94: ldr     x1, [x8, #0x40]                            S:'done_ad'
02c9ab98: mov     x0, x22                                    
02c9ab9c: bl      #0x2b70f34                                 fn_2b70f34
02c9aba0: cbz     x0, #0x2c9ae64                             
02c9aba4: ldr     w8, [x21, #0x18]                           
02c9aba8: cmp     w8, #2                                     
02c9abac: b.ls    #0x2c9ae3c                                 
02c9abb0: mov     x0, x21                                    
02c9abb4: str     x22, [x0, #0x30]!                          ._adID
02c9abb8: mov     x1, x22                                    
02c9abbc: bl      #0x2b70d54                                 fn_2b70d54
02c9abc0: ldr     d8, [sp, #0x28]                            
02c9abc4: ldr     x0, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9abc8: bl      #0x2b7104c                                 fn_2b7104c
02c9abcc: adrp    x8, #0x6265000                             
02c9abd0: mov     x22, x0                                    
02c9abd4: ldr     x8, [x8, #0x2a0]                           S:'value'
02c9abd8: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9abdc: fmov    d0, d8                                     
02c9abe0: mov     x2, xzr                                    
02c9abe4: bl      #0x2e07bf4                                 Firebase.Analytics.Parameter::.ctor
02c9abe8: cbz     x22, #0x2c9ac00                            
02c9abec: ldr     x8, [x21]                                  
02c9abf0: ldr     x1, [x8, #0x40]                            S:'done_ad'
02c9abf4: mov     x0, x22                                    
02c9abf8: bl      #0x2b70f34                                 fn_2b70f34
02c9abfc: cbz     x0, #0x2c9ae70                             
02c9ac00: ldr     w8, [x21, #0x18]                           
02c9ac04: tst     w8, #0xfffffffc                            
02c9ac08: b.eq    #0x2c9ae40                                 
02c9ac0c: mov     x0, x21                                    
02c9ac10: str     x22, [x0, #0x38]!                          ._showTime
02c9ac14: mov     x1, x22                                    
02c9ac18: bl      #0x2b70d54                                 fn_2b70d54
02c9ac1c: ldr     x0, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9ac20: mov     x23, x29                                   
02c9ac24: mov     x29, x28                                   
02c9ac28: bl      #0x2b7104c                                 fn_2b7104c
02c9ac2c: adrp    x28, #0x6265000                            
02c9ac30: adrp    x25, #0x6265000                            
02c9ac34: mov     x22, x0                                    
02c9ac38: ldr     x28, [x28, #0x2b0]                         S:'currency'
02c9ac3c: ldr     x25, [x25, #0x2b8]                         S:'USD'
02c9ac40: ldr     x1, [x28]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9ac44: ldr     x2, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9ac48: mov     x3, xzr                                    
02c9ac4c: bl      #0x2e07b48                                 Firebase.Analytics.Parameter::.ctor
02c9ac50: cbz     x22, #0x2c9ac68                            
02c9ac54: ldr     x8, [x21]                                  
02c9ac58: ldr     x1, [x8, #0x40]                            S:'done_ad'
02c9ac5c: mov     x0, x22                                    
02c9ac60: bl      #0x2b70f34                                 fn_2b70f34
02c9ac64: cbz     x0, #0x2c9ae7c                             
02c9ac68: ldr     w8, [x21, #0x18]                           
02c9ac6c: cmp     w8, #4                                     
02c9ac70: b.ls    #0x2c9ae44                                 
02c9ac74: mov     x0, x21                                    
02c9ac78: str     x22, [x0, #0x40]!                          ._maxRetryAttempts
02c9ac7c: mov     x1, x22                                    
02c9ac80: bl      #0x2b70d54                                 fn_2b70d54
02c9ac84: adrp    x8, #0x6265000                             
02c9ac88: ldr     x8, [x8, #0x1f8]                           T:Firebase.Analytics.FirebaseAnalytics
02c9ac8c: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9ac90: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c9ac94: cbnz    w8, #0x2c9ac9c                             
02c9ac98: bl      #0x2b70f30                                 fn_2b70f30
02c9ac9c: adrp    x8, #0x6265000                             
02c9aca0: ldr     x8, [x8, #0x2c0]                           S:'ad_impression'
02c9aca4: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9aca8: mov     x1, x21                                    
02c9acac: mov     x2, xzr                                    
02c9acb0: bl      #0x2e052d8                                 Firebase.Analytics.FirebaseAnalytics::LogEvent
02c9acb4: adrp    x8, #0x6265000                             
02c9acb8: ldr     x8, [x8, #0x2e8]                           T:type8944(k15)
02c9acbc: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9acc0: bl      #0x2b7104c                                 fn_2b7104c
02c9acc4: adrp    x8, #0x6265000                             
02c9acc8: mov     x21, x0                                    
02c9accc: ldr     x8, [x8, #0x2e0]                           MS:System.Collections.Generic.Dictionary`2::.ctor
02c9acd0: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9acd4: bl      #0x452b8a0                                 fn_452b8a0
02c9acd8: cbz     x21, #0x2c9ae48                            
02c9acdc: adrp    x22, #0x6265000                            
02c9ace0: ldr     x22, [x22, #0x2d8]                         MS:System.Collections.Generic.Dictionary`2::Add
02c9ace4: ldr     x1, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9ace8: ldr     x3, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9acec: mov     x0, x21                                    
02c9acf0: mov     x2, x19                                    
02c9acf4: bl      #0x452c61c                                 fn_452c61c
02c9acf8: ldr     x1, [x27]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9acfc: ldr     x3, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9ad00: mov     x0, x21                                    
02c9ad04: mov     x2, x20                                    
02c9ad08: bl      #0x452c61c                                 fn_452c61c
02c9ad0c: ldr     x0, [x29]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9ad10: mov     w8, #8                                     
02c9ad14: str     w8, [sp]                                   
02c9ad18: mov     x1, sp                                     
02c9ad1c: bl      #0x2b70f38                                 fn_2b70f38
02c9ad20: mov     x1, x0                                     
02c9ad24: ldr     x0, [x26]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c9ad28: mov     x2, xzr                                    
02c9ad2c: bl      #0x4c9d0ec                                 System.String::Format
02c9ad30: ldr     x1, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9ad34: ldr     x3, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9ad38: mov     x2, x0                                     
02c9ad3c: mov     x0, x21                                    
02c9ad40: bl      #0x452c61c                                 fn_452c61c
02c9ad44: adrp    x8, #0x6263000                             
02c9ad48: ldr     d0, [sp, #0x28]                            
02c9ad4c: ldr     x8, [x8, #0x970]                           &6645c70(=0)
02c9ad50: str     d0, [sp, #8]                               
02c9ad54: ldr     x0, [x8, #0x80]                            &2c498bc(=aa1f03e0d503245f)
02c9ad58: add     x1, sp, #8                                 
02c9ad5c: bl      #0x2b70f38                                 fn_2b70f38
02c9ad60: mov     x1, x0                                     
02c9ad64: ldr     x0, [x26]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c9ad68: mov     x2, xzr                                    
02c9ad6c: bl      #0x4c9d0ec                                 System.String::Format
02c9ad70: adrp    x8, #0x6265000                             
02c9ad74: ldr     x8, [x8, #0x2a0]                           S:'value'
02c9ad78: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9ad7c: ldr     x3, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9ad80: mov     x2, x0                                     
02c9ad84: mov     x0, x21                                    
02c9ad88: bl      #0x452c61c                                 fn_452c61c
02c9ad8c: ldr     x1, [x28]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9ad90: ldr     x2, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9ad94: ldr     x3, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9ad98: mov     x0, x21                                    
02c9ad9c: bl      #0x452c61c                                 fn_452c61c
02c9ada0: adrp    x8, #0x6265000                             
02c9ada4: ldr     x8, [x8, #0x2d0]                           T:AppsFlyerSDK.AFAdRevenueData
02c9ada8: ldr     d8, [sp, #0x28]                            
02c9adac: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9adb0: bl      #0x2b7104c                                 fn_2b7104c
02c9adb4: mov     x20, x0                                    
02c9adb8: ldr     x3, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9adbc: fmov    d0, d8                                     
02c9adc0: mov     x1, x19                                    
02c9adc4: mov     w2, #1                                     
02c9adc8: mov     x4, xzr                                    
02c9adcc: bl      #0x2c66b2c                                 AppsFlyerSDK.AFAdRevenueData::.ctor
02c9add0: adrp    x8, #0x6263000                             
02c9add4: ldr     x8, [x8, #0x900]                           T:AppsFlyerSDK.AppsFlyer
02c9add8: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c9addc: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c9ade0: cbnz    w8, #0x2c9ade8                             
02c9ade4: bl      #0x2b70f30                                 fn_2b70f30
02c9ade8: mov     x0, x20                                    
02c9adec: mov     x1, x21                                    
02c9adf0: mov     x2, xzr                                    
02c9adf4: bl      #0x2c67cf8                                 AppsFlyerSDK.AppsFlyer::logAdRevenue
02c9adf8: ldp     x20, x19, [sp, #0x80]                      
02c9adfc: ldr     d8, [sp, #0x20]                            
02c9ae00: ldp     x22, x21, [sp, #0x70]                      
02c9ae04: ldp     x24, x23, [sp, #0x60]                      
02c9ae08: ldp     x26, x25, [sp, #0x50]                      
02c9ae0c: ldp     x28, x27, [sp, #0x40]                      
02c9ae10: ldp     x29, x30, [sp, #0x30]                      
02c9ae14: add     sp, sp, #0x90                              
02c9ae18: ret                                                
02c9ae1c: bl      #0x2b71064                                 fn_2b71064
02c9ae20: bl      #0x2b71080                                 fn_2b71080
02c9ae24: mov     x1, xzr                                    
02c9ae28: bl      #0x2b70f20                                 fn_2b70f20
02c9ae2c: bl      #0x2b7105c                                 fn_2b7105c
02c9ae30: bl      #0x2b7105c                                 fn_2b7105c
02c9ae34: bl      #0x2b71064                                 fn_2b71064
02c9ae38: bl      #0x2b71064                                 fn_2b71064
02c9ae3c: bl      #0x2b71064                                 fn_2b71064
02c9ae40: bl      #0x2b71064                                 fn_2b71064
02c9ae44: bl      #0x2b71064                                 fn_2b71064
02c9ae48: bl      #0x2b7105c                                 fn_2b7105c
02c9ae4c: bl      #0x2b71080                                 fn_2b71080
02c9ae50: mov     x1, xzr                                    
02c9ae54: bl      #0x2b70f20                                 fn_2b70f20
02c9ae58: bl      #0x2b71080                                 fn_2b71080
02c9ae5c: mov     x1, xzr                                    
02c9ae60: bl      #0x2b70f20                                 fn_2b70f20
02c9ae64: bl      #0x2b71080                                 fn_2b71080
02c9ae68: mov     x1, xzr                                    
02c9ae6c: bl      #0x2b70f20                                 fn_2b70f20
02c9ae70: bl      #0x2b71080                                 fn_2b71080
02c9ae74: mov     x1, xzr                                    
02c9ae78: bl      #0x2b70f20                                 fn_2b70f20
02c9ae7c: bl      #0x2b71080                                 fn_2b71080
02c9ae80: mov     x1, xzr                                    
02c9ae84: bl      #0x2b70f20                                 fn_2b70f20
02c9ae88: b       #0x2c9aed8                                 
02c9ae8c: b       #0x2c9aed8                                 
02c9ae90: b       #0x2c9aed8                                 
02c9ae94: b       #0x2c9aed8                                 
02c9ae98: b       #0x2c9aed8                                 
02c9ae9c: b       #0x2c9aed8                                 
02c9aea0: b       #0x2c9aed8                                 
02c9aea4: b       #0x2c9aed8                                 
02c9aea8: b       #0x2c9aed8                                 
02c9aeac: b       #0x2c9aed8                                 
02c9aeb0: b       #0x2c9aed8                                 
02c9aeb4: b       #0x2c9aed8                                 
02c9aeb8: b       #0x2c9aed8                                 
02c9aebc: b       #0x2c9aed8                                 
02c9aec0: b       #0x2c9aed8                                 
02c9aec4: b       #0x2c9aed8                                 
02c9aec8: b       #0x2c9aed8                                 
02c9aecc: b       #0x2c9aed8                                 
02c9aed0: b       #0x2c9aed8                                 
02c9aed4: b       #0x2c9aed8                                 
02c9aed8: mov     x19, x0                                    
02c9aedc: cmp     w1, #1                                     
02c9aee0: b.ne    #0x2c9af58                                 
02c9aee4: mov     x0, x19                                    
02c9aee8: bl      #0x5e90260                                 fn_5e90260
02c9aeec: mov     x19, x0                                    
02c9aef0: adrp    x0, #0x6263000                             
02c9aef4: ldr     x0, [x0, #0xae0]                           T:System.Exception
02c9aef8: bl      #0x2b70dc4                                 fn_2b70dc4
02c9aefc: ldr     x8, [x19]                                  
02c9af00: ldr     x1, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c9af04: bl      #0x2b71464                                 fn_2b71464
02c9af08: tbz     w0, #0, #0x2c9af30                         
02c9af0c: ldrsw   x20, [sp, #0x18]                           
02c9af10: ldr     x8, [x19]                                  
02c9af14: add     x9, sp, #0x10                              
02c9af18: str     x8, [x9, x20, lsl #3]                      
02c9af1c: add     w8, w20, #1                                
02c9af20: str     w8, [sp, #0x18]                            
02c9af24: bl      #0x5e90270                                 fn_5e90270
02c9af28: str     w20, [sp, #0x18]                           
02c9af2c: b       #0x2c9adf8                                 
02c9af30: mov     w0, #8                                     
02c9af34: bl      #0x5e90290                                 fn_5e90290
02c9af38: ldr     x8, [x19]                                  
02c9af3c: str     x8, [x0]                                   
02c9af40: adrp    x1, #0x5e96000                             
02c9af44: add     x1, x1, #0x758                             &5e96758
02c9af48: mov     x2, xzr                                    
02c9af4c: bl      #0x5e902a0                                 fn_5e902a0
02c9af50: mov     x19, x0                                    
02c9af54: bl      #0x5e90270                                 fn_5e90270
02c9af58: mov     x0, x19                                    
02c9af5c: bl      #0x2c6051c                                 fn_2c6051c
02c9af60: bl      #0x27369b8                                 fn_27369b8
