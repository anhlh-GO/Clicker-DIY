#### CLASS DataClicker/<>c__DisplayClass13_0 parent= object
#   field index                          int                                                off=0x10 attr=6 
## .ctor() -> void
---- DataClicker/<>c__DisplayClass13_0::.ctor 0x2ca9978
02ca9978: mov     x1, xzr                                    
02ca997c: b       #0x4e53e9c                                 System.Object::.ctor
## <RemoveSavedKeycap>b__0(ClickerSaveDataItem k) -> bool
---- DataClicker/<>c__DisplayClass13_0::<RemoveSavedKeycap>b__0 0x2ca99f0
02ca99f0: cbz     x1, #0x2ca9a08                             
02ca99f4: ldr     w8, [x1, #0x10]                            
02ca99f8: ldr     w9, [x0, #0x10]                            .index
02ca99fc: cmp     w8, w9                                     
02ca9a00: cset    w0, eq                                     
02ca9a04: ret                                                
02ca9a08: str     x30, [sp, #-0x10]!                         
02ca9a0c: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS DataClicker/<>c__DisplayClass8_0 parent= object
#   field index                          int                                                off=0x10 attr=6 
## .ctor() -> void
---- DataClicker/<>c__DisplayClass8_0::.ctor 0x2ca9118
02ca9118: mov     x1, xzr                                    
02ca911c: b       #0x4e53e9c                                 System.Object::.ctor
## <GetKeycap>b__0(ClickerSaveDataItem k) -> bool
---- DataClicker/<>c__DisplayClass8_0::<GetKeycap>b__0 0x2ca9a10
02ca9a10: cbz     x1, #0x2ca9a28                             
02ca9a14: ldr     w8, [x1, #0x10]                            
02ca9a18: ldr     w9, [x0, #0x10]                            .index
02ca9a1c: cmp     w8, w9                                     
02ca9a20: cset    w0, eq                                     
02ca9a24: ret                                                
02ca9a28: str     x30, [sp, #-0x10]!                         
02ca9a2c: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS DataClicker parent= GameData
#   field _dataSave                      ClickerSaveData                                    off=0x20 attr=1 SerializeField
## get_DataSave() -> ClickerSaveData
---- DataClicker::get_DataSave 0x2ca8c64
02ca8c64: ldr     x0, [x0, #0x20]                            ._dataSave
02ca8c68: ret                                                
## set_DataSave(ClickerSaveData value) -> void
---- DataClicker::set_DataSave 0x2ca8c6c
02ca8c6c: str     x1, [x0, #0x20]!                           ._dataSave
02ca8c70: b       #0x2b70d54                                 
## SaveData() -> void
---- DataClicker::SaveData 0x2ca8c74
02ca8c74: stp     x30, x21, [sp, #-0x20]!                    
02ca8c78: stp     x20, x19, [sp, #0x10]                      
02ca8c7c: adrp    x20, #0x662f000                            
02ca8c80: adrp    x21, #0x6266000                            
02ca8c84: mov     x19, x0                                    
02ca8c88: ldrb    w8, [x20, #0xb03]                          
02ca8c8c: ldr     x21, [x21, #0x658]                         MS:MonoSingleton`1::get_Instance
02ca8c90: tbnz    w8, #0, #0x2ca8cb4                         
02ca8c94: adrp    x0, #0x6266000                             
02ca8c98: ldr     x0, [x0, #0x660]                           MS:DataManager::SaveData
02ca8c9c: bl      #0x2b70db0                                 fn_2b70db0
02ca8ca0: adrp    x0, #0x6266000                             
02ca8ca4: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02ca8ca8: bl      #0x2b70db0                                 fn_2b70db0
02ca8cac: mov     w8, #1                                     
02ca8cb0: strb    w8, [x20, #0xb03]                          
02ca8cb4: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca8cb8: bl      #0x3769600                                 fn_3769600
02ca8cbc: mov     x20, x0                                    
02ca8cc0: mov     x0, x19                                    
02ca8cc4: mov     x1, xzr                                    
02ca8cc8: bl      #0x4e54610                                 System.Object::GetType
02ca8ccc: cbz     x0, #0x2ca8d08                             
02ca8cd0: ldr     x8, [x0]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca8cd4: ldr     x9, [x8, #0x2f8]                           
02ca8cd8: ldr     x1, [x8, #0x300]                           
02ca8cdc: blr     x9                                         
02ca8ce0: cbz     x20, #0x2ca8d08                            
02ca8ce4: adrp    x8, #0x6266000                             
02ca8ce8: mov     x1, x0                                     
02ca8cec: mov     x0, x20                                    
02ca8cf0: ldr     x8, [x8, #0x660]                           MS:DataManager::SaveData
02ca8cf4: ldr     x2, [x19, #0x20]                           ._dataSave
02ca8cf8: ldp     x20, x19, [sp, #0x10]                      
02ca8cfc: ldr     x3, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca8d00: ldp     x30, x21, [sp], #0x20                      
02ca8d04: b       #0x3169790                                 
02ca8d08: bl      #0x2b7105c                                 fn_2b7105c
## LoadData() -> void
---- DataClicker::LoadData 0x2ca8d0c
02ca8d0c: str     x30, [sp, #-0x30]!                         
02ca8d10: stp     x22, x21, [sp, #0x10]                      
02ca8d14: stp     x20, x19, [sp, #0x20]                      
02ca8d18: adrp    x20, #0x662f000                            
02ca8d1c: adrp    x21, #0x6266000                            
02ca8d20: mov     x19, x0                                    
02ca8d24: ldrb    w8, [x20, #0xb04]                          
02ca8d28: ldr     x21, [x21, #0x658]                         MS:MonoSingleton`1::get_Instance
02ca8d2c: tbnz    w8, #0, #0x2ca8d74                         
02ca8d30: adrp    x0, #0x6266000                             
02ca8d34: ldr     x0, [x0, #0x668]                           MS:DataManager::LoadData
02ca8d38: bl      #0x2b70db0                                 fn_2b70db0
02ca8d3c: adrp    x0, #0x6266000                             
02ca8d40: ldr     x0, [x0, #0x5e0]                           T:GameConfig
02ca8d44: bl      #0x2b70db0                                 fn_2b70db0
02ca8d48: adrp    x0, #0x6266000                             
02ca8d4c: ldr     x0, [x0, #0x638]                           MS:System.Collections.Generic.List`1::.ctor
02ca8d50: bl      #0x2b70db0                                 fn_2b70db0
02ca8d54: adrp    x0, #0x6266000                             
02ca8d58: ldr     x0, [x0, #0x640]                           T:type14866(k15)
02ca8d5c: bl      #0x2b70db0                                 fn_2b70db0
02ca8d60: adrp    x0, #0x6266000                             
02ca8d64: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02ca8d68: bl      #0x2b70db0                                 fn_2b70db0
02ca8d6c: mov     w8, #1                                     
02ca8d70: strb    w8, [x20, #0xb04]                          
02ca8d74: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca8d78: bl      #0x3769600                                 fn_3769600
02ca8d7c: mov     x20, x0                                    
02ca8d80: mov     x0, x19                                    
02ca8d84: mov     x1, xzr                                    
02ca8d88: bl      #0x4e54610                                 System.Object::GetType
02ca8d8c: cbz     x0, #0x2ca8ed4                             
02ca8d90: ldr     x8, [x0]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca8d94: ldr     x9, [x8, #0x2f8]                           
02ca8d98: ldr     x1, [x8, #0x300]                           
02ca8d9c: blr     x9                                         
02ca8da0: cbz     x20, #0x2ca8ed4                            
02ca8da4: adrp    x8, #0x6266000                             
02ca8da8: mov     x1, x0                                     
02ca8dac: mov     x0, x20                                    
02ca8db0: ldr     x8, [x8, #0x668]                           MS:DataManager::LoadData
02ca8db4: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca8db8: bl      #0x31690b0                                 fn_31690b0
02ca8dbc: mov     x20, x19                                   
02ca8dc0: mov     x1, x0                                     
02ca8dc4: str     x0, [x20, #0x20]!                          ._dataSave
02ca8dc8: mov     x0, x20                                    
02ca8dcc: bl      #0x2b70d54                                 fn_2b70d54
02ca8dd0: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02ca8dd4: cbnz    x8, #0x2ca8df4                             
02ca8dd8: ldr     x8, [x19]                                  
02ca8ddc: mov     x0, x19                                    
02ca8de0: ldr     x9, [x8, #0x228]                           T:type15233(k15)
02ca8de4: ldr     x1, [x8, #0x230]                           T:UnityEngine.Purchasing.ProductDefinition
02ca8de8: blr     x9                                         
02ca8dec: ldr     x8, [x19, #0x20]                           ._dataSave
02ca8df0: cbz     x8, #0x2ca8ed4                             
02ca8df4: mov     x21, x8                                    
02ca8df8: ldr     x9, [x21, #0x18]!                          S:'level_show_popuprate'
02ca8dfc: cbnz    x9, #0x2ca8e50                             
02ca8e00: adrp    x8, #0x6266000                             
02ca8e04: ldr     x8, [x8, #0x640]                           T:type14866(k15)
02ca8e08: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca8e0c: bl      #0x2b7104c                                 fn_2b7104c
02ca8e10: adrp    x8, #0x6266000                             
02ca8e14: mov     x22, x0                                    
02ca8e18: ldr     x8, [x8, #0x638]                           MS:System.Collections.Generic.List`1::.ctor
02ca8e1c: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca8e20: bl      #0x35a89a4                                 fn_35a89a4
02ca8e24: mov     x0, x21                                    
02ca8e28: mov     x1, x22                                    
02ca8e2c: str     x22, [x21]                                 
02ca8e30: bl      #0x2b70d54                                 fn_2b70d54
02ca8e34: ldr     x8, [x19]                                  
02ca8e38: mov     x0, x19                                    
02ca8e3c: ldr     x9, [x8, #0x258]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02ca8e40: ldr     x1, [x8, #0x260]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02ca8e44: blr     x9                                         
02ca8e48: ldr     x8, [x19, #0x20]                           ._dataSave
02ca8e4c: cbz     x8, #0x2ca8ed4                             
02ca8e50: adrp    x21, #0x6266000                            
02ca8e54: ldr     x21, [x21, #0x5e0]                         T:GameConfig
02ca8e58: ldr     w22, [x8, #0x10]                           S:'mrec_ad_on_off'
02ca8e5c: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca8e60: ldr     w9, [x0, #0xe4]                            [62660e4]=0 f=0,0
02ca8e64: cbnz    w9, #0x2ca8e70                             
02ca8e68: bl      #0x2b70f30                                 fn_2b70f30
02ca8e6c: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca8e70: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time'
02ca8e74: ldr     w8, [x8, #0xbc]                            [62660bc]=0 f=0,0
02ca8e78: cmp     w22, w8                                    
02ca8e7c: b.ge    #0x2ca8ec4                                 
02ca8e80: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02ca8e84: ldr     x20, [x20]                                 &2b706c4(=eb01011ff9400808)
02ca8e88: cbnz    w8, #0x2ca8e90                             
02ca8e8c: bl      #0x2b70f30                                 fn_2b70f30
02ca8e90: cbz     x20, #0x2ca8ed4                            
02ca8e94: ldr     x8, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca8e98: mov     x0, x19                                    
02ca8e9c: ldp     x22, x21, [sp, #0x10]                      
02ca8ea0: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02ca8ea4: ldr     w8, [x8, #0xbc]                            [62660bc]=0 f=0,0
02ca8ea8: str     w8, [x20, #0x10]                           
02ca8eac: ldr     x8, [x19]                                  
02ca8eb0: ldp     x20, x19, [sp, #0x20]                      
02ca8eb4: ldr     x1, [x8, #0x260]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02ca8eb8: ldr     x2, [x8, #0x258]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02ca8ebc: ldr     x30, [sp], #0x30                           
02ca8ec0: br      x2                                         
02ca8ec4: ldp     x20, x19, [sp, #0x20]                      
02ca8ec8: ldp     x22, x21, [sp, #0x10]                      
02ca8ecc: ldr     x30, [sp], #0x30                           
02ca8ed0: ret                                                
02ca8ed4: bl      #0x2b7105c                                 fn_2b7105c
## NewData() -> void
---- DataClicker::NewData 0x2ca8ed8
02ca8ed8: stp     x30, x21, [sp, #-0x20]!                    
02ca8edc: stp     x20, x19, [sp, #0x10]                      
02ca8ee0: adrp    x20, #0x662f000                            
02ca8ee4: adrp    x21, #0x6266000                            
02ca8ee8: mov     x19, x0                                    
02ca8eec: ldrb    w8, [x20, #0xb05]                          
02ca8ef0: ldr     x21, [x21, #0x670]                         T:ClickerSaveData
02ca8ef4: tbnz    w8, #0, #0x2ca8f0c                         
02ca8ef8: adrp    x0, #0x6266000                             
02ca8efc: ldr     x0, [x0, #0x670]                           T:ClickerSaveData
02ca8f00: bl      #0x2b70db0                                 fn_2b70db0
02ca8f04: mov     w8, #1                                     
02ca8f08: strb    w8, [x20, #0xb05]                          
02ca8f0c: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca8f10: bl      #0x2b7104c                                 fn_2b7104c
02ca8f14: mov     x20, x0                                    
02ca8f18: bl      #0x2ca8aa4                                 ClickerSaveData::.ctor
02ca8f1c: mov     x0, x19                                    
02ca8f20: mov     x1, x20                                    
02ca8f24: str     x20, [x0, #0x20]!                          ._dataSave
02ca8f28: bl      #0x2b70d54                                 fn_2b70d54
02ca8f2c: ldr     x8, [x19]                                  
02ca8f30: mov     x0, x19                                    
02ca8f34: ldp     x20, x19, [sp, #0x10]                      
02ca8f38: ldr     x1, [x8, #0x260]                           
02ca8f3c: ldr     x2, [x8, #0x258]                           
02ca8f40: ldp     x30, x21, [sp], #0x20                      
02ca8f44: br      x2                                         
## RegisterNewKeycap(ClickerSaveDataItem newKeycap) -> void
---- DataClicker::RegisterNewKeycap 0x2ca8f48
02ca8f48: stp     x30, x21, [sp, #-0x20]!                    
02ca8f4c: stp     x20, x19, [sp, #0x10]                      
02ca8f50: adrp    x21, #0x662f000                            
02ca8f54: mov     x20, x1                                    
02ca8f58: mov     x19, x0                                    
02ca8f5c: ldrb    w8, [x21, #0xb06]                          
02ca8f60: tbnz    w8, #0, #0x2ca8f78                         
02ca8f64: adrp    x0, #0x6266000                             
02ca8f68: ldr     x0, [x0, #0x678]                           MS:System.Collections.Generic.List`1::Add
02ca8f6c: bl      #0x2b70db0                                 fn_2b70db0
02ca8f70: mov     w8, #1                                     
02ca8f74: strb    w8, [x21, #0xb06]                          
02ca8f78: ldr     x8, [x19, #0x20]                           ._dataSave
02ca8f7c: cbz     x8, #0x2ca9034                             
02ca8f80: ldr     w9, [x8, #0x14]                            
02ca8f84: add     w9, w9, #1                                 
02ca8f88: str     w9, [x8, #0x14]                            
02ca8f8c: cbz     x20, #0x2ca9034                            
02ca8f90: mov     x0, x20                                    
02ca8f94: mov     x1, xzr                                    
02ca8f98: mov     x2, xzr                                    
02ca8f9c: str     w9, [x20, #0x10]                           
02ca8fa0: bl      #0x2d03418                                 Trading.ClickerValuation::EnsureSnapshot
02ca8fa4: ldr     x8, [x19, #0x20]                           ._dataSave
02ca8fa8: cbz     x8, #0x2ca9034                             
02ca8fac: ldr     x0, [x8, #0x18]                            
02ca8fb0: cbz     x0, #0x2ca9034                             
02ca8fb4: adrp    x9, #0x6266000                             
02ca8fb8: ldr     x9, [x9, #0x678]                           MS:System.Collections.Generic.List`1::Add
02ca8fbc: ldr     w10, [x0, #0x1c]                           [626601c]=0 f=0,0
02ca8fc0: ldr     x8, [x0, #0x10]                            S:'mrec_ad_on_off'
02ca8fc4: ldr     x9, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca8fc8: add     w10, w10, #1                               
02ca8fcc: str     w10, [x0, #0x1c]                           
02ca8fd0: cbz     x8, #0x2ca9034                             
02ca8fd4: ldrsw   x10, [x0, #0x18]                           
02ca8fd8: ldr     w11, [x8, #0x18]                           
02ca8fdc: cmp     w10, w11                                   
02ca8fe0: b.hs    #0x2ca9004                                 
02ca8fe4: add     x8, x8, x10, lsl #3                        
02ca8fe8: add     w9, w10, #1                                
02ca8fec: mov     x1, x20                                    
02ca8ff0: str     w9, [x0, #0x18]                            
02ca8ff4: str     x20, [x8, #0x20]!                          
02ca8ff8: mov     x0, x8                                     
02ca8ffc: bl      #0x2b70d54                                 fn_2b70d54
02ca9000: b       #0x2ca9018                                 
02ca9004: ldr     x8, [x9, #0x20]                            S:'inter_ad_capping_time'
02ca9008: mov     x1, x20                                    
02ca900c: ldr     x8, [x8, #0xc0]                            
02ca9010: ldr     x2, [x8, #0x70]                            
02ca9014: bl      #0x35a920c                                 fn_35a920c
02ca9018: ldr     x8, [x19]                                  
02ca901c: mov     x0, x19                                    
02ca9020: ldp     x20, x19, [sp, #0x10]                      
02ca9024: ldr     x1, [x8, #0x260]                           
02ca9028: ldr     x2, [x8, #0x258]                           
02ca902c: ldp     x30, x21, [sp], #0x20                      
02ca9030: br      x2                                         
02ca9034: bl      #0x2b7105c                                 fn_2b7105c
## GetKeycap(int index) -> ClickerSaveDataItem
---- DataClicker::GetKeycap 0x2ca9038
02ca9038: str     x30, [sp, #-0x30]!                         
02ca903c: stp     x22, x21, [sp, #0x10]                      
02ca9040: stp     x20, x19, [sp, #0x20]                      
02ca9044: adrp    x21, #0x662f000                            
02ca9048: adrp    x22, #0x6266000                            
02ca904c: mov     w19, w1                                    
02ca9050: ldrb    w8, [x21, #0xb07]                          
02ca9054: ldr     x22, [x22, #0x680]                         T:DataClicker/<>c__DisplayClass8_0
02ca9058: mov     x20, x0                                    
02ca905c: tbnz    w8, #0, #0x2ca9098                         
02ca9060: adrp    x0, #0x6266000                             
02ca9064: ldr     x0, [x0, #0x688]                           MS:System.Collections.Generic.List`1::Find
02ca9068: bl      #0x2b70db0                                 fn_2b70db0
02ca906c: adrp    x0, #0x6266000                             
02ca9070: ldr     x0, [x0, #0x690]                           T:type57233(k15)
02ca9074: bl      #0x2b70db0                                 fn_2b70db0
02ca9078: adrp    x0, #0x6266000                             
02ca907c: ldr     x0, [x0, #0x698]                           M:DataClicker/<>c__DisplayClass8_0::<GetKeycap>b__0
02ca9080: bl      #0x2b70db0                                 fn_2b70db0
02ca9084: adrp    x0, #0x6266000                             
02ca9088: ldr     x0, [x0, #0x680]                           T:DataClicker/<>c__DisplayClass8_0
02ca908c: bl      #0x2b70db0                                 fn_2b70db0
02ca9090: mov     w8, #1                                     
02ca9094: strb    w8, [x21, #0xb07]                          
02ca9098: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca909c: bl      #0x2b7104c                                 fn_2b7104c
02ca90a0: mov     x1, xzr                                    
02ca90a4: mov     x21, x0                                    
02ca90a8: bl      #0x4e53e9c                                 System.Object::.ctor
02ca90ac: cbz     x21, #0x2ca9114                            
02ca90b0: ldr     x8, [x20, #0x20]                           ._dataSave
02ca90b4: str     w19, [x21, #0x10]                          
02ca90b8: cbz     x8, #0x2ca9114                             
02ca90bc: adrp    x9, #0x6266000                             
02ca90c0: adrp    x20, #0x6266000                            
02ca90c4: ldr     x9, [x9, #0x690]                           T:type57233(k15)
02ca90c8: ldr     x20, [x20, #0x698]                         M:DataClicker/<>c__DisplayClass8_0::<GetKeycap>b__0
02ca90cc: ldr     x19, [x8, #0x18]                           
02ca90d0: ldr     x0, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca90d4: bl      #0x2b7104c                                 fn_2b7104c
02ca90d8: ldr     x2, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca90dc: mov     x1, x21                                    
02ca90e0: mov     x3, xzr                                    
02ca90e4: mov     x20, x0                                    
02ca90e8: bl      #0x399ba10                                 fn_399ba10
02ca90ec: cbz     x19, #0x2ca9114                            
02ca90f0: adrp    x8, #0x6266000                             
02ca90f4: mov     x0, x19                                    
02ca90f8: mov     x1, x20                                    
02ca90fc: ldr     x8, [x8, #0x688]                           MS:System.Collections.Generic.List`1::Find
02ca9100: ldp     x20, x19, [sp, #0x20]                      
02ca9104: ldp     x22, x21, [sp, #0x10]                      
02ca9108: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca910c: ldr     x30, [sp], #0x30                           
02ca9110: b       #0x35a9868                                 
02ca9114: bl      #0x2b7105c                                 fn_2b7105c
## get_FreeSlotCount() -> int
---- DataClicker::get_FreeSlotCount 0x2ca9120
02ca9120: str     x30, [sp, #-0x20]!                         
02ca9124: stp     x20, x19, [sp, #0x10]                      
02ca9128: adrp    x20, #0x662f000                            
02ca912c: mov     x19, x0                                    
02ca9130: ldrb    w8, [x20, #0xb08]                          
02ca9134: tbnz    w8, #0, #0x2ca914c                         
02ca9138: adrp    x0, #0x6266000                             
02ca913c: ldr     x0, [x0, #0x6a0]                           MS:System.Collections.Generic.List`1::get_Count
02ca9140: bl      #0x2b70db0                                 fn_2b70db0
02ca9144: mov     w8, #1                                     
02ca9148: strb    w8, [x20, #0xb08]                          
02ca914c: ldr     x8, [x19, #0x20]                           ._dataSave
02ca9150: cbz     x8, #0x2ca9178                             
02ca9154: ldr     x9, [x8, #0x18]                            
02ca9158: cbz     x9, #0x2ca9178                             
02ca915c: ldr     w8, [x8, #0x10]                            
02ca9160: ldr     w9, [x9, #0x18]                            
02ca9164: ldp     x20, x19, [sp, #0x10]                      
02ca9168: sub     w8, w8, w9                                 
02ca916c: bic     w0, w8, w8, asr #31                        
02ca9170: ldr     x30, [sp], #0x20                           
02ca9174: ret                                                
02ca9178: bl      #0x2b7105c                                 fn_2b7105c
## TryCommitTrade(System.Collections.Generic.List`1<int> removeIndexes, System.Collections.Generic.List`1<ClickerSaveDataItem> addItems, System.Collections.Generic.List`1<ClickerSaveDataItem> addedItems) -> bool
---- DataClicker::TryCommitTrade 0x2ca917c
02ca917c: sub     sp, sp, #0xd0                              
02ca9180: stp     x29, x30, [sp, #0x70]                      
02ca9184: stp     x28, x27, [sp, #0x80]                      
02ca9188: stp     x26, x25, [sp, #0x90]                      
02ca918c: stp     x24, x23, [sp, #0xa0]                      
02ca9190: stp     x22, x21, [sp, #0xb0]                      
02ca9194: stp     x20, x19, [sp, #0xc0]                      
02ca9198: adrp    x22, #0x662f000                            
02ca919c: adrp    x25, #0x6266000                            
02ca91a0: adrp    x24, #0x6266000                            
02ca91a4: ldrb    w8, [x22, #0xb09]                          
02ca91a8: ldr     x25, [x25, #0x640]                         T:type14866(k15)
02ca91ac: ldr     x24, [x24, #0x638]                         MS:System.Collections.Generic.List`1::.ctor
02ca91b0: mov     x20, x3                                    
02ca91b4: mov     x21, x2                                    
02ca91b8: mov     x23, x1                                    
02ca91bc: mov     x19, x0                                    
02ca91c0: tbnz    w8, #0, #0x2ca92bc                         
02ca91c4: adrp    x0, #0x6266000                             
02ca91c8: ldr     x0, [x0, #0x6a8]                           T:type6847(k15)
02ca91cc: bl      #0x2b70db0                                 fn_2b70db0
02ca91d0: adrp    x0, #0x6266000                             
02ca91d4: ldr     x0, [x0, #0x6b0]                           T:ClickerSaveDataItem
02ca91d8: bl      #0x2b70db0                                 fn_2b70db0
02ca91dc: adrp    x0, #0x6266000                             
02ca91e0: ldr     x0, [x0, #0x6b8]                           M:DataClicker::<TryCommitTrade>b__11_0
02ca91e4: bl      #0x2b70db0                                 fn_2b70db0
02ca91e8: adrp    x0, #0x6266000                             
02ca91ec: ldr     x0, [x0, #0x6c0]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02ca91f0: bl      #0x2b70db0                                 fn_2b70db0
02ca91f4: adrp    x0, #0x6266000                             
02ca91f8: ldr     x0, [x0, #0x6c8]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02ca91fc: bl      #0x2b70db0                                 fn_2b70db0
02ca9200: adrp    x0, #0x6266000                             
02ca9204: ldr     x0, [x0, #0x6d0]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02ca9208: bl      #0x2b70db0                                 fn_2b70db0
02ca920c: adrp    x0, #0x6266000                             
02ca9210: ldr     x0, [x0, #0x6d8]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02ca9214: bl      #0x2b70db0                                 fn_2b70db0
02ca9218: adrp    x0, #0x6266000                             
02ca921c: ldr     x0, [x0, #0x6e0]                           MS:System.Collections.Generic.List`1/Enumerator::get_Current
02ca9220: bl      #0x2b70db0                                 fn_2b70db0
02ca9224: adrp    x0, #0x6266000                             
02ca9228: ldr     x0, [x0, #0x6e8]                           MS:System.Collections.Generic.List`1/Enumerator::get_Current
02ca922c: bl      #0x2b70db0                                 fn_2b70db0
02ca9230: adrp    x0, #0x6266000                             
02ca9234: ldr     x0, [x0, #0x678]                           MS:System.Collections.Generic.List`1::Add
02ca9238: bl      #0x2b70db0                                 fn_2b70db0
02ca923c: adrp    x0, #0x6266000                             
02ca9240: ldr     x0, [x0, #0x6f0]                           MS:System.Collections.Generic.List`1::Contains
02ca9244: bl      #0x2b70db0                                 fn_2b70db0
02ca9248: adrp    x0, #0x6266000                             
02ca924c: ldr     x0, [x0, #0x6f8]                           MS:System.Collections.Generic.List`1::ForEach
02ca9250: bl      #0x2b70db0                                 fn_2b70db0
02ca9254: adrp    x0, #0x6266000                             
02ca9258: ldr     x0, [x0, #0x700]                           MS:System.Collections.Generic.List`1::GetEnumerator
02ca925c: bl      #0x2b70db0                                 fn_2b70db0
02ca9260: adrp    x0, #0x6266000                             
02ca9264: ldr     x0, [x0, #0x708]                           MS:System.Collections.Generic.List`1::GetEnumerator
02ca9268: bl      #0x2b70db0                                 fn_2b70db0
02ca926c: adrp    x0, #0x6266000                             
02ca9270: ldr     x0, [x0, #0x650]                           MS:System.Collections.Generic.List`1::.ctor
02ca9274: bl      #0x2b70db0                                 fn_2b70db0
02ca9278: adrp    x0, #0x6266000                             
02ca927c: ldr     x0, [x0, #0x710]                           MS:System.Collections.Generic.List`1::.ctor
02ca9280: bl      #0x2b70db0                                 fn_2b70db0
02ca9284: adrp    x0, #0x6266000                             
02ca9288: ldr     x0, [x0, #0x638]                           MS:System.Collections.Generic.List`1::.ctor
02ca928c: bl      #0x2b70db0                                 fn_2b70db0
02ca9290: adrp    x0, #0x6266000                             
02ca9294: ldr     x0, [x0, #0x6a0]                           MS:System.Collections.Generic.List`1::get_Count
02ca9298: bl      #0x2b70db0                                 fn_2b70db0
02ca929c: adrp    x0, #0x6266000                             
02ca92a0: ldr     x0, [x0, #0x648]                           T:type15061(k15)
02ca92a4: bl      #0x2b70db0                                 fn_2b70db0
02ca92a8: adrp    x0, #0x6266000                             
02ca92ac: ldr     x0, [x0, #0x640]                           T:type14866(k15)
02ca92b0: bl      #0x2b70db0                                 fn_2b70db0
02ca92b4: mov     w8, #1                                     
02ca92b8: strb    w8, [x22, #0xb09]                          
02ca92bc: ldr     x0, [x25]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca92c0: stp     xzr, xzr, [sp, #0x50]                      
02ca92c4: str     xzr, [sp, #0x60]                           
02ca92c8: stp     xzr, xzr, [sp, #0x30]                      
02ca92cc: str     xzr, [sp, #0x40]                           
02ca92d0: bl      #0x2b7104c                                 fn_2b7104c
02ca92d4: ldr     x1, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca92d8: mov     x22, x0                                    
02ca92dc: bl      #0x35a89a4                                 fn_35a89a4
02ca92e0: mov     x0, x20                                    
02ca92e4: mov     x1, x22                                    
02ca92e8: str     x22, [x20]                                 
02ca92ec: bl      #0x2b70d54                                 fn_2b70d54
02ca92f0: cbz     x23, #0x2ca940c                            
02ca92f4: cbz     x21, #0x2ca9434                            
02ca92f8: ldr     x0, [x25]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca92fc: bl      #0x2b7104c                                 fn_2b7104c
02ca9300: ldr     x1, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca9304: mov     x22, x0                                    
02ca9308: bl      #0x35a89a4                                 fn_35a89a4
02ca930c: cbz     x23, #0x2ca9718                            
02ca9310: adrp    x8, #0x6266000                             
02ca9314: adrp    x26, #0x6266000                            
02ca9318: adrp    x27, #0x6266000                            
02ca931c: ldr     x8, [x8, #0x708]                           MS:System.Collections.Generic.List`1::GetEnumerator
02ca9320: adrp    x24, #0x6266000                            
02ca9324: adrp    x25, #0x6266000                            
02ca9328: ldr     x26, [x26, #0x6d0]                         MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02ca932c: ldr     x27, [x27, #0x6f0]                         MS:System.Collections.Generic.List`1::Contains
02ca9330: ldr     x24, [x24, #0x678]                         MS:System.Collections.Generic.List`1::Add
02ca9334: ldr     x25, [x25, #0x6c0]                         MS:System.Collections.Generic.List`1/Enumerator::Dispose
02ca9338: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca933c: add     x8, sp, #0x18                              
02ca9340: mov     x0, x23                                    
02ca9344: bl      #0x356a780                                 fn_356a780
02ca9348: ldr     x8, [sp, #0x28]                            
02ca934c: ldur    q0, [sp, #0x18]                            
02ca9350: str     x8, [sp, #0x60]                            
02ca9354: add     x8, sp, #0x50                              
02ca9358: str     q0, [sp, #0x50]                            
02ca935c: stp     xzr, x8, [sp, #0x18]                       
02ca9360: ldr     x1, [x26]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca9364: add     x0, sp, #0x50                              
02ca9368: bl      #0x4685af8                                 fn_4685af8
02ca936c: tbz     w0, #0, #0x2ca944c                         
02ca9370: ldr     w1, [sp, #0x60]                            
02ca9374: mov     x0, x19                                    
02ca9378: bl      #0x2ca9038                                 DataClicker::GetKeycap
02ca937c: mov     x23, x0                                    
02ca9380: cbz     x0, #0x2ca93fc                             
02ca9384: cbz     x22, #0x2ca9704                            
02ca9388: ldr     x2, [x27]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca938c: mov     x0, x22                                    
02ca9390: mov     x1, x23                                    
02ca9394: bl      #0x35a95a8                                 fn_35a95a8
02ca9398: tbnz    w0, #0, #0x2ca93fc                         
02ca939c: ldr     w10, [x22, #0x1c]                          [662f01c]=0 f=0,0
02ca93a0: ldr     x8, [x22, #0x10]                           &2b706e8(=14cc74f191004000)
02ca93a4: ldr     x9, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca93a8: add     w10, w10, #1                               
02ca93ac: str     w10, [x22, #0x1c]                          
02ca93b0: cbz     x8, #0x2ca9708                             
02ca93b4: ldrsw   x10, [x22, #0x18]                          
02ca93b8: ldr     w11, [x8, #0x18]                           S:'level_show_popuprate'
02ca93bc: cmp     w10, w11                                   
02ca93c0: b.hs    #0x2ca93e0                                 
02ca93c4: add     x0, x8, x10, lsl #3                        &6266000
02ca93c8: add     w9, w10, #1                                
02ca93cc: str     w9, [x22, #0x18]                           
02ca93d0: str     x23, [x0, #0x20]!                          ._dataSave
02ca93d4: mov     x1, x23                                    
02ca93d8: bl      #0x2b70d54                                 fn_2b70d54
02ca93dc: b       #0x2ca9360                                 
02ca93e0: ldr     x8, [x9, #0x20]                            
02ca93e4: ldr     x8, [x8, #0xc0]                            T:Firebase.RemoteConfig.ConfigValue
02ca93e8: ldr     x2, [x8, #0x70]                            S:'open_ad_id'
02ca93ec: mov     x0, x22                                    
02ca93f0: mov     x1, x23                                    
02ca93f4: bl      #0x35a920c                                 fn_35a920c
02ca93f8: b       #0x2ca9360                                 
02ca93fc: ldr     x1, [x25]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca9400: add     x0, sp, #0x50                              
02ca9404: bl      #0x4685af4                                 fn_4685af4
02ca9408: b       #0x2ca9490                                 
02ca940c: adrp    x8, #0x6266000                             
02ca9410: ldr     x8, [x8, #0x648]                           T:type15061(k15)
02ca9414: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca9418: bl      #0x2b7104c                                 fn_2b7104c
02ca941c: adrp    x8, #0x6266000                             
02ca9420: mov     x23, x0                                    
02ca9424: ldr     x8, [x8, #0x650]                           MS:System.Collections.Generic.List`1::.ctor
02ca9428: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca942c: bl      #0x3569388                                 fn_3569388
02ca9430: cbnz    x21, #0x2ca92f8                            
02ca9434: ldr     x0, [x25]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca9438: bl      #0x2b7104c                                 fn_2b7104c
02ca943c: ldr     x1, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca9440: mov     x21, x0                                    
02ca9444: bl      #0x35a89a4                                 fn_35a89a4
02ca9448: b       #0x2ca92f8                                 
02ca944c: ldr     x1, [x25]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca9450: add     x0, sp, #0x50                              
02ca9454: bl      #0x4685af4                                 fn_4685af4
02ca9458: ldr     x8, [x19, #0x20]                           ._dataSave
02ca945c: cbz     x8, #0x2ca9718                             
02ca9460: ldr     x9, [x8, #0x18]                            S:'level_show_popuprate'
02ca9464: cbz     x9, #0x2ca9718                             
02ca9468: cbz     x22, #0x2ca9718                            
02ca946c: cbz     x21, #0x2ca9718                            
02ca9470: ldr     w9, [x9, #0x18]                            
02ca9474: ldr     w10, [x22, #0x18]                          [662f018]=6000014 f=2.40742e-35,0
02ca9478: ldr     w11, [x21, #0x18]                          
02ca947c: ldr     w8, [x8, #0x10]                            S:'mrec_ad_on_off'
02ca9480: sub     w9, w9, w10                                
02ca9484: add     w9, w9, w11                                
02ca9488: cmp     w9, w8                                     
02ca948c: b.le    #0x2ca94b4                                 
02ca9490: mov     w0, wzr                                    
02ca9494: ldp     x20, x19, [sp, #0xc0]                      
02ca9498: ldp     x22, x21, [sp, #0xb0]                      
02ca949c: ldp     x24, x23, [sp, #0xa0]                      
02ca94a0: ldp     x26, x25, [sp, #0x90]                      
02ca94a4: ldp     x28, x27, [sp, #0x80]                      
02ca94a8: ldp     x29, x30, [sp, #0x70]                      
02ca94ac: add     sp, sp, #0xd0                              
02ca94b0: ret                                                
02ca94b4: adrp    x8, #0x6266000                             
02ca94b8: ldr     x8, [x8, #0x6a8]                           T:type6847(k15)
02ca94bc: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca94c0: bl      #0x2b7104c                                 fn_2b7104c
02ca94c4: adrp    x8, #0x6266000                             
02ca94c8: mov     x1, x19                                    
02ca94cc: mov     x3, xzr                                    
02ca94d0: ldr     x8, [x8, #0x6b8]                           M:DataClicker::<TryCommitTrade>b__11_0
02ca94d4: mov     x23, x0                                    
02ca94d8: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca94dc: bl      #0x453418c                                 fn_453418c
02ca94e0: adrp    x8, #0x6266000                             
02ca94e4: mov     x0, x22                                    
02ca94e8: mov     x1, x23                                    
02ca94ec: ldr     x8, [x8, #0x6f8]                           MS:System.Collections.Generic.List`1::ForEach
02ca94f0: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca94f4: bl      #0x35a9ce4                                 fn_35a9ce4
02ca94f8: adrp    x8, #0x6266000                             
02ca94fc: mov     x0, x21                                    
02ca9500: ldr     x8, [x8, #0x700]                           MS:System.Collections.Generic.List`1::GetEnumerator
02ca9504: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca9508: add     x8, sp, #0x18                              
02ca950c: bl      #0x35a9d9c                                 fn_35a9d9c
02ca9510: ldur    q0, [sp, #0x18]                            
02ca9514: ldr     x8, [sp, #0x28]                            
02ca9518: adrp    x23, #0x6266000                            
02ca951c: adrp    x25, #0x6266000                            
02ca9520: ldr     x23, [x23, #0x6d8]                         MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02ca9524: adrp    x28, #0x6266000                            
02ca9528: ldr     x25, [x25, #0x648]                         T:type15061(k15)
02ca952c: str     q0, [sp, #0x30]                            
02ca9530: str     x8, [sp, #0x40]                            
02ca9534: add     x8, sp, #0x30                              
02ca9538: ldr     x28, [x28, #0x6b0]                         T:ClickerSaveDataItem
02ca953c: stp     xzr, x8, [sp, #0x18]                       
02ca9540: ldr     x1, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca9544: add     x0, sp, #0x30                              
02ca9548: bl      #0x4690474                                 fn_4690474
02ca954c: tbz     w0, #0, #0x2ca96cc                         
02ca9550: ldr     x8, [x19, #0x20]                           ._dataSave
02ca9554: cbz     x8, #0x2ca9710                             
02ca9558: ldr     w9, [x8, #0x14]                            [6266014]=0 f=0,0
02ca955c: ldr     x29, [sp, #0x40]                           
02ca9560: add     w26, w9, #1                                
02ca9564: str     w26, [x8, #0x14]                           
02ca9568: cbz     x29, #0x2ca9714                            
02ca956c: ldr     x21, [x29, #0x28]                          
02ca9570: ldur    q0, [x29, #0x14]                           
02ca9574: ldr     w27, [x29, #0x24]                          
02ca9578: str     q0, [sp]                                   
02ca957c: cbnz    x21, #0x2ca959c                            
02ca9580: ldr     x0, [x25]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca9584: bl      #0x2b7104c                                 fn_2b7104c
02ca9588: adrp    x8, #0x6266000                             
02ca958c: mov     x21, x0                                    
02ca9590: ldr     x8, [x8, #0x650]                           MS:System.Collections.Generic.List`1::.ctor
02ca9594: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca9598: bl      #0x3569388                                 fn_3569388
02ca959c: ldr     x0, [x25]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca95a0: bl      #0x2b7104c                                 fn_2b7104c
02ca95a4: adrp    x8, #0x6266000                             
02ca95a8: mov     x22, x0                                    
02ca95ac: ldr     x8, [x8, #0x710]                           MS:System.Collections.Generic.List`1::.ctor
02ca95b0: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca95b4: mov     x1, x21                                    
02ca95b8: bl      #0x35694c4                                 fn_35694c4
02ca95bc: ldr     x0, [x28]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca95c0: bl      #0x2b7104c                                 fn_2b7104c
02ca95c4: mov     x1, xzr                                    
02ca95c8: mov     x21, x0                                    
02ca95cc: bl      #0x4e53e9c                                 System.Object::.ctor
02ca95d0: ldr     q0, [sp]                                   
02ca95d4: mov     x0, x21                                    
02ca95d8: str     x22, [x0, #0x28]!                          
02ca95dc: stur    w26, [x0, #-0x18]                          
02ca95e0: stur    q0, [x0, #-0x14]                           
02ca95e4: stur    w27, [x0, #-4]                             
02ca95e8: mov     x1, x22                                    
02ca95ec: bl      #0x2b70d54                                 fn_2b70d54
02ca95f0: ldr     w8, [x29, #0x30]                           
02ca95f4: str     w8, [x21, #0x30]                           
02ca95f8: ldr     x8, [x19, #0x20]                           ._dataSave
02ca95fc: cbz     x8, #0x2ca970c                             
02ca9600: ldr     x0, [x8, #0x18]                            S:'level_show_popuprate'
02ca9604: cbz     x0, #0x2ca9700                             
02ca9608: ldr     w10, [x0, #0x1c]                           [626601c]=0 f=0,0
02ca960c: ldr     x8, [x0, #0x10]                            S:'mrec_ad_on_off'
02ca9610: ldr     x9, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca9614: add     w10, w10, #1                               
02ca9618: str     w10, [x0, #0x1c]                           
02ca961c: cbz     x8, #0x2ca9700                             
02ca9620: ldrsw   x10, [x0, #0x18]                           
02ca9624: ldr     w11, [x8, #0x18]                           S:'level_show_popuprate'
02ca9628: cmp     w10, w11                                   
02ca962c: b.hs    #0x2ca9650                                 
02ca9630: add     x8, x8, x10, lsl #3                        &6266000
02ca9634: add     w9, w10, #1                                
02ca9638: str     w9, [x0, #0x18]                            
02ca963c: str     x21, [x8, #0x20]!                          
02ca9640: mov     x0, x8                                     
02ca9644: mov     x1, x21                                    
02ca9648: bl      #0x2b70d54                                 fn_2b70d54
02ca964c: b       #0x2ca9664                                 
02ca9650: ldr     x8, [x9, #0x20]                            
02ca9654: ldr     x8, [x8, #0xc0]                            T:Firebase.RemoteConfig.ConfigValue
02ca9658: ldr     x2, [x8, #0x70]                            S:'open_ad_id'
02ca965c: mov     x1, x21                                    
02ca9660: bl      #0x35a920c                                 fn_35a920c
02ca9664: ldr     x0, [x20]                                  
02ca9668: cbz     x0, #0x2ca96fc                             
02ca966c: ldr     w10, [x0, #0x1c]                           [626601c]=0 f=0,0
02ca9670: ldr     x8, [x0, #0x10]                            S:'mrec_ad_on_off'
02ca9674: ldr     x9, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca9678: add     w10, w10, #1                               
02ca967c: str     w10, [x0, #0x1c]                           
02ca9680: cbz     x8, #0x2ca96fc                             
02ca9684: ldrsw   x10, [x0, #0x18]                           
02ca9688: ldr     w11, [x8, #0x18]                           S:'level_show_popuprate'
02ca968c: cmp     w10, w11                                   
02ca9690: b.hs    #0x2ca96b4                                 
02ca9694: add     x8, x8, x10, lsl #3                        &6266000
02ca9698: add     w9, w10, #1                                
02ca969c: str     w9, [x0, #0x18]                            
02ca96a0: str     x21, [x8, #0x20]!                          
02ca96a4: mov     x0, x8                                     
02ca96a8: mov     x1, x21                                    
02ca96ac: bl      #0x2b70d54                                 fn_2b70d54
02ca96b0: b       #0x2ca9540                                 
02ca96b4: ldr     x8, [x9, #0x20]                            
02ca96b8: ldr     x8, [x8, #0xc0]                            T:Firebase.RemoteConfig.ConfigValue
02ca96bc: ldr     x2, [x8, #0x70]                            S:'open_ad_id'
02ca96c0: mov     x1, x21                                    
02ca96c4: bl      #0x35a920c                                 fn_35a920c
02ca96c8: b       #0x2ca9540                                 
02ca96cc: adrp    x8, #0x6266000                             
02ca96d0: add     x0, sp, #0x30                              
02ca96d4: ldr     x8, [x8, #0x6c8]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02ca96d8: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca96dc: bl      #0x4690470                                 fn_4690470
02ca96e0: ldr     x8, [x19]                                  
02ca96e4: mov     x0, x19                                    
02ca96e8: ldr     x9, [x8, #0x258]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02ca96ec: ldr     x1, [x8, #0x260]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02ca96f0: blr     x9                                         
02ca96f4: mov     w0, #1                                     
02ca96f8: b       #0x2ca9494                                 
02ca96fc: bl      #0x2b7105c                                 fn_2b7105c
02ca9700: bl      #0x2b7105c                                 fn_2b7105c
02ca9704: bl      #0x2b7105c                                 fn_2b7105c
02ca9708: bl      #0x2b7105c                                 fn_2b7105c
02ca970c: bl      #0x2b7105c                                 fn_2b7105c
02ca9710: bl      #0x2b7105c                                 fn_2b7105c
02ca9714: bl      #0x2b7105c                                 fn_2b7105c
02ca9718: bl      #0x2b7105c                                 fn_2b7105c
02ca971c: b       #0x2ca97a0                                 
02ca9720: b       #0x2ca97a0                                 
02ca9724: b       #0x2ca97a0                                 
02ca9728: b       #0x2ca97a0                                 
02ca972c: b       #0x2ca97a0                                 
02ca9730: b       #0x2ca97a0                                 
02ca9734: b       #0x2ca97a0                                 
02ca9738: b       #0x2ca9758                                 
02ca973c: b       #0x2ca9758                                 
02ca9740: b       #0x2ca9758                                 
02ca9744: b       #0x2ca9758                                 
02ca9748: b       #0x2ca97a0                                 
02ca974c: b       #0x2ca97a0                                 
02ca9750: b       #0x2ca97a0                                 
02ca9754: b       #0x2ca9758                                 
02ca9758: mov     x23, x0                                    
02ca975c: cmp     w1, #1                                     
02ca9760: b.ne    #0x2ca9794                                 
02ca9764: mov     x0, x23                                    
02ca9768: bl      #0x5e90260                                 fn_5e90260
02ca976c: ldr     x23, [x0]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca9770: str     x23, [sp, #0x18]                           
02ca9774: bl      #0x5e90270                                 fn_5e90270
02ca9778: ldr     x0, [sp, #0x20]                            
02ca977c: ldr     x1, [x25]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca9780: bl      #0x4685af4                                 fn_4685af4
02ca9784: cbz     x23, #0x2ca9458                            
02ca9788: mov     x0, x23                                    
02ca978c: bl      #0x2b71054                                 fn_2b71054
02ca9790: mov     x23, x0                                    
02ca9794: add     x0, sp, #0x18                              
02ca9798: bl      #0x2736f4c                                 fn_2736f4c
02ca979c: b       #0x2ca97ec                                 
02ca97a0: mov     x23, x0                                    
02ca97a4: cmp     w1, #1                                     
02ca97a8: b.ne    #0x2ca97e4                                 
02ca97ac: mov     x0, x23                                    
02ca97b0: bl      #0x5e90260                                 fn_5e90260
02ca97b4: ldr     x20, [x0]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca97b8: str     x20, [sp, #0x18]                           
02ca97bc: bl      #0x5e90270                                 fn_5e90270
02ca97c0: adrp    x8, #0x6266000                             
02ca97c4: ldr     x8, [x8, #0x6c8]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02ca97c8: ldr     x0, [sp, #0x20]                            
02ca97cc: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca97d0: bl      #0x4690470                                 fn_4690470
02ca97d4: cbz     x20, #0x2ca96e0                            
02ca97d8: mov     x0, x20                                    
02ca97dc: bl      #0x2b71054                                 fn_2b71054
02ca97e0: mov     x23, x0                                    
02ca97e4: add     x0, sp, #0x18                              
02ca97e8: bl      #0x2736f7c                                 fn_2736f7c
02ca97ec: mov     x0, x23                                    
02ca97f0: bl      #0x2c6051c                                 fn_2c6051c
02ca97f4: bl      #0x27369b8                                 fn_27369b8
## CanAddNewKeycap() -> bool
---- DataClicker::CanAddNewKeycap 0x2ca97f8
02ca97f8: str     x30, [sp, #-0x20]!                         
02ca97fc: stp     x20, x19, [sp, #0x10]                      
02ca9800: adrp    x20, #0x662f000                            
02ca9804: mov     x19, x0                                    
02ca9808: ldrb    w8, [x20, #0xb0a]                          
02ca980c: tbnz    w8, #0, #0x2ca9824                         
02ca9810: adrp    x0, #0x6266000                             
02ca9814: ldr     x0, [x0, #0x6a0]                           MS:System.Collections.Generic.List`1::get_Count
02ca9818: bl      #0x2b70db0                                 fn_2b70db0
02ca981c: mov     w8, #1                                     
02ca9820: strb    w8, [x20, #0xb0a]                          
02ca9824: ldr     x8, [x19, #0x20]                           ._dataSave
02ca9828: cbz     x8, #0x2ca9850                             
02ca982c: ldr     x9, [x8, #0x18]                            
02ca9830: cbz     x9, #0x2ca9850                             
02ca9834: ldr     w9, [x9, #0x18]                            
02ca9838: ldr     w8, [x8, #0x10]                            
02ca983c: ldp     x20, x19, [sp, #0x10]                      
02ca9840: cmp     w9, w8                                     
02ca9844: cset    w0, lt                                     
02ca9848: ldr     x30, [sp], #0x20                           
02ca984c: ret                                                
02ca9850: bl      #0x2b7105c                                 fn_2b7105c
## RemoveSavedKeycap(int index) -> void
---- DataClicker::RemoveSavedKeycap 0x2ca9854
02ca9854: str     x30, [sp, #-0x30]!                         
02ca9858: stp     x22, x21, [sp, #0x10]                      
02ca985c: stp     x20, x19, [sp, #0x20]                      
02ca9860: adrp    x21, #0x662f000                            
02ca9864: adrp    x22, #0x6266000                            
02ca9868: mov     w20, w1                                    
02ca986c: ldrb    w8, [x21, #0xb0b]                          
02ca9870: ldr     x22, [x22, #0x718]                         T:DataClicker/<>c__DisplayClass13_0
02ca9874: mov     x19, x0                                    
02ca9878: tbnz    w8, #0, #0x2ca98c0                         
02ca987c: adrp    x0, #0x6266000                             
02ca9880: ldr     x0, [x0, #0x688]                           MS:System.Collections.Generic.List`1::Find
02ca9884: bl      #0x2b70db0                                 fn_2b70db0
02ca9888: adrp    x0, #0x6266000                             
02ca988c: ldr     x0, [x0, #0x720]                           MS:System.Collections.Generic.List`1::Remove
02ca9890: bl      #0x2b70db0                                 fn_2b70db0
02ca9894: adrp    x0, #0x6266000                             
02ca9898: ldr     x0, [x0, #0x690]                           T:type57233(k15)
02ca989c: bl      #0x2b70db0                                 fn_2b70db0
02ca98a0: adrp    x0, #0x6266000                             
02ca98a4: ldr     x0, [x0, #0x728]                           M:DataClicker/<>c__DisplayClass13_0::<RemoveSavedKeycap>b__0
02ca98a8: bl      #0x2b70db0                                 fn_2b70db0
02ca98ac: adrp    x0, #0x6266000                             
02ca98b0: ldr     x0, [x0, #0x718]                           T:DataClicker/<>c__DisplayClass13_0
02ca98b4: bl      #0x2b70db0                                 fn_2b70db0
02ca98b8: mov     w8, #1                                     
02ca98bc: strb    w8, [x21, #0xb0b]                          
02ca98c0: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca98c4: bl      #0x2b7104c                                 fn_2b7104c
02ca98c8: mov     x1, xzr                                    
02ca98cc: mov     x21, x0                                    
02ca98d0: bl      #0x4e53e9c                                 System.Object::.ctor
02ca98d4: cbz     x21, #0x2ca9974                            
02ca98d8: ldr     x8, [x19, #0x20]                           ._dataSave
02ca98dc: str     w20, [x21, #0x10]                          
02ca98e0: cbz     x8, #0x2ca9974                             
02ca98e4: adrp    x9, #0x6266000                             
02ca98e8: adrp    x22, #0x6266000                            
02ca98ec: ldr     x9, [x9, #0x690]                           T:type57233(k15)
02ca98f0: ldr     x22, [x22, #0x728]                         M:DataClicker/<>c__DisplayClass13_0::<RemoveSavedKeycap>b__0
02ca98f4: ldr     x20, [x8, #0x18]                           
02ca98f8: ldr     x0, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca98fc: bl      #0x2b7104c                                 fn_2b7104c
02ca9900: ldr     x2, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca9904: mov     x1, x21                                    
02ca9908: mov     x3, xzr                                    
02ca990c: mov     x22, x0                                    
02ca9910: bl      #0x399ba10                                 fn_399ba10
02ca9914: cbz     x20, #0x2ca9974                            
02ca9918: adrp    x8, #0x6266000                             
02ca991c: mov     x0, x20                                    
02ca9920: mov     x1, x22                                    
02ca9924: ldr     x8, [x8, #0x688]                           MS:System.Collections.Generic.List`1::Find
02ca9928: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca992c: bl      #0x35a9868                                 fn_35a9868
02ca9930: cbz     x0, #0x2ca9964                             
02ca9934: ldr     x8, [x19, #0x20]                           ._dataSave
02ca9938: cbz     x8, #0x2ca9974                             
02ca993c: mov     x1, x0                                     
02ca9940: ldr     x0, [x8, #0x18]                            S:'level_show_popuprate'
02ca9944: cbz     x0, #0x2ca9974                             
02ca9948: adrp    x8, #0x6266000                             
02ca994c: ldr     x8, [x8, #0x720]                           MS:System.Collections.Generic.List`1::Remove
02ca9950: ldp     x20, x19, [sp, #0x20]                      
02ca9954: ldp     x22, x21, [sp, #0x10]                      
02ca9958: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca995c: ldr     x30, [sp], #0x30                           
02ca9960: b       #0x35aa7b4                                 
02ca9964: ldp     x20, x19, [sp, #0x20]                      
02ca9968: ldp     x22, x21, [sp, #0x10]                      
02ca996c: ldr     x30, [sp], #0x30                           
02ca9970: ret                                                
02ca9974: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- DataClicker::.ctor 0x2ca9980
02ca9980: mov     x1, xzr                                    
02ca9984: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
## <TryCommitTrade>b__11_0(ClickerSaveDataItem item) -> void
---- DataClicker::<TryCommitTrade>b__11_0 0x2ca9990
02ca9990: stp     x30, x21, [sp, #-0x20]!                    
02ca9994: stp     x20, x19, [sp, #0x10]                      
02ca9998: adrp    x21, #0x662f000                            
02ca999c: mov     x19, x1                                    
02ca99a0: mov     x20, x0                                    
02ca99a4: ldrb    w8, [x21, #0xb0c]                          
02ca99a8: tbnz    w8, #0, #0x2ca99c0                         
02ca99ac: adrp    x0, #0x6266000                             
02ca99b0: ldr     x0, [x0, #0x720]                           MS:System.Collections.Generic.List`1::Remove
02ca99b4: bl      #0x2b70db0                                 fn_2b70db0
02ca99b8: mov     w8, #1                                     
02ca99bc: strb    w8, [x21, #0xb0c]                          
02ca99c0: ldr     x8, [x20, #0x20]                           ._dataSave
02ca99c4: cbz     x8, #0x2ca99ec                             
02ca99c8: ldr     x0, [x8, #0x18]                            
02ca99cc: cbz     x0, #0x2ca99ec                             
02ca99d0: adrp    x8, #0x6266000                             
02ca99d4: mov     x1, x19                                    
02ca99d8: ldr     x8, [x8, #0x720]                           MS:System.Collections.Generic.List`1::Remove
02ca99dc: ldp     x20, x19, [sp, #0x10]                      
02ca99e0: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca99e4: ldp     x30, x21, [sp], #0x20                      
02ca99e8: b       #0x35aa7b4                                 
02ca99ec: bl      #0x2b7105c                                 fn_2b7105c
