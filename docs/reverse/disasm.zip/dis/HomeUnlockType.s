#### CLASS HomeUnlockType parent= int
#   field value__                        int                                                off=0x10 attr=606 
#   field None                           HomeUnlockType                                     off=0x0 attr=8056 
#   field ModeDreamHouse                 HomeUnlockType                                     off=0x0 attr=8056 
#   field Charm                          HomeUnlockType                                     off=0x0 attr=8056 
#   field ModeScoop                      HomeUnlockType                                     off=0x0 attr=8056 
#   field ModePartTime                   HomeUnlockType                                     off=0x0 attr=8056 
#   field ModeIdleChest                  HomeUnlockType                                     off=0x0 attr=8056 
#   field ModeDecor                      HomeUnlockType                                     off=0x0 attr=8056 
#   field ModeDailyTask                  HomeUnlockType                                     off=0x0 attr=8056 
#   field ModeBlindBag                   HomeUnlockType                                     off=0x0 attr=8056 
#   field ModeDumplingBlindBag           HomeUnlockType                                     off=0x0 attr=8056 
