#### CLASS CommentConfig parent= object
#   field IsViewer                       bool                                               off=0x10 attr=6 
#   field Id                             long                                               off=0x18 attr=6 
#   field Content                        string                                             off=0x20 attr=6 
## .ctor() -> void
---- CommentConfig::.ctor 0x2cb5a4c
02cb5a4c: mov     x1, xzr                                    
02cb5a50: b       #0x4e53e9c                                 System.Object::.ctor
