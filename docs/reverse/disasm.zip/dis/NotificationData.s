#### CLASS NotificationData parent= object
#   field channelType                    ChannelType                                        off=0x10 attr=6 
#   field title                          string                                             off=0x18 attr=6 HeaderAttribute
#   field descriptions                   string                                             off=0x20 attr=6 
## .ctor() -> void
---- NotificationData::.ctor 0x2ca804c
02ca804c: mov     x1, xzr                                    
02ca8050: b       #0x4e53e9c                                 System.Object::.ctor
