#### CLASS Character.SingleAnimationState parent= Character.BaseState
## Update() -> void
---- Character.SingleAnimationState::Update 0x2d761f4
02d761f4: ret                                                
## Exit() -> void
---- Character.SingleAnimationState::Exit 0x2d761f8
02d761f8: ldr     x0, [x0, #0x18]                            
02d761fc: cbz     x0, #0x2d76208                             
02d76200: mov     x1, xzr                                    
02d76204: b       #0x2cb3c24                                 SpineAnimationHandler::PauseAnimation
02d76208: str     x30, [sp, #-0x10]!                         
02d7620c: bl      #0x2b7105c                                 fn_2b7105c
## Enter(bool isLoop, System.Action OnStart, System.Action OnEnd) -> void
---- Character.SingleAnimationState::Enter 0x2d76210
02d76210: mov     x8, x0                                     
02d76214: ldr     x0, [x0, #0x18]                            
02d76218: cbz     x0, #0x2d76238                             
02d7621c: ldr     w8, [x8, #0x20]                            
02d76220: mov     x4, x3                                     
02d76224: mov     x3, x2                                     
02d76228: and     w2, w1, #1                                 
02d7622c: mov     x5, xzr                                    
02d76230: mov     w1, w8                                     
02d76234: b       #0x2cb3fec                                 SpineAnimationHandler::PlayAnimation
02d76238: str     x30, [sp, #-0x10]!                         
02d7623c: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Character.SingleAnimationState::.ctor 0x2d75c0c
02d75c0c: mov     x1, xzr                                    
02d75c10: b       #0x4e53e9c                                 System.Object::.ctor
