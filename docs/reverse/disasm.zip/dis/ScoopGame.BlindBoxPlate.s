#### CLASS ScoopGame.BlindBoxPlate/<>c parent= object
#   field <>9                            ScoopGame.BlindBoxPlate/<>c                        off=0x0 attr=36 
#   field <>9__3_0                       System.Predicate`1<ScoopGame.BlindBox>             off=0x8 attr=16 
#   field <>9__19_0                      System.Predicate`1<ScoopGame.BlindBox>             off=0x10 attr=16 
## .cctor() -> void
---- ScoopGame.BlindBoxPlate/<>c::.cctor 0x2d3e404
02d3e404: str     x30, [sp, #-0x20]!                         
02d3e408: stp     x20, x19, [sp, #0x10]                      
02d3e40c: adrp    x19, #0x6630000                            
02d3e410: adrp    x20, #0x626a000                            
02d3e414: ldrb    w8, [x19, #0x17b]                          
02d3e418: ldr     x20, [x20, #0xdf0]                         T:ScoopGame.BlindBoxPlate/<>c
02d3e41c: tbnz    w8, #0, #0x2d3e434                         
02d3e420: adrp    x0, #0x626a000                             
02d3e424: ldr     x0, [x0, #0xdf0]                           T:ScoopGame.BlindBoxPlate/<>c
02d3e428: bl      #0x2b70db0                                 fn_2b70db0
02d3e42c: mov     w8, #1                                     
02d3e430: strb    w8, [x19, #0x17b]                          
02d3e434: ldr     x0, [x20]                                  T:type56879(k15)
02d3e438: bl      #0x2b7104c                                 fn_2b7104c
02d3e43c: mov     x1, xzr                                    
02d3e440: mov     x19, x0                                    
02d3e444: bl      #0x4e53e9c                                 System.Object::.ctor
02d3e448: ldr     x8, [x20]                                  T:type56879(k15)
02d3e44c: mov     x1, x19                                    
02d3e450: ldr     x8, [x8, #0xb8]                            
02d3e454: str     x19, [x8]                                  
02d3e458: ldr     x8, [x20]                                  T:type56879(k15)
02d3e45c: ldp     x20, x19, [sp, #0x10]                      
02d3e460: ldr     x0, [x8, #0xb8]                            
02d3e464: ldr     x30, [sp], #0x20                           
02d3e468: b       #0x2b70d54                                 
## .ctor() -> void
---- ScoopGame.BlindBoxPlate/<>c::.ctor 0x2d3e46c
02d3e46c: mov     x1, xzr                                    
02d3e470: b       #0x4e53e9c                                 System.Object::.ctor
## <get_RareCharmCount>b__3_0(ScoopGame.BlindBox x) -> bool
---- ScoopGame.BlindBoxPlate/<>c::<get_RareCharmCount>b__3_0 0x2d3e474
02d3e474: cbz     x1, #0x2d3e480                             
02d3e478: ldrb    w0, [x1, #0x60]                            
02d3e47c: ret                                                
02d3e480: str     x30, [sp, #-0x10]!                         
02d3e484: bl      #0x2b7105c                                 fn_2b7105c
## <get_DoneUnbox>b__19_0(ScoopGame.BlindBox x) -> bool
---- ScoopGame.BlindBoxPlate/<>c::<get_DoneUnbox>b__19_0 0x2d3e488
02d3e488: cbz     x1, #0x2d3e49c                             
02d3e48c: ldrb    w8, [x1, #0x80]                            
02d3e490: cmp     w8, #0                                     
02d3e494: cset    w0, eq                                     
02d3e498: ret                                                
02d3e49c: str     x30, [sp, #-0x10]!                         
02d3e4a0: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS ScoopGame.BlindBoxPlate/<>c__DisplayClass30_0 parent= object
#   field <>4__this                      ScoopGame.BlindBoxPlate                            off=0x10 attr=6 
#   field cachedIndex                    int                                                off=0x18 attr=6 
## .ctor() -> void
---- ScoopGame.BlindBoxPlate/<>c__DisplayClass30_0::.ctor 0x2d3de90
02d3de90: mov     x1, xzr                                    
02d3de94: b       #0x4e53e9c                                 System.Object::.ctor
## <CheckPopOutBlindBox>b__0() -> void
---- ScoopGame.BlindBoxPlate/<>c__DisplayClass30_0::<CheckPopOutBlindBox>b__0 0x2d3e4a4
02d3e4a4: stp     x30, x21, [sp, #-0x20]!                    
02d3e4a8: stp     x20, x19, [sp, #0x10]                      
02d3e4ac: adrp    x20, #0x6630000                            
02d3e4b0: adrp    x21, #0x6267000                            
02d3e4b4: mov     x19, x0                                    
02d3e4b8: ldrb    w8, [x20, #0x17c]                          
02d3e4bc: ldr     x21, [x21, #0xea8]                         T:Framework.Vibration
02d3e4c0: tbnz    w8, #0, #0x2d3e4e4                         
02d3e4c4: adrp    x0, #0x626a000                             
02d3e4c8: ldr     x0, [x0, #0xe70]                           MS:System.Collections.Generic.List`1::get_Item
02d3e4cc: bl      #0x2b70db0                                 fn_2b70db0
02d3e4d0: adrp    x0, #0x6267000                             
02d3e4d4: ldr     x0, [x0, #0xea8]                           T:Framework.Vibration
02d3e4d8: bl      #0x2b70db0                                 fn_2b70db0
02d3e4dc: mov     w8, #1                                     
02d3e4e0: strb    w8, [x20, #0x17c]                          
02d3e4e4: ldr     x0, [x21]                                  S:'didu'
02d3e4e8: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02d3e4ec: cbnz    w8, #0x2d3e4f4                             
02d3e4f0: bl      #0x2b70f30                                 fn_2b70f30
02d3e4f4: mov     w0, #0x3c                                  
02d3e4f8: mov     w1, #-1                                    
02d3e4fc: mov     w2, wzr                                    
02d3e500: mov     x3, xzr                                    
02d3e504: bl      #0x2d6e144                                 Framework.Vibration::Vibrate
02d3e508: ldr     x8, [x19, #0x10]                           .<>4__this
02d3e50c: cbz     x8, #0x2d3e53c                             
02d3e510: ldr     x0, [x8, #0x28]                            
02d3e514: cbz     x0, #0x2d3e53c                             
02d3e518: adrp    x8, #0x626a000                             
02d3e51c: ldr     x8, [x8, #0xe70]                           MS:System.Collections.Generic.List`1::get_Item
02d3e520: ldr     w1, [x19, #0x18]                           .cachedIndex
02d3e524: ldr     x2, [x8]                                   T:type56879(k15)
02d3e528: bl      #0x35a8f3c                                 fn_35a8f3c
02d3e52c: cbz     x0, #0x2d3e53c                             
02d3e530: ldp     x20, x19, [sp, #0x10]                      
02d3e534: ldp     x30, x21, [sp], #0x20                      
02d3e538: b       #0x2d3cb08                                 ScoopGame.BlindBox::EnableClick
02d3e53c: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS ScoopGame.BlindBoxPlate/<>c__DisplayClass31_0 parent= object
#   field obj                            ScoopGame.BlindBox                                 off=0x10 attr=6 
## .ctor() -> void
---- ScoopGame.BlindBoxPlate/<>c__DisplayClass31_0::.ctor 0x2d3e2c8
02d3e2c8: mov     x1, xzr                                    
02d3e2cc: b       #0x4e53e9c                                 System.Object::.ctor
## <AddMoreRandomBox>b__0() -> void
---- ScoopGame.BlindBoxPlate/<>c__DisplayClass31_0::<AddMoreRandomBox>b__0 0x2d3e540
02d3e540: stp     x30, x21, [sp, #-0x20]!                    
02d3e544: stp     x20, x19, [sp, #0x10]                      
02d3e548: adrp    x20, #0x6630000                            
02d3e54c: adrp    x21, #0x6267000                            
02d3e550: mov     x19, x0                                    
02d3e554: ldrb    w8, [x20, #0x17d]                          
02d3e558: ldr     x21, [x21, #0xea8]                         T:Framework.Vibration
02d3e55c: tbnz    w8, #0, #0x2d3e574                         
02d3e560: adrp    x0, #0x6267000                             
02d3e564: ldr     x0, [x0, #0xea8]                           T:Framework.Vibration
02d3e568: bl      #0x2b70db0                                 fn_2b70db0
02d3e56c: mov     w8, #1                                     
02d3e570: strb    w8, [x20, #0x17d]                          
02d3e574: ldr     x0, [x21]                                  S:'didu'
02d3e578: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02d3e57c: cbnz    w8, #0x2d3e584                             
02d3e580: bl      #0x2b70f30                                 fn_2b70f30
02d3e584: mov     w0, #0x3c                                  
02d3e588: mov     w1, #-1                                    
02d3e58c: mov     w2, wzr                                    
02d3e590: mov     x3, xzr                                    
02d3e594: bl      #0x2d6e144                                 Framework.Vibration::Vibrate
02d3e598: ldr     x0, [x19, #0x10]                           .obj
02d3e59c: cbz     x0, #0x2d3e5ac                             
02d3e5a0: ldp     x20, x19, [sp, #0x10]                      
02d3e5a4: ldp     x30, x21, [sp], #0x20                      
02d3e5a8: b       #0x2d3cb08                                 ScoopGame.BlindBox::EnableClick
02d3e5ac: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS ScoopGame.BlindBoxPlate parent= UnityEngine.MonoBehaviour
#   field _blindBoxItem                  ScoopGame.BlindBox                                 off=0x20 attr=1 SerializeField
#   field _spawnedBlindBox               System.Collections.Generic.List`1<ScoopGame.BlindBox> off=0x28 attr=1 SerializeField
#   field _tfHolder                      UnityEngine.Transform                              off=0x30 attr=1 SerializeField
#   field _tfPlate                       UnityEngine.Transform                              off=0x38 attr=1 SerializeField
#   field _tfPlateResult                 UnityEngine.Transform                              off=0x40 attr=1 SerializeField
#   field _tfTopRight                    UnityEngine.Transform                              off=0x48 attr=1 SerializeField
#   field _tfBottomLeft                  UnityEngine.Transform                              off=0x50 attr=1 SerializeField
#   field _tfTopRightOpen                UnityEngine.Transform                              off=0x58 attr=1 SerializeField
#   field _tfBottomLeftOpen              UnityEngine.Transform                              off=0x60 attr=1 SerializeField
#   field _tfTopRightPlate               UnityEngine.Transform                              off=0x68 attr=1 SerializeField
#   field _tfBottomLeftPlate             UnityEngine.Transform                              off=0x70 attr=1 SerializeField
#   field _collider                      UnityEngine.Collider2D                             off=0x78 attr=1 SerializeField
#   field _complimentSprites             System.Collections.Generic.List`1<UnityEngine.Sprite> off=0x80 attr=1 HeaderAttribute,SerializeField
#   field _complimentSoundEnum           System.Collections.Generic.List`1<Framework.ESound> off=0x88 attr=1 SerializeField
#   field _tfComplimentTopRight          UnityEngine.Transform                              off=0x90 attr=1 SerializeField
#   field _tfComplimentBottomLeft        UnityEngine.Transform                              off=0x98 attr=1 SerializeField
#   field _currentBoxHold                int                                                off=0xa0 attr=1 
#   field _cachedSkinName                string                                             off=0xa8 attr=1 
#   field x                              float                                              off=0xb0 attr=1 
#   field y                              float                                              off=0xb4 attr=1 
#   field z                              float                                              off=0xb8 attr=1 
## get_RareCharmCount() -> int
---- ScoopGame.BlindBoxPlate::get_RareCharmCount 0x2d3d0cc
02d3d0cc: str     x30, [sp, #-0x30]!                         
02d3d0d0: stp     x22, x21, [sp, #0x10]                      
02d3d0d4: stp     x20, x19, [sp, #0x20]                      
02d3d0d8: adrp    x20, #0x6630000                            
02d3d0dc: adrp    x22, #0x626a000                            
02d3d0e0: mov     x19, x0                                    
02d3d0e4: ldrb    w8, [x20, #0x170]                          
02d3d0e8: ldr     x22, [x22, #0xdf0]                         T:ScoopGame.BlindBoxPlate/<>c
02d3d0ec: tbnz    w8, #0, #0x2d3d134                         
02d3d0f0: adrp    x0, #0x626a000                             
02d3d0f4: ldr     x0, [x0, #0xdf8]                           MS:System.Collections.Generic.List`1::FindAll
02d3d0f8: bl      #0x2b70db0                                 fn_2b70db0
02d3d0fc: adrp    x0, #0x626a000                             
02d3d100: ldr     x0, [x0, #0xe00]                           MS:System.Collections.Generic.List`1::get_Count
02d3d104: bl      #0x2b70db0                                 fn_2b70db0
02d3d108: adrp    x0, #0x626a000                             
02d3d10c: ldr     x0, [x0, #0xe08]                           T:type57221(k15)
02d3d110: bl      #0x2b70db0                                 fn_2b70db0
02d3d114: adrp    x0, #0x626a000                             
02d3d118: ldr     x0, [x0, #0xe10]                           M:ScoopGame.BlindBoxPlate/<>c::<get_RareCharmCount>b__3_0
02d3d11c: bl      #0x2b70db0                                 fn_2b70db0
02d3d120: adrp    x0, #0x626a000                             
02d3d124: ldr     x0, [x0, #0xdf0]                           T:ScoopGame.BlindBoxPlate/<>c
02d3d128: bl      #0x2b70db0                                 fn_2b70db0
02d3d12c: mov     w8, #1                                     
02d3d130: strb    w8, [x20, #0x170]                          
02d3d134: ldr     x0, [x22]                                  T:type56879(k15)
02d3d138: ldr     x19, [x19, #0x28]                          ._spawnedBlindBox
02d3d13c: ldr     w8, [x0, #0xe4]                            [626a0e4]=0 f=0,0
02d3d140: cbnz    w8, #0x2d3d14c                             
02d3d144: bl      #0x2b70f30                                 fn_2b70f30
02d3d148: ldr     x0, [x22]                                  T:type56879(k15)
02d3d14c: ldr     x8, [x0, #0xb8]                            MS:UnityEngine.Object::FindObjectsOfType .z
02d3d150: ldr     x20, [x8, #8]                              
02d3d154: cbnz    x20, #0x2d3d1b0                            
02d3d158: ldr     w9, [x0, #0xe4]                            [626a0e4]=0 f=0,0
02d3d15c: cbnz    w9, #0x2d3d16c                             
02d3d160: bl      #0x2b70f30                                 fn_2b70f30
02d3d164: ldr     x8, [x22]                                  T:type56879(k15)
02d3d168: ldr     x8, [x8, #0xb8]                            
02d3d16c: adrp    x9, #0x626a000                             
02d3d170: ldr     x9, [x9, #0xe08]                           T:type57221(k15)
02d3d174: ldr     x21, [x8]                                  
02d3d178: ldr     x0, [x9]                                   T:type56879(k15)
02d3d17c: bl      #0x2b7104c                                 fn_2b7104c
02d3d180: adrp    x8, #0x626a000                             
02d3d184: mov     x1, x21                                    
02d3d188: mov     x3, xzr                                    
02d3d18c: ldr     x8, [x8, #0xe10]                           M:ScoopGame.BlindBoxPlate/<>c::<get_RareCharmCount>b__3_0
02d3d190: mov     x20, x0                                    
02d3d194: ldr     x2, [x8]                                   T:type56879(k15)
02d3d198: bl      #0x399ba10                                 fn_399ba10
02d3d19c: ldr     x8, [x22]                                  T:type56879(k15)
02d3d1a0: mov     x1, x20                                    
02d3d1a4: ldr     x0, [x8, #0xb8]                            MS:UnityEngine.Object::FindObjectsOfType
02d3d1a8: str     x20, [x0, #8]!                             
02d3d1ac: bl      #0x2b70d54                                 fn_2b70d54
02d3d1b0: cbz     x19, #0x2d3d1e4                            
02d3d1b4: adrp    x8, #0x626a000                             
02d3d1b8: mov     x0, x19                                    
02d3d1bc: mov     x1, x20                                    
02d3d1c0: ldr     x8, [x8, #0xdf8]                           MS:System.Collections.Generic.List`1::FindAll
02d3d1c4: ldr     x2, [x8]                                   T:type56879(k15)
02d3d1c8: bl      #0x35a9914                                 fn_35a9914
02d3d1cc: cbz     x0, #0x2d3d1e4                             
02d3d1d0: ldp     x20, x19, [sp, #0x20]                      
02d3d1d4: ldr     w0, [x0, #0x18]                            MS:System.Collections.Generic.List`1::Add
02d3d1d8: ldp     x22, x21, [sp, #0x10]                      
02d3d1dc: ldr     x30, [sp], #0x30                           
02d3d1e0: ret                                                
02d3d1e4: bl      #0x2b7105c                                 fn_2b7105c
## get_DoneUnbox() -> bool
---- ScoopGame.BlindBoxPlate::get_DoneUnbox 0x2d3d1e8
02d3d1e8: str     x30, [sp, #-0x30]!                         
02d3d1ec: stp     x22, x21, [sp, #0x10]                      
02d3d1f0: stp     x20, x19, [sp, #0x20]                      
02d3d1f4: adrp    x20, #0x6630000                            
02d3d1f8: adrp    x22, #0x626a000                            
02d3d1fc: mov     x19, x0                                    
02d3d200: ldrb    w8, [x20, #0x171]                          
02d3d204: ldr     x22, [x22, #0xdf0]                         T:ScoopGame.BlindBoxPlate/<>c
02d3d208: tbnz    w8, #0, #0x2d3d250                         
02d3d20c: adrp    x0, #0x626a000                             
02d3d210: ldr     x0, [x0, #0xdf8]                           MS:System.Collections.Generic.List`1::FindAll
02d3d214: bl      #0x2b70db0                                 fn_2b70db0
02d3d218: adrp    x0, #0x626a000                             
02d3d21c: ldr     x0, [x0, #0xe00]                           MS:System.Collections.Generic.List`1::get_Count
02d3d220: bl      #0x2b70db0                                 fn_2b70db0
02d3d224: adrp    x0, #0x626a000                             
02d3d228: ldr     x0, [x0, #0xe08]                           T:type57221(k15)
02d3d22c: bl      #0x2b70db0                                 fn_2b70db0
02d3d230: adrp    x0, #0x626a000                             
02d3d234: ldr     x0, [x0, #0xe18]                           M:ScoopGame.BlindBoxPlate/<>c::<get_DoneUnbox>b__19_0
02d3d238: bl      #0x2b70db0                                 fn_2b70db0
02d3d23c: adrp    x0, #0x626a000                             
02d3d240: ldr     x0, [x0, #0xdf0]                           T:ScoopGame.BlindBoxPlate/<>c
02d3d244: bl      #0x2b70db0                                 fn_2b70db0
02d3d248: mov     w8, #1                                     
02d3d24c: strb    w8, [x20, #0x171]                          
02d3d250: ldr     x0, [x22]                                  T:type56879(k15)
02d3d254: ldr     x19, [x19, #0x28]                          ._spawnedBlindBox
02d3d258: ldr     w8, [x0, #0xe4]                            [626a0e4]=0 f=0,0
02d3d25c: cbnz    w8, #0x2d3d268                             
02d3d260: bl      #0x2b70f30                                 fn_2b70f30
02d3d264: ldr     x0, [x22]                                  T:type56879(k15)
02d3d268: ldr     x8, [x0, #0xb8]                            MS:UnityEngine.Object::FindObjectsOfType .z
02d3d26c: ldr     x20, [x8, #0x10]                           
02d3d270: cbnz    x20, #0x2d3d2cc                            
02d3d274: ldr     w9, [x0, #0xe4]                            [626a0e4]=0 f=0,0
02d3d278: cbnz    w9, #0x2d3d288                             
02d3d27c: bl      #0x2b70f30                                 fn_2b70f30
02d3d280: ldr     x8, [x22]                                  T:type56879(k15)
02d3d284: ldr     x8, [x8, #0xb8]                            
02d3d288: adrp    x9, #0x626a000                             
02d3d28c: ldr     x9, [x9, #0xe08]                           T:type57221(k15)
02d3d290: ldr     x21, [x8]                                  
02d3d294: ldr     x0, [x9]                                   T:type56879(k15)
02d3d298: bl      #0x2b7104c                                 fn_2b7104c
02d3d29c: adrp    x8, #0x626a000                             
02d3d2a0: mov     x1, x21                                    
02d3d2a4: mov     x3, xzr                                    
02d3d2a8: ldr     x8, [x8, #0xe18]                           M:ScoopGame.BlindBoxPlate/<>c::<get_DoneUnbox>b__19_0
02d3d2ac: mov     x20, x0                                    
02d3d2b0: ldr     x2, [x8]                                   T:type56879(k15)
02d3d2b4: bl      #0x399ba10                                 fn_399ba10
02d3d2b8: ldr     x8, [x22]                                  T:type56879(k15)
02d3d2bc: mov     x1, x20                                    
02d3d2c0: ldr     x0, [x8, #0xb8]                            MS:UnityEngine.Object::FindObjectsOfType
02d3d2c4: str     x20, [x0, #0x10]!                          
02d3d2c8: bl      #0x2b70d54                                 fn_2b70d54
02d3d2cc: cbz     x19, #0x2d3d308                            
02d3d2d0: adrp    x8, #0x626a000                             
02d3d2d4: mov     x0, x19                                    
02d3d2d8: mov     x1, x20                                    
02d3d2dc: ldr     x8, [x8, #0xdf8]                           MS:System.Collections.Generic.List`1::FindAll
02d3d2e0: ldr     x2, [x8]                                   T:type56879(k15)
02d3d2e4: bl      #0x35a9914                                 fn_35a9914
02d3d2e8: cbz     x0, #0x2d3d308                             
02d3d2ec: ldr     w8, [x0, #0x18]                            MS:System.Collections.Generic.List`1::Add
02d3d2f0: ldp     x20, x19, [sp, #0x20]                      
02d3d2f4: ldp     x22, x21, [sp, #0x10]                      
02d3d2f8: cmp     w8, #0                                     
02d3d2fc: cset    w0, eq                                     
02d3d300: ldr     x30, [sp], #0x30                           
02d3d304: ret                                                
02d3d308: bl      #0x2b7105c                                 fn_2b7105c
## ClearPlate() -> void
---- ScoopGame.BlindBoxPlate::ClearPlate 0x2d3d30c
02d3d30c: sub     sp, sp, #0x70                              
02d3d310: stp     x30, x23, [sp, #0x40]                      
02d3d314: stp     x22, x21, [sp, #0x50]                      
02d3d318: stp     x20, x19, [sp, #0x60]                      
02d3d31c: adrp    x20, #0x6630000                            
02d3d320: mov     x19, x0                                    
02d3d324: ldrb    w8, [x20, #0x172]                          
02d3d328: tbnz    w8, #0, #0x2d3d37c                         
02d3d32c: adrp    x0, #0x626a000                             
02d3d330: ldr     x0, [x0, #0xe20]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d3d334: bl      #0x2b70db0                                 fn_2b70db0
02d3d338: adrp    x0, #0x626a000                             
02d3d33c: ldr     x0, [x0, #0xe28]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d3d340: bl      #0x2b70db0                                 fn_2b70db0
02d3d344: adrp    x0, #0x626a000                             
02d3d348: ldr     x0, [x0, #0xe30]                           MS:System.Collections.Generic.List`1/Enumerator::get_Current
02d3d34c: bl      #0x2b70db0                                 fn_2b70db0
02d3d350: adrp    x0, #0x626a000                             
02d3d354: ldr     x0, [x0, #0xe38]                           MS:System.Collections.Generic.List`1::Clear
02d3d358: bl      #0x2b70db0                                 fn_2b70db0
02d3d35c: adrp    x0, #0x626a000                             
02d3d360: ldr     x0, [x0, #0xe40]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d3d364: bl      #0x2b70db0                                 fn_2b70db0
02d3d368: adrp    x0, #0x6263000                             
02d3d36c: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d3d370: bl      #0x2b70db0                                 fn_2b70db0
02d3d374: mov     w8, #1                                     
02d3d378: strb    w8, [x20, #0x172]                          
02d3d37c: ldr     x0, [x19, #0x28]                           ._spawnedBlindBox
02d3d380: stp     xzr, xzr, [sp, #0x20]                      
02d3d384: str     xzr, [sp, #0x30]                           
02d3d388: cbz     x0, #0x2d3d490                             
02d3d38c: adrp    x8, #0x626a000                             
02d3d390: adrp    x22, #0x626a000                            
02d3d394: adrp    x23, #0x6263000                            
02d3d398: ldr     x8, [x8, #0xe40]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d3d39c: adrp    x21, #0x626a000                            
02d3d3a0: ldr     x22, [x22, #0xe28]                         MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d3d3a4: ldr     x23, [x23, #0x918]                         T:UnityEngine.Object
02d3d3a8: ldr     x21, [x21, #0xe20]                         MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d3d3ac: ldr     x1, [x8]                                   T:type56879(k15)
02d3d3b0: add     x8, sp, #8                                 
02d3d3b4: bl      #0x35a9d9c                                 fn_35a9d9c
02d3d3b8: ldr     x8, [sp, #0x18]                            
02d3d3bc: ldur    q0, [sp, #8]                               
02d3d3c0: str     x8, [sp, #0x30]                            
02d3d3c4: add     x8, sp, #0x20                              
02d3d3c8: str     q0, [sp, #0x20]                            
02d3d3cc: stp     xzr, x8, [sp, #8]                          
02d3d3d0: ldr     x1, [x22]                                  T:type56879(k15)
02d3d3d4: add     x0, sp, #0x20                              
02d3d3d8: bl      #0x4690474                                 fn_4690474
02d3d3dc: tbz     w0, #0, #0x2d3d43c                         
02d3d3e0: ldr     x0, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d3d3e4: ldr     x20, [sp, #0x30]                           
02d3d3e8: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d3d3ec: cbnz    w8, #0x2d3d3f4                             
02d3d3f0: bl      #0x2b70f30                                 fn_2b70f30
02d3d3f4: mov     x0, x20                                    
02d3d3f8: mov     x1, xzr                                    
02d3d3fc: mov     x2, xzr                                    
02d3d400: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d3d404: tbz     w0, #0, #0x2d3d3d0                         
02d3d408: cbz     x20, #0x2d3d48c                            
02d3d40c: mov     x0, x20                                    
02d3d410: mov     x1, xzr                                    
02d3d414: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d3d418: mov     x20, x0                                    
02d3d41c: ldr     x0, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d3d420: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d3d424: cbnz    w8, #0x2d3d42c                             
02d3d428: bl      #0x2b70f30                                 fn_2b70f30
02d3d42c: mov     x0, x20                                    
02d3d430: mov     x1, xzr                                    
02d3d434: bl      #0x5b3ca38                                 UnityEngine.Object::Destroy
02d3d438: b       #0x2d3d3d0                                 
02d3d43c: ldr     x1, [x21]                                  T:type56879(k15)
02d3d440: add     x0, sp, #0x20                              
02d3d444: bl      #0x4690470                                 fn_4690470
02d3d448: ldr     x8, [x19, #0x28]                           ._spawnedBlindBox
02d3d44c: cbz     x8, #0x2d3d490                             
02d3d450: ldp     w2, w9, [x8, #0x18]                        
02d3d454: add     w9, w9, #1                                 
02d3d458: cmp     w2, #1                                     
02d3d45c: stp     wzr, w9, [x8, #0x18]                       
02d3d460: b.lt    #0x2d3d474                                 
02d3d464: ldr     x0, [x8, #0x10]                            T:Decor.DataDecor/CategoryData
02d3d468: mov     w1, wzr                                    
02d3d46c: mov     x3, xzr                                    
02d3d470: bl      #0x4e3494c                                 System.Array::Clear
02d3d474: str     wzr, [x19, #0xa0]                          ._currentBoxHold
02d3d478: ldp     x20, x19, [sp, #0x60]                      
02d3d47c: ldp     x22, x21, [sp, #0x50]                      
02d3d480: ldp     x30, x23, [sp, #0x40]                      
02d3d484: add     sp, sp, #0x70                              
02d3d488: ret                                                
02d3d48c: bl      #0x2b7105c                                 fn_2b7105c
02d3d490: bl      #0x2b7105c                                 fn_2b7105c
02d3d494: b       #0x2d3d4a4                                 
02d3d498: b       #0x2d3d4a4                                 
02d3d49c: b       #0x2d3d4a4                                 
02d3d4a0: b       #0x2d3d4a4                                 
02d3d4a4: mov     x20, x0                                    
02d3d4a8: cmp     w1, #1                                     
02d3d4ac: b.ne    #0x2d3d4e0                                 
02d3d4b0: mov     x0, x20                                    
02d3d4b4: bl      #0x5e90260                                 fn_5e90260
02d3d4b8: ldr     x20, [x0]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d3d4bc: str     x20, [sp, #8]                              
02d3d4c0: bl      #0x5e90270                                 fn_5e90270
02d3d4c4: ldr     x0, [sp, #0x10]                            
02d3d4c8: ldr     x1, [x21]                                  T:type56879(k15)
02d3d4cc: bl      #0x4690470                                 fn_4690470
02d3d4d0: cbz     x20, #0x2d3d448                            
02d3d4d4: mov     x0, x20                                    
02d3d4d8: bl      #0x2b71054                                 fn_2b71054
02d3d4dc: mov     x20, x0                                    
02d3d4e0: add     x0, sp, #8                                 
02d3d4e4: bl      #0x27385e4                                 fn_27385e4
02d3d4e8: mov     x0, x20                                    
02d3d4ec: bl      #0x2c6051c                                 fn_2c6051c
02d3d4f0: bl      #0x27369b8                                 fn_27369b8
## SetBlindBoxVisual(string skinName) -> void
---- ScoopGame.BlindBoxPlate::SetBlindBoxVisual 0x2d3d4f4
02d3d4f4: str     x30, [sp, #-0x20]!                         
02d3d4f8: stp     x20, x19, [sp, #0x10]                      
02d3d4fc: mov     x20, x0                                    
02d3d500: mov     x19, x1                                    
02d3d504: str     x1, [x20, #0xa8]!                          ._cachedSkinName
02d3d508: mov     x0, x20                                    
02d3d50c: bl      #0x2b70d54                                 fn_2b70d54
02d3d510: ldur    x0, [x20, #-0x88]                          
02d3d514: cbz     x0, #0x2d3d528                             
02d3d518: mov     x1, x19                                    
02d3d51c: ldp     x20, x19, [sp, #0x10]                      
02d3d520: ldr     x30, [sp], #0x20                           
02d3d524: b       #0x2d3c4f4                                 ScoopGame.BlindBox::SetVisual
02d3d528: bl      #0x2b7105c                                 fn_2b7105c
## SpawnBlindBox(int id, UnityEngine.Sprite charmSprite) -> void
---- ScoopGame.BlindBoxPlate::SpawnBlindBox 0x2d3d52c
02d3d52c: sub     sp, sp, #0x80                              
02d3d530: str     d14, [sp, #0x10]                           
02d3d534: stp     d13, d12, [sp, #0x18]                      
02d3d538: stp     d11, d10, [sp, #0x28]                      
02d3d53c: stp     d9, d8, [sp, #0x38]                        
02d3d540: str     x30, [sp, #0x48]                           
02d3d544: stp     x24, x23, [sp, #0x50]                      
02d3d548: stp     x22, x21, [sp, #0x60]                      
02d3d54c: stp     x20, x19, [sp, #0x70]                      
02d3d550: adrp    x22, #0x6630000                            
02d3d554: mov     x20, x2                                    
02d3d558: mov     w21, w1                                    
02d3d55c: ldrb    w8, [x22, #0x173]                          
02d3d560: mov     x19, x0                                    
02d3d564: tbnz    w8, #0, #0x2d3d5ac                         
02d3d568: adrp    x0, #0x626a000                             
02d3d56c: ldr     x0, [x0, #0xe48]                           MS:System.Collections.Generic.List`1::Add
02d3d570: bl      #0x2b70db0                                 fn_2b70db0
02d3d574: adrp    x0, #0x626a000                             
02d3d578: ldr     x0, [x0, #0xe00]                           MS:System.Collections.Generic.List`1::get_Count
02d3d57c: bl      #0x2b70db0                                 fn_2b70db0
02d3d580: adrp    x0, #0x626a000                             
02d3d584: ldr     x0, [x0, #0xe50]                           MS:UnityEngine.Object::Instantiate
02d3d588: bl      #0x2b70db0                                 fn_2b70db0
02d3d58c: adrp    x0, #0x6263000                             
02d3d590: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d3d594: bl      #0x2b70db0                                 fn_2b70db0
02d3d598: adrp    x0, #0x626a000                             
02d3d59c: ldr     x0, [x0, #0xe58]                           S:'BlindBox_{0}'
02d3d5a0: bl      #0x2b70db0                                 fn_2b70db0
02d3d5a4: mov     w8, #1                                     
02d3d5a8: strb    w8, [x22, #0x173]                          
02d3d5ac: ldr     x0, [x19, #0x50]                           ._tfBottomLeft
02d3d5b0: cbz     x0, #0x2d3d834                             
02d3d5b4: mov     x1, xzr                                    
02d3d5b8: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d3d5bc: ldr     x0, [x19, #0x48]                           ._tfTopRight
02d3d5c0: cbz     x0, #0x2d3d834                             
02d3d5c4: mov     x1, xzr                                    
02d3d5c8: fmov    s8, s0                                     
02d3d5cc: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d3d5d0: fmov    s1, s0                                     
02d3d5d4: fmov    s0, s8                                     
02d3d5d8: mov     x0, xzr                                    
02d3d5dc: bl      #0x5b2dfc0                                 UnityEngine.Random::Range
02d3d5e0: ldr     x0, [x19, #0x50]                           ._tfBottomLeft
02d3d5e4: cbz     x0, #0x2d3d834                             
02d3d5e8: mov     x1, xzr                                    
02d3d5ec: fmov    s8, s0                                     
02d3d5f0: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d3d5f4: ldr     x0, [x19, #0x48]                           ._tfTopRight
02d3d5f8: cbz     x0, #0x2d3d834                             
02d3d5fc: mov     x1, xzr                                    
02d3d600: fmov    s9, s1                                     
02d3d604: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d3d608: fmov    s0, s9                                     
02d3d60c: mov     x0, xzr                                    
02d3d610: bl      #0x5b2dfc0                                 UnityEngine.Random::Range
02d3d614: ldr     x8, [x19, #0x28]                           ._spawnedBlindBox
02d3d618: cbz     x8, #0x2d3d834                             
02d3d61c: fmov    s9, s0                                     
02d3d620: ldr     s0, [x8, #0x18]                            
02d3d624: adrp    x8, #0x1084000                             
02d3d628: ldr     s1, [x8, #0xeec]                           [1084eec]=457ff0003dcccccd f=0.1,4095
02d3d62c: mov     w8, #0x43b40000                            
02d3d630: adrp    x23, #0x6263000                            
02d3d634: scvtf   s0, s0                                     
02d3d638: adrp    x24, #0x626a000                            
02d3d63c: ldr     x23, [x23, #0x918]                         T:UnityEngine.Object
02d3d640: ldr     x24, [x24, #0xe50]                         MS:UnityEngine.Object::Instantiate
02d3d644: mov     x0, xzr                                    
02d3d648: fmul    s10, s0, s1                                
02d3d64c: movi    d0, #0000000000000000                      
02d3d650: fmov    s1, w8                                     
02d3d654: bl      #0x5b2dfc0                                 UnityEngine.Random::Range
02d3d658: adrp    x8, #0x1085000                             
02d3d65c: ldr     x22, [x19, #0x20]                          ._blindBoxItem
02d3d660: mov     x0, sp                                     
02d3d664: ldr     s1, [x8, #0x10]                            [1085010]=4202c6f23c8efa35 f=0.0174533,32.6943
02d3d668: mov     x1, xzr                                    
02d3d66c: str     xzr, [sp]                                  
02d3d670: fmul    s0, s0, s1                                 
02d3d674: str     s0, [sp, #8]                               
02d3d678: bl      #0x5b2607c                                 UnityEngine.Quaternion::Internal_FromEulerRad
02d3d67c: fmov    s11, s0                                    
02d3d680: fmov    s12, s1                                    
02d3d684: ldr     x0, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d3d688: fmov    s13, s2                                    
02d3d68c: fmov    s14, s3                                    
02d3d690: ldr     x23, [x19, #0x30]                          ._tfHolder
02d3d694: ldr     w8, [x0, #0xe4]                            [626a0e4]=0 f=0,0
02d3d698: cbnz    w8, #0x2d3d6a0                             
02d3d69c: bl      #0x2b70f30                                 fn_2b70f30
02d3d6a0: fmov    s0, s8                                     
02d3d6a4: fmov    s1, s9                                     
02d3d6a8: ldr     x2, [x24]                                  T:type56879(k15)
02d3d6ac: fmov    s2, s10                                    
02d3d6b0: fmov    s3, s11                                    
02d3d6b4: mov     x0, x22                                    
02d3d6b8: fmov    s4, s12                                    
02d3d6bc: fmov    s5, s13                                    
02d3d6c0: mov     x1, x23                                    
02d3d6c4: fmov    s6, s14                                    
02d3d6c8: bl      #0x3276204                                 fn_3276204
02d3d6cc: cbz     x0, #0x2d3d834                             
02d3d6d0: ldr     x1, [x19, #0xa8]                           ._cachedSkinName
02d3d6d4: mov     x22, x0                                    
02d3d6d8: bl      #0x2d3c4f4                                 ScoopGame.BlindBox::SetVisual
02d3d6dc: mov     x0, x22                                    
02d3d6e0: mov     w1, w21                                    
02d3d6e4: mov     x2, x20                                    
02d3d6e8: bl      #0x2d3c648                                 ScoopGame.BlindBox::SetCharm
02d3d6ec: mov     x0, x22                                    
02d3d6f0: bl      #0x2d3c304                                 ScoopGame.BlindBox::DisableBagClick
02d3d6f4: ldr     x20, [x19, #0x40]                          ._tfPlateResult
02d3d6f8: mov     x0, x19                                    
02d3d6fc: bl      #0x2d3d838                                 ScoopGame.BlindBoxPlate::GetRandomPositionBetweenPlate
02d3d700: mov     x0, x22                                    
02d3d704: mov     x1, x20                                    
02d3d708: fmov    s8, s0                                     
02d3d70c: fmov    s9, s1                                     
02d3d710: fmov    s10, s2                                    
02d3d714: str     x20, [x0, #0x70]!                          ._tfBottomLeftPlate
02d3d718: bl      #0x2b70d54                                 fn_2b70d54
02d3d71c: mov     x0, x22                                    
02d3d720: mov     x1, x19                                    
02d3d724: stp     s8, s9, [x22, #0x64]                       
02d3d728: str     s10, [x22, #0x6c]                          
02d3d72c: str     x19, [x0, #0x78]!                          ._collider
02d3d730: bl      #0x2b70d54                                 fn_2b70d54
02d3d734: mov     x0, x22                                    
02d3d738: mov     x1, xzr                                    
02d3d73c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d3d740: cbz     x0, #0x2d3d834                             
02d3d744: adrp    x20, #0x626a000                            
02d3d748: mov     x1, xzr                                    
02d3d74c: ldr     x20, [x20, #0xe58]                         S:'BlindBox_{0}'
02d3d750: bl      #0x5b485a4                                 UnityEngine.Transform::GetSiblingIndex
02d3d754: adrp    x8, #0x6263000                             
02d3d758: mov     x1, sp                                     
02d3d75c: ldr     x8, [x8, #0x970]                           &6645c70(=0)
02d3d760: str     w0, [sp]                                   
02d3d764: ldr     x8, [x8, #0x48]                            &6263098(=0)
02d3d768: mov     x0, x8                                     
02d3d76c: bl      #0x2b70f38                                 fn_2b70f38
02d3d770: ldr     x8, [x20]                                  T:type56879(k15)
02d3d774: mov     x1, x0                                     
02d3d778: mov     x2, xzr                                    
02d3d77c: mov     x0, x8                                     
02d3d780: bl      #0x4c9d0ec                                 System.String::Format
02d3d784: mov     x1, x0                                     
02d3d788: mov     x0, x22                                    
02d3d78c: mov     x2, xzr                                    
02d3d790: bl      #0x5b3bcf8                                 UnityEngine.Object::set_name
02d3d794: ldr     x0, [x19, #0x28]                           ._spawnedBlindBox
02d3d798: cbz     x0, #0x2d3d834                             
02d3d79c: adrp    x9, #0x626a000                             
02d3d7a0: ldr     x9, [x9, #0xe48]                           MS:System.Collections.Generic.List`1::Add
02d3d7a4: ldr     w10, [x0, #0x1c]                           [626a01c]=0 f=0,0
02d3d7a8: ldr     x8, [x0, #0x10]                            T:Decor.DataDecor/CategoryData
02d3d7ac: ldr     x9, [x9]                                   T:type56879(k15)
02d3d7b0: add     w10, w10, #1                               
02d3d7b4: str     w10, [x0, #0x1c]                           
02d3d7b8: cbz     x8, #0x2d3d834                             
02d3d7bc: ldrsw   x10, [x0, #0x18]                           
02d3d7c0: ldr     w11, [x8, #0x18]                           &2c5d934(=d65f03c0d503245f)
02d3d7c4: cmp     w10, w11                                   
02d3d7c8: b.hs    #0x2d3d7ec                                 
02d3d7cc: add     x8, x8, x10, lsl #3                        &6263000
02d3d7d0: add     w9, w10, #1                                
02d3d7d4: mov     x1, x22                                    
02d3d7d8: str     w9, [x0, #0x18]                            
02d3d7dc: str     x22, [x8, #0x20]!                          
02d3d7e0: mov     x0, x8                                     
02d3d7e4: bl      #0x2b70d54                                 fn_2b70d54
02d3d7e8: b       #0x2d3d800                                 
02d3d7ec: ldr     x8, [x9, #0x20]                            M:Decor.DataDecor/<>c__DisplayClass8_0::<NewData>b__0
02d3d7f0: mov     x1, x22                                    
02d3d7f4: ldr     x8, [x8, #0xc0]                            &2c5bebc(=f9400800d503245f)
02d3d7f8: ldr     x2, [x8, #0x70]                            &2c5bd48(=a9bd7bfdd503233f)
02d3d7fc: bl      #0x35a920c                                 fn_35a920c
02d3d800: ldr     w8, [x19, #0xa0]                           ._currentBoxHold
02d3d804: ldp     x22, x21, [sp, #0x60]                      
02d3d808: ldp     x24, x23, [sp, #0x50]                      
02d3d80c: ldr     x30, [sp, #0x48]                           
02d3d810: add     w8, w8, #1                                 
02d3d814: ldr     d14, [sp, #0x10]                           
02d3d818: str     w8, [x19, #0xa0]                           ._currentBoxHold
02d3d81c: ldp     x20, x19, [sp, #0x70]                      
02d3d820: ldp     d9, d8, [sp, #0x38]                        
02d3d824: ldp     d11, d10, [sp, #0x28]                      
02d3d828: ldp     d13, d12, [sp, #0x18]                      
02d3d82c: add     sp, sp, #0x80                              
02d3d830: ret                                                
02d3d834: bl      #0x2b7105c                                 fn_2b7105c
## PopOutBlindBox() -> void
---- ScoopGame.BlindBoxPlate::PopOutBlindBox 0x2d3d908
02d3d908: str     x30, [sp, #-0x30]!                         
02d3d90c: stp     x22, x21, [sp, #0x10]                      
02d3d910: stp     x20, x19, [sp, #0x20]                      
02d3d914: adrp    x21, #0x6630000                            
02d3d918: adrp    x22, #0x6264000                            
02d3d91c: adrp    x20, #0x626a000                            
02d3d920: ldrb    w8, [x21, #0x174]                          
02d3d924: ldr     x22, [x22, #0xe8]                          T:DG.Tweening.TweenCallback
02d3d928: ldr     x20, [x20, #0xe60]                         M:ScoopGame.BlindBoxPlate::<PopOutBlindBox>b__28_0
02d3d92c: mov     x19, x0                                    
02d3d930: tbnz    w8, #0, #0x2d3d954                         
02d3d934: adrp    x0, #0x626a000                             
02d3d938: ldr     x0, [x0, #0xe60]                           M:ScoopGame.BlindBoxPlate::<PopOutBlindBox>b__28_0
02d3d93c: bl      #0x2b70db0                                 fn_2b70db0
02d3d940: adrp    x0, #0x6264000                             
02d3d944: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d3d948: bl      #0x2b70db0                                 fn_2b70db0
02d3d94c: mov     w8, #1                                     
02d3d950: strb    w8, [x21, #0x174]                          
02d3d954: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d3d958: bl      #0x2b7104c                                 fn_2b7104c
02d3d95c: ldr     x2, [x20]                                  T:type56879(k15)
02d3d960: mov     x1, x19                                    
02d3d964: mov     x3, xzr                                    
02d3d968: mov     x20, x0                                    
02d3d96c: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d3d970: adrp    x8, #0x1084000                             
02d3d974: mov     x0, x20                                    
02d3d978: mov     w1, #1                                     
02d3d97c: ldp     x20, x19, [sp, #0x20]                      
02d3d980: ldr     s0, [x8, #0xeec]                           [1084eec]=457ff0003dcccccd f=0.1,4095
02d3d984: ldp     x22, x21, [sp, #0x10]                      
02d3d988: mov     x2, xzr                                    
02d3d98c: ldr     x30, [sp], #0x30                           
02d3d990: b       #0x2d8f37c                                 DG.Tweening.DOVirtual::DelayedCall
## OnPointerDown(UnityEngine.EventSystems.PointerEventData eventData) -> void
---- ScoopGame.BlindBoxPlate::OnPointerDown 0x2d3d994
02d3d994: stp     x30, x21, [sp, #-0x20]!                    
02d3d998: stp     x20, x19, [sp, #0x10]                      
02d3d99c: adrp    x20, #0x6630000                            
02d3d9a0: adrp    x21, #0x6266000                            
02d3d9a4: mov     x19, x0                                    
02d3d9a8: ldrb    w8, [x20, #0x175]                          
02d3d9ac: ldr     x21, [x21, #0x948]                         T:Touch
02d3d9b0: tbnz    w8, #0, #0x2d3d9c8                         
02d3d9b4: adrp    x0, #0x6266000                             
02d3d9b8: ldr     x0, [x0, #0x948]                           T:Touch
02d3d9bc: bl      #0x2b70db0                                 fn_2b70db0
02d3d9c0: mov     w8, #1                                     
02d3d9c4: strb    w8, [x20, #0x175]                          
02d3d9c8: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d3d9cc: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d3d9d0: cbnz    w8, #0x2d3d9d8                             
02d3d9d4: bl      #0x2b70f30                                 fn_2b70f30
02d3d9d8: mov     x0, xzr                                    
02d3d9dc: bl      #0x2cd6230                                 Touch::IsPointerOverUIObject
02d3d9e0: tbz     w0, #0, #0x2d3d9f0                         
02d3d9e4: ldp     x20, x19, [sp, #0x10]                      
02d3d9e8: ldp     x30, x21, [sp], #0x20                      
02d3d9ec: ret                                                
02d3d9f0: mov     x0, x19                                    
02d3d9f4: ldp     x20, x19, [sp, #0x10]                      
02d3d9f8: ldp     x30, x21, [sp], #0x20                      
02d3d9fc: b       #0x2d3da00                                 ScoopGame.BlindBoxPlate::CheckPopOutBlindBox
## CheckPopOutBlindBox() -> void
---- ScoopGame.BlindBoxPlate::CheckPopOutBlindBox 0x2d3da00
02d3da00: sub     sp, sp, #0x80                              
02d3da04: stp     d11, d10, [sp, #0x10]                      
02d3da08: stp     d9, d8, [sp, #0x20]                        
02d3da0c: stp     x30, x27, [sp, #0x30]                      
02d3da10: stp     x26, x25, [sp, #0x40]                      
02d3da14: stp     x24, x23, [sp, #0x50]                      
02d3da18: stp     x22, x21, [sp, #0x60]                      
02d3da1c: stp     x20, x19, [sp, #0x70]                      
02d3da20: adrp    x20, #0x6630000                            
02d3da24: adrp    x21, #0x626a000                            
02d3da28: mov     x19, x0                                    
02d3da2c: ldrb    w8, [x20, #0x176]                          
02d3da30: ldr     x21, [x21, #0xe68]                         T:ScoopGame.BlindBoxPlate/<>c__DisplayClass30_0
02d3da34: tbnz    w8, #0, #0x2d3dad0                         
02d3da38: adrp    x0, #0x6263000                             
02d3da3c: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02d3da40: bl      #0x2b70db0                                 fn_2b70db0
02d3da44: adrp    x0, #0x626a000                             
02d3da48: ldr     x0, [x0, #0xe70]                           MS:System.Collections.Generic.List`1::get_Item
02d3da4c: bl      #0x2b70db0                                 fn_2b70db0
02d3da50: adrp    x0, #0x6264000                             
02d3da54: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d3da58: bl      #0x2b70db0                                 fn_2b70db0
02d3da5c: adrp    x0, #0x6266000                             
02d3da60: ldr     x0, [x0, #0xa88]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d3da64: bl      #0x2b70db0                                 fn_2b70db0
02d3da68: adrp    x0, #0x6266000                             
02d3da6c: ldr     x0, [x0, #0xa90]                           MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02d3da70: bl      #0x2b70db0                                 fn_2b70db0
02d3da74: adrp    x0, #0x6266000                             
02d3da78: ldr     x0, [x0, #0xe08]                           MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02d3da7c: bl      #0x2b70db0                                 fn_2b70db0
02d3da80: adrp    x0, #0x6266000                             
02d3da84: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d3da88: bl      #0x2b70db0                                 fn_2b70db0
02d3da8c: adrp    x0, #0x6268000                             
02d3da90: ldr     x0, [x0, #0x10]                            MS:DG.Tweening.TweenSettingsExtensions::SetLoops
02d3da94: bl      #0x2b70db0                                 fn_2b70db0
02d3da98: adrp    x0, #0x626a000                             
02d3da9c: ldr     x0, [x0, #0xe78]                           M:ScoopGame.BlindBoxPlate/<>c__DisplayClass30_0::<CheckPopOutBlindBox>b__0
02d3daa0: bl      #0x2b70db0                                 fn_2b70db0
02d3daa4: adrp    x0, #0x626a000                             
02d3daa8: ldr     x0, [x0, #0xe68]                           T:ScoopGame.BlindBoxPlate/<>c__DisplayClass30_0
02d3daac: bl      #0x2b70db0                                 fn_2b70db0
02d3dab0: adrp    x0, #0x6267000                             
02d3dab4: ldr     x0, [x0, #0xea8]                           T:Framework.Vibration
02d3dab8: bl      #0x2b70db0                                 fn_2b70db0
02d3dabc: adrp    x0, #0x626a000                             
02d3dac0: ldr     x0, [x0, #0xc28]                           S:'curent box hold is {0}'
02d3dac4: bl      #0x2b70db0                                 fn_2b70db0
02d3dac8: mov     w8, #1                                     
02d3dacc: strb    w8, [x20, #0x176]                          
02d3dad0: ldr     x0, [x21]                                  T:type56879(k15)
02d3dad4: bl      #0x2b7104c                                 fn_2b7104c
02d3dad8: mov     x1, xzr                                    
02d3dadc: mov     x20, x0                                    
02d3dae0: bl      #0x4e53e9c                                 System.Object::.ctor
02d3dae4: cbz     x20, #0x2d3de8c                            
02d3dae8: mov     x0, x20                                    
02d3daec: mov     x1, x19                                    
02d3daf0: str     x19, [x0, #0x10]!                          
02d3daf4: bl      #0x2b70d54                                 fn_2b70d54
02d3daf8: ldr     w8, [x19, #0xa0]                           ._currentBoxHold
02d3dafc: cmp     w8, #1                                     
02d3db00: b.lt    #0x2d3de68                                 
02d3db04: mov     x0, xzr                                    
02d3db08: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d3db0c: cbz     x0, #0x2d3de8c                             
02d3db10: movi    d1, #0000000000000000                      
02d3db14: movi    d2, #0000000000000000                      
02d3db18: adrp    x21, #0x6267000                            
02d3db1c: fmov    s0, #1.00000000                            
02d3db20: ldr     x21, [x21, #0xea8]                         T:Framework.Vibration
02d3db24: mov     w1, #0x10                                  
02d3db28: mov     w2, wzr                                    
02d3db2c: mov     w3, wzr                                    
02d3db30: mov     x4, xzr                                    
02d3db34: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d3db38: ldr     x0, [x21]                                  S:'didu'
02d3db3c: ldr     w8, [x0, #0xe4]                            [626a0e4]=0 f=0,0
02d3db40: cbnz    w8, #0x2d3db48                             
02d3db44: bl      #0x2b70f30                                 fn_2b70f30
02d3db48: mov     w0, #0x3c                                  
02d3db4c: mov     w1, #-1                                    
02d3db50: mov     w2, wzr                                    
02d3db54: mov     x3, xzr                                    
02d3db58: bl      #0x2d6e144                                 Framework.Vibration::Vibrate
02d3db5c: ldr     x0, [x19, #0x60]                           ._tfBottomLeftOpen
02d3db60: cbz     x0, #0x2d3de8c                             
02d3db64: mov     x1, xzr                                    
02d3db68: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d3db6c: ldr     x0, [x19, #0x58]                           ._tfTopRightOpen
02d3db70: cbz     x0, #0x2d3de8c                             
02d3db74: mov     x1, xzr                                    
02d3db78: fmov    s8, s0                                     
02d3db7c: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d3db80: fmov    s1, s0                                     
02d3db84: fmov    s0, s8                                     
02d3db88: mov     x0, xzr                                    
02d3db8c: bl      #0x5b2dfc0                                 UnityEngine.Random::Range
02d3db90: ldr     x0, [x19, #0x60]                           ._tfBottomLeftOpen
02d3db94: cbz     x0, #0x2d3de8c                             
02d3db98: mov     x1, xzr                                    
02d3db9c: fmov    s8, s0                                     
02d3dba0: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d3dba4: ldr     x0, [x19, #0x58]                           ._tfTopRightOpen
02d3dba8: cbz     x0, #0x2d3de8c                             
02d3dbac: mov     x1, xzr                                    
02d3dbb0: fmov    s9, s1                                     
02d3dbb4: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d3dbb8: fmov    s0, s9                                     
02d3dbbc: mov     x0, xzr                                    
02d3dbc0: bl      #0x5b2dfc0                                 UnityEngine.Random::Range
02d3dbc4: ldr     x0, [x19, #0x38]                           ._tfPlate
02d3dbc8: cbz     x0, #0x2d3de8c                             
02d3dbcc: mov     x1, xzr                                    
02d3dbd0: fmov    s9, s0                                     
02d3dbd4: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d3dbd8: mov     w1, wzr                                    
02d3dbdc: mov     x2, xzr                                    
02d3dbe0: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d3dbe4: ldr     x0, [x19, #0x38]                           ._tfPlate
02d3dbe8: cbz     x0, #0x2d3de8c                             
02d3dbec: mov     x1, xzr                                    
02d3dbf0: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d3dbf4: adrp    x22, #0x662f000                            
02d3dbf8: mov     x21, x0                                    
02d3dbfc: ldrb    w8, [x22, #0xa74]                          
02d3dc00: cbnz    w8, #0x2d3dc18                             
02d3dc04: adrp    x0, #0x6264000                             
02d3dc08: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d3dc0c: bl      #0x2b70db0                                 fn_2b70db0
02d3dc10: mov     w8, #1                                     
02d3dc14: strb    w8, [x22, #0xa74]                          
02d3dc18: cbz     x21, #0x2d3de8c                            
02d3dc1c: adrp    x8, #0x6264000                             
02d3dc20: mov     x0, x21                                    
02d3dc24: mov     x1, xzr                                    
02d3dc28: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02d3dc2c: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d3dc30: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d3dc34: ldp     s1, s2, [x8, #0x10]                        
02d3dc38: ldr     s0, [x8, #0xc]                             [626400c]=0 f=0,0
02d3dc3c: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d3dc40: ldr     x0, [x19, #0x38]                           ._tfPlate
02d3dc44: cbz     x0, #0x2d3de8c                             
02d3dc48: adrp    x21, #0x6268000                            
02d3dc4c: mov     x1, xzr                                    
02d3dc50: ldr     x21, [x21, #0x10]                          MS:DG.Tweening.TweenSettingsExtensions::SetLoops
02d3dc54: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d3dc58: adrp    x8, #0x1084000                             
02d3dc5c: adrp    x9, #0x1084000                             
02d3dc60: mov     x1, xzr                                    
02d3dc64: ldr     s11, [x8, #0xcfc]                          [1084cfc]=3e58658c3f8ccccd f=1.1,0.211325
02d3dc68: ldr     s10, [x9, #0xdfc]                          [1084dfc]=3f2666663d4ccccd f=0.05,0.65
02d3dc6c: fmov    s0, s11                                    
02d3dc70: fmov    s1, s10                                    
02d3dc74: bl      #0x2d98e28                                 DG.Tweening.ShortcutExtensions::DOScaleX
02d3dc78: ldr     x3, [x21]                                  S:'{0}/2'
02d3dc7c: mov     w1, #2                                     
02d3dc80: mov     w2, #1                                     
02d3dc84: bl      #0x336fe74                                 fn_336fe74
02d3dc88: ldr     x0, [x19, #0x38]                           ._tfPlate
02d3dc8c: cbz     x0, #0x2d3de8c                             
02d3dc90: adrp    x22, #0x6266000                            
02d3dc94: mov     x1, xzr                                    
02d3dc98: ldr     x22, [x22, #0xe08]                         MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02d3dc9c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d3dca0: fmov    s0, s11                                    
02d3dca4: fmov    s1, s10                                    
02d3dca8: mov     x1, xzr                                    
02d3dcac: bl      #0x2d98fd4                                 DG.Tweening.ShortcutExtensions::DOScaleY
02d3dcb0: ldr     x3, [x21]                                  S:'{0}/2'
02d3dcb4: mov     w1, #2                                     
02d3dcb8: mov     w2, #1                                     
02d3dcbc: bl      #0x336fe74                                 fn_336fe74
02d3dcc0: fmov    s0, s10                                    
02d3dcc4: ldr     x1, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d3dcc8: bl      #0x336f7fc                                 fn_336f7fc
02d3dccc: ldr     w8, [x19, #0xa0]                           ._currentBoxHold
02d3dcd0: ldr     x0, [x19, #0x28]                           ._spawnedBlindBox
02d3dcd4: sub     w1, w8, #1                                 
02d3dcd8: str     w1, [x20, #0x18]                           
02d3dcdc: cbz     x0, #0x2d3de8c                             
02d3dce0: adrp    x22, #0x626a000                            
02d3dce4: ldr     x22, [x22, #0xe70]                         MS:System.Collections.Generic.List`1::get_Item
02d3dce8: ldr     x2, [x22]                                  T:type56879(k15)
02d3dcec: bl      #0x35a8f3c                                 fn_35a8f3c
02d3dcf0: cbz     x0, #0x2d3de8c                             
02d3dcf4: mov     x1, xzr                                    
02d3dcf8: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d3dcfc: ldr     x8, [x19, #0x28]                           ._spawnedBlindBox
02d3dd00: cbz     x8, #0x2d3de8c                             
02d3dd04: ldr     w1, [x20, #0x18]                           
02d3dd08: ldr     x2, [x22]                                  T:type56879(k15)
02d3dd0c: mov     x21, x0                                    
02d3dd10: mov     x0, x8                                     
02d3dd14: bl      #0x35a8f3c                                 fn_35a8f3c
02d3dd18: cbz     x0, #0x2d3de8c                             
02d3dd1c: mov     x1, xzr                                    
02d3dd20: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d3dd24: cbz     x0, #0x2d3de8c                             
02d3dd28: adrp    x22, #0x6266000                            
02d3dd2c: adrp    x25, #0x6264000                            
02d3dd30: adrp    x26, #0x626a000                            
02d3dd34: adrp    x27, #0x6266000                            
02d3dd38: adrp    x24, #0x626a000                            
02d3dd3c: adrp    x23, #0x6263000                            
02d3dd40: ldr     x22, [x22, #0xa90]                         MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02d3dd44: ldr     x25, [x25, #0xe8]                          T:DG.Tweening.TweenCallback
02d3dd48: ldr     x26, [x26, #0xe78]                         M:ScoopGame.BlindBoxPlate/<>c__DisplayClass30_0::<CheckPopOutBlindBox>b__0
02d3dd4c: ldr     x27, [x27, #0xa88]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d3dd50: ldr     x24, [x24, #0xc28]                         S:'curent box hold is {0}'
02d3dd54: ldr     x23, [x23, #0x928]                         T:UnityEngine.Debug
02d3dd58: mov     x1, xzr                                    
02d3dd5c: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d3dd60: fmov    s0, s8                                     
02d3dd64: fmov    s1, s9                                     
02d3dd68: mov     x0, x21                                    
02d3dd6c: fmov    s3, #3.00000000                            
02d3dd70: fmov    s4, #0.50000000                            
02d3dd74: mov     w1, #1                                     
02d3dd78: mov     w2, wzr                                    
02d3dd7c: mov     x3, xzr                                    
02d3dd80: bl      #0x2d9abb0                                 DG.Tweening.ShortcutExtensions::DOJump
02d3dd84: adrp    x8, #0x1084000                             
02d3dd88: ldr     x1, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d3dd8c: ldr     s0, [x8, #0xda4]                           [1084da4]=3eb851ec3e19999a f=0.15,0.36
02d3dd90: bl      #0x336f7fc                                 fn_336f7fc
02d3dd94: ldr     x8, [x25]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d3dd98: mov     x21, x0                                    
02d3dd9c: mov     x0, x8                                     
02d3dda0: bl      #0x2b7104c                                 fn_2b7104c
02d3dda4: ldr     x2, [x26]                                  T:type56879(k15)
02d3dda8: mov     x1, x20                                    
02d3ddac: mov     x3, xzr                                    
02d3ddb0: mov     x22, x0                                    
02d3ddb4: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d3ddb8: ldr     x2, [x27]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d3ddbc: mov     x0, x21                                    
02d3ddc0: mov     x1, x22                                    
02d3ddc4: bl      #0x336f26c                                 fn_336f26c
02d3ddc8: adrp    x9, #0x6263000                             
02d3ddcc: ldr     w8, [x19, #0xa0]                           ._currentBoxHold
02d3ddd0: add     x1, sp, #0xc                               
02d3ddd4: ldr     x9, [x9, #0x970]                           &6645c70(=0)
02d3ddd8: sub     w8, w8, #1                                 
02d3dddc: ldr     x0, [x9, #0x48]                            &6263098(=0)
02d3dde0: str     w8, [x19, #0xa0]                           ._currentBoxHold
02d3dde4: str     w8, [sp, #0xc]                             
02d3dde8: bl      #0x2b70f38                                 fn_2b70f38
02d3ddec: ldr     x8, [x24]                                  T:type56879(k15)
02d3ddf0: mov     x1, x0                                     
02d3ddf4: mov     x2, xzr                                    
02d3ddf8: mov     x0, x8                                     
02d3ddfc: bl      #0x4c9d0ec                                 System.String::Format
02d3de00: ldr     x8, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d3de04: mov     x20, x0                                    
02d3de08: ldr     w9, [x8, #0xe4]                            [10840e4]=2c2644327265746c f=4.54482e+30,2.36279e-12
02d3de0c: cbnz    w9, #0x2d3de18                             
02d3de10: mov     x0, x8                                     
02d3de14: bl      #0x2b70f30                                 fn_2b70f30
02d3de18: mov     x0, x20                                    
02d3de1c: mov     x1, xzr                                    
02d3de20: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02d3de24: ldr     w8, [x19, #0xa0]                           ._currentBoxHold
02d3de28: cbnz    w8, #0x2d3de68                             
02d3de2c: ldr     x0, [x19, #0x78]                           ._collider
02d3de30: cbz     x0, #0x2d3de8c                             
02d3de34: mov     w1, wzr                                    
02d3de38: mov     x2, xzr                                    
02d3de3c: bl      #0x5b33110                                 UnityEngine.Behaviour::set_enabled
02d3de40: movi    d0, #0000000000000000                      
02d3de44: fmov    s1, #0.50000000                            
02d3de48: ldr     x0, [x19, #0x38]                           ._tfPlate
02d3de4c: mov     x1, xzr                                    
02d3de50: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d3de54: adrp    x8, #0x6266000                             
02d3de58: mov     w1, #0x1a                                  
02d3de5c: ldr     x8, [x8, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d3de60: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d3de64: bl      #0x336fa0c                                 fn_336fa0c
02d3de68: ldp     x20, x19, [sp, #0x70]                      
02d3de6c: ldp     x22, x21, [sp, #0x60]                      
02d3de70: ldp     x24, x23, [sp, #0x50]                      
02d3de74: ldp     x26, x25, [sp, #0x40]                      
02d3de78: ldp     x30, x27, [sp, #0x30]                      
02d3de7c: ldp     d9, d8, [sp, #0x20]                        
02d3de80: ldp     d11, d10, [sp, #0x10]                      
02d3de84: add     sp, sp, #0x80                              
02d3de88: ret                                                
02d3de8c: bl      #0x2b7105c                                 fn_2b7105c
## AddMoreRandomBox(int id, UnityEngine.Sprite sprite) -> void
---- ScoopGame.BlindBoxPlate::AddMoreRandomBox 0x2d3de98
02d3de98: sub     sp, sp, #0xa0                              
02d3de9c: stp     d15, d14, [sp, #0x10]                      
02d3dea0: stp     d13, d12, [sp, #0x20]                      
02d3dea4: stp     d11, d10, [sp, #0x30]                      
02d3dea8: stp     d9, d8, [sp, #0x40]                        
02d3deac: str     x30, [sp, #0x50]                           
02d3deb0: stp     x26, x25, [sp, #0x60]                      
02d3deb4: stp     x24, x23, [sp, #0x70]                      
02d3deb8: stp     x22, x21, [sp, #0x80]                      
02d3debc: stp     x20, x19, [sp, #0x90]                      
02d3dec0: adrp    x19, #0x6630000                            
02d3dec4: adrp    x23, #0x626a000                            
02d3dec8: mov     x21, x2                                    
02d3decc: ldrb    w8, [x19, #0x177]                          
02d3ded0: ldr     x23, [x23, #0xe80]                         T:ScoopGame.BlindBoxPlate/<>c__DisplayClass31_0
02d3ded4: mov     w22, w1                                    
02d3ded8: mov     x20, x0                                    
02d3dedc: tbnz    w8, #0, #0x2d3df54                         
02d3dee0: adrp    x0, #0x626a000                             
02d3dee4: ldr     x0, [x0, #0xe48]                           MS:System.Collections.Generic.List`1::Add
02d3dee8: bl      #0x2b70db0                                 fn_2b70db0
02d3deec: adrp    x0, #0x626a000                             
02d3def0: ldr     x0, [x0, #0xe00]                           MS:System.Collections.Generic.List`1::get_Count
02d3def4: bl      #0x2b70db0                                 fn_2b70db0
02d3def8: adrp    x0, #0x626a000                             
02d3defc: ldr     x0, [x0, #0xe50]                           MS:UnityEngine.Object::Instantiate
02d3df00: bl      #0x2b70db0                                 fn_2b70db0
02d3df04: adrp    x0, #0x6263000                             
02d3df08: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d3df0c: bl      #0x2b70db0                                 fn_2b70db0
02d3df10: adrp    x0, #0x6264000                             
02d3df14: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d3df18: bl      #0x2b70db0                                 fn_2b70db0
02d3df1c: adrp    x0, #0x6266000                             
02d3df20: ldr     x0, [x0, #0xa88]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d3df24: bl      #0x2b70db0                                 fn_2b70db0
02d3df28: adrp    x0, #0x626a000                             
02d3df2c: ldr     x0, [x0, #0xe88]                           M:ScoopGame.BlindBoxPlate/<>c__DisplayClass31_0::<AddMoreRandomBox>b__0
02d3df30: bl      #0x2b70db0                                 fn_2b70db0
02d3df34: adrp    x0, #0x626a000                             
02d3df38: ldr     x0, [x0, #0xe80]                           T:ScoopGame.BlindBoxPlate/<>c__DisplayClass31_0
02d3df3c: bl      #0x2b70db0                                 fn_2b70db0
02d3df40: adrp    x0, #0x626a000                             
02d3df44: ldr     x0, [x0, #0xe58]                           S:'BlindBox_{0}'
02d3df48: bl      #0x2b70db0                                 fn_2b70db0
02d3df4c: mov     w8, #1                                     
02d3df50: strb    w8, [x19, #0x177]                          
02d3df54: ldr     x0, [x23]                                  T:type56879(k15)
02d3df58: bl      #0x2b7104c                                 fn_2b7104c
02d3df5c: mov     x1, xzr                                    
02d3df60: mov     x19, x0                                    
02d3df64: bl      #0x4e53e9c                                 System.Object::.ctor
02d3df68: ldr     x0, [x20, #0x60]                           ._tfBottomLeftOpen
02d3df6c: cbz     x0, #0x2d3e2c4                             
02d3df70: mov     x1, xzr                                    
02d3df74: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d3df78: ldr     x0, [x20, #0x58]                           ._tfTopRightOpen
02d3df7c: cbz     x0, #0x2d3e2c4                             
02d3df80: mov     x1, xzr                                    
02d3df84: fmov    s8, s0                                     
02d3df88: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d3df8c: fmov    s1, s0                                     
02d3df90: fmov    s0, s8                                     
02d3df94: mov     x0, xzr                                    
02d3df98: bl      #0x5b2dfc0                                 UnityEngine.Random::Range
02d3df9c: ldr     x0, [x20, #0x60]                           ._tfBottomLeftOpen
02d3dfa0: cbz     x0, #0x2d3e2c4                             
02d3dfa4: mov     x1, xzr                                    
02d3dfa8: str     s0, [sp, #0x5c]                            
02d3dfac: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d3dfb0: ldr     x0, [x20, #0x58]                           ._tfTopRightOpen
02d3dfb4: cbz     x0, #0x2d3e2c4                             
02d3dfb8: mov     x1, xzr                                    
02d3dfbc: fmov    s8, s1                                     
02d3dfc0: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d3dfc4: fmov    s0, s8                                     
02d3dfc8: mov     x0, xzr                                    
02d3dfcc: bl      #0x5b2dfc0                                 UnityEngine.Random::Range
02d3dfd0: ldr     x8, [x20, #0x28]                           ._spawnedBlindBox
02d3dfd4: cbz     x8, #0x2d3e2c4                             
02d3dfd8: fmov    s9, s0                                     
02d3dfdc: ldr     w25, [x8, #0x18]                           
02d3dfe0: movi    d0, #0000000000000000                      
02d3dfe4: mov     w8, #0x43b40000                            
02d3dfe8: mov     x0, xzr                                    
02d3dfec: fmov    s1, w8                                     
02d3dff0: bl      #0x5b2dfc0                                 UnityEngine.Random::Range
02d3dff4: ldr     x23, [x20, #0x20]                          ._blindBoxItem
02d3dff8: cbz     x23, #0x2d3e2c4                            
02d3dffc: mov     x0, x23                                    
02d3e000: mov     x1, xzr                                    
02d3e004: fmov    s13, s0                                    
02d3e008: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d3e00c: cbz     x0, #0x2d3e2c4                             
02d3e010: adrp    x24, #0x6263000                            
02d3e014: adrp    x26, #0x626a000                            
02d3e018: mov     x1, xzr                                    
02d3e01c: ldr     x24, [x24, #0x918]                         T:UnityEngine.Object
02d3e020: ldr     x26, [x26, #0xe50]                         MS:UnityEngine.Object::Instantiate
02d3e024: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d3e028: adrp    x8, #0x1085000                             
02d3e02c: fmov    s10, s0                                    
02d3e030: mov     x0, sp                                     
02d3e034: ldr     s0, [x8, #0x10]                            [1085010]=4202c6f23c8efa35 f=0.0174533,32.6943
02d3e038: mov     x1, xzr                                    
02d3e03c: fmov    s11, s1                                    
02d3e040: fmov    s12, s2                                    
02d3e044: str     xzr, [sp]                                  
02d3e048: fmul    s0, s13, s0                                
02d3e04c: str     s0, [sp, #8]                               
02d3e050: bl      #0x5b2607c                                 UnityEngine.Quaternion::Internal_FromEulerRad
02d3e054: fmov    s13, s0                                    
02d3e058: fmov    s14, s1                                    
02d3e05c: ldr     x0, [x24]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d3e060: fmov    s15, s2                                    
02d3e064: fmov    s8, s3                                     
02d3e068: ldr     x24, [x20, #0x30]                          ._tfHolder
02d3e06c: ldr     w8, [x0, #0xe4]                            [626a0e4]=0 f=0,0
02d3e070: cbnz    w8, #0x2d3e078                             
02d3e074: bl      #0x2b70f30                                 fn_2b70f30
02d3e078: fmov    s0, s10                                    
02d3e07c: fmov    s1, s11                                    
02d3e080: ldr     x2, [x26]                                  T:type56879(k15)
02d3e084: fmov    s2, s12                                    
02d3e088: fmov    s3, s13                                    
02d3e08c: mov     x0, x23                                    
02d3e090: fmov    s4, s14                                    
02d3e094: fmov    s5, s15                                    
02d3e098: mov     x1, x24                                    
02d3e09c: fmov    s6, s8                                     
02d3e0a0: bl      #0x3276204                                 fn_3276204
02d3e0a4: cbz     x19, #0x2d3e2c4                            
02d3e0a8: mov     x23, x19                                   
02d3e0ac: mov     x1, x0                                     
02d3e0b0: str     x0, [x23, #0x10]!                          
02d3e0b4: mov     x0, x23                                    
02d3e0b8: bl      #0x2b70d54                                 fn_2b70d54
02d3e0bc: ldr     x0, [x23]                                  T:type56879(k15)
02d3e0c0: cbz     x0, #0x2d3e2c4                             
02d3e0c4: ldr     x1, [x20, #0xa8]                           ._cachedSkinName
02d3e0c8: bl      #0x2d3c4f4                                 ScoopGame.BlindBox::SetVisual
02d3e0cc: ldr     x0, [x23]                                  T:type56879(k15)
02d3e0d0: cbz     x0, #0x2d3e2c4                             
02d3e0d4: mov     w1, w22                                    
02d3e0d8: mov     x2, x21                                    
02d3e0dc: bl      #0x2d3c648                                 ScoopGame.BlindBox::SetCharm
02d3e0e0: ldr     x0, [x23]                                  T:type56879(k15)
02d3e0e4: cbz     x0, #0x2d3e2c4                             
02d3e0e8: bl      #0x2d3c304                                 ScoopGame.BlindBox::DisableBagClick
02d3e0ec: ldr     x21, [x23]                                 T:type56879(k15)
02d3e0f0: ldr     x22, [x20, #0x40]                          ._tfPlateResult
02d3e0f4: mov     x0, x20                                    
02d3e0f8: bl      #0x2d3d838                                 ScoopGame.BlindBoxPlate::GetRandomPositionBetweenPlate
02d3e0fc: cbz     x21, #0x2d3e2c4                            
02d3e100: str     x22, [x21, #0x70]!                         ._tfBottomLeftPlate
02d3e104: mov     x0, x21                                    
02d3e108: mov     x1, x22                                    
02d3e10c: fmov    s8, s0                                     
02d3e110: fmov    s10, s1                                    
02d3e114: fmov    s11, s2                                    
02d3e118: bl      #0x2b70d54                                 fn_2b70d54
02d3e11c: stp     s8, s10, [x21, #-0xc]                      
02d3e120: stur    s11, [x21, #-4]                            
02d3e124: ldr     x0, [x23]                                  T:type56879(k15)
02d3e128: cbz     x0, #0x2d3e2c4                             
02d3e12c: mov     x1, x20                                    
02d3e130: str     x20, [x0, #0x78]!                          ._collider
02d3e134: bl      #0x2b70d54                                 fn_2b70d54
02d3e138: ldr     x21, [x23]                                 T:type56879(k15)
02d3e13c: cbz     x21, #0x2d3e2c4                            
02d3e140: mov     x0, x21                                    
02d3e144: mov     x1, xzr                                    
02d3e148: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d3e14c: cbz     x0, #0x2d3e2c4                             
02d3e150: adrp    x22, #0x626a000                            
02d3e154: mov     x1, xzr                                    
02d3e158: ldr     x22, [x22, #0xe58]                         S:'BlindBox_{0}'
02d3e15c: bl      #0x5b485a4                                 UnityEngine.Transform::GetSiblingIndex
02d3e160: adrp    x8, #0x6263000                             
02d3e164: mov     x1, sp                                     
02d3e168: ldr     x8, [x8, #0x970]                           &6645c70(=0)
02d3e16c: str     w0, [sp]                                   
02d3e170: ldr     x8, [x8, #0x48]                            &6263098(=0)
02d3e174: mov     x0, x8                                     
02d3e178: bl      #0x2b70f38                                 fn_2b70f38
02d3e17c: ldr     x8, [x22]                                  T:type56879(k15)
02d3e180: mov     x1, x0                                     
02d3e184: mov     x2, xzr                                    
02d3e188: mov     x0, x8                                     
02d3e18c: bl      #0x4c9d0ec                                 System.String::Format
02d3e190: mov     x1, x0                                     
02d3e194: mov     x0, x21                                    
02d3e198: mov     x2, xzr                                    
02d3e19c: bl      #0x5b3bcf8                                 UnityEngine.Object::set_name
02d3e1a0: ldr     x0, [x20, #0x28]                           ._spawnedBlindBox
02d3e1a4: cbz     x0, #0x2d3e2c4                             
02d3e1a8: adrp    x9, #0x626a000                             
02d3e1ac: ldr     x9, [x9, #0xe48]                           MS:System.Collections.Generic.List`1::Add
02d3e1b0: ldr     w10, [x0, #0x1c]                           [626a01c]=0 f=0,0
02d3e1b4: ldr     x8, [x0, #0x10]                            T:Decor.DataDecor/CategoryData
02d3e1b8: ldr     x1, [x23]                                  T:type56879(k15)
02d3e1bc: ldr     x9, [x9]                                   T:type56879(k15)
02d3e1c0: add     w10, w10, #1                               
02d3e1c4: str     w10, [x0, #0x1c]                           
02d3e1c8: cbz     x8, #0x2d3e2c4                             
02d3e1cc: ldrsw   x10, [x0, #0x18]                           
02d3e1d0: ldr     w11, [x8, #0x18]                           &2c5d934(=d65f03c0d503245f)
02d3e1d4: cmp     w10, w11                                   
02d3e1d8: b.hs    #0x2d3e1f8                                 
02d3e1dc: add     x8, x8, x10, lsl #3                        &6263000
02d3e1e0: add     w9, w10, #1                                
02d3e1e4: str     w9, [x0, #0x18]                            
02d3e1e8: str     x1, [x8, #0x20]!                           
02d3e1ec: mov     x0, x8                                     
02d3e1f0: bl      #0x2b70d54                                 fn_2b70d54
02d3e1f4: b       #0x2d3e208                                 
02d3e1f8: ldr     x8, [x9, #0x20]                            M:Decor.DataDecor/<>c__DisplayClass8_0::<NewData>b__0
02d3e1fc: ldr     x8, [x8, #0xc0]                            &2c5bebc(=f9400800d503245f)
02d3e200: ldr     x2, [x8, #0x70]                            &2c5bd48(=a9bd7bfdd503233f)
02d3e204: bl      #0x35a920c                                 fn_35a920c
02d3e208: ldr     x0, [x23]                                  T:type56879(k15)
02d3e20c: cbz     x0, #0x2d3e2c4                             
02d3e210: scvtf   s0, w25                                    
02d3e214: adrp    x8, #0x1084000                             
02d3e218: adrp    x20, #0x6264000                            
02d3e21c: ldr     s1, [x8, #0xeec]                           [1084eec]=457ff0003dcccccd f=0.1,4095
02d3e220: adrp    x21, #0x626a000                            
02d3e224: adrp    x22, #0x6266000                            
02d3e228: ldr     x20, [x20, #0xe8]                          T:DG.Tweening.TweenCallback
02d3e22c: ldr     x21, [x21, #0xe88]                         M:ScoopGame.BlindBoxPlate/<>c__DisplayClass31_0::<AddMoreRandomBox>b__0
02d3e230: ldr     x22, [x22, #0xa88]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d3e234: mov     x1, xzr                                    
02d3e238: fmul    s8, s0, s1                                 
02d3e23c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d3e240: fmov    s1, s9                                     
02d3e244: fmov    s2, s8                                     
02d3e248: ldr     s0, [sp, #0x5c]                            
02d3e24c: fmov    s3, #3.00000000                            
02d3e250: fmov    s4, #1.00000000                            
02d3e254: mov     w1, #1                                     
02d3e258: mov     w2, wzr                                    
02d3e25c: mov     x3, xzr                                    
02d3e260: bl      #0x2d9abb0                                 DG.Tweening.ShortcutExtensions::DOJump
02d3e264: ldr     x8, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d3e268: mov     x20, x0                                    
02d3e26c: mov     x0, x8                                     
02d3e270: bl      #0x2b7104c                                 fn_2b7104c
02d3e274: ldr     x2, [x21]                                  T:type56879(k15)
02d3e278: mov     x1, x19                                    
02d3e27c: mov     x3, xzr                                    
02d3e280: mov     x21, x0                                    
02d3e284: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d3e288: ldr     x2, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d3e28c: mov     x0, x20                                    
02d3e290: mov     x1, x21                                    
02d3e294: bl      #0x336f26c                                 fn_336f26c
02d3e298: ldp     x20, x19, [sp, #0x90]                      
02d3e29c: ldr     x30, [sp, #0x50]                           
02d3e2a0: ldp     x22, x21, [sp, #0x80]                      
02d3e2a4: ldp     x24, x23, [sp, #0x70]                      
02d3e2a8: ldp     x26, x25, [sp, #0x60]                      
02d3e2ac: ldp     d9, d8, [sp, #0x40]                        
02d3e2b0: ldp     d11, d10, [sp, #0x30]                      
02d3e2b4: ldp     d13, d12, [sp, #0x20]                      
02d3e2b8: ldp     d15, d14, [sp, #0x10]                      
02d3e2bc: add     sp, sp, #0xa0                              
02d3e2c0: ret                                                
02d3e2c4: bl      #0x2b7105c                                 fn_2b7105c
## GetRandomPositionBetweenPlate() -> UnityEngine.Vector3
---- ScoopGame.BlindBoxPlate::GetRandomPositionBetweenPlate 0x2d3d838
02d3d838: str     d10, [sp, #-0x30]!                         
02d3d83c: stp     d9, d8, [sp, #0x10]                        
02d3d840: stp     x30, x19, [sp, #0x20]                      
02d3d844: mov     x19, x0                                    
02d3d848: ldr     x0, [x0, #0x70]                            ._tfBottomLeftPlate
02d3d84c: cbz     x0, #0x2d3d904                             
02d3d850: mov     x1, xzr                                    
02d3d854: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d3d858: ldr     x0, [x19, #0x68]                           ._tfTopRightPlate
02d3d85c: cbz     x0, #0x2d3d904                             
02d3d860: mov     x1, xzr                                    
02d3d864: fmov    s8, s0                                     
02d3d868: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d3d86c: fmov    s1, s0                                     
02d3d870: fmov    s0, s8                                     
02d3d874: mov     x0, xzr                                    
02d3d878: bl      #0x5b2dfc0                                 UnityEngine.Random::Range
02d3d87c: ldr     x0, [x19, #0x70]                           ._tfBottomLeftPlate
02d3d880: cbz     x0, #0x2d3d904                             
02d3d884: mov     x1, xzr                                    
02d3d888: fmov    s8, s0                                     
02d3d88c: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d3d890: ldr     x0, [x19, #0x68]                           ._tfTopRightPlate
02d3d894: cbz     x0, #0x2d3d904                             
02d3d898: mov     x1, xzr                                    
02d3d89c: fmov    s9, s1                                     
02d3d8a0: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d3d8a4: fmov    s0, s9                                     
02d3d8a8: mov     x0, xzr                                    
02d3d8ac: bl      #0x5b2dfc0                                 UnityEngine.Random::Range
02d3d8b0: ldr     x0, [x19, #0x70]                           ._tfBottomLeftPlate
02d3d8b4: cbz     x0, #0x2d3d904                             
02d3d8b8: mov     x1, xzr                                    
02d3d8bc: fmov    s9, s0                                     
02d3d8c0: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d3d8c4: ldr     x0, [x19, #0x68]                           ._tfTopRightPlate
02d3d8c8: cbz     x0, #0x2d3d904                             
02d3d8cc: mov     x1, xzr                                    
02d3d8d0: fmov    s10, s2                                    
02d3d8d4: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d3d8d8: fmov    s1, s2                                     
02d3d8dc: fmov    s0, s10                                    
02d3d8e0: mov     x0, xzr                                    
02d3d8e4: bl      #0x5b2dfc0                                 UnityEngine.Random::Range
02d3d8e8: fmov    s2, s0                                     
02d3d8ec: fmov    s0, s8                                     
02d3d8f0: fmov    s1, s9                                     
02d3d8f4: ldp     x30, x19, [sp, #0x20]                      
02d3d8f8: ldp     d9, d8, [sp, #0x10]                        
02d3d8fc: ldr     d10, [sp], #0x30                           
02d3d900: ret                                                
02d3d904: bl      #0x2b7105c                                 fn_2b7105c
## SpawnCompliment() -> void
---- ScoopGame.BlindBoxPlate::SpawnCompliment 0x2d3ce90
02d3ce90: str     d8, [sp, #-0x30]!                          
02d3ce94: stp     x30, x21, [sp, #0x10]                      
02d3ce98: stp     x20, x19, [sp, #0x20]                      
02d3ce9c: adrp    x20, #0x6630000                            
02d3cea0: mov     x19, x0                                    
02d3cea4: ldrb    w8, [x20, #0x178]                          
02d3cea8: tbnz    w8, #0, #0x2d3cef0                         
02d3ceac: adrp    x0, #0x626a000                             
02d3ceb0: ldr     x0, [x0, #0xb38]                           MS:UnityEngine.Component::GetComponent
02d3ceb4: bl      #0x2b70db0                                 fn_2b70db0
02d3ceb8: adrp    x0, #0x6266000                             
02d3cebc: ldr     x0, [x0, #0xc30]                           MS:System.Collections.Generic.List`1::get_Count
02d3cec0: bl      #0x2b70db0                                 fn_2b70db0
02d3cec4: adrp    x0, #0x626a000                             
02d3cec8: ldr     x0, [x0, #0xb40]                           MS:System.Collections.Generic.List`1::get_Item
02d3cecc: bl      #0x2b70db0                                 fn_2b70db0
02d3ced0: adrp    x0, #0x6266000                             
02d3ced4: ldr     x0, [x0, #0xc38]                           MS:System.Collections.Generic.List`1::get_Item
02d3ced8: bl      #0x2b70db0                                 fn_2b70db0
02d3cedc: adrp    x0, #0x6266000                             
02d3cee0: ldr     x0, [x0, #0xd20]                           MS:MonoSingleton`1::get_Instance
02d3cee4: bl      #0x2b70db0                                 fn_2b70db0
02d3cee8: mov     w8, #1                                     
02d3ceec: strb    w8, [x20, #0x178]                          
02d3cef0: ldr     x0, [x19, #0x98]                           ._tfComplimentBottomLeft
02d3cef4: cbz     x0, #0x2d3d02c                             
02d3cef8: mov     x1, xzr                                    
02d3cefc: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d3cf00: ldr     x0, [x19, #0x90]                           ._tfComplimentTopRight
02d3cf04: cbz     x0, #0x2d3d02c                             
02d3cf08: mov     x1, xzr                                    
02d3cf0c: fmov    s8, s0                                     
02d3cf10: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d3cf14: fmov    s1, s0                                     
02d3cf18: fmov    s0, s8                                     
02d3cf1c: mov     x0, xzr                                    
02d3cf20: bl      #0x5b2dfc0                                 UnityEngine.Random::Range
02d3cf24: ldr     x0, [x19, #0x98]                           ._tfComplimentBottomLeft
02d3cf28: str     s0, [x19, #0xb0]                           .x
02d3cf2c: cbz     x0, #0x2d3d02c                             
02d3cf30: mov     x1, xzr                                    
02d3cf34: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d3cf38: ldr     x0, [x19, #0x90]                           ._tfComplimentTopRight
02d3cf3c: cbz     x0, #0x2d3d02c                             
02d3cf40: adrp    x20, #0x6266000                            
02d3cf44: mov     x1, xzr                                    
02d3cf48: fmov    s8, s1                                     
02d3cf4c: ldr     x20, [x20, #0xd20]                         MS:MonoSingleton`1::get_Instance
02d3cf50: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d3cf54: fmov    s0, s8                                     
02d3cf58: mov     x0, xzr                                    
02d3cf5c: bl      #0x5b2dfc0                                 UnityEngine.Random::Range
02d3cf60: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d3cf64: str     s0, [x19, #0xb4]                           .y
02d3cf68: bl      #0x3769600                                 fn_3769600
02d3cf6c: cbz     x0, #0x2d3d02c                             
02d3cf70: mov     w1, #0x6c                                  
02d3cf74: mov     x2, xzr                                    
02d3cf78: bl      #0x2cdcf8c                                 PoolManager::SpawnPoolElement
02d3cf7c: cbz     x0, #0x2d3d02c                             
02d3cf80: adrp    x8, #0x626a000                             
02d3cf84: ldr     x8, [x8, #0xb38]                           MS:UnityEngine.Component::GetComponent
02d3cf88: ldr     x1, [x8]                                   T:type56879(k15)
02d3cf8c: bl      #0x3140c84                                 fn_3140c84
02d3cf90: ldr     x8, [x19, #0x80]                           ._complimentSprites
02d3cf94: cbz     x8, #0x2d3d02c                             
02d3cf98: ldr     w1, [x8, #0x18]                            MS:System.Collections.Generic.List`1::Add
02d3cf9c: mov     x20, x0                                    
02d3cfa0: mov     w0, wzr                                    
02d3cfa4: mov     x2, xzr                                    
02d3cfa8: bl      #0x5b2e000                                 UnityEngine.Random::Range
02d3cfac: ldr     x8, [x19, #0x80]                           ._complimentSprites
02d3cfb0: cbz     x8, #0x2d3d02c                             
02d3cfb4: adrp    x9, #0x6266000                             
02d3cfb8: mov     w21, w0                                    
02d3cfbc: mov     x0, x8                                     
02d3cfc0: ldr     x9, [x9, #0xc38]                           MS:System.Collections.Generic.List`1::get_Item
02d3cfc4: mov     w1, w21                                    
02d3cfc8: ldr     x2, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d3cfcc: bl      #0x35a8f3c                                 fn_35a8f3c
02d3cfd0: cbz     x20, #0x2d3d02c                            
02d3cfd4: movi    d2, #0000000000000000                      
02d3cfd8: ldp     s0, s1, [x19, #0xb0]                       .x
02d3cfdc: mov     x1, x0                                     
02d3cfe0: mov     x0, x20                                    
02d3cfe4: bl      #0x2d37720                                 ScoopGame.ComplimentItem::ShowEffect
02d3cfe8: ldr     x0, [x19, #0x88]                           ._complimentSoundEnum
02d3cfec: cbz     x0, #0x2d3d02c                             
02d3cff0: adrp    x8, #0x626a000                             
02d3cff4: mov     w1, w21                                    
02d3cff8: ldr     x8, [x8, #0xb40]                           MS:System.Collections.Generic.List`1::get_Item
02d3cffc: ldr     x2, [x8]                                   T:type56879(k15)
02d3d000: bl      #0x356c280                                 fn_356c280
02d3d004: ldp     x20, x19, [sp, #0x20]                      
02d3d008: movi    d1, #0000000000000000                      
02d3d00c: ldp     x30, x21, [sp, #0x10]                      
02d3d010: movi    d2, #0000000000000000                      
02d3d014: fmov    s0, #1.00000000                            
02d3d018: mov     w1, wzr                                    
02d3d01c: mov     w2, wzr                                    
02d3d020: mov     x3, xzr                                    
02d3d024: ldr     d8, [sp], #0x30                            
02d3d028: b       #0x2d84264                                 Framework.AudioHelper::PlaySound
02d3d02c: bl      #0x2b7105c                                 fn_2b7105c
## HideTrayResult() -> void
---- ScoopGame.BlindBoxPlate::HideTrayResult 0x2d3e2d0
02d3e2d0: str     x30, [sp, #-0x30]!                         
02d3e2d4: stp     x22, x21, [sp, #0x10]                      
02d3e2d8: stp     x20, x19, [sp, #0x20]                      
02d3e2dc: adrp    x22, #0x6630000                            
02d3e2e0: adrp    x21, #0x6266000                            
02d3e2e4: adrp    x20, #0x6266000                            
02d3e2e8: ldrb    w8, [x22, #0x179]                          
02d3e2ec: ldr     x21, [x21, #0xe08]                         MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02d3e2f0: ldr     x20, [x20, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d3e2f4: mov     x19, x0                                    
02d3e2f8: tbnz    w8, #0, #0x2d3e31c                         
02d3e2fc: adrp    x0, #0x6266000                             
02d3e300: ldr     x0, [x0, #0xe08]                           MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02d3e304: bl      #0x2b70db0                                 fn_2b70db0
02d3e308: adrp    x0, #0x6266000                             
02d3e30c: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d3e310: bl      #0x2b70db0                                 fn_2b70db0
02d3e314: mov     w8, #1                                     
02d3e318: strb    w8, [x22, #0x179]                          
02d3e31c: adrp    x8, #0x1084000                             
02d3e320: fmov    s0, #-20.00000000                          
02d3e324: ldr     x0, [x19, #0x40]                           ._tfPlateResult
02d3e328: ldr     s1, [x8, #0xcc4]                           [1084cc4]=3f8000543f4ccccd f=0.8,1.00001
02d3e32c: mov     w1, wzr                                    
02d3e330: mov     x2, xzr                                    
02d3e334: bl      #0x2d98060                                 DG.Tweening.ShortcutExtensions::DOLocalMoveY
02d3e338: adrp    x8, #0x1084000                             
02d3e33c: ldr     x1, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d3e340: ldr     s0, [x8, #0xf10]                           [1084f10]=4110bc863e99999a f=0.3,9.04603
02d3e344: bl      #0x336f7fc                                 fn_336f7fc
02d3e348: ldr     x2, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d3e34c: ldp     x20, x19, [sp, #0x20]                      
02d3e350: ldp     x22, x21, [sp, #0x10]                      
02d3e354: mov     w1, #0x1a                                  
02d3e358: ldr     x30, [sp], #0x30                           
02d3e35c: b       #0x336fa0c                                 
## .ctor() -> void
---- ScoopGame.BlindBoxPlate::.ctor 0x2d3e360
02d3e360: mov     x1, xzr                                    
02d3e364: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
## <PopOutBlindBox>b__28_0() -> void
---- ScoopGame.BlindBoxPlate::<PopOutBlindBox>b__28_0 0x2d3e368
02d3e368: str     d8, [sp, #-0x30]!                          
02d3e36c: stp     x30, x21, [sp, #0x10]                      
02d3e370: stp     x20, x19, [sp, #0x20]                      
02d3e374: adrp    x20, #0x6630000                            
02d3e378: mov     x19, x0                                    
02d3e37c: ldrb    w8, [x20, #0x17a]                          
02d3e380: tbnz    w8, #0, #0x2d3e3a4                         
02d3e384: adrp    x0, #0x626a000                             
02d3e388: ldr     x0, [x0, #0xe00]                           MS:System.Collections.Generic.List`1::get_Count
02d3e38c: bl      #0x2b70db0                                 fn_2b70db0
02d3e390: adrp    x0, #0x626a000                             
02d3e394: ldr     x0, [x0, #0xe90]                           S:'CheckPopOutBlindBox'
02d3e398: bl      #0x2b70db0                                 fn_2b70db0
02d3e39c: mov     w8, #1                                     
02d3e3a0: strb    w8, [x20, #0x17a]                          
02d3e3a4: ldr     x8, [x19, #0x28]                           ._spawnedBlindBox
02d3e3a8: cbz     x8, #0x2d3e3f0                             
02d3e3ac: adrp    x9, #0x1084000                             
02d3e3b0: adrp    x20, #0x626a000                            
02d3e3b4: mov     w21, wzr                                   
02d3e3b8: ldr     x20, [x20, #0xe90]                         S:'CheckPopOutBlindBox'
02d3e3bc: ldr     s8, [x9, #0xeec]                           [1084eec]=457ff0003dcccccd f=0.1,4095
02d3e3c0: ldr     w8, [x8, #0x18]                            
02d3e3c4: cmp     w21, w8                                    
02d3e3c8: b.ge    #0x2d3e3f4                                 
02d3e3cc: scvtf   s0, w21                                    
02d3e3d0: ldr     x1, [x20]                                  T:type56879(k15)
02d3e3d4: mov     x0, x19                                    
02d3e3d8: mov     x2, xzr                                    
02d3e3dc: fmul    s0, s0, s8                                 
02d3e3e0: bl      #0x5b38044                                 UnityEngine.MonoBehaviour::Invoke
02d3e3e4: ldr     x8, [x19, #0x28]                           ._spawnedBlindBox
02d3e3e8: add     w21, w21, #1                               
02d3e3ec: cbnz    x8, #0x2d3e3c0                             
02d3e3f0: bl      #0x2b7105c                                 fn_2b7105c
02d3e3f4: ldp     x20, x19, [sp, #0x20]                      
02d3e3f8: ldp     x30, x21, [sp, #0x10]                      
02d3e3fc: ldr     d8, [sp], #0x30                            
02d3e400: ret                                                
