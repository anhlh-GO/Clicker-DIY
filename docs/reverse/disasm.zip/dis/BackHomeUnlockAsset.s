#### CLASS BackHomeUnlockAsset/<>c__DisplayClass1_0 parent= object
#   field day                            int                                                off=0x10 attr=6 
## .ctor() -> void
---- BackHomeUnlockAsset/<>c__DisplayClass1_0::.ctor 0x2cafd94
02cafd94: mov     x1, xzr                                    
02cafd98: b       #0x4e53e9c                                 System.Object::.ctor
## <GetData>b__0(HomeUnlockItemData x) -> bool
---- BackHomeUnlockAsset/<>c__DisplayClass1_0::<GetData>b__0 0x2cafdac
02cafdac: cbz     x1, #0x2cafdc4                             
02cafdb0: ldr     w8, [x1, #0x10]                            
02cafdb4: ldr     w9, [x0, #0x10]                            .day
02cafdb8: cmp     w8, w9                                     
02cafdbc: cset    w0, eq                                     
02cafdc0: ret                                                
02cafdc4: str     x30, [sp, #-0x10]!                         
02cafdc8: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS BackHomeUnlockAsset parent= UnityEngine.ScriptableObject
#   field DataList                       System.Collections.Generic.List`1<HomeUnlockItemData> off=0x18 attr=1 SerializeField
## GetData(int day) -> HomeUnlockItemData
---- BackHomeUnlockAsset::GetData 0x2cafcbc
02cafcbc: str     x30, [sp, #-0x30]!                         
02cafcc0: stp     x22, x21, [sp, #0x10]                      
02cafcc4: stp     x20, x19, [sp, #0x20]                      
02cafcc8: adrp    x21, #0x662f000                            
02cafccc: adrp    x22, #0x6266000                            
02cafcd0: mov     w19, w1                                    
02cafcd4: ldrb    w8, [x21, #0xb5f]                          
02cafcd8: ldr     x22, [x22, #0x9c0]                         T:BackHomeUnlockAsset/<>c__DisplayClass1_0
02cafcdc: mov     x20, x0                                    
02cafce0: tbnz    w8, #0, #0x2cafd1c                         
02cafce4: adrp    x0, #0x6266000                             
02cafce8: ldr     x0, [x0, #0x9c8]                           MS:System.Collections.Generic.List`1::Find
02cafcec: bl      #0x2b70db0                                 fn_2b70db0
02cafcf0: adrp    x0, #0x6266000                             
02cafcf4: ldr     x0, [x0, #0x9d0]                           T:type57247(k15)
02cafcf8: bl      #0x2b70db0                                 fn_2b70db0
02cafcfc: adrp    x0, #0x6266000                             
02cafd00: ldr     x0, [x0, #0x9d8]                           M:BackHomeUnlockAsset/<>c__DisplayClass1_0::<GetData>b__0
02cafd04: bl      #0x2b70db0                                 fn_2b70db0
02cafd08: adrp    x0, #0x6266000                             
02cafd0c: ldr     x0, [x0, #0x9c0]                           T:BackHomeUnlockAsset/<>c__DisplayClass1_0
02cafd10: bl      #0x2b70db0                                 fn_2b70db0
02cafd14: mov     w8, #1                                     
02cafd18: strb    w8, [x21, #0xb5f]                          
02cafd1c: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cafd20: bl      #0x2b7104c                                 fn_2b7104c
02cafd24: mov     x1, xzr                                    
02cafd28: mov     x21, x0                                    
02cafd2c: bl      #0x4e53e9c                                 System.Object::.ctor
02cafd30: cbz     x21, #0x2cafd90                            
02cafd34: adrp    x8, #0x6266000                             
02cafd38: adrp    x22, #0x6266000                            
02cafd3c: ldr     x8, [x8, #0x9d0]                           T:type57247(k15)
02cafd40: ldr     x22, [x22, #0x9d8]                         M:BackHomeUnlockAsset/<>c__DisplayClass1_0::<GetData>b__0
02cafd44: ldr     x20, [x20, #0x18]                          .DataList
02cafd48: str     w19, [x21, #0x10]                          
02cafd4c: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cafd50: bl      #0x2b7104c                                 fn_2b7104c
02cafd54: ldr     x2, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cafd58: mov     x1, x21                                    
02cafd5c: mov     x3, xzr                                    
02cafd60: mov     x19, x0                                    
02cafd64: bl      #0x399ba10                                 fn_399ba10
02cafd68: cbz     x20, #0x2cafd90                            
02cafd6c: adrp    x8, #0x6266000                             
02cafd70: mov     x0, x20                                    
02cafd74: mov     x1, x19                                    
02cafd78: ldr     x8, [x8, #0x9c8]                           MS:System.Collections.Generic.List`1::Find
02cafd7c: ldp     x20, x19, [sp, #0x20]                      
02cafd80: ldp     x22, x21, [sp, #0x10]                      
02cafd84: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cafd88: ldr     x30, [sp], #0x30                           
02cafd8c: b       #0x35a9868                                 
02cafd90: bl      #0x2b7105c                                 fn_2b7105c
## GetAllData() -> System.Collections.Generic.List`1<HomeUnlockItemData>
---- BackHomeUnlockAsset::GetAllData 0x2cafd9c
02cafd9c: ldr     x0, [x0, #0x18]                            .DataList
02cafda0: ret                                                
## .ctor() -> void
---- BackHomeUnlockAsset::.ctor 0x2cafda4
02cafda4: mov     x1, xzr                                    
02cafda8: b       #0x5b398f0                                 UnityEngine.ScriptableObject::.ctor
