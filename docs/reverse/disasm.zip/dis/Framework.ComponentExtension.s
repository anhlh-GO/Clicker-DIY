#### CLASS Framework.ComponentExtension parent= object
##  CopyComponent (no body)
