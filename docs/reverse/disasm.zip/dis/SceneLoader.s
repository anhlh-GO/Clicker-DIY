#### CLASS SceneLoader/<>c__DisplayClass3_0/<<FadeIn>b__0>d parent= System.ValueType
#   field <>1__state                     int                                                off=0x10 attr=6 
#   field <>t__builder                   System.Runtime.CompilerServices.AsyncVoidMethodBuilder off=0x18 attr=6 
#   field <>4__this                      SceneLoader/<>c__DisplayClass3_0                   off=0x38 attr=6 
#   field <>u__1                         System.Runtime.CompilerServices.TaskAwaiter`1<UnityEngine.AsyncOperation> off=0x40 attr=1 
#   field <>u__2                         Cysharp.Threading.Tasks.UniTask/Awaiter            off=0x48 attr=1 
## MoveNext() -> void
---- SceneLoader/<>c__DisplayClass3_0/<<FadeIn>b__0>d::MoveNext 0x2cd7914
02cd7914: sub     sp, sp, #0x70                              
02cd7918: str     x30, [sp, #0x30]                           
02cd791c: stp     x24, x23, [sp, #0x40]                      
02cd7920: stp     x22, x21, [sp, #0x50]                      
02cd7924: stp     x20, x19, [sp, #0x60]                      
02cd7928: adrp    x20, #0x662f000                            
02cd792c: mov     x19, x0                                    
02cd7930: ldrb    w8, [x20, #0xd39]                          
02cd7934: tbnz    w8, #0, #0x2cd7988                         
02cd7938: adrp    x0, #0x6267000                             
02cd793c: ldr     x0, [x0, #0xa18]                           MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::AwaitUnsafeOnCompleted
02cd7940: bl      #0x2b70db0                                 fn_2b70db0
02cd7944: adrp    x0, #0x6267000                             
02cd7948: ldr     x0, [x0, #0xa20]                           MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::AwaitUnsafeOnCompleted
02cd794c: bl      #0x2b70db0                                 fn_2b70db0
02cd7950: adrp    x0, #0x6267000                             
02cd7954: ldr     x0, [x0, #0xa28]                           MS:System.Runtime.CompilerServices.TaskAwaiter`1::GetResult
02cd7958: bl      #0x2b70db0                                 fn_2b70db0
02cd795c: adrp    x0, #0x6267000                             
02cd7960: ldr     x0, [x0, #0xa30]                           MS:System.Runtime.CompilerServices.TaskAwaiter`1::get_IsCompleted
02cd7964: bl      #0x2b70db0                                 fn_2b70db0
02cd7968: adrp    x0, #0x6267000                             
02cd796c: ldr     x0, [x0, #0xa38]                           MS:System.Threading.Tasks.Task`1::GetAwaiter
02cd7970: bl      #0x2b70db0                                 fn_2b70db0
02cd7974: adrp    x0, #0x6266000                             
02cd7978: ldr     x0, [x0, #0xcc8]                           T:Cysharp.Threading.Tasks.UniTask
02cd797c: bl      #0x2b70db0                                 fn_2b70db0
02cd7980: mov     w8, #1                                     
02cd7984: strb    w8, [x20, #0xd39]                          
02cd7988: ldr     w8, [x19]                                  
02cd798c: ldr     x22, [x19, #0x28]                          
02cd7990: str     xzr, [sp, #0x38]                           
02cd7994: stp     xzr, xzr, [sp, #0x10]                      
02cd7998: str     wzr, [sp, #8]                              
02cd799c: cbz     w8, #0x2cd79c0                             
02cd79a0: cmp     w8, #1                                     
02cd79a4: b.ne    #0x2cd79d8                                 
02cd79a8: ldur    q0, [x19, #0x38]                           .<>4__this
02cd79ac: mov     w8, #-1                                    
02cd79b0: stp     xzr, xzr, [x19, #0x38]                     .<>4__this
02cd79b4: str     w8, [x19]                                  
02cd79b8: str     q0, [sp, #0x10]                            
02cd79bc: b       #0x2cd7bd8                                 
02cd79c0: ldr     x8, [x19, #0x30]                           
02cd79c4: mov     w9, #-1                                    
02cd79c8: str     xzr, [x19, #0x30]                          
02cd79cc: str     w9, [x19]                                  
02cd79d0: str     x8, [sp, #0x38]                            
02cd79d4: b       #0x2cd7a1c                                 
02cd79d8: cbz     x22, #0x2cd7d08                            
02cd79dc: ldr     x8, [x22, #0x10]                           
02cd79e0: cbz     x8, #0x2cd7d0c                             
02cd79e4: ldr     x1, [x22, #0x18]                           
02cd79e8: bl      #0x2cd76f8                                 SceneLoader::LoadScene
02cd79ec: cbz     x0, #0x2cd7d10                             
02cd79f0: adrp    x8, #0x6267000                             
02cd79f4: ldr     x8, [x8, #0xa38]                           MS:System.Threading.Tasks.Task`1::GetAwaiter
02cd79f8: ldr     x1, [x8]                                   S:'didu'
02cd79fc: bl      #0x3d3e4e4                                 fn_3d3e4e4
02cd7a00: adrp    x8, #0x6267000                             
02cd7a04: ldr     x8, [x8, #0xa30]                           MS:System.Runtime.CompilerServices.TaskAwaiter`1::get_IsCompleted
02cd7a08: str     x0, [sp, #0x38]                            
02cd7a0c: ldr     x1, [x8]                                   S:'didu'
02cd7a10: add     x0, sp, #0x38                              
02cd7a14: bl      #0x3cbe788                                 fn_3cbe788
02cd7a18: tbz     w0, #0, #0x2cd7b80                         
02cd7a1c: adrp    x8, #0x6267000                             
02cd7a20: ldr     x8, [x8, #0xa28]                           MS:System.Runtime.CompilerServices.TaskAwaiter`1::GetResult
02cd7a24: ldr     x1, [x8]                                   S:'didu'
02cd7a28: add     x0, sp, #0x38                              
02cd7a2c: bl      #0x3cbe7c8                                 fn_3cbe7c8
02cd7a30: cbz     x0, #0x2cd7cec                             
02cd7a34: mov     w1, #1                                     
02cd7a38: mov     x2, xzr                                    
02cd7a3c: bl      #0x5b2f47c                                 UnityEngine.AsyncOperation::set_allowSceneActivation
02cd7a40: cbz     x22, #0x2cd7cf0                            
02cd7a44: ldr     x8, [x22, #0x10]                           
02cd7a48: cbz     x8, #0x2cd7cf4                             
02cd7a4c: ldr     x0, [x8, #0x20]                            T:System.IO.FileInfo
02cd7a50: cbz     x0, #0x2cd7cf8                             
02cd7a54: mov     w1, wzr                                    
02cd7a58: mov     x2, xzr                                    
02cd7a5c: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cd7a60: ldr     x8, [x22, #0x10]                           
02cd7a64: cbz     x8, #0x2cd7cfc                             
02cd7a68: ldr     x0, [x8, #0x30]                            MS:System.Nullable`1::get_HasValue
02cd7a6c: cbz     x0, #0x2cd7d00                             
02cd7a70: mov     w1, #1                                     
02cd7a74: mov     x2, xzr                                    
02cd7a78: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cd7a7c: ldr     x0, [x22, #0x10]                           
02cd7a80: cbz     x0, #0x2cd7d04                             
02cd7a84: mov     x1, xzr                                    
02cd7a88: bl      #0x5b37c84                                 UnityEngine.MonoBehaviour::get_destroyCancellationToken
02cd7a8c: adrp    x23, #0x6266000                            
02cd7a90: mov     x20, x0                                    
02cd7a94: ldr     x23, [x23, #0xcc8]                         T:Cysharp.Threading.Tasks.UniTask
02cd7a98: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cd7a9c: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02cd7aa0: cbnz    w8, #0x2cd7aa8                             
02cd7aa4: bl      #0x2b70f30                                 fn_2b70f30
02cd7aa8: fmov    s0, #1.00000000                            
02cd7aac: mov     w0, wzr                                    
02cd7ab0: mov     w1, #8                                     
02cd7ab4: mov     x2, x20                                    
02cd7ab8: mov     w3, wzr                                    
02cd7abc: mov     x4, xzr                                    
02cd7ac0: bl      #0x5447b08                                 Cysharp.Threading.Tasks.UniTask::WaitForSeconds
02cd7ac4: stp     x0, x1, [sp, #0x20]                        
02cd7ac8: add     x0, sp, #0x20                              
02cd7acc: mov     x1, xzr                                    
02cd7ad0: bl      #0x2b70d54                                 fn_2b70d54
02cd7ad4: adrp    x24, #0x662f000                            
02cd7ad8: ldp     x20, x21, [sp, #0x20]                      
02cd7adc: ldrb    w8, [x24, #0xbdc]                          
02cd7ae0: stp     x20, x21, [sp, #0x10]                      
02cd7ae4: cbnz    w8, #0x2cd7afc                             
02cd7ae8: adrp    x0, #0x6266000                             
02cd7aec: ldr     x0, [x0, #0xcc8]                           T:Cysharp.Threading.Tasks.UniTask
02cd7af0: bl      #0x2b70db0                                 fn_2b70db0
02cd7af4: mov     w8, #1                                     
02cd7af8: strb    w8, [x24, #0xbdc]                          
02cd7afc: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cd7b00: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02cd7b04: cbnz    w8, #0x2cd7b0c                             
02cd7b08: bl      #0x2b70f30                                 fn_2b70f30
02cd7b0c: adrp    x23, #0x662f000                            
02cd7b10: ldrb    w8, [x23, #0xbdd]                          
02cd7b14: cbz     w8, #0x2cd7b20                             
02cd7b18: cbnz    x20, #0x2cd7b38                            
02cd7b1c: b       #0x2cd7bd8                                 
02cd7b20: adrp    x0, #0x6266000                             
02cd7b24: ldr     x0, [x0, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02cd7b28: bl      #0x2b70db0                                 fn_2b70db0
02cd7b2c: mov     w8, #1                                     
02cd7b30: strb    w8, [x23, #0xbdd]                          
02cd7b34: cbz     x20, #0x2cd7bd8                            
02cd7b38: adrp    x10, #0x6266000                            
02cd7b3c: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02cd7b40: ldr     x10, [x10, #0xcd0]                         T:Cysharp.Threading.Tasks.IUniTaskSource
02cd7b44: ldrh    w9, [x8, #0x12e]                           
02cd7b48: ldr     x1, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cd7b4c: cbz     x9, #0x2cd7b70                             
02cd7b50: ldr     x10, [x8, #0xb0]                           M:Framework.SceneUtils/<CRLoadSceneAsync>d__1::System.Collections.IEnumerator.Reset
02cd7b54: add     x10, x10, #8                               &6266008
02cd7b58: ldur    x11, [x10, #-8]                            
02cd7b5c: cmp     x11, x1                                    
02cd7b60: b.eq    #0x2cd7bb8                                 
02cd7b64: subs    x9, x9, #1                                 
02cd7b68: add     x10, x10, #0x10                            &6266010
02cd7b6c: b.ne    #0x2cd7b58                                 
02cd7b70: mov     x0, x20                                    
02cd7b74: mov     w2, wzr                                    
02cd7b78: bl      #0x2baa05c                                 fn_2baa05c
02cd7b7c: b       #0x2cd7bc4                                 
02cd7b80: ldr     x8, [sp, #0x38]                            
02cd7b84: mov     x0, x19                                    
02cd7b88: str     wzr, [x19]                                 
02cd7b8c: str     x8, [x0, #0x30]!                           
02cd7b90: mov     x1, xzr                                    
02cd7b94: bl      #0x2b70d54                                 fn_2b70d54
02cd7b98: adrp    x8, #0x6267000                             
02cd7b9c: ldr     x8, [x8, #0xa20]                           MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::AwaitUnsafeOnCompleted
02cd7ba0: ldr     x3, [x8]                                   S:'didu'
02cd7ba4: add     x0, x19, #8                                
02cd7ba8: add     x1, sp, #0x38                              
02cd7bac: mov     x2, x19                                    
02cd7bb0: bl      #0x30bcf48                                 fn_30bcf48
02cd7bb4: b       #0x2cd7c90                                 
02cd7bb8: ldrsw   x9, [x10]                                  
02cd7bbc: add     x8, x8, x9, lsl #4                         &6267000
02cd7bc0: add     x0, x8, #0x138                             &6267138
02cd7bc4: ldp     x8, x2, [x0]                               
02cd7bc8: mov     x0, x20                                    
02cd7bcc: mov     w1, w21                                    
02cd7bd0: blr     x8                                         
02cd7bd4: cbz     w0, #0x2cd7ca8                             
02cd7bd8: adrp    x20, #0x662f000                            
02cd7bdc: ldrb    w8, [x20, #0xbde]                          
02cd7be0: cbnz    w8, #0x2cd7bf8                             
02cd7be4: adrp    x0, #0x6266000                             
02cd7be8: ldr     x0, [x0, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02cd7bec: bl      #0x2b70db0                                 fn_2b70db0
02cd7bf0: mov     w8, #1                                     
02cd7bf4: strb    w8, [x20, #0xbde]                          
02cd7bf8: ldr     x20, [sp, #0x10]                           
02cd7bfc: cbz     x20, #0x2cd7c6c                            
02cd7c00: adrp    x10, #0x6266000                            
02cd7c04: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02cd7c08: ldr     x10, [x10, #0xcd0]                         T:Cysharp.Threading.Tasks.IUniTaskSource
02cd7c0c: ldrh    w21, [sp, #0x18]                           
02cd7c10: ldrh    w9, [x8, #0x12e]                           
02cd7c14: ldr     x1, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cd7c18: cbz     x9, #0x2cd7c3c                             
02cd7c1c: ldr     x10, [x8, #0xb0]                           M:Framework.SceneUtils/<CRLoadSceneAsync>d__1::System.Collections.IEnumerator.Reset
02cd7c20: add     x10, x10, #8                               &6266008
02cd7c24: ldur    x11, [x10, #-8]                            
02cd7c28: cmp     x11, x1                                    
02cd7c2c: b.eq    #0x2cd7c4c                                 
02cd7c30: subs    x9, x9, #1                                 
02cd7c34: add     x10, x10, #0x10                            &6266010
02cd7c38: b.ne    #0x2cd7c24                                 
02cd7c3c: mov     x0, x20                                    
02cd7c40: mov     w2, #2                                     
02cd7c44: bl      #0x2baa05c                                 fn_2baa05c
02cd7c48: b       #0x2cd7c5c                                 
02cd7c4c: ldr     w9, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cd7c50: add     w9, w9, #2                                 
02cd7c54: add     x8, x8, w9, sxtw #4                        &6267000
02cd7c58: add     x0, x8, #0x138                             &6267138
02cd7c5c: ldp     x8, x2, [x0]                               
02cd7c60: mov     x0, x20                                    
02cd7c64: mov     w1, w21                                    
02cd7c68: blr     x8                                         
02cd7c6c: cbz     x22, #0x2cd7ce4                            
02cd7c70: ldr     x0, [x22, #0x10]                           
02cd7c74: cbz     x0, #0x2cd7ce8                             
02cd7c78: bl      #0x2cd7554                                 SceneLoader::FadeOut
02cd7c7c: mov     w8, #-2                                    
02cd7c80: mov     x1, xzr                                    
02cd7c84: str     w8, [x19], #8                              
02cd7c88: mov     x0, x19                                    
02cd7c8c: bl      #0x4d43b50                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::SetResult
02cd7c90: ldp     x20, x19, [sp, #0x60]                      
02cd7c94: ldr     x30, [sp, #0x30]                           
02cd7c98: ldp     x22, x21, [sp, #0x50]                      
02cd7c9c: ldp     x24, x23, [sp, #0x40]                      
02cd7ca0: add     sp, sp, #0x70                              
02cd7ca4: ret                                                
02cd7ca8: ldr     q0, [sp, #0x10]                            
02cd7cac: mov     w8, #1                                     
02cd7cb0: str     w8, [x19]                                  
02cd7cb4: stur    q0, [x19, #0x38]                           .<>4__this
02cd7cb8: add     x0, x19, #0x38                             
02cd7cbc: mov     x1, xzr                                    
02cd7cc0: bl      #0x2b70d54                                 fn_2b70d54
02cd7cc4: adrp    x8, #0x6267000                             
02cd7cc8: ldr     x8, [x8, #0xa18]                           MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::AwaitUnsafeOnCompleted
02cd7ccc: ldr     x3, [x8]                                   S:'didu'
02cd7cd0: add     x0, x19, #8                                
02cd7cd4: add     x1, sp, #0x10                              
02cd7cd8: mov     x2, x19                                    
02cd7cdc: bl      #0x30c4f48                                 fn_30c4f48
02cd7ce0: b       #0x2cd7c90                                 
02cd7ce4: bl      #0x2b7105c                                 fn_2b7105c
02cd7ce8: bl      #0x2b7105c                                 fn_2b7105c
02cd7cec: bl      #0x2b7105c                                 fn_2b7105c
02cd7cf0: bl      #0x2b7105c                                 fn_2b7105c
02cd7cf4: bl      #0x2b7105c                                 fn_2b7105c
02cd7cf8: bl      #0x2b7105c                                 fn_2b7105c
02cd7cfc: bl      #0x2b7105c                                 fn_2b7105c
02cd7d00: bl      #0x2b7105c                                 fn_2b7105c
02cd7d04: bl      #0x2b7105c                                 fn_2b7105c
02cd7d08: bl      #0x2b7105c                                 fn_2b7105c
02cd7d0c: bl      #0x2b7105c                                 fn_2b7105c
02cd7d10: bl      #0x2b7105c                                 fn_2b7105c
02cd7d14: b       #0x2cd7d70                                 
02cd7d18: b       #0x2cd7d70                                 
02cd7d1c: b       #0x2cd7d70                                 
02cd7d20: b       #0x2cd7d70                                 
02cd7d24: b       #0x2cd7d70                                 
02cd7d28: b       #0x2cd7d70                                 
02cd7d2c: b       #0x2cd7d70                                 
02cd7d30: b       #0x2cd7d70                                 
02cd7d34: b       #0x2cd7d70                                 
02cd7d38: b       #0x2cd7d70                                 
02cd7d3c: b       #0x2cd7d70                                 
02cd7d40: b       #0x2cd7d70                                 
02cd7d44: b       #0x2cd7d70                                 
02cd7d48: b       #0x2cd7d70                                 
02cd7d4c: b       #0x2cd7d70                                 
02cd7d50: b       #0x2cd7d70                                 
02cd7d54: b       #0x2cd7d70                                 
02cd7d58: b       #0x2cd7d70                                 
02cd7d5c: b       #0x2cd7d70                                 
02cd7d60: b       #0x2cd7d70                                 
02cd7d64: b       #0x2cd7d70                                 
02cd7d68: b       #0x2cd7d70                                 
02cd7d6c: b       #0x2cd7d70                                 
02cd7d70: mov     x20, x0                                    
02cd7d74: cmp     w1, #1                                     
02cd7d78: b.ne    #0x2cd7e08                                 
02cd7d7c: mov     x0, x20                                    
02cd7d80: bl      #0x5e90260                                 fn_5e90260
02cd7d84: mov     x20, x0                                    
02cd7d88: adrp    x0, #0x6263000                             
02cd7d8c: ldr     x0, [x0, #0xae0]                           T:System.Exception
02cd7d90: bl      #0x2b70dc4                                 fn_2b70dc4
02cd7d94: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02cd7d98: ldr     x1, [x8]                                   S:'didu'
02cd7d9c: bl      #0x2b71464                                 fn_2b71464
02cd7da0: tbz     w0, #0, #0x2cd7de0                         
02cd7da4: ldrsw   x21, [sp, #8]                              
02cd7da8: ldr     x20, [x20]                                 &2b706c4(=eb01011ff9400808)
02cd7dac: mov     x8, sp                                     
02cd7db0: str     x20, [x8, x21, lsl #3]                     
02cd7db4: add     w8, w21, #1                                
02cd7db8: str     w8, [sp, #8]                               
02cd7dbc: bl      #0x5e90270                                 fn_5e90270
02cd7dc0: mov     w8, #-2                                    
02cd7dc4: mov     x1, x20                                    
02cd7dc8: mov     x2, xzr                                    
02cd7dcc: str     w8, [x19], #8                              
02cd7dd0: mov     x0, x19                                    
02cd7dd4: bl      #0x4d43cc0                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::SetException
02cd7dd8: str     w21, [sp, #8]                              
02cd7ddc: b       #0x2cd7c90                                 
02cd7de0: mov     w0, #8                                     
02cd7de4: bl      #0x5e90290                                 fn_5e90290
02cd7de8: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02cd7dec: str     x8, [x0]                                   
02cd7df0: adrp    x1, #0x5e96000                             
02cd7df4: add     x1, x1, #0x758                             &5e96758
02cd7df8: mov     x2, xzr                                    
02cd7dfc: bl      #0x5e902a0                                 fn_5e902a0
02cd7e00: mov     x20, x0                                    
02cd7e04: bl      #0x5e90270                                 fn_5e90270
02cd7e08: mov     x0, x20                                    
02cd7e0c: bl      #0x2c6051c                                 fn_2c6051c
02cd7e10: bl      #0x27369b8                                 fn_27369b8
## SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine stateMachine) -> void
---- SceneLoader/<>c__DisplayClass3_0/<<FadeIn>b__0>d::SetStateMachine 0x2cd7e14
02cd7e14: add     x0, x0, #8                                 
02cd7e18: mov     x2, xzr                                    
02cd7e1c: b       #0x4d43a8c                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::SetStateMachine
#### CLASS SceneLoader/<>c__DisplayClass3_0 parent= object
#   field <>4__this                      SceneLoader                                        off=0x10 attr=6 
#   field targetScene                    string                                             off=0x18 attr=6 
## .ctor() -> void
---- SceneLoader/<>c__DisplayClass3_0::.ctor 0x2cd7864
02cd7864: mov     x1, xzr                                    
02cd7868: b       #0x4e53e9c                                 System.Object::.ctor
## <FadeIn>b__0() -> void
---- SceneLoader/<>c__DisplayClass3_0::<FadeIn>b__0 0x2cd786c
02cd786c: sub     sp, sp, #0x90                              
02cd7870: stp     x30, x21, [sp, #0x70]                      
02cd7874: stp     x20, x19, [sp, #0x80]                      
02cd7878: adrp    x21, #0x662f000                            
02cd787c: adrp    x20, #0x6267000                            
02cd7880: mov     x19, x0                                    
02cd7884: ldrb    w8, [x21, #0xd38]                          
02cd7888: ldr     x20, [x20, #0xa10]                         MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::Start
02cd788c: tbnz    w8, #0, #0x2cd78a4                         
02cd7890: adrp    x0, #0x6267000                             
02cd7894: ldr     x0, [x0, #0xa10]                           MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::Start
02cd7898: bl      #0x2b70db0                                 fn_2b70db0
02cd789c: mov     w8, #1                                     
02cd78a0: strb    w8, [x21, #0xd38]                          
02cd78a4: movi    v0.2d, #0000000000000000                   
02cd78a8: mov     x8, sp                                     
02cd78ac: mov     x0, xzr                                    
02cd78b0: str     xzr, [sp, #0x60]                           
02cd78b4: stp     q0, q0, [sp, #0x20]                        
02cd78b8: stp     q0, q0, [sp, #0x40]                        
02cd78bc: bl      #0x4d43a24                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::Create
02cd78c0: ldp     q0, q1, [sp]                               
02cd78c4: add     x21, sp, #0x20                             
02cd78c8: orr     x0, x21, #8                                
02cd78cc: mov     x1, xzr                                    
02cd78d0: stur    q0, [sp, #0x28]                            
02cd78d4: stur    q1, [sp, #0x38]                            
02cd78d8: bl      #0x2b70d54                                 fn_2b70d54
02cd78dc: add     x0, x21, #0x28                             &662f028
02cd78e0: mov     x1, x19                                    
02cd78e4: str     x19, [sp, #0x48]                           
02cd78e8: bl      #0x2b70d54                                 fn_2b70d54
02cd78ec: ldr     x2, [x20]                                  S:'didu'
02cd78f0: mov     w8, #-1                                    
02cd78f4: orr     x0, x21, #8                                
02cd78f8: add     x1, sp, #0x20                              
02cd78fc: str     w8, [sp, #0x20]                            
02cd7900: bl      #0x30c9a24                                 fn_30c9a24
02cd7904: ldp     x20, x19, [sp, #0x80]                      
02cd7908: ldp     x30, x21, [sp, #0x70]                      
02cd790c: add     sp, sp, #0x90                              
02cd7910: ret                                                
#### CLASS SceneLoader/<>c__DisplayClass5_0/<<Translate>b__0>d parent= System.ValueType
#   field <>1__state                     int                                                off=0x10 attr=6 
#   field <>t__builder                   System.Runtime.CompilerServices.AsyncVoidMethodBuilder off=0x18 attr=6 
#   field <>4__this                      SceneLoader/<>c__DisplayClass5_0                   off=0x38 attr=6 
#   field <>u__1                         Cysharp.Threading.Tasks.UniTask/Awaiter            off=0x40 attr=1 
## MoveNext() -> void
---- SceneLoader/<>c__DisplayClass5_0/<<Translate>b__0>d::MoveNext 0x2cd7ec4
02cd7ec4: sub     sp, sp, #0x70                              
02cd7ec8: str     x30, [sp, #0x30]                           
02cd7ecc: stp     x24, x23, [sp, #0x40]                      
02cd7ed0: stp     x22, x21, [sp, #0x50]                      
02cd7ed4: stp     x20, x19, [sp, #0x60]                      
02cd7ed8: adrp    x20, #0x662f000                            
02cd7edc: mov     x19, x0                                    
02cd7ee0: ldrb    w8, [x20, #0xd3b]                          
02cd7ee4: tbnz    w8, #0, #0x2cd7f08                         
02cd7ee8: adrp    x0, #0x6267000                             
02cd7eec: ldr     x0, [x0, #0xa48]                           MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::AwaitUnsafeOnCompleted
02cd7ef0: bl      #0x2b70db0                                 fn_2b70db0
02cd7ef4: adrp    x0, #0x6266000                             
02cd7ef8: ldr     x0, [x0, #0xcc8]                           T:Cysharp.Threading.Tasks.UniTask
02cd7efc: bl      #0x2b70db0                                 fn_2b70db0
02cd7f00: mov     w8, #1                                     
02cd7f04: strb    w8, [x20, #0xd3b]                          
02cd7f08: adrp    x24, #0x6266000                            
02cd7f0c: adrp    x23, #0x662f000                            
02cd7f10: ldr     x24, [x24, #0xcc8]                         T:Cysharp.Threading.Tasks.UniTask
02cd7f14: ldr     w8, [x19]                                  
02cd7f18: ldr     x22, [x19, #0x28]                          
02cd7f1c: stp     xzr, xzr, [sp, #0x10]                      
02cd7f20: str     wzr, [sp, #8]                              
02cd7f24: cbz     w8, #0x2cd7f48                             
02cd7f28: cmp     w8, #1                                     
02cd7f2c: b.ne    #0x2cd7f60                                 
02cd7f30: ldr     q0, [x19, #0x30]                           
02cd7f34: mov     w8, #-1                                    
02cd7f38: stp     xzr, xzr, [x19, #0x30]                     
02cd7f3c: str     w8, [x19]                                  
02cd7f40: str     q0, [sp, #0x10]                            
02cd7f44: b       #0x2cd8290                                 
02cd7f48: ldr     q0, [x19, #0x30]                           
02cd7f4c: mov     w8, #-1                                    
02cd7f50: stp     xzr, xzr, [x19, #0x30]                     
02cd7f54: str     w8, [x19]                                  
02cd7f58: str     q0, [sp, #0x10]                            
02cd7f5c: b       #0x2cd80bc                                 
02cd7f60: cbz     x22, #0x2cd8400                            
02cd7f64: ldr     x8, [x22, #0x10]                           
02cd7f68: cbz     x8, #0x2cd7f7c                             
02cd7f6c: ldr     x0, [x8, #0x40]                            
02cd7f70: ldr     x1, [x8, #0x28]                            
02cd7f74: ldr     x9, [x8, #0x18]                            
02cd7f78: blr     x9                                         
02cd7f7c: ldr     x8, [x22, #0x18]                           
02cd7f80: cbz     x8, #0x2cd8404                             
02cd7f84: ldr     x0, [x8, #0x20]                            
02cd7f88: cbz     x0, #0x2cd8408                             
02cd7f8c: mov     w1, wzr                                    
02cd7f90: mov     x2, xzr                                    
02cd7f94: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cd7f98: ldr     x8, [x22, #0x18]                           
02cd7f9c: cbz     x8, #0x2cd840c                             
02cd7fa0: ldr     x0, [x8, #0x30]                            
02cd7fa4: cbz     x0, #0x2cd8410                             
02cd7fa8: mov     w1, #1                                     
02cd7fac: mov     x2, xzr                                    
02cd7fb0: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cd7fb4: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cd7fb8: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02cd7fbc: cbnz    w8, #0x2cd7fc4                             
02cd7fc0: bl      #0x2b70f30                                 fn_2b70f30
02cd7fc4: fmov    s0, #0.50000000                            
02cd7fc8: mov     w0, wzr                                    
02cd7fcc: mov     w1, #8                                     
02cd7fd0: mov     x2, xzr                                    
02cd7fd4: mov     w3, wzr                                    
02cd7fd8: mov     x4, xzr                                    
02cd7fdc: bl      #0x5447b08                                 Cysharp.Threading.Tasks.UniTask::WaitForSeconds
02cd7fe0: stp     x0, x1, [sp, #0x20]                        
02cd7fe4: add     x0, sp, #0x20                              
02cd7fe8: mov     x1, xzr                                    
02cd7fec: bl      #0x2b70d54                                 fn_2b70d54
02cd7ff0: adrp    x20, #0x662f000                            
02cd7ff4: ldr     q0, [sp, #0x20]                            
02cd7ff8: ldrb    w8, [x20, #0xbdc]                          
02cd7ffc: str     q0, [sp, #0x10]                            
02cd8000: cbnz    w8, #0x2cd8018                             
02cd8004: adrp    x0, #0x6266000                             
02cd8008: ldr     x0, [x0, #0xcc8]                           T:Cysharp.Threading.Tasks.UniTask
02cd800c: bl      #0x2b70db0                                 fn_2b70db0
02cd8010: mov     w8, #1                                     
02cd8014: strb    w8, [x20, #0xbdc]                          
02cd8018: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cd801c: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02cd8020: cbnz    w8, #0x2cd8028                             
02cd8024: bl      #0x2b70f30                                 fn_2b70f30
02cd8028: adrp    x20, #0x662f000                            
02cd802c: ldrb    w8, [x20, #0xbdd]                          
02cd8030: cbnz    w8, #0x2cd8048                             
02cd8034: adrp    x0, #0x6266000                             
02cd8038: ldr     x0, [x0, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02cd803c: bl      #0x2b70db0                                 fn_2b70db0
02cd8040: mov     w8, #1                                     
02cd8044: strb    w8, [x20, #0xbdd]                          
02cd8048: ldr     x20, [sp, #0x10]                           
02cd804c: cbz     x20, #0x2cd80bc                            
02cd8050: adrp    x10, #0x6266000                            
02cd8054: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02cd8058: ldr     x10, [x10, #0xcd0]                         T:Cysharp.Threading.Tasks.IUniTaskSource
02cd805c: ldrh    w21, [sp, #0x18]                           
02cd8060: ldrh    w9, [x8, #0x12e]                           
02cd8064: ldr     x1, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cd8068: cbz     x9, #0x2cd808c                             
02cd806c: ldr     x10, [x8, #0xb0]                           
02cd8070: add     x10, x10, #8                               &6266008
02cd8074: ldur    x11, [x10, #-8]                            
02cd8078: cmp     x11, x1                                    
02cd807c: b.eq    #0x2cd809c                                 
02cd8080: subs    x9, x9, #1                                 
02cd8084: add     x10, x10, #0x10                            &6266010
02cd8088: b.ne    #0x2cd8074                                 
02cd808c: mov     x0, x20                                    
02cd8090: mov     w2, wzr                                    
02cd8094: bl      #0x2baa05c                                 fn_2baa05c
02cd8098: b       #0x2cd80a8                                 
02cd809c: ldrsw   x9, [x10]                                  
02cd80a0: add     x8, x8, x9, lsl #4                         
02cd80a4: add     x0, x8, #0x138                             
02cd80a8: ldp     x8, x2, [x0]                               
02cd80ac: mov     x0, x20                                    
02cd80b0: mov     w1, w21                                    
02cd80b4: blr     x8                                         
02cd80b8: cbz     w0, #0x2cd83a8                             
02cd80bc: ldrb    w8, [x23, #0xbde]                          
02cd80c0: cbnz    w8, #0x2cd80d8                             
02cd80c4: adrp    x0, #0x6266000                             
02cd80c8: ldr     x0, [x0, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02cd80cc: bl      #0x2b70db0                                 fn_2b70db0
02cd80d0: mov     w8, #1                                     
02cd80d4: strb    w8, [x23, #0xbde]                          
02cd80d8: ldr     x20, [sp, #0x10]                           
02cd80dc: cbz     x20, #0x2cd814c                            
02cd80e0: adrp    x10, #0x6266000                            
02cd80e4: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02cd80e8: ldr     x10, [x10, #0xcd0]                         T:Cysharp.Threading.Tasks.IUniTaskSource
02cd80ec: ldrh    w21, [sp, #0x18]                           
02cd80f0: ldrh    w9, [x8, #0x12e]                           
02cd80f4: ldr     x1, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cd80f8: cbz     x9, #0x2cd811c                             
02cd80fc: ldr     x10, [x8, #0xb0]                           
02cd8100: add     x10, x10, #8                               &6266008
02cd8104: ldur    x11, [x10, #-8]                            
02cd8108: cmp     x11, x1                                    
02cd810c: b.eq    #0x2cd812c                                 
02cd8110: subs    x9, x9, #1                                 
02cd8114: add     x10, x10, #0x10                            &6266010
02cd8118: b.ne    #0x2cd8104                                 
02cd811c: mov     x0, x20                                    
02cd8120: mov     w2, #2                                     
02cd8124: bl      #0x2baa05c                                 fn_2baa05c
02cd8128: b       #0x2cd813c                                 
02cd812c: ldr     w9, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cd8130: add     w9, w9, #2                                 
02cd8134: add     x8, x8, w9, sxtw #4                        
02cd8138: add     x0, x8, #0x138                             
02cd813c: ldp     x8, x2, [x0]                               
02cd8140: mov     x0, x20                                    
02cd8144: mov     w1, w21                                    
02cd8148: blr     x8                                         
02cd814c: cbz     x22, #0x2cd83ec                            
02cd8150: ldr     x8, [x22, #0x18]                           
02cd8154: cbz     x8, #0x2cd83f0                             
02cd8158: ldr     x0, [x8, #0x30]                            
02cd815c: cbz     x0, #0x2cd83f4                             
02cd8160: mov     w1, wzr                                    
02cd8164: mov     x2, xzr                                    
02cd8168: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cd816c: ldr     x8, [x22, #0x18]                           
02cd8170: cbz     x8, #0x2cd83f8                             
02cd8174: ldr     x0, [x8, #0x28]                            
02cd8178: cbz     x0, #0x2cd83fc                             
02cd817c: mov     w1, #1                                     
02cd8180: mov     x2, xzr                                    
02cd8184: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cd8188: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cd818c: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02cd8190: cbnz    w8, #0x2cd8198                             
02cd8194: bl      #0x2b70f30                                 fn_2b70f30
02cd8198: fmov    s0, #0.50000000                            
02cd819c: mov     w0, wzr                                    
02cd81a0: mov     w1, #8                                     
02cd81a4: mov     x2, xzr                                    
02cd81a8: mov     w3, wzr                                    
02cd81ac: mov     x4, xzr                                    
02cd81b0: bl      #0x5447b08                                 Cysharp.Threading.Tasks.UniTask::WaitForSeconds
02cd81b4: stp     x0, x1, [sp, #0x20]                        
02cd81b8: add     x0, sp, #0x20                              
02cd81bc: mov     x1, xzr                                    
02cd81c0: bl      #0x2b70d54                                 fn_2b70d54
02cd81c4: adrp    x20, #0x662f000                            
02cd81c8: ldr     q0, [sp, #0x20]                            
02cd81cc: ldrb    w8, [x20, #0xbdc]                          
02cd81d0: str     q0, [sp, #0x10]                            
02cd81d4: cbnz    w8, #0x2cd81ec                             
02cd81d8: adrp    x0, #0x6266000                             
02cd81dc: ldr     x0, [x0, #0xcc8]                           T:Cysharp.Threading.Tasks.UniTask
02cd81e0: bl      #0x2b70db0                                 fn_2b70db0
02cd81e4: mov     w8, #1                                     
02cd81e8: strb    w8, [x20, #0xbdc]                          
02cd81ec: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cd81f0: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02cd81f4: cbnz    w8, #0x2cd81fc                             
02cd81f8: bl      #0x2b70f30                                 fn_2b70f30
02cd81fc: adrp    x20, #0x662f000                            
02cd8200: ldrb    w8, [x20, #0xbdd]                          
02cd8204: cbnz    w8, #0x2cd821c                             
02cd8208: adrp    x0, #0x6266000                             
02cd820c: ldr     x0, [x0, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02cd8210: bl      #0x2b70db0                                 fn_2b70db0
02cd8214: mov     w8, #1                                     
02cd8218: strb    w8, [x20, #0xbdd]                          
02cd821c: ldr     x20, [sp, #0x10]                           
02cd8220: cbz     x20, #0x2cd8290                            
02cd8224: adrp    x10, #0x6266000                            
02cd8228: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02cd822c: ldr     x10, [x10, #0xcd0]                         T:Cysharp.Threading.Tasks.IUniTaskSource
02cd8230: ldrh    w21, [sp, #0x18]                           
02cd8234: ldrh    w9, [x8, #0x12e]                           
02cd8238: ldr     x1, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cd823c: cbz     x9, #0x2cd8260                             
02cd8240: ldr     x10, [x8, #0xb0]                           
02cd8244: add     x10, x10, #8                               &6266008
02cd8248: ldur    x11, [x10, #-8]                            
02cd824c: cmp     x11, x1                                    
02cd8250: b.eq    #0x2cd8270                                 
02cd8254: subs    x9, x9, #1                                 
02cd8258: add     x10, x10, #0x10                            &6266010
02cd825c: b.ne    #0x2cd8248                                 
02cd8260: mov     x0, x20                                    
02cd8264: mov     w2, wzr                                    
02cd8268: bl      #0x2baa05c                                 fn_2baa05c
02cd826c: b       #0x2cd827c                                 
02cd8270: ldrsw   x9, [x10]                                  
02cd8274: add     x8, x8, x9, lsl #4                         
02cd8278: add     x0, x8, #0x138                             
02cd827c: ldp     x8, x2, [x0]                               
02cd8280: mov     x0, x20                                    
02cd8284: mov     w1, w21                                    
02cd8288: blr     x8                                         
02cd828c: cbz     w0, #0x2cd836c                             
02cd8290: ldrb    w8, [x23, #0xbde]                          
02cd8294: cbnz    w8, #0x2cd82ac                             
02cd8298: adrp    x0, #0x6266000                             
02cd829c: ldr     x0, [x0, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02cd82a0: bl      #0x2b70db0                                 fn_2b70db0
02cd82a4: mov     w8, #1                                     
02cd82a8: strb    w8, [x23, #0xbde]                          
02cd82ac: ldr     x20, [sp, #0x10]                           
02cd82b0: cbz     x20, #0x2cd8320                            
02cd82b4: adrp    x10, #0x6266000                            
02cd82b8: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02cd82bc: ldr     x10, [x10, #0xcd0]                         T:Cysharp.Threading.Tasks.IUniTaskSource
02cd82c0: ldrh    w21, [sp, #0x18]                           
02cd82c4: ldrh    w9, [x8, #0x12e]                           
02cd82c8: ldr     x1, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cd82cc: cbz     x9, #0x2cd82f0                             
02cd82d0: ldr     x10, [x8, #0xb0]                           
02cd82d4: add     x10, x10, #8                               &6266008
02cd82d8: ldur    x11, [x10, #-8]                            
02cd82dc: cmp     x11, x1                                    
02cd82e0: b.eq    #0x2cd8300                                 
02cd82e4: subs    x9, x9, #1                                 
02cd82e8: add     x10, x10, #0x10                            &6266010
02cd82ec: b.ne    #0x2cd82d8                                 
02cd82f0: mov     x0, x20                                    
02cd82f4: mov     w2, #2                                     
02cd82f8: bl      #0x2baa05c                                 fn_2baa05c
02cd82fc: b       #0x2cd8310                                 
02cd8300: ldr     w9, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cd8304: add     w9, w9, #2                                 
02cd8308: add     x8, x8, w9, sxtw #4                        
02cd830c: add     x0, x8, #0x138                             
02cd8310: ldp     x8, x2, [x0]                               
02cd8314: mov     x0, x20                                    
02cd8318: mov     w1, w21                                    
02cd831c: blr     x8                                         
02cd8320: cbz     x22, #0x2cd83e0                            
02cd8324: ldr     x8, [x22, #0x18]                           
02cd8328: cbz     x8, #0x2cd83e4                             
02cd832c: ldr     x0, [x8, #0x28]                            
02cd8330: cbz     x0, #0x2cd83e8                             
02cd8334: mov     w1, wzr                                    
02cd8338: mov     x2, xzr                                    
02cd833c: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cd8340: mov     w8, #-2                                    
02cd8344: mov     x1, xzr                                    
02cd8348: str     w8, [x19], #8                              
02cd834c: mov     x0, x19                                    
02cd8350: bl      #0x4d43b50                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::SetResult
02cd8354: ldp     x20, x19, [sp, #0x60]                      
02cd8358: ldr     x30, [sp, #0x30]                           
02cd835c: ldp     x22, x21, [sp, #0x50]                      
02cd8360: ldp     x24, x23, [sp, #0x40]                      
02cd8364: add     sp, sp, #0x70                              
02cd8368: ret                                                
02cd836c: ldr     q0, [sp, #0x10]                            
02cd8370: mov     w8, #1                                     
02cd8374: str     w8, [x19]                                  
02cd8378: str     q0, [x19, #0x30]                           
02cd837c: add     x0, x19, #0x30                             
02cd8380: mov     x1, xzr                                    
02cd8384: bl      #0x2b70d54                                 fn_2b70d54
02cd8388: adrp    x8, #0x6267000                             
02cd838c: ldr     x8, [x8, #0xa48]                           MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::AwaitUnsafeOnCompleted
02cd8390: ldr     x3, [x8]                                   S:'didu'
02cd8394: add     x0, x19, #8                                
02cd8398: add     x1, sp, #0x10                              
02cd839c: mov     x2, x19                                    
02cd83a0: bl      #0x30c51b8                                 fn_30c51b8
02cd83a4: b       #0x2cd8354                                 
02cd83a8: ldr     q0, [sp, #0x10]                            
02cd83ac: str     wzr, [x19]                                 
02cd83b0: str     q0, [x19, #0x30]                           
02cd83b4: add     x0, x19, #0x30                             
02cd83b8: mov     x1, xzr                                    
02cd83bc: bl      #0x2b70d54                                 fn_2b70d54
02cd83c0: adrp    x8, #0x6267000                             
02cd83c4: ldr     x8, [x8, #0xa48]                           MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::AwaitUnsafeOnCompleted
02cd83c8: ldr     x3, [x8]                                   S:'didu'
02cd83cc: add     x0, x19, #8                                
02cd83d0: add     x1, sp, #0x10                              
02cd83d4: mov     x2, x19                                    
02cd83d8: bl      #0x30c51b8                                 fn_30c51b8
02cd83dc: b       #0x2cd8354                                 
02cd83e0: bl      #0x2b7105c                                 fn_2b7105c
02cd83e4: bl      #0x2b7105c                                 fn_2b7105c
02cd83e8: bl      #0x2b7105c                                 fn_2b7105c
02cd83ec: bl      #0x2b7105c                                 fn_2b7105c
02cd83f0: bl      #0x2b7105c                                 fn_2b7105c
02cd83f4: bl      #0x2b7105c                                 fn_2b7105c
02cd83f8: bl      #0x2b7105c                                 fn_2b7105c
02cd83fc: bl      #0x2b7105c                                 fn_2b7105c
02cd8400: bl      #0x2b7105c                                 fn_2b7105c
02cd8404: bl      #0x2b7105c                                 fn_2b7105c
02cd8408: bl      #0x2b7105c                                 fn_2b7105c
02cd840c: bl      #0x2b7105c                                 fn_2b7105c
02cd8410: bl      #0x2b7105c                                 fn_2b7105c
02cd8414: b       #0x2cd8478                                 
02cd8418: b       #0x2cd8478                                 
02cd841c: b       #0x2cd8478                                 
02cd8420: b       #0x2cd8478                                 
02cd8424: b       #0x2cd8478                                 
02cd8428: b       #0x2cd8478                                 
02cd842c: b       #0x2cd8478                                 
02cd8430: b       #0x2cd8478                                 
02cd8434: b       #0x2cd8478                                 
02cd8438: b       #0x2cd8478                                 
02cd843c: b       #0x2cd8478                                 
02cd8440: b       #0x2cd8478                                 
02cd8444: b       #0x2cd8478                                 
02cd8448: b       #0x2cd8478                                 
02cd844c: b       #0x2cd8478                                 
02cd8450: b       #0x2cd8478                                 
02cd8454: b       #0x2cd8478                                 
02cd8458: b       #0x2cd8478                                 
02cd845c: b       #0x2cd8478                                 
02cd8460: b       #0x2cd8478                                 
02cd8464: b       #0x2cd8478                                 
02cd8468: b       #0x2cd8478                                 
02cd846c: b       #0x2cd8478                                 
02cd8470: b       #0x2cd8478                                 
02cd8474: b       #0x2cd8478                                 
02cd8478: mov     x20, x0                                    
02cd847c: cmp     w1, #1                                     
02cd8480: b.ne    #0x2cd8510                                 
02cd8484: mov     x0, x20                                    
02cd8488: bl      #0x5e90260                                 fn_5e90260
02cd848c: mov     x20, x0                                    
02cd8490: adrp    x0, #0x6263000                             
02cd8494: ldr     x0, [x0, #0xae0]                           T:System.Exception
02cd8498: bl      #0x2b70dc4                                 fn_2b70dc4
02cd849c: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02cd84a0: ldr     x1, [x8]                                   S:'didu'
02cd84a4: bl      #0x2b71464                                 fn_2b71464
02cd84a8: tbz     w0, #0, #0x2cd84e8                         
02cd84ac: ldrsw   x21, [sp, #8]                              
02cd84b0: ldr     x20, [x20]                                 &2b706c4(=eb01011ff9400808)
02cd84b4: mov     x8, sp                                     
02cd84b8: str     x20, [x8, x21, lsl #3]                     
02cd84bc: add     w8, w21, #1                                
02cd84c0: str     w8, [sp, #8]                               
02cd84c4: bl      #0x5e90270                                 fn_5e90270
02cd84c8: mov     w8, #-2                                    
02cd84cc: mov     x1, x20                                    
02cd84d0: mov     x2, xzr                                    
02cd84d4: str     w8, [x19], #8                              
02cd84d8: mov     x0, x19                                    
02cd84dc: bl      #0x4d43cc0                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::SetException
02cd84e0: str     w21, [sp, #8]                              
02cd84e4: b       #0x2cd8354                                 
02cd84e8: mov     w0, #8                                     
02cd84ec: bl      #0x5e90290                                 fn_5e90290
02cd84f0: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02cd84f4: str     x8, [x0]                                   
02cd84f8: adrp    x1, #0x5e96000                             
02cd84fc: add     x1, x1, #0x758                             &5e96758
02cd8500: mov     x2, xzr                                    
02cd8504: bl      #0x5e902a0                                 fn_5e902a0
02cd8508: mov     x20, x0                                    
02cd850c: bl      #0x5e90270                                 fn_5e90270
02cd8510: mov     x0, x20                                    
02cd8514: bl      #0x2c6051c                                 fn_2c6051c
02cd8518: bl      #0x27369b8                                 fn_27369b8
## SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine stateMachine) -> void
---- SceneLoader/<>c__DisplayClass5_0/<<Translate>b__0>d::SetStateMachine 0x2cd851c
02cd851c: add     x0, x0, #8                                 
02cd8520: mov     x2, xzr                                    
02cd8524: b       #0x4d43a8c                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::SetStateMachine
#### CLASS SceneLoader/<>c__DisplayClass5_0 parent= object
#   field onComplete                     System.Action                                      off=0x10 attr=6 
#   field <>4__this                      SceneLoader                                        off=0x18 attr=6 
## .ctor() -> void
---- SceneLoader/<>c__DisplayClass5_0::.ctor 0x2cd76f0
02cd76f0: mov     x1, xzr                                    
02cd76f4: b       #0x4e53e9c                                 System.Object::.ctor
## <Translate>b__0() -> void
---- SceneLoader/<>c__DisplayClass5_0::<Translate>b__0 0x2cd7e20
02cd7e20: sub     sp, sp, #0x80                              
02cd7e24: stp     x30, x21, [sp, #0x60]                      
02cd7e28: stp     x20, x19, [sp, #0x70]                      
02cd7e2c: adrp    x21, #0x662f000                            
02cd7e30: adrp    x20, #0x6267000                            
02cd7e34: mov     x19, x0                                    
02cd7e38: ldrb    w8, [x21, #0xd3a]                          
02cd7e3c: ldr     x20, [x20, #0xa40]                         MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::Start
02cd7e40: tbnz    w8, #0, #0x2cd7e58                         
02cd7e44: adrp    x0, #0x6267000                             
02cd7e48: ldr     x0, [x0, #0xa40]                           MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::Start
02cd7e4c: bl      #0x2b70db0                                 fn_2b70db0
02cd7e50: mov     w8, #1                                     
02cd7e54: strb    w8, [x21, #0xd3a]                          
02cd7e58: movi    v0.2d, #0000000000000000                   
02cd7e5c: mov     x8, sp                                     
02cd7e60: mov     x0, xzr                                    
02cd7e64: stp     q0, q0, [sp, #0x20]                        
02cd7e68: stp     q0, q0, [sp, #0x40]                        
02cd7e6c: bl      #0x4d43a24                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::Create
02cd7e70: ldp     q0, q1, [sp]                               
02cd7e74: add     x21, sp, #0x20                             
02cd7e78: orr     x0, x21, #8                                
02cd7e7c: mov     x1, xzr                                    
02cd7e80: stur    q0, [sp, #0x28]                            
02cd7e84: stur    q1, [sp, #0x38]                            
02cd7e88: bl      #0x2b70d54                                 fn_2b70d54
02cd7e8c: add     x0, x21, #0x28                             &662f028
02cd7e90: mov     x1, x19                                    
02cd7e94: str     x19, [sp, #0x48]                           
02cd7e98: bl      #0x2b70d54                                 fn_2b70d54
02cd7e9c: ldr     x2, [x20]                                  S:'didu'
02cd7ea0: mov     w8, #-1                                    
02cd7ea4: orr     x0, x21, #8                                
02cd7ea8: add     x1, sp, #0x20                              
02cd7eac: str     w8, [sp, #0x20]                            
02cd7eb0: bl      #0x30c9b18                                 fn_30c9b18
02cd7eb4: ldp     x20, x19, [sp, #0x70]                      
02cd7eb8: ldp     x30, x21, [sp, #0x60]                      
02cd7ebc: add     sp, sp, #0x80                              
02cd7ec0: ret                                                
#### CLASS SceneLoader/<>c__DisplayClass6_0 parent= object
#   field screen                         UnityEngine.AsyncOperation                         off=0x10 attr=6 
## .ctor() -> void
---- SceneLoader/<>c__DisplayClass6_0::.ctor 0x2cd8528
02cd8528: mov     x1, xzr                                    
02cd852c: b       #0x4e53e9c                                 System.Object::.ctor
## <LoadScene>b__0() -> bool
---- SceneLoader/<>c__DisplayClass6_0::<LoadScene>b__0 0x2cd8530
02cd8530: str     x30, [sp, #-0x10]!                         
02cd8534: ldr     x0, [x0, #0x10]                            .screen
02cd8538: cbz     x0, #0x2cd855c                             
02cd853c: mov     x1, xzr                                    
02cd8540: bl      #0x5b2f3f0                                 UnityEngine.AsyncOperation::get_progress
02cd8544: adrp    x8, #0x1084000                             
02cd8548: ldr     s1, [x8, #0xbd4]                           [1084bd4]=440980003f666666 f=0.9,550
02cd854c: fcmp    s0, s1                                     
02cd8550: cset    w0, ge                                     
02cd8554: ldr     x30, [sp], #0x10                           
02cd8558: ret                                                
02cd855c: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS SceneLoader/<FadeIn>d__3 parent= System.ValueType
#   field <>1__state                     int                                                off=0x10 attr=6 
#   field <>t__builder                   System.Runtime.CompilerServices.AsyncVoidMethodBuilder off=0x18 attr=6 
#   field <>4__this                      SceneLoader                                        off=0x38 attr=6 
#   field targetScene                    string                                             off=0x40 attr=6 
#   field <>u__1                         System.Runtime.CompilerServices.TaskAwaiter`1<UnityEngine.AsyncOperation> off=0x48 attr=1 
## MoveNext() -> void
---- SceneLoader/<FadeIn>d__3::MoveNext 0x2cd8560
02cd8560: sub     sp, sp, #0x40                              
02cd8564: stp     x30, x21, [sp, #0x20]                      
02cd8568: stp     x20, x19, [sp, #0x30]                      
02cd856c: adrp    x20, #0x662f000                            
02cd8570: mov     x19, x0                                    
02cd8574: ldrb    w8, [x20, #0xd3c]                          
02cd8578: tbnz    w8, #0, #0x2cd85c0                         
02cd857c: adrp    x0, #0x6267000                             
02cd8580: ldr     x0, [x0, #0xa50]                           MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::AwaitUnsafeOnCompleted
02cd8584: bl      #0x2b70db0                                 fn_2b70db0
02cd8588: adrp    x0, #0x6267000                             
02cd858c: ldr     x0, [x0, #0xa28]                           MS:System.Runtime.CompilerServices.TaskAwaiter`1::GetResult
02cd8590: bl      #0x2b70db0                                 fn_2b70db0
02cd8594: adrp    x0, #0x6267000                             
02cd8598: ldr     x0, [x0, #0xa30]                           MS:System.Runtime.CompilerServices.TaskAwaiter`1::get_IsCompleted
02cd859c: bl      #0x2b70db0                                 fn_2b70db0
02cd85a0: adrp    x0, #0x6267000                             
02cd85a4: ldr     x0, [x0, #0xa38]                           MS:System.Threading.Tasks.Task`1::GetAwaiter
02cd85a8: bl      #0x2b70db0                                 fn_2b70db0
02cd85ac: adrp    x0, #0x6267000                             
02cd85b0: ldr     x0, [x0, #0xa58]                           T:SceneLoader/<>c__DisplayClass3_0
02cd85b4: bl      #0x2b70db0                                 fn_2b70db0
02cd85b8: mov     w8, #1                                     
02cd85bc: strb    w8, [x20, #0xd3c]                          
02cd85c0: ldr     w8, [x19]                                  
02cd85c4: str     xzr, [sp, #0x18]                           
02cd85c8: str     wzr, [sp, #0x10]                           
02cd85cc: cbz     w8, #0x2cd8688                             
02cd85d0: adrp    x8, #0x6267000                             
02cd85d4: ldr     x8, [x8, #0xa58]                           T:SceneLoader/<>c__DisplayClass3_0
02cd85d8: ldr     x21, [x19, #0x28]                          
02cd85dc: ldr     x0, [x8]                                   S:'didu'
02cd85e0: bl      #0x2b7104c                                 fn_2b7104c
02cd85e4: mov     x1, xzr                                    
02cd85e8: mov     x20, x0                                    
02cd85ec: bl      #0x4e53e9c                                 System.Object::.ctor
02cd85f0: cbz     x20, #0x2cd86e8                            
02cd85f4: ldr     x1, [x19, #0x28]                           
02cd85f8: mov     x0, x20                                    
02cd85fc: str     x1, [x0, #0x10]!                           .<>1__state
02cd8600: bl      #0x2b70d54                                 fn_2b70d54
02cd8604: ldr     x1, [x19, #0x30]                           
02cd8608: str     x1, [x20, #0x18]!                          .<>t__builder
02cd860c: mov     x0, x20                                    
02cd8610: bl      #0x2b70d54                                 fn_2b70d54
02cd8614: cbz     x21, #0x2cd86ec                            
02cd8618: ldr     x1, [x20]                                  &2b706c4(=eb01011ff9400808)
02cd861c: bl      #0x2cd76f8                                 SceneLoader::LoadScene
02cd8620: cbz     x0, #0x2cd86f0                             
02cd8624: adrp    x8, #0x6267000                             
02cd8628: ldr     x8, [x8, #0xa38]                           MS:System.Threading.Tasks.Task`1::GetAwaiter
02cd862c: ldr     x1, [x8]                                   S:'didu'
02cd8630: bl      #0x3d3e4e4                                 fn_3d3e4e4
02cd8634: adrp    x8, #0x6267000                             
02cd8638: ldr     x8, [x8, #0xa30]                           MS:System.Runtime.CompilerServices.TaskAwaiter`1::get_IsCompleted
02cd863c: str     x0, [sp, #0x18]                            
02cd8640: ldr     x1, [x8]                                   S:'didu'
02cd8644: add     x0, sp, #0x18                              
02cd8648: bl      #0x3cbe788                                 fn_3cbe788
02cd864c: tbnz    w0, #0, #0x2cd869c                         
02cd8650: ldr     x8, [sp, #0x18]                            
02cd8654: mov     x0, x19                                    
02cd8658: str     wzr, [x19]                                 
02cd865c: str     x8, [x0, #0x38]!                           .<>4__this
02cd8660: mov     x1, xzr                                    
02cd8664: bl      #0x2b70d54                                 fn_2b70d54
02cd8668: adrp    x8, #0x6267000                             
02cd866c: ldr     x8, [x8, #0xa50]                           MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::AwaitUnsafeOnCompleted
02cd8670: ldr     x3, [x8]                                   S:'didu'
02cd8674: add     x0, x19, #8                                
02cd8678: add     x1, sp, #0x18                              
02cd867c: mov     x2, x19                                    
02cd8680: bl      #0x30bc7f0                                 fn_30bc7f0
02cd8684: b       #0x2cd86d4                                 
02cd8688: ldr     x8, [x19, #0x38]                           .<>4__this
02cd868c: mov     w9, #-1                                    
02cd8690: str     xzr, [x19, #0x38]                          .<>4__this
02cd8694: str     w9, [x19]                                  
02cd8698: str     x8, [sp, #0x18]                            
02cd869c: adrp    x8, #0x6267000                             
02cd86a0: ldr     x8, [x8, #0xa28]                           MS:System.Runtime.CompilerServices.TaskAwaiter`1::GetResult
02cd86a4: ldr     x1, [x8]                                   S:'didu'
02cd86a8: add     x0, sp, #0x18                              
02cd86ac: bl      #0x3cbe7c8                                 fn_3cbe7c8
02cd86b0: cbz     x0, #0x2cd86e4                             
02cd86b4: mov     w1, #1                                     
02cd86b8: mov     x2, xzr                                    
02cd86bc: bl      #0x5b2f47c                                 UnityEngine.AsyncOperation::set_allowSceneActivation
02cd86c0: mov     w8, #-2                                    
02cd86c4: mov     x1, xzr                                    
02cd86c8: str     w8, [x19], #8                              
02cd86cc: mov     x0, x19                                    
02cd86d0: bl      #0x4d43b50                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::SetResult
02cd86d4: ldp     x20, x19, [sp, #0x30]                      
02cd86d8: ldp     x30, x21, [sp, #0x20]                      
02cd86dc: add     sp, sp, #0x40                              
02cd86e0: ret                                                
02cd86e4: bl      #0x2b7105c                                 fn_2b7105c
02cd86e8: bl      #0x2b7105c                                 fn_2b7105c
02cd86ec: bl      #0x2b7105c                                 fn_2b7105c
02cd86f0: bl      #0x2b7105c                                 fn_2b7105c
02cd86f4: b       #0x2cd8718                                 
02cd86f8: b       #0x2cd8718                                 
02cd86fc: b       #0x2cd8718                                 
02cd8700: b       #0x2cd8718                                 
02cd8704: b       #0x2cd8718                                 
02cd8708: b       #0x2cd8718                                 
02cd870c: b       #0x2cd8718                                 
02cd8710: b       #0x2cd8718                                 
02cd8714: b       #0x2cd8718                                 
02cd8718: mov     x20, x0                                    
02cd871c: cmp     w1, #1                                     
02cd8720: b.ne    #0x2cd87b0                                 
02cd8724: mov     x0, x20                                    
02cd8728: bl      #0x5e90260                                 fn_5e90260
02cd872c: mov     x20, x0                                    
02cd8730: adrp    x0, #0x6263000                             
02cd8734: ldr     x0, [x0, #0xae0]                           T:System.Exception
02cd8738: bl      #0x2b70dc4                                 fn_2b70dc4
02cd873c: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02cd8740: ldr     x1, [x8]                                   S:'didu'
02cd8744: bl      #0x2b71464                                 fn_2b71464
02cd8748: tbz     w0, #0, #0x2cd8788                         
02cd874c: ldrsw   x21, [sp, #0x10]                           
02cd8750: ldr     x20, [x20]                                 &2b706c4(=eb01011ff9400808)
02cd8754: add     x8, sp, #8                                 
02cd8758: str     x20, [x8, x21, lsl #3]                     
02cd875c: add     w8, w21, #1                                
02cd8760: str     w8, [sp, #0x10]                            
02cd8764: bl      #0x5e90270                                 fn_5e90270
02cd8768: mov     w8, #-2                                    
02cd876c: mov     x1, x20                                    
02cd8770: mov     x2, xzr                                    
02cd8774: str     w8, [x19], #8                              
02cd8778: mov     x0, x19                                    
02cd877c: bl      #0x4d43cc0                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::SetException
02cd8780: str     w21, [sp, #0x10]                           
02cd8784: b       #0x2cd86d4                                 
02cd8788: mov     w0, #8                                     
02cd878c: bl      #0x5e90290                                 fn_5e90290
02cd8790: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02cd8794: str     x8, [x0]                                   
02cd8798: adrp    x1, #0x5e96000                             
02cd879c: add     x1, x1, #0x758                             &5e96758
02cd87a0: mov     x2, xzr                                    
02cd87a4: bl      #0x5e902a0                                 fn_5e902a0
02cd87a8: mov     x20, x0                                    
02cd87ac: bl      #0x5e90270                                 fn_5e90270
02cd87b0: mov     x0, x20                                    
02cd87b4: bl      #0x2c6051c                                 fn_2c6051c
02cd87b8: bl      #0x27369b8                                 fn_27369b8
## SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine stateMachine) -> void
---- SceneLoader/<FadeIn>d__3::SetStateMachine 0x2cd87bc
02cd87bc: add     x0, x0, #8                                 
02cd87c0: mov     x2, xzr                                    
02cd87c4: b       #0x4d43a8c                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::SetStateMachine
#### CLASS SceneLoader/<LoadScene>d__6 parent= System.ValueType
#   field <>1__state                     int                                                off=0x10 attr=6 
#   field <>t__builder                   System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1<UnityEngine.AsyncOperation> off=0x18 attr=6 
#   field id                             string                                             off=0x30 attr=6 
#   field <>8__1                         SceneLoader/<>c__DisplayClass6_0                   off=0x38 attr=1 
#   field <>u__1                         Cysharp.Threading.Tasks.UniTask/Awaiter            off=0x40 attr=1 
## MoveNext() -> void
---- SceneLoader/<LoadScene>d__6::MoveNext 0x2cd87c8
02cd87c8: sub     sp, sp, #0x70                              
02cd87cc: str     x30, [sp, #0x30]                           
02cd87d0: stp     x24, x23, [sp, #0x40]                      
02cd87d4: stp     x22, x21, [sp, #0x50]                      
02cd87d8: stp     x20, x19, [sp, #0x60]                      
02cd87dc: adrp    x20, #0x662f000                            
02cd87e0: mov     x19, x0                                    
02cd87e4: ldrb    w8, [x20, #0xd3d]                          
02cd87e8: tbnz    w8, #0, #0x2cd8854                         
02cd87ec: adrp    x0, #0x6267000                             
02cd87f0: ldr     x0, [x0, #0xa60]                           MS:System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1::AwaitUnsafeOnCompleted
02cd87f4: bl      #0x2b70db0                                 fn_2b70db0
02cd87f8: adrp    x0, #0x6267000                             
02cd87fc: ldr     x0, [x0, #0xa68]                           MS:System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1::SetResult
02cd8800: bl      #0x2b70db0                                 fn_2b70db0
02cd8804: adrp    x0, #0x6267000                             
02cd8808: ldr     x0, [x0, #0x9e8]                           T:type53308(k15)
02cd880c: bl      #0x2b70db0                                 fn_2b70db0
02cd8810: adrp    x0, #0x6265000                             
02cd8814: ldr     x0, [x0, #0xfb0]                           T:type9979(k15)
02cd8818: bl      #0x2b70db0                                 fn_2b70db0
02cd881c: adrp    x0, #0x6264000                             
02cd8820: ldr     x0, [x0, #0xb58]                           T:UnityEngine.SceneManagement.SceneManager
02cd8824: bl      #0x2b70db0                                 fn_2b70db0
02cd8828: adrp    x0, #0x6267000                             
02cd882c: ldr     x0, [x0, #0xa70]                           M:SceneLoader/<>c__DisplayClass6_0::<LoadScene>b__0
02cd8830: bl      #0x2b70db0                                 fn_2b70db0
02cd8834: adrp    x0, #0x6267000                             
02cd8838: ldr     x0, [x0, #0xa78]                           T:SceneLoader/<>c__DisplayClass6_0
02cd883c: bl      #0x2b70db0                                 fn_2b70db0
02cd8840: adrp    x0, #0x6266000                             
02cd8844: ldr     x0, [x0, #0xcc8]                           T:Cysharp.Threading.Tasks.UniTask
02cd8848: bl      #0x2b70db0                                 fn_2b70db0
02cd884c: mov     w8, #1                                     
02cd8850: strb    w8, [x20, #0xd3d]                          
02cd8854: str     xzr, [sp, #0x18]                           
02cd8858: adrp    x23, #0x6267000                            
02cd885c: ldr     w8, [x19]                                  
02cd8860: ldr     x23, [x23, #0x9e8]                         T:type53308(k15)
02cd8864: str     xzr, [sp, #0x10]                           
02cd8868: str     wzr, [sp, #8]                              
02cd886c: cbz     w8, #0x2cd89b4                             
02cd8870: adrp    x8, #0x6267000                             
02cd8874: ldr     x8, [x8, #0xa78]                           T:SceneLoader/<>c__DisplayClass6_0
02cd8878: ldr     x0, [x8]                                   S:'didu'
02cd887c: bl      #0x2b7104c                                 fn_2b7104c
02cd8880: mov     x1, xzr                                    
02cd8884: mov     x21, x0                                    
02cd8888: bl      #0x4e53e9c                                 System.Object::.ctor
02cd888c: mov     x20, x19                                   
02cd8890: str     x21, [x20, #0x28]!                         
02cd8894: mov     x0, x20                                    
02cd8898: mov     x1, x21                                    
02cd889c: bl      #0x2b70d54                                 fn_2b70d54
02cd88a0: adrp    x8, #0x6264000                             
02cd88a4: ldr     x8, [x8, #0xb58]                           T:UnityEngine.SceneManagement.SceneManager
02cd88a8: ldp     x22, x21, [x19, #0x20]                     
02cd88ac: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cd88b0: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02cd88b4: cbnz    w8, #0x2cd88bc                             
02cd88b8: bl      #0x2b70f30                                 fn_2b70f30
02cd88bc: mov     x0, x22                                    
02cd88c0: mov     x1, xzr                                    
02cd88c4: bl      #0x5b4f8e8                                 UnityEngine.SceneManagement.SceneManager::LoadSceneAsync
02cd88c8: mov     x1, x0                                     
02cd88cc: cbz     x21, #0x2cd8b90                            
02cd88d0: str     x1, [x21, #0x10]!                          .<>1__state
02cd88d4: mov     x0, x21                                    
02cd88d8: bl      #0x2b70d54                                 fn_2b70d54
02cd88dc: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02cd88e0: cbz     x8, #0x2cd8b94                             
02cd88e4: ldr     x0, [x8, #0x10]                            M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0::<DOSetFloat>b__0
02cd88e8: cbz     x0, #0x2cd8b98                             
02cd88ec: mov     w1, wzr                                    
02cd88f0: mov     x2, xzr                                    
02cd88f4: bl      #0x5b2f47c                                 UnityEngine.AsyncOperation::set_allowSceneActivation
02cd88f8: adrp    x8, #0x6265000                             
02cd88fc: ldr     x8, [x8, #0xfb0]                           T:type9979(k15)
02cd8900: ldr     x21, [x20]                                 &2b706c4(=eb01011ff9400808)
02cd8904: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02cd8908: bl      #0x2b7104c                                 fn_2b7104c
02cd890c: adrp    x8, #0x6267000                             
02cd8910: mov     x20, x0                                    
02cd8914: ldr     x8, [x8, #0xa70]                           M:SceneLoader/<>c__DisplayClass6_0::<LoadScene>b__0
02cd8918: ldr     x2, [x8]                                   S:'didu'
02cd891c: mov     x1, x21                                    
02cd8920: mov     x3, xzr                                    
02cd8924: bl      #0x4932dc8                                 fn_4932dc8
02cd8928: adrp    x22, #0x6266000                            
02cd892c: ldr     x22, [x22, #0xcc8]                         T:Cysharp.Threading.Tasks.UniTask
02cd8930: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cd8934: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02cd8938: cbnz    w8, #0x2cd8940                             
02cd893c: bl      #0x2b70f30                                 fn_2b70f30
02cd8940: mov     x0, x20                                    
02cd8944: mov     w1, #8                                     
02cd8948: mov     x2, xzr                                    
02cd894c: mov     w3, wzr                                    
02cd8950: mov     x4, xzr                                    
02cd8954: bl      #0x5449e4c                                 Cysharp.Threading.Tasks.UniTask::WaitUntil
02cd8958: stp     x0, x1, [sp, #0x20]                        
02cd895c: add     x0, sp, #0x20                              
02cd8960: mov     x1, xzr                                    
02cd8964: bl      #0x2b70d54                                 fn_2b70d54
02cd8968: adrp    x24, #0x662f000                            
02cd896c: ldp     x20, x21, [sp, #0x20]                      
02cd8970: ldrb    w8, [x24, #0xbdc]                          
02cd8974: stp     x20, x21, [sp, #0x10]                      
02cd8978: cbnz    w8, #0x2cd8990                             
02cd897c: adrp    x0, #0x6266000                             
02cd8980: ldr     x0, [x0, #0xcc8]                           T:Cysharp.Threading.Tasks.UniTask
02cd8984: bl      #0x2b70db0                                 fn_2b70db0
02cd8988: mov     w8, #1                                     
02cd898c: strb    w8, [x24, #0xbdc]                          
02cd8990: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cd8994: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02cd8998: cbnz    w8, #0x2cd89a0                             
02cd899c: bl      #0x2b70f30                                 fn_2b70f30
02cd89a0: adrp    x22, #0x662f000                            
02cd89a4: ldrb    w8, [x22, #0xbdd]                          
02cd89a8: cbz     w8, #0x2cd89cc                             
02cd89ac: cbnz    x20, #0x2cd89e4                            
02cd89b0: b       #0x2cd8a4c                                 
02cd89b4: ldr     q0, [x19, #0x30]                           .id
02cd89b8: mov     w8, #-1                                    
02cd89bc: stp     xzr, xzr, [x19, #0x30]                     .id
02cd89c0: str     w8, [x19]                                  
02cd89c4: str     q0, [sp, #0x10]                            
02cd89c8: b       #0x2cd8a4c                                 
02cd89cc: adrp    x0, #0x6266000                             
02cd89d0: ldr     x0, [x0, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02cd89d4: bl      #0x2b70db0                                 fn_2b70db0
02cd89d8: mov     w8, #1                                     
02cd89dc: strb    w8, [x22, #0xbdd]                          
02cd89e0: cbz     x20, #0x2cd8a4c                            
02cd89e4: adrp    x10, #0x6266000                            
02cd89e8: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02cd89ec: ldr     x10, [x10, #0xcd0]                         T:Cysharp.Threading.Tasks.IUniTaskSource
02cd89f0: ldrh    w9, [x8, #0x12e]                           
02cd89f4: ldr     x1, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cd89f8: cbz     x9, #0x2cd8a1c                             
02cd89fc: ldr     x10, [x8, #0xb0]                           M:Framework.SceneUtils/<CRLoadSceneAsync>d__1::System.Collections.IEnumerator.Reset
02cd8a00: add     x10, x10, #8                               &6266008
02cd8a04: ldur    x11, [x10, #-8]                            
02cd8a08: cmp     x11, x1                                    
02cd8a0c: b.eq    #0x2cd8a2c                                 
02cd8a10: subs    x9, x9, #1                                 
02cd8a14: add     x10, x10, #0x10                            &6266010
02cd8a18: b.ne    #0x2cd8a04                                 
02cd8a1c: mov     x0, x20                                    
02cd8a20: mov     w2, wzr                                    
02cd8a24: bl      #0x2baa05c                                 fn_2baa05c
02cd8a28: b       #0x2cd8a38                                 
02cd8a2c: ldrsw   x9, [x10]                                  
02cd8a30: add     x8, x8, x9, lsl #4                         &6267000
02cd8a34: add     x0, x8, #0x138                             &6267138
02cd8a38: ldp     x8, x2, [x0]                               
02cd8a3c: mov     x0, x20                                    
02cd8a40: mov     w1, w21                                    
02cd8a44: blr     x8                                         
02cd8a48: cbz     w0, #0x2cd8b44                             
02cd8a4c: adrp    x20, #0x662f000                            
02cd8a50: ldrb    w8, [x20, #0xbde]                          
02cd8a54: cbnz    w8, #0x2cd8a6c                             
02cd8a58: adrp    x0, #0x6266000                             
02cd8a5c: ldr     x0, [x0, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02cd8a60: bl      #0x2b70db0                                 fn_2b70db0
02cd8a64: mov     w8, #1                                     
02cd8a68: strb    w8, [x20, #0xbde]                          
02cd8a6c: ldr     x20, [sp, #0x10]                           
02cd8a70: cbz     x20, #0x2cd8ae0                            
02cd8a74: adrp    x10, #0x6266000                            
02cd8a78: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02cd8a7c: ldr     x10, [x10, #0xcd0]                         T:Cysharp.Threading.Tasks.IUniTaskSource
02cd8a80: ldrh    w21, [sp, #0x18]                           
02cd8a84: ldrh    w9, [x8, #0x12e]                           
02cd8a88: ldr     x1, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cd8a8c: cbz     x9, #0x2cd8ab0                             
02cd8a90: ldr     x10, [x8, #0xb0]                           M:Framework.SceneUtils/<CRLoadSceneAsync>d__1::System.Collections.IEnumerator.Reset
02cd8a94: add     x10, x10, #8                               &6266008
02cd8a98: ldur    x11, [x10, #-8]                            
02cd8a9c: cmp     x11, x1                                    
02cd8aa0: b.eq    #0x2cd8ac0                                 
02cd8aa4: subs    x9, x9, #1                                 
02cd8aa8: add     x10, x10, #0x10                            &6266010
02cd8aac: b.ne    #0x2cd8a98                                 
02cd8ab0: mov     x0, x20                                    
02cd8ab4: mov     w2, #2                                     
02cd8ab8: bl      #0x2baa05c                                 fn_2baa05c
02cd8abc: b       #0x2cd8ad0                                 
02cd8ac0: ldr     w9, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cd8ac4: add     w9, w9, #2                                 
02cd8ac8: add     x8, x8, w9, sxtw #4                        &6267000
02cd8acc: add     x0, x8, #0x138                             &6267138
02cd8ad0: ldp     x8, x2, [x0]                               
02cd8ad4: mov     x0, x20                                    
02cd8ad8: mov     w1, w21                                    
02cd8adc: blr     x8                                         
02cd8ae0: mov     x0, x19                                    
02cd8ae4: ldr     x8, [x0, #0x28]!                           S:'banner_ad_on_off'
02cd8ae8: cbz     x8, #0x2cd8b8c                             
02cd8aec: adrp    x21, #0x6267000                            
02cd8af0: mov     w9, #-2                                    
02cd8af4: mov     x1, xzr                                    
02cd8af8: ldr     x21, [x21, #0xa68]                         MS:System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1::SetResult
02cd8afc: ldr     x20, [x8, #0x10]                           S:'startActivity'
02cd8b00: str     w9, [x19]                                  
02cd8b04: str     xzr, [x19, #0x28]                          
02cd8b08: bl      #0x2b70d54                                 fn_2b70d54
02cd8b0c: ldr     x0, [x23]                                  S:'didu'
02cd8b10: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02cd8b14: cbnz    w8, #0x2cd8b1c                             
02cd8b18: bl      #0x2b70f30                                 fn_2b70f30
02cd8b1c: ldr     x2, [x21]                                  S:'didu'
02cd8b20: add     x0, x19, #8                                
02cd8b24: mov     x1, x20                                    
02cd8b28: bl      #0x3c14d88                                 fn_3c14d88
02cd8b2c: ldp     x20, x19, [sp, #0x60]                      
02cd8b30: ldr     x30, [sp, #0x30]                           
02cd8b34: ldp     x22, x21, [sp, #0x50]                      
02cd8b38: ldp     x24, x23, [sp, #0x40]                      
02cd8b3c: add     sp, sp, #0x70                              
02cd8b40: ret                                                
02cd8b44: ldr     q0, [sp, #0x10]                            
02cd8b48: str     wzr, [x19]                                 
02cd8b4c: str     q0, [x19, #0x30]                           .id
02cd8b50: add     x0, x19, #0x30                             
02cd8b54: mov     x1, xzr                                    
02cd8b58: bl      #0x2b70d54                                 fn_2b70d54
02cd8b5c: ldr     x0, [x23]                                  S:'didu'
02cd8b60: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02cd8b64: cbnz    w8, #0x2cd8b6c                             
02cd8b68: bl      #0x2b70f30                                 fn_2b70f30
02cd8b6c: adrp    x8, #0x6267000                             
02cd8b70: ldr     x8, [x8, #0xa60]                           MS:System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1::AwaitUnsafeOnCompleted
02cd8b74: ldr     x3, [x8]                                   S:'didu'
02cd8b78: add     x0, x19, #8                                
02cd8b7c: add     x1, sp, #0x10                              
02cd8b80: mov     x2, x19                                    
02cd8b84: bl      #0x2e6f368                                 fn_2e6f368
02cd8b88: b       #0x2cd8b2c                                 
02cd8b8c: bl      #0x2b7105c                                 fn_2b7105c
02cd8b90: bl      #0x2b7105c                                 fn_2b7105c
02cd8b94: bl      #0x2b7105c                                 fn_2b7105c
02cd8b98: bl      #0x2b7105c                                 fn_2b7105c
02cd8b9c: b       #0x2cd8bd0                                 
02cd8ba0: b       #0x2cd8bd0                                 
02cd8ba4: b       #0x2cd8bd0                                 
02cd8ba8: b       #0x2cd8bd0                                 
02cd8bac: b       #0x2cd8bd0                                 
02cd8bb0: b       #0x2cd8bd0                                 
02cd8bb4: b       #0x2cd8bd0                                 
02cd8bb8: b       #0x2cd8bd0                                 
02cd8bbc: b       #0x2cd8bd0                                 
02cd8bc0: b       #0x2cd8bd0                                 
02cd8bc4: b       #0x2cd8bd0                                 
02cd8bc8: b       #0x2cd8bd0                                 
02cd8bcc: b       #0x2cd8bd0                                 
02cd8bd0: mov     x20, x0                                    
02cd8bd4: cmp     w1, #1                                     
02cd8bd8: b.ne    #0x2cd8c9c                                 
02cd8bdc: mov     x0, x20                                    
02cd8be0: bl      #0x5e90260                                 fn_5e90260
02cd8be4: mov     x20, x0                                    
02cd8be8: adrp    x0, #0x6263000                             
02cd8bec: ldr     x0, [x0, #0xae0]                           T:System.Exception
02cd8bf0: bl      #0x2b70dc4                                 fn_2b70dc4
02cd8bf4: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02cd8bf8: ldr     x1, [x8]                                   S:'didu'
02cd8bfc: bl      #0x2b71464                                 fn_2b71464
02cd8c00: tbz     w0, #0, #0x2cd8c74                         
02cd8c04: ldrsw   x21, [sp, #8]                              
02cd8c08: ldr     x20, [x20]                                 &2b706c4(=eb01011ff9400808)
02cd8c0c: mov     x8, sp                                     
02cd8c10: str     x20, [x8, x21, lsl #3]                     
02cd8c14: add     w8, w21, #1                                
02cd8c18: str     w8, [sp, #8]                               
02cd8c1c: bl      #0x5e90270                                 fn_5e90270
02cd8c20: mov     w8, #-2                                    
02cd8c24: mov     x0, x19                                    
02cd8c28: mov     x1, xzr                                    
02cd8c2c: str     w8, [x19]                                  
02cd8c30: str     xzr, [x0, #0x28]!                          
02cd8c34: bl      #0x2b70d54                                 fn_2b70d54
02cd8c38: adrp    x0, #0x6267000                             
02cd8c3c: ldr     x0, [x0, #0x9e8]                           T:type53308(k15)
02cd8c40: bl      #0x2b70dc4                                 fn_2b70dc4
02cd8c44: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02cd8c48: cbnz    w8, #0x2cd8c50                             
02cd8c4c: bl      #0x2b70f30                                 fn_2b70f30
02cd8c50: adrp    x0, #0x6267000                             
02cd8c54: ldr     x0, [x0, #0xa80]                           MS:System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1::SetException
02cd8c58: bl      #0x2b70dc4                                 fn_2b70dc4
02cd8c5c: mov     x2, x0                                     
02cd8c60: add     x0, x19, #8                                
02cd8c64: mov     x1, x20                                    
02cd8c68: bl      #0x3c14fd4                                 fn_3c14fd4
02cd8c6c: str     w21, [sp, #8]                              
02cd8c70: b       #0x2cd8b2c                                 
02cd8c74: mov     w0, #8                                     
02cd8c78: bl      #0x5e90290                                 fn_5e90290
02cd8c7c: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02cd8c80: str     x8, [x0]                                   
02cd8c84: adrp    x1, #0x5e96000                             
02cd8c88: add     x1, x1, #0x758                             &5e96758
02cd8c8c: mov     x2, xzr                                    
02cd8c90: bl      #0x5e902a0                                 fn_5e902a0
02cd8c94: mov     x20, x0                                    
02cd8c98: bl      #0x5e90270                                 fn_5e90270
02cd8c9c: mov     x0, x20                                    
02cd8ca0: bl      #0x2c6051c                                 fn_2c6051c
02cd8ca4: bl      #0x27369b8                                 fn_27369b8
## SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine stateMachine) -> void
---- SceneLoader/<LoadScene>d__6::SetStateMachine 0x2cd8ca8
02cd8ca8: str     x30, [sp, #-0x30]!                         
02cd8cac: stp     x22, x21, [sp, #0x10]                      
02cd8cb0: stp     x20, x19, [sp, #0x20]                      
02cd8cb4: adrp    x22, #0x662f000                            
02cd8cb8: adrp    x21, #0x6267000                            
02cd8cbc: mov     x19, x1                                    
02cd8cc0: ldrb    w8, [x22, #0xd3e]                          
02cd8cc4: ldr     x21, [x21, #0x9e8]                         T:type53308(k15)
02cd8cc8: mov     x20, x0                                    
02cd8ccc: tbnz    w8, #0, #0x2cd8cf0                         
02cd8cd0: adrp    x0, #0x6267000                             
02cd8cd4: ldr     x0, [x0, #0xa88]                           MS:System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1::SetStateMachine
02cd8cd8: bl      #0x2b70db0                                 fn_2b70db0
02cd8cdc: adrp    x0, #0x6267000                             
02cd8ce0: ldr     x0, [x0, #0x9e8]                           T:type53308(k15)
02cd8ce4: bl      #0x2b70db0                                 fn_2b70db0
02cd8ce8: mov     w8, #1                                     
02cd8cec: strb    w8, [x22, #0xd3e]                          
02cd8cf0: ldr     x0, [x21]                                  S:'didu'
02cd8cf4: adrp    x21, #0x6267000                            
02cd8cf8: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02cd8cfc: ldr     x21, [x21, #0xa88]                         MS:System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1::SetStateMachine
02cd8d00: cbnz    w8, #0x2cd8d08                             
02cd8d04: bl      #0x2b70f30                                 fn_2b70f30
02cd8d08: ldr     x2, [x21]                                  S:'didu'
02cd8d0c: add     x0, x20, #8                                
02cd8d10: mov     x1, x19                                    
02cd8d14: ldp     x20, x19, [sp, #0x20]                      
02cd8d18: ldp     x22, x21, [sp, #0x10]                      
02cd8d1c: ldr     x30, [sp], #0x30                           
02cd8d20: b       #0x3c14ce8                                 
#### CLASS SceneLoader parent= MonoSingleton`1<SceneLoader>
#   field _prefabFadeIn                  UnityEngine.GameObject                             off=0x20 attr=1 SerializeField
#   field _prefabFadeOut                 UnityEngine.GameObject                             off=0x28 attr=1 SerializeField
#   field _loadingGo                     UnityEngine.GameObject                             off=0x30 attr=1 SerializeField
## FadeIn(string targetScene) -> void
---- SceneLoader::FadeIn 0x2cd7494
02cd7494: sub     sp, sp, #0x90                              
02cd7498: str     x30, [sp, #0x60]                           
02cd749c: stp     x22, x21, [sp, #0x70]                      
02cd74a0: stp     x20, x19, [sp, #0x80]                      
02cd74a4: adrp    x22, #0x662f000                            
02cd74a8: adrp    x21, #0x6267000                            
02cd74ac: mov     x19, x1                                    
02cd74b0: ldrb    w8, [x22, #0xd33]                          
02cd74b4: ldr     x21, [x21, #0x9c8]                         MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::Start
02cd74b8: mov     x20, x0                                    
02cd74bc: tbnz    w8, #0, #0x2cd74d4                         
02cd74c0: adrp    x0, #0x6267000                             
02cd74c4: ldr     x0, [x0, #0x9c8]                           MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::Start
02cd74c8: bl      #0x2b70db0                                 fn_2b70db0
02cd74cc: mov     w8, #1                                     
02cd74d0: strb    w8, [x22, #0xd33]                          
02cd74d4: movi    v0.2d, #0000000000000000                   
02cd74d8: mov     x8, sp                                     
02cd74dc: mov     x0, xzr                                    
02cd74e0: add     x22, sp, #0x20                             
02cd74e4: stp     q0, q0, [sp, #0x20]                        
02cd74e8: stp     q0, q0, [sp, #0x40]                        
02cd74ec: bl      #0x4d43a24                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::Create
02cd74f0: ldp     q0, q1, [sp]                               
02cd74f4: orr     x0, x22, #8                                
02cd74f8: mov     x1, xzr                                    
02cd74fc: stur    q0, [sp, #0x28]                            
02cd7500: stur    q1, [sp, #0x38]                            
02cd7504: bl      #0x2b70d54                                 fn_2b70d54
02cd7508: add     x0, x22, #0x28                             &662f028
02cd750c: mov     x1, x20                                    
02cd7510: str     x20, [sp, #0x48]                           
02cd7514: bl      #0x2b70d54                                 fn_2b70d54
02cd7518: add     x0, x22, #0x30                             &662f030
02cd751c: mov     x1, x19                                    
02cd7520: str     x19, [sp, #0x50]                           
02cd7524: bl      #0x2b70d54                                 fn_2b70d54
02cd7528: ldr     x2, [x21]                                  S:'didu'
02cd752c: mov     w8, #-1                                    
02cd7530: orr     x0, x22, #8                                
02cd7534: add     x1, sp, #0x20                              
02cd7538: str     w8, [sp, #0x20]                            
02cd753c: bl      #0x30c8fa8                                 fn_30c8fa8
02cd7540: ldp     x20, x19, [sp, #0x80]                      
02cd7544: ldr     x30, [sp, #0x60]                           
02cd7548: ldp     x22, x21, [sp, #0x70]                      
02cd754c: add     sp, sp, #0x90                              
02cd7550: ret                                                
## FadeOut() -> void
---- SceneLoader::FadeOut 0x2cd7554
02cd7554: stp     x30, x21, [sp, #-0x20]!                    
02cd7558: stp     x20, x19, [sp, #0x10]                      
02cd755c: adrp    x20, #0x662f000                            
02cd7560: mov     x19, x0                                    
02cd7564: ldrb    w8, [x20, #0xd34]                          
02cd7568: tbnz    w8, #0, #0x2cd758c                         
02cd756c: adrp    x0, #0x6267000                             
02cd7570: ldr     x0, [x0, #0x9d0]                           M:SceneLoader::<FadeOut>b__4_0
02cd7574: bl      #0x2b70db0                                 fn_2b70db0
02cd7578: adrp    x0, #0x6264000                             
02cd757c: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02cd7580: bl      #0x2b70db0                                 fn_2b70db0
02cd7584: mov     w8, #1                                     
02cd7588: strb    w8, [x20, #0xd34]                          
02cd758c: ldr     x0, [x19, #0x30]                           ._loadingGo
02cd7590: cbz     x0, #0x2cd75fc                             
02cd7594: mov     w1, wzr                                    
02cd7598: mov     x2, xzr                                    
02cd759c: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cd75a0: ldr     x0, [x19, #0x28]                           ._prefabFadeOut
02cd75a4: cbz     x0, #0x2cd75fc                             
02cd75a8: adrp    x20, #0x6264000                            
02cd75ac: adrp    x21, #0x6267000                            
02cd75b0: mov     w1, #1                                     
02cd75b4: ldr     x20, [x20, #0xe8]                          T:DG.Tweening.TweenCallback
02cd75b8: ldr     x21, [x21, #0x9d0]                         M:SceneLoader::<FadeOut>b__4_0
02cd75bc: mov     x2, xzr                                    
02cd75c0: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cd75c4: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cd75c8: bl      #0x2b7104c                                 fn_2b7104c
02cd75cc: ldr     x2, [x21]                                  S:'didu'
02cd75d0: mov     x1, x19                                    
02cd75d4: mov     x3, xzr                                    
02cd75d8: mov     x20, x0                                    
02cd75dc: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02cd75e0: mov     x0, x20                                    
02cd75e4: ldp     x20, x19, [sp, #0x10]                      
02cd75e8: fmov    s0, #1.00000000                            
02cd75ec: mov     w1, #1                                     
02cd75f0: mov     x2, xzr                                    
02cd75f4: ldp     x30, x21, [sp], #0x20                      
02cd75f8: b       #0x2d8f37c                                 DG.Tweening.DOVirtual::DelayedCall
02cd75fc: bl      #0x2b7105c                                 fn_2b7105c
## Translate(System.Action onComplete) -> void
---- SceneLoader::Translate 0x2cd7600
02cd7600: str     x30, [sp, #-0x30]!                         
02cd7604: stp     x22, x21, [sp, #0x10]                      
02cd7608: stp     x20, x19, [sp, #0x20]                      
02cd760c: adrp    x20, #0x662f000                            
02cd7610: adrp    x22, #0x6267000                            
02cd7614: mov     x21, x1                                    
02cd7618: ldrb    w8, [x20, #0xd35]                          
02cd761c: ldr     x22, [x22, #0x9d8]                         T:SceneLoader/<>c__DisplayClass5_0
02cd7620: mov     x19, x0                                    
02cd7624: tbnz    w8, #0, #0x2cd7654                         
02cd7628: adrp    x0, #0x6264000                             
02cd762c: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02cd7630: bl      #0x2b70db0                                 fn_2b70db0
02cd7634: adrp    x0, #0x6267000                             
02cd7638: ldr     x0, [x0, #0x9e0]                           M:SceneLoader/<>c__DisplayClass5_0::<Translate>b__0
02cd763c: bl      #0x2b70db0                                 fn_2b70db0
02cd7640: adrp    x0, #0x6267000                             
02cd7644: ldr     x0, [x0, #0x9d8]                           T:SceneLoader/<>c__DisplayClass5_0
02cd7648: bl      #0x2b70db0                                 fn_2b70db0
02cd764c: mov     w8, #1                                     
02cd7650: strb    w8, [x20, #0xd35]                          
02cd7654: ldr     x0, [x22]                                  S:'didu'
02cd7658: bl      #0x2b7104c                                 fn_2b7104c
02cd765c: mov     x1, xzr                                    
02cd7660: mov     x20, x0                                    
02cd7664: bl      #0x4e53e9c                                 System.Object::.ctor
02cd7668: cbz     x20, #0x2cd76ec                            
02cd766c: mov     x0, x20                                    
02cd7670: mov     x1, x21                                    
02cd7674: str     x21, [x0, #0x10]!                          
02cd7678: bl      #0x2b70d54                                 fn_2b70d54
02cd767c: mov     x0, x20                                    
02cd7680: mov     x1, x19                                    
02cd7684: str     x19, [x0, #0x18]!                          
02cd7688: bl      #0x2b70d54                                 fn_2b70d54
02cd768c: ldr     x0, [x19, #0x20]                           ._prefabFadeIn
02cd7690: cbz     x0, #0x2cd76ec                             
02cd7694: adrp    x19, #0x6264000                            
02cd7698: adrp    x21, #0x6267000                            
02cd769c: mov     w1, #1                                     
02cd76a0: ldr     x19, [x19, #0xe8]                          T:DG.Tweening.TweenCallback
02cd76a4: ldr     x21, [x21, #0x9e0]                         M:SceneLoader/<>c__DisplayClass5_0::<Translate>b__0
02cd76a8: mov     x2, xzr                                    
02cd76ac: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cd76b0: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cd76b4: bl      #0x2b7104c                                 fn_2b7104c
02cd76b8: ldr     x2, [x21]                                  S:'didu'
02cd76bc: mov     x1, x20                                    
02cd76c0: mov     x3, xzr                                    
02cd76c4: mov     x19, x0                                    
02cd76c8: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02cd76cc: mov     x0, x19                                    
02cd76d0: ldp     x20, x19, [sp, #0x20]                      
02cd76d4: ldp     x22, x21, [sp, #0x10]                      
02cd76d8: fmov    s0, #0.50000000                            
02cd76dc: mov     w1, #1                                     
02cd76e0: mov     x2, xzr                                    
02cd76e4: ldr     x30, [sp], #0x30                           
02cd76e8: b       #0x2d8f37c                                 DG.Tweening.DOVirtual::DelayedCall
02cd76ec: bl      #0x2b7105c                                 fn_2b7105c
## LoadScene(string id) -> System.Threading.Tasks.Task`1<UnityEngine.AsyncOperation>
---- SceneLoader::LoadScene 0x2cd76f8
02cd76f8: sub     sp, sp, #0x90                              
02cd76fc: str     x30, [sp, #0x60]                           
02cd7700: stp     x22, x21, [sp, #0x70]                      
02cd7704: stp     x20, x19, [sp, #0x80]                      
02cd7708: adrp    x21, #0x662f000                            
02cd770c: adrp    x20, #0x6267000                            
02cd7710: mov     x19, x1                                    
02cd7714: ldrb    w8, [x21, #0xd36]                          
02cd7718: ldr     x20, [x20, #0x9e8]                         T:type53308(k15)
02cd771c: tbnz    w8, #0, #0x2cd7758                         
02cd7720: adrp    x0, #0x6267000                             
02cd7724: ldr     x0, [x0, #0x9f0]                           MS:System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1::Create
02cd7728: bl      #0x2b70db0                                 fn_2b70db0
02cd772c: adrp    x0, #0x6267000                             
02cd7730: ldr     x0, [x0, #0x9f8]                           MS:System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1::Start
02cd7734: bl      #0x2b70db0                                 fn_2b70db0
02cd7738: adrp    x0, #0x6267000                             
02cd773c: ldr     x0, [x0, #0xa00]                           MS:System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1::get_Task
02cd7740: bl      #0x2b70db0                                 fn_2b70db0
02cd7744: adrp    x0, #0x6267000                             
02cd7748: ldr     x0, [x0, #0x9e8]                           T:type53308(k15)
02cd774c: bl      #0x2b70db0                                 fn_2b70db0
02cd7750: mov     w8, #1                                     
02cd7754: strb    w8, [x21, #0xd36]                          
02cd7758: movi    v0.2d, #0000000000000000                   
02cd775c: adrp    x22, #0x6267000                            
02cd7760: adrp    x21, #0x6267000                            
02cd7764: ldr     x22, [x22, #0x9f0]                         MS:System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1::Create
02cd7768: ldr     x0, [x20]                                  S:'didu'
02cd776c: ldr     x21, [x21, #0x9f8]                         MS:System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1::Start
02cd7770: adrp    x20, #0x6267000                            
02cd7774: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02cd7778: stp     q0, q0, [sp, #0x40]                        
02cd777c: ldr     x20, [x20, #0xa00]                         MS:System.Runtime.CompilerServices.AsyncTaskMethodBuilder`1::get_Task
02cd7780: stp     q0, q0, [sp, #0x20]                        
02cd7784: cbnz    w8, #0x2cd778c                             
02cd7788: bl      #0x2b70f30                                 fn_2b70f30
02cd778c: ldr     x0, [x22]                                  S:'didu'
02cd7790: add     x8, sp, #8                                 
02cd7794: bl      #0x3c14cdc                                 fn_3c14cdc
02cd7798: ldur    q0, [sp, #8]                               
02cd779c: ldr     x8, [sp, #0x18]                            
02cd77a0: add     x22, sp, #0x20                             
02cd77a4: orr     x0, x22, #8                                
02cd77a8: mov     x1, xzr                                    
02cd77ac: stur    q0, [sp, #0x28]                            
02cd77b0: str     x8, [sp, #0x38]                            
02cd77b4: bl      #0x2b70d54                                 fn_2b70d54
02cd77b8: add     x0, x22, #0x20                             &6267020
02cd77bc: mov     x1, x19                                    
02cd77c0: str     x19, [sp, #0x40]                           
02cd77c4: bl      #0x2b70d54                                 fn_2b70d54
02cd77c8: ldr     x2, [x21]                                  S:'didu'
02cd77cc: mov     w8, #-1                                    
02cd77d0: orr     x0, x22, #8                                
02cd77d4: add     x1, sp, #0x20                              
02cd77d8: str     w8, [sp, #0x20]                            
02cd77dc: bl      #0x2e75700                                 fn_2e75700
02cd77e0: ldr     x1, [x20]                                  S:'didu'
02cd77e4: orr     x0, x22, #8                                
02cd77e8: bl      #0x3c14cf0                                 fn_3c14cf0
02cd77ec: ldp     x20, x19, [sp, #0x80]                      
02cd77f0: ldr     x30, [sp, #0x60]                           
02cd77f4: ldp     x22, x21, [sp, #0x70]                      
02cd77f8: add     sp, sp, #0x90                              
02cd77fc: ret                                                
## .ctor() -> void
---- SceneLoader::.ctor 0x2cd7800
02cd7800: stp     x30, x21, [sp, #-0x20]!                    
02cd7804: stp     x20, x19, [sp, #0x10]                      
02cd7808: adrp    x20, #0x662f000                            
02cd780c: adrp    x21, #0x6267000                            
02cd7810: mov     x19, x0                                    
02cd7814: ldrb    w8, [x20, #0xd37]                          
02cd7818: ldr     x21, [x21, #0xa08]                         MS:MonoSingleton`1::.ctor
02cd781c: tbnz    w8, #0, #0x2cd7834                         
02cd7820: adrp    x0, #0x6267000                             
02cd7824: ldr     x0, [x0, #0xa08]                           MS:MonoSingleton`1::.ctor
02cd7828: bl      #0x2b70db0                                 fn_2b70db0
02cd782c: mov     w8, #1                                     
02cd7830: strb    w8, [x20, #0xd37]                          
02cd7834: mov     x0, x19                                    
02cd7838: ldp     x20, x19, [sp, #0x10]                      
02cd783c: ldr     x1, [x21]                                  S:'didu'
02cd7840: ldp     x30, x21, [sp], #0x20                      
02cd7844: b       #0x3769e18                                 
## <FadeOut>b__4_0() -> void
---- SceneLoader::<FadeOut>b__4_0 0x2cd7848
02cd7848: ldr     x0, [x0, #0x28]                            ._prefabFadeOut
02cd784c: cbz     x0, #0x2cd785c                             
02cd7850: mov     w1, wzr                                    
02cd7854: mov     x2, xzr                                    
02cd7858: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cd785c: str     x30, [sp, #-0x10]!                         
02cd7860: bl      #0x2b7105c                                 fn_2b7105c
