#### CLASS Home.PetHomeAsset/<>c__DisplayClass2_0 parent= object
#   field id                             int                                                off=0x10 attr=6 
## .ctor() -> void
---- Home.PetHomeAsset/<>c__DisplayClass2_0::.ctor 0x2d1de9c
02d1de9c: mov     x1, xzr                                    
02d1dea0: b       #0x4e53e9c                                 System.Object::.ctor
## <GetData>b__0(Home.PetHomeDataItem x) -> bool
---- Home.PetHomeAsset/<>c__DisplayClass2_0::<GetData>b__0 0x2d1deb4
02d1deb4: cbz     x1, #0x2d1decc                             
02d1deb8: ldr     w8, [x1, #0x10]                            
02d1debc: ldr     w9, [x0, #0x10]                            .id
02d1dec0: cmp     w8, w9                                     
02d1dec4: cset    w0, eq                                     
02d1dec8: ret                                                
02d1decc: str     x30, [sp, #-0x10]!                         
02d1ded0: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Home.PetHomeAsset parent= UnityEngine.ScriptableObject
#   field _petCategoryRef                Decor.CategoryAsset                                off=0x18 attr=1 SerializeField
#   field _dataList                      System.Collections.Generic.List`1<Home.PetHomeDataItem> off=0x20 attr=1 SerializeField
## GetData(int id) -> Home.PetHomeDataItem
---- Home.PetHomeAsset::GetData 0x2d1ddc4
02d1ddc4: str     x30, [sp, #-0x30]!                         
02d1ddc8: stp     x22, x21, [sp, #0x10]                      
02d1ddcc: stp     x20, x19, [sp, #0x20]                      
02d1ddd0: adrp    x21, #0x6630000                            
02d1ddd4: adrp    x22, #0x6269000                            
02d1ddd8: mov     w19, w1                                    
02d1dddc: ldrb    w8, [x21, #0x2d]                           
02d1dde0: ldr     x22, [x22, #0xcf0]                         T:Home.PetHomeAsset/<>c__DisplayClass2_0
02d1dde4: mov     x20, x0                                    
02d1dde8: tbnz    w8, #0, #0x2d1de24                         
02d1ddec: adrp    x0, #0x6269000                             
02d1ddf0: ldr     x0, [x0, #0xcf8]                           MS:System.Collections.Generic.List`1::Find
02d1ddf4: bl      #0x2b70db0                                 fn_2b70db0
02d1ddf8: adrp    x0, #0x6269000                             
02d1ddfc: ldr     x0, [x0, #0xd00]                           T:type57269(k15)
02d1de00: bl      #0x2b70db0                                 fn_2b70db0
02d1de04: adrp    x0, #0x6269000                             
02d1de08: ldr     x0, [x0, #0xd08]                           M:Home.PetHomeAsset/<>c__DisplayClass2_0::<GetData>b__0
02d1de0c: bl      #0x2b70db0                                 fn_2b70db0
02d1de10: adrp    x0, #0x6269000                             
02d1de14: ldr     x0, [x0, #0xcf0]                           T:Home.PetHomeAsset/<>c__DisplayClass2_0
02d1de18: bl      #0x2b70db0                                 fn_2b70db0
02d1de1c: mov     w8, #1                                     
02d1de20: strb    w8, [x21, #0x2d]                           
02d1de24: ldr     x0, [x22]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1de28: bl      #0x2b7104c                                 fn_2b7104c
02d1de2c: mov     x1, xzr                                    
02d1de30: mov     x21, x0                                    
02d1de34: bl      #0x4e53e9c                                 System.Object::.ctor
02d1de38: cbz     x21, #0x2d1de98                            
02d1de3c: adrp    x8, #0x6269000                             
02d1de40: adrp    x22, #0x6269000                            
02d1de44: ldr     x8, [x8, #0xd00]                           T:type57269(k15)
02d1de48: ldr     x22, [x22, #0xd08]                         M:Home.PetHomeAsset/<>c__DisplayClass2_0::<GetData>b__0
02d1de4c: ldr     x20, [x20, #0x20]                          ._dataList
02d1de50: str     w19, [x21, #0x10]                          
02d1de54: ldr     x0, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d1de58: bl      #0x2b7104c                                 fn_2b7104c
02d1de5c: ldr     x2, [x22]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1de60: mov     x1, x21                                    
02d1de64: mov     x3, xzr                                    
02d1de68: mov     x19, x0                                    
02d1de6c: bl      #0x399ba10                                 fn_399ba10
02d1de70: cbz     x20, #0x2d1de98                            
02d1de74: adrp    x8, #0x6269000                             
02d1de78: mov     x0, x20                                    
02d1de7c: mov     x1, x19                                    
02d1de80: ldr     x8, [x8, #0xcf8]                           MS:System.Collections.Generic.List`1::Find
02d1de84: ldp     x20, x19, [sp, #0x20]                      
02d1de88: ldp     x22, x21, [sp, #0x10]                      
02d1de8c: ldr     x2, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d1de90: ldr     x30, [sp], #0x30                           
02d1de94: b       #0x35a9868                                 
02d1de98: bl      #0x2b7105c                                 fn_2b7105c
## GetAllData() -> System.Collections.Generic.List`1<Home.PetHomeDataItem>
---- Home.PetHomeAsset::GetAllData 0x2d1dea4
02d1dea4: ldr     x0, [x0, #0x20]                            ._dataList
02d1dea8: ret                                                
## .ctor() -> void
---- Home.PetHomeAsset::.ctor 0x2d1deac
02d1deac: mov     x1, xzr                                    
02d1deb0: b       #0x5b398f0                                 UnityEngine.ScriptableObject::.ctor
