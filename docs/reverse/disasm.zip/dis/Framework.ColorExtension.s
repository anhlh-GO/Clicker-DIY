#### CLASS Framework.ColorExtension parent= object
## ToHtmlStringRGB(UnityEngine.Color color) -> string
---- Framework.ColorExtension::ToHtmlStringRGB 0x2cb88a8
02cb88a8: sub     sp, sp, #0x20                              
02cb88ac: str     x30, [sp, #0x10]                           
02cb88b0: mov     x0, sp                                     
02cb88b4: mov     x1, xzr                                    
02cb88b8: stp     s0, s1, [sp]                               
02cb88bc: stp     s2, s3, [sp, #8]                           
02cb88c0: bl      #0x5b21048                                 UnityEngine.ColorUtility::ToHtmlStringRGB
02cb88c4: ldr     x30, [sp, #0x10]                           
02cb88c8: add     sp, sp, #0x20                              
02cb88cc: ret                                                
## WithAlpha(UnityEngine.Color color, float alpha) -> UnityEngine.Color
---- Framework.ColorExtension::WithAlpha 0x2cb88d0
02cb88d0: fmov    s3, s4                                     
02cb88d4: ret                                                
