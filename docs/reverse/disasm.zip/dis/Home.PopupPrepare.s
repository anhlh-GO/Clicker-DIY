#### CLASS Home.PopupPrepare/<OnShow>d__17 parent= System.ValueType
#   field <>1__state                     int                                                off=0x10 attr=6 
#   field <>t__builder                   System.Runtime.CompilerServices.AsyncVoidMethodBuilder off=0x18 attr=6 
#   field <>4__this                      Home.PopupPrepare                                  off=0x38 attr=6 
#   field <>u__1                         Cysharp.Threading.Tasks.UniTask/Awaiter            off=0x40 attr=1 
## MoveNext() -> void
---- Home.PopupPrepare/<OnShow>d__17::MoveNext 0x2d231e0
02d231e0: sub     sp, sp, #0x70                              
02d231e4: str     x30, [sp, #0x30]                           
02d231e8: stp     x24, x23, [sp, #0x40]                      
02d231ec: stp     x22, x21, [sp, #0x50]                      
02d231f0: stp     x20, x19, [sp, #0x60]                      
02d231f4: adrp    x20, #0x6630000                            
02d231f8: mov     x19, x0                                    
02d231fc: ldrb    w8, [x20, #0x58]                           
02d23200: tbnz    w8, #0, #0x2d232a8                         
02d23204: adrp    x0, #0x6269000                             
02d23208: ldr     x0, [x0, #0xec8]                           MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::AwaitUnsafeOnCompleted
02d2320c: bl      #0x2b70db0                                 fn_2b70db0
02d23210: adrp    x0, #0x6266000                             
02d23214: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d23218: bl      #0x2b70db0                                 fn_2b70db0
02d2321c: adrp    x0, #0x6265000                             
02d23220: ldr     x0, [x0, #0xb38]                           T:DevTrack
02d23224: bl      #0x2b70db0                                 fn_2b70db0
02d23228: adrp    x0, #0x6266000                             
02d2322c: ldr     x0, [x0, #0x9f0]                           T:Assets.SimpleLocalization.Scripts.LocalizationManager
02d23230: bl      #0x2b70db0                                 fn_2b70db0
02d23234: adrp    x0, #0x6266000                             
02d23238: ldr     x0, [x0, #0xac0]                           MS:MonoSingleton`1::get_Instance
02d2323c: bl      #0x2b70db0                                 fn_2b70db0
02d23240: adrp    x0, #0x6266000                             
02d23244: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d23248: bl      #0x2b70db0                                 fn_2b70db0
02d2324c: adrp    x0, #0x6263000                             
02d23250: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d23254: bl      #0x2b70db0                                 fn_2b70db0
02d23258: adrp    x0, #0x6269000                             
02d2325c: ldr     x0, [x0, #0xed0]                           M:Home.PopupPrepare::<OnShow>b__17_0
02d23260: bl      #0x2b70db0                                 fn_2b70db0
02d23264: adrp    x0, #0x6264000                             
02d23268: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d2326c: bl      #0x2b70db0                                 fn_2b70db0
02d23270: adrp    x0, #0x6266000                             
02d23274: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d23278: bl      #0x2b70db0                                 fn_2b70db0
02d2327c: adrp    x0, #0x6266000                             
02d23280: ldr     x0, [x0, #0xcc8]                           T:Cysharp.Threading.Tasks.UniTask
02d23284: bl      #0x2b70db0                                 fn_2b70db0
02d23288: adrp    x0, #0x6267000                             
02d2328c: ldr     x0, [x0, #0xea8]                           T:Framework.Vibration
02d23290: bl      #0x2b70db0                                 fn_2b70db0
02d23294: adrp    x0, #0x6266000                             
02d23298: ldr     x0, [x0, #0xd68]                           S:'Welcome !'
02d2329c: bl      #0x2b70db0                                 fn_2b70db0
02d232a0: mov     w8, #1                                     
02d232a4: strb    w8, [x20, #0x58]                           
02d232a8: adrp    x24, #0x6266000                            
02d232ac: adrp    x23, #0x662f000                            
02d232b0: ldr     x24, [x24, #0xcc8]                         T:Cysharp.Threading.Tasks.UniTask
02d232b4: ldr     w8, [x19]                                  
02d232b8: ldr     x20, [x19, #0x28]                          
02d232bc: stp     xzr, xzr, [sp, #0x10]                      
02d232c0: str     wzr, [sp, #8]                              
02d232c4: cbz     w8, #0x2d232e8                             
02d232c8: cmp     w8, #1                                     
02d232cc: b.ne    #0x2d23300                                 
02d232d0: ldr     q0, [x19, #0x30]                           
02d232d4: mov     w8, #-1                                    
02d232d8: stp     xzr, xzr, [x19, #0x30]                     
02d232dc: str     w8, [x19]                                  
02d232e0: str     q0, [sp, #0x10]                            
02d232e4: b       #0x2d23848                                 
02d232e8: ldr     q0, [x19, #0x30]                           
02d232ec: mov     w8, #-1                                    
02d232f0: stp     xzr, xzr, [x19, #0x30]                     
02d232f4: str     w8, [x19]                                  
02d232f8: str     q0, [sp, #0x10]                            
02d232fc: b       #0x2d235cc                                 
02d23300: adrp    x8, #0x6266000                             
02d23304: ldr     x8, [x8, #0x658]                           MS:MonoSingleton`1::get_Instance
02d23308: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d2330c: bl      #0x3769600                                 fn_3769600
02d23310: cbz     x0, #0x2d23a04                             
02d23314: adrp    x8, #0x6266000                             
02d23318: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02d2331c: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d23320: bl      #0x3168dd0                                 fn_3168dd0
02d23324: cbz     x0, #0x2d23a08                             
02d23328: ldr     x8, [x0, #0x20]                            S:'inter_ad_capping_time'
02d2332c: cbz     x8, #0x2d23a0c                             
02d23330: ldr     w8, [x8, #0x4c]                            [626604c]=0 f=0,0
02d23334: cbz     w8, #0x2d23360                             
02d23338: cbz     x20, #0x2d23a38                            
02d2333c: ldr     x0, [x20, #0x48]                           
02d23340: cbz     x0, #0x2d23a3c                             
02d23344: mov     x1, xzr                                    
02d23348: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d2334c: cbz     x0, #0x2d23a40                             
02d23350: mov     w1, #1                                     
02d23354: mov     x2, xzr                                    
02d23358: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d2335c: b       #0x2d23384                                 
02d23360: cbz     x20, #0x2d23a44                            
02d23364: ldr     x0, [x20, #0x48]                           
02d23368: cbz     x0, #0x2d23a48                             
02d2336c: mov     x1, xzr                                    
02d23370: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d23374: cbz     x0, #0x2d23a4c                             
02d23378: mov     w1, wzr                                    
02d2337c: mov     x2, xzr                                    
02d23380: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d23384: adrp    x21, #0x6265000                            
02d23388: ldr     x21, [x21, #0xb38]                         T:DevTrack
02d2338c: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d23390: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d23394: cbnz    w8, #0x2d233a0                             
02d23398: bl      #0x2b70f30                                 fn_2b70f30
02d2339c: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d233a0: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time'
02d233a4: ldr     x0, [x8, #0x348]                           S:"Unknown productId '"
02d233a8: mov     x1, xzr                                    
02d233ac: bl      #0x2c9c4e4                                 DevTrack::GameModeEnter
02d233b0: ldr     x0, [x20, #0x90]                           
02d233b4: cbz     x0, #0x2d23a10                             
02d233b8: mov     x1, xzr                                    
02d233bc: bl      #0x2cddf7c                                 ProfilePanel::UpdateAvatar
02d233c0: cbz     x0, #0x2d23a14                             
02d233c4: mov     x1, xzr                                    
02d233c8: bl      #0x2cddfec                                 ProfilePanel::UpdateLevel
02d233cc: cbz     x0, #0x2d23a18                             
02d233d0: mov     x1, xzr                                    
02d233d4: bl      #0x2cdda80                                 ProfilePanel::UpdateName
02d233d8: cbz     x0, #0x2d23a1c                             
02d233dc: mov     x1, xzr                                    
02d233e0: bl      #0x2cdddfc                                 ProfilePanel::UpdateProgress
02d233e4: cbz     x0, #0x2d23a20                             
02d233e8: mov     x1, xzr                                    
02d233ec: bl      #0x2cdddbc                                 ProfilePanel::OnShow
02d233f0: ldr     x0, [x20, #0x40]                           .<>u__1
02d233f4: cbz     x0, #0x2d23a24                             
02d233f8: mov     x1, xzr                                    
02d233fc: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d23400: cbz     x0, #0x2d23a28                             
02d23404: mov     w1, wzr                                    
02d23408: mov     x2, xzr                                    
02d2340c: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d23410: ldr     x0, [x20, #0x40]                           .<>u__1
02d23414: cbz     x0, #0x2d23a2c                             
02d23418: mov     w1, wzr                                    
02d2341c: mov     x2, xzr                                    
02d23420: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d23424: mov     x0, x20                                    
02d23428: mov     x1, xzr                                    
02d2342c: bl      #0x2cdd6b8                                 UIBase::OnShow
02d23430: adrp    x8, #0x6263000                             
02d23434: ldr     x8, [x8, #0x918]                           T:UnityEngine.Object
02d23438: ldr     x21, [x20, #0x98]                          
02d2343c: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02d23440: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d23444: cbnz    w8, #0x2d2344c                             
02d23448: bl      #0x2b70f30                                 fn_2b70f30
02d2344c: mov     x0, x21                                    
02d23450: mov     x1, xzr                                    
02d23454: mov     x2, xzr                                    
02d23458: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d2345c: tbz     w0, #0, #0x2d23470                         
02d23460: ldr     x0, [x20, #0x98]                           
02d23464: cbz     x0, #0x2d23470                             
02d23468: mov     x1, xzr                                    
02d2346c: bl      #0x2d11ba0                                 Livestream.LivestreamPanel::OnShow
02d23470: adrp    x8, #0x6266000                             
02d23474: ldr     x8, [x8, #0x9f0]                           T:Assets.SimpleLocalization.Scripts.LocalizationManager
02d23478: ldr     x21, [x20, #0x38]                          .<>4__this
02d2347c: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d23480: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d23484: cbnz    w8, #0x2d2348c                             
02d23488: bl      #0x2b70f30                                 fn_2b70f30
02d2348c: adrp    x8, #0x6266000                             
02d23490: ldr     x8, [x8, #0xd68]                           S:'Welcome !'
02d23494: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d23498: mov     x1, xzr                                    
02d2349c: bl      #0x2d76794                                 Assets.SimpleLocalization.Scripts.LocalizationManager::Localize
02d234a0: mov     x1, x0                                     
02d234a4: cbz     x21, #0x2d23a30                            
02d234a8: mov     x0, x21                                    
02d234ac: mov     x2, xzr                                    
02d234b0: bl      #0x2cb6c58                                 CommentHandler::UserComment
02d234b4: ldr     x8, [x20, #0x38]                           .<>4__this
02d234b8: cbz     x8, #0x2d23a34                             
02d234bc: mov     w9, #1                                     
02d234c0: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d234c4: strb    w9, [x8, #0x20]                            
02d234c8: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d234cc: cbnz    w8, #0x2d234d4                             
02d234d0: bl      #0x2b70f30                                 fn_2b70f30
02d234d4: fmov    s0, #1.00000000                            
02d234d8: mov     w0, wzr                                    
02d234dc: mov     w1, #8                                     
02d234e0: mov     x2, xzr                                    
02d234e4: mov     w3, wzr                                    
02d234e8: mov     x4, xzr                                    
02d234ec: bl      #0x5447b08                                 Cysharp.Threading.Tasks.UniTask::WaitForSeconds
02d234f0: stp     x0, x1, [sp, #0x20]                        
02d234f4: add     x0, sp, #0x20                              
02d234f8: mov     x1, xzr                                    
02d234fc: bl      #0x2b70d54                                 fn_2b70d54
02d23500: adrp    x21, #0x662f000                            
02d23504: ldr     q0, [sp, #0x20]                            
02d23508: ldrb    w8, [x21, #0xbdc]                          
02d2350c: str     q0, [sp, #0x10]                            
02d23510: cbnz    w8, #0x2d23528                             
02d23514: adrp    x0, #0x6266000                             
02d23518: ldr     x0, [x0, #0xcc8]                           T:Cysharp.Threading.Tasks.UniTask
02d2351c: bl      #0x2b70db0                                 fn_2b70db0
02d23520: mov     w8, #1                                     
02d23524: strb    w8, [x21, #0xbdc]                          
02d23528: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d2352c: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d23530: cbnz    w8, #0x2d23538                             
02d23534: bl      #0x2b70f30                                 fn_2b70f30
02d23538: adrp    x21, #0x662f000                            
02d2353c: ldrb    w8, [x21, #0xbdd]                          
02d23540: cbnz    w8, #0x2d23558                             
02d23544: adrp    x0, #0x6266000                             
02d23548: ldr     x0, [x0, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02d2354c: bl      #0x2b70db0                                 fn_2b70db0
02d23550: mov     w8, #1                                     
02d23554: strb    w8, [x21, #0xbdd]                          
02d23558: ldr     x21, [sp, #0x10]                           
02d2355c: cbz     x21, #0x2d235cc                            
02d23560: adrp    x10, #0x6266000                            
02d23564: ldr     x8, [x21]                                  &2b706c4(=eb01011ff9400808)
02d23568: ldr     x10, [x10, #0xcd0]                         T:Cysharp.Threading.Tasks.IUniTaskSource
02d2356c: ldrh    w22, [sp, #0x18]                           
02d23570: ldrh    w9, [x8, #0x12e]                           
02d23574: ldr     x1, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d23578: cbz     x9, #0x2d2359c                             
02d2357c: ldr     x10, [x8, #0xb0]                           S:'native_banner_ad_on_off'
02d23580: add     x10, x10, #8                               &6266008
02d23584: ldur    x11, [x10, #-8]                            
02d23588: cmp     x11, x1                                    
02d2358c: b.eq    #0x2d235ac                                 
02d23590: subs    x9, x9, #1                                 
02d23594: add     x10, x10, #0x10                            &6266010
02d23598: b.ne    #0x2d23584                                 
02d2359c: mov     x0, x21                                    
02d235a0: mov     w2, wzr                                    
02d235a4: bl      #0x2baa05c                                 fn_2baa05c
02d235a8: b       #0x2d235b8                                 
02d235ac: ldrsw   x9, [x10]                                  
02d235b0: add     x8, x8, x9, lsl #4                         &6266000
02d235b4: add     x0, x8, #0x138                             &6266138
02d235b8: ldp     x8, x2, [x0]                               
02d235bc: mov     x0, x21                                    
02d235c0: mov     w1, w22                                    
02d235c4: blr     x8                                         
02d235c8: cbz     w0, #0x2d239ac                             
02d235cc: ldrb    w8, [x23, #0xbde]                          
02d235d0: cbnz    w8, #0x2d235e8                             
02d235d4: adrp    x0, #0x6266000                             
02d235d8: ldr     x0, [x0, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02d235dc: bl      #0x2b70db0                                 fn_2b70db0
02d235e0: mov     w8, #1                                     
02d235e4: strb    w8, [x23, #0xbde]                          
02d235e8: ldr     x21, [sp, #0x10]                           
02d235ec: cbz     x21, #0x2d2365c                            
02d235f0: adrp    x10, #0x6266000                            
02d235f4: ldr     x8, [x21]                                  &2b706c4(=eb01011ff9400808)
02d235f8: ldr     x10, [x10, #0xcd0]                         T:Cysharp.Threading.Tasks.IUniTaskSource
02d235fc: ldrh    w22, [sp, #0x18]                           
02d23600: ldrh    w9, [x8, #0x12e]                           
02d23604: ldr     x1, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d23608: cbz     x9, #0x2d2362c                             
02d2360c: ldr     x10, [x8, #0xb0]                           S:'native_banner_ad_on_off'
02d23610: add     x10, x10, #8                               &6266008
02d23614: ldur    x11, [x10, #-8]                            
02d23618: cmp     x11, x1                                    
02d2361c: b.eq    #0x2d2363c                                 
02d23620: subs    x9, x9, #1                                 
02d23624: add     x10, x10, #0x10                            &6266010
02d23628: b.ne    #0x2d23614                                 
02d2362c: mov     x0, x21                                    
02d23630: mov     w2, #2                                     
02d23634: bl      #0x2baa05c                                 fn_2baa05c
02d23638: b       #0x2d2364c                                 
02d2363c: ldr     w9, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d23640: add     w9, w9, #2                                 
02d23644: add     x8, x8, w9, sxtw #4                        &6266000
02d23648: add     x0, x8, #0x138                             &6266138
02d2364c: ldp     x8, x2, [x0]                               
02d23650: mov     x0, x21                                    
02d23654: mov     w1, w22                                    
02d23658: blr     x8                                         
02d2365c: cbz     x20, #0x2d239e4                            
02d23660: ldr     x0, [x20, #0x80]                           
02d23664: cbz     x0, #0x2d239e8                             
02d23668: mov     x1, xzr                                    
02d2366c: bl      #0x2cb4bfc                                 ViewerNameAsset::PickRandomContent
02d23670: mov     x22, x0                                    
02d23674: ldr     x0, [x20, #0x88]                           
02d23678: cbz     x0, #0x2d239ec                             
02d2367c: mov     x1, xzr                                    
02d23680: bl      #0x2cb4b80                                 ViewerAvatarAsset::PickRandom
02d23684: mov     x21, x0                                    
02d23688: ldr     x0, [x20, #0x70]                           
02d2368c: cbz     x0, #0x2d239f0                             
02d23690: ldr     x8, [x0]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d23694: ldr     x9, [x8, #0x558]                           MS:NFramework.GoogleSheetConfigSO`1::.ctor
02d23698: ldr     x2, [x8, #0x560]                           MS:NFramework.GoogleSheetConfigSO`1::OpenSheet
02d2369c: mov     x1, x22                                    
02d236a0: blr     x9                                         
02d236a4: ldr     x0, [x20, #0x58]                           
02d236a8: cbz     x0, #0x2d239f4                             
02d236ac: mov     x1, x21                                    
02d236b0: mov     x2, xzr                                    
02d236b4: bl      #0x5c45aa0                                 UnityEngine.UI.Image::set_sprite
02d236b8: adrp    x8, #0x6266000                             
02d236bc: ldr     x8, [x8, #0xac0]                           MS:MonoSingleton`1::get_Instance
02d236c0: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d236c4: bl      #0x3769600                                 fn_3769600
02d236c8: cbz     x0, #0x2d239f8                             
02d236cc: str     x21, [x0, #0x68]!                          
02d236d0: mov     x1, x21                                    
02d236d4: bl      #0x2b70d54                                 fn_2b70d54
02d236d8: mov     x0, xzr                                    
02d236dc: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d236e0: cbz     x0, #0x2d239fc                             
02d236e4: movi    d1, #0000000000000000                      
02d236e8: movi    d2, #0000000000000000                      
02d236ec: mov     w1, #4                                     
02d236f0: fmov    s0, #1.00000000                            
02d236f4: mov     w2, wzr                                    
02d236f8: mov     w3, wzr                                    
02d236fc: mov     x4, xzr                                    
02d23700: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d23704: ldrb    w8, [x20, #0x20]                           
02d23708: cbz     w8, #0x2d23740                             
02d2370c: ldr     x0, [x20, #0xa0]                           
02d23710: cbz     x0, #0x2d23a00                             
02d23714: mov     x1, xzr                                    
02d23718: bl      #0x5b368f0                                 UnityEngine.GameObject::get_transform
02d2371c: fmov    s0, #1.00000000                            
02d23720: fmov    s1, #0.50000000                            
02d23724: mov     x1, xzr                                    
02d23728: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d2372c: adrp    x8, #0x6266000                             
02d23730: ldr     x8, [x8, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d23734: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d23738: mov     w1, #0x1b                                  
02d2373c: bl      #0x336fa0c                                 fn_336fa0c
02d23740: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d23744: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d23748: cbnz    w8, #0x2d23750                             
02d2374c: bl      #0x2b70f30                                 fn_2b70f30
02d23750: fmov    s0, #1.00000000                            
02d23754: mov     w0, wzr                                    
02d23758: mov     w1, #8                                     
02d2375c: mov     x2, xzr                                    
02d23760: mov     w3, wzr                                    
02d23764: mov     x4, xzr                                    
02d23768: bl      #0x5447b08                                 Cysharp.Threading.Tasks.UniTask::WaitForSeconds
02d2376c: stp     x0, x1, [sp, #0x20]                        
02d23770: add     x0, sp, #0x20                              
02d23774: mov     x1, xzr                                    
02d23778: bl      #0x2b70d54                                 fn_2b70d54
02d2377c: adrp    x21, #0x662f000                            
02d23780: ldr     q0, [sp, #0x20]                            
02d23784: ldrb    w8, [x21, #0xbdc]                          
02d23788: str     q0, [sp, #0x10]                            
02d2378c: cbnz    w8, #0x2d237a4                             
02d23790: adrp    x0, #0x6266000                             
02d23794: ldr     x0, [x0, #0xcc8]                           T:Cysharp.Threading.Tasks.UniTask
02d23798: bl      #0x2b70db0                                 fn_2b70db0
02d2379c: mov     w8, #1                                     
02d237a0: strb    w8, [x21, #0xbdc]                          
02d237a4: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d237a8: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d237ac: cbnz    w8, #0x2d237b4                             
02d237b0: bl      #0x2b70f30                                 fn_2b70f30
02d237b4: adrp    x21, #0x662f000                            
02d237b8: ldrb    w8, [x21, #0xbdd]                          
02d237bc: cbnz    w8, #0x2d237d4                             
02d237c0: adrp    x0, #0x6266000                             
02d237c4: ldr     x0, [x0, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02d237c8: bl      #0x2b70db0                                 fn_2b70db0
02d237cc: mov     w8, #1                                     
02d237d0: strb    w8, [x21, #0xbdd]                          
02d237d4: ldr     x21, [sp, #0x10]                           
02d237d8: cbz     x21, #0x2d23848                            
02d237dc: adrp    x10, #0x6266000                            
02d237e0: ldr     x8, [x21]                                  &2b706c4(=eb01011ff9400808)
02d237e4: ldr     x10, [x10, #0xcd0]                         T:Cysharp.Threading.Tasks.IUniTaskSource
02d237e8: ldrh    w22, [sp, #0x18]                           
02d237ec: ldrh    w9, [x8, #0x12e]                           
02d237f0: ldr     x1, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d237f4: cbz     x9, #0x2d23818                             
02d237f8: ldr     x10, [x8, #0xb0]                           S:'native_banner_ad_on_off'
02d237fc: add     x10, x10, #8                               &6266008
02d23800: ldur    x11, [x10, #-8]                            
02d23804: cmp     x11, x1                                    
02d23808: b.eq    #0x2d23828                                 
02d2380c: subs    x9, x9, #1                                 
02d23810: add     x10, x10, #0x10                            &6266010
02d23814: b.ne    #0x2d23800                                 
02d23818: mov     x0, x21                                    
02d2381c: mov     w2, wzr                                    
02d23820: bl      #0x2baa05c                                 fn_2baa05c
02d23824: b       #0x2d23834                                 
02d23828: ldrsw   x9, [x10]                                  
02d2382c: add     x8, x8, x9, lsl #4                         &6266000
02d23830: add     x0, x8, #0x138                             &6266138
02d23834: ldp     x8, x2, [x0]                               
02d23838: mov     x0, x21                                    
02d2383c: mov     w1, w22                                    
02d23840: blr     x8                                         
02d23844: cbz     w0, #0x2d23970                             
02d23848: ldrb    w8, [x23, #0xbde]                          
02d2384c: cbnz    w8, #0x2d23864                             
02d23850: adrp    x0, #0x6266000                             
02d23854: ldr     x0, [x0, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02d23858: bl      #0x2b70db0                                 fn_2b70db0
02d2385c: mov     w8, #1                                     
02d23860: strb    w8, [x23, #0xbde]                          
02d23864: ldr     x21, [sp, #0x10]                           
02d23868: cbz     x21, #0x2d238d8                            
02d2386c: adrp    x10, #0x6266000                            
02d23870: ldr     x8, [x21]                                  &2b706c4(=eb01011ff9400808)
02d23874: ldr     x10, [x10, #0xcd0]                         T:Cysharp.Threading.Tasks.IUniTaskSource
02d23878: ldrh    w22, [sp, #0x18]                           
02d2387c: ldrh    w9, [x8, #0x12e]                           
02d23880: ldr     x1, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d23884: cbz     x9, #0x2d238a8                             
02d23888: ldr     x10, [x8, #0xb0]                           S:'native_banner_ad_on_off'
02d2388c: add     x10, x10, #8                               &6266008
02d23890: ldur    x11, [x10, #-8]                            
02d23894: cmp     x11, x1                                    
02d23898: b.eq    #0x2d238b8                                 
02d2389c: subs    x9, x9, #1                                 
02d238a0: add     x10, x10, #0x10                            &6266010
02d238a4: b.ne    #0x2d23890                                 
02d238a8: mov     x0, x21                                    
02d238ac: mov     w2, #2                                     
02d238b0: bl      #0x2baa05c                                 fn_2baa05c
02d238b4: b       #0x2d238c8                                 
02d238b8: ldr     w9, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d238bc: add     w9, w9, #2                                 
02d238c0: add     x8, x8, w9, sxtw #4                        &6266000
02d238c4: add     x0, x8, #0x138                             &6266138
02d238c8: ldp     x8, x2, [x0]                               
02d238cc: mov     x0, x21                                    
02d238d0: mov     w1, w22                                    
02d238d4: blr     x8                                         
02d238d8: adrp    x8, #0x6267000                             
02d238dc: ldr     x8, [x8, #0xea8]                           T:Framework.Vibration
02d238e0: ldr     x0, [x8]                                   S:'didu'
02d238e4: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d238e8: cbnz    w8, #0x2d238f0                             
02d238ec: bl      #0x2b70f30                                 fn_2b70f30
02d238f0: mov     w0, #0x64                                  
02d238f4: mov     w1, #-1                                    
02d238f8: mov     w2, wzr                                    
02d238fc: mov     x3, xzr                                    
02d23900: bl      #0x2d6e144                                 Framework.Vibration::Vibrate
02d23904: adrp    x8, #0x6264000                             
02d23908: ldr     x8, [x8, #0xe8]                            T:DG.Tweening.TweenCallback
02d2390c: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d23910: bl      #0x2b7104c                                 fn_2b7104c
02d23914: adrp    x8, #0x6269000                             
02d23918: mov     x21, x0                                    
02d2391c: ldr     x8, [x8, #0xed0]                           M:Home.PopupPrepare::<OnShow>b__17_0
02d23920: ldr     x2, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d23924: mov     x1, x20                                    
02d23928: mov     x3, xzr                                    
02d2392c: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d23930: fmov    s0, #0.50000000                            
02d23934: mov     x0, x21                                    
02d23938: mov     w1, #1                                     
02d2393c: mov     x2, xzr                                    
02d23940: bl      #0x2d8f37c                                 DG.Tweening.DOVirtual::DelayedCall
02d23944: mov     w8, #-2                                    
02d23948: mov     x1, xzr                                    
02d2394c: str     w8, [x19], #8                              
02d23950: mov     x0, x19                                    
02d23954: bl      #0x4d43b50                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::SetResult
02d23958: ldp     x20, x19, [sp, #0x60]                      
02d2395c: ldr     x30, [sp, #0x30]                           
02d23960: ldp     x22, x21, [sp, #0x50]                      
02d23964: ldp     x24, x23, [sp, #0x40]                      
02d23968: add     sp, sp, #0x70                              
02d2396c: ret                                                
02d23970: ldr     q0, [sp, #0x10]                            
02d23974: mov     w8, #1                                     
02d23978: str     w8, [x19]                                  
02d2397c: str     q0, [x19, #0x30]                           
02d23980: add     x0, x19, #0x30                             
02d23984: mov     x1, xzr                                    
02d23988: bl      #0x2b70d54                                 fn_2b70d54
02d2398c: adrp    x8, #0x6269000                             
02d23990: ldr     x8, [x8, #0xec8]                           MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::AwaitUnsafeOnCompleted
02d23994: ldr     x3, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d23998: add     x0, x19, #8                                
02d2399c: add     x1, sp, #0x10                              
02d239a0: mov     x2, x19                                    
02d239a4: bl      #0x30c47fc                                 fn_30c47fc
02d239a8: b       #0x2d23958                                 
02d239ac: ldr     q0, [sp, #0x10]                            
02d239b0: str     wzr, [x19]                                 
02d239b4: str     q0, [x19, #0x30]                           
02d239b8: add     x0, x19, #0x30                             
02d239bc: mov     x1, xzr                                    
02d239c0: bl      #0x2b70d54                                 fn_2b70d54
02d239c4: adrp    x8, #0x6269000                             
02d239c8: ldr     x8, [x8, #0xec8]                           MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::AwaitUnsafeOnCompleted
02d239cc: ldr     x3, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d239d0: add     x0, x19, #8                                
02d239d4: add     x1, sp, #0x10                              
02d239d8: mov     x2, x19                                    
02d239dc: bl      #0x30c47fc                                 fn_30c47fc
02d239e0: b       #0x2d23958                                 
02d239e4: bl      #0x2b7105c                                 fn_2b7105c
02d239e8: bl      #0x2b7105c                                 fn_2b7105c
02d239ec: bl      #0x2b7105c                                 fn_2b7105c
02d239f0: bl      #0x2b7105c                                 fn_2b7105c
02d239f4: bl      #0x2b7105c                                 fn_2b7105c
02d239f8: bl      #0x2b7105c                                 fn_2b7105c
02d239fc: bl      #0x2b7105c                                 fn_2b7105c
02d23a00: bl      #0x2b7105c                                 fn_2b7105c
02d23a04: bl      #0x2b7105c                                 fn_2b7105c
02d23a08: bl      #0x2b7105c                                 fn_2b7105c
02d23a0c: bl      #0x2b7105c                                 fn_2b7105c
02d23a10: bl      #0x2b7105c                                 fn_2b7105c
02d23a14: bl      #0x2b7105c                                 fn_2b7105c
02d23a18: bl      #0x2b7105c                                 fn_2b7105c
02d23a1c: bl      #0x2b7105c                                 fn_2b7105c
02d23a20: bl      #0x2b7105c                                 fn_2b7105c
02d23a24: bl      #0x2b7105c                                 fn_2b7105c
02d23a28: bl      #0x2b7105c                                 fn_2b7105c
02d23a2c: bl      #0x2b7105c                                 fn_2b7105c
02d23a30: bl      #0x2b7105c                                 fn_2b7105c
02d23a34: bl      #0x2b7105c                                 fn_2b7105c
02d23a38: bl      #0x2b7105c                                 fn_2b7105c
02d23a3c: bl      #0x2b7105c                                 fn_2b7105c
02d23a40: bl      #0x2b7105c                                 fn_2b7105c
02d23a44: bl      #0x2b7105c                                 fn_2b7105c
02d23a48: bl      #0x2b7105c                                 fn_2b7105c
02d23a4c: bl      #0x2b7105c                                 fn_2b7105c
02d23a50: b       #0x2d23b24                                 
02d23a54: b       #0x2d23b24                                 
02d23a58: b       #0x2d23b24                                 
02d23a5c: b       #0x2d23b24                                 
02d23a60: b       #0x2d23b24                                 
02d23a64: b       #0x2d23b24                                 
02d23a68: b       #0x2d23b24                                 
02d23a6c: b       #0x2d23b24                                 
02d23a70: b       #0x2d23b24                                 
02d23a74: b       #0x2d23b24                                 
02d23a78: b       #0x2d23b24                                 
02d23a7c: b       #0x2d23b24                                 
02d23a80: b       #0x2d23b24                                 
02d23a84: b       #0x2d23b24                                 
02d23a88: b       #0x2d23b24                                 
02d23a8c: b       #0x2d23b24                                 
02d23a90: b       #0x2d23b24                                 
02d23a94: b       #0x2d23b24                                 
02d23a98: b       #0x2d23b24                                 
02d23a9c: b       #0x2d23b24                                 
02d23aa0: b       #0x2d23b24                                 
02d23aa4: b       #0x2d23b24                                 
02d23aa8: b       #0x2d23b24                                 
02d23aac: b       #0x2d23b24                                 
02d23ab0: b       #0x2d23b24                                 
02d23ab4: b       #0x2d23b24                                 
02d23ab8: b       #0x2d23b24                                 
02d23abc: b       #0x2d23b24                                 
02d23ac0: b       #0x2d23b24                                 
02d23ac4: b       #0x2d23b24                                 
02d23ac8: b       #0x2d23b24                                 
02d23acc: b       #0x2d23b24                                 
02d23ad0: b       #0x2d23b24                                 
02d23ad4: b       #0x2d23b24                                 
02d23ad8: b       #0x2d23b24                                 
02d23adc: b       #0x2d23b24                                 
02d23ae0: b       #0x2d23b24                                 
02d23ae4: b       #0x2d23b24                                 
02d23ae8: b       #0x2d23b24                                 
02d23aec: b       #0x2d23b24                                 
02d23af0: b       #0x2d23b24                                 
02d23af4: b       #0x2d23b24                                 
02d23af8: b       #0x2d23b24                                 
02d23afc: b       #0x2d23b24                                 
02d23b00: b       #0x2d23b24                                 
02d23b04: b       #0x2d23b24                                 
02d23b08: b       #0x2d23b24                                 
02d23b0c: b       #0x2d23b24                                 
02d23b10: b       #0x2d23b24                                 
02d23b14: b       #0x2d23b24                                 
02d23b18: b       #0x2d23b24                                 
02d23b1c: b       #0x2d23b24                                 
02d23b20: b       #0x2d23b24                                 
02d23b24: mov     x20, x0                                    
02d23b28: cmp     w1, #1                                     
02d23b2c: b.ne    #0x2d23bbc                                 
02d23b30: mov     x0, x20                                    
02d23b34: bl      #0x5e90260                                 fn_5e90260
02d23b38: mov     x20, x0                                    
02d23b3c: adrp    x0, #0x6263000                             
02d23b40: ldr     x0, [x0, #0xae0]                           T:System.Exception
02d23b44: bl      #0x2b70dc4                                 fn_2b70dc4
02d23b48: ldr     x8, [x20]                                  
02d23b4c: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d23b50: bl      #0x2b71464                                 fn_2b71464
02d23b54: tbz     w0, #0, #0x2d23b94                         
02d23b58: ldrsw   x21, [sp, #8]                              
02d23b5c: ldr     x20, [x20]                                 
02d23b60: mov     x8, sp                                     
02d23b64: str     x20, [x8, x21, lsl #3]                     
02d23b68: add     w8, w21, #1                                
02d23b6c: str     w8, [sp, #8]                               
02d23b70: bl      #0x5e90270                                 fn_5e90270
02d23b74: mov     w8, #-2                                    
02d23b78: mov     x1, x20                                    
02d23b7c: mov     x2, xzr                                    
02d23b80: str     w8, [x19], #8                              
02d23b84: mov     x0, x19                                    
02d23b88: bl      #0x4d43cc0                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::SetException
02d23b8c: str     w21, [sp, #8]                              
02d23b90: b       #0x2d23958                                 
02d23b94: mov     w0, #8                                     
02d23b98: bl      #0x5e90290                                 fn_5e90290
02d23b9c: ldr     x8, [x20]                                  
02d23ba0: str     x8, [x0]                                   
02d23ba4: adrp    x1, #0x5e96000                             
02d23ba8: add     x1, x1, #0x758                             &5e96758
02d23bac: mov     x2, xzr                                    
02d23bb0: bl      #0x5e902a0                                 fn_5e902a0
02d23bb4: mov     x20, x0                                    
02d23bb8: bl      #0x5e90270                                 fn_5e90270
02d23bbc: mov     x0, x20                                    
02d23bc0: bl      #0x2c6051c                                 fn_2c6051c
02d23bc4: bl      #0x27369b8                                 fn_27369b8
## SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine stateMachine) -> void
---- Home.PopupPrepare/<OnShow>d__17::SetStateMachine 0x2d23bc8
02d23bc8: add     x0, x0, #8                                 
02d23bcc: mov     x2, xzr                                    
02d23bd0: b       #0x4d43a8c                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::SetStateMachine
#### CLASS Home.PopupPrepare parent= PopupBase
#   field _commentHandler                CommentHandler                                     off=0x38 attr=1 SerializeField
#   field _playButton                    UnityEngine.UI.Button                              off=0x40 attr=1 SerializeField
#   field _backButton                    UnityEngine.UI.Button                              off=0x48 attr=1 SerializeField
#   field _playButtonImage               UnityEngine.UI.Image                               off=0x50 attr=1 SerializeField
#   field _customerAvatar                UnityEngine.UI.Image                               off=0x58 attr=1 SerializeField
#   field _txtPlayButton                 TMPro.TextMeshProUGUI                              off=0x60 attr=1 SerializeField
#   field _txtPlayButtonOff              TMPro.TextMeshProUGUI                              off=0x68 attr=1 SerializeField
#   field _txtCustomerName               TMPro.TextMeshProUGUI                              off=0x70 attr=1 SerializeField
#   field _txtTipMoney                   TMPro.TextMeshProUGUI                              off=0x78 attr=1 SerializeField
#   field _viewerNameAsset               ViewerNameAsset                                    off=0x80 attr=1 SerializeField
#   field _viewerAvatarAsset             ViewerAvatarAsset                                  off=0x88 attr=1 SerializeField
#   field _profilePanel                  ProfilePanel                                       off=0x90 attr=1 SerializeField
#   field _livestreamPanel               Livestream.LivestreamPanel                         off=0x98 attr=1 SerializeField
#   field _missionBoard                  UnityEngine.GameObject                             off=0xa0 attr=1 SerializeField
#   field _coroutineSpawnComment         UnityEngine.Coroutine                              off=0xa8 attr=1 
## OnInit(UIManager uiManager) -> void
---- Home.PopupPrepare::OnInit 0x2d22798
02d22798: str     x30, [sp, #-0x30]!                         
02d2279c: stp     x22, x21, [sp, #0x10]                      
02d227a0: stp     x20, x19, [sp, #0x20]                      
02d227a4: adrp    x21, #0x6630000                            
02d227a8: mov     x20, x1                                    
02d227ac: mov     x19, x0                                    
02d227b0: ldrb    w8, [x21, #0x52]                           
02d227b4: tbnz    w8, #0, #0x2d227fc                         
02d227b8: adrp    x0, #0x6269000                             
02d227bc: ldr     x0, [x0, #0xea0]                           M:Home.PopupPrepare::OnButtonBackClicked
02d227c0: bl      #0x2b70db0                                 fn_2b70db0
02d227c4: adrp    x0, #0x6269000                             
02d227c8: ldr     x0, [x0, #0xea8]                           M:Home.PopupPrepare::OnButtonPlayClicked
02d227cc: bl      #0x2b70db0                                 fn_2b70db0
02d227d0: adrp    x0, #0x6264000                             
02d227d4: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02d227d8: bl      #0x2b70db0                                 fn_2b70db0
02d227dc: adrp    x0, #0x6265000                             
02d227e0: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d227e4: bl      #0x2b70db0                                 fn_2b70db0
02d227e8: adrp    x0, #0x6269000                             
02d227ec: ldr     x0, [x0, #0xdb8]                           S:'+{0}'
02d227f0: bl      #0x2b70db0                                 fn_2b70db0
02d227f4: mov     w8, #1                                     
02d227f8: strb    w8, [x21, #0x52]                           
02d227fc: mov     x0, x19                                    
02d22800: mov     x1, x20                                    
02d22804: mov     x2, xzr                                    
02d22808: bl      #0x2cdd3c4                                 UIBase::OnInit
02d2280c: ldr     x8, [x19, #0x40]                           ._playButton
02d22810: cbz     x8, #0x2d229b8                             
02d22814: adrp    x22, #0x6265000                            
02d22818: adrp    x21, #0x6269000                            
02d2281c: ldr     x22, [x22, #0x3f0]                         T:UnityEngine.Events.UnityAction
02d22820: ldr     x21, [x21, #0xea8]                         M:Home.PopupPrepare::OnButtonPlayClicked
02d22824: ldr     x20, [x8, #0x100]                          
02d22828: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d2282c: bl      #0x2b7104c                                 fn_2b7104c
02d22830: ldr     x2, [x21]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d22834: mov     x1, x19                                    
02d22838: mov     x3, xzr                                    
02d2283c: mov     x21, x0                                    
02d22840: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d22844: cbz     x20, #0x2d229b8                            
02d22848: mov     x0, x20                                    
02d2284c: mov     x1, x21                                    
02d22850: mov     x2, xzr                                    
02d22854: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d22858: ldr     x8, [x19, #0x48]                           ._backButton
02d2285c: cbz     x8, #0x2d229b8                             
02d22860: adrp    x21, #0x6269000                            
02d22864: ldr     x21, [x21, #0xea0]                         M:Home.PopupPrepare::OnButtonBackClicked
02d22868: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d2286c: ldr     x20, [x8, #0x100]                          
02d22870: bl      #0x2b7104c                                 fn_2b7104c
02d22874: ldr     x2, [x21]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d22878: mov     x1, x19                                    
02d2287c: mov     x3, xzr                                    
02d22880: mov     x21, x0                                    
02d22884: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d22888: cbz     x20, #0x2d229b8                            
02d2288c: mov     x0, x20                                    
02d22890: mov     x1, x21                                    
02d22894: mov     x2, xzr                                    
02d22898: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d2289c: ldr     x0, [x19, #0x98]                           ._livestreamPanel
02d228a0: cbz     x0, #0x2d229b8                             
02d228a4: mov     x1, xzr                                    
02d228a8: bl      #0x2d11b9c                                 Livestream.LivestreamPanel::Initialized
02d228ac: ldr     x0, [x19, #0xa0]                           ._missionBoard
02d228b0: cbz     x0, #0x2d229b8                             
02d228b4: mov     x1, xzr                                    
02d228b8: bl      #0x5b368f0                                 UnityEngine.GameObject::get_transform
02d228bc: adrp    x21, #0x662f000                            
02d228c0: mov     x20, x0                                    
02d228c4: ldrb    w8, [x21, #0x91a]                          
02d228c8: cbnz    w8, #0x2d228e0                             
02d228cc: adrp    x0, #0x6264000                             
02d228d0: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d228d4: bl      #0x2b70db0                                 fn_2b70db0
02d228d8: mov     w8, #1                                     
02d228dc: strb    w8, [x21, #0x91a]                          
02d228e0: cbz     x20, #0x2d229b8                            
02d228e4: adrp    x8, #0x6264000                             
02d228e8: adrp    x21, #0x6264000                            
02d228ec: mov     x0, x20                                    
02d228f0: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02d228f4: mov     x1, xzr                                    
02d228f8: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d228fc: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d22900: ldr     x21, [x21, #0xfc0]                         T:RemoteConfigManager
02d22904: ldp     s1, s2, [x8, #4]                           
02d22908: ldr     s0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d2290c: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d22910: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d22914: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02d22918: cbnz    w8, #0x2d22920                             
02d2291c: bl      #0x2b70f30                                 fn_2b70f30
02d22920: adrp    x20, #0x662f000                            
02d22924: ldrb    w8, [x20, #0xbc1]                          
02d22928: cbnz    w8, #0x2d22940                             
02d2292c: adrp    x0, #0x6264000                             
02d22930: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02d22934: bl      #0x2b70db0                                 fn_2b70db0
02d22938: mov     w8, #1                                     
02d2293c: strb    w8, [x20, #0xbc1]                          
02d22940: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d22944: adrp    x20, #0x6269000                            
02d22948: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02d2294c: ldr     x20, [x20, #0xdb8]                         S:'+{0}'
02d22950: cbnz    w8, #0x2d22958                             
02d22954: bl      #0x2b70f30                                 fn_2b70f30
02d22958: adrp    x8, #0x6263000                             
02d2295c: mov     w9, #0x64                                  
02d22960: add     x1, sp, #0xc                               
02d22964: ldr     x8, [x8, #0x970]                           &6645c70(=0)
02d22968: ldr     x19, [x19, #0x78]                          ._txtTipMoney
02d2296c: str     w9, [sp, #0xc]                             
02d22970: ldr     x0, [x8, #0x48]                            &6263098(=0)
02d22974: bl      #0x2b70f38                                 fn_2b70f38
02d22978: ldr     x8, [x20]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d2297c: mov     x1, x0                                     
02d22980: mov     x2, xzr                                    
02d22984: mov     x0, x8                                     
02d22988: bl      #0x4c9d0ec                                 System.String::Format
02d2298c: cbz     x19, #0x2d229b8                            
02d22990: ldr     x8, [x19]                                  
02d22994: mov     x1, x0                                     
02d22998: mov     x0, x19                                    
02d2299c: ldr     x9, [x8, #0x558]                           &2c5d934(=d65f03c0d503245f)
02d229a0: ldr     x2, [x8, #0x560]                           &2c5d58c(=14c8cc6cd503245f)
02d229a4: blr     x9                                         
02d229a8: ldp     x20, x19, [sp, #0x20]                      
02d229ac: ldp     x22, x21, [sp, #0x10]                      
02d229b0: ldr     x30, [sp], #0x30                           
02d229b4: ret                                                
02d229b8: bl      #0x2b7105c                                 fn_2b7105c
## OnHide() -> void
---- Home.PopupPrepare::OnHide 0x2d229bc
02d229bc: stp     x30, x19, [sp, #-0x10]!                    
02d229c0: mov     x1, xzr                                    
02d229c4: mov     x19, x0                                    
02d229c8: bl      #0x2cddc10                                 UIBase::OnHide
02d229cc: ldr     x0, [x19, #0x98]                           ._livestreamPanel
02d229d0: cbz     x0, #0x2d229e0                             
02d229d4: mov     x1, xzr                                    
02d229d8: ldp     x30, x19, [sp], #0x10                      
02d229dc: b       #0x2d11cdc                                 Livestream.LivestreamPanel::OnHide
02d229e0: bl      #0x2b7105c                                 fn_2b7105c
## OnShow() -> void
---- Home.PopupPrepare::OnShow 0x2d229e4
02d229e4: sub     sp, sp, #0x80                              
02d229e8: stp     x30, x21, [sp, #0x60]                      
02d229ec: stp     x20, x19, [sp, #0x70]                      
02d229f0: adrp    x21, #0x6630000                            
02d229f4: adrp    x20, #0x6269000                            
02d229f8: mov     x19, x0                                    
02d229fc: ldrb    w8, [x21, #0x53]                           
02d22a00: ldr     x20, [x20, #0xeb0]                         MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::Start
02d22a04: tbnz    w8, #0, #0x2d22a1c                         
02d22a08: adrp    x0, #0x6269000                             
02d22a0c: ldr     x0, [x0, #0xeb0]                           MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::Start
02d22a10: bl      #0x2b70db0                                 fn_2b70db0
02d22a14: mov     w8, #1                                     
02d22a18: strb    w8, [x21, #0x53]                           
02d22a1c: movi    v0.2d, #0000000000000000                   
02d22a20: mov     x8, sp                                     
02d22a24: mov     x0, xzr                                    
02d22a28: stp     q0, q0, [sp, #0x20]                        
02d22a2c: stp     q0, q0, [sp, #0x40]                        
02d22a30: bl      #0x4d43a24                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::Create
02d22a34: ldp     q0, q1, [sp]                               
02d22a38: add     x21, sp, #0x20                             
02d22a3c: orr     x0, x21, #8                                
02d22a40: mov     x1, xzr                                    
02d22a44: stur    q0, [sp, #0x28]                            
02d22a48: stur    q1, [sp, #0x38]                            
02d22a4c: bl      #0x2b70d54                                 fn_2b70d54
02d22a50: add     x0, x21, #0x28                             &6630028
02d22a54: mov     x1, x19                                    
02d22a58: str     x19, [sp, #0x48]                           
02d22a5c: bl      #0x2b70d54                                 fn_2b70d54
02d22a60: ldr     x2, [x20]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d22a64: mov     w8, #-1                                    
02d22a68: orr     x0, x21, #8                                
02d22a6c: add     x1, sp, #0x20                              
02d22a70: str     w8, [sp, #0x20]                            
02d22a74: bl      #0x30c8808                                 fn_30c8808
02d22a78: ldp     x20, x19, [sp, #0x70]                      
02d22a7c: ldp     x30, x21, [sp, #0x60]                      
02d22a80: add     sp, sp, #0x80                              
02d22a84: ret                                                
## OnButtonPlayClicked() -> void
---- Home.PopupPrepare::OnButtonPlayClicked 0x2d22a88
02d22a88: str     x30, [sp, #-0x30]!                         
02d22a8c: stp     x22, x21, [sp, #0x10]                      
02d22a90: stp     x20, x19, [sp, #0x20]                      
02d22a94: adrp    x20, #0x6630000                            
02d22a98: mov     x19, x0                                    
02d22a9c: ldrb    w8, [x20, #0x54]                           
02d22aa0: tbnz    w8, #0, #0x2d22b00                         
02d22aa4: adrp    x0, #0x6266000                             
02d22aa8: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d22aac: bl      #0x2b70db0                                 fn_2b70db0
02d22ab0: adrp    x0, #0x6265000                             
02d22ab4: ldr     x0, [x0, #0xb38]                           T:DevTrack
02d22ab8: bl      #0x2b70db0                                 fn_2b70db0
02d22abc: adrp    x0, #0x6266000                             
02d22ac0: ldr     x0, [x0, #0x5e0]                           T:GameConfig
02d22ac4: bl      #0x2b70db0                                 fn_2b70db0
02d22ac8: adrp    x0, #0x6267000                             
02d22acc: ldr     x0, [x0, #0xd50]                           MS:MonoSingleton`1::get_Instance
02d22ad0: bl      #0x2b70db0                                 fn_2b70db0
02d22ad4: adrp    x0, #0x6265000                             
02d22ad8: ldr     x0, [x0, #0x10]                            MS:MonoSingleton`1::get_Instance
02d22adc: bl      #0x2b70db0                                 fn_2b70db0
02d22ae0: adrp    x0, #0x6266000                             
02d22ae4: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d22ae8: bl      #0x2b70db0                                 fn_2b70db0
02d22aec: adrp    x0, #0x6266000                             
02d22af0: ldr     x0, [x0, #0xb48]                           MS:MonoSingleton`1::get_Instance
02d22af4: bl      #0x2b70db0                                 fn_2b70db0
02d22af8: mov     w8, #1                                     
02d22afc: strb    w8, [x20, #0x54]                           
02d22b00: mov     x0, xzr                                    
02d22b04: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d22b08: cbz     x0, #0x2d22d48                             
02d22b0c: movi    d1, #0000000000000000                      
02d22b10: movi    d2, #0000000000000000                      
02d22b14: adrp    x20, #0x6267000                            
02d22b18: fmov    s0, #1.00000000                            
02d22b1c: ldr     x20, [x20, #0xd50]                         MS:MonoSingleton`1::get_Instance
02d22b20: mov     w1, #1                                     
02d22b24: mov     w2, wzr                                    
02d22b28: mov     w3, wzr                                    
02d22b2c: mov     x4, xzr                                    
02d22b30: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d22b34: ldr     x0, [x20]                                  S:'didu'
02d22b38: bl      #0x3769600                                 fn_3769600
02d22b3c: cbz     x0, #0x2d22d48                             
02d22b40: mov     w1, #4                                     
02d22b44: mov     x2, xzr                                    
02d22b48: bl      #0x2cc6ee0                                 Framework.VibrationManager::Haptic
02d22b4c: mov     x0, x19                                    
02d22b50: bl      #0x2d22d4c                                 Home.PopupPrepare::StartButtonPlayClickEffect
02d22b54: ldr     x0, [x19, #0x40]                           ._playButton
02d22b58: cbz     x0, #0x2d22d48                             
02d22b5c: mov     w1, wzr                                    
02d22b60: mov     x2, xzr                                    
02d22b64: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d22b68: ldr     x8, [x19, #0x38]                           ._commentHandler
02d22b6c: cbz     x8, #0x2d22d48                             
02d22b70: adrp    x9, #0x6265000                             
02d22b74: adrp    x20, #0x6266000                            
02d22b78: ldr     x9, [x9, #0x10]                            MS:MonoSingleton`1::get_Instance
02d22b7c: ldr     x20, [x20, #0x5e0]                         T:GameConfig
02d22b80: strb    wzr, [x8, #0x20]                           
02d22b84: ldr     x0, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02d22b88: bl      #0x3769600                                 fn_3769600
02d22b8c: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d22b90: mov     x19, x0                                    
02d22b94: ldr     w9, [x8, #0xe4]                            
02d22b98: cbnz    w9, #0x2d22ba4                             
02d22b9c: mov     x0, x8                                     
02d22ba0: bl      #0x2b70f30                                 fn_2b70f30
02d22ba4: cbz     x19, #0x2d22d48                            
02d22ba8: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d22bac: adrp    x20, #0x6266000                            
02d22bb0: mov     x0, x19                                    
02d22bb4: mov     w2, wzr                                    
02d22bb8: mov     x3, xzr                                    
02d22bbc: ldr     x8, [x8, #0xb8]                            
02d22bc0: ldr     x20, [x20, #0x658]                         MS:MonoSingleton`1::get_Instance
02d22bc4: ldr     x1, [x8, #0x28]                            
02d22bc8: bl      #0x2ce9e58                                 SimpleSceneTransition::FlashIn
02d22bcc: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d22bd0: bl      #0x3769600                                 fn_3769600
02d22bd4: cbz     x0, #0x2d22d48                             
02d22bd8: adrp    x8, #0x6266000                             
02d22bdc: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02d22be0: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d22be4: bl      #0x3168dd0                                 fn_3168dd0
02d22be8: cbz     x0, #0x2d22d48                             
02d22bec: ldr     x8, [x0, #0x20]                            S:'inter_ad_capping_time'
02d22bf0: mov     x19, x0                                    
02d22bf4: cbz     x8, #0x2d22d48                             
02d22bf8: adrp    x21, #0x6265000                            
02d22bfc: adrp    x22, #0x6266000                            
02d22c00: ldr     x21, [x21, #0xb38]                         T:DevTrack
02d22c04: ldrb    w8, [x8, #0x3a]                            
02d22c08: ldr     x22, [x22, #0xb48]                         MS:MonoSingleton`1::get_Instance
02d22c0c: cbz     w8, #0x2d22c3c                             
02d22c10: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d22c14: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d22c18: cbnz    w8, #0x2d22c24                             
02d22c1c: bl      #0x2b70f30                                 fn_2b70f30
02d22c20: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d22c24: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time'
02d22c28: mov     x3, xzr                                    
02d22c2c: ldr     x0, [x8, #0x1f8]                           MS:System.Collections.Generic.List`1/Enumerator::get_Current
02d22c30: ldr     x1, [x8, #0x218]                           MS:System.Collections.Generic.List`1::.ctor
02d22c34: ldr     w2, [x8, #0x270]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d22c38: bl      #0x2c9c1e0                                 DevTrack::OnboardingStep
02d22c3c: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d22c40: bl      #0x3769600                                 fn_3769600
02d22c44: ldr     x8, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d22c48: mov     x20, x0                                    
02d22c4c: ldr     w9, [x8, #0xe4]                            [62660e4]=0 f=0,0
02d22c50: cbnz    w9, #0x2d22c5c                             
02d22c54: mov     x0, x8                                     
02d22c58: bl      #0x2b70f30                                 fn_2b70f30
02d22c5c: cbz     x20, #0x2d22d48                            
02d22c60: ldr     x8, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d22c64: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02d22c68: ldr     x1, [x8, #0x348]                           S:"Unknown productId '"
02d22c6c: str     x1, [x20, #0x30]!                          
02d22c70: mov     x0, x20                                    
02d22c74: bl      #0x2b70d54                                 fn_2b70d54
02d22c78: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d22c7c: bl      #0x3769600                                 fn_3769600
02d22c80: ldr     x8, [x19, #0x20]                           
02d22c84: cbz     x8, #0x2d22d48                             
02d22c88: cbz     x0, #0x2d22d48                             
02d22c8c: ldr     w8, [x8, #0x4c]                            [626604c]=0 f=0,0
02d22c90: add     w9, w8, #1                                 
02d22c94: ldr     x8, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d22c98: str     w9, [x0, #0x3c]                            
02d22c9c: mov     x0, x8                                     
02d22ca0: bl      #0x3769600                                 fn_3769600
02d22ca4: mov     x20, x0                                    
02d22ca8: mov     x0, xzr                                    
02d22cac: bl      #0x5b432fc                                 UnityEngine.Time::get_time
02d22cb0: cbz     x20, #0x2d22d48                            
02d22cb4: ldr     x8, [x19, #0x20]                           
02d22cb8: str     s0, [x20, #0x38]                           ._commentHandler
02d22cbc: cbz     x8, #0x2d22d48                             
02d22cc0: ldr     x9, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d22cc4: ldr     w8, [x8, #0x4c]                            [626604c]=0 f=0,0
02d22cc8: mov     x3, xzr                                    
02d22ccc: ldr     x9, [x9, #0xb8]                            T:AdsManager/<>c__DisplayClass42_0
02d22cd0: add     w1, w8, #1                                 
02d22cd4: ldr     x0, [x9, #0x348]                           S:'MAX SDK Initialized'
02d22cd8: ldr     x2, [x9, #0x1e0]                           S:'_OnAdLoadedEvent'
02d22cdc: bl      #0x2c9c5c4                                 DevTrack::GameModeStart
02d22ce0: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d22ce4: bl      #0x3769600                                 fn_3769600
02d22ce8: cbz     x0, #0x2d22d48                             
02d22cec: ldr     x19, [x0, #0x30]                           S:'popup_rate_on_off'
02d22cf0: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d22cf4: bl      #0x3769600                                 fn_3769600
02d22cf8: cbz     x0, #0x2d22d48                             
02d22cfc: ldr     x8, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d22d00: ldr     w1, [x0, #0x3c]                            [626603c]=0 f=0,0
02d22d04: mov     x0, x19                                    
02d22d08: mov     x4, xzr                                    
02d22d0c: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02d22d10: ldr     x2, [x8, #0x218]                           MS:System.Collections.Generic.List`1::.ctor
02d22d14: ldr     w3, [x8, #0x270]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d22d18: bl      #0x2c9c714                                 DevTrack::GameModeStepEnter
02d22d1c: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d22d20: bl      #0x3769600                                 fn_3769600
02d22d24: cbz     x0, #0x2d22d48                             
02d22d28: ldr     x8, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d22d2c: ldp     x20, x19, [sp, #0x20]                      
02d22d30: ldp     x22, x21, [sp, #0x10]                      
02d22d34: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02d22d38: ldr     x1, [x8, #0x218]                           MS:System.Collections.Generic.List`1::.ctor
02d22d3c: str     x1, [x0, #0x40]!                           ._playButton
02d22d40: ldr     x30, [sp], #0x30                           
02d22d44: b       #0x2b70d54                                 
02d22d48: bl      #0x2b7105c                                 fn_2b7105c
## OnButtonBackClicked() -> void
---- Home.PopupPrepare::OnButtonBackClicked 0x2d22df0
02d22df0: str     x30, [sp, #-0x30]!                         
02d22df4: stp     x22, x21, [sp, #0x10]                      
02d22df8: stp     x20, x19, [sp, #0x20]                      
02d22dfc: adrp    x20, #0x6630000                            
02d22e00: mov     x19, x0                                    
02d22e04: ldrb    w8, [x20, #0x55]                           
02d22e08: tbnz    w8, #0, #0x2d22e44                         
02d22e0c: adrp    x0, #0x6264000                             
02d22e10: ldr     x0, [x0, #0xf90]                           T:System.Action
02d22e14: bl      #0x2b70db0                                 fn_2b70db0
02d22e18: adrp    x0, #0x6269000                             
02d22e1c: ldr     x0, [x0, #0xeb8]                           M:Home.PopupPrepare::<OnButtonBackClicked>b__19_0
02d22e20: bl      #0x2b70db0                                 fn_2b70db0
02d22e24: adrp    x0, #0x6265000                             
02d22e28: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02d22e2c: bl      #0x2b70db0                                 fn_2b70db0
02d22e30: adrp    x0, #0x6269000                             
02d22e34: ldr     x0, [x0, #0xec0]                           S:'prepare_back'
02d22e38: bl      #0x2b70db0                                 fn_2b70db0
02d22e3c: mov     w8, #1                                     
02d22e40: strb    w8, [x20, #0x55]                           
02d22e44: mov     x0, xzr                                    
02d22e48: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d22e4c: cbz     x0, #0x2d22f3c                             
02d22e50: movi    d1, #0000000000000000                      
02d22e54: movi    d2, #0000000000000000                      
02d22e58: mov     w1, #1                                     
02d22e5c: fmov    s0, #1.00000000                            
02d22e60: mov     w2, wzr                                    
02d22e64: mov     w3, wzr                                    
02d22e68: mov     x4, xzr                                    
02d22e6c: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d22e70: ldr     x8, [x19, #0x38]                           ._commentHandler
02d22e74: cbz     x8, #0x2d22f3c                             
02d22e78: strb    wzr, [x8, #0x20]                           
02d22e7c: mov     x0, x19                                    
02d22e80: ldr     x8, [x19]                                  
02d22e84: ldp     x9, x1, [x8, #0x198]                       
02d22e88: blr     x9                                         
02d22e8c: ldr     x0, [x19, #0xa0]                           ._missionBoard
02d22e90: cbz     x0, #0x2d22f3c                             
02d22e94: mov     x1, xzr                                    
02d22e98: bl      #0x5b368f0                                 UnityEngine.GameObject::get_transform
02d22e9c: mov     w1, wzr                                    
02d22ea0: mov     x2, xzr                                    
02d22ea4: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d22ea8: ldr     x0, [x19, #0xa0]                           ._missionBoard
02d22eac: cbz     x0, #0x2d22f3c                             
02d22eb0: adrp    x20, #0x6265000                            
02d22eb4: adrp    x21, #0x6264000                            
02d22eb8: adrp    x22, #0x6269000                            
02d22ebc: ldr     x20, [x20, #0x310]                         MS:WejoyService.Singleton`1::get_Instance
02d22ec0: ldr     x21, [x21, #0xf90]                         T:System.Action
02d22ec4: ldr     x22, [x22, #0xeb8]                         M:Home.PopupPrepare::<OnButtonBackClicked>b__19_0
02d22ec8: mov     x1, xzr                                    
02d22ecc: bl      #0x5b368f0                                 UnityEngine.GameObject::get_transform
02d22ed0: movi    d0, #0000000000000000                      
02d22ed4: movi    d1, #0000000000000000                      
02d22ed8: mov     x1, xzr                                    
02d22edc: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d22ee0: ldr     x0, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d22ee4: bl      #0x3be7218                                 fn_3be7218
02d22ee8: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d22eec: mov     x20, x0                                    
02d22ef0: mov     x0, x8                                     
02d22ef4: bl      #0x2b7104c                                 fn_2b7104c
02d22ef8: ldr     x2, [x22]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d22efc: mov     x1, x19                                    
02d22f00: mov     x3, xzr                                    
02d22f04: mov     x21, x0                                    
02d22f08: bl      #0x4d8ddbc                                 System.Action::.ctor
02d22f0c: cbz     x20, #0x2d22f3c                            
02d22f10: adrp    x8, #0x6269000                             
02d22f14: mov     x0, x20                                    
02d22f18: mov     x2, x21                                    
02d22f1c: ldr     x8, [x8, #0xec0]                           S:'prepare_back'
02d22f20: ldp     x20, x19, [sp, #0x20]                      
02d22f24: ldp     x22, x21, [sp, #0x10]                      
02d22f28: mov     w3, #1                                     
02d22f2c: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d22f30: mov     x4, xzr                                    
02d22f34: ldr     x30, [sp], #0x30                           
02d22f38: b       #0x2c89698                                 AdsManager::ShowInter
02d22f3c: bl      #0x2b7105c                                 fn_2b7105c
## StartButtonPlayClickEffect() -> void
---- Home.PopupPrepare::StartButtonPlayClickEffect 0x2d22d4c
02d22d4c: str     x30, [sp, #-0x20]!                         
02d22d50: stp     x20, x19, [sp, #0x10]                      
02d22d54: mov     x19, x0                                    
02d22d58: bl      #0x2d22f40                                 Home.PopupPrepare::StopButtonPlayAnim
02d22d5c: ldr     x0, [x19, #0x40]                           ._playButton
02d22d60: cbz     x0, #0x2d22dec                             
02d22d64: mov     x1, xzr                                    
02d22d68: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d22d6c: adrp    x20, #0x662f000                            
02d22d70: mov     x19, x0                                    
02d22d74: ldrb    w8, [x20, #0xa74]                          
02d22d78: cbnz    w8, #0x2d22d90                             
02d22d7c: adrp    x0, #0x6264000                             
02d22d80: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d22d84: bl      #0x2b70db0                                 fn_2b70db0
02d22d88: mov     w8, #1                                     
02d22d8c: strb    w8, [x20, #0xa74]                          
02d22d90: adrp    x8, #0x6264000                             
02d22d94: mov     w9, #0xcccd                                
02d22d98: mov     x0, x19                                    
02d22d9c: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02d22da0: movk    w9, #0x3dcc, lsl #16                       
02d22da4: fmov    s4, #1.00000000                            
02d22da8: dup     v0.2s, w9                                  
02d22dac: adrp    x9, #0x1084000                             
02d22db0: mov     w1, #0xa                                   
02d22db4: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d22db8: ldp     x20, x19, [sp, #0x10]                      
02d22dbc: mov     x2, xzr                                    
02d22dc0: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d22dc4: ldur    d1, [x8, #0xc]                             
02d22dc8: ldr     s2, [x8, #0x14]                            [6264014]=0 f=0,0
02d22dcc: adrp    x8, #0x1084000                             
02d22dd0: ldr     s3, [x8, #0xdd8]                           [1084dd8]=3f7333333e4ccccd f=0.2,0.95
02d22dd4: fmul    v0.2s, v1.2s, v0.2s                        
02d22dd8: ldr     s1, [x9, #0xeec]                           [1084eec]=457ff0003dcccccd f=0.1,4095
02d22ddc: fmul    s2, s2, s1                                 
02d22de0: mov     s1, v0.s[1]                                
02d22de4: ldr     x30, [sp], #0x20                           
02d22de8: b       #0x2d9982c                                 DG.Tweening.ShortcutExtensions::DOPunchScale
02d22dec: bl      #0x2b7105c                                 fn_2b7105c
## StartButtonPlayAnim() -> void
---- Home.PopupPrepare::StartButtonPlayAnim 0x2d22fd0
02d22fd0: str     x30, [sp, #-0x30]!                         
02d22fd4: stp     x22, x21, [sp, #0x10]                      
02d22fd8: stp     x20, x19, [sp, #0x20]                      
02d22fdc: adrp    x20, #0x6630000                            
02d22fe0: mov     x19, x0                                    
02d22fe4: ldrb    w8, [x20, #0x56]                           
02d22fe8: tbnz    w8, #0, #0x2d2300c                         
02d22fec: adrp    x0, #0x6266000                             
02d22ff0: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d22ff4: bl      #0x2b70db0                                 fn_2b70db0
02d22ff8: adrp    x0, #0x6268000                             
02d22ffc: ldr     x0, [x0, #0x10]                            MS:DG.Tweening.TweenSettingsExtensions::SetLoops
02d23000: bl      #0x2b70db0                                 fn_2b70db0
02d23004: mov     w8, #1                                     
02d23008: strb    w8, [x20, #0x56]                           
02d2300c: mov     x0, x19                                    
02d23010: bl      #0x2d22f40                                 Home.PopupPrepare::StopButtonPlayAnim
02d23014: ldr     x0, [x19, #0x40]                           ._playButton
02d23018: cbz     x0, #0x2d230cc                             
02d2301c: adrp    x21, #0x6266000                            
02d23020: adrp    x20, #0x6268000                            
02d23024: mov     x1, xzr                                    
02d23028: ldr     x21, [x21, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d2302c: ldr     x20, [x20, #0x10]                          MS:DG.Tweening.TweenSettingsExtensions::SetLoops
02d23030: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d23034: adrp    x22, #0x662f000                            
02d23038: mov     x19, x0                                    
02d2303c: ldrb    w8, [x22, #0xa74]                          
02d23040: cbnz    w8, #0x2d23058                             
02d23044: adrp    x0, #0x6264000                             
02d23048: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d2304c: bl      #0x2b70db0                                 fn_2b70db0
02d23050: mov     w8, #1                                     
02d23054: strb    w8, [x22, #0xa74]                          
02d23058: adrp    x8, #0x6264000                             
02d2305c: mov     w9, #0xcccd                                
02d23060: mov     x0, x19                                    
02d23064: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02d23068: movk    w9, #0x3f8c, lsl #16                       
02d2306c: mov     x1, xzr                                    
02d23070: dup     v0.2s, w9                                  
02d23074: adrp    x9, #0x1084000                             
02d23078: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d2307c: ldr     s2, [x9, #0xcfc]                           [1084cfc]=3e58658c3f8ccccd f=1.1,0.211325
02d23080: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d23084: ldur    d1, [x8, #0xc]                             
02d23088: fmul    v0.2s, v1.2s, v0.2s                        
02d2308c: ldr     s1, [x8, #0x14]                            [6264014]=0 f=0,0
02d23090: adrp    x8, #0x1084000                             
02d23094: ldr     s3, [x8, #0xda8]                           [1084da8]=da242603eb851ec f=0.36,1e-30
02d23098: fmul    s2, s1, s2                                 
02d2309c: mov     s1, v0.s[1]                                
02d230a0: bl      #0x2d98af8                                 DG.Tweening.ShortcutExtensions::DOScale
02d230a4: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d230a8: mov     w1, #4                                     
02d230ac: bl      #0x336fa0c                                 fn_336fa0c
02d230b0: ldr     x3, [x20]                                  S:'{0}/2'
02d230b4: ldp     x20, x19, [sp, #0x20]                      
02d230b8: ldp     x22, x21, [sp, #0x10]                      
02d230bc: mov     w1, #-1                                    
02d230c0: mov     w2, #1                                     
02d230c4: ldr     x30, [sp], #0x30                           
02d230c8: b       #0x336fe74                                 
02d230cc: bl      #0x2b7105c                                 fn_2b7105c
## OnDestroy() -> void
---- Home.PopupPrepare::OnDestroy 0x2d230d0
02d230d0: stp     x30, x19, [sp, #-0x10]!                    
02d230d4: mov     x19, x0                                    
02d230d8: ldr     x0, [x0, #0x98]                            ._livestreamPanel
02d230dc: cbz     x0, #0x2d23124                             
02d230e0: mov     x1, xzr                                    
02d230e4: bl      #0x2d11cdc                                 Livestream.LivestreamPanel::OnHide
02d230e8: ldr     x0, [x19, #0x40]                           ._playButton
02d230ec: cbz     x0, #0x2d23124                             
02d230f0: mov     x1, xzr                                    
02d230f4: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d230f8: mov     w1, wzr                                    
02d230fc: mov     x2, xzr                                    
02d23100: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d23104: ldr     x1, [x19, #0xa8]                           ._coroutineSpawnComment
02d23108: cbz     x1, #0x2d2311c                             
02d2310c: mov     x0, x19                                    
02d23110: mov     x2, xzr                                    
02d23114: ldp     x30, x19, [sp], #0x10                      
02d23118: b       #0x5b38c4c                                 UnityEngine.MonoBehaviour::StopCoroutine
02d2311c: ldp     x30, x19, [sp], #0x10                      
02d23120: ret                                                
02d23124: bl      #0x2b7105c                                 fn_2b7105c
## StopButtonPlayAnim() -> void
---- Home.PopupPrepare::StopButtonPlayAnim 0x2d22f40
02d22f40: str     x30, [sp, #-0x20]!                         
02d22f44: stp     x20, x19, [sp, #0x10]                      
02d22f48: mov     x19, x0                                    
02d22f4c: ldr     x0, [x0, #0x40]                            ._playButton
02d22f50: cbz     x0, #0x2d22fcc                             
02d22f54: mov     x1, xzr                                    
02d22f58: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d22f5c: mov     w1, wzr                                    
02d22f60: mov     x2, xzr                                    
02d22f64: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d22f68: ldr     x0, [x19, #0x40]                           ._playButton
02d22f6c: cbz     x0, #0x2d22fcc                             
02d22f70: mov     x1, xzr                                    
02d22f74: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d22f78: adrp    x20, #0x662f000                            
02d22f7c: mov     x19, x0                                    
02d22f80: ldrb    w8, [x20, #0xa74]                          
02d22f84: cbnz    w8, #0x2d22f9c                             
02d22f88: adrp    x0, #0x6264000                             
02d22f8c: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d22f90: bl      #0x2b70db0                                 fn_2b70db0
02d22f94: mov     w8, #1                                     
02d22f98: strb    w8, [x20, #0xa74]                          
02d22f9c: cbz     x19, #0x2d22fcc                            
02d22fa0: adrp    x8, #0x6264000                             
02d22fa4: mov     x0, x19                                    
02d22fa8: mov     x1, xzr                                    
02d22fac: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02d22fb0: ldp     x20, x19, [sp, #0x10]                      
02d22fb4: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d22fb8: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d22fbc: ldp     s0, s1, [x8, #0xc]                         
02d22fc0: ldr     s2, [x8, #0x14]                            [6264014]=0 f=0,0
02d22fc4: ldr     x30, [sp], #0x20                           
02d22fc8: b       #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d22fcc: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Home.PopupPrepare::.ctor 0x2d23128
02d23128: mov     x1, xzr                                    
02d2312c: b       #0x2cddba8                                 PopupBase::.ctor
## <OnShow>b__17_0() -> void
---- Home.PopupPrepare::<OnShow>b__17_0 0x2d23130
02d23130: stp     x30, x19, [sp, #-0x10]!                    
02d23134: mov     x19, x0                                    
02d23138: ldr     x0, [x0, #0x40]                            ._playButton
02d2313c: cbz     x0, #0x2d23178                             
02d23140: mov     w1, #1                                     
02d23144: mov     x2, xzr                                    
02d23148: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d2314c: ldr     x0, [x19, #0x40]                           ._playButton
02d23150: cbz     x0, #0x2d23178                             
02d23154: mov     x1, xzr                                    
02d23158: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d2315c: cbz     x0, #0x2d23178                             
02d23160: mov     w1, #1                                     
02d23164: mov     x2, xzr                                    
02d23168: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d2316c: mov     x0, x19                                    
02d23170: ldp     x30, x19, [sp], #0x10                      
02d23174: b       #0x2d22fd0                                 Home.PopupPrepare::StartButtonPlayAnim
02d23178: bl      #0x2b7105c                                 fn_2b7105c
## <>n__0() -> void
---- Home.PopupPrepare::<>n__0 0x2d2317c
02d2317c: mov     x1, xzr                                    
02d23180: b       #0x2cdd6b8                                 UIBase::OnShow
## <OnButtonBackClicked>b__19_0() -> void
---- Home.PopupPrepare::<OnButtonBackClicked>b__19_0 0x2d23184
02d23184: str     x30, [sp, #-0x20]!                         
02d23188: stp     x20, x19, [sp, #0x10]                      
02d2318c: adrp    x20, #0x6630000                            
02d23190: mov     x19, x0                                    
02d23194: ldrb    w8, [x20, #0x57]                           
02d23198: tbnz    w8, #0, #0x2d231b0                         
02d2319c: adrp    x0, #0x6268000                             
02d231a0: ldr     x0, [x0, #0x108]                           MS:UIManager::ShowScreen
02d231a4: bl      #0x2b70db0                                 fn_2b70db0
02d231a8: mov     w8, #1                                     
02d231ac: strb    w8, [x20, #0x57]                           
02d231b0: ldr     x0, [x19, #0x30]                           
02d231b4: cbz     x0, #0x2d231dc                             
02d231b8: adrp    x8, #0x6268000                             
02d231bc: ldr     x8, [x8, #0x108]                           MS:UIManager::ShowScreen
02d231c0: ldr     x1, [x8]                                   S:'{0}/2'
02d231c4: bl      #0x33fc0e8                                 fn_33fc0e8
02d231c8: cbz     x0, #0x2d231dc                             
02d231cc: ldp     x20, x19, [sp, #0x10]                      
02d231d0: mov     x1, xzr                                    
02d231d4: ldr     x30, [sp], #0x20                           
02d231d8: b       #0x2cb2bd0                                 ScreenHome::MoveMoneyLeft
02d231dc: bl      #0x2b7105c                                 fn_2b7105c
