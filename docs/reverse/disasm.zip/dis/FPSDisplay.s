#### CLASS FPSDisplay parent= UnityEngine.MonoBehaviour
#   field deltaTime                      float                                              off=0x20 attr=1 
## Update() -> void
---- FPSDisplay::Update 0x2cee9e8
02cee9e8: str     d8, [sp, #-0x20]!                          
02cee9ec: stp     x30, x19, [sp, #0x10]                      
02cee9f0: mov     x19, x0                                    
02cee9f4: ldr     s8, [x0, #0x20]                            .deltaTime
02cee9f8: mov     x0, xzr                                    
02cee9fc: bl      #0x5b433a4                                 UnityEngine.Time::get_deltaTime
02ceea00: ldr     s1, [x19, #0x20]                           .deltaTime
02ceea04: adrp    x8, #0x1084000                             
02ceea08: fsub    s0, s0, s1                                 
02ceea0c: ldr     s1, [x8, #0xeec]                           [1084eec]=457ff0003dcccccd f=0.1,4095
02ceea10: fmul    s0, s0, s1                                 
02ceea14: fadd    s0, s8, s0                                 
02ceea18: str     s0, [x19, #0x20]                           .deltaTime
02ceea1c: ldp     x30, x19, [sp, #0x10]                      
02ceea20: ldr     d8, [sp], #0x20                            
02ceea24: ret                                                
## OnGUI() -> void
---- FPSDisplay::OnGUI 0x2ceea28
02ceea28: str     d8, [sp, #-0x50]!                          
02ceea2c: stp     x30, x25, [sp, #0x10]                      
02ceea30: stp     x24, x23, [sp, #0x20]                      
02ceea34: stp     x22, x21, [sp, #0x30]                      
02ceea38: stp     x20, x19, [sp, #0x40]                      
02ceea3c: adrp    x19, #0x662f000                            
02ceea40: adrp    x20, #0x6267000                            
02ceea44: mov     x21, x0                                    
02ceea48: ldrb    w8, [x19, #0xe44]                          
02ceea4c: ldr     x20, [x20, #0x2b8]                         T:UnityEngine.GUIStyle
02ceea50: tbnz    w8, #0, #0x2ceea80                         
02ceea54: adrp    x0, #0x6267000                             
02ceea58: ldr     x0, [x0, #0x2b8]                           T:UnityEngine.GUIStyle
02ceea5c: bl      #0x2b70db0                                 fn_2b70db0
02ceea60: adrp    x0, #0x6267000                             
02ceea64: ldr     x0, [x0, #0x2c0]                           T:UnityEngine.GUI
02ceea68: bl      #0x2b70db0                                 fn_2b70db0
02ceea6c: adrp    x0, #0x6268000                             
02ceea70: ldr     x0, [x0, #0x518]                           S:'{0:0.0} ms ({1:0.} fps)'
02ceea74: bl      #0x2b70db0                                 fn_2b70db0
02ceea78: mov     w8, #1                                     
02ceea7c: strb    w8, [x19, #0xe44]                          
02ceea80: mov     x0, xzr                                    
02ceea84: bl      #0x5afb6fc                                 UnityEngine.Screen::get_width
02ceea88: mov     w19, w0                                    
02ceea8c: mov     x0, xzr                                    
02ceea90: bl      #0x5afb724                                 UnityEngine.Screen::get_height
02ceea94: ldr     x8, [x20]                                  S:'didu'
02ceea98: mov     w22, w0                                    
02ceea9c: mov     x0, x8                                     
02ceeaa0: bl      #0x2b7104c                                 fn_2b7104c
02ceeaa4: mov     x1, xzr                                    
02ceeaa8: mov     x20, x0                                    
02ceeaac: bl      #0x5b97bc0                                 UnityEngine.GUIStyle::.ctor
02ceeab0: cbz     x20, #0x2ceebe8                            
02ceeab4: mov     x0, x20                                    
02ceeab8: mov     w1, wzr                                    
02ceeabc: mov     x2, xzr                                    
02ceeac0: lsl     w22, w22, #1                               
02ceeac4: bl      #0x5b9a5a8                                 UnityEngine.GUIStyle::set_alignment
02ceeac8: mov     w8, #0x851f                                
02ceeacc: mov     x0, x20                                    
02ceead0: mov     x2, xzr                                    
02ceead4: movk    w8, #0x51eb, lsl #16                       
02ceead8: smull   x8, w22, w8                                
02ceeadc: lsr     x9, x8, #0x3f                              
02ceeae0: asr     x8, x8, #0x24                              
02ceeae4: add     w1, w8, w9                                 
02ceeae8: bl      #0x5b9ad5c                                 UnityEngine.GUIStyle::set_fontSize
02ceeaec: mov     x0, x20                                    
02ceeaf0: mov     x1, xzr                                    
02ceeaf4: bl      #0x5b99850                                 UnityEngine.GUIStyle::get_normal
02ceeaf8: cbz     x0, #0x2ceebe8                             
02ceeafc: movi    d2, #0000000000000000                      
02ceeb00: fmov    s0, #1.00000000                            
02ceeb04: adrp    x23, #0x6268000                            
02ceeb08: fmov    s1, #1.00000000                            
02ceeb0c: fmov    s3, #1.00000000                            
02ceeb10: adrp    x24, #0x6267000                            
02ceeb14: ldr     x23, [x23, #0x518]                         S:'{0:0.0} ms ({1:0.} fps)'
02ceeb18: ldr     x24, [x24, #0x2c0]                         T:UnityEngine.GUI
02ceeb1c: mov     x1, xzr                                    
02ceeb20: fmov    s8, #1.00000000                            
02ceeb24: bl      #0x5b998a0                                 UnityEngine.GUIStyleState::set_textColor
02ceeb28: mov     w8, #0x447a0000                            
02ceeb2c: ldr     s0, [x21, #0x20]                           .deltaTime
02ceeb30: adrp    x25, #0x6263000                            
02ceeb34: fmov    s1, w8                                     
02ceeb38: ldr     x25, [x25, #0x970]                         &6645c70(=0)
02ceeb3c: add     x1, sp, #0xc                               
02ceeb40: fdiv    s8, s8, s0                                 
02ceeb44: ldr     x0, [x25, #0x78]                           &2c498b4(=d65f03c0d503245f)
02ceeb48: fmul    s0, s0, s1                                 
02ceeb4c: str     s0, [sp, #0xc]                             
02ceeb50: bl      #0x2b70f38                                 fn_2b70f38
02ceeb54: mov     x21, x0                                    
02ceeb58: ldr     x0, [x25, #0x78]                           &2c498b4(=d65f03c0d503245f)
02ceeb5c: add     x1, sp, #8                                 
02ceeb60: str     s8, [sp, #8]                               
02ceeb64: bl      #0x2b70f38                                 fn_2b70f38
02ceeb68: ldr     x8, [x23]                                  S:'{0}/2'
02ceeb6c: mov     x2, x0                                     
02ceeb70: mov     x1, x21                                    
02ceeb74: mov     x3, xzr                                    
02ceeb78: mov     x0, x8                                     
02ceeb7c: bl      #0x4ca7720                                 System.String::Format
02ceeb80: ldr     x8, [x24]                                  S:'didu'
02ceeb84: mov     x21, x0                                    
02ceeb88: ldr     w9, [x8, #0xe4]                            
02ceeb8c: cbnz    w9, #0x2ceeb98                             
02ceeb90: mov     x0, x8                                     
02ceeb94: bl      #0x2b70f30                                 fn_2b70f30
02ceeb98: mov     w8, #0x851f                                
02ceeb9c: scvtf   s2, w19                                    
02ceeba0: movi    d0, #0000000000000000                      
02ceeba4: movk    w8, #0x51eb, lsl #16                       
02ceeba8: movi    d1, #0000000000000000                      
02ceebac: mov     x0, x21                                    
02ceebb0: smull   x8, w22, w8                                
02ceebb4: mov     x1, x20                                    
02ceebb8: mov     x2, xzr                                    
02ceebbc: lsr     x9, x8, #0x3f                              
02ceebc0: asr     x8, x8, #0x25                              
02ceebc4: add     w8, w8, w9                                 
02ceebc8: scvtf   s3, w8                                     
02ceebcc: bl      #0x5b8ce7c                                 UnityEngine.GUI::Label
02ceebd0: ldp     x20, x19, [sp, #0x40]                      
02ceebd4: ldp     x22, x21, [sp, #0x30]                      
02ceebd8: ldp     x24, x23, [sp, #0x20]                      
02ceebdc: ldp     x30, x25, [sp, #0x10]                      
02ceebe0: ldr     d8, [sp], #0x50                            
02ceebe4: ret                                                
02ceebe8: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- FPSDisplay::.ctor 0x2ceebec
02ceebec: mov     x1, xzr                                    
02ceebf0: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
