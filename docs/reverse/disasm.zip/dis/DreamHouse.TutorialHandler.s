#### CLASS DreamHouse.TutorialHandler parent= MonoSingleton`1<DreamHouse.TutorialHandler>
#   field _handTutorials                 System.Collections.Generic.List`1<UnityEngine.GameObject> off=0x20 attr=1 SerializeField
#   field _dataDreamHouse                DreamHouse.DataDreamHouse                          off=0x28 attr=1 
## Initiate() -> void
---- DreamHouse.TutorialHandler::Initiate 0x2d19610
02d19610: str     x30, [sp, #-0x30]!                         
02d19614: stp     x22, x21, [sp, #0x10]                      
02d19618: stp     x20, x19, [sp, #0x20]                      
02d1961c: adrp    x21, #0x662f000                            
02d19620: adrp    x22, #0x6269000                            
02d19624: adrp    x20, #0x6266000                            
02d19628: ldrb    w8, [x21, #0xff7]                          
02d1962c: ldr     x22, [x22, #0xaa0]                         MS:MonoSingleton`1::Initiate
02d19630: ldr     x20, [x20, #0x658]                         MS:MonoSingleton`1::get_Instance
02d19634: mov     x19, x0                                    
02d19638: tbnz    w8, #0, #0x2d19668                         
02d1963c: adrp    x0, #0x6269000                             
02d19640: ldr     x0, [x0, #0x9e8]                           MS:DataManager::GetData
02d19644: bl      #0x2b70db0                                 fn_2b70db0
02d19648: adrp    x0, #0x6269000                             
02d1964c: ldr     x0, [x0, #0xaa0]                           MS:MonoSingleton`1::Initiate
02d19650: bl      #0x2b70db0                                 fn_2b70db0
02d19654: adrp    x0, #0x6266000                             
02d19658: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d1965c: bl      #0x2b70db0                                 fn_2b70db0
02d19660: mov     w8, #1                                     
02d19664: strb    w8, [x21, #0xff7]                          
02d19668: ldr     x1, [x22]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1966c: mov     x0, x19                                    
02d19670: bl      #0x3769de4                                 fn_3769de4
02d19674: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d19678: bl      #0x3769600                                 fn_3769600
02d1967c: cbz     x0, #0x2d196ac                             
02d19680: adrp    x8, #0x6269000                             
02d19684: ldr     x8, [x8, #0x9e8]                           MS:DataManager::GetData
02d19688: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d1968c: bl      #0x3168dd0                                 fn_3168dd0
02d19690: str     x0, [x19, #0x28]!                          ._dataDreamHouse
02d19694: mov     x1, x0                                     
02d19698: mov     x0, x19                                    
02d1969c: ldp     x20, x19, [sp, #0x20]                      
02d196a0: ldp     x22, x21, [sp, #0x10]                      
02d196a4: ldr     x30, [sp], #0x30                           
02d196a8: b       #0x2b70d54                                 
02d196ac: bl      #0x2b7105c                                 fn_2b7105c
## OnEnable() -> void
---- DreamHouse.TutorialHandler::OnEnable 0x2d196b0
02d196b0: str     x30, [sp, #-0x30]!                         
02d196b4: stp     x22, x21, [sp, #0x10]                      
02d196b8: stp     x20, x19, [sp, #0x20]                      
02d196bc: adrp    x21, #0x662f000                            
02d196c0: adrp    x22, #0x6265000                            
02d196c4: adrp    x20, #0x6269000                            
02d196c8: ldrb    w8, [x21, #0xff8]                          
02d196cc: ldr     x22, [x22, #0x3f0]                         T:UnityEngine.Events.UnityAction
02d196d0: ldr     x20, [x20, #0xaa8]                         M:DreamHouse.TutorialHandler::OnRoomInitialized
02d196d4: mov     x19, x0                                    
02d196d8: tbnz    w8, #0, #0x2d196fc                         
02d196dc: adrp    x0, #0x6269000                             
02d196e0: ldr     x0, [x0, #0xaa8]                           M:DreamHouse.TutorialHandler::OnRoomInitialized
02d196e4: bl      #0x2b70db0                                 fn_2b70db0
02d196e8: adrp    x0, #0x6265000                             
02d196ec: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d196f0: bl      #0x2b70db0                                 fn_2b70db0
02d196f4: mov     w8, #1                                     
02d196f8: strb    w8, [x21, #0xff8]                          
02d196fc: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d19700: bl      #0x2b7104c                                 fn_2b7104c
02d19704: ldr     x2, [x20]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d19708: mov     x1, x19                                    
02d1970c: mov     x3, xzr                                    
02d19710: mov     x20, x0                                    
02d19714: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d19718: mov     x0, x20                                    
02d1971c: ldp     x20, x19, [sp, #0x20]                      
02d19720: ldp     x22, x21, [sp, #0x10]                      
02d19724: mov     x1, xzr                                    
02d19728: ldr     x30, [sp], #0x30                           
02d1972c: b       #0x2d186f4                                 DreamHouse.RoomController::add_OnInitialized
## OnDisable() -> void
---- DreamHouse.TutorialHandler::OnDisable 0x2d19730
02d19730: str     x30, [sp, #-0x30]!                         
02d19734: stp     x22, x21, [sp, #0x10]                      
02d19738: stp     x20, x19, [sp, #0x20]                      
02d1973c: adrp    x21, #0x662f000                            
02d19740: adrp    x22, #0x6265000                            
02d19744: adrp    x20, #0x6269000                            
02d19748: ldrb    w8, [x21, #0xff9]                          
02d1974c: ldr     x22, [x22, #0x3f0]                         T:UnityEngine.Events.UnityAction
02d19750: ldr     x20, [x20, #0xaa8]                         M:DreamHouse.TutorialHandler::OnRoomInitialized
02d19754: mov     x19, x0                                    
02d19758: tbnz    w8, #0, #0x2d1977c                         
02d1975c: adrp    x0, #0x6269000                             
02d19760: ldr     x0, [x0, #0xaa8]                           M:DreamHouse.TutorialHandler::OnRoomInitialized
02d19764: bl      #0x2b70db0                                 fn_2b70db0
02d19768: adrp    x0, #0x6265000                             
02d1976c: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d19770: bl      #0x2b70db0                                 fn_2b70db0
02d19774: mov     w8, #1                                     
02d19778: strb    w8, [x21, #0xff9]                          
02d1977c: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d19780: bl      #0x2b7104c                                 fn_2b7104c
02d19784: ldr     x2, [x20]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d19788: mov     x1, x19                                    
02d1978c: mov     x3, xzr                                    
02d19790: mov     x20, x0                                    
02d19794: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d19798: mov     x0, x20                                    
02d1979c: ldp     x20, x19, [sp, #0x20]                      
02d197a0: ldp     x22, x21, [sp, #0x10]                      
02d197a4: mov     x1, xzr                                    
02d197a8: ldr     x30, [sp], #0x30                           
02d197ac: b       #0x2d187ac                                 DreamHouse.RoomController::remove_OnInitialized
## OnRoomInitialized() -> void
---- DreamHouse.TutorialHandler::OnRoomInitialized 0x2d197b0
02d197b0: stp     x30, x19, [sp, #-0x10]!                    
02d197b4: mov     x19, x0                                    
02d197b8: ldr     x0, [x0, #0x28]                            ._dataDreamHouse
02d197bc: cbz     x0, #0x2d19810                             
02d197c0: mov     x1, xzr                                    
02d197c4: bl      #0x2d173cc                                 DreamHouse.DataDreamHouse::IsDoneTutorial
02d197c8: tbnz    w0, #0, #0x2d197f4                         
02d197cc: ldr     x0, [x19, #0x28]                           ._dataDreamHouse
02d197d0: cbz     x0, #0x2d19810                             
02d197d4: mov     x1, xzr                                    
02d197d8: bl      #0x2d166b8                                 DreamHouse.DataDreamHouse::IsFirstTime
02d197dc: tbz     w0, #0, #0x2d197f4                         
02d197e0: ldr     x0, [x19, #0x28]                           ._dataDreamHouse
02d197e4: cbz     x0, #0x2d19810                             
02d197e8: mov     x1, xzr                                    
02d197ec: bl      #0x2d1733c                                 DreamHouse.DataDreamHouse::GetCurrentRoomStep
02d197f0: cbz     w0, #0x2d197fc                             
02d197f4: ldp     x30, x19, [sp], #0x10                      
02d197f8: ret                                                
02d197fc: mov     x0, x19                                    
02d19800: mov     w1, wzr                                    
02d19804: mov     w2, #1                                     
02d19808: ldp     x30, x19, [sp], #0x10                      
02d1980c: b       #0x2d19814                                 DreamHouse.TutorialHandler::SetActiveHandTutorial
02d19810: bl      #0x2b7105c                                 fn_2b7105c
## SetActiveHandTutorial(int tutorialIndex, bool isActive) -> void
---- DreamHouse.TutorialHandler::SetActiveHandTutorial 0x2d19814
02d19814: str     x30, [sp, #-0x30]!                         
02d19818: stp     x22, x21, [sp, #0x10]                      
02d1981c: stp     x20, x19, [sp, #0x20]                      
02d19820: adrp    x22, #0x662f000                            
02d19824: mov     w19, w2                                    
02d19828: mov     w20, w1                                    
02d1982c: ldrb    w8, [x22, #0xffa]                          
02d19830: mov     x21, x0                                    
02d19834: str     w1, [sp, #0xc]                             
02d19838: tbnz    w8, #0, #0x2d19874                         
02d1983c: adrp    x0, #0x6263000                             
02d19840: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02d19844: bl      #0x2b70db0                                 fn_2b70db0
02d19848: adrp    x0, #0x6266000                             
02d1984c: ldr     x0, [x0, #0x900]                           MS:System.Collections.Generic.List`1::get_Count
02d19850: bl      #0x2b70db0                                 fn_2b70db0
02d19854: adrp    x0, #0x6266000                             
02d19858: ldr     x0, [x0, #0x908]                           MS:System.Collections.Generic.List`1::get_Item
02d1985c: bl      #0x2b70db0                                 fn_2b70db0
02d19860: adrp    x0, #0x6269000                             
02d19864: ldr     x0, [x0, #0xab0]                           S:'Invalid tutorial index: '
02d19868: bl      #0x2b70db0                                 fn_2b70db0
02d1986c: mov     w8, #1                                     
02d19870: strb    w8, [x22, #0xffa]                          
02d19874: ldr     x0, [x21, #0x28]                           ._dataDreamHouse
02d19878: cbz     x0, #0x2d19964                             
02d1987c: mov     x1, xzr                                    
02d19880: bl      #0x2d173cc                                 DreamHouse.DataDreamHouse::IsDoneTutorial
02d19884: tbnz    w0, #0, #0x2d19954                         
02d19888: tbnz    w20, #0x1f, #0x2d19900                     
02d1988c: ldr     x0, [x21, #0x20]                           ._handTutorials
02d19890: cbz     x0, #0x2d19964                             
02d19894: ldr     w8, [x0, #0x18]                            M:Trading.TradingSession::<ValidateTrade>b__57_0
02d19898: cmp     w8, w20                                    
02d1989c: b.le    #0x2d19900                                 
02d198a0: adrp    x22, #0x6266000                            
02d198a4: mov     w1, w20                                    
02d198a8: ldr     x22, [x22, #0x908]                         MS:System.Collections.Generic.List`1::get_Item
02d198ac: ldr     x2, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d198b0: bl      #0x35a8f3c                                 fn_35a8f3c
02d198b4: cbz     x0, #0x2d19964                             
02d198b8: mov     x1, xzr                                    
02d198bc: bl      #0x5b36bfc                                 UnityEngine.GameObject::get_activeSelf
02d198c0: and     w8, w19, #1                                
02d198c4: and     w9, w0, #1                                 
02d198c8: cmp     w9, w8                                     
02d198cc: b.eq    #0x2d19954                                 
02d198d0: ldr     x0, [x21, #0x20]                           ._handTutorials
02d198d4: cbz     x0, #0x2d19964                             
02d198d8: ldr     x2, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d198dc: mov     w1, w20                                    
02d198e0: bl      #0x35a8f3c                                 fn_35a8f3c
02d198e4: cbz     x0, #0x2d19964                             
02d198e8: and     w1, w19, #1                                
02d198ec: ldp     x20, x19, [sp, #0x20]                      
02d198f0: ldp     x22, x21, [sp, #0x10]                      
02d198f4: mov     x2, xzr                                    
02d198f8: ldr     x30, [sp], #0x30                           
02d198fc: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d19900: add     x0, sp, #0xc                               
02d19904: mov     x1, xzr                                    
02d19908: bl      #0x4e0ea3c                                 System.Int32::ToString
02d1990c: adrp    x8, #0x6269000                             
02d19910: mov     x1, x0                                     
02d19914: mov     x2, xzr                                    
02d19918: ldr     x8, [x8, #0xab0]                           S:'Invalid tutorial index: '
02d1991c: ldr     x8, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d19920: mov     x0, x8                                     
02d19924: bl      #0x4c9c514                                 System.String::Concat
02d19928: adrp    x8, #0x6263000                             
02d1992c: mov     x19, x0                                    
02d19930: ldr     x8, [x8, #0x928]                           T:UnityEngine.Debug
02d19934: ldr     x8, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02d19938: ldr     w9, [x8, #0xe4]                            [62630e4]=0 f=0,0
02d1993c: cbnz    w9, #0x2d19948                             
02d19940: mov     x0, x8                                     
02d19944: bl      #0x2b70f30                                 fn_2b70f30
02d19948: mov     x0, x19                                    
02d1994c: mov     x1, xzr                                    
02d19950: bl      #0x5af2840                                 UnityEngine.Debug::LogError
02d19954: ldp     x20, x19, [sp, #0x20]                      
02d19958: ldp     x22, x21, [sp, #0x10]                      
02d1995c: ldr     x30, [sp], #0x30                           
02d19960: ret                                                
02d19964: bl      #0x2b7105c                                 fn_2b7105c
## DoneTutorial() -> void
---- DreamHouse.TutorialHandler::DoneTutorial 0x2d19968
02d19968: ldr     x0, [x0, #0x28]                            ._dataDreamHouse
02d1996c: cbz     x0, #0x2d1997c                             
02d19970: mov     w1, #1                                     
02d19974: mov     x2, xzr                                    
02d19978: b       #0x2d17394                                 DreamHouse.DataDreamHouse::SetDoneTutorial
02d1997c: str     x30, [sp, #-0x10]!                         
02d19980: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- DreamHouse.TutorialHandler::.ctor 0x2d19984
02d19984: stp     x30, x21, [sp, #-0x20]!                    
02d19988: stp     x20, x19, [sp, #0x10]                      
02d1998c: adrp    x20, #0x662f000                            
02d19990: adrp    x21, #0x6269000                            
02d19994: mov     x19, x0                                    
02d19998: ldrb    w8, [x20, #0xffb]                          
02d1999c: ldr     x21, [x21, #0xab8]                         MS:MonoSingleton`1::.ctor
02d199a0: tbnz    w8, #0, #0x2d199b8                         
02d199a4: adrp    x0, #0x6269000                             
02d199a8: ldr     x0, [x0, #0xab8]                           MS:MonoSingleton`1::.ctor
02d199ac: bl      #0x2b70db0                                 fn_2b70db0
02d199b0: mov     w8, #1                                     
02d199b4: strb    w8, [x20, #0xffb]                          
02d199b8: mov     x0, x19                                    
02d199bc: ldp     x20, x19, [sp, #0x10]                      
02d199c0: ldr     x1, [x21]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d199c4: ldp     x30, x21, [sp], #0x20                      
02d199c8: b       #0x3769e18                                 
