#### CLASS KeyHolder parent= UnityEngine.MonoBehaviour
#   field keysData                       KeysData                                           off=0x20 attr=1 SerializeField
## Awake() -> void
---- KeyHolder::Awake 0x2c9bd9c
02c9bd9c: str     x30, [sp, #-0x20]!                         
02c9bda0: stp     x20, x19, [sp, #0x10]                      
02c9bda4: adrp    x20, #0x662f000                            
02c9bda8: ldr     x19, [x0, #0x20]                           .keysData
02c9bdac: ldrb    w8, [x20, #0xa89]                          
02c9bdb0: cbnz    w8, #0x2c9bdc8                             
02c9bdb4: adrp    x0, #0x6265000                             
02c9bdb8: ldr     x0, [x0, #0x3b8]                           T:KeyAds
02c9bdbc: bl      #0x2b70db0                                 fn_2b70db0
02c9bdc0: mov     w8, #1                                     
02c9bdc4: strb    w8, [x20, #0xa89]                          
02c9bdc8: adrp    x8, #0x6265000                             
02c9bdcc: mov     x1, x19                                    
02c9bdd0: ldr     x8, [x8, #0x3b8]                           T:KeyAds
02c9bdd4: ldr     x9, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9bdd8: ldr     x9, [x9, #0xb8]                            
02c9bddc: str     x19, [x9]                                  
02c9bde0: ldp     x20, x19, [sp, #0x10]                      
02c9bde4: ldr     x8, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9bde8: ldr     x0, [x8, #0xb8]                            T:AdsManager/<>c__DisplayClass42_0
02c9bdec: ldr     x30, [sp], #0x20                           
02c9bdf0: b       #0x2b70d54                                 
## .ctor() -> void
---- KeyHolder::.ctor 0x2c9bdf4
02c9bdf4: mov     x1, xzr                                    
02c9bdf8: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
