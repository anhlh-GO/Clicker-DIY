#### CLASS Games.RandomAnimationConfig parent= object
#   field ID                             int                                                off=0x10 attr=6 
#   field RandomAnimation                Games.RandomAnimation                              off=0x18 attr=6 
## .ctor() -> void
---- Games.RandomAnimationConfig::.ctor 0x2d2fdec
02d2fdec: mov     x1, xzr                                    
02d2fdf0: b       #0x4e53e9c                                 System.Object::.ctor
