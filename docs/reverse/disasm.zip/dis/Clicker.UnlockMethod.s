#### CLASS Clicker.UnlockMethod parent= object
#   field Type                           Clicker.UnlockMethodType                           off=0x10 attr=6 
#   field Value                          int                                                off=0x14 attr=6 
## .ctor() -> void
---- Clicker.UnlockMethod::.ctor 0x2d5bf58
02d5bf58: mov     x1, xzr                                    
02d5bf5c: b       #0x4e53e9c                                 System.Object::.ctor
