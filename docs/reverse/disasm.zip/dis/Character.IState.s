#### CLASS Character.IState parent= None
##  GetAnimationSpineType (no body)
##  Update (no body)
##  Exit (no body)
##  Enter (no body)
