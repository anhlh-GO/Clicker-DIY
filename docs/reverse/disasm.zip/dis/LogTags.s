#### CLASS LogTags parent= object
#   field IAP                            string                                             off=0x0 attr=16 
## .cctor() -> void
---- LogTags::.cctor 0x2ca4644
02ca4644: stp     x30, x21, [sp, #-0x20]!                    
02ca4648: stp     x20, x19, [sp, #0x10]                      
02ca464c: adrp    x21, #0x662f000                            
02ca4650: adrp    x20, #0x6266000                            
02ca4654: adrp    x19, #0x6266000                            
02ca4658: ldrb    w8, [x21, #0xac9]                          
02ca465c: ldr     x20, [x20, #0x190]                         S:'IAP'
02ca4660: ldr     x19, [x19, #0x198]                         T:LogTags
02ca4664: tbnz    w8, #0, #0x2ca4688                         
02ca4668: adrp    x0, #0x6266000                             
02ca466c: ldr     x0, [x0, #0x198]                           T:LogTags
02ca4670: bl      #0x2b70db0                                 fn_2b70db0
02ca4674: adrp    x0, #0x6266000                             
02ca4678: ldr     x0, [x0, #0x190]                           S:'IAP'
02ca467c: bl      #0x2b70db0                                 fn_2b70db0
02ca4680: mov     w8, #1                                     
02ca4684: strb    w8, [x21, #0xac9]                          
02ca4688: ldr     x8, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca468c: ldr     x1, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca4690: ldr     x8, [x8, #0xb8]                            
02ca4694: str     x1, [x8]                                   
02ca4698: ldr     x8, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca469c: ldp     x20, x19, [sp, #0x10]                      
02ca46a0: ldr     x0, [x8, #0xb8]                            
02ca46a4: ldp     x30, x21, [sp], #0x20                      
02ca46a8: b       #0x2b70d54                                 
