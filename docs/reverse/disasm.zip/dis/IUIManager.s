#### CLASS IUIManager parent= None
##  OnInit (no body)
##  OnRelease (no body)
##  ShowScreen (no body)
##  GetScreen (no body)
##  GetPopup (no body)
##  ShowPopup (no body)
##  HideScreen (no body)
##  HidePopup (no body)
