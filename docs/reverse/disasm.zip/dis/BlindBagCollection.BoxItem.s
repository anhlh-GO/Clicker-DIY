#### CLASS BlindBagCollection.BoxItem parent= object
#   field IsUnlocked                     bool                                               off=0x10 attr=6 
#   field ItemType                       BlindBagCollection.CollectionItemType              off=0x14 attr=6 
#   field Icon                           UnityEngine.SpriteRenderer                         off=0x18 attr=6 
## .ctor() -> void
---- BlindBagCollection.BoxItem::.ctor 0x2d39228
02d39228: mov     x1, xzr                                    
02d3922c: b       #0x4e53e9c                                 System.Object::.ctor
