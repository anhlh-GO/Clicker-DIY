#### CLASS Framework.DictionaryExtension parent= object
##  TryGetKeyByValue (no body)
##  GetKeysByValue (no body)
##  IsNullOrEmpty (no body)
