#### CLASS Clicker.PopupClickerComplete/<>c parent= object
#   field <>9                            Clicker.PopupClickerComplete/<>c                   off=0x0 attr=36 
#   field <>9__18_1                      System.Action                                      off=0x8 attr=16 
#   field <>9__18_0                      System.Action                                      off=0x10 attr=16 
#   field <>9__19_1                      System.Action                                      off=0x18 attr=16 
## .cctor() -> void
---- Clicker.PopupClickerComplete/<>c::.cctor 0x2d6f5d0
02d6f5d0: str     x30, [sp, #-0x20]!                         
02d6f5d4: stp     x20, x19, [sp, #0x10]                      
02d6f5d8: adrp    x19, #0x6630000                            
02d6f5dc: adrp    x20, #0x626c000                            
02d6f5e0: ldrb    w8, [x19, #0x395]                          
02d6f5e4: ldr     x20, [x20, #0x500]                         T:Clicker.PopupClickerComplete/<>c
02d6f5e8: tbnz    w8, #0, #0x2d6f600                         
02d6f5ec: adrp    x0, #0x626c000                             
02d6f5f0: ldr     x0, [x0, #0x500]                           T:Clicker.PopupClickerComplete/<>c
02d6f5f4: bl      #0x2b70db0                                 fn_2b70db0
02d6f5f8: mov     w8, #1                                     
02d6f5fc: strb    w8, [x19, #0x395]                          
02d6f600: ldr     x0, [x20]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6f604: bl      #0x2b7104c                                 fn_2b7104c
02d6f608: mov     x1, xzr                                    
02d6f60c: mov     x19, x0                                    
02d6f610: bl      #0x4e53e9c                                 System.Object::.ctor
02d6f614: ldr     x8, [x20]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6f618: mov     x1, x19                                    
02d6f61c: ldr     x8, [x8, #0xb8]                            
02d6f620: str     x19, [x8]                                  
02d6f624: ldr     x8, [x20]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6f628: ldp     x20, x19, [sp, #0x10]                      
02d6f62c: ldr     x0, [x8, #0xb8]                            
02d6f630: ldr     x30, [sp], #0x20                           
02d6f634: b       #0x2b70d54                                 
## .ctor() -> void
---- Clicker.PopupClickerComplete/<>c::.ctor 0x2d6f638
02d6f638: mov     x1, xzr                                    
02d6f63c: b       #0x4e53e9c                                 System.Object::.ctor
## <OnBtnRewardClick>b__18_0() -> void
---- Clicker.PopupClickerComplete/<>c::<OnBtnRewardClick>b__18_0 0x2d6f640
02d6f640: str     d8, [sp, #-0x40]!                          
02d6f644: stp     x30, x23, [sp, #0x10]                      
02d6f648: stp     x22, x21, [sp, #0x20]                      
02d6f64c: stp     x20, x19, [sp, #0x30]                      
02d6f650: adrp    x20, #0x6630000                            
02d6f654: adrp    x19, #0x6265000                            
02d6f658: adrp    x23, #0x626c000                            
02d6f65c: ldrb    w8, [x20, #0x396]                          
02d6f660: ldr     x19, [x19, #0x310]                         MS:WejoyService.Singleton`1::get_Instance
02d6f664: ldr     x23, [x23, #0x500]                         T:Clicker.PopupClickerComplete/<>c
02d6f668: tbnz    w8, #0, #0x2d6f710                         
02d6f66c: adrp    x0, #0x6264000                             
02d6f670: ldr     x0, [x0, #0xf90]                           T:System.Action
02d6f674: bl      #0x2b70db0                                 fn_2b70db0
02d6f678: adrp    x0, #0x6266000                             
02d6f67c: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d6f680: bl      #0x2b70db0                                 fn_2b70db0
02d6f684: adrp    x0, #0x6265000                             
02d6f688: ldr     x0, [x0, #0xb38]                           T:DevTrack
02d6f68c: bl      #0x2b70db0                                 fn_2b70db0
02d6f690: adrp    x0, #0x6266000                             
02d6f694: ldr     x0, [x0, #0x5e0]                           T:GameConfig
02d6f698: bl      #0x2b70db0                                 fn_2b70db0
02d6f69c: adrp    x0, #0x6266000                             
02d6f6a0: ldr     x0, [x0, #0xac0]                           MS:MonoSingleton`1::get_Instance
02d6f6a4: bl      #0x2b70db0                                 fn_2b70db0
02d6f6a8: adrp    x0, #0x626b000                             
02d6f6ac: ldr     x0, [x0, #0xda8]                           MS:MonoSingleton`1::get_Instance
02d6f6b0: bl      #0x2b70db0                                 fn_2b70db0
02d6f6b4: adrp    x0, #0x6265000                             
02d6f6b8: ldr     x0, [x0, #0x10]                            MS:MonoSingleton`1::get_Instance .<>9__18_0
02d6f6bc: bl      #0x2b70db0                                 fn_2b70db0
02d6f6c0: adrp    x0, #0x6266000                             
02d6f6c4: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d6f6c8: bl      #0x2b70db0                                 fn_2b70db0
02d6f6cc: adrp    x0, #0x6266000                             
02d6f6d0: ldr     x0, [x0, #0xb48]                           MS:MonoSingleton`1::get_Instance
02d6f6d4: bl      #0x2b70db0                                 fn_2b70db0
02d6f6d8: adrp    x0, #0x6265000                             
02d6f6dc: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02d6f6e0: bl      #0x2b70db0                                 fn_2b70db0
02d6f6e4: adrp    x0, #0x626c000                             
02d6f6e8: ldr     x0, [x0, #0x518]                           M:Clicker.PopupClickerComplete/<>c::<OnBtnRewardClick>b__18_1
02d6f6ec: bl      #0x2b70db0                                 fn_2b70db0
02d6f6f0: adrp    x0, #0x626c000                             
02d6f6f4: ldr     x0, [x0, #0x500]                           T:Clicker.PopupClickerComplete/<>c
02d6f6f8: bl      #0x2b70db0                                 fn_2b70db0
02d6f6fc: adrp    x0, #0x626a000                             
02d6f700: ldr     x0, [x0, #0xcd0]                           S:'no_thanks'
02d6f704: bl      #0x2b70db0                                 fn_2b70db0
02d6f708: mov     w8, #1                                     
02d6f70c: strb    w8, [x20, #0x396]                          
02d6f710: adrp    x20, #0x626a000                            
02d6f714: ldr     x20, [x20, #0xcd0]                         S:'no_thanks'
02d6f718: ldr     x0, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d6f71c: bl      #0x3be7218                                 fn_3be7218
02d6f720: ldr     x8, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6f724: mov     x19, x0                                    
02d6f728: ldr     w9, [x8, #0xe4]                            
02d6f72c: cbnz    w9, #0x2d6f73c                             
02d6f730: mov     x0, x8                                     
02d6f734: bl      #0x2b70f30                                 fn_2b70f30
02d6f738: ldr     x8, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6f73c: ldr     x9, [x8, #0xb8]                            
02d6f740: ldr     x20, [x20]                                 T:type56879(k15)
02d6f744: ldr     x21, [x9, #8]                              
02d6f748: cbnz    x21, #0x2d6f7a8                            
02d6f74c: ldr     w10, [x8, #0xe4]                           
02d6f750: cbnz    w10, #0x2d6f764                            
02d6f754: mov     x0, x8                                     
02d6f758: bl      #0x2b70f30                                 fn_2b70f30
02d6f75c: ldr     x8, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6f760: ldr     x9, [x8, #0xb8]                            
02d6f764: adrp    x8, #0x6264000                             
02d6f768: ldr     x8, [x8, #0xf90]                           T:System.Action
02d6f76c: ldr     x22, [x9]                                  
02d6f770: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d6f774: bl      #0x2b7104c                                 fn_2b7104c
02d6f778: adrp    x8, #0x626c000                             
02d6f77c: mov     x1, x22                                    
02d6f780: mov     x3, xzr                                    
02d6f784: ldr     x8, [x8, #0x518]                           M:Clicker.PopupClickerComplete/<>c::<OnBtnRewardClick>b__18_1
02d6f788: mov     x21, x0                                    
02d6f78c: ldr     x2, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6f790: bl      #0x4d8ddbc                                 System.Action::.ctor
02d6f794: ldr     x8, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6f798: mov     x1, x21                                    
02d6f79c: ldr     x0, [x8, #0xb8]                            MS:System.Collections.Generic.List`1::Add
02d6f7a0: str     x21, [x0, #8]!                             
02d6f7a4: bl      #0x2b70d54                                 fn_2b70d54
02d6f7a8: cbz     x19, #0x2d6f9ac                            
02d6f7ac: adrp    x22, #0x626b000                            
02d6f7b0: mov     x0, x19                                    
02d6f7b4: mov     x1, x20                                    
02d6f7b8: ldr     x22, [x22, #0xda8]                         MS:MonoSingleton`1::get_Instance
02d6f7bc: mov     x2, x21                                    
02d6f7c0: mov     w3, #1                                     
02d6f7c4: mov     x4, xzr                                    
02d6f7c8: bl      #0x2c89698                                 AdsManager::ShowInter
02d6f7cc: ldr     x0, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d6f7d0: bl      #0x3769600                                 fn_3769600
02d6f7d4: cbz     x0, #0x2d6f9ac                             
02d6f7d8: adrp    x19, #0x6265000                            
02d6f7dc: adrp    x20, #0x6266000                            
02d6f7e0: mov     x1, xzr                                    
02d6f7e4: ldr     x19, [x19, #0x10]                          MS:MonoSingleton`1::get_Instance .<>9__18_0
02d6f7e8: ldr     x20, [x20, #0x5e0]                         T:GameConfig
02d6f7ec: bl      #0x2d5d5ec                                 Clicker.Light2DManager::ReleaseAllItem
02d6f7f0: ldr     x0, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d6f7f4: bl      #0x3769600                                 fn_3769600
02d6f7f8: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6f7fc: mov     x19, x0                                    
02d6f800: ldr     w9, [x8, #0xe4]                            [626c0e4]=0 f=0,0
02d6f804: cbnz    w9, #0x2d6f810                             
02d6f808: mov     x0, x8                                     
02d6f80c: bl      #0x2b70f30                                 fn_2b70f30
02d6f810: cbz     x19, #0x2d6f9ac                            
02d6f814: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6f818: adrp    x20, #0x6266000                            
02d6f81c: mov     x0, x19                                    
02d6f820: mov     w2, wzr                                    
02d6f824: mov     x3, xzr                                    
02d6f828: ldr     x8, [x8, #0xb8]                            MS:System.Collections.Generic.List`1::Add
02d6f82c: ldr     x20, [x20, #0x658]                         MS:MonoSingleton`1::get_Instance
02d6f830: ldr     x1, [x8, #8]                               M:Clicker.GlowSprite2DItem::<DoGlow>b__10_3
02d6f834: bl      #0x2ce9e58                                 SimpleSceneTransition::FlashIn
02d6f838: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6f83c: bl      #0x3769600                                 fn_3769600
02d6f840: cbz     x0, #0x2d6f9ac                             
02d6f844: adrp    x8, #0x6266000                             
02d6f848: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02d6f84c: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6f850: bl      #0x3168dd0                                 fn_3168dd0
02d6f854: cbz     x0, #0x2d6f9ac                             
02d6f858: ldr     x8, [x0, #0x20]                            M:Decor.DataDecor/<>c__DisplayClass8_0::<NewData>b__0
02d6f85c: cbz     x8, #0x2d6f9ac                             
02d6f860: adrp    x9, #0x6266000                             
02d6f864: adrp    x21, #0x6265000                            
02d6f868: ldr     x9, [x9, #0xac0]                           MS:MonoSingleton`1::get_Instance
02d6f86c: ldr     x21, [x21, #0xb38]                         T:DevTrack
02d6f870: ldrb    w19, [x8, #0x44]                           
02d6f874: ldr     x0, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6f878: bl      #0x3769600                                 fn_3769600
02d6f87c: cbz     w19, #0x2d6f890                            
02d6f880: cbz     x0, #0x2d6f9ac                             
02d6f884: mov     w8, #1                                     
02d6f888: str     w8, [x0, #0x60]                            
02d6f88c: b       #0x2d6f8c8                                 
02d6f890: cbz     x0, #0x2d6f9ac                             
02d6f894: ldr     x8, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d6f898: str     wzr, [x0, #0x60]                           
02d6f89c: ldr     w9, [x8, #0xe4]                            [62660e4]=0 f=0,0
02d6f8a0: cbnz    w9, #0x2d6f8b0                             
02d6f8a4: mov     x0, x8                                     
02d6f8a8: bl      #0x2b70f30                                 fn_2b70f30
02d6f8ac: ldr     x8, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d6f8b0: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02d6f8b4: mov     x3, xzr                                    
02d6f8b8: ldr     x0, [x8, #0x1f8]                           MS:System.Collections.Generic.List`1/Enumerator::get_Current
02d6f8bc: ldr     x1, [x8, #0x260]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d6f8c0: ldr     w2, [x8, #0x294]                           [6266294]=0 f=0,0
02d6f8c4: bl      #0x2c9c1e0                                 DevTrack::OnboardingStep
02d6f8c8: adrp    x23, #0x6266000                            
02d6f8cc: ldr     x23, [x23, #0xb48]                         MS:MonoSingleton`1::get_Instance
02d6f8d0: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6f8d4: bl      #0x3769600                                 fn_3769600
02d6f8d8: cbz     x0, #0x2d6f9ac                             
02d6f8dc: ldr     x19, [x0, #0x30]                           S:'======================================================  i : '
02d6f8e0: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6f8e4: bl      #0x3769600                                 fn_3769600
02d6f8e8: cbz     x0, #0x2d6f9ac                             
02d6f8ec: mov     x8, x0                                     
02d6f8f0: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d6f8f4: ldr     w20, [x8, #0x3c]                           [626603c]=0 f=0,0
02d6f8f8: ldr     w9, [x0, #0xe4]                            [626a0e4]=0 f=0,0
02d6f8fc: cbnz    w9, #0x2d6f908                             
02d6f900: bl      #0x2b70f30                                 fn_2b70f30
02d6f904: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d6f908: ldr     x8, [x0, #0xb8]                            MS:UnityEngine.Object::FindObjectsOfType
02d6f90c: mov     x0, xzr                                    
02d6f910: ldr     x21, [x8, #0x260]                          MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d6f914: ldr     w22, [x8, #0x294]                          [6266294]=0 f=0,0
02d6f918: bl      #0x5b432fc                                 UnityEngine.Time::get_time
02d6f91c: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6f920: fmov    s8, s0                                     
02d6f924: bl      #0x3769600                                 fn_3769600
02d6f928: cbz     x0, #0x2d6f9ac                             
02d6f92c: ldr     s0, [x0, #0x38]                            MS:System.Collections.Generic.List`1::get_Item
02d6f930: mov     x0, x19                                    
02d6f934: mov     w1, w20                                    
02d6f938: mov     x2, x21                                    
02d6f93c: mov     w3, w22                                    
02d6f940: mov     x4, xzr                                    
02d6f944: fsub    s0, s8, s0                                 
02d6f948: bl      #0x2c9c898                                 DevTrack::GameModeStepComplete
02d6f94c: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6f950: bl      #0x3769600                                 fn_3769600
02d6f954: cbz     x0, #0x2d6f9ac                             
02d6f958: ldr     x19, [x0, #0x30]                           S:'======================================================  i : '
02d6f95c: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6f960: bl      #0x3769600                                 fn_3769600
02d6f964: cbz     x0, #0x2d6f9ac                             
02d6f968: ldr     w20, [x0, #0x3c]                           [626a03c]=0 f=0,0
02d6f96c: mov     x0, xzr                                    
02d6f970: bl      #0x5b432fc                                 UnityEngine.Time::get_time
02d6f974: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6f978: fmov    s8, s0                                     
02d6f97c: bl      #0x3769600                                 fn_3769600
02d6f980: cbz     x0, #0x2d6f9ac                             
02d6f984: ldr     s0, [x0, #0x38]                            MS:System.Collections.Generic.List`1::get_Item
02d6f988: mov     x0, x19                                    
02d6f98c: mov     w1, w20                                    
02d6f990: ldp     x20, x19, [sp, #0x30]                      
02d6f994: mov     x2, xzr                                    
02d6f998: ldp     x22, x21, [sp, #0x20]                      
02d6f99c: fsub    s0, s8, s0                                 
02d6f9a0: ldp     x30, x23, [sp, #0x10]                      
02d6f9a4: ldr     d8, [sp], #0x40                            
02d6f9a8: b       #0x2c9cd1c                                 DevTrack::GameModeComplete
02d6f9ac: bl      #0x2b7105c                                 fn_2b7105c
## <OnBtnRewardClick>b__18_1() -> void
---- Clicker.PopupClickerComplete/<>c::<OnBtnRewardClick>b__18_1 0x2d6f9b0
02d6f9b0: ret                                                
## <OnBtnAdRewardClick>b__19_1() -> void
---- Clicker.PopupClickerComplete/<>c::<OnBtnAdRewardClick>b__19_1 0x2d6f9b4
02d6f9b4: str     d8, [sp, #-0x40]!                          
02d6f9b8: stp     x30, x23, [sp, #0x10]                      
02d6f9bc: stp     x22, x21, [sp, #0x20]                      
02d6f9c0: stp     x20, x19, [sp, #0x30]                      
02d6f9c4: adrp    x19, #0x6630000                            
02d6f9c8: adrp    x21, #0x6265000                            
02d6f9cc: adrp    x20, #0x6266000                            
02d6f9d0: ldrb    w8, [x19, #0x397]                          
02d6f9d4: ldr     x21, [x21, #0x10]                          MS:MonoSingleton`1::get_Instance .<>9__18_0
02d6f9d8: ldr     x20, [x20, #0x5e0]                         T:GameConfig
02d6f9dc: tbnz    w8, #0, #0x2d6fa3c                         
02d6f9e0: adrp    x0, #0x6266000                             
02d6f9e4: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d6f9e8: bl      #0x2b70db0                                 fn_2b70db0
02d6f9ec: adrp    x0, #0x6265000                             
02d6f9f0: ldr     x0, [x0, #0xb38]                           T:DevTrack
02d6f9f4: bl      #0x2b70db0                                 fn_2b70db0
02d6f9f8: adrp    x0, #0x6266000                             
02d6f9fc: ldr     x0, [x0, #0x5e0]                           T:GameConfig
02d6fa00: bl      #0x2b70db0                                 fn_2b70db0
02d6fa04: adrp    x0, #0x6266000                             
02d6fa08: ldr     x0, [x0, #0xac0]                           MS:MonoSingleton`1::get_Instance
02d6fa0c: bl      #0x2b70db0                                 fn_2b70db0
02d6fa10: adrp    x0, #0x6265000                             
02d6fa14: ldr     x0, [x0, #0x10]                            MS:MonoSingleton`1::get_Instance .<>9__18_0
02d6fa18: bl      #0x2b70db0                                 fn_2b70db0
02d6fa1c: adrp    x0, #0x6266000                             
02d6fa20: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d6fa24: bl      #0x2b70db0                                 fn_2b70db0
02d6fa28: adrp    x0, #0x6266000                             
02d6fa2c: ldr     x0, [x0, #0xb48]                           MS:MonoSingleton`1::get_Instance
02d6fa30: bl      #0x2b70db0                                 fn_2b70db0
02d6fa34: mov     w8, #1                                     
02d6fa38: strb    w8, [x19, #0x397]                          
02d6fa3c: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d6fa40: bl      #0x3769600                                 fn_3769600
02d6fa44: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6fa48: mov     x19, x0                                    
02d6fa4c: ldr     w9, [x8, #0xe4]                            
02d6fa50: cbnz    w9, #0x2d6fa5c                             
02d6fa54: mov     x0, x8                                     
02d6fa58: bl      #0x2b70f30                                 fn_2b70f30
02d6fa5c: cbz     x19, #0x2d6fbf8                            
02d6fa60: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6fa64: adrp    x20, #0x6266000                            
02d6fa68: mov     x0, x19                                    
02d6fa6c: mov     w2, wzr                                    
02d6fa70: mov     x3, xzr                                    
02d6fa74: ldr     x8, [x8, #0xb8]                            
02d6fa78: ldr     x20, [x20, #0x658]                         MS:MonoSingleton`1::get_Instance
02d6fa7c: ldr     x1, [x8, #8]                               
02d6fa80: bl      #0x2ce9e58                                 SimpleSceneTransition::FlashIn
02d6fa84: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6fa88: bl      #0x3769600                                 fn_3769600
02d6fa8c: cbz     x0, #0x2d6fbf8                             
02d6fa90: adrp    x8, #0x6266000                             
02d6fa94: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02d6fa98: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6fa9c: bl      #0x3168dd0                                 fn_3168dd0
02d6faa0: cbz     x0, #0x2d6fbf8                             
02d6faa4: ldr     x8, [x0, #0x20]                            S:'inter_ad_capping_time'
02d6faa8: cbz     x8, #0x2d6fbf8                             
02d6faac: adrp    x9, #0x6266000                             
02d6fab0: adrp    x21, #0x6265000                            
02d6fab4: ldr     x9, [x9, #0xac0]                           MS:MonoSingleton`1::get_Instance
02d6fab8: ldr     x21, [x21, #0xb38]                         T:DevTrack
02d6fabc: ldrb    w19, [x8, #0x44]                           
02d6fac0: ldr     x0, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6fac4: bl      #0x3769600                                 fn_3769600
02d6fac8: cbz     w19, #0x2d6fadc                            
02d6facc: cbz     x0, #0x2d6fbf8                             
02d6fad0: mov     w8, #1                                     
02d6fad4: str     w8, [x0, #0x60]                            
02d6fad8: b       #0x2d6fb14                                 
02d6fadc: cbz     x0, #0x2d6fbf8                             
02d6fae0: ldr     x8, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d6fae4: str     wzr, [x0, #0x60]                           
02d6fae8: ldr     w9, [x8, #0xe4]                            [62660e4]=0 f=0,0
02d6faec: cbnz    w9, #0x2d6fafc                             
02d6faf0: mov     x0, x8                                     
02d6faf4: bl      #0x2b70f30                                 fn_2b70f30
02d6faf8: ldr     x8, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d6fafc: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02d6fb00: mov     x3, xzr                                    
02d6fb04: ldr     x0, [x8, #0x1f8]                           MS:System.Collections.Generic.List`1/Enumerator::get_Current
02d6fb08: ldr     x1, [x8, #0x260]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d6fb0c: ldr     w2, [x8, #0x294]                           [6266294]=0 f=0,0
02d6fb10: bl      #0x2c9c1e0                                 DevTrack::OnboardingStep
02d6fb14: adrp    x23, #0x6266000                            
02d6fb18: ldr     x23, [x23, #0xb48]                         MS:MonoSingleton`1::get_Instance
02d6fb1c: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6fb20: bl      #0x3769600                                 fn_3769600
02d6fb24: cbz     x0, #0x2d6fbf8                             
02d6fb28: ldr     x19, [x0, #0x30]                           S:'popup_rate_on_off'
02d6fb2c: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6fb30: bl      #0x3769600                                 fn_3769600
02d6fb34: cbz     x0, #0x2d6fbf8                             
02d6fb38: mov     x8, x0                                     
02d6fb3c: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d6fb40: ldr     w20, [x8, #0x3c]                           [626603c]=0 f=0,0
02d6fb44: ldr     w9, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d6fb48: cbnz    w9, #0x2d6fb54                             
02d6fb4c: bl      #0x2b70f30                                 fn_2b70f30
02d6fb50: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d6fb54: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time'
02d6fb58: mov     x0, xzr                                    
02d6fb5c: ldr     x21, [x8, #0x260]                          MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d6fb60: ldr     w22, [x8, #0x294]                          [6266294]=0 f=0,0
02d6fb64: bl      #0x5b432fc                                 UnityEngine.Time::get_time
02d6fb68: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6fb6c: fmov    s8, s0                                     
02d6fb70: bl      #0x3769600                                 fn_3769600
02d6fb74: cbz     x0, #0x2d6fbf8                             
02d6fb78: ldr     s0, [x0, #0x38]                            S:'native_collap_id'
02d6fb7c: mov     x0, x19                                    
02d6fb80: mov     w1, w20                                    
02d6fb84: mov     x2, x21                                    
02d6fb88: mov     w3, w22                                    
02d6fb8c: mov     x4, xzr                                    
02d6fb90: fsub    s0, s8, s0                                 
02d6fb94: bl      #0x2c9c898                                 DevTrack::GameModeStepComplete
02d6fb98: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6fb9c: bl      #0x3769600                                 fn_3769600
02d6fba0: cbz     x0, #0x2d6fbf8                             
02d6fba4: ldr     x19, [x0, #0x30]                           S:'popup_rate_on_off'
02d6fba8: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6fbac: bl      #0x3769600                                 fn_3769600
02d6fbb0: cbz     x0, #0x2d6fbf8                             
02d6fbb4: ldr     w20, [x0, #0x3c]                           [626603c]=0 f=0,0
02d6fbb8: mov     x0, xzr                                    
02d6fbbc: bl      #0x5b432fc                                 UnityEngine.Time::get_time
02d6fbc0: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6fbc4: fmov    s8, s0                                     
02d6fbc8: bl      #0x3769600                                 fn_3769600
02d6fbcc: cbz     x0, #0x2d6fbf8                             
02d6fbd0: ldr     s0, [x0, #0x38]                            S:'native_collap_id'
02d6fbd4: mov     x0, x19                                    
02d6fbd8: mov     w1, w20                                    
02d6fbdc: ldp     x20, x19, [sp, #0x30]                      
02d6fbe0: mov     x2, xzr                                    
02d6fbe4: ldp     x22, x21, [sp, #0x20]                      
02d6fbe8: fsub    s0, s8, s0                                 
02d6fbec: ldp     x30, x23, [sp, #0x10]                      
02d6fbf0: ldr     d8, [sp], #0x40                            
02d6fbf4: b       #0x2c9cd1c                                 DevTrack::GameModeComplete
02d6fbf8: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Clicker.PopupClickerComplete parent= PopupBase
#   field _btnAdReward                   UnityEngine.UI.Button                              off=0x38 attr=1 SerializeField
#   field _btnReward                     UnityEngine.UI.Button                              off=0x40 attr=1 SerializeField
#   field _imgCustomer                   UnityEngine.UI.Image                               off=0x48 attr=1 SerializeField
#   field _viewerAvatarAsset             ViewerAvatarAsset                                  off=0x50 attr=1 SerializeField
#   field _txtCompliment                 TMPro.TextMeshProUGUI                              off=0x58 attr=1 SerializeField
#   field _txtEarnings                   TMPro.TextMeshProUGUI                              off=0x60 attr=1 SerializeField
#   field _txtTips                       TMPro.TextMeshProUGUI                              off=0x68 attr=1 SerializeField
#   field _fxConfetti                    AssetKits.ParticleImage.ParticleImage              off=0x70 attr=1 SerializeField
#   field _tfTitle                       UnityEngine.Transform                              off=0x78 attr=1 SerializeField
#   field _tfCompliment                  UnityEngine.Transform                              off=0x80 attr=1 SerializeField
#   field _tfRewardInfo                  UnityEngine.Transform                              off=0x88 attr=1 SerializeField
#   field _tfBtnAdReward                 UnityEngine.Transform                              off=0x90 attr=1 SerializeField
#   field _tfBtnReward                   UnityEngine.Transform                              off=0x98 attr=1 SerializeField
#   field _moneyReward                   int                                                off=0xa0 attr=1 
#   field _moneyBonus                    int                                                off=0xa4 attr=1 
## OnInit(UIManager uiManager) -> void
---- Clicker.PopupClickerComplete::OnInit 0x2d6e6f8
02d6e6f8: str     x30, [sp, #-0x30]!                         
02d6e6fc: stp     x22, x21, [sp, #0x10]                      
02d6e700: stp     x20, x19, [sp, #0x20]                      
02d6e704: adrp    x21, #0x6630000                            
02d6e708: mov     x20, x1                                    
02d6e70c: mov     x19, x0                                    
02d6e710: ldrb    w8, [x21, #0x390]                          
02d6e714: tbnz    w8, #0, #0x2d6e750                         
02d6e718: adrp    x0, #0x626c000                             
02d6e71c: ldr     x0, [x0, #0x4c8]                           M:Clicker.PopupClickerComplete::OnBtnAdRewardClick
02d6e720: bl      #0x2b70db0                                 fn_2b70db0
02d6e724: adrp    x0, #0x626c000                             
02d6e728: ldr     x0, [x0, #0x4d0]                           M:Clicker.PopupClickerComplete::OnBtnRewardClick
02d6e72c: bl      #0x2b70db0                                 fn_2b70db0
02d6e730: adrp    x0, #0x6264000                             
02d6e734: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02d6e738: bl      #0x2b70db0                                 fn_2b70db0
02d6e73c: adrp    x0, #0x6265000                             
02d6e740: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d6e744: bl      #0x2b70db0                                 fn_2b70db0
02d6e748: mov     w8, #1                                     
02d6e74c: strb    w8, [x21, #0x390]                          
02d6e750: mov     x0, x19                                    
02d6e754: mov     x1, x20                                    
02d6e758: mov     x2, xzr                                    
02d6e75c: bl      #0x2cdd3c4                                 UIBase::OnInit
02d6e760: ldr     x8, [x19, #0x40]                           ._btnReward
02d6e764: cbz     x8, #0x2d6e8bc                             
02d6e768: ldr     x0, [x8, #0x100]                           
02d6e76c: cbz     x0, #0x2d6e8bc                             
02d6e770: mov     x1, xzr                                    
02d6e774: bl      #0x5b4ce48                                 UnityEngine.Events.UnityEventBase::RemoveAllListeners
02d6e778: ldr     x8, [x19, #0x40]                           ._btnReward
02d6e77c: cbz     x8, #0x2d6e8bc                             
02d6e780: adrp    x22, #0x6265000                            
02d6e784: adrp    x21, #0x626c000                            
02d6e788: ldr     x22, [x22, #0x3f0]                         T:UnityEngine.Events.UnityAction
02d6e78c: ldr     x21, [x21, #0x4d0]                         M:Clicker.PopupClickerComplete::OnBtnRewardClick
02d6e790: ldr     x20, [x8, #0x100]                          
02d6e794: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d6e798: bl      #0x2b7104c                                 fn_2b7104c
02d6e79c: ldr     x2, [x21]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6e7a0: mov     x1, x19                                    
02d6e7a4: mov     x3, xzr                                    
02d6e7a8: mov     x21, x0                                    
02d6e7ac: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d6e7b0: cbz     x20, #0x2d6e8bc                            
02d6e7b4: mov     x0, x20                                    
02d6e7b8: mov     x1, x21                                    
02d6e7bc: mov     x2, xzr                                    
02d6e7c0: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d6e7c4: ldr     x8, [x19, #0x38]                           ._btnAdReward
02d6e7c8: cbz     x8, #0x2d6e8bc                             
02d6e7cc: ldr     x0, [x8, #0x100]                           
02d6e7d0: cbz     x0, #0x2d6e8bc                             
02d6e7d4: mov     x1, xzr                                    
02d6e7d8: bl      #0x5b4ce48                                 UnityEngine.Events.UnityEventBase::RemoveAllListeners
02d6e7dc: ldr     x8, [x19, #0x38]                           ._btnAdReward
02d6e7e0: cbz     x8, #0x2d6e8bc                             
02d6e7e4: adrp    x21, #0x626c000                            
02d6e7e8: ldr     x21, [x21, #0x4c8]                         M:Clicker.PopupClickerComplete::OnBtnAdRewardClick
02d6e7ec: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d6e7f0: ldr     x20, [x8, #0x100]                          
02d6e7f4: bl      #0x2b7104c                                 fn_2b7104c
02d6e7f8: ldr     x2, [x21]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6e7fc: mov     x1, x19                                    
02d6e800: mov     x3, xzr                                    
02d6e804: mov     x21, x0                                    
02d6e808: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d6e80c: cbz     x20, #0x2d6e8bc                            
02d6e810: mov     x0, x20                                    
02d6e814: mov     x1, x21                                    
02d6e818: mov     x2, xzr                                    
02d6e81c: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d6e820: ldr     x0, [x19, #0x70]                           ._fxConfetti
02d6e824: cbz     x0, #0x2d6e8bc                             
02d6e828: mov     x1, xzr                                    
02d6e82c: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d6e830: cbz     x0, #0x2d6e8bc                             
02d6e834: adrp    x20, #0x6264000                            
02d6e838: mov     w1, wzr                                    
02d6e83c: mov     x2, xzr                                    
02d6e840: ldr     x20, [x20, #0xfc0]                         T:RemoteConfigManager
02d6e844: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d6e848: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d6e84c: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02d6e850: cbnz    w8, #0x2d6e858                             
02d6e854: bl      #0x2b70f30                                 fn_2b70f30
02d6e858: adrp    x21, #0x662f000                            
02d6e85c: ldrb    w8, [x21, #0xbc1]                          
02d6e860: cbnz    w8, #0x2d6e878                             
02d6e864: adrp    x0, #0x6264000                             
02d6e868: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02d6e86c: bl      #0x2b70db0                                 fn_2b70db0
02d6e870: mov     w8, #1                                     
02d6e874: strb    w8, [x21, #0xbc1]                          
02d6e878: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d6e87c: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02d6e880: cbnz    w8, #0x2d6e88c                             
02d6e884: bl      #0x2b70f30                                 fn_2b70f30
02d6e888: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d6e88c: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d6e890: mov     w9, #0x190                                 
02d6e894: mov     w10, #0x1f4                                
02d6e898: ldp     x22, x21, [sp, #0x10]                      
02d6e89c: ldr     w8, [x8, #0x10]                            
02d6e8a0: cmp     w8, #1                                     
02d6e8a4: csel    w8, w10, w9, eq                            
02d6e8a8: mov     w9, #0x64                                  
02d6e8ac: stp     w8, w9, [x19, #0xa0]                       ._moneyReward
02d6e8b0: ldp     x20, x19, [sp, #0x20]                      
02d6e8b4: ldr     x30, [sp], #0x30                           
02d6e8b8: ret                                                
02d6e8bc: bl      #0x2b7105c                                 fn_2b7105c
## OnShow() -> void
---- Clicker.PopupClickerComplete::OnShow 0x2d6e8c0
02d6e8c0: str     d8, [sp, #-0x40]!                          
02d6e8c4: str     x30, [sp, #8]                              
02d6e8c8: stp     x24, x23, [sp, #0x10]                      
02d6e8cc: stp     x22, x21, [sp, #0x20]                      
02d6e8d0: stp     x20, x19, [sp, #0x30]                      
02d6e8d4: adrp    x20, #0x6630000                            
02d6e8d8: mov     x19, x0                                    
02d6e8dc: ldrb    w8, [x20, #0x391]                          
02d6e8e0: tbnz    w8, #0, #0x2d6e970                         
02d6e8e4: adrp    x0, #0x6266000                             
02d6e8e8: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d6e8ec: bl      #0x2b70db0                                 fn_2b70db0
02d6e8f0: adrp    x0, #0x6265000                             
02d6e8f4: ldr     x0, [x0, #0xb38]                           T:DevTrack
02d6e8f8: bl      #0x2b70db0                                 fn_2b70db0
02d6e8fc: adrp    x0, #0x6267000                             
02d6e900: ldr     x0, [x0, #0xd20]                           MS:MonoSingleton`1::get_Instance
02d6e904: bl      #0x2b70db0                                 fn_2b70db0
02d6e908: adrp    x0, #0x6266000                             
02d6e90c: ldr     x0, [x0, #0xac0]                           MS:MonoSingleton`1::get_Instance
02d6e910: bl      #0x2b70db0                                 fn_2b70db0
02d6e914: adrp    x0, #0x626b000                             
02d6e918: ldr     x0, [x0, #0xee0]                           MS:MonoSingleton`1::get_Instance
02d6e91c: bl      #0x2b70db0                                 fn_2b70db0
02d6e920: adrp    x0, #0x6266000                             
02d6e924: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d6e928: bl      #0x2b70db0                                 fn_2b70db0
02d6e92c: adrp    x0, #0x6266000                             
02d6e930: ldr     x0, [x0, #0xb48]                           MS:MonoSingleton`1::get_Instance
02d6e934: bl      #0x2b70db0                                 fn_2b70db0
02d6e938: adrp    x0, #0x6263000                             
02d6e93c: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d6e940: bl      #0x2b70db0                                 fn_2b70db0
02d6e944: adrp    x0, #0x6266000                             
02d6e948: ldr     x0, [x0, #0xe08]                           MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02d6e94c: bl      #0x2b70db0                                 fn_2b70db0
02d6e950: adrp    x0, #0x6266000                             
02d6e954: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d6e958: bl      #0x2b70db0                                 fn_2b70db0
02d6e95c: adrp    x0, #0x6267000                             
02d6e960: ldr     x0, [x0, #0x308]                           S:'+'
02d6e964: bl      #0x2b70db0                                 fn_2b70db0
02d6e968: mov     w8, #1                                     
02d6e96c: strb    w8, [x20, #0x391]                          
02d6e970: mov     x0, x19                                    
02d6e974: mov     x1, xzr                                    
02d6e978: bl      #0x2cdd6b8                                 UIBase::OnShow
02d6e97c: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d6e980: cbz     x0, #0x2d6eec4                             
02d6e984: movi    d1, #0000000000000000                      
02d6e988: movi    d2, #0000000000000000                      
02d6e98c: mov     w1, #0x30                                  
02d6e990: fmov    s0, #1.00000000                            
02d6e994: mov     w2, wzr                                    
02d6e998: mov     w3, wzr                                    
02d6e99c: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d6e9a0: ldr     x0, [x19, #0x70]                           ._fxConfetti
02d6e9a4: cbz     x0, #0x2d6eec4                             
02d6e9a8: mov     x1, xzr                                    
02d6e9ac: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d6e9b0: cbz     x0, #0x2d6eec4                             
02d6e9b4: mov     w1, #1                                     
02d6e9b8: mov     x2, xzr                                    
02d6e9bc: mov     w21, #1                                    
02d6e9c0: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d6e9c4: ldr     x0, [x19, #0x78]                           ._tfTitle
02d6e9c8: mov     w1, wzr                                    
02d6e9cc: mov     x2, xzr                                    
02d6e9d0: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d6e9d4: adrp    x22, #0x662f000                            
02d6e9d8: ldr     x20, [x19, #0x78]                          ._tfTitle
02d6e9dc: ldrb    w8, [x22, #0x91a]                          
02d6e9e0: cbnz    w8, #0x2d6e9f4                             
02d6e9e4: adrp    x0, #0x6264000                             
02d6e9e8: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d6e9ec: bl      #0x2b70db0                                 fn_2b70db0
02d6e9f0: strb    w21, [x22, #0x91a]                         
02d6e9f4: cbz     x20, #0x2d6eec4                            
02d6e9f8: adrp    x23, #0x6264000                            
02d6e9fc: adrp    x21, #0x6266000                            
02d6ea00: mov     x0, x20                                    
02d6ea04: ldr     x23, [x23, #0xd8]                          T:UnityEngine.Vector3
02d6ea08: mov     x1, xzr                                    
02d6ea0c: ldr     x8, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d6ea10: ldr     x8, [x8, #0xb8]                            
02d6ea14: ldr     x21, [x21, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d6ea18: ldp     s1, s2, [x8, #4]                           
02d6ea1c: ldr     s0, [x8]                                   
02d6ea20: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d6ea24: adrp    x8, #0x1084000                             
02d6ea28: fmov    s0, #1.00000000                            
02d6ea2c: ldr     x0, [x19, #0x78]                           ._tfTitle
02d6ea30: ldr     s8, [x8, #0xf10]                           [1084f10]=4110bc863e99999a f=0.3,9.04603
02d6ea34: mov     x1, xzr                                    
02d6ea38: fmov    s1, s8                                     
02d6ea3c: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d6ea40: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6ea44: mov     w1, #0x1b                                  
02d6ea48: bl      #0x336fa0c                                 fn_336fa0c
02d6ea4c: ldr     x0, [x19, #0x80]                           ._tfCompliment
02d6ea50: mov     w1, wzr                                    
02d6ea54: mov     x2, xzr                                    
02d6ea58: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d6ea5c: ldrb    w8, [x22, #0x91a]                          
02d6ea60: ldr     x20, [x19, #0x80]                          ._tfCompliment
02d6ea64: cbnz    w8, #0x2d6ea7c                             
02d6ea68: adrp    x0, #0x6264000                             
02d6ea6c: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d6ea70: bl      #0x2b70db0                                 fn_2b70db0
02d6ea74: mov     w8, #1                                     
02d6ea78: strb    w8, [x22, #0x91a]                          
02d6ea7c: cbz     x20, #0x2d6eec4                            
02d6ea80: ldr     x8, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d6ea84: adrp    x24, #0x6266000                            
02d6ea88: mov     x0, x20                                    
02d6ea8c: mov     x1, xzr                                    
02d6ea90: ldr     x8, [x8, #0xb8]                            [10840b8]=2632726f74636556 f=7.20646e+31,6.19112e-16
02d6ea94: ldr     x24, [x24, #0xe08]                         MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02d6ea98: ldp     s1, s2, [x8, #4]                           
02d6ea9c: ldr     s0, [x8]                                   [1084000]=287475706e49646c f=1.5582e+28,1.35702e-14
02d6eaa0: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d6eaa4: fmov    s1, s8                                     
02d6eaa8: fmov    s0, #1.00000000                            
02d6eaac: ldr     x0, [x19, #0x80]                           ._tfCompliment
02d6eab0: mov     x1, xzr                                    
02d6eab4: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d6eab8: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6eabc: mov     w1, #0x1b                                  
02d6eac0: bl      #0x336fa0c                                 fn_336fa0c
02d6eac4: fmov    s0, #0.50000000                            
02d6eac8: ldr     x1, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6eacc: bl      #0x336f7fc                                 fn_336f7fc
02d6ead0: ldr     x0, [x19, #0x88]                           ._tfRewardInfo
02d6ead4: mov     w1, wzr                                    
02d6ead8: mov     x2, xzr                                    
02d6eadc: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d6eae0: ldrb    w8, [x22, #0x91a]                          
02d6eae4: ldr     x20, [x19, #0x88]                          ._tfRewardInfo
02d6eae8: cbnz    w8, #0x2d6eb00                             
02d6eaec: adrp    x0, #0x6264000                             
02d6eaf0: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d6eaf4: bl      #0x2b70db0                                 fn_2b70db0
02d6eaf8: mov     w8, #1                                     
02d6eafc: strb    w8, [x22, #0x91a]                          
02d6eb00: cbz     x20, #0x2d6eec4                            
02d6eb04: ldr     x8, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d6eb08: mov     x0, x20                                    
02d6eb0c: mov     x1, xzr                                    
02d6eb10: ldr     x8, [x8, #0xb8]                            [10840b8]=2632726f74636556 f=7.20646e+31,6.19112e-16
02d6eb14: ldp     s1, s2, [x8, #4]                           
02d6eb18: ldr     s0, [x8]                                   [1084000]=287475706e49646c f=1.5582e+28,1.35702e-14
02d6eb1c: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d6eb20: fmov    s1, s8                                     
02d6eb24: fmov    s0, #1.00000000                            
02d6eb28: ldr     x0, [x19, #0x88]                           ._tfRewardInfo
02d6eb2c: mov     x1, xzr                                    
02d6eb30: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d6eb34: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6eb38: mov     w1, #0x1b                                  
02d6eb3c: bl      #0x336fa0c                                 fn_336fa0c
02d6eb40: fmov    s0, #0.75000000                            
02d6eb44: ldr     x1, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6eb48: bl      #0x336f7fc                                 fn_336f7fc
02d6eb4c: ldr     x0, [x19, #0x90]                           ._tfBtnAdReward
02d6eb50: mov     w1, wzr                                    
02d6eb54: mov     x2, xzr                                    
02d6eb58: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d6eb5c: ldrb    w8, [x22, #0x91a]                          
02d6eb60: ldr     x20, [x19, #0x90]                          ._tfBtnAdReward
02d6eb64: cbnz    w8, #0x2d6eb7c                             
02d6eb68: adrp    x0, #0x6264000                             
02d6eb6c: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d6eb70: bl      #0x2b70db0                                 fn_2b70db0
02d6eb74: mov     w8, #1                                     
02d6eb78: strb    w8, [x22, #0x91a]                          
02d6eb7c: cbz     x20, #0x2d6eec4                            
02d6eb80: ldr     x8, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d6eb84: mov     x0, x20                                    
02d6eb88: mov     x1, xzr                                    
02d6eb8c: ldr     x8, [x8, #0xb8]                            [10840b8]=2632726f74636556 f=7.20646e+31,6.19112e-16
02d6eb90: ldp     s1, s2, [x8, #4]                           
02d6eb94: ldr     s0, [x8]                                   [1084000]=287475706e49646c f=1.5582e+28,1.35702e-14
02d6eb98: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d6eb9c: fmov    s1, s8                                     
02d6eba0: fmov    s0, #1.00000000                            
02d6eba4: ldr     x0, [x19, #0x90]                           ._tfBtnAdReward
02d6eba8: mov     x1, xzr                                    
02d6ebac: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d6ebb0: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6ebb4: mov     w1, #0x1b                                  
02d6ebb8: bl      #0x336fa0c                                 fn_336fa0c
02d6ebbc: fmov    s0, #1.00000000                            
02d6ebc0: ldr     x1, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6ebc4: bl      #0x336f7fc                                 fn_336f7fc
02d6ebc8: ldr     x0, [x19, #0x98]                           ._tfBtnReward
02d6ebcc: mov     w1, wzr                                    
02d6ebd0: mov     x2, xzr                                    
02d6ebd4: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d6ebd8: ldrb    w8, [x22, #0x91a]                          
02d6ebdc: ldr     x20, [x19, #0x98]                          ._tfBtnReward
02d6ebe0: cbnz    w8, #0x2d6ebf8                             
02d6ebe4: adrp    x0, #0x6264000                             
02d6ebe8: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d6ebec: bl      #0x2b70db0                                 fn_2b70db0
02d6ebf0: mov     w8, #1                                     
02d6ebf4: strb    w8, [x22, #0x91a]                          
02d6ebf8: cbz     x20, #0x2d6eec4                            
02d6ebfc: ldr     x8, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d6ec00: adrp    x22, #0x6267000                            
02d6ec04: mov     x0, x20                                    
02d6ec08: mov     x1, xzr                                    
02d6ec0c: ldr     x8, [x8, #0xb8]                            [10840b8]=2632726f74636556 f=7.20646e+31,6.19112e-16
02d6ec10: ldr     x22, [x22, #0x308]                         S:'+'
02d6ec14: ldp     s1, s2, [x8, #4]                           
02d6ec18: ldr     s0, [x8]                                   [1084000]=287475706e49646c f=1.5582e+28,1.35702e-14
02d6ec1c: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d6ec20: fmov    s1, s8                                     
02d6ec24: fmov    s0, #1.00000000                            
02d6ec28: ldr     x0, [x19, #0x98]                           ._tfBtnReward
02d6ec2c: mov     x1, xzr                                    
02d6ec30: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d6ec34: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6ec38: mov     w1, #0x1b                                  
02d6ec3c: bl      #0x336fa0c                                 fn_336fa0c
02d6ec40: fmov    s0, #1.50000000                            
02d6ec44: ldr     x1, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6ec48: bl      #0x336f7fc                                 fn_336f7fc
02d6ec4c: ldr     x20, [x19, #0x60]                          ._txtEarnings
02d6ec50: add     x0, x19, #0xa0                             
02d6ec54: mov     x1, xzr                                    
02d6ec58: bl      #0x4e0ea3c                                 System.Int32::ToString
02d6ec5c: ldr     x8, [x22]                                  S:'didu'
02d6ec60: mov     x1, x0                                     
02d6ec64: mov     x2, xzr                                    
02d6ec68: mov     x0, x8                                     
02d6ec6c: bl      #0x4c9c514                                 System.String::Concat
02d6ec70: cbz     x20, #0x2d6eec4                            
02d6ec74: ldr     x8, [x20]                                  
02d6ec78: mov     x1, x0                                     
02d6ec7c: mov     x0, x20                                    
02d6ec80: ldr     x9, [x8, #0x558]                           [1084558]=5500292632726f74 f=1.41116e-08,8.80714e+12
02d6ec84: ldr     x2, [x8, #0x560]                           [1084560]=69676e457974696e f=7.93162e+34,1.74864e+25
02d6ec88: blr     x9                                         
02d6ec8c: ldr     x20, [x19, #0x68]                          ._txtTips
02d6ec90: add     x0, x19, #0xa4                             
02d6ec94: mov     x1, xzr                                    
02d6ec98: bl      #0x4e0ea3c                                 System.Int32::ToString
02d6ec9c: ldr     x8, [x22]                                  S:'didu'
02d6eca0: mov     x1, x0                                     
02d6eca4: mov     x2, xzr                                    
02d6eca8: mov     x0, x8                                     
02d6ecac: bl      #0x4c9c514                                 System.String::Concat
02d6ecb0: cbz     x20, #0x2d6eec4                            
02d6ecb4: ldr     x8, [x20]                                  
02d6ecb8: adrp    x21, #0x6266000                            
02d6ecbc: mov     x1, x0                                     
02d6ecc0: ldr     x21, [x21, #0x658]                         MS:MonoSingleton`1::get_Instance
02d6ecc4: mov     x0, x20                                    
02d6ecc8: ldr     x9, [x8, #0x558]                           [1084558]=5500292632726f74 f=1.41116e-08,8.80714e+12
02d6eccc: ldr     x2, [x8, #0x560]                           [1084560]=69676e457974696e f=7.93162e+34,1.74864e+25
02d6ecd0: blr     x9                                         
02d6ecd4: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6ecd8: bl      #0x3769600                                 fn_3769600
02d6ecdc: cbz     x0, #0x2d6eec4                             
02d6ece0: adrp    x8, #0x6266000                             
02d6ece4: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02d6ece8: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6ecec: bl      #0x3168dd0                                 fn_3168dd0
02d6ecf0: cbz     x0, #0x2d6eec4                             
02d6ecf4: ldr     x8, [x0, #0x20]                            T:DG.Tweening.DOTweenModulePhysics/<>c__DisplayClass0_0
02d6ecf8: cbz     x8, #0x2d6eec4                             
02d6ecfc: adrp    x21, #0x6266000                            
02d6ed00: ldrb    w9, [x8, #0x3b]                            
02d6ed04: ldr     x21, [x21, #0xac0]                         MS:MonoSingleton`1::get_Instance
02d6ed08: cbz     w9, #0x2d6ed10                             
02d6ed0c: strh    wzr, [x8, #0x3a]                           
02d6ed10: ldr     w9, [x8, #0x4c]                            [626604c]=0 f=0,0
02d6ed14: add     w9, w9, #1                                 
02d6ed18: str     w9, [x8, #0x4c]                            
02d6ed1c: ldr     x8, [x0]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d6ed20: ldr     x9, [x8, #0x258]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d6ed24: ldr     x1, [x8, #0x260]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d6ed28: blr     x9                                         
02d6ed2c: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6ed30: bl      #0x3769600                                 fn_3769600
02d6ed34: cbz     x0, #0x2d6eec4                             
02d6ed38: adrp    x8, #0x6263000                             
02d6ed3c: ldr     x8, [x8, #0x918]                           T:UnityEngine.Object
02d6ed40: ldr     x20, [x0, #0x68]                           M:DG.Tweening.DOTweenModulePhysics/<>c__DisplayClass2_0::<DOMoveY>b__0 ._txtTips
02d6ed44: ldr     x8, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02d6ed48: ldr     w9, [x8, #0xe4]                            [62630e4]=0 f=0,0
02d6ed4c: cbnz    w9, #0x2d6ed58                             
02d6ed50: mov     x0, x8                                     
02d6ed54: bl      #0x2b70f30                                 fn_2b70f30
02d6ed58: mov     x0, x20                                    
02d6ed5c: mov     x1, xzr                                    
02d6ed60: mov     x2, xzr                                    
02d6ed64: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d6ed68: tbz     w0, #0, #0x2d6ed90                         
02d6ed6c: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6ed70: ldr     x19, [x19, #0x48]                          ._imgCustomer
02d6ed74: bl      #0x3769600                                 fn_3769600
02d6ed78: cbz     x0, #0x2d6eec4                             
02d6ed7c: cbz     x19, #0x2d6eec4                            
02d6ed80: ldr     x1, [x0, #0x68]                            M:DG.Tweening.DOTweenModulePhysics/<>c__DisplayClass2_0::<DOMoveY>b__0 ._txtTips
02d6ed84: mov     x0, x19                                    
02d6ed88: mov     x2, xzr                                    
02d6ed8c: bl      #0x5c45aa0                                 UnityEngine.UI.Image::set_sprite
02d6ed90: adrp    x8, #0x6267000                             
02d6ed94: ldr     x8, [x8, #0xd20]                           MS:MonoSingleton`1::get_Instance
02d6ed98: ldr     x0, [x8]                                   S:'didu'
02d6ed9c: bl      #0x3769600                                 fn_3769600
02d6eda0: cbz     x0, #0x2d6eec4                             
02d6eda4: adrp    x19, #0x626b000                            
02d6eda8: mov     x1, xzr                                    
02d6edac: ldr     x19, [x19, #0xee0]                         MS:MonoSingleton`1::get_Instance
02d6edb0: bl      #0x2cf4100                                 Profile.ProfileManager::ObtainExperiencePoint
02d6edb4: ldr     x0, [x19]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d6edb8: bl      #0x3769600                                 fn_3769600
02d6edbc: cbz     x0, #0x2d6eec4                             
02d6edc0: adrp    x23, #0x6266000                            
02d6edc4: mov     x1, xzr                                    
02d6edc8: ldr     x23, [x23, #0xb48]                         MS:MonoSingleton`1::get_Instance
02d6edcc: bl      #0x2d6dc34                                 Clicker.KeycapMakerController::TrySaveKeycapToDatabase
02d6edd0: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6edd4: bl      #0x3769600                                 fn_3769600
02d6edd8: cbz     x0, #0x2d6eec4                             
02d6eddc: ldr     x19, [x0, #0x30]                           T:type8556(k15)
02d6ede0: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6ede4: bl      #0x3769600                                 fn_3769600
02d6ede8: cbz     x0, #0x2d6eec4                             
02d6edec: adrp    x24, #0x6265000                            
02d6edf0: mov     x8, x0                                     
02d6edf4: ldr     x24, [x24, #0xb38]                         T:DevTrack
02d6edf8: ldr     w20, [x8, #0x3c]                           [626703c]=0 f=0,0
02d6edfc: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d6ee00: ldr     w9, [x0, #0xe4]                            [62640e4]=0 f=0,0
02d6ee04: cbnz    w9, #0x2d6ee10                             
02d6ee08: bl      #0x2b70f30                                 fn_2b70f30
02d6ee0c: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d6ee10: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d6ee14: mov     x0, xzr                                    
02d6ee18: ldr     x21, [x8, #0x258]                          MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d6ee1c: ldr     w22, [x8, #0x290]                          MS:System.Collections.Generic.List`1::Add
02d6ee20: bl      #0x5b432fc                                 UnityEngine.Time::get_time
02d6ee24: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6ee28: fmov    s8, s0                                     
02d6ee2c: bl      #0x3769600                                 fn_3769600
02d6ee30: cbz     x0, #0x2d6eec4                             
02d6ee34: ldr     s0, [x0, #0x38]                            M:UnityEngine.Rigidbody::MovePosition ._btnAdReward
02d6ee38: mov     x0, x19                                    
02d6ee3c: mov     w1, w20                                    
02d6ee40: mov     x2, x21                                    
02d6ee44: mov     w3, w22                                    
02d6ee48: mov     x4, xzr                                    
02d6ee4c: fsub    s0, s8, s0                                 
02d6ee50: bl      #0x2c9c898                                 DevTrack::GameModeStepComplete
02d6ee54: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6ee58: bl      #0x3769600                                 fn_3769600
02d6ee5c: cbz     x0, #0x2d6eec4                             
02d6ee60: ldr     x19, [x0, #0x30]                           T:type8556(k15)
02d6ee64: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6ee68: bl      #0x3769600                                 fn_3769600
02d6ee6c: cbz     x0, #0x2d6eec4                             
02d6ee70: ldr     x8, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d6ee74: ldr     w1, [x0, #0x3c]                            [626403c]=0 f=0,0
02d6ee78: mov     x0, x19                                    
02d6ee7c: mov     x4, xzr                                    
02d6ee80: ldr     x8, [x8, #0xb8]                            M:Framework.SceneUtils/<CRUnloadSceneAsync>d__2::System.Collections.IEnumerator.Reset
02d6ee84: ldr     x2, [x8, #0x260]                           MS:System.Collections.Generic.List`1/Enumerator::get_Current
02d6ee88: ldr     w3, [x8, #0x294]                           [6267294]=0 f=0,0
02d6ee8c: bl      #0x2c9c714                                 DevTrack::GameModeStepEnter
02d6ee90: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6ee94: bl      #0x3769600                                 fn_3769600
02d6ee98: cbz     x0, #0x2d6eec4                             
02d6ee9c: ldr     x8, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d6eea0: ldp     x20, x19, [sp, #0x30]                      
02d6eea4: ldp     x22, x21, [sp, #0x20]                      
02d6eea8: ldr     x30, [sp, #8]                              
02d6eeac: ldr     x8, [x8, #0xb8]                            M:Framework.SceneUtils/<CRUnloadSceneAsync>d__2::System.Collections.IEnumerator.Reset
02d6eeb0: ldp     x24, x23, [sp, #0x10]                      
02d6eeb4: ldr     x1, [x8, #0x260]                           MS:System.Collections.Generic.List`1/Enumerator::get_Current
02d6eeb8: str     x1, [x0, #0x40]!                           ._btnReward
02d6eebc: ldr     d8, [sp], #0x40                            
02d6eec0: b       #0x2b70d54                                 
02d6eec4: bl      #0x2b7105c                                 fn_2b7105c
## OnHide() -> void
---- Clicker.PopupClickerComplete::OnHide 0x2d6f150
02d6f150: stp     x30, x19, [sp, #-0x10]!                    
02d6f154: mov     x1, xzr                                    
02d6f158: mov     x19, x0                                    
02d6f15c: bl      #0x2cddc10                                 UIBase::OnHide
02d6f160: ldr     x0, [x19, #0x70]                           ._fxConfetti
02d6f164: cbz     x0, #0x2d6f194                             
02d6f168: mov     x1, xzr                                    
02d6f16c: bl      #0x4f871ec                                 AssetKits.ParticleImage.ParticleImage::Stop
02d6f170: ldr     x0, [x19, #0x70]                           ._fxConfetti
02d6f174: cbz     x0, #0x2d6f194                             
02d6f178: mov     x1, xzr                                    
02d6f17c: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d6f180: cbz     x0, #0x2d6f194                             
02d6f184: mov     w1, wzr                                    
02d6f188: mov     x2, xzr                                    
02d6f18c: ldp     x30, x19, [sp], #0x10                      
02d6f190: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d6f194: bl      #0x2b7105c                                 fn_2b7105c
## OnBtnRewardClick() -> void
---- Clicker.PopupClickerComplete::OnBtnRewardClick 0x2d6f198
02d6f198: str     x30, [sp, #-0x40]!                         
02d6f19c: stp     x24, x23, [sp, #0x10]                      
02d6f1a0: stp     x22, x21, [sp, #0x20]                      
02d6f1a4: stp     x20, x19, [sp, #0x30]                      
02d6f1a8: adrp    x20, #0x6630000                            
02d6f1ac: mov     x19, x0                                    
02d6f1b0: ldrb    w8, [x20, #0x392]                          
02d6f1b4: tbnz    w8, #0, #0x2d6f208                         
02d6f1b8: adrp    x0, #0x6264000                             
02d6f1bc: ldr     x0, [x0, #0xf90]                           T:System.Action
02d6f1c0: bl      #0x2b70db0                                 fn_2b70db0
02d6f1c4: adrp    x0, #0x6266000                             
02d6f1c8: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d6f1cc: bl      #0x2b70db0                                 fn_2b70db0
02d6f1d0: adrp    x0, #0x6266000                             
02d6f1d4: ldr     x0, [x0, #0xaa0]                           MS:MonoSingleton`1::get_Instance
02d6f1d8: bl      #0x2b70db0                                 fn_2b70db0
02d6f1dc: adrp    x0, #0x6266000                             
02d6f1e0: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d6f1e4: bl      #0x2b70db0                                 fn_2b70db0
02d6f1e8: adrp    x0, #0x626c000                             
02d6f1ec: ldr     x0, [x0, #0x4f8]                           M:Clicker.PopupClickerComplete/<>c::<OnBtnRewardClick>b__18_0
02d6f1f0: bl      #0x2b70db0                                 fn_2b70db0
02d6f1f4: adrp    x0, #0x626c000                             
02d6f1f8: ldr     x0, [x0, #0x500]                           T:Clicker.PopupClickerComplete/<>c
02d6f1fc: bl      #0x2b70db0                                 fn_2b70db0
02d6f200: mov     w8, #1                                     
02d6f204: strb    w8, [x20, #0x392]                          
02d6f208: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d6f20c: cbz     x0, #0x2d6f378                             
02d6f210: movi    d1, #0000000000000000                      
02d6f214: movi    d2, #0000000000000000                      
02d6f218: mov     w1, #1                                     
02d6f21c: fmov    s0, #1.00000000                            
02d6f220: mov     w2, wzr                                    
02d6f224: mov     w3, wzr                                    
02d6f228: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d6f22c: ldr     x0, [x19, #0x38]                           ._btnAdReward
02d6f230: cbz     x0, #0x2d6f378                             
02d6f234: mov     w1, wzr                                    
02d6f238: mov     x2, xzr                                    
02d6f23c: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d6f240: ldr     x0, [x19, #0x40]                           ._btnReward
02d6f244: cbz     x0, #0x2d6f378                             
02d6f248: adrp    x20, #0x6266000                            
02d6f24c: mov     w1, wzr                                    
02d6f250: mov     x2, xzr                                    
02d6f254: ldr     x20, [x20, #0x658]                         MS:MonoSingleton`1::get_Instance
02d6f258: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d6f25c: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6f260: bl      #0x3769600                                 fn_3769600
02d6f264: cbz     x0, #0x2d6f378                             
02d6f268: adrp    x8, #0x6266000                             
02d6f26c: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02d6f270: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6f274: bl      #0x3168dd0                                 fn_3168dd0
02d6f278: cbz     x0, #0x2d6f378                             
02d6f27c: ldr     x8, [x0, #0x20]                            M:Clicker.GlowSprite2DItem::<DoGlow>b__10_6
02d6f280: cbz     x8, #0x2d6f378                             
02d6f284: ldr     w9, [x8, #0x3c]                            [626603c]=0 f=0,0
02d6f288: adrp    x20, #0x6266000                            
02d6f28c: adrp    x22, #0x626c000                            
02d6f290: add     w10, w9, #1                                
02d6f294: cmp     w10, #4                                    
02d6f298: mov     w10, #4                                    
02d6f29c: csinc   w9, w10, w9, ge                            
02d6f2a0: str     w9, [x8, #0x3c]                            
02d6f2a4: ldr     x20, [x20, #0xaa0]                         MS:MonoSingleton`1::get_Instance
02d6f2a8: ldr     x8, [x0]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6f2ac: ldr     x22, [x22, #0x500]                         T:Clicker.PopupClickerComplete/<>c
02d6f2b0: ldr     x9, [x8, #0x258]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d6f2b4: ldr     x1, [x8, #0x260]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d6f2b8: blr     x9                                         
02d6f2bc: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6f2c0: bl      #0x3769600                                 fn_3769600
02d6f2c4: ldr     x8, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6f2c8: ldp     w23, w24, [x19, #0xa0]                     ._moneyReward
02d6f2cc: ldr     w9, [x8, #0xe4]                            [62660e4]=0 f=0,0
02d6f2d0: mov     x19, x0                                    
02d6f2d4: cbnz    w9, #0x2d6f2e4                             
02d6f2d8: mov     x0, x8                                     
02d6f2dc: bl      #0x2b70f30                                 fn_2b70f30
02d6f2e0: ldr     x8, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6f2e4: ldr     x9, [x8, #0xb8]                            S:'banner_native_refresh_time'
02d6f2e8: ldr     x20, [x9, #0x10]                           
02d6f2ec: cbnz    x20, #0x2d6f34c                            
02d6f2f0: ldr     w10, [x8, #0xe4]                           [62660e4]=0 f=0,0
02d6f2f4: cbnz    w10, #0x2d6f308                            
02d6f2f8: mov     x0, x8                                     
02d6f2fc: bl      #0x2b70f30                                 fn_2b70f30
02d6f300: ldr     x8, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6f304: ldr     x9, [x8, #0xb8]                            S:'banner_native_refresh_time'
02d6f308: adrp    x8, #0x6264000                             
02d6f30c: ldr     x8, [x8, #0xf90]                           T:System.Action
02d6f310: ldr     x21, [x9]                                  
02d6f314: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d6f318: bl      #0x2b7104c                                 fn_2b7104c
02d6f31c: adrp    x8, #0x626c000                             
02d6f320: mov     x1, x21                                    
02d6f324: mov     x3, xzr                                    
02d6f328: ldr     x8, [x8, #0x4f8]                           M:Clicker.PopupClickerComplete/<>c::<OnBtnRewardClick>b__18_0
02d6f32c: mov     x20, x0                                    
02d6f330: ldr     x2, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6f334: bl      #0x4d8ddbc                                 System.Action::.ctor
02d6f338: ldr     x8, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6f33c: mov     x1, x20                                    
02d6f340: ldr     x0, [x8, #0xb8]                            MS:System.Collections.Generic.List`1::Add
02d6f344: str     x20, [x0, #0x10]!                          
02d6f348: bl      #0x2b70d54                                 fn_2b70d54
02d6f34c: cbz     x19, #0x2d6f378                            
02d6f350: add     w1, w24, w23                               
02d6f354: mov     x0, x19                                    
02d6f358: mov     x3, x20                                    
02d6f35c: ldp     x20, x19, [sp, #0x30]                      
02d6f360: mov     w2, #0xa                                   
02d6f364: ldp     x22, x21, [sp, #0x20]                      
02d6f368: mov     x4, xzr                                    
02d6f36c: ldp     x24, x23, [sp, #0x10]                      
02d6f370: ldr     x30, [sp], #0x40                           
02d6f374: b       #0x2cdaf30                                 MoneyManager::CollectMoney
02d6f378: bl      #0x2b7105c                                 fn_2b7105c
## OnBtnAdRewardClick() -> void
---- Clicker.PopupClickerComplete::OnBtnAdRewardClick 0x2d6f37c
02d6f37c: str     x30, [sp, #-0x30]!                         
02d6f380: stp     x22, x21, [sp, #0x10]                      
02d6f384: stp     x20, x19, [sp, #0x20]                      
02d6f388: adrp    x20, #0x6630000                            
02d6f38c: mov     x19, x0                                    
02d6f390: ldrb    w8, [x20, #0x393]                          
02d6f394: tbnz    w8, #0, #0x2d6f3d0                         
02d6f398: adrp    x0, #0x6264000                             
02d6f39c: ldr     x0, [x0, #0xf90]                           T:System.Action
02d6f3a0: bl      #0x2b70db0                                 fn_2b70db0
02d6f3a4: adrp    x0, #0x626c000                             
02d6f3a8: ldr     x0, [x0, #0x508]                           M:Clicker.PopupClickerComplete::<OnBtnAdRewardClick>b__19_0
02d6f3ac: bl      #0x2b70db0                                 fn_2b70db0
02d6f3b0: adrp    x0, #0x6265000                             
02d6f3b4: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02d6f3b8: bl      #0x2b70db0                                 fn_2b70db0
02d6f3bc: adrp    x0, #0x626a000                             
02d6f3c0: ldr     x0, [x0, #0xcb0]                           S:'x2_reward'
02d6f3c4: bl      #0x2b70db0                                 fn_2b70db0
02d6f3c8: mov     w8, #1                                     
02d6f3cc: strb    w8, [x20, #0x393]                          
02d6f3d0: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d6f3d4: cbz     x0, #0x2d6f464                             
02d6f3d8: movi    d1, #0000000000000000                      
02d6f3dc: movi    d2, #0000000000000000                      
02d6f3e0: adrp    x20, #0x6265000                            
02d6f3e4: fmov    s0, #1.00000000                            
02d6f3e8: adrp    x21, #0x6264000                            
02d6f3ec: adrp    x22, #0x626c000                            
02d6f3f0: ldr     x20, [x20, #0x310]                         MS:WejoyService.Singleton`1::get_Instance
02d6f3f4: ldr     x21, [x21, #0xf90]                         T:System.Action
02d6f3f8: ldr     x22, [x22, #0x508]                         M:Clicker.PopupClickerComplete::<OnBtnAdRewardClick>b__19_0
02d6f3fc: mov     w1, #1                                     
02d6f400: mov     w2, wzr                                    
02d6f404: mov     w3, wzr                                    
02d6f408: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d6f40c: ldr     x0, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d6f410: bl      #0x3be7218                                 fn_3be7218
02d6f414: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d6f418: mov     x20, x0                                    
02d6f41c: mov     x0, x8                                     
02d6f420: bl      #0x2b7104c                                 fn_2b7104c
02d6f424: ldr     x2, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6f428: mov     x1, x19                                    
02d6f42c: mov     x3, xzr                                    
02d6f430: mov     x21, x0                                    
02d6f434: bl      #0x4d8ddbc                                 System.Action::.ctor
02d6f438: cbz     x20, #0x2d6f464                            
02d6f43c: adrp    x8, #0x626a000                             
02d6f440: mov     x0, x20                                    
02d6f444: mov     x2, x21                                    
02d6f448: ldr     x8, [x8, #0xcb0]                           S:'x2_reward'
02d6f44c: ldp     x20, x19, [sp, #0x20]                      
02d6f450: ldp     x22, x21, [sp, #0x10]                      
02d6f454: mov     x3, xzr                                    
02d6f458: ldr     x1, [x8]                                   T:type56879(k15)
02d6f45c: ldr     x30, [sp], #0x30                           
02d6f460: b       #0x2c8a2c0                                 AdsManager::ShowRewarded
02d6f464: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Clicker.PopupClickerComplete::.ctor 0x2d6f468
02d6f468: adrp    x8, #0x1041000                             
02d6f46c: mov     x1, xzr                                    
02d6f470: ldr     d0, [x8, #0x18]                            [1041018]=64000001f4 f=7.00649e-43,1.4013e-43
02d6f474: str     d0, [x0, #0xa0]                            ._moneyReward
02d6f478: b       #0x2cddba8                                 PopupBase::.ctor
## <OnBtnAdRewardClick>b__19_0() -> void
---- Clicker.PopupClickerComplete::<OnBtnAdRewardClick>b__19_0 0x2d6f47c
02d6f47c: str     x30, [sp, #-0x40]!                         
02d6f480: stp     x24, x23, [sp, #0x10]                      
02d6f484: stp     x22, x21, [sp, #0x20]                      
02d6f488: stp     x20, x19, [sp, #0x30]                      
02d6f48c: adrp    x20, #0x6630000                            
02d6f490: mov     x19, x0                                    
02d6f494: ldrb    w8, [x20, #0x394]                          
02d6f498: tbnz    w8, #0, #0x2d6f4d4                         
02d6f49c: adrp    x0, #0x6264000                             
02d6f4a0: ldr     x0, [x0, #0xf90]                           T:System.Action
02d6f4a4: bl      #0x2b70db0                                 fn_2b70db0
02d6f4a8: adrp    x0, #0x6266000                             
02d6f4ac: ldr     x0, [x0, #0xaa0]                           MS:MonoSingleton`1::get_Instance
02d6f4b0: bl      #0x2b70db0                                 fn_2b70db0
02d6f4b4: adrp    x0, #0x626c000                             
02d6f4b8: ldr     x0, [x0, #0x510]                           M:Clicker.PopupClickerComplete/<>c::<OnBtnAdRewardClick>b__19_1
02d6f4bc: bl      #0x2b70db0                                 fn_2b70db0
02d6f4c0: adrp    x0, #0x626c000                             
02d6f4c4: ldr     x0, [x0, #0x500]                           T:Clicker.PopupClickerComplete/<>c
02d6f4c8: bl      #0x2b70db0                                 fn_2b70db0
02d6f4cc: mov     w8, #1                                     
02d6f4d0: strb    w8, [x20, #0x394]                          
02d6f4d4: ldr     x0, [x19, #0x38]                           ._btnAdReward
02d6f4d8: cbz     x0, #0x2d6f5cc                             
02d6f4dc: mov     w1, wzr                                    
02d6f4e0: mov     x2, xzr                                    
02d6f4e4: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d6f4e8: ldr     x0, [x19, #0x40]                           ._btnReward
02d6f4ec: cbz     x0, #0x2d6f5cc                             
02d6f4f0: adrp    x20, #0x6266000                            
02d6f4f4: adrp    x22, #0x626c000                            
02d6f4f8: mov     w1, wzr                                    
02d6f4fc: ldr     x20, [x20, #0xaa0]                         MS:MonoSingleton`1::get_Instance
02d6f500: ldr     x22, [x22, #0x500]                         T:Clicker.PopupClickerComplete/<>c
02d6f504: mov     x2, xzr                                    
02d6f508: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d6f50c: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6f510: bl      #0x3769600                                 fn_3769600
02d6f514: ldr     x8, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6f518: ldp     w23, w24, [x19, #0xa0]                     ._moneyReward
02d6f51c: ldr     w9, [x8, #0xe4]                            
02d6f520: mov     x19, x0                                    
02d6f524: cbnz    w9, #0x2d6f534                             
02d6f528: mov     x0, x8                                     
02d6f52c: bl      #0x2b70f30                                 fn_2b70f30
02d6f530: ldr     x8, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6f534: ldr     x9, [x8, #0xb8]                            
02d6f538: ldr     x20, [x9, #0x18]                           
02d6f53c: cbnz    x20, #0x2d6f59c                            
02d6f540: ldr     w10, [x8, #0xe4]                           
02d6f544: cbnz    w10, #0x2d6f558                            
02d6f548: mov     x0, x8                                     
02d6f54c: bl      #0x2b70f30                                 fn_2b70f30
02d6f550: ldr     x8, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6f554: ldr     x9, [x8, #0xb8]                            
02d6f558: adrp    x8, #0x6264000                             
02d6f55c: ldr     x8, [x8, #0xf90]                           T:System.Action
02d6f560: ldr     x21, [x9]                                  
02d6f564: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d6f568: bl      #0x2b7104c                                 fn_2b7104c
02d6f56c: adrp    x8, #0x626c000                             
02d6f570: mov     x1, x21                                    
02d6f574: mov     x3, xzr                                    
02d6f578: ldr     x8, [x8, #0x510]                           M:Clicker.PopupClickerComplete/<>c::<OnBtnAdRewardClick>b__19_1
02d6f57c: mov     x20, x0                                    
02d6f580: ldr     x2, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6f584: bl      #0x4d8ddbc                                 System.Action::.ctor
02d6f588: ldr     x8, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6f58c: mov     x1, x20                                    
02d6f590: ldr     x0, [x8, #0xb8]                            MS:System.Collections.Generic.List`1::Add
02d6f594: str     x20, [x0, #0x18]!                          
02d6f598: bl      #0x2b70d54                                 fn_2b70d54
02d6f59c: cbz     x19, #0x2d6f5cc                            
02d6f5a0: add     w8, w24, w23                               
02d6f5a4: mov     x0, x19                                    
02d6f5a8: mov     x3, x20                                    
02d6f5ac: ldp     x20, x19, [sp, #0x30]                      
02d6f5b0: lsl     w1, w8, #1                                 
02d6f5b4: ldp     x22, x21, [sp, #0x20]                      
02d6f5b8: mov     w2, #0xa                                   
02d6f5bc: ldp     x24, x23, [sp, #0x10]                      
02d6f5c0: mov     x4, xzr                                    
02d6f5c4: ldr     x30, [sp], #0x40                           
02d6f5c8: b       #0x2cdaf30                                 MoneyManager::CollectMoney
02d6f5cc: bl      #0x2b7105c                                 fn_2b7105c
