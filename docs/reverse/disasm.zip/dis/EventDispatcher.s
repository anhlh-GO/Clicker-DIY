#### CLASS EventDispatcher parent= UnityEngine.MonoBehaviour
#   field s_instance                     EventDispatcher                                    off=0x0 attr=11 
#   field _listeners                     System.Collections.Generic.Dictionary`2<EventID,System.Action`1<object>> off=0x20 attr=1 
## get_Instance() -> EventDispatcher
---- EventDispatcher::get_Instance 0x2cdba74
02cdba74: stp     x30, x21, [sp, #-0x20]!                    
02cdba78: stp     x20, x19, [sp, #0x10]                      
02cdba7c: adrp    x21, #0x662f000                            
02cdba80: adrp    x20, #0x6267000                            
02cdba84: adrp    x19, #0x6263000                            
02cdba88: ldrb    w8, [x21, #0xd67]                          
02cdba8c: ldr     x20, [x20, #0xc28]                         T:EventDispatcher
02cdba90: ldr     x19, [x19, #0x918]                         T:UnityEngine.Object
02cdba94: tbnz    w8, #0, #0x2cdbadc                         
02cdba98: adrp    x0, #0x6267000                             
02cdba9c: ldr     x0, [x0, #0xc28]                           T:EventDispatcher
02cdbaa0: bl      #0x2b70db0                                 fn_2b70db0
02cdbaa4: adrp    x0, #0x6267000                             
02cdbaa8: ldr     x0, [x0, #0xc30]                           MS:UnityEngine.GameObject::AddComponent
02cdbaac: bl      #0x2b70db0                                 fn_2b70db0
02cdbab0: adrp    x0, #0x6263000                             
02cdbab4: ldr     x0, [x0, #0xf58]                           T:UnityEngine.GameObject
02cdbab8: bl      #0x2b70db0                                 fn_2b70db0
02cdbabc: adrp    x0, #0x6263000                             
02cdbac0: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02cdbac4: bl      #0x2b70db0                                 fn_2b70db0
02cdbac8: adrp    x0, #0x6267000                             
02cdbacc: ldr     x0, [x0, #0xc38]                           S:'Singleton - EventDispatcher'
02cdbad0: bl      #0x2b70db0                                 fn_2b70db0
02cdbad4: mov     w8, #1                                     
02cdbad8: strb    w8, [x21, #0xd67]                          
02cdbadc: ldr     x8, [x20]                                  S:'didu'
02cdbae0: ldr     x0, [x19]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cdbae4: ldr     x8, [x8, #0xb8]                            
02cdbae8: ldr     w9, [x0, #0xe4]                            [62670e4]=0 f=0,0
02cdbaec: ldr     x19, [x8]                                  
02cdbaf0: cbnz    w9, #0x2cdbaf8                             
02cdbaf4: bl      #0x2b70f30                                 fn_2b70f30
02cdbaf8: mov     x0, x19                                    
02cdbafc: mov     x1, xzr                                    
02cdbb00: mov     x2, xzr                                    
02cdbb04: bl      #0x5b37d84                                 UnityEngine.Object::op_Equality
02cdbb08: tbz     w0, #0, #0x2cdbb74                         
02cdbb0c: adrp    x8, #0x6263000                             
02cdbb10: ldr     x8, [x8, #0xf58]                           T:UnityEngine.GameObject
02cdbb14: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02cdbb18: bl      #0x2b7104c                                 fn_2b7104c
02cdbb1c: mov     x1, xzr                                    
02cdbb20: mov     x19, x0                                    
02cdbb24: bl      #0x5b3736c                                 UnityEngine.GameObject::.ctor
02cdbb28: cbz     x19, #0x2cdbb8c                            
02cdbb2c: adrp    x8, #0x6267000                             
02cdbb30: mov     x0, x19                                    
02cdbb34: ldr     x8, [x8, #0xc30]                           MS:UnityEngine.GameObject::AddComponent
02cdbb38: ldr     x1, [x8]                                   S:'didu'
02cdbb3c: bl      #0x31d1114                                 fn_31d1114
02cdbb40: ldr     x8, [x20]                                  S:'didu'
02cdbb44: mov     x1, x0                                     
02cdbb48: ldr     x8, [x8, #0xb8]                            M:Framework.SceneUtils/<CRUnloadSceneAsync>d__2::System.Collections.IEnumerator.Reset
02cdbb4c: str     x0, [x8]                                   
02cdbb50: ldr     x8, [x20]                                  S:'didu'
02cdbb54: ldr     x0, [x8, #0xb8]                            M:Framework.SceneUtils/<CRUnloadSceneAsync>d__2::System.Collections.IEnumerator.Reset
02cdbb58: bl      #0x2b70d54                                 fn_2b70d54
02cdbb5c: adrp    x8, #0x6267000                             
02cdbb60: mov     x0, x19                                    
02cdbb64: mov     x2, xzr                                    
02cdbb68: ldr     x8, [x8, #0xc38]                           S:'Singleton - EventDispatcher'
02cdbb6c: ldr     x1, [x8]                                   S:'didu'
02cdbb70: bl      #0x5b3bcf8                                 UnityEngine.Object::set_name
02cdbb74: ldr     x8, [x20]                                  S:'didu'
02cdbb78: ldp     x20, x19, [sp, #0x10]                      
02cdbb7c: ldr     x8, [x8, #0xb8]                            M:Framework.SceneUtils/<CRUnloadSceneAsync>d__2::System.Collections.IEnumerator.Reset
02cdbb80: ldr     x0, [x8]                                   S:'didu'
02cdbb84: ldp     x30, x21, [sp], #0x20                      
02cdbb88: ret                                                
02cdbb8c: bl      #0x2b7105c                                 fn_2b7105c
## set_Instance(EventDispatcher value) -> void
---- EventDispatcher::set_Instance 0x2cdbb90
02cdbb90: ret                                                
## HasInstance() -> bool
---- EventDispatcher::HasInstance 0x2cdbb94
02cdbb94: stp     x30, x21, [sp, #-0x20]!                    
02cdbb98: stp     x20, x19, [sp, #0x10]                      
02cdbb9c: adrp    x20, #0x662f000                            
02cdbba0: adrp    x21, #0x6267000                            
02cdbba4: adrp    x19, #0x6263000                            
02cdbba8: ldrb    w8, [x20, #0xd68]                          
02cdbbac: ldr     x21, [x21, #0xc28]                         T:EventDispatcher
02cdbbb0: ldr     x19, [x19, #0x918]                         T:UnityEngine.Object
02cdbbb4: tbnz    w8, #0, #0x2cdbbd8                         
02cdbbb8: adrp    x0, #0x6267000                             
02cdbbbc: ldr     x0, [x0, #0xc28]                           T:EventDispatcher
02cdbbc0: bl      #0x2b70db0                                 fn_2b70db0
02cdbbc4: adrp    x0, #0x6263000                             
02cdbbc8: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02cdbbcc: bl      #0x2b70db0                                 fn_2b70db0
02cdbbd0: mov     w8, #1                                     
02cdbbd4: strb    w8, [x20, #0xd68]                          
02cdbbd8: ldr     x8, [x21]                                  S:'didu'
02cdbbdc: ldr     x0, [x19]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cdbbe0: ldr     x8, [x8, #0xb8]                            
02cdbbe4: ldr     w9, [x0, #0xe4]                            [62630e4]=0 f=0,0
02cdbbe8: ldr     x19, [x8]                                  
02cdbbec: cbnz    w9, #0x2cdbbf4                             
02cdbbf0: bl      #0x2b70f30                                 fn_2b70f30
02cdbbf4: mov     x0, x19                                    
02cdbbf8: ldp     x20, x19, [sp, #0x10]                      
02cdbbfc: mov     x1, xzr                                    
02cdbc00: mov     x2, xzr                                    
02cdbc04: ldp     x30, x21, [sp], #0x20                      
02cdbc08: b       #0x5b3666c                                 UnityEngine.Object::op_Inequality
## Awake() -> void
---- EventDispatcher::Awake 0x2cdbc0c
02cdbc0c: str     x30, [sp, #-0x30]!                         
02cdbc10: stp     x22, x21, [sp, #0x10]                      
02cdbc14: stp     x20, x19, [sp, #0x20]                      
02cdbc18: adrp    x20, #0x662f000                            
02cdbc1c: adrp    x22, #0x6267000                            
02cdbc20: adrp    x21, #0x6263000                            
02cdbc24: ldrb    w8, [x20, #0xd69]                          
02cdbc28: ldr     x22, [x22, #0xc28]                         T:EventDispatcher
02cdbc2c: ldr     x21, [x21, #0x918]                         T:UnityEngine.Object
02cdbc30: mov     x19, x0                                    
02cdbc34: tbnz    w8, #0, #0x2cdbc58                         
02cdbc38: adrp    x0, #0x6267000                             
02cdbc3c: ldr     x0, [x0, #0xc28]                           T:EventDispatcher
02cdbc40: bl      #0x2b70db0                                 fn_2b70db0
02cdbc44: adrp    x0, #0x6263000                             
02cdbc48: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02cdbc4c: bl      #0x2b70db0                                 fn_2b70db0
02cdbc50: mov     w8, #1                                     
02cdbc54: strb    w8, [x20, #0xd69]                          
02cdbc58: ldr     x8, [x22]                                  S:'didu'
02cdbc5c: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cdbc60: ldr     x8, [x8, #0xb8]                            
02cdbc64: ldr     w9, [x0, #0xe4]                            [62630e4]=0 f=0,0
02cdbc68: ldr     x20, [x8]                                  
02cdbc6c: cbnz    w9, #0x2cdbc74                             
02cdbc70: bl      #0x2b70f30                                 fn_2b70f30
02cdbc74: mov     x0, x20                                    
02cdbc78: mov     x1, xzr                                    
02cdbc7c: mov     x2, xzr                                    
02cdbc80: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02cdbc84: tbz     w0, #0, #0x2cdbcb8                         
02cdbc88: ldr     x8, [x22]                                  S:'didu'
02cdbc8c: ldr     x8, [x8, #0xb8]                            
02cdbc90: ldr     x0, [x8]                                   
02cdbc94: cbz     x0, #0x2cdbd1c                             
02cdbc98: mov     x1, xzr                                    
02cdbc9c: bl      #0x5b3b8f8                                 UnityEngine.Object::GetInstanceID
02cdbca0: mov     w20, w0                                    
02cdbca4: mov     x0, x19                                    
02cdbca8: mov     x1, xzr                                    
02cdbcac: bl      #0x5b3b8f8                                 UnityEngine.Object::GetInstanceID
02cdbcb0: cmp     w20, w0                                    
02cdbcb4: b.ne    #0x2cdbce0                                 
02cdbcb8: ldr     x8, [x22]                                  S:'didu'
02cdbcbc: mov     x1, x19                                    
02cdbcc0: ldr     x8, [x8, #0xb8]                            
02cdbcc4: str     x19, [x8]                                  
02cdbcc8: ldp     x20, x19, [sp, #0x20]                      
02cdbccc: ldr     x8, [x22]                                  S:'didu'
02cdbcd0: ldp     x22, x21, [sp, #0x10]                      
02cdbcd4: ldr     x0, [x8, #0xb8]                            
02cdbcd8: ldr     x30, [sp], #0x30                           
02cdbcdc: b       #0x2b70d54                                 
02cdbce0: mov     x0, x19                                    
02cdbce4: mov     x1, xzr                                    
02cdbce8: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02cdbcec: ldr     x8, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cdbcf0: mov     x19, x0                                    
02cdbcf4: ldr     w9, [x8, #0xe4]                            
02cdbcf8: cbnz    w9, #0x2cdbd04                             
02cdbcfc: mov     x0, x8                                     
02cdbd00: bl      #0x2b70f30                                 fn_2b70f30
02cdbd04: mov     x0, x19                                    
02cdbd08: ldp     x20, x19, [sp, #0x20]                      
02cdbd0c: ldp     x22, x21, [sp, #0x10]                      
02cdbd10: mov     x1, xzr                                    
02cdbd14: ldr     x30, [sp], #0x30                           
02cdbd18: b       #0x5b3ca38                                 UnityEngine.Object::Destroy
02cdbd1c: bl      #0x2b7105c                                 fn_2b7105c
## OnDestroy() -> void
---- EventDispatcher::OnDestroy 0x2cdbd20
02cdbd20: str     x30, [sp, #-0x30]!                         
02cdbd24: stp     x22, x21, [sp, #0x10]                      
02cdbd28: stp     x20, x19, [sp, #0x20]                      
02cdbd2c: adrp    x22, #0x662f000                            
02cdbd30: adrp    x21, #0x6267000                            
02cdbd34: adrp    x20, #0x6263000                            
02cdbd38: ldrb    w8, [x22, #0xd6a]                          
02cdbd3c: ldr     x21, [x21, #0xc28]                         T:EventDispatcher
02cdbd40: ldr     x20, [x20, #0x918]                         T:UnityEngine.Object
02cdbd44: mov     x19, x0                                    
02cdbd48: tbnz    w8, #0, #0x2cdbd6c                         
02cdbd4c: adrp    x0, #0x6267000                             
02cdbd50: ldr     x0, [x0, #0xc28]                           T:EventDispatcher
02cdbd54: bl      #0x2b70db0                                 fn_2b70db0
02cdbd58: adrp    x0, #0x6263000                             
02cdbd5c: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02cdbd60: bl      #0x2b70db0                                 fn_2b70db0
02cdbd64: mov     w8, #1                                     
02cdbd68: strb    w8, [x22, #0xd6a]                          
02cdbd6c: ldr     x8, [x21]                                  S:'didu'
02cdbd70: ldr     x0, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cdbd74: ldr     x8, [x8, #0xb8]                            
02cdbd78: ldr     w9, [x0, #0xe4]                            [62630e4]=0 f=0,0
02cdbd7c: ldr     x20, [x8]                                  
02cdbd80: cbnz    w9, #0x2cdbd88                             
02cdbd84: bl      #0x2b70f30                                 fn_2b70f30
02cdbd88: mov     x0, x20                                    
02cdbd8c: mov     x1, x19                                    
02cdbd90: mov     x2, xzr                                    
02cdbd94: bl      #0x5b37d84                                 UnityEngine.Object::op_Equality
02cdbd98: tbz     w0, #0, #0x2cdbdcc                         
02cdbd9c: mov     x0, x19                                    
02cdbda0: bl      #0x2cdbddc                                 EventDispatcher::ClearAllListener
02cdbda4: ldr     x8, [x21]                                  S:'didu'
02cdbda8: ldp     x20, x19, [sp, #0x20]                      
02cdbdac: mov     x1, xzr                                    
02cdbdb0: ldr     x8, [x8, #0xb8]                            
02cdbdb4: str     xzr, [x8]                                  
02cdbdb8: ldr     x8, [x21]                                  S:'didu'
02cdbdbc: ldp     x22, x21, [sp, #0x10]                      
02cdbdc0: ldr     x0, [x8, #0xb8]                            
02cdbdc4: ldr     x30, [sp], #0x30                           
02cdbdc8: b       #0x2b70d54                                 
02cdbdcc: ldp     x20, x19, [sp, #0x20]                      
02cdbdd0: ldp     x22, x21, [sp, #0x10]                      
02cdbdd4: ldr     x30, [sp], #0x30                           
02cdbdd8: ret                                                
## RegisterListener(EventID eventID, System.Action`1<object> callback) -> void
---- EventDispatcher::RegisterListener 0x2cdbe2c
02cdbe2c: str     x30, [sp, #-0x30]!                         
02cdbe30: stp     x22, x21, [sp, #0x10]                      
02cdbe34: stp     x20, x19, [sp, #0x20]                      
02cdbe38: adrp    x22, #0x662f000                            
02cdbe3c: mov     x20, x2                                    
02cdbe40: mov     w19, w1                                    
02cdbe44: ldrb    w8, [x22, #0xd6b]                          
02cdbe48: mov     x21, x0                                    
02cdbe4c: tbnz    w8, #0, #0x2cdbe94                         
02cdbe50: adrp    x0, #0x6267000                             
02cdbe54: ldr     x0, [x0, #0xc48]                           T:type6961(k15)
02cdbe58: bl      #0x2b70db0                                 fn_2b70db0
02cdbe5c: adrp    x0, #0x6267000                             
02cdbe60: ldr     x0, [x0, #0xc50]                           MS:System.Collections.Generic.Dictionary`2::Add
02cdbe64: bl      #0x2b70db0                                 fn_2b70db0
02cdbe68: adrp    x0, #0x6267000                             
02cdbe6c: ldr     x0, [x0, #0xc58]                           MS:System.Collections.Generic.Dictionary`2::ContainsKey
02cdbe70: bl      #0x2b70db0                                 fn_2b70db0
02cdbe74: adrp    x0, #0x6267000                             
02cdbe78: ldr     x0, [x0, #0xc60]                           MS:System.Collections.Generic.Dictionary`2::get_Item
02cdbe7c: bl      #0x2b70db0                                 fn_2b70db0
02cdbe80: adrp    x0, #0x6267000                             
02cdbe84: ldr     x0, [x0, #0xc68]                           MS:System.Collections.Generic.Dictionary`2::set_Item
02cdbe88: bl      #0x2b70db0                                 fn_2b70db0
02cdbe8c: mov     w8, #1                                     
02cdbe90: strb    w8, [x22, #0xd6b]                          
02cdbe94: ldr     x0, [x21, #0x20]                           ._listeners
02cdbe98: cbz     x0, #0x2cdbfc4                             
02cdbe9c: adrp    x8, #0x6267000                             
02cdbea0: mov     w1, w19                                    
02cdbea4: ldr     x8, [x8, #0xc58]                           MS:System.Collections.Generic.Dictionary`2::ContainsKey
02cdbea8: ldr     x2, [x8]                                   S:'didu'
02cdbeac: bl      #0x44ec5e4                                 fn_44ec5e4
02cdbeb0: ldr     x22, [x21, #0x20]                          ._listeners
02cdbeb4: tbz     w0, #0, #0x2cdbf10                         
02cdbeb8: cbz     x22, #0x2cdbfc4                            
02cdbebc: adrp    x8, #0x6267000                             
02cdbec0: mov     x0, x22                                    
02cdbec4: mov     w1, w19                                    
02cdbec8: ldr     x8, [x8, #0xc60]                           MS:System.Collections.Generic.Dictionary`2::get_Item
02cdbecc: ldr     x2, [x8]                                   S:'didu'
02cdbed0: bl      #0x44ec350                                 fn_44ec350
02cdbed4: mov     x1, x20                                    
02cdbed8: mov     x2, xzr                                    
02cdbedc: bl      #0x4e570ac                                 System.Delegate::Combine
02cdbee0: cbz     x0, #0x2cdbf8c                             
02cdbee4: adrp    x8, #0x6267000                             
02cdbee8: mov     x20, x0                                    
02cdbeec: ldr     x8, [x8, #0xc48]                           T:type6961(k15)
02cdbef0: ldr     x21, [x8]                                  S:'didu'
02cdbef4: mov     x1, x21                                    
02cdbef8: bl      #0x2b70f34                                 fn_2b70f34
02cdbefc: mov     x2, x0                                     
02cdbf00: cbnz    x0, #0x2cdbf90                             
02cdbf04: mov     x0, x20                                    
02cdbf08: mov     x1, x21                                    
02cdbf0c: bl      #0x2b713dc                                 fn_2b713dc
02cdbf10: cbz     x22, #0x2cdbfc4                            
02cdbf14: adrp    x8, #0x6267000                             
02cdbf18: mov     x0, x22                                    
02cdbf1c: mov     w1, w19                                    
02cdbf20: ldr     x8, [x8, #0xc50]                           MS:System.Collections.Generic.Dictionary`2::Add
02cdbf24: mov     x2, xzr                                    
02cdbf28: ldr     x3, [x8]                                   S:'didu'
02cdbf2c: bl      #0x44ec3f0                                 fn_44ec3f0
02cdbf30: ldr     x21, [x21, #0x20]                          ._listeners
02cdbf34: cbz     x21, #0x2cdbfc4                            
02cdbf38: adrp    x8, #0x6267000                             
02cdbf3c: mov     x0, x21                                    
02cdbf40: mov     w1, w19                                    
02cdbf44: ldr     x8, [x8, #0xc60]                           MS:System.Collections.Generic.Dictionary`2::get_Item
02cdbf48: ldr     x2, [x8]                                   S:'didu'
02cdbf4c: bl      #0x44ec350                                 fn_44ec350
02cdbf50: mov     x1, x20                                    
02cdbf54: mov     x2, xzr                                    
02cdbf58: bl      #0x4e570ac                                 System.Delegate::Combine
02cdbf5c: cbz     x0, #0x2cdbf9c                             
02cdbf60: adrp    x8, #0x6267000                             
02cdbf64: mov     x20, x0                                    
02cdbf68: ldr     x8, [x8, #0xc48]                           T:type6961(k15)
02cdbf6c: ldr     x22, [x8]                                  S:'didu'
02cdbf70: mov     x1, x22                                    
02cdbf74: bl      #0x2b70f34                                 fn_2b70f34
02cdbf78: mov     x2, x0                                     
02cdbf7c: cbnz    x0, #0x2cdbfa0                             
02cdbf80: mov     x0, x20                                    
02cdbf84: mov     x1, x22                                    
02cdbf88: bl      #0x2b713dc                                 fn_2b713dc
02cdbf8c: mov     x2, xzr                                    
02cdbf90: adrp    x8, #0x6267000                             
02cdbf94: mov     x0, x22                                    
02cdbf98: b       #0x2cdbfa8                                 
02cdbf9c: mov     x2, xzr                                    
02cdbfa0: adrp    x8, #0x6267000                             
02cdbfa4: mov     x0, x21                                    
02cdbfa8: ldr     x8, [x8, #0xc68]                           MS:System.Collections.Generic.Dictionary`2::set_Item
02cdbfac: ldr     x3, [x8]                                   S:'didu'
02cdbfb0: mov     w1, w19                                    
02cdbfb4: ldp     x20, x19, [sp, #0x20]                      
02cdbfb8: ldp     x22, x21, [sp, #0x10]                      
02cdbfbc: ldr     x30, [sp], #0x30                           
02cdbfc0: b       #0x44ec3dc                                 
02cdbfc4: bl      #0x2b7105c                                 fn_2b7105c
## PostEvent(EventID eventID, object param) -> void
---- EventDispatcher::PostEvent 0x2cdbfc8
02cdbfc8: str     x30, [sp, #-0x30]!                         
02cdbfcc: stp     x22, x21, [sp, #0x10]                      
02cdbfd0: stp     x20, x19, [sp, #0x20]                      
02cdbfd4: adrp    x22, #0x662f000                            
02cdbfd8: mov     x20, x2                                    
02cdbfdc: mov     w19, w1                                    
02cdbfe0: ldrb    w8, [x22, #0xd6c]                          
02cdbfe4: mov     x21, x0                                    
02cdbfe8: tbnz    w8, #0, #0x2cdc018                         
02cdbfec: adrp    x0, #0x6267000                             
02cdbff0: ldr     x0, [x0, #0xc58]                           MS:System.Collections.Generic.Dictionary`2::ContainsKey
02cdbff4: bl      #0x2b70db0                                 fn_2b70db0
02cdbff8: adrp    x0, #0x6267000                             
02cdbffc: ldr     x0, [x0, #0xc70]                           MS:System.Collections.Generic.Dictionary`2::Remove
02cdc000: bl      #0x2b70db0                                 fn_2b70db0
02cdc004: adrp    x0, #0x6267000                             
02cdc008: ldr     x0, [x0, #0xc60]                           MS:System.Collections.Generic.Dictionary`2::get_Item
02cdc00c: bl      #0x2b70db0                                 fn_2b70db0
02cdc010: mov     w8, #1                                     
02cdc014: strb    w8, [x22, #0xd6c]                          
02cdc018: ldr     x0, [x21, #0x20]                           ._listeners
02cdc01c: cbz     x0, #0x2cdc0b4                             
02cdc020: adrp    x8, #0x6267000                             
02cdc024: mov     w1, w19                                    
02cdc028: ldr     x8, [x8, #0xc58]                           MS:System.Collections.Generic.Dictionary`2::ContainsKey
02cdc02c: ldr     x2, [x8]                                   S:'didu'
02cdc030: bl      #0x44ec5e4                                 fn_44ec5e4
02cdc034: tbz     w0, #0, #0x2cdc07c                         
02cdc038: ldr     x0, [x21, #0x20]                           ._listeners
02cdc03c: cbz     x0, #0x2cdc0b4                             
02cdc040: adrp    x8, #0x6267000                             
02cdc044: mov     w1, w19                                    
02cdc048: ldr     x8, [x8, #0xc60]                           MS:System.Collections.Generic.Dictionary`2::get_Item
02cdc04c: ldr     x2, [x8]                                   S:'didu'
02cdc050: bl      #0x44ec350                                 fn_44ec350
02cdc054: cbz     x0, #0x2cdc08c                             
02cdc058: ldr     x8, [x0, #0x40]                            S:'<color=#'
02cdc05c: mov     x1, x20                                    
02cdc060: ldr     x2, [x0, #0x28]                            S:'[^A-Za-z0-9_. ]+'
02cdc064: ldp     x20, x19, [sp, #0x20]                      
02cdc068: ldr     x3, [x0, #0x18]                            S:'android.content.Intent'
02cdc06c: ldp     x22, x21, [sp, #0x10]                      
02cdc070: mov     x0, x8                                     
02cdc074: ldr     x30, [sp], #0x30                           
02cdc078: br      x3                                         
02cdc07c: ldp     x20, x19, [sp, #0x20]                      
02cdc080: ldp     x22, x21, [sp, #0x10]                      
02cdc084: ldr     x30, [sp], #0x30                           
02cdc088: ret                                                
02cdc08c: ldr     x0, [x21, #0x20]                           ._listeners
02cdc090: cbz     x0, #0x2cdc0b4                             
02cdc094: adrp    x8, #0x6267000                             
02cdc098: mov     w1, w19                                    
02cdc09c: ldr     x8, [x8, #0xc70]                           MS:System.Collections.Generic.Dictionary`2::Remove
02cdc0a0: ldp     x20, x19, [sp, #0x20]                      
02cdc0a4: ldp     x22, x21, [sp, #0x10]                      
02cdc0a8: ldr     x2, [x8]                                   S:'didu'
02cdc0ac: ldr     x30, [sp], #0x30                           
02cdc0b0: b       #0x44ed898                                 
02cdc0b4: bl      #0x2b7105c                                 fn_2b7105c
## RemoveListener(EventID eventID, System.Action`1<object> callback) -> void
---- EventDispatcher::RemoveListener 0x2cdc0b8
02cdc0b8: str     x30, [sp, #-0x30]!                         
02cdc0bc: stp     x22, x21, [sp, #0x10]                      
02cdc0c0: stp     x20, x19, [sp, #0x20]                      
02cdc0c4: adrp    x22, #0x662f000                            
02cdc0c8: mov     x20, x2                                    
02cdc0cc: mov     w19, w1                                    
02cdc0d0: ldrb    w8, [x22, #0xd6d]                          
02cdc0d4: mov     x21, x0                                    
02cdc0d8: tbnz    w8, #0, #0x2cdc114                         
02cdc0dc: adrp    x0, #0x6267000                             
02cdc0e0: ldr     x0, [x0, #0xc48]                           T:type6961(k15)
02cdc0e4: bl      #0x2b70db0                                 fn_2b70db0
02cdc0e8: adrp    x0, #0x6267000                             
02cdc0ec: ldr     x0, [x0, #0xc58]                           MS:System.Collections.Generic.Dictionary`2::ContainsKey
02cdc0f0: bl      #0x2b70db0                                 fn_2b70db0
02cdc0f4: adrp    x0, #0x6267000                             
02cdc0f8: ldr     x0, [x0, #0xc60]                           MS:System.Collections.Generic.Dictionary`2::get_Item
02cdc0fc: bl      #0x2b70db0                                 fn_2b70db0
02cdc100: adrp    x0, #0x6267000                             
02cdc104: ldr     x0, [x0, #0xc68]                           MS:System.Collections.Generic.Dictionary`2::set_Item
02cdc108: bl      #0x2b70db0                                 fn_2b70db0
02cdc10c: mov     w8, #1                                     
02cdc110: strb    w8, [x22, #0xd6d]                          
02cdc114: ldr     x0, [x21, #0x20]                           ._listeners
02cdc118: cbz     x0, #0x2cdc1c8                             
02cdc11c: adrp    x8, #0x6267000                             
02cdc120: mov     w1, w19                                    
02cdc124: ldr     x8, [x8, #0xc58]                           MS:System.Collections.Generic.Dictionary`2::ContainsKey
02cdc128: ldr     x2, [x8]                                   S:'didu'
02cdc12c: bl      #0x44ec5e4                                 fn_44ec5e4
02cdc130: tbz     w0, #0, #0x2cdc190                         
02cdc134: ldr     x21, [x21, #0x20]                          ._listeners
02cdc138: cbz     x21, #0x2cdc1c8                            
02cdc13c: adrp    x8, #0x6267000                             
02cdc140: mov     x0, x21                                    
02cdc144: mov     w1, w19                                    
02cdc148: ldr     x8, [x8, #0xc60]                           MS:System.Collections.Generic.Dictionary`2::get_Item
02cdc14c: ldr     x2, [x8]                                   S:'didu'
02cdc150: bl      #0x44ec350                                 fn_44ec350
02cdc154: mov     x1, x20                                    
02cdc158: mov     x2, xzr                                    
02cdc15c: bl      #0x4e57298                                 System.Delegate::Remove
02cdc160: cbz     x0, #0x2cdc1a0                             
02cdc164: adrp    x8, #0x6267000                             
02cdc168: mov     x20, x0                                    
02cdc16c: ldr     x8, [x8, #0xc48]                           T:type6961(k15)
02cdc170: ldr     x22, [x8]                                  S:'didu'
02cdc174: mov     x1, x22                                    
02cdc178: bl      #0x2b70f34                                 fn_2b70f34
02cdc17c: mov     x2, x0                                     
02cdc180: cbnz    x0, #0x2cdc1a4                             
02cdc184: mov     x0, x20                                    
02cdc188: mov     x1, x22                                    
02cdc18c: bl      #0x2b713dc                                 fn_2b713dc
02cdc190: ldp     x20, x19, [sp, #0x20]                      
02cdc194: ldp     x22, x21, [sp, #0x10]                      
02cdc198: ldr     x30, [sp], #0x30                           
02cdc19c: ret                                                
02cdc1a0: mov     x2, xzr                                    
02cdc1a4: adrp    x8, #0x6267000                             
02cdc1a8: mov     x0, x21                                    
02cdc1ac: mov     w1, w19                                    
02cdc1b0: ldr     x8, [x8, #0xc68]                           MS:System.Collections.Generic.Dictionary`2::set_Item
02cdc1b4: ldp     x20, x19, [sp, #0x20]                      
02cdc1b8: ldp     x22, x21, [sp, #0x10]                      
02cdc1bc: ldr     x3, [x8]                                   S:'didu'
02cdc1c0: ldr     x30, [sp], #0x30                           
02cdc1c4: b       #0x44ec3dc                                 
02cdc1c8: bl      #0x2b7105c                                 fn_2b7105c
## ClearAllListener() -> void
---- EventDispatcher::ClearAllListener 0x2cdbddc
02cdbddc: str     x30, [sp, #-0x20]!                         
02cdbde0: stp     x20, x19, [sp, #0x10]                      
02cdbde4: adrp    x20, #0x662f000                            
02cdbde8: mov     x19, x0                                    
02cdbdec: ldrb    w8, [x20, #0xd6e]                          
02cdbdf0: tbnz    w8, #0, #0x2cdbe08                         
02cdbdf4: adrp    x0, #0x6267000                             
02cdbdf8: ldr     x0, [x0, #0xc40]                           MS:System.Collections.Generic.Dictionary`2::Clear
02cdbdfc: bl      #0x2b70db0                                 fn_2b70db0
02cdbe00: mov     w8, #1                                     
02cdbe04: strb    w8, [x20, #0xd6e]                          
02cdbe08: ldr     x0, [x19, #0x20]                           ._listeners
02cdbe0c: cbz     x0, #0x2cdbe28                             
02cdbe10: adrp    x8, #0x6267000                             
02cdbe14: ldr     x8, [x8, #0xc40]                           MS:System.Collections.Generic.Dictionary`2::Clear
02cdbe18: ldp     x20, x19, [sp, #0x10]                      
02cdbe1c: ldr     x1, [x8]                                   S:'didu'
02cdbe20: ldr     x30, [sp], #0x20                           
02cdbe24: b       #0x44ec578                                 
02cdbe28: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- EventDispatcher::.ctor 0x2cdc1cc
02cdc1cc: str     x30, [sp, #-0x30]!                         
02cdc1d0: stp     x22, x21, [sp, #0x10]                      
02cdc1d4: stp     x20, x19, [sp, #0x20]                      
02cdc1d8: adrp    x21, #0x662f000                            
02cdc1dc: adrp    x22, #0x6267000                            
02cdc1e0: adrp    x20, #0x6267000                            
02cdc1e4: ldrb    w8, [x21, #0xd6f]                          
02cdc1e8: ldr     x22, [x22, #0xc78]                         T:type54330(k15)
02cdc1ec: ldr     x20, [x20, #0xc80]                         MS:System.Collections.Generic.Dictionary`2::.ctor
02cdc1f0: mov     x19, x0                                    
02cdc1f4: tbnz    w8, #0, #0x2cdc218                         
02cdc1f8: adrp    x0, #0x6267000                             
02cdc1fc: ldr     x0, [x0, #0xc80]                           MS:System.Collections.Generic.Dictionary`2::.ctor
02cdc200: bl      #0x2b70db0                                 fn_2b70db0
02cdc204: adrp    x0, #0x6267000                             
02cdc208: ldr     x0, [x0, #0xc78]                           T:type54330(k15)
02cdc20c: bl      #0x2b70db0                                 fn_2b70db0
02cdc210: mov     w8, #1                                     
02cdc214: strb    w8, [x21, #0xd6f]                          
02cdc218: ldr     x0, [x22]                                  S:'didu'
02cdc21c: bl      #0x2b7104c                                 fn_2b7104c
02cdc220: ldr     x1, [x20]                                  S:'didu'
02cdc224: mov     x20, x0                                    
02cdc228: bl      #0x44eb650                                 fn_44eb650
02cdc22c: mov     x0, x19                                    
02cdc230: mov     x1, x20                                    
02cdc234: str     x20, [x0, #0x20]!                          ._listeners
02cdc238: bl      #0x2b70d54                                 fn_2b70d54
02cdc23c: mov     x0, x19                                    
02cdc240: ldp     x20, x19, [sp, #0x20]                      
02cdc244: ldp     x22, x21, [sp, #0x10]                      
02cdc248: mov     x1, xzr                                    
02cdc24c: ldr     x30, [sp], #0x30                           
02cdc250: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
