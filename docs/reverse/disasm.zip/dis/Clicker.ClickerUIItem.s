#### CLASS Clicker.ClickerUIItem/<>c__DisplayClass19_0 parent= object
#   field <>4__this                      Clicker.ClickerUIItem                              off=0x10 attr=6 
#   field onUseSuccess                   System.Action`1<int>                               off=0x18 attr=6 
## .ctor() -> void
---- Clicker.ClickerUIItem/<>c__DisplayClass19_0::.ctor 0x2d667b0
02d667b0: mov     x1, xzr                                    
02d667b4: b       #0x4e53e9c                                 System.Object::.ctor
## <RegisterClickListener>b__0() -> void
---- Clicker.ClickerUIItem/<>c__DisplayClass19_0::<RegisterClickListener>b__0 0x2d66de0
02d66de0: mov     x8, x0                                     
02d66de4: ldr     x0, [x0, #0x10]                            .<>4__this
02d66de8: cbz     x0, #0x2d66dfc                             
02d66dec: ldr     x9, [x0]                                   
02d66df0: ldr     x1, [x8, #0x18]                            
02d66df4: ldp     x3, x2, [x9, #0x1b8]                       
02d66df8: br      x3                                         
02d66dfc: str     x30, [sp, #-0x10]!                         
02d66e00: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Clicker.ClickerUIItem/<>c__DisplayClass22_0 parent= object
#   field <>4__this                      Clicker.ClickerUIItem                              off=0x10 attr=6 
#   field onUseSuccess                   System.Action`1<int>                               off=0x18 attr=6 
## .ctor() -> void
---- Clicker.ClickerUIItem/<>c__DisplayClass22_0::.ctor 0x2d66da0
02d66da0: mov     x1, xzr                                    
02d66da4: b       #0x4e53e9c                                 System.Object::.ctor
## <OnItemClick>b__0() -> void
---- Clicker.ClickerUIItem/<>c__DisplayClass22_0::<OnItemClick>b__0 0x2d66e04
02d66e04: stp     x30, x19, [sp, #-0x10]!                    
02d66e08: mov     x19, x0                                    
02d66e0c: ldr     x0, [x0, #0x10]                            .<>4__this
02d66e10: cbz     x0, #0x2d66e58                             
02d66e14: ldr     x8, [x0]                                   
02d66e18: mov     w1, #1                                     
02d66e1c: ldp     x9, x2, [x8, #0x188]                       
02d66e20: blr     x9                                         
02d66e24: ldr     x8, [x19, #0x18]                           .onUseSuccess
02d66e28: cbz     x8, #0x2d66e48                             
02d66e2c: ldr     x9, [x19, #0x10]                           .<>4__this
02d66e30: cbz     x9, #0x2d66e58                             
02d66e34: ldr     w1, [x9, #0x6c]                            
02d66e38: ldr     x9, [x8, #0x18]                            
02d66e3c: ldr     x0, [x8, #0x40]                            
02d66e40: ldr     x2, [x8, #0x28]                            
02d66e44: blr     x9                                         
02d66e48: ldr     x0, [x19, #0x10]                           .<>4__this
02d66e4c: cbz     x0, #0x2d66e58                             
02d66e50: ldp     x30, x19, [sp], #0x10                      
02d66e54: b       #0x2d66a30                                 Clicker.ClickerUIItem::UpdateVisualUnlock
02d66e58: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Clicker.ClickerUIItem parent= UnityEngine.MonoBehaviour
#   field _goSelected                    UnityEngine.GameObject                             off=0x20 attr=4 SerializeField
#   field _goNotSelected                 UnityEngine.GameObject                             off=0x28 attr=4 SerializeField
#   field _goCheck                       UnityEngine.GameObject                             off=0x30 attr=4 SerializeField
#   field _goAdLock                      UnityEngine.GameObject                             off=0x38 attr=4 SerializeField
#   field _goCoinLock                    UnityEngine.GameObject                             off=0x40 attr=4 SerializeField
#   field _goOtherLock                   UnityEngine.GameObject                             off=0x48 attr=4 SerializeField
#   field _txtCoinPrice                  TMPro.TextMeshProUGUI                              off=0x50 attr=4 SerializeField
#   field _imgIcon                       UnityEngine.UI.Image                               off=0x58 attr=4 SerializeField
#   field _btnFull                       UnityEngine.UI.Button                              off=0x60 attr=4 SerializeField
#   field _priceCached                   int                                                off=0x68 attr=4 
#   field _id                            int                                                off=0x6c attr=4 
#   field _unlockStatus                  Clicker.UnlockMethodType                           off=0x70 attr=4 
#   field _unlocked                      bool                                               off=0x74 attr=4 
## get_PriceCached() -> int
---- Clicker.ClickerUIItem::get_PriceCached 0x2d665ec
02d665ec: ldr     w0, [x0, #0x68]                            ._priceCached
02d665f0: ret                                                
## get_ID() -> int
---- Clicker.ClickerUIItem::get_ID 0x2d665f4
02d665f4: ldr     w0, [x0, #0x6c]                            ._id
02d665f8: ret                                                
## SetData(int id, UnityEngine.Sprite icon) -> void
---- Clicker.ClickerUIItem::SetData 0x2d665fc
02d665fc: stp     x30, x19, [sp, #-0x10]!                    
02d66600: mov     x19, x0                                    
02d66604: ldr     x0, [x0, #0x58]                            ._imgIcon
02d66608: str     w1, [x19, #0x6c]                           ._id
02d6660c: cbz     x0, #0x2d6663c                             
02d66610: mov     x1, x2                                     
02d66614: mov     x2, xzr                                    
02d66618: bl      #0x5c45aa0                                 UnityEngine.UI.Image::set_sprite
02d6661c: ldr     x8, [x19]                                  
02d66620: mov     x0, x19                                    
02d66624: mov     w1, wzr                                    
02d66628: ldp     x9, x2, [x8, #0x188]                       
02d6662c: blr     x9                                         
02d66630: strb    wzr, [x19, #0x74]                          ._unlocked
02d66634: ldp     x30, x19, [sp], #0x10                      
02d66638: ret                                                
02d6663c: bl      #0x2b7105c                                 fn_2b7105c
## SetSelected(bool isSelected) -> void
---- Clicker.ClickerUIItem::SetSelected 0x2d66640
02d66640: str     x30, [sp, #-0x20]!                         
02d66644: stp     x20, x19, [sp, #0x10]                      
02d66648: mov     x19, x0                                    
02d6664c: ldr     x0, [x0, #0x20]                            ._goSelected
02d66650: cbz     x0, #0x2d666ac                             
02d66654: mov     w20, w1                                    
02d66658: and     w1, w1, #1                                 
02d6665c: mov     x2, xzr                                    
02d66660: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d66664: ldr     x0, [x19, #0x30]                           ._goCheck
02d66668: cbz     x0, #0x2d666ac                             
02d6666c: and     w1, w20, #1                                
02d66670: mov     x2, xzr                                    
02d66674: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d66678: ldr     x0, [x19, #0x28]                           ._goNotSelected
02d6667c: cbz     x0, #0x2d666ac                             
02d66680: mov     w8, #1                                     
02d66684: mov     x2, xzr                                    
02d66688: bic     w1, w8, w20                                
02d6668c: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d66690: ldr     x8, [x19]                                  
02d66694: and     w1, w20, #1                                
02d66698: mov     x0, x19                                    
02d6669c: ldp     x20, x19, [sp, #0x10]                      
02d666a0: ldp     x3, x2, [x8, #0x1d8]                       
02d666a4: ldr     x30, [sp], #0x20                           
02d666a8: br      x3                                         
02d666ac: bl      #0x2b7105c                                 fn_2b7105c
## RegisterClickListener(System.Action`1<int> onUseSuccess) -> void
---- Clicker.ClickerUIItem::RegisterClickListener 0x2d666b0
02d666b0: str     x30, [sp, #-0x30]!                         
02d666b4: stp     x22, x21, [sp, #0x10]                      
02d666b8: stp     x20, x19, [sp, #0x20]                      
02d666bc: adrp    x20, #0x6630000                            
02d666c0: adrp    x22, #0x626c000                            
02d666c4: mov     x21, x1                                    
02d666c8: ldrb    w8, [x20, #0x335]                          
02d666cc: ldr     x22, [x22, #0x1b8]                         T:Clicker.ClickerUIItem/<>c__DisplayClass19_0
02d666d0: mov     x19, x0                                    
02d666d4: tbnz    w8, #0, #0x2d66704                         
02d666d8: adrp    x0, #0x626c000                             
02d666dc: ldr     x0, [x0, #0x1c0]                           M:Clicker.ClickerUIItem/<>c__DisplayClass19_0::<RegisterClickListener>b__0
02d666e0: bl      #0x2b70db0                                 fn_2b70db0
02d666e4: adrp    x0, #0x626c000                             
02d666e8: ldr     x0, [x0, #0x1b8]                           T:Clicker.ClickerUIItem/<>c__DisplayClass19_0
02d666ec: bl      #0x2b70db0                                 fn_2b70db0
02d666f0: adrp    x0, #0x6265000                             
02d666f4: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d666f8: bl      #0x2b70db0                                 fn_2b70db0
02d666fc: mov     w8, #1                                     
02d66700: strb    w8, [x20, #0x335]                          
02d66704: ldr     x0, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d66708: bl      #0x2b7104c                                 fn_2b7104c
02d6670c: mov     x1, xzr                                    
02d66710: mov     x20, x0                                    
02d66714: bl      #0x4e53e9c                                 System.Object::.ctor
02d66718: cbz     x20, #0x2d667ac                            
02d6671c: mov     x0, x20                                    
02d66720: mov     x1, x19                                    
02d66724: str     x19, [x0, #0x10]!                          
02d66728: bl      #0x2b70d54                                 fn_2b70d54
02d6672c: mov     x0, x20                                    
02d66730: mov     x1, x21                                    
02d66734: str     x21, [x0, #0x18]!                          
02d66738: bl      #0x2b70d54                                 fn_2b70d54
02d6673c: ldr     x8, [x19, #0x60]                           ._btnFull
02d66740: cbz     x8, #0x2d667ac                             
02d66744: ldr     x0, [x8, #0x100]                           
02d66748: cbz     x0, #0x2d667ac                             
02d6674c: mov     x1, xzr                                    
02d66750: bl      #0x5b4ce48                                 UnityEngine.Events.UnityEventBase::RemoveAllListeners
02d66754: ldr     x8, [x19, #0x60]                           ._btnFull
02d66758: cbz     x8, #0x2d667ac                             
02d6675c: adrp    x9, #0x6265000                             
02d66760: adrp    x21, #0x626c000                            
02d66764: ldr     x9, [x9, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d66768: ldr     x21, [x21, #0x1c0]                         M:Clicker.ClickerUIItem/<>c__DisplayClass19_0::<RegisterClickListener>b__0
02d6676c: ldr     x19, [x8, #0x100]                          
02d66770: ldr     x0, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02d66774: bl      #0x2b7104c                                 fn_2b7104c
02d66778: ldr     x2, [x21]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6677c: mov     x1, x20                                    
02d66780: mov     x3, xzr                                    
02d66784: mov     x21, x0                                    
02d66788: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d6678c: cbz     x19, #0x2d667ac                            
02d66790: mov     x0, x19                                    
02d66794: mov     x1, x21                                    
02d66798: mov     x2, xzr                                    
02d6679c: ldp     x20, x19, [sp, #0x20]                      
02d667a0: ldp     x22, x21, [sp, #0x10]                      
02d667a4: ldr     x30, [sp], #0x30                           
02d667a8: b       #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d667ac: bl      #0x2b7105c                                 fn_2b7105c
## SetUnlockStatus(Clicker.UnlockMethodType type, int value, bool userUnlocked) -> void
---- Clicker.ClickerUIItem::SetUnlockStatus 0x2d667b8
02d667b8: str     x30, [sp, #-0x40]!                         
02d667bc: stp     x24, x23, [sp, #0x10]                      
02d667c0: stp     x22, x21, [sp, #0x20]                      
02d667c4: stp     x20, x19, [sp, #0x30]                      
02d667c8: adrp    x24, #0x6630000                            
02d667cc: mov     w21, w3                                    
02d667d0: mov     w22, w2                                    
02d667d4: ldrb    w8, [x24, #0x336]                          
02d667d8: mov     w20, w1                                    
02d667dc: mov     x19, x0                                    
02d667e0: and     w23, w3, #1                                
02d667e4: str     w2, [sp, #0xc]                             
02d667e8: tbnz    w8, #0, #0x2d66800                         
02d667ec: adrp    x0, #0x6263000                             
02d667f0: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d667f4: bl      #0x2b70db0                                 fn_2b70db0
02d667f8: mov     w8, #1                                     
02d667fc: strb    w8, [x24, #0x336]                          
02d66800: ldr     x0, [x19, #0x38]                           ._goAdLock
02d66804: str     w22, [x19, #0x68]                          ._priceCached
02d66808: str     w20, [x19, #0x70]                          ._unlockStatus
02d6680c: strb    w23, [x19, #0x74]                          ._unlocked
02d66810: tbz     w21, #0, #0x2d66884                        
02d66814: cbz     x0, #0x2d66a2c                             
02d66818: mov     w1, wzr                                    
02d6681c: mov     x2, xzr                                    
02d66820: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d66824: ldr     x0, [x19, #0x40]                           ._goCoinLock
02d66828: cbz     x0, #0x2d66a2c                             
02d6682c: mov     w1, wzr                                    
02d66830: mov     x2, xzr                                    
02d66834: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d66838: adrp    x8, #0x6263000                             
02d6683c: ldr     x8, [x8, #0x918]                           T:UnityEngine.Object
02d66840: ldr     x20, [x19, #0x48]                          ._goOtherLock
02d66844: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02d66848: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d6684c: cbnz    w8, #0x2d66854                             
02d66850: bl      #0x2b70f30                                 fn_2b70f30
02d66854: mov     x0, x20                                    
02d66858: mov     x1, xzr                                    
02d6685c: mov     x2, xzr                                    
02d66860: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d66864: tbz     w0, #0, #0x2d6687c                         
02d66868: ldr     x0, [x19, #0x48]                           ._goOtherLock
02d6686c: cbz     x0, #0x2d66a2c                             
02d66870: mov     w1, wzr                                    
02d66874: mov     x2, xzr                                    
02d66878: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d6687c: str     wzr, [x19, #0x70]                          ._unlockStatus
02d66880: b       #0x2d66a18                                 
02d66884: cmp     w20, #2                                    
02d66888: b.eq    #0x2d66908                                 
02d6688c: cmp     w20, #1                                    
02d66890: b.eq    #0x2d668a4                                 
02d66894: cbnz    w20, #0x2d669a0                            
02d66898: cbz     x0, #0x2d66a2c                             
02d6689c: mov     w1, wzr                                    
02d668a0: b       #0x2d668ac                                 
02d668a4: cbz     x0, #0x2d66a2c                             
02d668a8: mov     w1, #1                                     
02d668ac: mov     x2, xzr                                    
02d668b0: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d668b4: ldr     x0, [x19, #0x40]                           ._goCoinLock
02d668b8: cbz     x0, #0x2d66a2c                             
02d668bc: mov     w1, wzr                                    
02d668c0: mov     x2, xzr                                    
02d668c4: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d668c8: adrp    x8, #0x6263000                             
02d668cc: ldr     x8, [x8, #0x918]                           T:UnityEngine.Object
02d668d0: ldr     x20, [x19, #0x48]                          ._goOtherLock
02d668d4: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02d668d8: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d668dc: cbnz    w8, #0x2d668e4                             
02d668e0: bl      #0x2b70f30                                 fn_2b70f30
02d668e4: mov     x0, x20                                    
02d668e8: mov     x1, xzr                                    
02d668ec: mov     x2, xzr                                    
02d668f0: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d668f4: tbz     w0, #0, #0x2d66a18                         
02d668f8: ldr     x0, [x19, #0x48]                           ._goOtherLock
02d668fc: cbz     x0, #0x2d66a2c                             
02d66900: mov     w1, wzr                                    
02d66904: b       #0x2d66a00                                 
02d66908: cbz     x0, #0x2d66a2c                             
02d6690c: mov     w1, wzr                                    
02d66910: mov     x2, xzr                                    
02d66914: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d66918: ldr     x0, [x19, #0x40]                           ._goCoinLock
02d6691c: cbz     x0, #0x2d66a2c                             
02d66920: mov     w1, #1                                     
02d66924: mov     x2, xzr                                    
02d66928: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d6692c: adrp    x8, #0x6263000                             
02d66930: ldr     x8, [x8, #0x918]                           T:UnityEngine.Object
02d66934: ldr     x20, [x19, #0x48]                          ._goOtherLock
02d66938: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02d6693c: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d66940: cbnz    w8, #0x2d66948                             
02d66944: bl      #0x2b70f30                                 fn_2b70f30
02d66948: mov     x0, x20                                    
02d6694c: mov     x1, xzr                                    
02d66950: mov     x2, xzr                                    
02d66954: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d66958: tbz     w0, #0, #0x2d66970                         
02d6695c: ldr     x0, [x19, #0x48]                           ._goOtherLock
02d66960: cbz     x0, #0x2d66a2c                             
02d66964: mov     w1, wzr                                    
02d66968: mov     x2, xzr                                    
02d6696c: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d66970: ldr     x19, [x19, #0x50]                          ._txtCoinPrice
02d66974: add     x0, sp, #0xc                               
02d66978: mov     x1, xzr                                    
02d6697c: bl      #0x4e0ea3c                                 System.Int32::ToString
02d66980: cbz     x19, #0x2d66a2c                            
02d66984: ldr     x8, [x19]                                  
02d66988: mov     x1, x0                                     
02d6698c: mov     x0, x19                                    
02d66990: ldr     x9, [x8, #0x558]                           &2c5d934(=d65f03c0d503245f)
02d66994: ldr     x2, [x8, #0x560]                           &2c5d58c(=14c8cc6cd503245f)
02d66998: blr     x9                                         
02d6699c: b       #0x2d66a18                                 
02d669a0: cbz     x0, #0x2d66a2c                             
02d669a4: mov     w1, wzr                                    
02d669a8: mov     x2, xzr                                    
02d669ac: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d669b0: ldr     x0, [x19, #0x40]                           ._goCoinLock
02d669b4: cbz     x0, #0x2d66a2c                             
02d669b8: mov     w1, wzr                                    
02d669bc: mov     x2, xzr                                    
02d669c0: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d669c4: adrp    x8, #0x6263000                             
02d669c8: ldr     x8, [x8, #0x918]                           T:UnityEngine.Object
02d669cc: ldr     x20, [x19, #0x48]                          ._goOtherLock
02d669d0: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02d669d4: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d669d8: cbnz    w8, #0x2d669e0                             
02d669dc: bl      #0x2b70f30                                 fn_2b70f30
02d669e0: mov     x0, x20                                    
02d669e4: mov     x1, xzr                                    
02d669e8: mov     x2, xzr                                    
02d669ec: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d669f0: tbz     w0, #0, #0x2d66a18                         
02d669f4: ldr     x0, [x19, #0x48]                           ._goOtherLock
02d669f8: cbz     x0, #0x2d66a2c                             
02d669fc: mov     w1, #1                                     
02d66a00: ldp     x20, x19, [sp, #0x30]                      
02d66a04: mov     x2, xzr                                    
02d66a08: ldp     x22, x21, [sp, #0x20]                      
02d66a0c: ldp     x24, x23, [sp, #0x10]                      
02d66a10: ldr     x30, [sp], #0x40                           
02d66a14: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d66a18: ldp     x20, x19, [sp, #0x30]                      
02d66a1c: ldp     x22, x21, [sp, #0x20]                      
02d66a20: ldp     x24, x23, [sp, #0x10]                      
02d66a24: ldr     x30, [sp], #0x40                           
02d66a28: ret                                                
02d66a2c: bl      #0x2b7105c                                 fn_2b7105c
## UpdateVisualUnlock() -> void
---- Clicker.ClickerUIItem::UpdateVisualUnlock 0x2d66a30
02d66a30: stp     x30, x19, [sp, #-0x10]!                    
02d66a34: mov     x19, x0                                    
02d66a38: ldr     x0, [x0, #0x38]                            ._goAdLock
02d66a3c: str     wzr, [x19, #0x70]                          ._unlockStatus
02d66a40: cbz     x0, #0x2d66a7c                             
02d66a44: mov     w1, wzr                                    
02d66a48: mov     x2, xzr                                    
02d66a4c: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d66a50: ldr     x0, [x19, #0x40]                           ._goCoinLock
02d66a54: cbz     x0, #0x2d66a7c                             
02d66a58: mov     w1, wzr                                    
02d66a5c: mov     x2, xzr                                    
02d66a60: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d66a64: ldr     x0, [x19, #0x48]                           ._goOtherLock
02d66a68: cbz     x0, #0x2d66a7c                             
02d66a6c: mov     w1, wzr                                    
02d66a70: mov     x2, xzr                                    
02d66a74: ldp     x30, x19, [sp], #0x10                      
02d66a78: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d66a7c: bl      #0x2b7105c                                 fn_2b7105c
## OnItemClick(System.Action`1<int> onUseSuccess) -> void
---- Clicker.ClickerUIItem::OnItemClick 0x2d66a80
02d66a80: str     x30, [sp, #-0x30]!                         
02d66a84: stp     x22, x21, [sp, #0x10]                      
02d66a88: stp     x20, x19, [sp, #0x20]                      
02d66a8c: adrp    x20, #0x6630000                            
02d66a90: adrp    x22, #0x626c000                            
02d66a94: mov     x21, x1                                    
02d66a98: ldrb    w8, [x20, #0x337]                          
02d66a9c: ldr     x22, [x22, #0x1c8]                         T:Clicker.ClickerUIItem/<>c__DisplayClass22_0
02d66aa0: mov     x19, x0                                    
02d66aa4: tbnz    w8, #0, #0x2d66b34                         
02d66aa8: adrp    x0, #0x6264000                             
02d66aac: ldr     x0, [x0, #0xf90]                           T:System.Action
02d66ab0: bl      #0x2b70db0                                 fn_2b70db0
02d66ab4: adrp    x0, #0x6266000                             
02d66ab8: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d66abc: bl      #0x2b70db0                                 fn_2b70db0
02d66ac0: adrp    x0, #0x6267000                             
02d66ac4: ldr     x0, [x0, #0xbd0]                           MS:MonoSingleton`1::get_Instance
02d66ac8: bl      #0x2b70db0                                 fn_2b70db0
02d66acc: adrp    x0, #0x6266000                             
02d66ad0: ldr     x0, [x0, #0xaa0]                           MS:MonoSingleton`1::get_Instance
02d66ad4: bl      #0x2b70db0                                 fn_2b70db0
02d66ad8: adrp    x0, #0x6266000                             
02d66adc: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d66ae0: bl      #0x2b70db0                                 fn_2b70db0
02d66ae4: adrp    x0, #0x6265000                             
02d66ae8: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02d66aec: bl      #0x2b70db0                                 fn_2b70db0
02d66af0: adrp    x0, #0x626c000                             
02d66af4: ldr     x0, [x0, #0x1d0]                           M:Clicker.ClickerUIItem/<>c__DisplayClass22_0::<OnItemClick>b__0
02d66af8: bl      #0x2b70db0                                 fn_2b70db0
02d66afc: adrp    x0, #0x626c000                             
02d66b00: ldr     x0, [x0, #0x1c8]                           T:Clicker.ClickerUIItem/<>c__DisplayClass22_0
02d66b04: bl      #0x2b70db0                                 fn_2b70db0
02d66b08: adrp    x0, #0x6269000                             
02d66b0c: ldr     x0, [x0, #0xb40]                           MS:UIManager::ShowPopup
02d66b10: bl      #0x2b70db0                                 fn_2b70db0
02d66b14: adrp    x0, #0x626c000                             
02d66b18: ldr     x0, [x0, #0x1d8]                           MS:UIManager::ShowPopup
02d66b1c: bl      #0x2b70db0                                 fn_2b70db0
02d66b20: adrp    x0, #0x626c000                             
02d66b24: ldr     x0, [x0, #0x1e0]                           S:'unlock_item'
02d66b28: bl      #0x2b70db0                                 fn_2b70db0
02d66b2c: mov     w8, #1                                     
02d66b30: strb    w8, [x20, #0x337]                          
02d66b34: ldr     x0, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d66b38: bl      #0x2b7104c                                 fn_2b7104c
02d66b3c: mov     x1, xzr                                    
02d66b40: mov     x22, x0                                    
02d66b44: bl      #0x4e53e9c                                 System.Object::.ctor
02d66b48: cbz     x22, #0x2d66d9c                            
02d66b4c: mov     x0, x22                                    
02d66b50: mov     x1, x19                                    
02d66b54: str     x19, [x0, #0x10]!                          
02d66b58: bl      #0x2b70d54                                 fn_2b70d54
02d66b5c: mov     x20, x22                                   
02d66b60: mov     x1, x21                                    
02d66b64: str     x21, [x20, #0x18]!                         
02d66b68: mov     x0, x20                                    
02d66b6c: bl      #0x2b70d54                                 fn_2b70d54
02d66b70: ldr     x8, [x19]                                  
02d66b74: mov     x0, x19                                    
02d66b78: ldp     x9, x1, [x8, #0x1c8]                       
02d66b7c: blr     x9                                         
02d66b80: ldr     w8, [x19, #0x70]                           ._unlockStatus
02d66b84: cmp     w8, #2                                     
02d66b88: b.eq    #0x2d66c44                                 
02d66b8c: cmp     w8, #1                                     
02d66b90: b.eq    #0x2d66bd4                                 
02d66b94: cbnz    w8, #0x2d66cb0                             
02d66b98: ldr     x8, [x19]                                  
02d66b9c: mov     x0, x19                                    
02d66ba0: mov     w1, #1                                     
02d66ba4: ldp     x9, x2, [x8, #0x188]                       
02d66ba8: blr     x9                                         
02d66bac: ldr     x8, [x20]                                  
02d66bb0: cbz     x8, #0x2d66d8c                             
02d66bb4: ldr     w1, [x19, #0x6c]                           ._id
02d66bb8: ldp     x20, x19, [sp, #0x20]                      
02d66bbc: ldp     x22, x21, [sp, #0x10]                      
02d66bc0: ldr     x0, [x8, #0x40]                            
02d66bc4: ldr     x2, [x8, #0x28]                            
02d66bc8: ldr     x3, [x8, #0x18]                            
02d66bcc: ldr     x30, [sp], #0x30                           
02d66bd0: br      x3                                         
02d66bd4: adrp    x8, #0x6265000                             
02d66bd8: ldr     x8, [x8, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02d66bdc: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02d66be0: bl      #0x3be7218                                 fn_3be7218
02d66be4: adrp    x8, #0x6264000                             
02d66be8: mov     x19, x0                                    
02d66bec: ldr     x8, [x8, #0xf90]                           T:System.Action
02d66bf0: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d66bf4: mov     x0, x8                                     
02d66bf8: bl      #0x2b7104c                                 fn_2b7104c
02d66bfc: adrp    x8, #0x626c000                             
02d66c00: mov     x1, x22                                    
02d66c04: mov     x3, xzr                                    
02d66c08: ldr     x8, [x8, #0x1d0]                           M:Clicker.ClickerUIItem/<>c__DisplayClass22_0::<OnItemClick>b__0
02d66c0c: mov     x20, x0                                    
02d66c10: ldr     x2, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d66c14: bl      #0x4d8ddbc                                 System.Action::.ctor
02d66c18: cbz     x19, #0x2d66d9c                            
02d66c1c: adrp    x8, #0x626c000                             
02d66c20: mov     x0, x19                                    
02d66c24: mov     x2, x20                                    
02d66c28: ldr     x8, [x8, #0x1e0]                           S:'unlock_item'
02d66c2c: ldp     x20, x19, [sp, #0x20]                      
02d66c30: ldp     x22, x21, [sp, #0x10]                      
02d66c34: mov     x3, xzr                                    
02d66c38: ldr     x1, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d66c3c: ldr     x30, [sp], #0x30                           
02d66c40: b       #0x2c8a2c0                                 AdsManager::ShowRewarded
02d66c44: adrp    x8, #0x6266000                             
02d66c48: ldr     x8, [x8, #0x658]                           MS:MonoSingleton`1::get_Instance
02d66c4c: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d66c50: bl      #0x3769600                                 fn_3769600
02d66c54: cbz     x0, #0x2d66d9c                             
02d66c58: adrp    x8, #0x6266000                             
02d66c5c: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02d66c60: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d66c64: bl      #0x3168dd0                                 fn_3168dd0
02d66c68: cbz     x0, #0x2d66d9c                             
02d66c6c: mov     x1, xzr                                    
02d66c70: bl      #0x2cabaf8                                 DataUser::GetMoney
02d66c74: ldr     w8, [x19, #0x68]                           ._priceCached
02d66c78: cmp     w0, w8                                     
02d66c7c: b.ge    #0x2d66cf8                                 
02d66c80: adrp    x8, #0x6267000                             
02d66c84: ldr     x8, [x8, #0xbd0]                           MS:MonoSingleton`1::get_Instance
02d66c88: ldr     x0, [x8]                                   S:'didu'
02d66c8c: bl      #0x3769600                                 fn_3769600
02d66c90: cbz     x0, #0x2d66d9c                             
02d66c94: adrp    x8, #0x6269000                             
02d66c98: ldr     x8, [x8, #0xb40]                           MS:UIManager::ShowPopup
02d66c9c: ldp     x20, x19, [sp, #0x20]                      
02d66ca0: ldp     x22, x21, [sp, #0x10]                      
02d66ca4: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d66ca8: ldr     x30, [sp], #0x30                           
02d66cac: b       #0x33fbfac                                 
02d66cb0: adrp    x8, #0x6267000                             
02d66cb4: ldr     x8, [x8, #0xbd0]                           MS:MonoSingleton`1::get_Instance
02d66cb8: ldr     x0, [x8]                                   S:'didu'
02d66cbc: bl      #0x3769600                                 fn_3769600
02d66cc0: cbz     x0, #0x2d66d9c                             
02d66cc4: adrp    x8, #0x626c000                             
02d66cc8: ldr     x8, [x8, #0x1d8]                           MS:UIManager::ShowPopup
02d66ccc: ldr     x1, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d66cd0: bl      #0x33fbfac                                 fn_33fbfac
02d66cd4: ldr     x8, [x19, #0x58]                           ._imgIcon
02d66cd8: cbz     x8, #0x2d66d9c                             
02d66cdc: cbz     x0, #0x2d66d9c                             
02d66ce0: ldp     x20, x19, [sp, #0x20]                      
02d66ce4: mov     x2, xzr                                    
02d66ce8: ldp     x22, x21, [sp, #0x10]                      
02d66cec: ldr     x1, [x8, #0xd8]                            M:Clicker.Printer2DButton::<Init>b__3_1
02d66cf0: ldr     x30, [sp], #0x30                           
02d66cf4: b       #0x2d70344                                 Clicker.PopupItemLocked::ShowWithItem
02d66cf8: mov     x0, xzr                                    
02d66cfc: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d66d00: cbz     x0, #0x2d66d9c                             
02d66d04: movi    d1, #0000000000000000                      
02d66d08: movi    d2, #0000000000000000                      
02d66d0c: mov     w1, #0x2f                                  
02d66d10: fmov    s0, #1.00000000                            
02d66d14: mov     w2, wzr                                    
02d66d18: mov     w3, wzr                                    
02d66d1c: mov     x4, xzr                                    
02d66d20: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d66d24: adrp    x8, #0x6266000                             
02d66d28: ldr     x8, [x8, #0xaa0]                           MS:MonoSingleton`1::get_Instance
02d66d2c: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d66d30: bl      #0x3769600                                 fn_3769600
02d66d34: cbz     x0, #0x2d66d9c                             
02d66d38: ldr     w8, [x19, #0x68]                           ._priceCached
02d66d3c: mov     x2, xzr                                    
02d66d40: neg     w1, w8                                     
02d66d44: bl      #0x2cdac78                                 MoneyManager::UpdateMoney
02d66d48: ldr     x8, [x19]                                  
02d66d4c: mov     x0, x19                                    
02d66d50: mov     w1, #1                                     
02d66d54: ldp     x9, x2, [x8, #0x188]                       
02d66d58: blr     x9                                         
02d66d5c: ldr     x8, [x20]                                  
02d66d60: cbz     x8, #0x2d66d78                             
02d66d64: ldr     w1, [x19, #0x6c]                           ._id
02d66d68: ldr     x9, [x8, #0x18]                            S:'level_show_popuprate'
02d66d6c: ldr     x0, [x8, #0x40]                            S:'native_collap_ad_on_off'
02d66d70: ldr     x2, [x8, #0x28]                            S:'banner_ad_on_off'
02d66d74: blr     x9                                         
02d66d78: mov     x0, x19                                    
02d66d7c: ldp     x20, x19, [sp, #0x20]                      
02d66d80: ldp     x22, x21, [sp, #0x10]                      
02d66d84: ldr     x30, [sp], #0x30                           
02d66d88: b       #0x2d66a30                                 Clicker.ClickerUIItem::UpdateVisualUnlock
02d66d8c: ldp     x20, x19, [sp, #0x20]                      
02d66d90: ldp     x22, x21, [sp, #0x10]                      
02d66d94: ldr     x30, [sp], #0x30                           
02d66d98: ret                                                
02d66d9c: bl      #0x2b7105c                                 fn_2b7105c
## PlayClickSound() -> void
---- Clicker.ClickerUIItem::PlayClickSound 0x2d66da8
02d66da8: str     x30, [sp, #-0x10]!                         
02d66dac: mov     x0, xzr                                    
02d66db0: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d66db4: cbz     x0, #0x2d66ddc                             
02d66db8: movi    d1, #0000000000000000                      
02d66dbc: movi    d2, #0000000000000000                      
02d66dc0: mov     w1, #1                                     
02d66dc4: fmov    s0, #1.00000000                            
02d66dc8: mov     w2, wzr                                    
02d66dcc: mov     w3, wzr                                    
02d66dd0: mov     x4, xzr                                    
02d66dd4: ldr     x30, [sp], #0x10                           
02d66dd8: b       #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d66ddc: bl      #0x2b7105c                                 fn_2b7105c
## OnSelected(bool isSelected) -> void
---- Clicker.ClickerUIItem::OnSelected 0x2d664a8
02d664a8: ret                                                
## .ctor() -> void
---- Clicker.ClickerUIItem::.ctor 0x2d664b4
02d664b4: mov     x1, xzr                                    
02d664b8: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
