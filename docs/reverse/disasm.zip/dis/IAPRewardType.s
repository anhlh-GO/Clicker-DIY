#### CLASS IAPRewardType parent= int
#   field value__                        int                                                off=0x10 attr=606 
#   field None                           IAPRewardType                                      off=0x0 attr=8056 
#   field Coin                           IAPRewardType                                      off=0x0 attr=8056 
#   field SkinChar                       IAPRewardType                                      off=0x0 attr=8056 
#   field Charm                          IAPRewardType                                      off=0x0 attr=8056 
#   field Keychain                       IAPRewardType                                      off=0x0 attr=8056 
