#### CLASS KeycapEffect/<>c parent= object
#   field <>9                            KeycapEffect/<>c                                   off=0x0 attr=36 
#   field <>9__3_0                       System.Action`1<UnityEngine.RectTransform>         off=0x8 attr=16 
## .cctor() -> void
---- KeycapEffect/<>c::.cctor 0x2ce9ca4
02ce9ca4: str     x30, [sp, #-0x20]!                         
02ce9ca8: stp     x20, x19, [sp, #0x10]                      
02ce9cac: adrp    x19, #0x662f000                            
02ce9cb0: adrp    x20, #0x6268000                            
02ce9cb4: ldrb    w8, [x19, #0xe12]                          
02ce9cb8: ldr     x20, [x20, #0x340]                         T:KeycapEffect/<>c
02ce9cbc: tbnz    w8, #0, #0x2ce9cd4                         
02ce9cc0: adrp    x0, #0x6268000                             
02ce9cc4: ldr     x0, [x0, #0x340]                           T:KeycapEffect/<>c
02ce9cc8: bl      #0x2b70db0                                 fn_2b70db0
02ce9ccc: mov     w8, #1                                     
02ce9cd0: strb    w8, [x19, #0xe12]                          
02ce9cd4: ldr     x0, [x20]                                  S:'{0}/2'
02ce9cd8: bl      #0x2b7104c                                 fn_2b7104c
02ce9cdc: mov     x1, xzr                                    
02ce9ce0: mov     x19, x0                                    
02ce9ce4: bl      #0x4e53e9c                                 System.Object::.ctor
02ce9ce8: ldr     x8, [x20]                                  S:'{0}/2'
02ce9cec: mov     x1, x19                                    
02ce9cf0: ldr     x8, [x8, #0xb8]                            
02ce9cf4: str     x19, [x8]                                  
02ce9cf8: ldr     x8, [x20]                                  S:'{0}/2'
02ce9cfc: ldp     x20, x19, [sp, #0x10]                      
02ce9d00: ldr     x0, [x8, #0xb8]                            
02ce9d04: ldr     x30, [sp], #0x20                           
02ce9d08: b       #0x2b70d54                                 
## .ctor() -> void
---- KeycapEffect/<>c::.ctor 0x2ce9d0c
02ce9d0c: mov     x1, xzr                                    
02ce9d10: b       #0x4e53e9c                                 System.Object::.ctor
## <StopAnimate>b__3_0(UnityEngine.RectTransform letter) -> void
---- KeycapEffect/<>c::<StopAnimate>b__3_0 0x2ce9d14
02ce9d14: stp     x30, x19, [sp, #-0x10]!                    
02ce9d18: mov     x19, x1                                    
02ce9d1c: mov     x0, x1                                     
02ce9d20: mov     w1, wzr                                    
02ce9d24: mov     x2, xzr                                    
02ce9d28: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02ce9d2c: movi    d1, #0000000000000000                      
02ce9d30: fmov    s0, #-15.00000000                          
02ce9d34: mov     x0, x19                                    
02ce9d38: mov     w1, wzr                                    
02ce9d3c: mov     x2, xzr                                    
02ce9d40: ldp     x30, x19, [sp], #0x10                      
02ce9d44: b       #0x2c79c1c                                 DG.Tweening.DOTweenModuleUI::DOAnchorPosY
#### CLASS KeycapEffect parent= UnityEngine.MonoBehaviour
#   field _letters                       System.Collections.Generic.List`1<UnityEngine.RectTransform> off=0x20 attr=1 SerializeField
#   field _sequence                      DG.Tweening.Sequence                               off=0x28 attr=1 
## Animate() -> void
---- KeycapEffect::Animate 0x2ce990c
02ce990c: sub     sp, sp, #0x80                              
02ce9910: str     d8, [sp, #0x30]                            
02ce9914: stp     x30, x25, [sp, #0x40]                      
02ce9918: stp     x24, x23, [sp, #0x50]                      
02ce991c: stp     x22, x21, [sp, #0x60]                      
02ce9920: stp     x20, x19, [sp, #0x70]                      
02ce9924: adrp    x19, #0x662f000                            
02ce9928: mov     x20, x0                                    
02ce992c: ldrb    w8, [x19, #0xe10]                          
02ce9930: tbnz    w8, #0, #0x2ce9990                         
02ce9934: adrp    x0, #0x6263000                             
02ce9938: ldr     x0, [x0, #0xfd0]                           T:DG.Tweening.DOTween
02ce993c: bl      #0x2b70db0                                 fn_2b70db0
02ce9940: adrp    x0, #0x6267000                             
02ce9944: ldr     x0, [x0, #0x1d0]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02ce9948: bl      #0x2b70db0                                 fn_2b70db0
02ce994c: adrp    x0, #0x6267000                             
02ce9950: ldr     x0, [x0, #0x1d8]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02ce9954: bl      #0x2b70db0                                 fn_2b70db0
02ce9958: adrp    x0, #0x6267000                             
02ce995c: ldr     x0, [x0, #0x1e0]                           MS:System.Collections.Generic.List`1/Enumerator::get_Current
02ce9960: bl      #0x2b70db0                                 fn_2b70db0
02ce9964: adrp    x0, #0x6267000                             
02ce9968: ldr     x0, [x0, #0x1e8]                           MS:System.Collections.Generic.List`1::GetEnumerator
02ce996c: bl      #0x2b70db0                                 fn_2b70db0
02ce9970: adrp    x0, #0x6264000                             
02ce9974: ldr     x0, [x0, #0x100]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02ce9978: bl      #0x2b70db0                                 fn_2b70db0
02ce997c: adrp    x0, #0x6268000                             
02ce9980: ldr     x0, [x0, #0x320]                           MS:DG.Tweening.TweenSettingsExtensions::SetLoops
02ce9984: bl      #0x2b70db0                                 fn_2b70db0
02ce9988: mov     w8, #1                                     
02ce998c: strb    w8, [x19, #0xe10]                          
02ce9990: mov     x19, x20                                   
02ce9994: str     xzr, [sp, #0x20]                           
02ce9998: adrp    x21, #0x6263000                            
02ce999c: ldr     x0, [x19, #0x28]!                          [662f028]=6000015 f=2.40742e-35,0 ._sequence
02ce99a0: ldr     x21, [x21, #0xfd0]                         T:DG.Tweening.DOTween
02ce99a4: str     xzr, [sp, #0x18]                           
02ce99a8: str     xzr, [sp, #0x28]                           
02ce99ac: cbz     x0, #0x2ce99cc                             
02ce99b0: mov     w1, wzr                                    
02ce99b4: mov     x2, xzr                                    
02ce99b8: bl      #0x2d8fe94                                 DG.Tweening.TweenExtensions::Kill
02ce99bc: mov     x0, x19                                    
02ce99c0: mov     x1, xzr                                    
02ce99c4: str     xzr, [x19]                                 
02ce99c8: bl      #0x2b70d54                                 fn_2b70d54
02ce99cc: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02ce99d0: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02ce99d4: cbnz    w8, #0x2ce99dc                             
02ce99d8: bl      #0x2b70f30                                 fn_2b70f30
02ce99dc: mov     x0, xzr                                    
02ce99e0: bl      #0x2d8cfe8                                 DG.Tweening.DOTween::Sequence
02ce99e4: mov     x1, x0                                     
02ce99e8: str     x0, [x20, #0x28]                           ._sequence
02ce99ec: mov     x0, x19                                    
02ce99f0: bl      #0x2b70d54                                 fn_2b70d54
02ce99f4: ldr     x0, [x20, #0x20]                           ._letters
02ce99f8: cbz     x0, #0x2ce9b04                             
02ce99fc: adrp    x8, #0x6267000                             
02ce9a00: adrp    x24, #0x6267000                            
02ce9a04: adrp    x25, #0x6264000                            
02ce9a08: ldr     x8, [x8, #0x1e8]                           MS:System.Collections.Generic.List`1::GetEnumerator
02ce9a0c: adrp    x22, #0x6268000                            
02ce9a10: adrp    x23, #0x6267000                            
02ce9a14: ldr     x24, [x24, #0x1d8]                         MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02ce9a18: ldr     x25, [x25, #0x100]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02ce9a1c: ldr     x22, [x22, #0x320]                         MS:DG.Tweening.TweenSettingsExtensions::SetLoops
02ce9a20: ldr     x23, [x23, #0x1d0]                         MS:System.Collections.Generic.List`1/Enumerator::Dispose
02ce9a24: ldr     x1, [x8]                                   S:'didu'
02ce9a28: add     x8, sp, #0x18                              
02ce9a2c: add     x20, sp, #0x18                             
02ce9a30: bl      #0x35a9d9c                                 fn_35a9d9c
02ce9a34: adrp    x8, #0x1084000                             
02ce9a38: stp     xzr, x20, [sp, #8]                         
02ce9a3c: ldr     s8, [x8, #0xdd8]                           [1084dd8]=3f7333333e4ccccd f=0.2,0.95
02ce9a40: ldr     x1, [x24]                                  S:'didu'
02ce9a44: add     x0, sp, #0x18                              
02ce9a48: bl      #0x4690474                                 fn_4690474
02ce9a4c: tbz     w0, #0, #0x2ce9ac8                         
02ce9a50: ldr     x20, [sp, #0x28]                           
02ce9a54: ldr     x21, [x19]                                 &2b706c4(=eb01011ff9400808)
02ce9a58: fmov    s1, s8                                     
02ce9a5c: fmov    s0, #-31.00000000                          
02ce9a60: mov     x0, x20                                    
02ce9a64: mov     w1, wzr                                    
02ce9a68: mov     x2, xzr                                    
02ce9a6c: bl      #0x2c79c1c                                 DG.Tweening.DOTweenModuleUI::DOAnchorPosY
02ce9a70: mov     x1, x0                                     
02ce9a74: mov     x0, x21                                    
02ce9a78: mov     x2, xzr                                    
02ce9a7c: bl      #0x2d9b0a8                                 DG.Tweening.TweenSettingsExtensions::Append
02ce9a80: ldr     x2, [x25]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ce9a84: mov     w1, #5                                     
02ce9a88: bl      #0x336fa0c                                 fn_336fa0c
02ce9a8c: ldr     x21, [x19]                                 &2b706c4(=eb01011ff9400808)
02ce9a90: fmov    s1, s8                                     
02ce9a94: fmov    s0, #-15.00000000                          
02ce9a98: mov     x0, x20                                    
02ce9a9c: mov     w1, wzr                                    
02ce9aa0: mov     x2, xzr                                    
02ce9aa4: bl      #0x2c79c1c                                 DG.Tweening.DOTweenModuleUI::DOAnchorPosY
02ce9aa8: mov     x1, x0                                     
02ce9aac: mov     x0, x21                                    
02ce9ab0: mov     x2, xzr                                    
02ce9ab4: bl      #0x2d9b0a8                                 DG.Tweening.TweenSettingsExtensions::Append
02ce9ab8: ldr     x2, [x25]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ce9abc: mov     w1, #6                                     
02ce9ac0: bl      #0x336fa0c                                 fn_336fa0c
02ce9ac4: b       #0x2ce9a40                                 
02ce9ac8: ldr     x1, [x23]                                  S:'didu'
02ce9acc: add     x0, sp, #0x18                              
02ce9ad0: bl      #0x4690470                                 fn_4690470
02ce9ad4: ldr     x0, [x19]                                  &2b706c4(=eb01011ff9400808)
02ce9ad8: ldr     x3, [x22]                                  S:'{0}/2'
02ce9adc: mov     w1, #-1                                    
02ce9ae0: mov     w2, wzr                                    
02ce9ae4: bl      #0x336fe74                                 fn_336fe74
02ce9ae8: ldp     x20, x19, [sp, #0x70]                      
02ce9aec: ldr     d8, [sp, #0x30]                            
02ce9af0: ldp     x22, x21, [sp, #0x60]                      
02ce9af4: ldp     x24, x23, [sp, #0x50]                      
02ce9af8: ldp     x30, x25, [sp, #0x40]                      
02ce9afc: add     sp, sp, #0x80                              
02ce9b00: ret                                                
02ce9b04: bl      #0x2b7105c                                 fn_2b7105c
02ce9b08: b       #0x2ce9b20                                 
02ce9b0c: b       #0x2ce9b20                                 
02ce9b10: b       #0x2ce9b20                                 
02ce9b14: b       #0x2ce9b20                                 
02ce9b18: b       #0x2ce9b20                                 
02ce9b1c: b       #0x2ce9b20                                 
02ce9b20: mov     x20, x0                                    
02ce9b24: cmp     w1, #1                                     
02ce9b28: b.ne    #0x2ce9b5c                                 
02ce9b2c: mov     x0, x20                                    
02ce9b30: bl      #0x5e90260                                 fn_5e90260
02ce9b34: ldr     x20, [x0]                                  S:'{0}/2'
02ce9b38: str     x20, [sp, #8]                              
02ce9b3c: bl      #0x5e90270                                 fn_5e90270
02ce9b40: ldr     x0, [sp, #0x10]                            
02ce9b44: ldr     x1, [x23]                                  S:'didu'
02ce9b48: bl      #0x4690470                                 fn_4690470
02ce9b4c: cbz     x20, #0x2ce9ad4                            
02ce9b50: mov     x0, x20                                    
02ce9b54: bl      #0x2b71054                                 fn_2b71054
02ce9b58: mov     x20, x0                                    
02ce9b5c: add     x0, sp, #8                                 
02ce9b60: bl      #0x27370fc                                 fn_27370fc
02ce9b64: mov     x0, x20                                    
02ce9b68: bl      #0x2c6051c                                 fn_2c6051c
02ce9b6c: bl      #0x27369b8                                 fn_27369b8
## StopAnimate() -> void
---- KeycapEffect::StopAnimate 0x2ce9b70
02ce9b70: str     x30, [sp, #-0x30]!                         
02ce9b74: stp     x22, x21, [sp, #0x10]                      
02ce9b78: stp     x20, x19, [sp, #0x20]                      
02ce9b7c: adrp    x20, #0x662f000                            
02ce9b80: mov     x19, x0                                    
02ce9b84: ldrb    w8, [x20, #0xe11]                          
02ce9b88: tbnz    w8, #0, #0x2ce9bc4                         
02ce9b8c: adrp    x0, #0x6268000                             
02ce9b90: ldr     x0, [x0, #0x328]                           T:type53153(k15)
02ce9b94: bl      #0x2b70db0                                 fn_2b70db0
02ce9b98: adrp    x0, #0x6268000                             
02ce9b9c: ldr     x0, [x0, #0x330]                           MS:System.Collections.Generic.List`1::ForEach
02ce9ba0: bl      #0x2b70db0                                 fn_2b70db0
02ce9ba4: adrp    x0, #0x6268000                             
02ce9ba8: ldr     x0, [x0, #0x338]                           M:KeycapEffect/<>c::<StopAnimate>b__3_0
02ce9bac: bl      #0x2b70db0                                 fn_2b70db0
02ce9bb0: adrp    x0, #0x6268000                             
02ce9bb4: ldr     x0, [x0, #0x340]                           T:KeycapEffect/<>c
02ce9bb8: bl      #0x2b70db0                                 fn_2b70db0
02ce9bbc: mov     w8, #1                                     
02ce9bc0: strb    w8, [x20, #0xe11]                          
02ce9bc4: mov     x20, x19                                   
02ce9bc8: adrp    x22, #0x6268000                            
02ce9bcc: ldr     x0, [x20, #0x28]!                          [662f028]=6000015 f=2.40742e-35,0 ._sequence
02ce9bd0: ldr     x22, [x22, #0x340]                         T:KeycapEffect/<>c
02ce9bd4: cbz     x0, #0x2ce9bf4                             
02ce9bd8: mov     w1, wzr                                    
02ce9bdc: mov     x2, xzr                                    
02ce9be0: bl      #0x2d8fe94                                 DG.Tweening.TweenExtensions::Kill
02ce9be4: mov     x0, x20                                    
02ce9be8: mov     x1, xzr                                    
02ce9bec: str     xzr, [x20]                                 
02ce9bf0: bl      #0x2b70d54                                 fn_2b70d54
02ce9bf4: ldr     x0, [x22]                                  S:'{0}/2'
02ce9bf8: ldr     x19, [x19, #0x20]                          ._letters
02ce9bfc: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02ce9c00: cbnz    w8, #0x2ce9c0c                             
02ce9c04: bl      #0x2b70f30                                 fn_2b70f30
02ce9c08: ldr     x0, [x22]                                  S:'{0}/2'
02ce9c0c: ldr     x8, [x0, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02ce9c10: ldr     x20, [x8, #8]                              
02ce9c14: cbnz    x20, #0x2ce9c70                            
02ce9c18: ldr     w9, [x0, #0xe4]                            [62680e4]=0 f=0,0
02ce9c1c: cbnz    w9, #0x2ce9c2c                             
02ce9c20: bl      #0x2b70f30                                 fn_2b70f30
02ce9c24: ldr     x8, [x22]                                  S:'{0}/2'
02ce9c28: ldr     x8, [x8, #0xb8]                            
02ce9c2c: adrp    x9, #0x6268000                             
02ce9c30: ldr     x9, [x9, #0x328]                           T:type53153(k15)
02ce9c34: ldr     x21, [x8]                                  
02ce9c38: ldr     x0, [x9]                                   S:'{0}/2'
02ce9c3c: bl      #0x2b7104c                                 fn_2b7104c
02ce9c40: adrp    x8, #0x6268000                             
02ce9c44: mov     x1, x21                                    
02ce9c48: mov     x3, xzr                                    
02ce9c4c: ldr     x8, [x8, #0x338]                           M:KeycapEffect/<>c::<StopAnimate>b__3_0
02ce9c50: mov     x20, x0                                    
02ce9c54: ldr     x2, [x8]                                   S:'{0}/2'
02ce9c58: bl      #0x453418c                                 fn_453418c
02ce9c5c: ldr     x8, [x22]                                  S:'{0}/2'
02ce9c60: mov     x1, x20                                    
02ce9c64: ldr     x0, [x8, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02ce9c68: str     x20, [x0, #8]!                             
02ce9c6c: bl      #0x2b70d54                                 fn_2b70d54
02ce9c70: cbz     x19, #0x2ce9c98                            
02ce9c74: adrp    x8, #0x6268000                             
02ce9c78: mov     x0, x19                                    
02ce9c7c: mov     x1, x20                                    
02ce9c80: ldr     x8, [x8, #0x330]                           MS:System.Collections.Generic.List`1::ForEach
02ce9c84: ldp     x20, x19, [sp, #0x20]                      
02ce9c88: ldp     x22, x21, [sp, #0x10]                      
02ce9c8c: ldr     x2, [x8]                                   S:'{0}/2'
02ce9c90: ldr     x30, [sp], #0x30                           
02ce9c94: b       #0x35a9ce4                                 
02ce9c98: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- KeycapEffect::.ctor 0x2ce9c9c
02ce9c9c: mov     x1, xzr                                    
02ce9ca0: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
