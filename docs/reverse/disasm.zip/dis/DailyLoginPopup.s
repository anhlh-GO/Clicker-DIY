#### CLASS DailyLoginPopup/<>c parent= object
#   field <>9                            DailyLoginPopup/<>c                                off=0x0 attr=36 
#   field <>9__26_0                      System.Action`1<DailyMission.DailyItemBase>        off=0x8 attr=16 
## .cctor() -> void
---- DailyLoginPopup/<>c::.cctor 0x2cdfb9c
02cdfb9c: str     x30, [sp, #-0x20]!                         
02cdfba0: stp     x20, x19, [sp, #0x10]                      
02cdfba4: adrp    x19, #0x662f000                            
02cdfba8: adrp    x20, #0x6267000                            
02cdfbac: ldrb    w8, [x19, #0xda4]                          
02cdfbb0: ldr     x20, [x20, #0xe78]                         T:DailyLoginPopup/<>c
02cdfbb4: tbnz    w8, #0, #0x2cdfbcc                         
02cdfbb8: adrp    x0, #0x6267000                             
02cdfbbc: ldr     x0, [x0, #0xe78]                           T:DailyLoginPopup/<>c
02cdfbc0: bl      #0x2b70db0                                 fn_2b70db0
02cdfbc4: mov     w8, #1                                     
02cdfbc8: strb    w8, [x19, #0xda4]                          
02cdfbcc: ldr     x0, [x20]                                  S:'didu'
02cdfbd0: bl      #0x2b7104c                                 fn_2b7104c
02cdfbd4: mov     x1, xzr                                    
02cdfbd8: mov     x19, x0                                    
02cdfbdc: bl      #0x4e53e9c                                 System.Object::.ctor
02cdfbe0: ldr     x8, [x20]                                  S:'didu'
02cdfbe4: mov     x1, x19                                    
02cdfbe8: ldr     x8, [x8, #0xb8]                            
02cdfbec: str     x19, [x8]                                  
02cdfbf0: ldr     x8, [x20]                                  S:'didu'
02cdfbf4: ldp     x20, x19, [sp, #0x10]                      
02cdfbf8: ldr     x0, [x8, #0xb8]                            
02cdfbfc: ldr     x30, [sp], #0x20                           
02cdfc00: b       #0x2b70d54                                 
## .ctor() -> void
---- DailyLoginPopup/<>c::.ctor 0x2cdfc04
02cdfc04: mov     x1, xzr                                    
02cdfc08: b       #0x4e53e9c                                 System.Object::.ctor
## <RefreshStatus>b__26_0(DailyMission.DailyItemBase x) -> void
---- DailyLoginPopup/<>c::<RefreshStatus>b__26_0 0x2cdfc0c
02cdfc0c: cbz     x1, #0x2cdfc24                             
02cdfc10: ldr     x9, [x1]                                   
02cdfc14: mov     x0, x1                                     
02cdfc18: ldp     x2, x8, [x9, #0x198]                       
02cdfc1c: mov     x1, x8                                     
02cdfc20: br      x2                                         
02cdfc24: str     x30, [sp, #-0x10]!                         
02cdfc28: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS DailyLoginPopup parent= PopupBase
#   field OnRewardClaimed                System.Action`1<int>                               off=0x38 attr=6 
#   field _dailyLoginController          DailyReward.DailyLoginController                   off=0x40 attr=1 SerializeField
#   field _claimButton                   UnityEngine.UI.Button                              off=0x48 attr=1 SerializeField
#   field _unClaimGo                     UnityEngine.GameObject                             off=0x50 attr=1 SerializeField
#   field _textClaimed                   UnityEngine.GameObject                             off=0x58 attr=1 SerializeField
#   field _closeButton                   UnityEngine.UI.Button                              off=0x60 attr=1 SerializeField
#   field _closeButtonHidden             UnityEngine.UI.Button                              off=0x68 attr=1 SerializeField
#   field _notificationGo                UnityEngine.GameObject                             off=0x70 attr=1 SerializeField
#   field _handGo                        UnityEngine.GameObject                             off=0x78 attr=1 SerializeField
#   field _panel                         UnityEngine.Transform                              off=0x80 attr=1 SerializeField
#   field _dailyConfig                   DailyMission.DailyConfig                           off=0x88 attr=1 SerializeField
#   field _dailyItems                    System.Collections.Generic.List`1<DailyMission.DailyItemBase> off=0x90 attr=1 SerializeField
#   field _onClosePopupAction            UnityEngine.Events.UnityAction                     off=0x98 attr=1 
## get_IsEnable() -> bool
---- DailyLoginPopup::get_IsEnable 0x2cdf174
02cdf174: ldr     x0, [x0, #0x40]                            ._dailyLoginController
02cdf178: cbz     x0, #0x2cdf184                             
02cdf17c: mov     x1, xzr                                    
02cdf180: b       #0x2cf3af0                                 DailyReward.DailyLoginController::IsEnable
02cdf184: str     x30, [sp, #-0x10]!                         
02cdf188: bl      #0x2b7105c                                 fn_2b7105c
## RegisterCloseCallback(UnityEngine.Events.UnityAction action) -> DailyLoginPopup
---- DailyLoginPopup::RegisterCloseCallback 0x2cdf18c
02cdf18c: stp     x30, x19, [sp, #-0x10]!                    
02cdf190: mov     x19, x0                                    
02cdf194: str     x1, [x0, #0x98]!                           ._onClosePopupAction
02cdf198: bl      #0x2b70d54                                 fn_2b70d54
02cdf19c: mov     x0, x19                                    
02cdf1a0: ldp     x30, x19, [sp], #0x10                      
02cdf1a4: ret                                                
## ShowTutorial(bool value) -> DailyLoginPopup
---- DailyLoginPopup::ShowTutorial 0x2cdf1a8
02cdf1a8: stp     x30, x19, [sp, #-0x10]!                    
02cdf1ac: mov     x19, x0                                    
02cdf1b0: ldr     x0, [x0, #0x78]                            ._handGo
02cdf1b4: cbz     x0, #0x2cdf210                             
02cdf1b8: and     w1, w1, #1                                 
02cdf1bc: mov     x2, xzr                                    
02cdf1c0: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cdf1c4: ldr     x0, [x19, #0x60]                           ._closeButton
02cdf1c8: cbz     x0, #0x2cdf210                             
02cdf1cc: mov     x1, xzr                                    
02cdf1d0: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02cdf1d4: cbz     x0, #0x2cdf210                             
02cdf1d8: mov     w1, #1                                     
02cdf1dc: mov     x2, xzr                                    
02cdf1e0: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cdf1e4: ldr     x0, [x19, #0x68]                           ._closeButtonHidden
02cdf1e8: cbz     x0, #0x2cdf210                             
02cdf1ec: mov     x1, xzr                                    
02cdf1f0: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02cdf1f4: cbz     x0, #0x2cdf210                             
02cdf1f8: mov     w1, #1                                     
02cdf1fc: mov     x2, xzr                                    
02cdf200: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cdf204: mov     x0, x19                                    
02cdf208: ldp     x30, x19, [sp], #0x10                      
02cdf20c: ret                                                
02cdf210: bl      #0x2b7105c                                 fn_2b7105c
## OnInit(UIManager uiManager) -> void
---- DailyLoginPopup::OnInit 0x2cdf214
02cdf214: stp     x30, x21, [sp, #-0x20]!                    
02cdf218: stp     x20, x19, [sp, #0x10]                      
02cdf21c: adrp    x21, #0x662f000                            
02cdf220: mov     x20, x1                                    
02cdf224: mov     x19, x0                                    
02cdf228: ldrb    w8, [x21, #0xd9b]                          
02cdf22c: tbnz    w8, #0, #0x2cdf244                         
02cdf230: adrp    x0, #0x6267000                             
02cdf234: ldr     x0, [x0, #0xe68]                           MS:System.Collections.Generic.List`1::get_Count
02cdf238: bl      #0x2b70db0                                 fn_2b70db0
02cdf23c: mov     w8, #1                                     
02cdf240: strb    w8, [x21, #0xd9b]                          
02cdf244: mov     x0, x19                                    
02cdf248: mov     x1, x20                                    
02cdf24c: bl      #0x2cdd3c4                                 UIBase::OnInit
02cdf250: mov     x0, x19                                    
02cdf254: bl      #0x2cdf288                                 DailyLoginPopup::SetUpData
02cdf258: mov     x0, x19                                    
02cdf25c: bl      #0x2cdf324                                 DailyLoginPopup::RefreshStatus
02cdf260: ldr     x8, [x19, #0x90]                           ._dailyItems
02cdf264: cbz     x8, #0x2cdf284                             
02cdf268: ldr     x9, [x19, #0x40]                           ._dailyLoginController
02cdf26c: cbz     x9, #0x2cdf284                             
02cdf270: ldr     w8, [x8, #0x18]                            
02cdf274: ldp     x20, x19, [sp, #0x10]                      
02cdf278: str     w8, [x9, #0x20]                            
02cdf27c: ldp     x30, x21, [sp], #0x20                      
02cdf280: ret                                                
02cdf284: bl      #0x2b7105c                                 fn_2b7105c
## OnEnable() -> void
---- DailyLoginPopup::OnEnable 0x2cdf48c
02cdf48c: stp     x30, x23, [sp, #-0x30]!                    
02cdf490: stp     x22, x21, [sp, #0x10]                      
02cdf494: stp     x20, x19, [sp, #0x20]                      
02cdf498: adrp    x20, #0x662f000                            
02cdf49c: mov     x19, x0                                    
02cdf4a0: ldrb    w8, [x20, #0xd9c]                          
02cdf4a4: tbnz    w8, #0, #0x2cdf4d4                         
02cdf4a8: adrp    x0, #0x6267000                             
02cdf4ac: ldr     x0, [x0, #0xe98]                           M:DailyLoginPopup::OnClaimButtonHandler
02cdf4b0: bl      #0x2b70db0                                 fn_2b70db0
02cdf4b4: adrp    x0, #0x6267000                             
02cdf4b8: ldr     x0, [x0, #0xea0]                           M:DailyLoginPopup::OnCloseButtonClicked
02cdf4bc: bl      #0x2b70db0                                 fn_2b70db0
02cdf4c0: adrp    x0, #0x6265000                             
02cdf4c4: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02cdf4c8: bl      #0x2b70db0                                 fn_2b70db0
02cdf4cc: mov     w8, #1                                     
02cdf4d0: strb    w8, [x20, #0xd9c]                          
02cdf4d4: ldr     x8, [x19, #0x48]                           ._claimButton
02cdf4d8: cbz     x8, #0x2cdf5ac                             
02cdf4dc: adrp    x22, #0x6265000                            
02cdf4e0: adrp    x21, #0x6267000                            
02cdf4e4: ldr     x22, [x22, #0x3f0]                         T:UnityEngine.Events.UnityAction
02cdf4e8: ldr     x21, [x21, #0xe98]                         M:DailyLoginPopup::OnClaimButtonHandler
02cdf4ec: ldr     x20, [x8, #0x100]                          
02cdf4f0: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02cdf4f4: bl      #0x2b7104c                                 fn_2b7104c
02cdf4f8: ldr     x2, [x21]                                  S:'didu'
02cdf4fc: mov     x1, x19                                    
02cdf500: mov     x3, xzr                                    
02cdf504: mov     x21, x0                                    
02cdf508: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02cdf50c: cbz     x20, #0x2cdf5ac                            
02cdf510: mov     x0, x20                                    
02cdf514: mov     x1, x21                                    
02cdf518: mov     x2, xzr                                    
02cdf51c: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02cdf520: ldr     x8, [x19, #0x60]                           ._closeButton
02cdf524: cbz     x8, #0x2cdf5ac                             
02cdf528: adrp    x23, #0x6267000                            
02cdf52c: ldr     x23, [x23, #0xea0]                         M:DailyLoginPopup::OnCloseButtonClicked
02cdf530: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02cdf534: ldr     x20, [x8, #0x100]                          
02cdf538: bl      #0x2b7104c                                 fn_2b7104c
02cdf53c: ldr     x2, [x23]                                  S:'didu'
02cdf540: mov     x1, x19                                    
02cdf544: mov     x3, xzr                                    
02cdf548: mov     x21, x0                                    
02cdf54c: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02cdf550: cbz     x20, #0x2cdf5ac                            
02cdf554: mov     x0, x20                                    
02cdf558: mov     x1, x21                                    
02cdf55c: mov     x2, xzr                                    
02cdf560: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02cdf564: ldr     x8, [x19, #0x68]                           ._closeButtonHidden
02cdf568: cbz     x8, #0x2cdf5ac                             
02cdf56c: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02cdf570: ldr     x20, [x8, #0x100]                          
02cdf574: bl      #0x2b7104c                                 fn_2b7104c
02cdf578: ldr     x2, [x23]                                  S:'didu'
02cdf57c: mov     x1, x19                                    
02cdf580: mov     x3, xzr                                    
02cdf584: mov     x21, x0                                    
02cdf588: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02cdf58c: cbz     x20, #0x2cdf5ac                            
02cdf590: mov     x0, x20                                    
02cdf594: mov     x1, x21                                    
02cdf598: mov     x2, xzr                                    
02cdf59c: ldp     x20, x19, [sp, #0x20]                      
02cdf5a0: ldp     x22, x21, [sp, #0x10]                      
02cdf5a4: ldp     x30, x23, [sp], #0x30                      
02cdf5a8: b       #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02cdf5ac: bl      #0x2b7105c                                 fn_2b7105c
## OnDisable() -> void
---- DailyLoginPopup::OnDisable 0x2cdf5b0
02cdf5b0: stp     x30, x23, [sp, #-0x30]!                    
02cdf5b4: stp     x22, x21, [sp, #0x10]                      
02cdf5b8: stp     x20, x19, [sp, #0x20]                      
02cdf5bc: adrp    x20, #0x662f000                            
02cdf5c0: mov     x19, x0                                    
02cdf5c4: ldrb    w8, [x20, #0xd9d]                          
02cdf5c8: tbnz    w8, #0, #0x2cdf5f8                         
02cdf5cc: adrp    x0, #0x6267000                             
02cdf5d0: ldr     x0, [x0, #0xe98]                           M:DailyLoginPopup::OnClaimButtonHandler
02cdf5d4: bl      #0x2b70db0                                 fn_2b70db0
02cdf5d8: adrp    x0, #0x6267000                             
02cdf5dc: ldr     x0, [x0, #0xea0]                           M:DailyLoginPopup::OnCloseButtonClicked
02cdf5e0: bl      #0x2b70db0                                 fn_2b70db0
02cdf5e4: adrp    x0, #0x6265000                             
02cdf5e8: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02cdf5ec: bl      #0x2b70db0                                 fn_2b70db0
02cdf5f0: mov     w8, #1                                     
02cdf5f4: strb    w8, [x20, #0xd9d]                          
02cdf5f8: ldr     x8, [x19, #0x48]                           ._claimButton
02cdf5fc: cbz     x8, #0x2cdf6d0                             
02cdf600: adrp    x22, #0x6265000                            
02cdf604: adrp    x21, #0x6267000                            
02cdf608: ldr     x22, [x22, #0x3f0]                         T:UnityEngine.Events.UnityAction
02cdf60c: ldr     x21, [x21, #0xe98]                         M:DailyLoginPopup::OnClaimButtonHandler
02cdf610: ldr     x20, [x8, #0x100]                          
02cdf614: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02cdf618: bl      #0x2b7104c                                 fn_2b7104c
02cdf61c: ldr     x2, [x21]                                  S:'didu'
02cdf620: mov     x1, x19                                    
02cdf624: mov     x3, xzr                                    
02cdf628: mov     x21, x0                                    
02cdf62c: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02cdf630: cbz     x20, #0x2cdf6d0                            
02cdf634: mov     x0, x20                                    
02cdf638: mov     x1, x21                                    
02cdf63c: mov     x2, xzr                                    
02cdf640: bl      #0x5b4d13c                                 UnityEngine.Events.UnityEvent::RemoveListener
02cdf644: ldr     x8, [x19, #0x60]                           ._closeButton
02cdf648: cbz     x8, #0x2cdf6d0                             
02cdf64c: adrp    x23, #0x6267000                            
02cdf650: ldr     x23, [x23, #0xea0]                         M:DailyLoginPopup::OnCloseButtonClicked
02cdf654: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02cdf658: ldr     x20, [x8, #0x100]                          
02cdf65c: bl      #0x2b7104c                                 fn_2b7104c
02cdf660: ldr     x2, [x23]                                  S:'didu'
02cdf664: mov     x1, x19                                    
02cdf668: mov     x3, xzr                                    
02cdf66c: mov     x21, x0                                    
02cdf670: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02cdf674: cbz     x20, #0x2cdf6d0                            
02cdf678: mov     x0, x20                                    
02cdf67c: mov     x1, x21                                    
02cdf680: mov     x2, xzr                                    
02cdf684: bl      #0x5b4d13c                                 UnityEngine.Events.UnityEvent::RemoveListener
02cdf688: ldr     x8, [x19, #0x68]                           ._closeButtonHidden
02cdf68c: cbz     x8, #0x2cdf6d0                             
02cdf690: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02cdf694: ldr     x20, [x8, #0x100]                          
02cdf698: bl      #0x2b7104c                                 fn_2b7104c
02cdf69c: ldr     x2, [x23]                                  S:'didu'
02cdf6a0: mov     x1, x19                                    
02cdf6a4: mov     x3, xzr                                    
02cdf6a8: mov     x21, x0                                    
02cdf6ac: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02cdf6b0: cbz     x20, #0x2cdf6d0                            
02cdf6b4: mov     x0, x20                                    
02cdf6b8: mov     x1, x21                                    
02cdf6bc: mov     x2, xzr                                    
02cdf6c0: ldp     x20, x19, [sp, #0x20]                      
02cdf6c4: ldp     x22, x21, [sp, #0x10]                      
02cdf6c8: ldp     x30, x23, [sp], #0x30                      
02cdf6cc: b       #0x5b4d13c                                 UnityEngine.Events.UnityEvent::RemoveListener
02cdf6d0: bl      #0x2b7105c                                 fn_2b7105c
## OnCloseButtonClicked() -> void
---- DailyLoginPopup::OnCloseButtonClicked 0x2cdf6d4
02cdf6d4: stp     x30, x19, [sp, #-0x10]!                    
02cdf6d8: mov     x19, x0                                    
02cdf6dc: mov     x0, xzr                                    
02cdf6e0: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02cdf6e4: cbz     x0, #0x2cdf71c                             
02cdf6e8: movi    d1, #0000000000000000                      
02cdf6ec: movi    d2, #0000000000000000                      
02cdf6f0: mov     w1, #1                                     
02cdf6f4: fmov    s0, #1.00000000                            
02cdf6f8: mov     w2, wzr                                    
02cdf6fc: mov     w3, wzr                                    
02cdf700: mov     x4, xzr                                    
02cdf704: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02cdf708: ldr     x8, [x19]                                  
02cdf70c: mov     x0, x19                                    
02cdf710: ldp     x2, x1, [x8, #0x198]                       
02cdf714: ldp     x30, x19, [sp], #0x10                      
02cdf718: br      x2                                         
02cdf71c: bl      #0x2b7105c                                 fn_2b7105c
## OnClaimButtonHandler() -> void
---- DailyLoginPopup::OnClaimButtonHandler 0x2cdf720
02cdf720: stp     x30, x21, [sp, #-0x20]!                    
02cdf724: stp     x20, x19, [sp, #0x10]                      
02cdf728: adrp    x20, #0x662f000                            
02cdf72c: adrp    x21, #0x6267000                            
02cdf730: mov     x19, x0                                    
02cdf734: ldrb    w8, [x20, #0xd9e]                          
02cdf738: ldr     x21, [x21, #0xea8]                         T:Framework.Vibration
02cdf73c: tbnz    w8, #0, #0x2cdf754                         
02cdf740: adrp    x0, #0x6267000                             
02cdf744: ldr     x0, [x0, #0xea8]                           T:Framework.Vibration
02cdf748: bl      #0x2b70db0                                 fn_2b70db0
02cdf74c: mov     w8, #1                                     
02cdf750: strb    w8, [x20, #0xd9e]                          
02cdf754: ldr     x0, [x21]                                  S:'didu'
02cdf758: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02cdf75c: cbnz    w8, #0x2cdf764                             
02cdf760: bl      #0x2b70f30                                 fn_2b70f30
02cdf764: mov     w0, #0x64                                  
02cdf768: mov     w1, #-1                                    
02cdf76c: mov     w2, wzr                                    
02cdf770: mov     x3, xzr                                    
02cdf774: bl      #0x2d6e144                                 Framework.Vibration::Vibrate
02cdf778: mov     x0, xzr                                    
02cdf77c: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02cdf780: cbz     x0, #0x2cdf830                             
02cdf784: movi    d1, #0000000000000000                      
02cdf788: movi    d2, #0000000000000000                      
02cdf78c: mov     w1, #1                                     
02cdf790: fmov    s0, #1.00000000                            
02cdf794: mov     w2, wzr                                    
02cdf798: mov     w3, wzr                                    
02cdf79c: mov     x4, xzr                                    
02cdf7a0: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02cdf7a4: ldr     x0, [x19, #0x60]                           ._closeButton
02cdf7a8: cbz     x0, #0x2cdf830                             
02cdf7ac: mov     x1, xzr                                    
02cdf7b0: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02cdf7b4: cbz     x0, #0x2cdf830                             
02cdf7b8: mov     w1, #1                                     
02cdf7bc: mov     x2, xzr                                    
02cdf7c0: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cdf7c4: ldr     x0, [x19, #0x68]                           ._closeButtonHidden
02cdf7c8: cbz     x0, #0x2cdf830                             
02cdf7cc: mov     x1, xzr                                    
02cdf7d0: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02cdf7d4: cbz     x0, #0x2cdf830                             
02cdf7d8: mov     w1, #1                                     
02cdf7dc: mov     x2, xzr                                    
02cdf7e0: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cdf7e4: ldr     x0, [x19, #0x40]                           ._dailyLoginController
02cdf7e8: cbz     x0, #0x2cdf830                             
02cdf7ec: mov     x1, xzr                                    
02cdf7f0: bl      #0x2cf3b90                                 DailyReward.DailyLoginController::GetLoginDayIndex
02cdf7f4: mov     w1, w0                                     
02cdf7f8: mov     x0, x19                                    
02cdf7fc: bl      #0x2cdf834                                 DailyLoginPopup::ClaimReward
02cdf800: ldr     x0, [x19, #0x40]                           ._dailyLoginController
02cdf804: cbz     x0, #0x2cdf830                             
02cdf808: mov     x1, xzr                                    
02cdf80c: bl      #0x2cf3cec                                 DailyReward.DailyLoginController::SaveLoginData
02cdf810: mov     x0, x19                                    
02cdf814: bl      #0x2cdf324                                 DailyLoginPopup::RefreshStatus
02cdf818: ldr     x8, [x19]                                  
02cdf81c: mov     x0, x19                                    
02cdf820: ldp     x20, x19, [sp, #0x10]                      
02cdf824: ldp     x2, x1, [x8, #0x198]                       
02cdf828: ldp     x30, x21, [sp], #0x20                      
02cdf82c: br      x2                                         
02cdf830: bl      #0x2b7105c                                 fn_2b7105c
## ClaimReward(int index) -> void
---- DailyLoginPopup::ClaimReward 0x2cdf834
02cdf834: stp     x30, x21, [sp, #-0x20]!                    
02cdf838: stp     x20, x19, [sp, #0x10]                      
02cdf83c: adrp    x21, #0x662f000                            
02cdf840: mov     w19, w1                                    
02cdf844: mov     x20, x0                                    
02cdf848: ldrb    w8, [x21, #0xd9f]                          
02cdf84c: tbnz    w8, #0, #0x2cdf870                         
02cdf850: adrp    x0, #0x6267000                             
02cdf854: ldr     x0, [x0, #0xe68]                           MS:System.Collections.Generic.List`1::get_Count
02cdf858: bl      #0x2b70db0                                 fn_2b70db0
02cdf85c: adrp    x0, #0x6267000                             
02cdf860: ldr     x0, [x0, #0xe70]                           MS:System.Collections.Generic.List`1::get_Item
02cdf864: bl      #0x2b70db0                                 fn_2b70db0
02cdf868: mov     w8, #1                                     
02cdf86c: strb    w8, [x21, #0xd9f]                          
02cdf870: tbnz    w19, #0x1f, #0x2cdf8b4                     
02cdf874: ldr     x0, [x20, #0x90]                           ._dailyItems
02cdf878: cbz     x0, #0x2cdf8c0                             
02cdf87c: ldr     w8, [x0, #0x18]                            S:'android.content.Intent'
02cdf880: cmp     w8, w19                                    
02cdf884: b.le    #0x2cdf8b4                                 
02cdf888: adrp    x8, #0x6267000                             
02cdf88c: mov     w1, w19                                    
02cdf890: ldr     x8, [x8, #0xe70]                           MS:System.Collections.Generic.List`1::get_Item
02cdf894: ldr     x2, [x8]                                   S:'didu'
02cdf898: bl      #0x35a8f3c                                 fn_35a8f3c
02cdf89c: cbz     x0, #0x2cdf8c0                             
02cdf8a0: ldr     x8, [x0]                                   S:'didu'
02cdf8a4: ldp     x20, x19, [sp, #0x10]                      
02cdf8a8: ldp     x2, x1, [x8, #0x1a8]                       
02cdf8ac: ldp     x30, x21, [sp], #0x20                      
02cdf8b0: br      x2                                         
02cdf8b4: ldp     x20, x19, [sp, #0x10]                      
02cdf8b8: ldp     x30, x21, [sp], #0x20                      
02cdf8bc: ret                                                
02cdf8c0: bl      #0x2b7105c                                 fn_2b7105c
## OnShow() -> void
---- DailyLoginPopup::OnShow 0x2cdf8c4
02cdf8c4: stp     x30, x23, [sp, #-0x30]!                    
02cdf8c8: stp     x22, x21, [sp, #0x10]                      
02cdf8cc: stp     x20, x19, [sp, #0x20]                      
02cdf8d0: adrp    x20, #0x662f000                            
02cdf8d4: mov     x19, x0                                    
02cdf8d8: ldrb    w8, [x20, #0xda0]                          
02cdf8dc: tbnz    w8, #0, #0x2cdf900                         
02cdf8e0: adrp    x0, #0x6266000                             
02cdf8e4: ldr     x0, [x0, #0xaa0]                           MS:MonoSingleton`1::get_Instance
02cdf8e8: bl      #0x2b70db0                                 fn_2b70db0
02cdf8ec: adrp    x0, #0x6266000                             
02cdf8f0: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02cdf8f4: bl      #0x2b70db0                                 fn_2b70db0
02cdf8f8: mov     w8, #1                                     
02cdf8fc: strb    w8, [x20, #0xda0]                          
02cdf900: movi    d0, #0000000000000000                      
02cdf904: ldr     x0, [x19, #0x28]                           
02cdf908: mov     w1, #1                                     
02cdf90c: mov     x2, xzr                                    
02cdf910: mov     w21, #1                                    
02cdf914: bl      #0x2cf1928                                 FrameWorkUtility::SetActive
02cdf918: mov     x0, x19                                    
02cdf91c: strb    w21, [x19, #0x20]                          
02cdf920: bl      #0x2cdf324                                 DailyLoginPopup::RefreshStatus
02cdf924: ldr     x0, [x19, #0x80]                           ._panel
02cdf928: mov     w1, wzr                                    
02cdf92c: mov     x2, xzr                                    
02cdf930: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02cdf934: adrp    x22, #0x662f000                            
02cdf938: ldr     x20, [x19, #0x80]                          ._panel
02cdf93c: ldrb    w8, [x22, #0x91a]                          
02cdf940: cbnz    w8, #0x2cdf954                             
02cdf944: adrp    x0, #0x6264000                             
02cdf948: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02cdf94c: bl      #0x2b70db0                                 fn_2b70db0
02cdf950: strb    w21, [x22, #0x91a]                         
02cdf954: cbz     x20, #0x2cdfa7c                            
02cdf958: adrp    x22, #0x6264000                            
02cdf95c: adrp    x21, #0x6266000                            
02cdf960: mov     x0, x20                                    
02cdf964: ldr     x22, [x22, #0xd8]                          T:UnityEngine.Vector3
02cdf968: mov     x1, xzr                                    
02cdf96c: ldr     x8, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cdf970: ldr     x8, [x8, #0xb8]                            
02cdf974: ldr     x21, [x21, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02cdf978: ldp     s1, s2, [x8, #4]                           
02cdf97c: ldr     s0, [x8]                                   
02cdf980: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02cdf984: adrp    x23, #0x662f000                            
02cdf988: ldr     x20, [x19, #0x80]                          ._panel
02cdf98c: ldrb    w8, [x23, #0xa74]                          
02cdf990: cbnz    w8, #0x2cdf9a8                             
02cdf994: adrp    x0, #0x6264000                             
02cdf998: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02cdf99c: bl      #0x2b70db0                                 fn_2b70db0
02cdf9a0: mov     w8, #1                                     
02cdf9a4: strb    w8, [x23, #0xa74]                          
02cdf9a8: ldr     x8, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cdf9ac: mov     x0, x20                                    
02cdf9b0: mov     x1, xzr                                    
02cdf9b4: ldr     x8, [x8, #0xb8]                            
02cdf9b8: ldp     s0, s1, [x8, #0xc]                         
02cdf9bc: ldr     s2, [x8, #0x14]                            
02cdf9c0: adrp    x8, #0x1084000                             
02cdf9c4: ldr     s3, [x8, #0xe60]                           [1084e60]=bc8efa353eb33333 f=0.35,-0.0174533
02cdf9c8: bl      #0x2d98af8                                 DG.Tweening.ShortcutExtensions::DOScale
02cdf9cc: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cdf9d0: mov     w1, #0x1b                                  
02cdf9d4: bl      #0x336fa0c                                 fn_336fa0c
02cdf9d8: ldr     x0, [x19, #0x40]                           ._dailyLoginController
02cdf9dc: cbz     x0, #0x2cdfa7c                             
02cdf9e0: mov     x1, xzr                                    
02cdf9e4: bl      #0x2cf3af0                                 DailyReward.DailyLoginController::IsEnable
02cdf9e8: ldr     x8, [x19, #0x48]                           ._claimButton
02cdf9ec: cbz     x8, #0x2cdfa7c                             
02cdf9f0: mov     w20, w0                                    
02cdf9f4: mov     x0, x8                                     
02cdf9f8: mov     x1, xzr                                    
02cdf9fc: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02cdfa00: cbz     x0, #0x2cdfa7c                             
02cdfa04: and     w1, w20, #1                                
02cdfa08: mov     x2, xzr                                    
02cdfa0c: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cdfa10: ldr     x0, [x19, #0x50]                           ._unClaimGo
02cdfa14: cbz     x0, #0x2cdfa7c                             
02cdfa18: eor     w20, w20, #1                               
02cdfa1c: mov     x2, xzr                                    
02cdfa20: and     w1, w20, #1                                
02cdfa24: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cdfa28: ldr     x0, [x19, #0x58]                           ._textClaimed
02cdfa2c: cbz     x0, #0x2cdfa7c                             
02cdfa30: adrp    x21, #0x6266000                            
02cdfa34: and     w1, w20, #1                                
02cdfa38: mov     x2, xzr                                    
02cdfa3c: ldr     x21, [x21, #0xaa0]                         MS:MonoSingleton`1::get_Instance
02cdfa40: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cdfa44: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cdfa48: bl      #0x3769600                                 fn_3769600
02cdfa4c: mov     x20, x0                                    
02cdfa50: mov     x0, x19                                    
02cdfa54: mov     x1, xzr                                    
02cdfa58: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cdfa5c: cbz     x20, #0x2cdfa7c                            
02cdfa60: mov     x1, x0                                     
02cdfa64: mov     x0, x20                                    
02cdfa68: bl      #0x2cdac14                                 MoneyManager::SetCurrentParent
02cdfa6c: ldp     x20, x19, [sp, #0x20]                      
02cdfa70: ldp     x22, x21, [sp, #0x10]                      
02cdfa74: ldp     x30, x23, [sp], #0x30                      
02cdfa78: b       #0x2cdabd8                                 MoneyManager::UpdateParent
02cdfa7c: bl      #0x2b7105c                                 fn_2b7105c
## OnHide() -> void
---- DailyLoginPopup::OnHide 0x2cdfa80
02cdfa80: stp     x30, x21, [sp, #-0x20]!                    
02cdfa84: stp     x20, x19, [sp, #0x10]                      
02cdfa88: adrp    x21, #0x662f000                            
02cdfa8c: adrp    x20, #0x6266000                            
02cdfa90: mov     x19, x0                                    
02cdfa94: ldrb    w8, [x21, #0xda1]                          
02cdfa98: ldr     x20, [x20, #0xaa0]                         MS:MonoSingleton`1::get_Instance
02cdfa9c: tbnz    w8, #0, #0x2cdfac0                         
02cdfaa0: adrp    x0, #0x6266000                             
02cdfaa4: ldr     x0, [x0, #0xaa0]                           MS:MonoSingleton`1::get_Instance
02cdfaa8: bl      #0x2b70db0                                 fn_2b70db0
02cdfaac: adrp    x0, #0x6267000                             
02cdfab0: ldr     x0, [x0, #0xd58]                           MS:UIManager::GetScreen
02cdfab4: bl      #0x2b70db0                                 fn_2b70db0
02cdfab8: mov     w8, #1                                     
02cdfabc: strb    w8, [x21, #0xda1]                          
02cdfac0: movi    d0, #0000000000000000                      
02cdfac4: ldr     x0, [x19, #0x28]                           
02cdfac8: mov     w1, wzr                                    
02cdfacc: mov     x2, xzr                                    
02cdfad0: bl      #0x2cf1928                                 FrameWorkUtility::SetActive
02cdfad4: mov     x0, x19                                    
02cdfad8: strb    wzr, [x19, #0x20]                          
02cdfadc: bl      #0x2cdfb5c                                 DailyLoginPopup::CheckNotification
02cdfae0: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cdfae4: bl      #0x3769600                                 fn_3769600
02cdfae8: ldr     x8, [x19, #0x30]                           
02cdfaec: cbz     x8, #0x2cdfb58                             
02cdfaf0: adrp    x9, #0x6267000                             
02cdfaf4: mov     x20, x0                                    
02cdfaf8: mov     x0, x8                                     
02cdfafc: ldr     x9, [x9, #0xd58]                           MS:UIManager::GetScreen
02cdfb00: ldr     x1, [x9]                                   S:'didu'
02cdfb04: bl      #0x33fbbd0                                 fn_33fbbd0
02cdfb08: cbz     x0, #0x2cdfb58                             
02cdfb0c: mov     x1, xzr                                    
02cdfb10: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cdfb14: cbz     x20, #0x2cdfb58                            
02cdfb18: mov     x1, x0                                     
02cdfb1c: mov     x0, x20                                    
02cdfb20: bl      #0x2cdac14                                 MoneyManager::SetCurrentParent
02cdfb24: bl      #0x2cdabd8                                 MoneyManager::UpdateParent
02cdfb28: ldr     x8, [x19, #0x98]!                          ._onClosePopupAction
02cdfb2c: cbz     x8, #0x2cdfb40                             
02cdfb30: ldr     x9, [x8, #0x18]                            
02cdfb34: ldr     x0, [x8, #0x40]                            
02cdfb38: ldr     x1, [x8, #0x28]                            
02cdfb3c: blr     x9                                         
02cdfb40: mov     x0, x19                                    
02cdfb44: str     xzr, [x19]                                 
02cdfb48: mov     x1, xzr                                    
02cdfb4c: ldp     x20, x19, [sp, #0x10]                      
02cdfb50: ldp     x30, x21, [sp], #0x20                      
02cdfb54: b       #0x2b70d54                                 
02cdfb58: bl      #0x2b7105c                                 fn_2b7105c
## SetUpData() -> void
---- DailyLoginPopup::SetUpData 0x2cdf288
02cdf288: stp     x30, x21, [sp, #-0x20]!                    
02cdf28c: stp     x20, x19, [sp, #0x10]                      
02cdf290: adrp    x20, #0x662f000                            
02cdf294: mov     x19, x0                                    
02cdf298: ldrb    w8, [x20, #0xda2]                          
02cdf29c: tbnz    w8, #0, #0x2cdf2c0                         
02cdf2a0: adrp    x0, #0x6267000                             
02cdf2a4: ldr     x0, [x0, #0xe68]                           MS:System.Collections.Generic.List`1::get_Count
02cdf2a8: bl      #0x2b70db0                                 fn_2b70db0
02cdf2ac: adrp    x0, #0x6267000                             
02cdf2b0: ldr     x0, [x0, #0xe70]                           MS:System.Collections.Generic.List`1::get_Item
02cdf2b4: bl      #0x2b70db0                                 fn_2b70db0
02cdf2b8: mov     w8, #1                                     
02cdf2bc: strb    w8, [x20, #0xda2]                          
02cdf2c0: ldr     x0, [x19, #0x90]                           ._dailyItems
02cdf2c4: cbz     x0, #0x2cdf314                             
02cdf2c8: adrp    x21, #0x6267000                            
02cdf2cc: mov     w20, wzr                                   
02cdf2d0: ldr     x21, [x21, #0xe70]                         MS:System.Collections.Generic.List`1::get_Item
02cdf2d4: ldr     w8, [x0, #0x18]                            S:'android.content.Intent'
02cdf2d8: cmp     w20, w8                                    
02cdf2dc: b.ge    #0x2cdf318                                 
02cdf2e0: ldr     x2, [x21]                                  S:'didu'
02cdf2e4: mov     w1, w20                                    
02cdf2e8: bl      #0x35a8f3c                                 fn_35a8f3c
02cdf2ec: cbz     x0, #0x2cdf314                             
02cdf2f0: ldr     x8, [x0]                                   S:'didu'
02cdf2f4: ldr     x3, [x19, #0x40]                           ._dailyLoginController
02cdf2f8: mov     w1, w20                                    
02cdf2fc: ldr     x2, [x19, #0x88]                           ._dailyConfig
02cdf300: ldp     x9, x4, [x8, #0x178]                       
02cdf304: blr     x9                                         
02cdf308: ldr     x0, [x19, #0x90]                           ._dailyItems
02cdf30c: add     w20, w20, #1                               
02cdf310: cbnz    x0, #0x2cdf2d4                             
02cdf314: bl      #0x2b7105c                                 fn_2b7105c
02cdf318: ldp     x20, x19, [sp, #0x10]                      
02cdf31c: ldp     x30, x21, [sp], #0x20                      
02cdf320: ret                                                
## RefreshStatus() -> void
---- DailyLoginPopup::RefreshStatus 0x2cdf324
02cdf324: stp     x30, x23, [sp, #-0x30]!                    
02cdf328: stp     x22, x21, [sp, #0x10]                      
02cdf32c: stp     x20, x19, [sp, #0x20]                      
02cdf330: adrp    x20, #0x662f000                            
02cdf334: adrp    x23, #0x6267000                            
02cdf338: mov     x19, x0                                    
02cdf33c: ldrb    w8, [x20, #0xda3]                          
02cdf340: ldr     x23, [x23, #0xe78]                         T:DailyLoginPopup/<>c
02cdf344: tbnz    w8, #0, #0x2cdf380                         
02cdf348: adrp    x0, #0x6267000                             
02cdf34c: ldr     x0, [x0, #0xe80]                           T:type53125(k15)
02cdf350: bl      #0x2b70db0                                 fn_2b70db0
02cdf354: adrp    x0, #0x6267000                             
02cdf358: ldr     x0, [x0, #0xe88]                           MS:System.Collections.Generic.List`1::ForEach
02cdf35c: bl      #0x2b70db0                                 fn_2b70db0
02cdf360: adrp    x0, #0x6267000                             
02cdf364: ldr     x0, [x0, #0xe90]                           M:DailyLoginPopup/<>c::<RefreshStatus>b__26_0
02cdf368: bl      #0x2b70db0                                 fn_2b70db0
02cdf36c: adrp    x0, #0x6267000                             
02cdf370: ldr     x0, [x0, #0xe78]                           T:DailyLoginPopup/<>c
02cdf374: bl      #0x2b70db0                                 fn_2b70db0
02cdf378: mov     w8, #1                                     
02cdf37c: strb    w8, [x20, #0xda3]                          
02cdf380: ldr     x0, [x23]                                  S:'didu'
02cdf384: ldr     x20, [x19, #0x90]                          ._dailyItems
02cdf388: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02cdf38c: cbnz    w8, #0x2cdf398                             
02cdf390: bl      #0x2b70f30                                 fn_2b70f30
02cdf394: ldr     x0, [x23]                                  S:'didu'
02cdf398: ldr     x8, [x0, #0xb8]                            M:Framework.SceneUtils/<CRUnloadSceneAsync>d__2::System.Collections.IEnumerator.Reset
02cdf39c: ldr     x21, [x8, #8]                              
02cdf3a0: cbnz    x21, #0x2cdf3fc                            
02cdf3a4: ldr     w9, [x0, #0xe4]                            [62670e4]=0 f=0,0
02cdf3a8: cbnz    w9, #0x2cdf3b8                             
02cdf3ac: bl      #0x2b70f30                                 fn_2b70f30
02cdf3b0: ldr     x8, [x23]                                  S:'didu'
02cdf3b4: ldr     x8, [x8, #0xb8]                            
02cdf3b8: adrp    x9, #0x6267000                             
02cdf3bc: ldr     x9, [x9, #0xe80]                           T:type53125(k15)
02cdf3c0: ldr     x22, [x8]                                  
02cdf3c4: ldr     x0, [x9]                                   S:'didu'
02cdf3c8: bl      #0x2b7104c                                 fn_2b7104c
02cdf3cc: adrp    x8, #0x6267000                             
02cdf3d0: mov     x1, x22                                    
02cdf3d4: mov     x3, xzr                                    
02cdf3d8: ldr     x8, [x8, #0xe90]                           M:DailyLoginPopup/<>c::<RefreshStatus>b__26_0
02cdf3dc: mov     x21, x0                                    
02cdf3e0: ldr     x2, [x8]                                   S:'didu'
02cdf3e4: bl      #0x453418c                                 fn_453418c
02cdf3e8: ldr     x8, [x23]                                  S:'didu'
02cdf3ec: mov     x1, x21                                    
02cdf3f0: ldr     x0, [x8, #0xb8]                            M:Framework.SceneUtils/<CRUnloadSceneAsync>d__2::System.Collections.IEnumerator.Reset
02cdf3f4: str     x21, [x0, #8]!                             
02cdf3f8: bl      #0x2b70d54                                 fn_2b70d54
02cdf3fc: cbz     x20, #0x2cdf488                            
02cdf400: adrp    x8, #0x6267000                             
02cdf404: mov     x0, x20                                    
02cdf408: mov     x1, x21                                    
02cdf40c: ldr     x8, [x8, #0xe88]                           MS:System.Collections.Generic.List`1::ForEach
02cdf410: ldr     x2, [x8]                                   S:'didu'
02cdf414: bl      #0x35a9ce4                                 fn_35a9ce4
02cdf418: ldr     x0, [x19, #0x40]                           ._dailyLoginController
02cdf41c: cbz     x0, #0x2cdf488                             
02cdf420: mov     x1, xzr                                    
02cdf424: bl      #0x2cf3af0                                 DailyReward.DailyLoginController::IsEnable
02cdf428: ldr     x8, [x19, #0x48]                           ._claimButton
02cdf42c: cbz     x8, #0x2cdf488                             
02cdf430: mov     w20, w0                                    
02cdf434: mov     x0, x8                                     
02cdf438: mov     x1, xzr                                    
02cdf43c: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02cdf440: cbz     x0, #0x2cdf488                             
02cdf444: and     w1, w20, #1                                
02cdf448: mov     x2, xzr                                    
02cdf44c: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cdf450: ldr     x0, [x19, #0x50]                           ._unClaimGo
02cdf454: cbz     x0, #0x2cdf488                             
02cdf458: eor     w20, w20, #1                               
02cdf45c: mov     x2, xzr                                    
02cdf460: and     w1, w20, #1                                
02cdf464: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cdf468: ldr     x0, [x19, #0x58]                           ._textClaimed
02cdf46c: cbz     x0, #0x2cdf488                             
02cdf470: and     w1, w20, #1                                
02cdf474: ldp     x20, x19, [sp, #0x20]                      
02cdf478: ldp     x22, x21, [sp, #0x10]                      
02cdf47c: mov     x2, xzr                                    
02cdf480: ldp     x30, x23, [sp], #0x30                      
02cdf484: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cdf488: bl      #0x2b7105c                                 fn_2b7105c
## CheckNotification() -> void
---- DailyLoginPopup::CheckNotification 0x2cdfb5c
02cdfb5c: stp     x30, x19, [sp, #-0x10]!                    
02cdfb60: mov     x8, x0                                     
02cdfb64: ldr     x0, [x0, #0x40]                            ._dailyLoginController
02cdfb68: cbz     x0, #0x2cdfb90                             
02cdfb6c: ldr     x19, [x8, #0x70]                           
02cdfb70: mov     x1, xzr                                    
02cdfb74: bl      #0x2cf3af0                                 DailyReward.DailyLoginController::IsEnable
02cdfb78: cbz     x19, #0x2cdfb90                            
02cdfb7c: and     w1, w0, #1                                 
02cdfb80: mov     x0, x19                                    
02cdfb84: mov     x2, xzr                                    
02cdfb88: ldp     x30, x19, [sp], #0x10                      
02cdfb8c: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cdfb90: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- DailyLoginPopup::.ctor 0x2cdfb94
02cdfb94: mov     x1, xzr                                    
02cdfb98: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
