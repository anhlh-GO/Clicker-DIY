#### CLASS Profile.ProfileManager parent= MonoSingleton`1<Profile.ProfileManager>
#   field User                           Profile.UserProfile                                off=0x20 attr=6 
#   field SAVE                           string                                             off=0x0 attr=8051 
#   field OnExperiencePointObtained      System.Action                                      off=0x28 attr=6 
#   field OnNameChanged                  System.Action                                      off=0x30 attr=6 
#   field OnAvatarChanged                System.Action`1<UnityEngine.Sprite>                off=0x38 attr=6 
#   field OnLevelUp                      System.Action                                      off=0x40 attr=6 
#   field _requiredExp                   float                                              off=0x48 attr=1 
#   field _currentExp                    float                                              off=0x4c attr=1 
## Initiate() -> void
---- Profile.ProfileManager::Initiate 0x2cf3e60
02cf3e60: stp     x30, x21, [sp, #-0x20]!                    
02cf3e64: stp     x20, x19, [sp, #0x10]                      
02cf3e68: adrp    x20, #0x662f000                            
02cf3e6c: adrp    x21, #0x6268000                            
02cf3e70: mov     x19, x0                                    
02cf3e74: ldrb    w8, [x20, #0xe7c]                          
02cf3e78: ldr     x21, [x21, #0x6c8]                         MS:MonoSingleton`1::Initiate
02cf3e7c: tbnz    w8, #0, #0x2cf3e94                         
02cf3e80: adrp    x0, #0x6268000                             
02cf3e84: ldr     x0, [x0, #0x6c8]                           MS:MonoSingleton`1::Initiate
02cf3e88: bl      #0x2b70db0                                 fn_2b70db0
02cf3e8c: mov     w8, #1                                     
02cf3e90: strb    w8, [x20, #0xe7c]                          
02cf3e94: ldr     x1, [x21]                                  S:'{0}/2'
02cf3e98: mov     x0, x19                                    
02cf3e9c: bl      #0x3769de4                                 fn_3769de4
02cf3ea0: mov     x0, x19                                    
02cf3ea4: ldp     x20, x19, [sp, #0x10]                      
02cf3ea8: ldp     x30, x21, [sp], #0x20                      
02cf3eac: b       #0x2cf3eb0                                 Profile.ProfileManager::Load
## SetName(string name) -> void
---- Profile.ProfileManager::SetName 0x2cf3f44
02cf3f44: stp     x30, x21, [sp, #-0x20]!                    
02cf3f48: stp     x20, x19, [sp, #0x10]                      
02cf3f4c: adrp    x21, #0x662f000                            
02cf3f50: mov     x20, x1                                    
02cf3f54: mov     x19, x0                                    
02cf3f58: ldrb    w8, [x21, #0xe7d]                          
02cf3f5c: tbnz    w8, #0, #0x2cf3f74                         
02cf3f60: adrp    x0, #0x6268000                             
02cf3f64: ldr     x0, [x0, #0x6e0]                           S:'You'
02cf3f68: bl      #0x2b70db0                                 fn_2b70db0
02cf3f6c: mov     w8, #1                                     
02cf3f70: strb    w8, [x21, #0xe7d]                          
02cf3f74: ldr     x21, [x19, #0x20]                          .User
02cf3f78: mov     x0, x20                                    
02cf3f7c: mov     x1, xzr                                    
02cf3f80: bl      #0x4ca6234                                 System.String::IsNullOrEmpty
02cf3f84: cbz     x21, #0x2cf3fdc                            
02cf3f88: adrp    x8, #0x6268000                             
02cf3f8c: tst     w0, #1                                     
02cf3f90: ldr     x8, [x8, #0x6e0]                           S:'You'
02cf3f94: ldr     x8, [x8]                                   S:'{0}/2'
02cf3f98: csel    x1, x8, x20, ne                            
02cf3f9c: str     x1, [x21, #0x10]!                          
02cf3fa0: mov     x0, x21                                    
02cf3fa4: bl      #0x2b70d54                                 fn_2b70d54
02cf3fa8: mov     x0, x19                                    
02cf3fac: bl      #0x2cf3fe0                                 Profile.ProfileManager::Save
02cf3fb0: ldr     x8, [x19, #0x30]                           .OnNameChanged
02cf3fb4: cbz     x8, #0x2cf3fd0                             
02cf3fb8: ldp     x20, x19, [sp, #0x10]                      
02cf3fbc: ldr     x0, [x8, #0x40]                            MS:System.Collections.Generic.List`1/Enumerator::Dispose
02cf3fc0: ldr     x1, [x8, #0x28]                            T:LuckyWheelPopup/<>c__DisplayClass52_0
02cf3fc4: ldr     x2, [x8, #0x18]                            M:LuckyWheelPopup/<>c__DisplayClass50_0::<RunAnimation>b__0
02cf3fc8: ldp     x30, x21, [sp], #0x20                      
02cf3fcc: br      x2                                         
02cf3fd0: ldp     x20, x19, [sp, #0x10]                      
02cf3fd4: ldp     x30, x21, [sp], #0x20                      
02cf3fd8: ret                                                
02cf3fdc: bl      #0x2b7105c                                 fn_2b7105c
## SetAvatar(int id, UnityEngine.Sprite avatar) -> void
---- Profile.ProfileManager::SetAvatar 0x2cf403c
02cf403c: str     x30, [sp, #-0x20]!                         
02cf4040: stp     x20, x19, [sp, #0x10]                      
02cf4044: ldr     x8, [x0, #0x20]                            .User
02cf4048: cbz     x8, #0x2cf408c                             
02cf404c: mov     x19, x2                                    
02cf4050: mov     x20, x0                                    
02cf4054: str     w1, [x8, #0x20]                            
02cf4058: bl      #0x2cf3fe0                                 Profile.ProfileManager::Save
02cf405c: ldr     x8, [x20, #0x38]                           .OnAvatarChanged
02cf4060: cbz     x8, #0x2cf4080                             
02cf4064: mov     x1, x19                                    
02cf4068: ldp     x20, x19, [sp, #0x10]                      
02cf406c: ldr     x0, [x8, #0x40]                            
02cf4070: ldr     x2, [x8, #0x28]                            
02cf4074: ldr     x3, [x8, #0x18]                            
02cf4078: ldr     x30, [sp], #0x20                           
02cf407c: br      x3                                         
02cf4080: ldp     x20, x19, [sp, #0x10]                      
02cf4084: ldr     x30, [sp], #0x20                           
02cf4088: ret                                                
02cf408c: bl      #0x2b7105c                                 fn_2b7105c
## GetRequirementExperiencePoint() -> int
---- Profile.ProfileManager::GetRequirementExperiencePoint 0x2cf4090
02cf4090: str     x30, [sp, #-0x20]!                         
02cf4094: stp     x20, x19, [sp, #0x10]                      
02cf4098: adrp    x20, #0x662f000                            
02cf409c: mov     x19, x0                                    
02cf40a0: ldrb    w8, [x20, #0xe7e]                          
02cf40a4: tbnz    w8, #0, #0x2cf40bc                         
02cf40a8: adrp    x0, #0x6266000                             
02cf40ac: ldr     x0, [x0, #0x5e0]                           T:GameConfig
02cf40b0: bl      #0x2b70db0                                 fn_2b70db0
02cf40b4: mov     w8, #1                                     
02cf40b8: strb    w8, [x20, #0xe7e]                          
02cf40bc: ldr     x8, [x19, #0x20]                           .User
02cf40c0: cbz     x8, #0x2cf40fc                             
02cf40c4: adrp    x20, #0x6266000                            
02cf40c8: ldr     x20, [x20, #0x5e0]                         T:GameConfig
02cf40cc: ldr     w19, [x8, #0x18]                           
02cf40d0: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cf40d4: ldr     w9, [x0, #0xe4]                            [62660e4]=0 f=0,0
02cf40d8: cbnz    w9, #0x2cf40e4                             
02cf40dc: bl      #0x2b70f30                                 fn_2b70f30
02cf40e0: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cf40e4: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time'
02cf40e8: ldr     w8, [x8, #0x8c]                            
02cf40ec: mul     w0, w8, w19                                
02cf40f0: ldp     x20, x19, [sp, #0x10]                      
02cf40f4: ldr     x30, [sp], #0x20                           
02cf40f8: ret                                                
02cf40fc: bl      #0x2b7105c                                 fn_2b7105c
## ObtainExperiencePoint() -> bool
---- Profile.ProfileManager::ObtainExperiencePoint 0x2cf4100
02cf4100: sub     sp, sp, #0x40                              
02cf4104: stp     d9, d8, [sp, #0x10]                        
02cf4108: stp     x30, x21, [sp, #0x20]                      
02cf410c: stp     x20, x19, [sp, #0x30]                      
02cf4110: adrp    x20, #0x662f000                            
02cf4114: mov     x19, x0                                    
02cf4118: ldrb    w8, [x20, #0xe7f]                          
02cf411c: tbnz    w8, #0, #0x2cf4140                         
02cf4120: adrp    x0, #0x6263000                             
02cf4124: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02cf4128: bl      #0x2b70db0                                 fn_2b70db0
02cf412c: adrp    x0, #0x6268000                             
02cf4130: ldr     x0, [x0, #0x6e8]                           S:'ObtainExperiencePoint ==============================='
02cf4134: bl      #0x2b70db0                                 fn_2b70db0
02cf4138: mov     w8, #1                                     
02cf413c: strb    w8, [x20, #0xe7f]                          
02cf4140: ldr     x8, [x19, #0x20]                           .User
02cf4144: str     wzr, [sp, #0xc]                            
02cf4148: cbz     x8, #0x2cf422c                             
02cf414c: mov     w9, #0x42480000                            
02cf4150: ldr     s0, [x8, #0x1c]                            
02cf4154: adrp    x20, #0x6268000                            
02cf4158: fmov    s1, w9                                     
02cf415c: adrp    x21, #0x6263000                            
02cf4160: ldr     x20, [x20, #0x6e8]                         S:'ObtainExperiencePoint ==============================='
02cf4164: ldr     x21, [x21, #0x928]                         T:UnityEngine.Debug
02cf4168: mov     x0, x19                                    
02cf416c: fadd    s0, s0, s1                                 
02cf4170: str     s0, [x8, #0x1c]                            
02cf4174: bl      #0x2cf4090                                 Profile.ProfileManager::GetRequirementExperiencePoint
02cf4178: str     w0, [sp, #0xc]                             
02cf417c: add     x0, sp, #0xc                               
02cf4180: mov     x1, xzr                                    
02cf4184: bl      #0x4e0ea3c                                 System.Int32::ToString
02cf4188: ldr     x8, [x20]                                  S:'{0}/2'
02cf418c: mov     x1, x0                                     
02cf4190: mov     x2, xzr                                    
02cf4194: mov     x0, x8                                     
02cf4198: bl      #0x4c9c514                                 System.String::Concat
02cf419c: ldr     x8, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cf41a0: mov     x20, x0                                    
02cf41a4: ldr     w9, [x8, #0xe4]                            
02cf41a8: cbnz    w9, #0x2cf41b4                             
02cf41ac: mov     x0, x8                                     
02cf41b0: bl      #0x2b70f30                                 fn_2b70f30
02cf41b4: mov     x0, x20                                    
02cf41b8: mov     x1, xzr                                    
02cf41bc: bl      #0x5af2840                                 UnityEngine.Debug::LogError
02cf41c0: ldr     x8, [x19, #0x20]                           .User
02cf41c4: cbz     x8, #0x2cf422c                             
02cf41c8: ldr     s8, [x8, #0x1c]                            
02cf41cc: mov     x0, x19                                    
02cf41d0: bl      #0x2cf4090                                 Profile.ProfileManager::GetRequirementExperiencePoint
02cf41d4: scvtf   s9, w0                                     
02cf41d8: mov     x0, x19                                    
02cf41dc: fcmp    s8, s9                                     
02cf41e0: b.lt    #0x2cf41f4                                 
02cf41e4: bl      #0x2cf4230                                 Profile.ProfileManager::LevelUp
02cf41e8: mov     x0, x19                                    
02cf41ec: bl      #0x2cf3fe0                                 Profile.ProfileManager::Save
02cf41f0: b       #0x2cf4210                                 
02cf41f4: bl      #0x2cf3fe0                                 Profile.ProfileManager::Save
02cf41f8: ldr     x8, [x19, #0x28]                           .OnExperiencePointObtained
02cf41fc: cbz     x8, #0x2cf4210                             
02cf4200: ldr     x9, [x8, #0x18]                            
02cf4204: ldr     x0, [x8, #0x40]                            
02cf4208: ldr     x1, [x8, #0x28]                            
02cf420c: blr     x9                                         
02cf4210: fcmp    s8, s9                                     
02cf4214: ldp     x20, x19, [sp, #0x30]                      
02cf4218: ldp     x30, x21, [sp, #0x20]                      
02cf421c: ldp     d9, d8, [sp, #0x10]                        
02cf4220: cset    w0, ge                                     
02cf4224: add     sp, sp, #0x40                              
02cf4228: ret                                                
02cf422c: bl      #0x2b7105c                                 fn_2b7105c
## LevelUpDirectly() -> void
---- Profile.ProfileManager::LevelUpDirectly 0x2cf4270
02cf4270: stp     x30, x19, [sp, #-0x10]!                    
02cf4274: mov     x19, x0                                    
02cf4278: bl      #0x2cf4230                                 Profile.ProfileManager::LevelUp
02cf427c: mov     x0, x19                                    
02cf4280: ldp     x30, x19, [sp], #0x10                      
02cf4284: b       #0x2cf3fe0                                 Profile.ProfileManager::Save
## LevelUp() -> void
---- Profile.ProfileManager::LevelUp 0x2cf4230
02cf4230: ldr     x8, [x0, #0x20]                            .User
02cf4234: cbz     x8, #0x2cf4268                             
02cf4238: ldr     w10, [x8, #0x18]                           
02cf423c: ldr     x9, [x0, #0x40]                            .OnLevelUp
02cf4240: mov     w11, #1                                    
02cf4244: strb    w11, [x8, #0x24]                           
02cf4248: add     w10, w10, #1                               
02cf424c: stp     w10, wzr, [x8, #0x18]                      
02cf4250: cbz     x9, #0x2cf4264                             
02cf4254: ldr     x0, [x9, #0x40]                            
02cf4258: ldr     x1, [x9, #0x28]                            
02cf425c: ldr     x2, [x9, #0x18]                            
02cf4260: br      x2                                         
02cf4264: ret                                                
02cf4268: str     x30, [sp, #-0x10]!                         
02cf426c: bl      #0x2b7105c                                 fn_2b7105c
## Load() -> void
---- Profile.ProfileManager::Load 0x2cf3eb0
02cf3eb0: stp     x30, x21, [sp, #-0x20]!                    
02cf3eb4: stp     x20, x19, [sp, #0x10]                      
02cf3eb8: adrp    x21, #0x662f000                            
02cf3ebc: adrp    x20, #0x6268000                            
02cf3ec0: mov     x19, x0                                    
02cf3ec4: ldrb    w8, [x21, #0xe80]                          
02cf3ec8: ldr     x20, [x20, #0x6d0]                         S:'profile_data'
02cf3ecc: tbnz    w8, #0, #0x2cf3ef0                         
02cf3ed0: adrp    x0, #0x6268000                             
02cf3ed4: ldr     x0, [x0, #0x6d8]                           MS:UnityEngine.JsonUtility::FromJson
02cf3ed8: bl      #0x2b70db0                                 fn_2b70db0
02cf3edc: adrp    x0, #0x6268000                             
02cf3ee0: ldr     x0, [x0, #0x6d0]                           S:'profile_data'
02cf3ee4: bl      #0x2b70db0                                 fn_2b70db0
02cf3ee8: mov     w8, #1                                     
02cf3eec: strb    w8, [x21, #0xe80]                          
02cf3ef0: ldr     x0, [x20]                                  S:'{0}/2'
02cf3ef4: mov     x1, xzr                                    
02cf3ef8: bl      #0x5b2d73c                                 UnityEngine.PlayerPrefs::HasKey
02cf3efc: tbz     w0, #0, #0x2cf3f34                         
02cf3f00: adrp    x21, #0x6268000                            
02cf3f04: mov     x1, xzr                                    
02cf3f08: ldr     x21, [x21, #0x6d8]                         MS:UnityEngine.JsonUtility::FromJson
02cf3f0c: ldr     x0, [x20]                                  S:'{0}/2'
02cf3f10: bl      #0x5b2d6f4                                 UnityEngine.PlayerPrefs::GetString
02cf3f14: ldr     x1, [x21]                                  S:'{0}/2'
02cf3f18: bl      #0x3224ff4                                 fn_3224ff4
02cf3f1c: str     x0, [x19, #0x20]!                          .User
02cf3f20: mov     x1, x0                                     
02cf3f24: mov     x0, x19                                    
02cf3f28: ldp     x20, x19, [sp, #0x10]                      
02cf3f2c: ldp     x30, x21, [sp], #0x20                      
02cf3f30: b       #0x2b70d54                                 
02cf3f34: mov     x0, x19                                    
02cf3f38: ldp     x20, x19, [sp, #0x10]                      
02cf3f3c: ldp     x30, x21, [sp], #0x20                      
02cf3f40: b       #0x2cf3fe0                                 Profile.ProfileManager::Save
## Save() -> void
---- Profile.ProfileManager::Save 0x2cf3fe0
02cf3fe0: stp     x30, x21, [sp, #-0x20]!                    
02cf3fe4: stp     x20, x19, [sp, #0x10]                      
02cf3fe8: adrp    x21, #0x662f000                            
02cf3fec: adrp    x20, #0x6268000                            
02cf3ff0: mov     x19, x0                                    
02cf3ff4: ldrb    w8, [x21, #0xe81]                          
02cf3ff8: ldr     x20, [x20, #0x6d0]                         S:'profile_data'
02cf3ffc: tbnz    w8, #0, #0x2cf4014                         
02cf4000: adrp    x0, #0x6268000                             
02cf4004: ldr     x0, [x0, #0x6d0]                           S:'profile_data'
02cf4008: bl      #0x2b70db0                                 fn_2b70db0
02cf400c: mov     w8, #1                                     
02cf4010: strb    w8, [x21, #0xe81]                          
02cf4014: ldr     x0, [x19, #0x20]                           .User
02cf4018: mov     x1, xzr                                    
02cf401c: bl      #0x5bba258                                 UnityEngine.JsonUtility::ToJson
02cf4020: ldr     x8, [x20]                                  S:'{0}/2'
02cf4024: ldp     x20, x19, [sp, #0x10]                      
02cf4028: mov     x1, x0                                     
02cf402c: mov     x2, xzr                                    
02cf4030: mov     x0, x8                                     
02cf4034: ldp     x30, x21, [sp], #0x20                      
02cf4038: b       #0x5b2d398                                 UnityEngine.PlayerPrefs::SetString
## .ctor() -> void
---- Profile.ProfileManager::.ctor 0x2cf4288
02cf4288: stp     x30, x21, [sp, #-0x20]!                    
02cf428c: stp     x20, x19, [sp, #0x10]                      
02cf4290: adrp    x20, #0x662f000                            
02cf4294: adrp    x21, #0x6268000                            
02cf4298: mov     x19, x0                                    
02cf429c: ldrb    w8, [x20, #0xe82]                          
02cf42a0: ldr     x21, [x21, #0x6f0]                         MS:MonoSingleton`1::.ctor
02cf42a4: tbnz    w8, #0, #0x2cf42bc                         
02cf42a8: adrp    x0, #0x6268000                             
02cf42ac: ldr     x0, [x0, #0x6f0]                           MS:MonoSingleton`1::.ctor
02cf42b0: bl      #0x2b70db0                                 fn_2b70db0
02cf42b4: mov     w8, #1                                     
02cf42b8: strb    w8, [x20, #0xe82]                          
02cf42bc: mov     x0, x19                                    
02cf42c0: ldp     x20, x19, [sp, #0x10]                      
02cf42c4: ldr     x1, [x21]                                  S:'{0}/2'
02cf42c8: ldp     x30, x21, [sp], #0x20                      
02cf42cc: b       #0x3769e18                                 
