#### CLASS NativeAdBase/<RetryGetNative>d__18 parent= object
#   field <>1__state                     int                                                off=0x10 attr=1 
#   field <>2__current                   object                                             off=0x18 attr=1 
#   field delaySeconds                   float                                              off=0x20 attr=6 
#   field <>4__this                      NativeAdBase                                       off=0x28 attr=6 
## .ctor(int <>1__state) -> void
---- NativeAdBase/<RetryGetNative>d__18::.ctor 0x2c96dcc
02c96dcc: str     x30, [sp, #-0x20]!                         
02c96dd0: stp     x20, x19, [sp, #0x10]                      
02c96dd4: mov     w19, w1                                    
02c96dd8: mov     x1, xzr                                    
02c96ddc: mov     x20, x0                                    
02c96de0: bl      #0x4e53e9c                                 System.Object::.ctor
02c96de4: str     w19, [x20, #0x10]                          .<>1__state
02c96de8: ldp     x20, x19, [sp, #0x10]                      
02c96dec: ldr     x30, [sp], #0x20                           
02c96df0: ret                                                
## System.IDisposable.Dispose() -> void
---- NativeAdBase/<RetryGetNative>d__18::System.IDisposable.Dispose 0x2c96f38
02c96f38: ret                                                
## MoveNext() -> bool
---- NativeAdBase/<RetryGetNative>d__18::MoveNext 0x2c96f3c
02c96f3c: str     d8, [sp, #-0x30]!                          
02c96f40: stp     x30, x21, [sp, #0x10]                      
02c96f44: stp     x20, x19, [sp, #0x20]                      
02c96f48: adrp    x20, #0x662f000                            
02c96f4c: mov     x19, x0                                    
02c96f50: ldrb    w8, [x20, #0xa0a]                          
02c96f54: tbnz    w8, #0, #0x2c96f6c                         
02c96f58: adrp    x0, #0x6264000                             
02c96f5c: ldr     x0, [x0, #0xf58]                           T:UnityEngine.WaitForSeconds
02c96f60: bl      #0x2b70db0                                 fn_2b70db0
02c96f64: mov     w8, #1                                     
02c96f68: strb    w8, [x20, #0xa0a]                          
02c96f6c: ldr     w21, [x19, #0x10]                          .<>1__state
02c96f70: cbz     w21, #0x2c96f9c                            
02c96f74: cmp     w21, #1                                    
02c96f78: b.ne    #0x2c96fe0                                 
02c96f7c: ldr     x0, [x19, #0x28]                           .<>4__this
02c96f80: mov     w8, #-1                                    
02c96f84: str     w8, [x19, #0x10]                           .<>1__state
02c96f88: cbz     x0, #0x2c96ff8                             
02c96f8c: ldr     x1, [x0, #0x78]                            M:DG.Tweening.DOTweenModulePhysics/<>c__DisplayClass3_0::<DOMoveZ>b__0
02c96f90: ldr     w2, [x0, #0x80]                            T:DG.Tweening.DOTweenModulePhysics/<>c__DisplayClass4_0
02c96f94: bl      #0x2c96b28                                 NativeAdBase::ShowAd
02c96f98: b       #0x2c96fe0                                 
02c96f9c: adrp    x8, #0x6264000                             
02c96fa0: mov     w9, #-1                                    
02c96fa4: ldr     x8, [x8, #0xf58]                           T:UnityEngine.WaitForSeconds
02c96fa8: ldr     s8, [x19, #0x20]                           .delaySeconds
02c96fac: str     w9, [x19, #0x10]                           .<>1__state
02c96fb0: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c96fb4: bl      #0x2b7104c                                 fn_2b7104c
02c96fb8: fmov    s0, s8                                     
02c96fbc: mov     x1, xzr                                    
02c96fc0: mov     x20, x0                                    
02c96fc4: bl      #0x5b3e5e8                                 UnityEngine.WaitForSeconds::.ctor
02c96fc8: mov     x0, x19                                    
02c96fcc: mov     x1, x20                                    
02c96fd0: str     x20, [x0, #0x18]!                          .<>2__current
02c96fd4: bl      #0x2b70d54                                 fn_2b70d54
02c96fd8: mov     w8, #1                                     
02c96fdc: str     w8, [x19, #0x10]                           .<>1__state
02c96fe0: cmp     w21, #0                                    
02c96fe4: ldp     x20, x19, [sp, #0x20]                      
02c96fe8: ldp     x30, x21, [sp, #0x10]                      
02c96fec: cset    w0, eq                                     
02c96ff0: ldr     d8, [sp], #0x30                            
02c96ff4: ret                                                
02c96ff8: bl      #0x2b7105c                                 fn_2b7105c
## System.Collections.Generic.IEnumerator<System.Object>.get_Current() -> object
---- NativeAdBase/<RetryGetNative>d__18::System.Collections.Generic.IEnumerator<System.Object>.get_Current 0x2c96ffc
02c96ffc: ldr     x0, [x0, #0x18]                            .<>2__current
02c97000: ret                                                
## System.Collections.IEnumerator.Reset() -> void
---- NativeAdBase/<RetryGetNative>d__18::System.Collections.IEnumerator.Reset 0x2c97004
02c97004: stp     x30, x19, [sp, #-0x10]!                    
02c97008: adrp    x0, #0x6264000                             
02c9700c: ldr     x0, [x0, #0xf60]                           T:System.NotSupportedException
02c97010: bl      #0x2b70dc4                                 fn_2b70dc4
02c97014: bl      #0x2b7104c                                 fn_2b7104c
02c97018: mov     x1, xzr                                    
02c9701c: mov     x19, x0                                    
02c97020: bl      #0x4e14238                                 System.NotSupportedException::.ctor
02c97024: adrp    x0, #0x6265000                             
02c97028: ldr     x0, [x0, #0x848]                           M:NativeAdBase/<RetryGetNative>d__18::System.Collections.IEnumerator.Reset
02c9702c: bl      #0x2b70dc4                                 fn_2b70dc4
02c97030: mov     x1, x0                                     
02c97034: mov     x0, x19                                    
02c97038: bl      #0x2b70f20                                 fn_2b70f20
## System.Collections.IEnumerator.get_Current() -> object
---- NativeAdBase/<RetryGetNative>d__18::System.Collections.IEnumerator.get_Current 0x2c9703c
02c9703c: ldr     x0, [x0, #0x18]                            .<>2__current
02c97040: ret                                                
#### CLASS NativeAdBase parent= UnityEngine.MonoBehaviour
#   field _bigIcon                       UnityEngine.UI.RawImage                            off=0x20 attr=1 SerializeField
#   field _bigImage                      UnityEngine.UI.RawImage                            off=0x28 attr=1 SerializeField
#   field _adInfoIcon                    UnityEngine.UI.RawImage                            off=0x30 attr=1 SerializeField
#   field _headLineText                  UnityEngine.UI.Text                                off=0x38 attr=1 SerializeField
#   field _advertiserText                UnityEngine.UI.Text                                off=0x40 attr=1 SerializeField
#   field _ctaText                       UnityEngine.UI.Text                                off=0x48 attr=1 SerializeField
#   field _aspectRatioFitter             UnityEngine.UI.AspectRatioFitter                   off=0x50 attr=1 SerializeField
#   field _coverLoadObj                  UnityEngine.GameObject                             off=0x58 attr=1 SerializeField
#   field _nativeAd                      NativeObject                                       off=0x60 attr=1 
#   field retryCoroutine                 UnityEngine.Coroutine                              off=0x68 attr=1 
#   field retryAttempt                   float                                              off=0x70 attr=1 
#   field _hasAd                         bool                                               off=0x74 attr=1 
#   field _placement                     string                                             off=0x78 attr=1 
#   field _adFormat                      AdFormat                                           off=0x80 attr=1 
## ShowAd(string placement, AdFormat adFormat) -> void
---- NativeAdBase::ShowAd 0x2c96b28
02c96b28: str     x30, [sp, #-0x20]!                         
02c96b2c: stp     x20, x19, [sp, #0x10]                      
02c96b30: mov     w20, w2                                    
02c96b34: mov     x19, x0                                    
02c96b38: str     x1, [x0, #0x78]!                           ._placement
02c96b3c: bl      #0x2b70d54                                 fn_2b70d54
02c96b40: mov     x0, x19                                    
02c96b44: mov     x1, xzr                                    
02c96b48: str     w20, [x19, #0x80]                          ._adFormat
02c96b4c: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02c96b50: cbz     x0, #0x2c96bbc                             
02c96b54: mov     w1, #1                                     
02c96b58: mov     x2, xzr                                    
02c96b5c: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02c96b60: ldrb    w8, [x19, #0x74]                           ._hasAd
02c96b64: cbz     w8, #0x2c96b74                             
02c96b68: ldp     x20, x19, [sp, #0x10]                      
02c96b6c: ldr     x30, [sp], #0x20                           
02c96b70: ret                                                
02c96b74: mov     w1, w20                                    
02c96b78: bl      #0x2c96bc0                                 NativeAdBase::GetNativeAd
02c96b7c: mov     x20, x19                                   
02c96b80: mov     x1, x0                                     
02c96b84: str     x0, [x20, #0x60]!                          ._nativeAd
02c96b88: mov     x0, x20                                    
02c96b8c: bl      #0x2b70d54                                 fn_2b70d54
02c96b90: ldr     x8, [x20]                                  
02c96b94: cbz     x8, #0x2c96bac                             
02c96b98: mov     x0, x19                                    
02c96b9c: str     wzr, [x19, #0x70]                          .retryAttempt
02c96ba0: ldp     x20, x19, [sp, #0x10]                      
02c96ba4: ldr     x30, [sp], #0x20                           
02c96ba8: b       #0x2c96c80                                 NativeAdBase::SetNativeToShow
02c96bac: mov     x0, x19                                    
02c96bb0: ldp     x20, x19, [sp, #0x10]                      
02c96bb4: ldr     x30, [sp], #0x20                           
02c96bb8: b       #0x2c96ca8                                 NativeAdBase::TryGetNative
02c96bbc: bl      #0x2b7105c                                 fn_2b7105c
## GetNativeAd(AdFormat adFormat) -> NativeObject
---- NativeAdBase::GetNativeAd 0x2c96bc0
02c96bc0: str     x30, [sp, #-0x20]!                         
02c96bc4: stp     x20, x19, [sp, #0x10]                      
02c96bc8: adrp    x20, #0x662f000                            
02c96bcc: mov     w19, w1                                    
02c96bd0: ldrb    w8, [x20, #0xa06]                          
02c96bd4: tbnz    w8, #0, #0x2c96c10                         
02c96bd8: adrp    x0, #0x6265000                             
02c96bdc: ldr     x0, [x0, #0x820]                           MS:NativeProduceBase`1::GetNativeAd
02c96be0: bl      #0x2b70db0                                 fn_2b70db0
02c96be4: adrp    x0, #0x6265000                             
02c96be8: ldr     x0, [x0, #0x828]                           MS:NativeProduceBase`1::GetNativeAd
02c96bec: bl      #0x2b70db0                                 fn_2b70db0
02c96bf0: adrp    x0, #0x6265000                             
02c96bf4: ldr     x0, [x0, #0x830]                           MS:WejoyService.Singleton`1::get_Instance
02c96bf8: bl      #0x2b70db0                                 fn_2b70db0
02c96bfc: adrp    x0, #0x6265000                             
02c96c00: ldr     x0, [x0, #0x838]                           MS:WejoyService.Singleton`1::get_Instance
02c96c04: bl      #0x2b70db0                                 fn_2b70db0
02c96c08: mov     w8, #1                                     
02c96c0c: strb    w8, [x20, #0xa06]                          
02c96c10: cmp     w19, #8                                    
02c96c14: b.eq    #0x2c96c40                                 
02c96c18: cmp     w19, #6                                    
02c96c1c: b.ne    #0x2c96c6c                                 
02c96c20: adrp    x8, #0x6265000                             
02c96c24: ldr     x8, [x8, #0x830]                           MS:WejoyService.Singleton`1::get_Instance
02c96c28: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c96c2c: bl      #0x3be7218                                 fn_3be7218
02c96c30: cbz     x0, #0x2c96c7c                             
02c96c34: adrp    x8, #0x6265000                             
02c96c38: ldr     x8, [x8, #0x828]                           MS:NativeProduceBase`1::GetNativeAd
02c96c3c: b       #0x2c96c5c                                 
02c96c40: adrp    x8, #0x6265000                             
02c96c44: ldr     x8, [x8, #0x838]                           MS:WejoyService.Singleton`1::get_Instance
02c96c48: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c96c4c: bl      #0x3be7218                                 fn_3be7218
02c96c50: cbz     x0, #0x2c96c7c                             
02c96c54: adrp    x8, #0x6265000                             
02c96c58: ldr     x8, [x8, #0x820]                           MS:NativeProduceBase`1::GetNativeAd
02c96c5c: ldp     x20, x19, [sp, #0x10]                      
02c96c60: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c96c64: ldr     x30, [sp], #0x20                           
02c96c68: b       #0x38cf67c                                 
02c96c6c: ldp     x20, x19, [sp, #0x10]                      
02c96c70: mov     x0, xzr                                    
02c96c74: ldr     x30, [sp], #0x20                           
02c96c78: ret                                                
02c96c7c: bl      #0x2b7105c                                 fn_2b7105c
## HideAd() -> void
---- NativeAdBase::HideAd 0x2c96d10
02c96d10: stp     x30, x19, [sp, #-0x10]!                    
02c96d14: ldr     x1, [x0, #0x68]                            .retryCoroutine
02c96d18: mov     x19, x0                                    
02c96d1c: cbz     x1, #0x2c96d2c                             
02c96d20: mov     x0, x19                                    
02c96d24: mov     x2, xzr                                    
02c96d28: bl      #0x5b38c4c                                 UnityEngine.MonoBehaviour::StopCoroutine
02c96d2c: mov     x0, x19                                    
02c96d30: mov     x1, xzr                                    
02c96d34: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02c96d38: cbz     x0, #0x2c96d4c                             
02c96d3c: mov     w1, wzr                                    
02c96d40: mov     x2, xzr                                    
02c96d44: ldp     x30, x19, [sp], #0x10                      
02c96d48: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02c96d4c: bl      #0x2b7105c                                 fn_2b7105c
## TryGetNative() -> void
---- NativeAdBase::TryGetNative 0x2c96ca8
02c96ca8: str     x30, [sp, #-0x20]!                         
02c96cac: stp     x20, x19, [sp, #0x10]                      
02c96cb0: fmov    s0, #0.50000000                            
02c96cb4: mov     x20, x0                                    
02c96cb8: mov     x19, x0                                    
02c96cbc: ldr     x1, [x20, #0x68]!                          .retryCoroutine
02c96cc0: ldr     s1, [x20, #8]                              
02c96cc4: fadd    s0, s1, s0                                 
02c96cc8: str     s0, [x20, #8]                              
02c96ccc: cbz     x1, #0x2c96ce0                             
02c96cd0: mov     x0, x19                                    
02c96cd4: mov     x2, xzr                                    
02c96cd8: bl      #0x5b38c4c                                 UnityEngine.MonoBehaviour::StopCoroutine
02c96cdc: ldr     s0, [x19, #0x70]                           .retryAttempt
02c96ce0: mov     x0, x19                                    
02c96ce4: bl      #0x2c96d50                                 NativeAdBase::RetryGetNative
02c96ce8: mov     x1, x0                                     
02c96cec: mov     x0, x19                                    
02c96cf0: mov     x2, xzr                                    
02c96cf4: bl      #0x5b389f0                                 UnityEngine.MonoBehaviour::StartCoroutine
02c96cf8: mov     x1, x0                                     
02c96cfc: mov     x0, x20                                    
02c96d00: str     x1, [x19, #0x68]                           .retryCoroutine
02c96d04: ldp     x20, x19, [sp, #0x10]                      
02c96d08: ldr     x30, [sp], #0x20                           
02c96d0c: b       #0x2b70d54                                 
## RetryGetNative(float delaySeconds) -> System.Collections.IEnumerator
---- NativeAdBase::RetryGetNative 0x2c96d50
02c96d50: str     d8, [sp, #-0x30]!                          
02c96d54: stp     x30, x21, [sp, #0x10]                      
02c96d58: stp     x20, x19, [sp, #0x20]                      
02c96d5c: fmov    s8, s0                                     
02c96d60: adrp    x20, #0x662f000                            
02c96d64: adrp    x21, #0x6265000                            
02c96d68: ldrb    w8, [x20, #0xa07]                          
02c96d6c: ldr     x21, [x21, #0x840]                         T:NativeAdBase/<RetryGetNative>d__18
02c96d70: mov     x19, x0                                    
02c96d74: tbnz    w8, #0, #0x2c96d8c                         
02c96d78: adrp    x0, #0x6265000                             
02c96d7c: ldr     x0, [x0, #0x840]                           T:NativeAdBase/<RetryGetNative>d__18
02c96d80: bl      #0x2b70db0                                 fn_2b70db0
02c96d84: mov     w8, #1                                     
02c96d88: strb    w8, [x20, #0xa07]                          
02c96d8c: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c96d90: bl      #0x2b7104c                                 fn_2b7104c
02c96d94: mov     x1, xzr                                    
02c96d98: mov     x20, x0                                    
02c96d9c: bl      #0x4e53e9c                                 System.Object::.ctor
02c96da0: mov     x0, x20                                    
02c96da4: mov     x1, x19                                    
02c96da8: str     wzr, [x20, #0x10]                          
02c96dac: str     x19, [x0, #0x28]!                          ._bigImage
02c96db0: bl      #0x2b70d54                                 fn_2b70d54
02c96db4: mov     x0, x20                                    
02c96db8: str     s8, [x20, #0x20]                           ._bigIcon
02c96dbc: ldp     x20, x19, [sp, #0x20]                      
02c96dc0: ldp     x30, x21, [sp, #0x10]                      
02c96dc4: ldr     d8, [sp], #0x30                            
02c96dc8: ret                                                
## SetNativeToShow(NativeObject nativeAd) -> void
---- NativeAdBase::SetNativeToShow 0x2c96c80
02c96c80: mov     x8, x0                                     
02c96c84: ldr     x0, [x0, #0x58]                            ._coverLoadObj
02c96c88: mov     w9, #1                                     
02c96c8c: strb    w9, [x8, #0x74]                            
02c96c90: cbz     x0, #0x2c96ca0                             
02c96c94: mov     w1, wzr                                    
02c96c98: mov     x2, xzr                                    
02c96c9c: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02c96ca0: str     x30, [sp, #-0x10]!                         
02c96ca4: bl      #0x2b7105c                                 fn_2b7105c
## ProcessBigImageSize(UnityEngine.Texture2D texture2D) -> void
---- NativeAdBase::ProcessBigImageSize 0x2c96df4
02c96df4: str     x30, [sp, #-0x30]!                         
02c96df8: stp     x22, x21, [sp, #0x10]                      
02c96dfc: stp     x20, x19, [sp, #0x20]                      
02c96e00: adrp    x21, #0x662f000                            
02c96e04: adrp    x22, #0x6263000                            
02c96e08: mov     x19, x1                                    
02c96e0c: ldrb    w8, [x21, #0xa08]                          
02c96e10: ldr     x22, [x22, #0x918]                         T:UnityEngine.Object
02c96e14: mov     x20, x0                                    
02c96e18: tbnz    w8, #0, #0x2c96e30                         
02c96e1c: adrp    x0, #0x6263000                             
02c96e20: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02c96e24: bl      #0x2b70db0                                 fn_2b70db0
02c96e28: mov     w8, #1                                     
02c96e2c: strb    w8, [x21, #0xa08]                          
02c96e30: ldr     x0, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c96e34: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02c96e38: cbnz    w8, #0x2c96e40                             
02c96e3c: bl      #0x2b70f30                                 fn_2b70f30
02c96e40: mov     x0, x19                                    
02c96e44: mov     x1, xzr                                    
02c96e48: bl      #0x5b3bb1c                                 UnityEngine.Object::op_Implicit
02c96e4c: tbz     w0, #0, #0x2c96ecc                         
02c96e50: ldr     x0, [x20, #0x28]                           ._bigImage
02c96e54: cbz     x0, #0x2c96edc                             
02c96e58: mov     x1, x19                                    
02c96e5c: mov     x2, xzr                                    
02c96e60: bl      #0x5e5e2dc                                 UnityEngine.UI.RawImage::set_texture
02c96e64: ldr     x0, [x20, #0x50]                           ._aspectRatioFitter
02c96e68: cbz     x0, #0x2c96edc                             
02c96e6c: mov     w1, #3                                     
02c96e70: mov     x2, xzr                                    
02c96e74: bl      #0x5e53d4c                                 UnityEngine.UI.AspectRatioFitter::set_aspectMode
02c96e78: cbz     x19, #0x2c96edc                            
02c96e7c: ldr     x8, [x19]                                  
02c96e80: ldr     x20, [x20, #0x50]                          ._aspectRatioFitter
02c96e84: mov     x0, x19                                    
02c96e88: ldp     x9, x1, [x8, #0x188]                       
02c96e8c: blr     x9                                         
02c96e90: ldr     x8, [x19]                                  
02c96e94: mov     w21, w0                                    
02c96e98: mov     x0, x19                                    
02c96e9c: ldp     x9, x1, [x8, #0x1a8]                       
02c96ea0: blr     x9                                         
02c96ea4: cbz     x20, #0x2c96edc                            
02c96ea8: scvtf   s0, w21                                    
02c96eac: scvtf   s1, w0                                     
02c96eb0: mov     x0, x20                                    
02c96eb4: ldp     x20, x19, [sp, #0x20]                      
02c96eb8: mov     x1, xzr                                    
02c96ebc: ldp     x22, x21, [sp, #0x10]                      
02c96ec0: fdiv    s0, s0, s1                                 
02c96ec4: ldr     x30, [sp], #0x30                           
02c96ec8: b       #0x5e53dcc                                 UnityEngine.UI.AspectRatioFitter::set_aspectRatio
02c96ecc: ldp     x20, x19, [sp, #0x20]                      
02c96ed0: ldp     x22, x21, [sp, #0x10]                      
02c96ed4: ldr     x30, [sp], #0x30                           
02c96ed8: ret                                                
02c96edc: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- NativeAdBase::.ctor 0x2c96ee0
02c96ee0: stp     x30, x21, [sp, #-0x20]!                    
02c96ee4: stp     x20, x19, [sp, #0x10]                      
02c96ee8: adrp    x20, #0x662f000                            
02c96eec: adrp    x21, #0x6263000                            
02c96ef0: mov     x19, x0                                    
02c96ef4: ldrb    w8, [x20, #0xa09]                          
02c96ef8: ldr     x21, [x21, #0xa90]                         S:''
02c96efc: tbnz    w8, #0, #0x2c96f14                         
02c96f00: adrp    x0, #0x6263000                             
02c96f04: ldr     x0, [x0, #0xa90]                           S:''
02c96f08: bl      #0x2b70db0                                 fn_2b70db0
02c96f0c: mov     w8, #1                                     
02c96f10: strb    w8, [x20, #0xa09]                          
02c96f14: ldr     x1, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c96f18: mov     x0, x19                                    
02c96f1c: str     x1, [x0, #0x78]!                           ._placement
02c96f20: bl      #0x2b70d54                                 fn_2b70d54
02c96f24: mov     x0, x19                                    
02c96f28: ldp     x20, x19, [sp, #0x10]                      
02c96f2c: mov     x1, xzr                                    
02c96f30: ldp     x30, x21, [sp], #0x20                      
02c96f34: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
