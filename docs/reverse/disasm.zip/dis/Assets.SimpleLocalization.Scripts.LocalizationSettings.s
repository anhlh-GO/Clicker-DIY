#### CLASS Assets.SimpleLocalization.Scripts.LocalizationSettings/<>c parent= object
#   field <>9                            Assets.SimpleLocalization.Scripts.LocalizationSettings/<>c off=0x0 attr=36 
## .cctor() -> void
---- Assets.SimpleLocalization.Scripts.LocalizationSettings/<>c::.cctor 0x2d7c564
02d7c564: str     x30, [sp, #-0x20]!                         
02d7c568: stp     x20, x19, [sp, #0x10]                      
02d7c56c: adrp    x19, #0x6630000                            
02d7c570: adrp    x20, #0x626c000                            
02d7c574: ldrb    w8, [x19, #0x417]                          
02d7c578: ldr     x20, [x20, #0xc50]                         T:Assets.SimpleLocalization.Scripts.LocalizationSettings/<>c
02d7c57c: tbnz    w8, #0, #0x2d7c594                         
02d7c580: adrp    x0, #0x626c000                             
02d7c584: ldr     x0, [x0, #0xc50]                           T:Assets.SimpleLocalization.Scripts.LocalizationSettings/<>c
02d7c588: bl      #0x2b70db0                                 fn_2b70db0
02d7c58c: mov     w8, #1                                     
02d7c590: strb    w8, [x19, #0x417]                          
02d7c594: ldr     x0, [x20]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7c598: bl      #0x2b7104c                                 fn_2b7104c
02d7c59c: mov     x1, xzr                                    
02d7c5a0: mov     x19, x0                                    
02d7c5a4: bl      #0x4e53e9c                                 System.Object::.ctor
02d7c5a8: ldr     x8, [x20]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7c5ac: mov     x1, x19                                    
02d7c5b0: ldr     x8, [x8, #0xb8]                            
02d7c5b4: str     x19, [x8]                                  
02d7c5b8: ldr     x8, [x20]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7c5bc: ldp     x20, x19, [sp, #0x10]                      
02d7c5c0: ldr     x0, [x8, #0xb8]                            
02d7c5c4: ldr     x30, [sp], #0x20                           
02d7c5c8: b       #0x2b70d54                                 
## .ctor() -> void
---- Assets.SimpleLocalization.Scripts.LocalizationSettings/<>c::.ctor 0x2d7c5cc
02d7c5cc: mov     x1, xzr                                    
02d7c5d0: b       #0x4e53e9c                                 System.Object::.ctor
## <.cctor>b__13_0() -> void
---- Assets.SimpleLocalization.Scripts.LocalizationSettings/<>c::<.cctor>b__13_0 0x2d7c5d4
02d7c5d4: ret                                                
#### CLASS Assets.SimpleLocalization.Scripts.LocalizationSettings parent= UnityEngine.ScriptableObject
#   field TableId                        string                                             off=0x18 attr=6 
#   field Sheets                         System.Collections.Generic.List`1<Assets.SimpleLocalization.Scripts.Sheet> off=0x20 attr=6 
#   field SaveFolder                     UnityEngine.Object                                 off=0x28 attr=6 
#   field UrlPattern                     string                                             off=0x0 attr=16 
#   field Timestamp                      System.DateTime                                    off=0x8 attr=16 
#   field OnRunEditor                    System.Action                                      off=0x10 attr=11 CompilerGeneratedAttribute
#   field _instance                      Assets.SimpleLocalization.Scripts.LocalizationSettings off=0x18 attr=11 
## get_Instance() -> Assets.SimpleLocalization.Scripts.LocalizationSettings
---- Assets.SimpleLocalization.Scripts.LocalizationSettings::get_Instance 0x2d7b2d8
02d7b2d8: str     x30, [sp, #-0x20]!                         
02d7b2dc: stp     x20, x19, [sp, #0x10]                      
02d7b2e0: adrp    x19, #0x6630000                            
02d7b2e4: adrp    x20, #0x626c000                            
02d7b2e8: ldrb    w8, [x19, #0x411]                          
02d7b2ec: ldr     x20, [x20, #0xab0]                         T:Assets.SimpleLocalization.Scripts.LocalizationSettings
02d7b2f0: tbnz    w8, #0, #0x2d7b314                         
02d7b2f4: adrp    x0, #0x626c000                             
02d7b2f8: ldr     x0, [x0, #0xab0]                           T:Assets.SimpleLocalization.Scripts.LocalizationSettings
02d7b2fc: bl      #0x2b70db0                                 fn_2b70db0
02d7b300: adrp    x0, #0x6263000                             
02d7b304: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d7b308: bl      #0x2b70db0                                 fn_2b70db0
02d7b30c: mov     w8, #1                                     
02d7b310: strb    w8, [x19, #0x411]                          
02d7b314: ldr     x0, [x20]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7b318: adrp    x19, #0x6263000                            
02d7b31c: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d7b320: ldr     x19, [x19, #0x918]                         T:UnityEngine.Object
02d7b324: cbnz    w8, #0x2d7b330                             
02d7b328: bl      #0x2b70f30                                 fn_2b70f30
02d7b32c: ldr     x0, [x20]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7b330: ldr     x8, [x19]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d7b334: ldr     x9, [x0, #0xb8]                            &6263108(=0)
02d7b338: ldr     w10, [x8, #0xe4]                           
02d7b33c: ldr     x19, [x9, #0x18]                           
02d7b340: cbnz    w10, #0x2d7b34c                            
02d7b344: mov     x0, x8                                     
02d7b348: bl      #0x2b70f30                                 fn_2b70f30
02d7b34c: mov     x0, x19                                    
02d7b350: mov     x1, xzr                                    
02d7b354: mov     x2, xzr                                    
02d7b358: bl      #0x5b37d84                                 UnityEngine.Object::op_Equality
02d7b35c: tbz     w0, #0, #0x2d7b38c                         
02d7b360: ldr     x0, [x20]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7b364: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d7b368: cbnz    w8, #0x2d7b370                             
02d7b36c: bl      #0x2b70f30                                 fn_2b70f30
02d7b370: bl      #0x2d7c118                                 Assets.SimpleLocalization.Scripts.LocalizationSettings::LoadSettings
02d7b374: ldr     x8, [x20]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7b378: mov     x1, x0                                     
02d7b37c: ldr     x8, [x8, #0xb8]                            
02d7b380: str     x0, [x8, #0x18]!                           
02d7b384: mov     x0, x8                                     
02d7b388: bl      #0x2b70d54                                 fn_2b70d54
02d7b38c: ldr     x0, [x20]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7b390: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d7b394: cbnz    w8, #0x2d7b3a0                             
02d7b398: bl      #0x2b70f30                                 fn_2b70f30
02d7b39c: ldr     x0, [x20]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7b3a0: ldr     x8, [x0, #0xb8]                            &6263108(=0)
02d7b3a4: ldp     x20, x19, [sp, #0x10]                      
02d7b3a8: ldr     x0, [x8, #0x18]                            
02d7b3ac: ldr     x30, [sp], #0x20                           
02d7b3b0: ret                                                
## add_OnRunEditor(System.Action value) -> void
---- Assets.SimpleLocalization.Scripts.LocalizationSettings::add_OnRunEditor 0x2d7c22c
02d7c22c: stp     x30, x23, [sp, #-0x30]!                    
02d7c230: stp     x22, x21, [sp, #0x10]                      
02d7c234: stp     x20, x19, [sp, #0x20]                      
02d7c238: adrp    x20, #0x6630000                            
02d7c23c: adrp    x22, #0x626c000                            
02d7c240: mov     x19, x0                                    
02d7c244: ldrb    w8, [x20, #0x412]                          
02d7c248: ldr     x22, [x22, #0xab0]                         T:Assets.SimpleLocalization.Scripts.LocalizationSettings
02d7c24c: tbnz    w8, #0, #0x2d7c270                         
02d7c250: adrp    x0, #0x6264000                             
02d7c254: ldr     x0, [x0, #0xf90]                           T:System.Action
02d7c258: bl      #0x2b70db0                                 fn_2b70db0
02d7c25c: adrp    x0, #0x626c000                             
02d7c260: ldr     x0, [x0, #0xab0]                           T:Assets.SimpleLocalization.Scripts.LocalizationSettings
02d7c264: bl      #0x2b70db0                                 fn_2b70db0
02d7c268: mov     w8, #1                                     
02d7c26c: strb    w8, [x20, #0x412]                          
02d7c270: ldr     x0, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7c274: ldr     w8, [x0, #0xe4]                            [626c0e4]=0 f=0,0
02d7c278: cbnz    w8, #0x2d7c284                             
02d7c27c: bl      #0x2b70f30                                 fn_2b70f30
02d7c280: ldr     x0, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7c284: ldr     x8, [x0, #0xb8]                            MS:System.Collections.Generic.List`1::Add
02d7c288: adrp    x23, #0x6264000                            
02d7c28c: ldr     x23, [x23, #0xf90]                         T:System.Action
02d7c290: ldr     x20, [x8, #0x10]                           
02d7c294: mov     x0, x20                                    
02d7c298: mov     x1, x19                                    
02d7c29c: mov     x2, xzr                                    
02d7c2a0: bl      #0x4e570ac                                 System.Delegate::Combine
02d7c2a4: mov     x21, x0                                    
02d7c2a8: cbz     x0, #0x2d7c2bc                             
02d7c2ac: ldr     x1, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d7c2b0: ldr     x8, [x21]                                  
02d7c2b4: cmp     x8, x1                                     
02d7c2b8: b.ne    #0x2d7c300                                 
02d7c2bc: ldr     x0, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7c2c0: ldr     w8, [x0, #0xe4]                            [626c0e4]=0 f=0,0
02d7c2c4: cbnz    w8, #0x2d7c2d0                             
02d7c2c8: bl      #0x2b70f30                                 fn_2b70f30
02d7c2cc: ldr     x0, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7c2d0: ldr     x8, [x0, #0xb8]                            MS:System.Collections.Generic.List`1::Add
02d7c2d4: mov     x1, x21                                    
02d7c2d8: mov     x2, x20                                    
02d7c2dc: add     x0, x8, #0x10                              
02d7c2e0: bl      #0x2ba9880                                 fn_2ba9880
02d7c2e4: cmp     x0, x20                                    
02d7c2e8: mov     x20, x0                                    
02d7c2ec: b.ne    #0x2d7c294                                 
02d7c2f0: ldp     x20, x19, [sp, #0x20]                      
02d7c2f4: ldp     x22, x21, [sp, #0x10]                      
02d7c2f8: ldp     x30, x23, [sp], #0x30                      
02d7c2fc: ret                                                
02d7c300: mov     x0, x21                                    
02d7c304: bl      #0x2b713dc                                 fn_2b713dc
## remove_OnRunEditor(System.Action value) -> void
---- Assets.SimpleLocalization.Scripts.LocalizationSettings::remove_OnRunEditor 0x2d7c308
02d7c308: stp     x30, x23, [sp, #-0x30]!                    
02d7c30c: stp     x22, x21, [sp, #0x10]                      
02d7c310: stp     x20, x19, [sp, #0x20]                      
02d7c314: adrp    x20, #0x6630000                            
02d7c318: adrp    x22, #0x626c000                            
02d7c31c: mov     x19, x0                                    
02d7c320: ldrb    w8, [x20, #0x413]                          
02d7c324: ldr     x22, [x22, #0xab0]                         T:Assets.SimpleLocalization.Scripts.LocalizationSettings
02d7c328: tbnz    w8, #0, #0x2d7c34c                         
02d7c32c: adrp    x0, #0x6264000                             
02d7c330: ldr     x0, [x0, #0xf90]                           T:System.Action
02d7c334: bl      #0x2b70db0                                 fn_2b70db0
02d7c338: adrp    x0, #0x626c000                             
02d7c33c: ldr     x0, [x0, #0xab0]                           T:Assets.SimpleLocalization.Scripts.LocalizationSettings
02d7c340: bl      #0x2b70db0                                 fn_2b70db0
02d7c344: mov     w8, #1                                     
02d7c348: strb    w8, [x20, #0x413]                          
02d7c34c: ldr     x0, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7c350: ldr     w8, [x0, #0xe4]                            [626c0e4]=0 f=0,0
02d7c354: cbnz    w8, #0x2d7c360                             
02d7c358: bl      #0x2b70f30                                 fn_2b70f30
02d7c35c: ldr     x0, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7c360: ldr     x8, [x0, #0xb8]                            MS:System.Collections.Generic.List`1::Add
02d7c364: adrp    x23, #0x6264000                            
02d7c368: ldr     x23, [x23, #0xf90]                         T:System.Action
02d7c36c: ldr     x20, [x8, #0x10]                           
02d7c370: mov     x0, x20                                    
02d7c374: mov     x1, x19                                    
02d7c378: mov     x2, xzr                                    
02d7c37c: bl      #0x4e57298                                 System.Delegate::Remove
02d7c380: mov     x21, x0                                    
02d7c384: cbz     x0, #0x2d7c398                             
02d7c388: ldr     x1, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d7c38c: ldr     x8, [x21]                                  
02d7c390: cmp     x8, x1                                     
02d7c394: b.ne    #0x2d7c3dc                                 
02d7c398: ldr     x0, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7c39c: ldr     w8, [x0, #0xe4]                            [626c0e4]=0 f=0,0
02d7c3a0: cbnz    w8, #0x2d7c3ac                             
02d7c3a4: bl      #0x2b70f30                                 fn_2b70f30
02d7c3a8: ldr     x0, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7c3ac: ldr     x8, [x0, #0xb8]                            MS:System.Collections.Generic.List`1::Add
02d7c3b0: mov     x1, x21                                    
02d7c3b4: mov     x2, x20                                    
02d7c3b8: add     x0, x8, #0x10                              
02d7c3bc: bl      #0x2ba9880                                 fn_2ba9880
02d7c3c0: cmp     x0, x20                                    
02d7c3c4: mov     x20, x0                                    
02d7c3c8: b.ne    #0x2d7c370                                 
02d7c3cc: ldp     x20, x19, [sp, #0x20]                      
02d7c3d0: ldp     x22, x21, [sp, #0x10]                      
02d7c3d4: ldp     x30, x23, [sp], #0x30                      
02d7c3d8: ret                                                
02d7c3dc: mov     x0, x21                                    
02d7c3e0: bl      #0x2b713dc                                 fn_2b713dc
## LoadSettings() -> Assets.SimpleLocalization.Scripts.LocalizationSettings
---- Assets.SimpleLocalization.Scripts.LocalizationSettings::LoadSettings 0x2d7c118
02d7c118: stp     x30, x21, [sp, #-0x20]!                    
02d7c11c: stp     x20, x19, [sp, #0x10]                      
02d7c120: adrp    x20, #0x6630000                            
02d7c124: adrp    x19, #0x6267000                            
02d7c128: ldrb    w8, [x20, #0x414]                          
02d7c12c: ldr     x19, [x19, #0x60]                          T:System.IO.Path
02d7c130: tbnz    w8, #0, #0x2d7c16c                         
02d7c134: adrp    x0, #0x6263000                             
02d7c138: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d7c13c: bl      #0x2b70db0                                 fn_2b70db0
02d7c140: adrp    x0, #0x6267000                             
02d7c144: ldr     x0, [x0, #0x60]                            T:System.IO.Path
02d7c148: bl      #0x2b70db0                                 fn_2b70db0
02d7c14c: adrp    x0, #0x626c000                             
02d7c150: ldr     x0, [x0, #0xc18]                           MS:UnityEngine.Resources::Load
02d7c154: bl      #0x2b70db0                                 fn_2b70db0
02d7c158: adrp    x0, #0x626c000                             
02d7c15c: ldr     x0, [x0, #0xc20]                           S:'Assets/SimpleLocalization/Resources/LocalizationSettings.asset'
02d7c160: bl      #0x2b70db0                                 fn_2b70db0
02d7c164: mov     w8, #1                                     
02d7c168: strb    w8, [x20, #0x414]                          
02d7c16c: ldr     x0, [x19]                                  S:'didu'
02d7c170: adrp    x21, #0x626c000                            
02d7c174: adrp    x20, #0x626c000                            
02d7c178: adrp    x19, #0x6263000                            
02d7c17c: ldr     x21, [x21, #0xc20]                         S:'Assets/SimpleLocalization/Resources/LocalizationSettings.asset'
02d7c180: ldr     x20, [x20, #0xc18]                         MS:UnityEngine.Resources::Load
02d7c184: ldr     w8, [x0, #0xe4]                            [626c0e4]=0 f=0,0
02d7c188: ldr     x19, [x19, #0x918]                         T:UnityEngine.Object
02d7c18c: cbnz    w8, #0x2d7c194                             
02d7c190: bl      #0x2b70f30                                 fn_2b70f30
02d7c194: ldr     x0, [x21]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7c198: mov     x1, xzr                                    
02d7c19c: bl      #0x4de997c                                 System.IO.Path::GetFileNameWithoutExtension
02d7c1a0: ldr     x1, [x20]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7c1a4: bl      #0x331d05c                                 fn_331d05c
02d7c1a8: ldr     x8, [x19]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d7c1ac: mov     x19, x0                                    
02d7c1b0: ldr     w9, [x8, #0xe4]                            
02d7c1b4: cbnz    w9, #0x2d7c1c0                             
02d7c1b8: mov     x0, x8                                     
02d7c1bc: bl      #0x2b70f30                                 fn_2b70f30
02d7c1c0: mov     x0, x19                                    
02d7c1c4: mov     x1, xzr                                    
02d7c1c8: mov     x2, xzr                                    
02d7c1cc: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d7c1d0: tbz     w0, #0, #0x2d7c1e4                         
02d7c1d4: mov     x0, x19                                    
02d7c1d8: ldp     x20, x19, [sp, #0x10]                      
02d7c1dc: ldp     x30, x21, [sp], #0x20                      
02d7c1e0: ret                                                
02d7c1e4: adrp    x0, #0x6263000                             
02d7c1e8: ldr     x0, [x0, #0xae0]                           T:System.Exception
02d7c1ec: bl      #0x2b70dc4                                 fn_2b70dc4
02d7c1f0: bl      #0x2b7104c                                 fn_2b7104c
02d7c1f4: mov     x19, x0                                    
02d7c1f8: adrp    x0, #0x626c000                             
02d7c1fc: ldr     x0, [x0, #0xc28]                           S:'Localization settings not found: Assets/SimpleLocalization/Resources/L'
02d7c200: bl      #0x2b70dc4                                 fn_2b70dc4
02d7c204: mov     x1, x0                                     
02d7c208: mov     x0, x19                                    
02d7c20c: mov     x2, xzr                                    
02d7c210: bl      #0x4e49334                                 System.Exception::.ctor
02d7c214: adrp    x0, #0x626c000                             
02d7c218: ldr     x0, [x0, #0xc30]                           M:Assets.SimpleLocalization.Scripts.LocalizationSettings::LoadSettings
02d7c21c: bl      #0x2b70dc4                                 fn_2b70dc4
02d7c220: mov     x1, x0                                     
02d7c224: mov     x0, x19                                    
02d7c228: bl      #0x2b70f20                                 fn_2b70f20
## .ctor() -> void
---- Assets.SimpleLocalization.Scripts.LocalizationSettings::.ctor 0x2d7c3e4
02d7c3e4: str     x30, [sp, #-0x30]!                         
02d7c3e8: stp     x22, x21, [sp, #0x10]                      
02d7c3ec: stp     x20, x19, [sp, #0x20]                      
02d7c3f0: adrp    x21, #0x6630000                            
02d7c3f4: adrp    x22, #0x626c000                            
02d7c3f8: adrp    x20, #0x626c000                            
02d7c3fc: ldrb    w8, [x21, #0x415]                          
02d7c400: ldr     x22, [x22, #0xc38]                         T:type56807(k15)
02d7c404: ldr     x20, [x20, #0xc40]                         MS:System.Collections.Generic.List`1::.ctor
02d7c408: mov     x19, x0                                    
02d7c40c: tbnz    w8, #0, #0x2d7c430                         
02d7c410: adrp    x0, #0x626c000                             
02d7c414: ldr     x0, [x0, #0xc40]                           MS:System.Collections.Generic.List`1::.ctor
02d7c418: bl      #0x2b70db0                                 fn_2b70db0
02d7c41c: adrp    x0, #0x626c000                             
02d7c420: ldr     x0, [x0, #0xc38]                           T:type56807(k15)
02d7c424: bl      #0x2b70db0                                 fn_2b70db0
02d7c428: mov     w8, #1                                     
02d7c42c: strb    w8, [x21, #0x415]                          
02d7c430: ldr     x0, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7c434: bl      #0x2b7104c                                 fn_2b7104c
02d7c438: ldr     x1, [x20]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7c43c: mov     x20, x0                                    
02d7c440: bl      #0x35a89a4                                 fn_35a89a4
02d7c444: mov     x0, x19                                    
02d7c448: mov     x1, x20                                    
02d7c44c: str     x20, [x0, #0x20]!                          .Sheets
02d7c450: bl      #0x2b70d54                                 fn_2b70d54
02d7c454: mov     x0, x19                                    
02d7c458: ldp     x20, x19, [sp, #0x20]                      
02d7c45c: ldp     x22, x21, [sp, #0x10]                      
02d7c460: mov     x1, xzr                                    
02d7c464: ldr     x30, [sp], #0x30                           
02d7c468: b       #0x5b398f0                                 UnityEngine.ScriptableObject::.ctor
## .cctor() -> void
---- Assets.SimpleLocalization.Scripts.LocalizationSettings::.cctor 0x2d7c46c
02d7c46c: str     x30, [sp, #-0x30]!                         
02d7c470: stp     x22, x21, [sp, #0x10]                      
02d7c474: stp     x20, x19, [sp, #0x20]                      
02d7c478: adrp    x22, #0x6630000                            
02d7c47c: adrp    x20, #0x626c000                            
02d7c480: adrp    x21, #0x626c000                            
02d7c484: adrp    x19, #0x626c000                            
02d7c488: ldr     x20, [x20, #0xc48]                         S:'https://docs.google.com/spreadsheets/d/{0}/export?format=csv&gid={1}'
02d7c48c: ldrb    w8, [x22, #0x416]                          
02d7c490: ldr     x21, [x21, #0xab0]                         T:Assets.SimpleLocalization.Scripts.LocalizationSettings
02d7c494: ldr     x19, [x19, #0xc50]                         T:Assets.SimpleLocalization.Scripts.LocalizationSettings/<>c
02d7c498: tbnz    w8, #0, #0x2d7c4e0                         
02d7c49c: adrp    x0, #0x6264000                             
02d7c4a0: ldr     x0, [x0, #0xf90]                           T:System.Action
02d7c4a4: bl      #0x2b70db0                                 fn_2b70db0
02d7c4a8: adrp    x0, #0x626c000                             
02d7c4ac: ldr     x0, [x0, #0xab0]                           T:Assets.SimpleLocalization.Scripts.LocalizationSettings
02d7c4b0: bl      #0x2b70db0                                 fn_2b70db0
02d7c4b4: adrp    x0, #0x626c000                             
02d7c4b8: ldr     x0, [x0, #0xc58]                           M:Assets.SimpleLocalization.Scripts.LocalizationSettings/<>c::<.cctor>b__13_0
02d7c4bc: bl      #0x2b70db0                                 fn_2b70db0
02d7c4c0: adrp    x0, #0x626c000                             
02d7c4c4: ldr     x0, [x0, #0xc50]                           T:Assets.SimpleLocalization.Scripts.LocalizationSettings/<>c
02d7c4c8: bl      #0x2b70db0                                 fn_2b70db0
02d7c4cc: adrp    x0, #0x626c000                             
02d7c4d0: ldr     x0, [x0, #0xc48]                           S:'https://docs.google.com/spreadsheets/d/{0}/export?format=csv&gid={1}'
02d7c4d4: bl      #0x2b70db0                                 fn_2b70db0
02d7c4d8: mov     w8, #1                                     
02d7c4dc: strb    w8, [x22, #0x416]                          
02d7c4e0: ldr     x8, [x21]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7c4e4: ldr     x1, [x20]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7c4e8: adrp    x22, #0x6264000                            
02d7c4ec: adrp    x20, #0x626c000                            
02d7c4f0: ldr     x8, [x8, #0xb8]                            
02d7c4f4: str     x1, [x8]                                   
02d7c4f8: ldr     x8, [x21]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7c4fc: ldr     x22, [x22, #0xf90]                         T:System.Action
02d7c500: ldr     x20, [x20, #0xc58]                         M:Assets.SimpleLocalization.Scripts.LocalizationSettings/<>c::<.cctor>b__13_0
02d7c504: ldr     x0, [x8, #0xb8]                            
02d7c508: bl      #0x2b70d54                                 fn_2b70d54
02d7c50c: ldr     x0, [x19]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7c510: ldr     w8, [x0, #0xe4]                            [626c0e4]=0 f=0,0
02d7c514: cbnz    w8, #0x2d7c520                             
02d7c518: bl      #0x2b70f30                                 fn_2b70f30
02d7c51c: ldr     x0, [x19]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7c520: ldr     x8, [x0, #0xb8]                            MS:System.Collections.Generic.List`1::Add
02d7c524: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d7c528: ldr     x19, [x8]                                  
02d7c52c: bl      #0x2b7104c                                 fn_2b7104c
02d7c530: ldr     x2, [x20]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7c534: mov     x1, x19                                    
02d7c538: mov     x3, xzr                                    
02d7c53c: mov     x20, x0                                    
02d7c540: bl      #0x4d8ddbc                                 System.Action::.ctor
02d7c544: ldr     x8, [x21]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7c548: mov     x1, x20                                    
02d7c54c: ldp     x22, x21, [sp, #0x10]                      
02d7c550: ldr     x0, [x8, #0xb8]                            
02d7c554: str     x20, [x0, #0x10]!                          .OnRunEditor
02d7c558: ldp     x20, x19, [sp, #0x20]                      
02d7c55c: ldr     x30, [sp], #0x30                           
02d7c560: b       #0x2b70d54                                 
