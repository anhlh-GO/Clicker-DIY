#### CLASS JobGame.CollectingCoin/<CollectCoins>d__20 parent= System.ValueType
#   field <>1__state                     int                                                off=0x10 attr=6 
#   field <>t__builder                   System.Runtime.CompilerServices.AsyncVoidMethodBuilder off=0x18 attr=6 
#   field <>4__this                      JobGame.CollectingCoin                             off=0x38 attr=6 
#   field coinAmount                     int                                                off=0x40 attr=6 
#   field onCoinCollected                System.Action                                      off=0x48 attr=6 
#   field <>u__1                         Cysharp.Threading.Tasks.UniTask/Awaiter            off=0x50 attr=1 
## MoveNext() -> void
---- JobGame.CollectingCoin/<CollectCoins>d__20::MoveNext 0x2d128c4
02d128c4: sub     sp, sp, #0x80                              
02d128c8: str     x30, [sp, #0x40]                           
02d128cc: stp     x24, x23, [sp, #0x50]                      
02d128d0: stp     x22, x21, [sp, #0x60]                      
02d128d4: stp     x20, x19, [sp, #0x70]                      
02d128d8: adrp    x20, #0x662f000                            
02d128dc: mov     x19, x0                                    
02d128e0: ldrb    w8, [x20, #0xfc5]                          
02d128e4: tbnz    w8, #0, #0x2d12920                         
02d128e8: adrp    x0, #0x6269000                             
02d128ec: ldr     x0, [x0, #0x830]                           MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::AwaitUnsafeOnCompleted
02d128f0: bl      #0x2b70db0                                 fn_2b70db0
02d128f4: adrp    x0, #0x6269000                             
02d128f8: ldr     x0, [x0, #0x838]                           M:JobGame.CollectingCoin::<CollectCoins>b__20_0
02d128fc: bl      #0x2b70db0                                 fn_2b70db0
02d12900: adrp    x0, #0x6265000                             
02d12904: ldr     x0, [x0, #0xfb0]                           T:type9979(k15)
02d12908: bl      #0x2b70db0                                 fn_2b70db0
02d1290c: adrp    x0, #0x6266000                             
02d12910: ldr     x0, [x0, #0xcc8]                           T:Cysharp.Threading.Tasks.UniTask
02d12914: bl      #0x2b70db0                                 fn_2b70db0
02d12918: mov     w8, #1                                     
02d1291c: strb    w8, [x20, #0xfc5]                          
02d12920: adrp    x24, #0x6266000                            
02d12924: adrp    x23, #0x662f000                            
02d12928: ldr     x24, [x24, #0xcc8]                         T:Cysharp.Threading.Tasks.UniTask
02d1292c: ldr     w8, [x19]                                  
02d12930: ldr     x20, [x19, #0x28]                          
02d12934: stp     xzr, xzr, [sp, #0x20]                      
02d12938: str     wzr, [sp, #0x18]                           
02d1293c: cbz     w8, #0x2d12980                             
02d12940: cmp     w8, #1                                     
02d12944: b.eq    #0x2d12968                                 
02d12948: cmp     w8, #2                                     
02d1294c: b.ne    #0x2d12998                                 
02d12950: ldr     q0, [x19, #0x40]                           .coinAmount
02d12954: mov     w8, #-1                                    
02d12958: stp     xzr, xzr, [x19, #0x40]                     .coinAmount
02d1295c: str     w8, [x19]                                  
02d12960: str     q0, [sp, #0x20]                            
02d12964: b       #0x2d12e14                                 
02d12968: ldr     q0, [x19, #0x40]                           .coinAmount
02d1296c: mov     w8, #-1                                    
02d12970: stp     xzr, xzr, [x19, #0x40]                     .coinAmount
02d12974: str     w8, [x19]                                  
02d12978: str     q0, [sp, #0x20]                            
02d1297c: b       #0x2d12c80                                 
02d12980: ldr     q0, [x19, #0x40]                           .coinAmount
02d12984: mov     w8, #-1                                    
02d12988: stp     xzr, xzr, [x19, #0x40]                     .coinAmount
02d1298c: str     w8, [x19]                                  
02d12990: str     q0, [sp, #0x20]                            
02d12994: b       #0x2d12ac8                                 
02d12998: adrp    x8, #0x6265000                             
02d1299c: ldr     x8, [x8, #0xfb0]                           T:type9979(k15)
02d129a0: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02d129a4: bl      #0x2b7104c                                 fn_2b7104c
02d129a8: adrp    x8, #0x6269000                             
02d129ac: mov     x21, x0                                    
02d129b0: ldr     x8, [x8, #0x838]                           M:JobGame.CollectingCoin::<CollectCoins>b__20_0
02d129b4: ldr     x2, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d129b8: mov     x1, x20                                    
02d129bc: mov     x3, xzr                                    
02d129c0: bl      #0x4932dc8                                 fn_4932dc8
02d129c4: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d129c8: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d129cc: cbnz    w8, #0x2d129d4                             
02d129d0: bl      #0x2b70f30                                 fn_2b70f30
02d129d4: mov     x0, x21                                    
02d129d8: mov     w1, #8                                     
02d129dc: mov     x2, xzr                                    
02d129e0: mov     w3, wzr                                    
02d129e4: mov     x4, xzr                                    
02d129e8: bl      #0x5449e4c                                 Cysharp.Threading.Tasks.UniTask::WaitUntil
02d129ec: stp     x0, x1, [sp, #0x30]                        
02d129f0: add     x0, sp, #0x30                              
02d129f4: mov     x1, xzr                                    
02d129f8: bl      #0x2b70d54                                 fn_2b70d54
02d129fc: adrp    x21, #0x662f000                            
02d12a00: ldr     q0, [sp, #0x30]                            
02d12a04: ldrb    w8, [x21, #0xbdc]                          
02d12a08: str     q0, [sp, #0x20]                            
02d12a0c: cbnz    w8, #0x2d12a24                             
02d12a10: adrp    x0, #0x6266000                             
02d12a14: ldr     x0, [x0, #0xcc8]                           T:Cysharp.Threading.Tasks.UniTask
02d12a18: bl      #0x2b70db0                                 fn_2b70db0
02d12a1c: mov     w8, #1                                     
02d12a20: strb    w8, [x21, #0xbdc]                          
02d12a24: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d12a28: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d12a2c: cbnz    w8, #0x2d12a34                             
02d12a30: bl      #0x2b70f30                                 fn_2b70f30
02d12a34: adrp    x21, #0x662f000                            
02d12a38: ldrb    w8, [x21, #0xbdd]                          
02d12a3c: cbnz    w8, #0x2d12a54                             
02d12a40: adrp    x0, #0x6266000                             
02d12a44: ldr     x0, [x0, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02d12a48: bl      #0x2b70db0                                 fn_2b70db0
02d12a4c: mov     w8, #1                                     
02d12a50: strb    w8, [x21, #0xbdd]                          
02d12a54: ldr     x21, [sp, #0x20]                           
02d12a58: cbz     x21, #0x2d12ac8                            
02d12a5c: adrp    x10, #0x6266000                            
02d12a60: ldr     x8, [x21]                                  &2b706c4(=eb01011ff9400808)
02d12a64: ldr     x10, [x10, #0xcd0]                         T:Cysharp.Threading.Tasks.IUniTaskSource
02d12a68: ldrh    w22, [sp, #0x28]                           
02d12a6c: ldrh    w9, [x8, #0x12e]                           
02d12a70: ldr     x1, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d12a74: cbz     x9, #0x2d12a98                             
02d12a78: ldr     x10, [x8, #0xb0]                           M:Trading.TradingSession/<>c__DisplayClass65_0::<BuildResult>b__0
02d12a7c: add     x10, x10, #8                               &6266008
02d12a80: ldur    x11, [x10, #-8]                            
02d12a84: cmp     x11, x1                                    
02d12a88: b.eq    #0x2d12aa8                                 
02d12a8c: subs    x9, x9, #1                                 
02d12a90: add     x10, x10, #0x10                            &6266010
02d12a94: b.ne    #0x2d12a80                                 
02d12a98: mov     x0, x21                                    
02d12a9c: mov     w2, wzr                                    
02d12aa0: bl      #0x2baa05c                                 fn_2baa05c
02d12aa4: b       #0x2d12ab4                                 
02d12aa8: ldrsw   x9, [x10]                                  
02d12aac: add     x8, x8, x9, lsl #4                         &6269000
02d12ab0: add     x0, x8, #0x138                             &6269138
02d12ab4: ldp     x8, x2, [x0]                               
02d12ab8: mov     x0, x21                                    
02d12abc: mov     w1, w22                                    
02d12ac0: blr     x8                                         
02d12ac4: cbz     w0, #0x2d12f68                             
02d12ac8: ldrb    w8, [x23, #0xbde]                          
02d12acc: cbnz    w8, #0x2d12ae4                             
02d12ad0: adrp    x0, #0x6266000                             
02d12ad4: ldr     x0, [x0, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02d12ad8: bl      #0x2b70db0                                 fn_2b70db0
02d12adc: mov     w8, #1                                     
02d12ae0: strb    w8, [x23, #0xbde]                          
02d12ae4: ldr     x21, [sp, #0x20]                           
02d12ae8: cbz     x21, #0x2d12b58                            
02d12aec: adrp    x10, #0x6266000                            
02d12af0: ldr     x8, [x21]                                  &2b706c4(=eb01011ff9400808)
02d12af4: ldr     x10, [x10, #0xcd0]                         T:Cysharp.Threading.Tasks.IUniTaskSource
02d12af8: ldrh    w22, [sp, #0x28]                           
02d12afc: ldrh    w9, [x8, #0x12e]                           
02d12b00: ldr     x1, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d12b04: cbz     x9, #0x2d12b28                             
02d12b08: ldr     x10, [x8, #0xb0]                           M:Trading.TradingSession/<>c__DisplayClass65_0::<BuildResult>b__0
02d12b0c: add     x10, x10, #8                               &6266008
02d12b10: ldur    x11, [x10, #-8]                            
02d12b14: cmp     x11, x1                                    
02d12b18: b.eq    #0x2d12b38                                 
02d12b1c: subs    x9, x9, #1                                 
02d12b20: add     x10, x10, #0x10                            &6266010
02d12b24: b.ne    #0x2d12b10                                 
02d12b28: mov     x0, x21                                    
02d12b2c: mov     w2, #2                                     
02d12b30: bl      #0x2baa05c                                 fn_2baa05c
02d12b34: b       #0x2d12b48                                 
02d12b38: ldr     w9, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d12b3c: add     w9, w9, #2                                 
02d12b40: add     x8, x8, w9, sxtw #4                        &6269000
02d12b44: add     x0, x8, #0x138                             &6269138
02d12b48: ldp     x8, x2, [x0]                               
02d12b4c: mov     x0, x21                                    
02d12b50: mov     w1, w22                                    
02d12b54: blr     x8                                         
02d12b58: cbz     x20, #0x2d12fac                            
02d12b5c: mov     w8, #1                                     
02d12b60: strb    w8, [x20, #0x79]                           
02d12b64: mov     x0, x20                                    
02d12b68: bl      #0x2d122f0                                 JobGame.CollectingCoin::ResetCoins
02d12b6c: ldr     x0, [x20, #0x30]                           &2b706f8(=d65f03c0b9401800)
02d12b70: cbz     x0, #0x2d12fb0                             
02d12b74: ldr     w21, [x19, #0x30]                          
02d12b78: mov     x1, xzr                                    
02d12b7c: bl      #0x5b45c24                                 UnityEngine.Transform::get_localPosition
02d12b80: mov     x0, x20                                    
02d12b84: mov     w1, w21                                    
02d12b88: bl      #0x2d124c8                                 JobGame.CollectingCoin::SpawnCoin
02d12b8c: mov     x21, x0                                    
02d12b90: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d12b94: mov     x22, x1                                    
02d12b98: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d12b9c: cbnz    w8, #0x2d12ba4                             
02d12ba0: bl      #0x2b70f30                                 fn_2b70f30
02d12ba4: stp     x21, x22, [sp, #0x30]                      
02d12ba8: add     x0, sp, #0x30                              
02d12bac: mov     x1, xzr                                    
02d12bb0: bl      #0x2b70d54                                 fn_2b70d54
02d12bb4: adrp    x21, #0x662f000                            
02d12bb8: ldr     q0, [sp, #0x30]                            
02d12bbc: ldrb    w8, [x21, #0xbdc]                          
02d12bc0: str     q0, [sp, #0x20]                            
02d12bc4: cbnz    w8, #0x2d12bdc                             
02d12bc8: adrp    x0, #0x6266000                             
02d12bcc: ldr     x0, [x0, #0xcc8]                           T:Cysharp.Threading.Tasks.UniTask
02d12bd0: bl      #0x2b70db0                                 fn_2b70db0
02d12bd4: mov     w8, #1                                     
02d12bd8: strb    w8, [x21, #0xbdc]                          
02d12bdc: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d12be0: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d12be4: cbnz    w8, #0x2d12bec                             
02d12be8: bl      #0x2b70f30                                 fn_2b70f30
02d12bec: adrp    x21, #0x662f000                            
02d12bf0: ldrb    w8, [x21, #0xbdd]                          
02d12bf4: cbnz    w8, #0x2d12c0c                             
02d12bf8: adrp    x0, #0x6266000                             
02d12bfc: ldr     x0, [x0, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02d12c00: bl      #0x2b70db0                                 fn_2b70db0
02d12c04: mov     w8, #1                                     
02d12c08: strb    w8, [x21, #0xbdd]                          
02d12c0c: ldr     x21, [sp, #0x20]                           
02d12c10: cbz     x21, #0x2d12c80                            
02d12c14: adrp    x10, #0x6266000                            
02d12c18: ldr     x8, [x21]                                  &2b706c4(=eb01011ff9400808)
02d12c1c: ldr     x10, [x10, #0xcd0]                         T:Cysharp.Threading.Tasks.IUniTaskSource
02d12c20: ldrh    w22, [sp, #0x28]                           
02d12c24: ldrh    w9, [x8, #0x12e]                           
02d12c28: ldr     x1, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d12c2c: cbz     x9, #0x2d12c50                             
02d12c30: ldr     x10, [x8, #0xb0]                           M:Trading.TradingSession/<>c__DisplayClass65_0::<BuildResult>b__0
02d12c34: add     x10, x10, #8                               &6266008
02d12c38: ldur    x11, [x10, #-8]                            
02d12c3c: cmp     x11, x1                                    
02d12c40: b.eq    #0x2d12c60                                 
02d12c44: subs    x9, x9, #1                                 
02d12c48: add     x10, x10, #0x10                            &6266010
02d12c4c: b.ne    #0x2d12c38                                 
02d12c50: mov     x0, x21                                    
02d12c54: mov     w2, wzr                                    
02d12c58: bl      #0x2baa05c                                 fn_2baa05c
02d12c5c: b       #0x2d12c6c                                 
02d12c60: ldrsw   x9, [x10]                                  
02d12c64: add     x8, x8, x9, lsl #4                         &6269000
02d12c68: add     x0, x8, #0x138                             &6269138
02d12c6c: ldp     x8, x2, [x0]                               
02d12c70: mov     x0, x21                                    
02d12c74: mov     w1, w22                                    
02d12c78: blr     x8                                         
02d12c7c: cbz     w0, #0x2d12f2c                             
02d12c80: ldrb    w8, [x23, #0xbde]                          
02d12c84: cbnz    w8, #0x2d12c9c                             
02d12c88: adrp    x0, #0x6266000                             
02d12c8c: ldr     x0, [x0, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02d12c90: bl      #0x2b70db0                                 fn_2b70db0
02d12c94: mov     w8, #1                                     
02d12c98: strb    w8, [x23, #0xbde]                          
02d12c9c: ldr     x21, [sp, #0x20]                           
02d12ca0: cbz     x21, #0x2d12d10                            
02d12ca4: adrp    x10, #0x6266000                            
02d12ca8: ldr     x8, [x21]                                  &2b706c4(=eb01011ff9400808)
02d12cac: ldr     x10, [x10, #0xcd0]                         T:Cysharp.Threading.Tasks.IUniTaskSource
02d12cb0: ldrh    w22, [sp, #0x28]                           
02d12cb4: ldrh    w9, [x8, #0x12e]                           
02d12cb8: ldr     x1, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d12cbc: cbz     x9, #0x2d12ce0                             
02d12cc0: ldr     x10, [x8, #0xb0]                           M:Trading.TradingSession/<>c__DisplayClass65_0::<BuildResult>b__0
02d12cc4: add     x10, x10, #8                               &6266008
02d12cc8: ldur    x11, [x10, #-8]                            
02d12ccc: cmp     x11, x1                                    
02d12cd0: b.eq    #0x2d12cf0                                 
02d12cd4: subs    x9, x9, #1                                 
02d12cd8: add     x10, x10, #0x10                            &6266010
02d12cdc: b.ne    #0x2d12cc8                                 
02d12ce0: mov     x0, x21                                    
02d12ce4: mov     w2, #2                                     
02d12ce8: bl      #0x2baa05c                                 fn_2baa05c
02d12cec: b       #0x2d12d00                                 
02d12cf0: ldr     w9, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d12cf4: add     w9, w9, #2                                 
02d12cf8: add     x8, x8, w9, sxtw #4                        &6269000
02d12cfc: add     x0, x8, #0x138                             &6269138
02d12d00: ldp     x8, x2, [x0]                               
02d12d04: mov     x0, x21                                    
02d12d08: mov     w1, w22                                    
02d12d0c: blr     x8                                         
02d12d10: cbz     x20, #0x2d12fa8                            
02d12d14: ldr     x1, [x19, #0x38]                           .<>4__this
02d12d18: mov     x0, x20                                    
02d12d1c: bl      #0x2d125a0                                 JobGame.CollectingCoin::MoveCoinsTask
02d12d20: mov     x21, x0                                    
02d12d24: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d12d28: mov     x22, x1                                    
02d12d2c: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d12d30: cbnz    w8, #0x2d12d38                             
02d12d34: bl      #0x2b70f30                                 fn_2b70f30
02d12d38: stp     x21, x22, [sp, #0x30]                      
02d12d3c: add     x0, sp, #0x30                              
02d12d40: mov     x1, xzr                                    
02d12d44: bl      #0x2b70d54                                 fn_2b70d54
02d12d48: adrp    x21, #0x662f000                            
02d12d4c: ldr     q0, [sp, #0x30]                            
02d12d50: ldrb    w8, [x21, #0xbdc]                          
02d12d54: str     q0, [sp, #0x20]                            
02d12d58: cbnz    w8, #0x2d12d70                             
02d12d5c: adrp    x0, #0x6266000                             
02d12d60: ldr     x0, [x0, #0xcc8]                           T:Cysharp.Threading.Tasks.UniTask
02d12d64: bl      #0x2b70db0                                 fn_2b70db0
02d12d68: mov     w8, #1                                     
02d12d6c: strb    w8, [x21, #0xbdc]                          
02d12d70: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d12d74: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d12d78: cbnz    w8, #0x2d12d80                             
02d12d7c: bl      #0x2b70f30                                 fn_2b70f30
02d12d80: adrp    x21, #0x662f000                            
02d12d84: ldrb    w8, [x21, #0xbdd]                          
02d12d88: cbnz    w8, #0x2d12da0                             
02d12d8c: adrp    x0, #0x6266000                             
02d12d90: ldr     x0, [x0, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02d12d94: bl      #0x2b70db0                                 fn_2b70db0
02d12d98: mov     w8, #1                                     
02d12d9c: strb    w8, [x21, #0xbdd]                          
02d12da0: ldr     x21, [sp, #0x20]                           
02d12da4: cbz     x21, #0x2d12e14                            
02d12da8: adrp    x10, #0x6266000                            
02d12dac: ldr     x8, [x21]                                  &2b706c4(=eb01011ff9400808)
02d12db0: ldr     x10, [x10, #0xcd0]                         T:Cysharp.Threading.Tasks.IUniTaskSource
02d12db4: ldrh    w22, [sp, #0x28]                           
02d12db8: ldrh    w9, [x8, #0x12e]                           
02d12dbc: ldr     x1, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d12dc0: cbz     x9, #0x2d12de4                             
02d12dc4: ldr     x10, [x8, #0xb0]                           M:Trading.TradingSession/<>c__DisplayClass65_0::<BuildResult>b__0
02d12dc8: add     x10, x10, #8                               &6266008
02d12dcc: ldur    x11, [x10, #-8]                            
02d12dd0: cmp     x11, x1                                    
02d12dd4: b.eq    #0x2d12df4                                 
02d12dd8: subs    x9, x9, #1                                 
02d12ddc: add     x10, x10, #0x10                            &6266010
02d12de0: b.ne    #0x2d12dcc                                 
02d12de4: mov     x0, x21                                    
02d12de8: mov     w2, wzr                                    
02d12dec: bl      #0x2baa05c                                 fn_2baa05c
02d12df0: b       #0x2d12e00                                 
02d12df4: ldrsw   x9, [x10]                                  
02d12df8: add     x8, x8, x9, lsl #4                         &6269000
02d12dfc: add     x0, x8, #0x138                             &6269138
02d12e00: ldp     x8, x2, [x0]                               
02d12e04: mov     x0, x21                                    
02d12e08: mov     w1, w22                                    
02d12e0c: blr     x8                                         
02d12e10: cbz     w0, #0x2d12ef0                             
02d12e14: ldrb    w8, [x23, #0xbde]                          
02d12e18: cbnz    w8, #0x2d12e30                             
02d12e1c: adrp    x0, #0x6266000                             
02d12e20: ldr     x0, [x0, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02d12e24: bl      #0x2b70db0                                 fn_2b70db0
02d12e28: mov     w8, #1                                     
02d12e2c: strb    w8, [x23, #0xbde]                          
02d12e30: ldr     x21, [sp, #0x20]                           
02d12e34: cbz     x21, #0x2d12ea4                            
02d12e38: adrp    x10, #0x6266000                            
02d12e3c: ldr     x8, [x21]                                  &2b706c4(=eb01011ff9400808)
02d12e40: ldr     x10, [x10, #0xcd0]                         T:Cysharp.Threading.Tasks.IUniTaskSource
02d12e44: ldrh    w22, [sp, #0x28]                           
02d12e48: ldrh    w9, [x8, #0x12e]                           
02d12e4c: ldr     x1, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d12e50: cbz     x9, #0x2d12e74                             
02d12e54: ldr     x10, [x8, #0xb0]                           M:Trading.TradingSession/<>c__DisplayClass65_0::<BuildResult>b__0
02d12e58: add     x10, x10, #8                               &6266008
02d12e5c: ldur    x11, [x10, #-8]                            
02d12e60: cmp     x11, x1                                    
02d12e64: b.eq    #0x2d12e84                                 
02d12e68: subs    x9, x9, #1                                 
02d12e6c: add     x10, x10, #0x10                            &6266010
02d12e70: b.ne    #0x2d12e5c                                 
02d12e74: mov     x0, x21                                    
02d12e78: mov     w2, #2                                     
02d12e7c: bl      #0x2baa05c                                 fn_2baa05c
02d12e80: b       #0x2d12e94                                 
02d12e84: ldr     w9, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d12e88: add     w9, w9, #2                                 
02d12e8c: add     x8, x8, w9, sxtw #4                        &6269000
02d12e90: add     x0, x8, #0x138                             &6269138
02d12e94: ldp     x8, x2, [x0]                               
02d12e98: mov     x0, x21                                    
02d12e9c: mov     w1, w22                                    
02d12ea0: blr     x8                                         
02d12ea4: cbz     x20, #0x2d12fa0                            
02d12ea8: ldr     x0, [x20, #0x30]                           &2b706f8(=d65f03c0b9401800)
02d12eac: strb    wzr, [x20, #0x79]                          
02d12eb0: cbz     x0, #0x2d12fa4                             
02d12eb4: ldp     s0, s1, [x20, #0x7c]                       
02d12eb8: ldr     s2, [x20, #0x84]                           [662f084]=600001b00000000 f=0,2.40742e-35
02d12ebc: mov     x1, xzr                                    
02d12ec0: bl      #0x5b46888                                 UnityEngine.Transform::set_position
02d12ec4: mov     w8, #-2                                    
02d12ec8: mov     x1, xzr                                    
02d12ecc: str     w8, [x19], #8                              
02d12ed0: mov     x0, x19                                    
02d12ed4: bl      #0x4d43b50                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::SetResult
02d12ed8: ldp     x20, x19, [sp, #0x70]                      
02d12edc: ldr     x30, [sp, #0x40]                           
02d12ee0: ldp     x22, x21, [sp, #0x60]                      
02d12ee4: ldp     x24, x23, [sp, #0x50]                      
02d12ee8: add     sp, sp, #0x80                              
02d12eec: ret                                                
02d12ef0: ldr     q0, [sp, #0x20]                            
02d12ef4: mov     w8, #2                                     
02d12ef8: str     w8, [x19]                                  
02d12efc: str     q0, [x19, #0x40]                           .coinAmount
02d12f00: add     x0, x19, #0x40                             
02d12f04: mov     x1, xzr                                    
02d12f08: bl      #0x2b70d54                                 fn_2b70d54
02d12f0c: adrp    x8, #0x6269000                             
02d12f10: ldr     x8, [x8, #0x830]                           MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::AwaitUnsafeOnCompleted
02d12f14: ldr     x3, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d12f18: add     x0, x19, #8                                
02d12f1c: add     x1, sp, #0x20                              
02d12f20: mov     x2, x19                                    
02d12f24: bl      #0x30c2d28                                 fn_30c2d28
02d12f28: b       #0x2d12ed8                                 
02d12f2c: ldr     q0, [sp, #0x20]                            
02d12f30: mov     w8, #1                                     
02d12f34: str     w8, [x19]                                  
02d12f38: str     q0, [x19, #0x40]                           .coinAmount
02d12f3c: add     x0, x19, #0x40                             
02d12f40: mov     x1, xzr                                    
02d12f44: bl      #0x2b70d54                                 fn_2b70d54
02d12f48: adrp    x8, #0x6269000                             
02d12f4c: ldr     x8, [x8, #0x830]                           MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::AwaitUnsafeOnCompleted
02d12f50: ldr     x3, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d12f54: add     x0, x19, #8                                
02d12f58: add     x1, sp, #0x20                              
02d12f5c: mov     x2, x19                                    
02d12f60: bl      #0x30c2d28                                 fn_30c2d28
02d12f64: b       #0x2d12ed8                                 
02d12f68: ldr     q0, [sp, #0x20]                            
02d12f6c: str     wzr, [x19]                                 
02d12f70: str     q0, [x19, #0x40]                           .coinAmount
02d12f74: add     x0, x19, #0x40                             
02d12f78: mov     x1, xzr                                    
02d12f7c: bl      #0x2b70d54                                 fn_2b70d54
02d12f80: adrp    x8, #0x6269000                             
02d12f84: ldr     x8, [x8, #0x830]                           MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::AwaitUnsafeOnCompleted
02d12f88: ldr     x3, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d12f8c: add     x0, x19, #8                                
02d12f90: add     x1, sp, #0x20                              
02d12f94: mov     x2, x19                                    
02d12f98: bl      #0x30c2d28                                 fn_30c2d28
02d12f9c: b       #0x2d12ed8                                 
02d12fa0: bl      #0x2b7105c                                 fn_2b7105c
02d12fa4: bl      #0x2b7105c                                 fn_2b7105c
02d12fa8: bl      #0x2b7105c                                 fn_2b7105c
02d12fac: bl      #0x2b7105c                                 fn_2b7105c
02d12fb0: bl      #0x2b7105c                                 fn_2b7105c
02d12fb4: b       #0x2d13018                                 
02d12fb8: b       #0x2d13018                                 
02d12fbc: b       #0x2d13018                                 
02d12fc0: b       #0x2d13018                                 
02d12fc4: b       #0x2d13018                                 
02d12fc8: b       #0x2d13018                                 
02d12fcc: b       #0x2d13018                                 
02d12fd0: b       #0x2d13018                                 
02d12fd4: b       #0x2d13018                                 
02d12fd8: b       #0x2d13018                                 
02d12fdc: b       #0x2d13018                                 
02d12fe0: b       #0x2d13018                                 
02d12fe4: b       #0x2d13018                                 
02d12fe8: b       #0x2d13018                                 
02d12fec: b       #0x2d13018                                 
02d12ff0: b       #0x2d13018                                 
02d12ff4: b       #0x2d13018                                 
02d12ff8: b       #0x2d13018                                 
02d12ffc: b       #0x2d13018                                 
02d13000: b       #0x2d13018                                 
02d13004: b       #0x2d13018                                 
02d13008: b       #0x2d13018                                 
02d1300c: b       #0x2d13018                                 
02d13010: b       #0x2d13018                                 
02d13014: b       #0x2d13018                                 
02d13018: mov     x20, x0                                    
02d1301c: cmp     w1, #1                                     
02d13020: b.eq    #0x2d13094                                 
02d13024: mov     w8, #1                                     
02d13028: cmp     w1, w8                                     
02d1302c: b.ne    #0x2d13150                                 
02d13030: mov     x0, x20                                    
02d13034: bl      #0x5e90260                                 fn_5e90260
02d13038: mov     x20, x0                                    
02d1303c: adrp    x0, #0x6263000                             
02d13040: ldr     x0, [x0, #0xae0]                           T:System.Exception
02d13044: bl      #0x2b70dc4                                 fn_2b70dc4
02d13048: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02d1304c: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d13050: bl      #0x2b71464                                 fn_2b71464
02d13054: tbz     w0, #0, #0x2d130e4                         
02d13058: ldrsw   x21, [sp, #0x18]                           
02d1305c: ldr     x20, [x20]                                 &2b706c4(=eb01011ff9400808)
02d13060: add     x8, sp, #8                                 
02d13064: str     x20, [x8, x21, lsl #3]                     
02d13068: add     w8, w21, #1                                
02d1306c: str     w8, [sp, #0x18]                            
02d13070: bl      #0x5e90270                                 fn_5e90270
02d13074: mov     w8, #-2                                    
02d13078: mov     x1, x20                                    
02d1307c: mov     x2, xzr                                    
02d13080: str     w8, [x19], #8                              
02d13084: mov     x0, x19                                    
02d13088: bl      #0x4d43cc0                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::SetException
02d1308c: str     w21, [sp, #0x18]                           
02d13090: b       #0x2d12ed8                                 
02d13094: mov     x0, x20                                    
02d13098: bl      #0x5e90260                                 fn_5e90260
02d1309c: mov     x20, x0                                    
02d130a0: adrp    x0, #0x6263000                             
02d130a4: ldr     x0, [x0, #0xae0]                           T:System.Exception
02d130a8: bl      #0x2b70dc4                                 fn_2b70dc4
02d130ac: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02d130b0: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d130b4: bl      #0x2b71464                                 fn_2b71464
02d130b8: tbz     w0, #0, #0x2d13108                         
02d130bc: ldrsw   x21, [sp, #0x18]                           
02d130c0: ldr     x20, [x20]                                 &2b706c4(=eb01011ff9400808)
02d130c4: add     x8, sp, #8                                 
02d130c8: str     x20, [x8, x21, lsl #3]                     
02d130cc: add     w8, w21, #1                                
02d130d0: str     w8, [sp, #0x18]                            
02d130d4: bl      #0x5e90270                                 fn_5e90270
02d130d8: str     w21, [sp, #0x18]                           
02d130dc: mov     x0, x20                                    
02d130e0: bl      #0x2b71054                                 fn_2b71054
02d130e4: mov     w0, #8                                     
02d130e8: bl      #0x5e90290                                 fn_5e90290
02d130ec: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02d130f0: str     x8, [x0]                                   
02d130f4: adrp    x1, #0x5e96000                             
02d130f8: add     x1, x1, #0x758                             &5e96758
02d130fc: mov     x2, xzr                                    
02d13100: bl      #0x5e902a0                                 fn_5e902a0
02d13104: b       #0x2d13128                                 
02d13108: mov     w0, #8                                     
02d1310c: bl      #0x5e90290                                 fn_5e90290
02d13110: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02d13114: str     x8, [x0]                                   
02d13118: adrp    x1, #0x5e96000                             
02d1311c: add     x1, x1, #0x758                             &5e96758
02d13120: mov     x2, xzr                                    
02d13124: bl      #0x5e902a0                                 fn_5e902a0
02d13128: b       #0x2d1312c                                 
02d1312c: mov     x20, x0                                    
02d13130: b       #0x2d13024                                 
02d13134: mov     x21, x1                                    
02d13138: mov     x20, x0                                    
02d1313c: bl      #0x5e90270                                 fn_5e90270
02d13140: mov     w1, w21                                    
02d13144: b       #0x2d13024                                 
02d13148: mov     x20, x0                                    
02d1314c: bl      #0x5e90270                                 fn_5e90270
02d13150: mov     x0, x20                                    
02d13154: bl      #0x2c6051c                                 fn_2c6051c
02d13158: bl      #0x27369b8                                 fn_27369b8
02d1315c: mov     x20, x0                                    
02d13160: b       #0x2d1301c                                 
## SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine stateMachine) -> void
---- JobGame.CollectingCoin/<CollectCoins>d__20::SetStateMachine 0x2d13164
02d13164: add     x0, x0, #8                                 
02d13168: mov     x2, xzr                                    
02d1316c: b       #0x4d43a8c                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::SetStateMachine
#### CLASS JobGame.CollectingCoin/<MoveCoinTask>d__24 parent= System.ValueType
#   field <>1__state                     int                                                off=0x10 attr=6 
#   field <>t__builder                   Cysharp.Threading.Tasks.CompilerServices.AsyncUniTaskMethodBuilder off=0x18 attr=6 
#   field <>4__this                      JobGame.CollectingCoin                             off=0x28 attr=6 
#   field coinInstance                   UnityEngine.Transform                              off=0x30 attr=6 
#   field onCompleted                    System.Action                                      off=0x38 attr=6 
#   field <>u__1                         Cysharp.Threading.Tasks.UniTask/Awaiter            off=0x40 attr=1 
## MoveNext() -> void
---- JobGame.CollectingCoin/<MoveCoinTask>d__24::MoveNext 0x2d13170
02d13170: sub     sp, sp, #0x70                              
02d13174: stp     x30, x25, [sp, #0x30]                      
02d13178: stp     x24, x23, [sp, #0x40]                      
02d1317c: stp     x22, x21, [sp, #0x50]                      
02d13180: stp     x20, x19, [sp, #0x60]                      
02d13184: adrp    x20, #0x662f000                            
02d13188: mov     x19, x0                                    
02d1318c: ldrb    w8, [x20, #0xfc6]                          
02d13190: tbnz    w8, #0, #0x2d131d8                         
02d13194: adrp    x0, #0x6269000                             
02d13198: ldr     x0, [x0, #0x840]                           MS:Cysharp.Threading.Tasks.CompilerServices.AsyncUniTaskMethodBuilder::AwaitUnsafeOnCompleted
02d1319c: bl      #0x2b70db0                                 fn_2b70db0
02d131a0: adrp    x0, #0x6268000                             
02d131a4: ldr     x0, [x0, #0xa70]                           MS:System.Collections.Generic.List`1::Remove
02d131a8: bl      #0x2b70db0                                 fn_2b70db0
02d131ac: adrp    x0, #0x6263000                             
02d131b0: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d131b4: bl      #0x2b70db0                                 fn_2b70db0
02d131b8: adrp    x0, #0x6266000                             
02d131bc: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d131c0: bl      #0x2b70db0                                 fn_2b70db0
02d131c4: adrp    x0, #0x6266000                             
02d131c8: ldr     x0, [x0, #0xcc8]                           T:Cysharp.Threading.Tasks.UniTask
02d131cc: bl      #0x2b70db0                                 fn_2b70db0
02d131d0: mov     w8, #1                                     
02d131d4: strb    w8, [x20, #0xfc6]                          
02d131d8: adrp    x25, #0x6263000                            
02d131dc: adrp    x24, #0x6266000                            
02d131e0: adrp    x23, #0x662f000                            
02d131e4: ldr     x25, [x25, #0x918]                         T:UnityEngine.Object
02d131e8: ldr     x24, [x24, #0xcc8]                         T:Cysharp.Threading.Tasks.UniTask
02d131ec: ldr     w8, [x19]                                  
02d131f0: ldr     x20, [x19, #0x18]                          .<>t__builder
02d131f4: stp     xzr, xzr, [sp, #0x10]                      
02d131f8: str     wzr, [sp, #8]                              
02d131fc: cbz     w8, #0x2d132ac                             
02d13200: cmp     w8, #1                                     
02d13204: b.eq    #0x2d13228                                 
02d13208: cmp     w8, #2                                     
02d1320c: b.ne    #0x2d13330                                 
02d13210: ldr     q0, [x19, #0x30]                           .coinInstance
02d13214: mov     w8, #-1                                    
02d13218: stp     xzr, xzr, [x19, #0x30]                     .coinInstance
02d1321c: str     w8, [x19]                                  
02d13220: str     q0, [sp, #0x10]                            
02d13224: b       #0x2d13688                                 
02d13228: ldr     q0, [x19, #0x30]                           .coinInstance
02d1322c: mov     w8, #-1                                    
02d13230: stp     xzr, xzr, [x19, #0x30]                     .coinInstance
02d13234: str     w8, [x19]                                  
02d13238: str     q0, [sp, #0x10]                            
02d1323c: ldrb    w8, [x23, #0xbde]                          
02d13240: cbnz    w8, #0x2d13258                             
02d13244: adrp    x0, #0x6266000                             
02d13248: ldr     x0, [x0, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02d1324c: bl      #0x2b70db0                                 fn_2b70db0
02d13250: mov     w8, #1                                     
02d13254: strb    w8, [x23, #0xbde]                          
02d13258: ldr     x21, [sp, #0x10]                           
02d1325c: cbz     x21, #0x2d134b8                            
02d13260: adrp    x9, #0x6266000                             
02d13264: ldr     x8, [x21]                                  
02d13268: ldr     x9, [x9, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02d1326c: ldrh    w22, [sp, #0x18]                           
02d13270: ldrh    w10, [x8, #0x12e]                          
02d13274: ldr     x1, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d13278: cbz     x10, #0x2d1329c                            
02d1327c: ldr     x9, [x8, #0xb0]                            
02d13280: add     x9, x9, #8                                 &6266008
02d13284: ldur    x11, [x9, #-8]                             
02d13288: cmp     x11, x1                                    
02d1328c: b.eq    #0x2d13498                                 
02d13290: subs    x10, x10, #1                               
02d13294: add     x9, x9, #0x10                              &6266010
02d13298: b.ne    #0x2d13284                                 
02d1329c: mov     x0, x21                                    
02d132a0: mov     w2, #2                                     
02d132a4: bl      #0x2baa05c                                 fn_2baa05c
02d132a8: b       #0x2d134a8                                 
02d132ac: ldr     q0, [x19, #0x30]                           .coinInstance
02d132b0: mov     w8, #-1                                    
02d132b4: stp     xzr, xzr, [x19, #0x30]                     .coinInstance
02d132b8: str     w8, [x19]                                  
02d132bc: str     q0, [sp, #0x10]                            
02d132c0: ldrb    w8, [x23, #0xbde]                          
02d132c4: cbnz    w8, #0x2d132dc                             
02d132c8: adrp    x0, #0x6266000                             
02d132cc: ldr     x0, [x0, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02d132d0: bl      #0x2b70db0                                 fn_2b70db0
02d132d4: mov     w8, #1                                     
02d132d8: strb    w8, [x23, #0xbde]                          
02d132dc: ldr     x21, [sp, #0x10]                           
02d132e0: cbz     x21, #0x2d134b8                            
02d132e4: adrp    x9, #0x6266000                             
02d132e8: ldr     x8, [x21]                                  
02d132ec: ldr     x9, [x9, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02d132f0: ldrh    w22, [sp, #0x18]                           
02d132f4: ldrh    w10, [x8, #0x12e]                          
02d132f8: ldr     x1, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d132fc: cbz     x10, #0x2d13320                            
02d13300: ldr     x9, [x8, #0xb0]                            
02d13304: add     x9, x9, #8                                 &6266008
02d13308: ldur    x11, [x9, #-8]                             
02d1330c: cmp     x11, x1                                    
02d13310: b.eq    #0x2d13498                                 
02d13314: subs    x10, x10, #1                               
02d13318: add     x9, x9, #0x10                              &6266010
02d1331c: b.ne    #0x2d13308                                 
02d13320: mov     x0, x21                                    
02d13324: mov     w2, #2                                     
02d13328: bl      #0x2baa05c                                 fn_2baa05c
02d1332c: b       #0x2d134a8                                 
02d13330: cbz     x20, #0x2d13a20                            
02d13334: ldr     x0, [x25]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d13338: ldr     x21, [x20, #0x38]                          [662f038]=6000016 f=2.40742e-35,0 .onCompleted
02d1333c: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d13340: cbnz    w8, #0x2d13348                             
02d13344: bl      #0x2b70f30                                 fn_2b70f30
02d13348: mov     x0, x21                                    
02d1334c: mov     x1, xzr                                    
02d13350: mov     x2, xzr                                    
02d13354: bl      #0x5b37d84                                 UnityEngine.Object::op_Equality
02d13358: mov     w8, w0                                     
02d1335c: ldr     x0, [x19, #0x20]                           
02d13360: tbz     w8, #0, #0x2d1382c                         
02d13364: cbz     x0, #0x2d13a28                             
02d13368: mov     x1, xzr                                    
02d1336c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d13370: mov     x21, x0                                    
02d13374: mov     x0, x20                                    
02d13378: mov     x1, xzr                                    
02d1337c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d13380: cbz     x0, #0x2d13a34                             
02d13384: mov     x1, xzr                                    
02d13388: bl      #0x5b45c24                                 UnityEngine.Transform::get_localPosition
02d1338c: ldr     s3, [x20, #0x48]                           [662f048]=6000017 f=2.40742e-35,0
02d13390: mov     x0, x21                                    
02d13394: mov     w1, wzr                                    
02d13398: mov     x2, xzr                                    
02d1339c: bl      #0x2d97cf0                                 DG.Tweening.ShortcutExtensions::DOLocalMove
02d133a0: adrp    x8, #0x6266000                             
02d133a4: ldr     x8, [x8, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d133a8: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d133ac: mov     w1, #0x1a                                  
02d133b0: bl      #0x336fa0c                                 fn_336fa0c
02d133b4: mov     w1, wzr                                    
02d133b8: mov     x2, xzr                                    
02d133bc: mov     x3, xzr                                    
02d133c0: bl      #0x545d870                                 Cysharp.Threading.Tasks.DOTweenAsyncExtensions::ToUniTask
02d133c4: mov     x21, x0                                    
02d133c8: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d133cc: mov     x22, x1                                    
02d133d0: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d133d4: cbnz    w8, #0x2d133dc                             
02d133d8: bl      #0x2b70f30                                 fn_2b70f30
02d133dc: stp     x21, x22, [sp, #0x20]                      
02d133e0: add     x0, sp, #0x20                              
02d133e4: mov     x1, xzr                                    
02d133e8: bl      #0x2b70d54                                 fn_2b70d54
02d133ec: adrp    x21, #0x662f000                            
02d133f0: ldr     q0, [sp, #0x20]                            
02d133f4: ldrb    w8, [x21, #0xbdc]                          
02d133f8: str     q0, [sp, #0x10]                            
02d133fc: cbnz    w8, #0x2d13414                             
02d13400: adrp    x0, #0x6266000                             
02d13404: ldr     x0, [x0, #0xcc8]                           T:Cysharp.Threading.Tasks.UniTask
02d13408: bl      #0x2b70db0                                 fn_2b70db0
02d1340c: mov     w8, #1                                     
02d13410: strb    w8, [x21, #0xbdc]                          
02d13414: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d13418: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d1341c: cbnz    w8, #0x2d13424                             
02d13420: bl      #0x2b70f30                                 fn_2b70f30
02d13424: adrp    x21, #0x662f000                            
02d13428: ldrb    w8, [x21, #0xbdd]                          
02d1342c: cbnz    w8, #0x2d13444                             
02d13430: adrp    x0, #0x6266000                             
02d13434: ldr     x0, [x0, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02d13438: bl      #0x2b70db0                                 fn_2b70db0
02d1343c: mov     w8, #1                                     
02d13440: strb    w8, [x21, #0xbdd]                          
02d13444: ldr     x21, [sp, #0x10]                           
02d13448: cbz     x21, #0x2d132c0                            
02d1344c: adrp    x10, #0x6266000                            
02d13450: ldr     x8, [x21]                                  &2b706c4(=eb01011ff9400808)
02d13454: ldr     x10, [x10, #0xcd0]                         T:Cysharp.Threading.Tasks.IUniTaskSource
02d13458: ldrh    w22, [sp, #0x18]                           
02d1345c: ldrh    w9, [x8, #0x12e]                           
02d13460: ldr     x1, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d13464: cbz     x9, #0x2d13488                             
02d13468: ldr     x10, [x8, #0xb0]                           S:'native_banner_ad_on_off'
02d1346c: add     x10, x10, #8                               &6266008
02d13470: ldur    x11, [x10, #-8]                            
02d13474: cmp     x11, x1                                    
02d13478: b.eq    #0x2d139b4                                 
02d1347c: subs    x9, x9, #1                                 
02d13480: add     x10, x10, #0x10                            &6266010
02d13484: b.ne    #0x2d13470                                 
02d13488: mov     x0, x21                                    
02d1348c: mov     w2, wzr                                    
02d13490: bl      #0x2baa05c                                 fn_2baa05c
02d13494: b       #0x2d139c0                                 
02d13498: ldr     w9, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1349c: add     w9, w9, #2                                 
02d134a0: add     x8, x8, w9, sxtw #4                        &6266000
02d134a4: add     x0, x8, #0x138                             &6266138
02d134a8: ldp     x8, x2, [x0]                               
02d134ac: mov     x0, x21                                    
02d134b0: mov     w1, w22                                    
02d134b4: blr     x8                                         
02d134b8: mov     x0, xzr                                    
02d134bc: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d134c0: cbz     x0, #0x2d13a10                             
02d134c4: movi    d1, #0000000000000000                      
02d134c8: movi    d2, #0000000000000000                      
02d134cc: mov     w1, #6                                     
02d134d0: fmov    s0, #1.00000000                            
02d134d4: mov     w2, wzr                                    
02d134d8: mov     w3, wzr                                    
02d134dc: mov     x4, xzr                                    
02d134e0: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d134e4: cbz     x20, #0x2d13a14                            
02d134e8: ldr     x0, [x20, #0x60]                           &2b7072c(=14cc752491004000)
02d134ec: cbz     x0, #0x2d13a18                             
02d134f0: adrp    x8, #0x6268000                             
02d134f4: ldr     x8, [x8, #0xa70]                           MS:System.Collections.Generic.List`1::Remove
02d134f8: ldr     x1, [x19, #0x20]                           
02d134fc: ldr     x2, [x8]                                   S:'{0}/2'
02d13500: bl      #0x35aa7b4                                 fn_35aa7b4
02d13504: ldr     x0, [x25]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d13508: ldr     x21, [x19, #0x20]                          
02d1350c: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d13510: cbnz    w8, #0x2d13518                             
02d13514: bl      #0x2b70f30                                 fn_2b70f30
02d13518: mov     x0, x21                                    
02d1351c: mov     x1, xzr                                    
02d13520: bl      #0x5b3bb1c                                 UnityEngine.Object::op_Implicit
02d13524: tbz     w0, #0, #0x2d1358c                         
02d13528: ldr     x0, [x19, #0x20]                           
02d1352c: cbz     x0, #0x2d13a1c                             
02d13530: mov     x1, xzr                                    
02d13534: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d13538: mov     x21, x0                                    
02d1353c: ldr     x0, [x25]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d13540: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d13544: cbnz    w8, #0x2d1354c                             
02d13548: bl      #0x2b70f30                                 fn_2b70f30
02d1354c: mov     x0, x21                                    
02d13550: mov     x1, xzr                                    
02d13554: bl      #0x5b3bb1c                                 UnityEngine.Object::op_Implicit
02d13558: tbz     w0, #0, #0x2d1358c                         
02d1355c: ldr     x0, [x19, #0x20]                           
02d13560: cbz     x0, #0x2d13a24                             
02d13564: mov     x1, xzr                                    
02d13568: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d1356c: mov     x21, x0                                    
02d13570: ldr     x0, [x25]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d13574: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d13578: cbnz    w8, #0x2d13580                             
02d1357c: bl      #0x2b70f30                                 fn_2b70f30
02d13580: mov     x0, x21                                    
02d13584: mov     x1, xzr                                    
02d13588: bl      #0x5b3ca38                                 UnityEngine.Object::Destroy
02d1358c: mov     x0, x20                                    
02d13590: bl      #0x2d12730                                 JobGame.CollectingCoin::ReactToCollectionCoin
02d13594: mov     x21, x0                                    
02d13598: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1359c: mov     x22, x1                                    
02d135a0: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d135a4: cbnz    w8, #0x2d135ac                             
02d135a8: bl      #0x2b70f30                                 fn_2b70f30
02d135ac: stp     x21, x22, [sp, #0x20]                      
02d135b0: add     x0, sp, #0x20                              
02d135b4: mov     x1, xzr                                    
02d135b8: bl      #0x2b70d54                                 fn_2b70d54
02d135bc: adrp    x21, #0x662f000                            
02d135c0: ldr     q0, [sp, #0x20]                            
02d135c4: ldrb    w8, [x21, #0xbdc]                          
02d135c8: str     q0, [sp, #0x10]                            
02d135cc: cbnz    w8, #0x2d135e4                             
02d135d0: adrp    x0, #0x6266000                             
02d135d4: ldr     x0, [x0, #0xcc8]                           T:Cysharp.Threading.Tasks.UniTask
02d135d8: bl      #0x2b70db0                                 fn_2b70db0
02d135dc: mov     w8, #1                                     
02d135e0: strb    w8, [x21, #0xbdc]                          
02d135e4: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d135e8: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d135ec: cbnz    w8, #0x2d135f4                             
02d135f0: bl      #0x2b70f30                                 fn_2b70f30
02d135f4: adrp    x21, #0x662f000                            
02d135f8: ldrb    w8, [x21, #0xbdd]                          
02d135fc: cbnz    w8, #0x2d13614                             
02d13600: adrp    x0, #0x6266000                             
02d13604: ldr     x0, [x0, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02d13608: bl      #0x2b70db0                                 fn_2b70db0
02d1360c: mov     w8, #1                                     
02d13610: strb    w8, [x21, #0xbdd]                          
02d13614: ldr     x21, [sp, #0x10]                           
02d13618: cbz     x21, #0x2d13688                            
02d1361c: adrp    x10, #0x6266000                            
02d13620: ldr     x8, [x21]                                  &2b706c4(=eb01011ff9400808)
02d13624: ldr     x10, [x10, #0xcd0]                         T:Cysharp.Threading.Tasks.IUniTaskSource
02d13628: ldrh    w22, [sp, #0x18]                           
02d1362c: ldrh    w9, [x8, #0x12e]                           
02d13630: ldr     x1, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d13634: cbz     x9, #0x2d13658                             
02d13638: ldr     x10, [x8, #0xb0]                           S:'penguin_close_mouth'
02d1363c: add     x10, x10, #8                               &6266008
02d13640: ldur    x11, [x10, #-8]                            
02d13644: cmp     x11, x1                                    
02d13648: b.eq    #0x2d13668                                 
02d1364c: subs    x9, x9, #1                                 
02d13650: add     x10, x10, #0x10                            &6266010
02d13654: b.ne    #0x2d13640                                 
02d13658: mov     x0, x21                                    
02d1365c: mov     w2, wzr                                    
02d13660: bl      #0x2baa05c                                 fn_2baa05c
02d13664: b       #0x2d13674                                 
02d13668: ldrsw   x9, [x10]                                  
02d1366c: add     x8, x8, x9, lsl #4                         &6268000
02d13670: add     x0, x8, #0x138                             &6268138
02d13674: ldp     x8, x2, [x0]                               
02d13678: mov     x0, x21                                    
02d1367c: mov     w1, w22                                    
02d13680: blr     x8                                         
02d13684: cbz     w0, #0x2d136f8                             
02d13688: ldrb    w8, [x23, #0xbde]                          
02d1368c: cbnz    w8, #0x2d136a4                             
02d13690: adrp    x0, #0x6266000                             
02d13694: ldr     x0, [x0, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02d13698: bl      #0x2b70db0                                 fn_2b70db0
02d1369c: mov     w8, #1                                     
02d136a0: strb    w8, [x23, #0xbde]                          
02d136a4: ldr     x21, [sp, #0x10]                           
02d136a8: cbz     x21, #0x2d13754                            
02d136ac: adrp    x10, #0x6266000                            
02d136b0: ldr     x8, [x21]                                  &2b706c4(=eb01011ff9400808)
02d136b4: ldr     x10, [x10, #0xcd0]                         T:Cysharp.Threading.Tasks.IUniTaskSource
02d136b8: ldrh    w22, [sp, #0x18]                           
02d136bc: ldrh    w9, [x8, #0x12e]                           
02d136c0: ldr     x1, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d136c4: cbz     x9, #0x2d136e8                             
02d136c8: ldr     x10, [x8, #0xb0]                           S:'penguin_close_mouth'
02d136cc: add     x10, x10, #8                               &6266008
02d136d0: ldur    x11, [x10, #-8]                            
02d136d4: cmp     x11, x1                                    
02d136d8: b.eq    #0x2d13734                                 
02d136dc: subs    x9, x9, #1                                 
02d136e0: add     x10, x10, #0x10                            &6266010
02d136e4: b.ne    #0x2d136d0                                 
02d136e8: mov     x0, x21                                    
02d136ec: mov     w2, #2                                     
02d136f0: bl      #0x2baa05c                                 fn_2baa05c
02d136f4: b       #0x2d13744                                 
02d136f8: ldr     q0, [sp, #0x10]                            
02d136fc: mov     w8, #2                                     
02d13700: str     w8, [x19]                                  
02d13704: str     q0, [x19, #0x30]                           .coinInstance
02d13708: add     x0, x19, #0x30                             
02d1370c: mov     x1, xzr                                    
02d13710: bl      #0x2b70d54                                 fn_2b70d54
02d13714: adrp    x8, #0x6269000                             
02d13718: ldr     x8, [x8, #0x840]                           MS:Cysharp.Threading.Tasks.CompilerServices.AsyncUniTaskMethodBuilder::AwaitUnsafeOnCompleted
02d1371c: ldr     x3, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d13720: add     x0, x19, #8                                
02d13724: add     x1, sp, #0x10                              
02d13728: mov     x2, x19                                    
02d1372c: bl      #0x2d18f08                                 fn_2d18f08
02d13730: b       #0x2d13814                                 
02d13734: ldr     w9, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d13738: add     w9, w9, #2                                 
02d1373c: add     x8, x8, w9, sxtw #4                        &6269000
02d13740: add     x0, x8, #0x138                             &6269138
02d13744: ldp     x8, x2, [x0]                               
02d13748: mov     x0, x21                                    
02d1374c: mov     w1, w22                                    
02d13750: blr     x8                                         
02d13754: cbz     x20, #0x2d13a0c                            
02d13758: ldrb    w8, [x20, #0x78]                           
02d1375c: cbnz    w8, #0x2d13780                             
02d13760: mov     w8, #1                                     
02d13764: strb    w8, [x20, #0x78]                           
02d13768: ldr     x8, [x19, #0x28]                           .<>4__this
02d1376c: cbz     x8, #0x2d13780                             
02d13770: ldr     x0, [x8, #0x40]                            MS:System.Linq.Enumerable::Select
02d13774: ldr     x1, [x8, #0x28]                            T:Trading.TradingCounterRequest
02d13778: ldr     x9, [x8, #0x18]                            M:Trading.TradingSession::<ValidateTrade>b__57_0
02d1377c: blr     x9                                         
02d13780: adrp    x20, #0x662f000                            
02d13784: mov     w9, #-2                                    
02d13788: ldrb    w8, [x20, #0xe25]                          
02d1378c: str     w9, [x19]                                  
02d13790: cbnz    w8, #0x2d137a8                             
02d13794: adrp    x0, #0x6268000                             
02d13798: ldr     x0, [x0, #0xd8]                            T:Cysharp.Threading.Tasks.CompilerServices.IStateMachineRunnerPromise
02d1379c: bl      #0x2b70db0                                 fn_2b70db0
02d137a0: mov     w8, #1                                     
02d137a4: strb    w8, [x20, #0xe25]                          
02d137a8: ldr     x19, [x19, #8]                             
02d137ac: cbz     x19, #0x2d13814                            
02d137b0: adrp    x10, #0x6268000                            
02d137b4: ldr     x8, [x19]                                  
02d137b8: ldr     x10, [x10, #0xd8]                          T:Cysharp.Threading.Tasks.CompilerServices.IStateMachineRunnerPromise
02d137bc: ldrh    w9, [x8, #0x12e]                           
02d137c0: ldr     x1, [x10]                                  S:'{0}/2'
02d137c4: cbz     x9, #0x2d137e8                             
02d137c8: ldr     x10, [x8, #0xb0]                           M:Trading.TradingSession/<>c__DisplayClass65_0::<BuildResult>b__0
02d137cc: add     x10, x10, #8                               &6268008
02d137d0: ldur    x11, [x10, #-8]                            
02d137d4: cmp     x11, x1                                    
02d137d8: b.eq    #0x2d137f8                                 
02d137dc: subs    x9, x9, #1                                 
02d137e0: add     x10, x10, #0x10                            &6268010
02d137e4: b.ne    #0x2d137d0                                 
02d137e8: mov     x0, x19                                    
02d137ec: mov     w2, #2                                     
02d137f0: bl      #0x2baa05c                                 fn_2baa05c
02d137f4: b       #0x2d13808                                 
02d137f8: ldr     w9, [x10]                                  S:'{0}/2'
02d137fc: add     w9, w9, #2                                 
02d13800: add     x8, x8, w9, sxtw #4                        &6269000
02d13804: add     x0, x8, #0x138                             &6269138
02d13808: ldp     x8, x1, [x0]                               
02d1380c: mov     x0, x19                                    
02d13810: blr     x8                                         
02d13814: ldp     x20, x19, [sp, #0x60]                      
02d13818: ldp     x22, x21, [sp, #0x50]                      
02d1381c: ldp     x24, x23, [sp, #0x40]                      
02d13820: ldp     x30, x25, [sp, #0x30]                      
02d13824: add     sp, sp, #0x70                              
02d13828: ret                                                
02d1382c: cbz     x0, #0x2d13a2c                             
02d13830: mov     x1, xzr                                    
02d13834: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d13838: mov     x21, x0                                    
02d1383c: ldr     x0, [x20, #0x38]                           [662f038]=6000016 f=2.40742e-35,0 .onCompleted
02d13840: cbz     x0, #0x2d13a30                             
02d13844: mov     x1, xzr                                    
02d13848: bl      #0x5b45c24                                 UnityEngine.Transform::get_localPosition
02d1384c: ldr     s3, [x20, #0x48]                           [662f048]=6000017 f=2.40742e-35,0
02d13850: mov     x0, x21                                    
02d13854: mov     w1, wzr                                    
02d13858: mov     x2, xzr                                    
02d1385c: bl      #0x2d97cf0                                 DG.Tweening.ShortcutExtensions::DOLocalMove
02d13860: adrp    x8, #0x6266000                             
02d13864: ldr     x8, [x8, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d13868: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1386c: mov     w1, #0x1a                                  
02d13870: bl      #0x336fa0c                                 fn_336fa0c
02d13874: mov     w1, wzr                                    
02d13878: mov     x2, xzr                                    
02d1387c: mov     x3, xzr                                    
02d13880: bl      #0x545d870                                 Cysharp.Threading.Tasks.DOTweenAsyncExtensions::ToUniTask
02d13884: mov     x21, x0                                    
02d13888: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1388c: mov     x22, x1                                    
02d13890: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02d13894: cbnz    w8, #0x2d1389c                             
02d13898: bl      #0x2b70f30                                 fn_2b70f30
02d1389c: stp     x21, x22, [sp, #0x20]                      
02d138a0: add     x0, sp, #0x20                              
02d138a4: mov     x1, xzr                                    
02d138a8: bl      #0x2b70d54                                 fn_2b70d54
02d138ac: adrp    x21, #0x662f000                            
02d138b0: ldr     q0, [sp, #0x20]                            
02d138b4: ldrb    w8, [x21, #0xbdc]                          
02d138b8: str     q0, [sp, #0x10]                            
02d138bc: cbnz    w8, #0x2d138d4                             
02d138c0: adrp    x0, #0x6266000                             
02d138c4: ldr     x0, [x0, #0xcc8]                           T:Cysharp.Threading.Tasks.UniTask
02d138c8: bl      #0x2b70db0                                 fn_2b70db0
02d138cc: mov     w8, #1                                     
02d138d0: strb    w8, [x21, #0xbdc]                          
02d138d4: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d138d8: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d138dc: cbnz    w8, #0x2d138e4                             
02d138e0: bl      #0x2b70f30                                 fn_2b70f30
02d138e4: adrp    x21, #0x662f000                            
02d138e8: ldrb    w8, [x21, #0xbdd]                          
02d138ec: cbnz    w8, #0x2d13904                             
02d138f0: adrp    x0, #0x6266000                             
02d138f4: ldr     x0, [x0, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02d138f8: bl      #0x2b70db0                                 fn_2b70db0
02d138fc: mov     w8, #1                                     
02d13900: strb    w8, [x21, #0xbdd]                          
02d13904: ldr     x21, [sp, #0x10]                           
02d13908: cbz     x21, #0x2d1323c                            
02d1390c: adrp    x10, #0x6266000                            
02d13910: ldr     x8, [x21]                                  &2b706c4(=eb01011ff9400808)
02d13914: ldr     x10, [x10, #0xcd0]                         T:Cysharp.Threading.Tasks.IUniTaskSource
02d13918: ldrh    w22, [sp, #0x18]                           
02d1391c: ldrh    w9, [x8, #0x12e]                           
02d13920: ldr     x1, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d13924: cbz     x9, #0x2d13948                             
02d13928: ldr     x10, [x8, #0xb0]                           S:'native_banner_ad_on_off'
02d1392c: add     x10, x10, #8                               &6266008
02d13930: ldur    x11, [x10, #-8]                            
02d13934: cmp     x11, x1                                    
02d13938: b.eq    #0x2d13958                                 
02d1393c: subs    x9, x9, #1                                 
02d13940: add     x10, x10, #0x10                            &6266010
02d13944: b.ne    #0x2d13930                                 
02d13948: mov     x0, x21                                    
02d1394c: mov     w2, wzr                                    
02d13950: bl      #0x2baa05c                                 fn_2baa05c
02d13954: b       #0x2d13964                                 
02d13958: ldrsw   x9, [x10]                                  
02d1395c: add     x8, x8, x9, lsl #4                         &6266000
02d13960: add     x0, x8, #0x138                             &6266138
02d13964: ldp     x8, x2, [x0]                               
02d13968: mov     x0, x21                                    
02d1396c: mov     w1, w22                                    
02d13970: blr     x8                                         
02d13974: cbnz    w0, #0x2d1323c                             
02d13978: ldr     q0, [sp, #0x10]                            
02d1397c: mov     w8, #1                                     
02d13980: str     w8, [x19]                                  
02d13984: str     q0, [x19, #0x30]                           .coinInstance
02d13988: add     x0, x19, #0x30                             
02d1398c: mov     x1, xzr                                    
02d13990: bl      #0x2b70d54                                 fn_2b70d54
02d13994: adrp    x8, #0x6269000                             
02d13998: ldr     x8, [x8, #0x840]                           MS:Cysharp.Threading.Tasks.CompilerServices.AsyncUniTaskMethodBuilder::AwaitUnsafeOnCompleted
02d1399c: ldr     x3, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d139a0: add     x0, x19, #8                                
02d139a4: add     x1, sp, #0x10                              
02d139a8: mov     x2, x19                                    
02d139ac: bl      #0x2d18f08                                 fn_2d18f08
02d139b0: b       #0x2d13814                                 
02d139b4: ldrsw   x9, [x10]                                  
02d139b8: add     x8, x8, x9, lsl #4                         &6269000
02d139bc: add     x0, x8, #0x138                             &6269138
02d139c0: ldp     x8, x2, [x0]                               
02d139c4: mov     x0, x21                                    
02d139c8: mov     w1, w22                                    
02d139cc: blr     x8                                         
02d139d0: cbnz    w0, #0x2d132c0                             
02d139d4: ldr     q0, [sp, #0x10]                            
02d139d8: str     wzr, [x19]                                 
02d139dc: str     q0, [x19, #0x30]                           .coinInstance
02d139e0: add     x0, x19, #0x30                             
02d139e4: mov     x1, xzr                                    
02d139e8: bl      #0x2b70d54                                 fn_2b70d54
02d139ec: adrp    x8, #0x6269000                             
02d139f0: ldr     x8, [x8, #0x840]                           MS:Cysharp.Threading.Tasks.CompilerServices.AsyncUniTaskMethodBuilder::AwaitUnsafeOnCompleted
02d139f4: ldr     x3, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d139f8: add     x0, x19, #8                                
02d139fc: add     x1, sp, #0x10                              
02d13a00: mov     x2, x19                                    
02d13a04: bl      #0x2d18f08                                 fn_2d18f08
02d13a08: b       #0x2d13814                                 
02d13a0c: bl      #0x2b7105c                                 fn_2b7105c
02d13a10: bl      #0x2b7105c                                 fn_2b7105c
02d13a14: bl      #0x2b7105c                                 fn_2b7105c
02d13a18: bl      #0x2b7105c                                 fn_2b7105c
02d13a1c: bl      #0x2b7105c                                 fn_2b7105c
02d13a20: bl      #0x2b7105c                                 fn_2b7105c
02d13a24: bl      #0x2b7105c                                 fn_2b7105c
02d13a28: bl      #0x2b7105c                                 fn_2b7105c
02d13a2c: bl      #0x2b7105c                                 fn_2b7105c
02d13a30: bl      #0x2b7105c                                 fn_2b7105c
02d13a34: bl      #0x2b7105c                                 fn_2b7105c
02d13a38: b       #0x2d13af0                                 
02d13a3c: b       #0x2d13af0                                 
02d13a40: b       #0x2d13af0                                 
02d13a44: b       #0x2d13af0                                 
02d13a48: b       #0x2d13af0                                 
02d13a4c: b       #0x2d13af0                                 
02d13a50: b       #0x2d13af0                                 
02d13a54: b       #0x2d13af0                                 
02d13a58: b       #0x2d13af0                                 
02d13a5c: b       #0x2d13af0                                 
02d13a60: b       #0x2d13af0                                 
02d13a64: b       #0x2d13af0                                 
02d13a68: b       #0x2d13af0                                 
02d13a6c: b       #0x2d13af0                                 
02d13a70: b       #0x2d13af0                                 
02d13a74: b       #0x2d13af0                                 
02d13a78: b       #0x2d13af0                                 
02d13a7c: b       #0x2d13af0                                 
02d13a80: b       #0x2d13af0                                 
02d13a84: b       #0x2d13af0                                 
02d13a88: b       #0x2d13af0                                 
02d13a8c: b       #0x2d13af0                                 
02d13a90: b       #0x2d13af0                                 
02d13a94: b       #0x2d13af0                                 
02d13a98: b       #0x2d13af0                                 
02d13a9c: b       #0x2d13af0                                 
02d13aa0: b       #0x2d13af0                                 
02d13aa4: b       #0x2d13af0                                 
02d13aa8: b       #0x2d13af0                                 
02d13aac: b       #0x2d13af0                                 
02d13ab0: b       #0x2d13af0                                 
02d13ab4: b       #0x2d13af0                                 
02d13ab8: b       #0x2d13af0                                 
02d13abc: b       #0x2d13af0                                 
02d13ac0: b       #0x2d13af0                                 
02d13ac4: b       #0x2d13af0                                 
02d13ac8: b       #0x2d13af0                                 
02d13acc: b       #0x2d13af0                                 
02d13ad0: b       #0x2d13af0                                 
02d13ad4: b       #0x2d13af0                                 
02d13ad8: b       #0x2d13af0                                 
02d13adc: b       #0x2d13af0                                 
02d13ae0: b       #0x2d13af0                                 
02d13ae4: b       #0x2d13af0                                 
02d13ae8: b       #0x2d13af0                                 
02d13aec: b       #0x2d13af0                                 
02d13af0: mov     x20, x0                                    
02d13af4: cmp     w1, #1                                     
02d13af8: b.ne    #0x2d13b88                                 
02d13afc: mov     x0, x20                                    
02d13b00: bl      #0x5e90260                                 fn_5e90260
02d13b04: mov     x20, x0                                    
02d13b08: adrp    x0, #0x6263000                             
02d13b0c: ldr     x0, [x0, #0xae0]                           T:System.Exception
02d13b10: bl      #0x2b70dc4                                 fn_2b70dc4
02d13b14: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02d13b18: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d13b1c: bl      #0x2b71464                                 fn_2b71464
02d13b20: tbz     w0, #0, #0x2d13b60                         
02d13b24: ldrsw   x21, [sp, #8]                              
02d13b28: ldr     x20, [x20]                                 &2b706c4(=eb01011ff9400808)
02d13b2c: mov     x8, sp                                     
02d13b30: str     x20, [x8, x21, lsl #3]                     
02d13b34: add     w8, w21, #1                                
02d13b38: str     w8, [sp, #8]                               
02d13b3c: bl      #0x5e90270                                 fn_5e90270
02d13b40: mov     w8, #-2                                    
02d13b44: mov     x1, x20                                    
02d13b48: mov     x2, xzr                                    
02d13b4c: str     w8, [x19], #8                              
02d13b50: mov     x0, x19                                    
02d13b54: bl      #0x2ceaea8                                 fn_2ceaea8
02d13b58: str     w21, [sp, #8]                              
02d13b5c: b       #0x2d13814                                 
02d13b60: mov     w0, #8                                     
02d13b64: bl      #0x5e90290                                 fn_5e90290
02d13b68: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02d13b6c: str     x8, [x0]                                   
02d13b70: adrp    x1, #0x5e96000                             
02d13b74: add     x1, x1, #0x758                             &5e96758
02d13b78: mov     x2, xzr                                    
02d13b7c: bl      #0x5e902a0                                 fn_5e902a0
02d13b80: mov     x20, x0                                    
02d13b84: bl      #0x5e90270                                 fn_5e90270
02d13b88: mov     x0, x20                                    
02d13b8c: bl      #0x2c6051c                                 fn_2c6051c
02d13b90: bl      #0x27369b8                                 fn_27369b8
## SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine stateMachine) -> void
---- JobGame.CollectingCoin/<MoveCoinTask>d__24::SetStateMachine 0x2d13b94
02d13b94: add     x0, x0, #8                                 
02d13b98: mov     x2, xzr                                    
02d13b9c: b       #0x545f130                                 Cysharp.Threading.Tasks.CompilerServices.AsyncUniTaskMethodBuilder::SetStateMachine
#### CLASS JobGame.CollectingCoin/<MoveCoinsTask>d__23 parent= System.ValueType
#   field <>1__state                     int                                                off=0x10 attr=6 
#   field <>t__builder                   Cysharp.Threading.Tasks.CompilerServices.AsyncUniTaskMethodBuilder off=0x18 attr=6 
#   field <>4__this                      JobGame.CollectingCoin                             off=0x28 attr=6 
#   field onCoinCollected                System.Action                                      off=0x30 attr=6 
#   field <moveCoinTask>5__2             System.Collections.Generic.List`1<Cysharp.Threading.Tasks.UniTask> off=0x38 attr=1 
#   field <i>5__3                        int                                                off=0x40 attr=1 
#   field <>u__1                         Cysharp.Threading.Tasks.UniTask/Awaiter            off=0x48 attr=1 
## MoveNext() -> void
---- JobGame.CollectingCoin/<MoveCoinsTask>d__23::MoveNext 0x2d13ba0
02d13ba0: sub     sp, sp, #0x90                              
02d13ba4: str     x30, [sp, #0x30]                           
02d13ba8: stp     x28, x27, [sp, #0x40]                      
02d13bac: stp     x26, x25, [sp, #0x50]                      
02d13bb0: stp     x24, x23, [sp, #0x60]                      
02d13bb4: stp     x22, x21, [sp, #0x70]                      
02d13bb8: stp     x20, x19, [sp, #0x80]                      
02d13bbc: adrp    x20, #0x662f000                            
02d13bc0: mov     x19, x0                                    
02d13bc4: ldrb    w8, [x20, #0xfc7]                          
02d13bc8: tbnz    w8, #0, #0x2d13c34                         
02d13bcc: adrp    x0, #0x6269000                             
02d13bd0: ldr     x0, [x0, #0x848]                           MS:Cysharp.Threading.Tasks.CompilerServices.AsyncUniTaskMethodBuilder::AwaitUnsafeOnCompleted
02d13bd4: bl      #0x2b70db0                                 fn_2b70db0
02d13bd8: adrp    x0, #0x6269000                             
02d13bdc: ldr     x0, [x0, #0x850]                           MS:System.Collections.Generic.List`1::Add
02d13be0: bl      #0x2b70db0                                 fn_2b70db0
02d13be4: adrp    x0, #0x6269000                             
02d13be8: ldr     x0, [x0, #0x828]                           MS:System.Collections.Generic.List`1::.ctor
02d13bec: bl      #0x2b70db0                                 fn_2b70db0
02d13bf0: adrp    x0, #0x6268000                             
02d13bf4: ldr     x0, [x0, #0x4c8]                           MS:System.Collections.Generic.List`1::get_Count
02d13bf8: bl      #0x2b70db0                                 fn_2b70db0
02d13bfc: adrp    x0, #0x6268000                             
02d13c00: ldr     x0, [x0, #0x4d0]                           MS:System.Collections.Generic.List`1::get_Item
02d13c04: bl      #0x2b70db0                                 fn_2b70db0
02d13c08: adrp    x0, #0x6269000                             
02d13c0c: ldr     x0, [x0, #0x820]                           T:type56853(k15)
02d13c10: bl      #0x2b70db0                                 fn_2b70db0
02d13c14: adrp    x0, #0x6265000                             
02d13c18: ldr     x0, [x0, #0xf98]                           T:System.TimeSpan
02d13c1c: bl      #0x2b70db0                                 fn_2b70db0
02d13c20: adrp    x0, #0x6266000                             
02d13c24: ldr     x0, [x0, #0xcc8]                           T:Cysharp.Threading.Tasks.UniTask
02d13c28: bl      #0x2b70db0                                 fn_2b70db0
02d13c2c: mov     w8, #1                                     
02d13c30: strb    w8, [x20, #0xfc7]                          
02d13c34: adrp    x23, #0x6268000                            
02d13c38: adrp    x24, #0x6269000                            
02d13c3c: adrp    x25, #0x6265000                            
02d13c40: adrp    x26, #0x6266000                            
02d13c44: ldr     x23, [x23, #0x4d0]                         MS:System.Collections.Generic.List`1::get_Item
02d13c48: ldr     x24, [x24, #0x850]                         MS:System.Collections.Generic.List`1::Add
02d13c4c: ldr     x25, [x25, #0xf98]                         T:System.TimeSpan
02d13c50: ldr     x26, [x26, #0xcc8]                         T:Cysharp.Threading.Tasks.UniTask
02d13c54: stp     xzr, xzr, [sp, #0x10]                      
02d13c58: adrp    x27, #0x6266000                            
02d13c5c: ldr     w8, [x19]                                  
02d13c60: ldr     x20, [x19, #0x18]                          .<>t__builder
02d13c64: ldr     x27, [x27, #0xcd0]                         T:Cysharp.Threading.Tasks.IUniTaskSource
02d13c68: str     wzr, [sp, #8]                              
02d13c6c: cbz     w8, #0x2d13cb8                             
02d13c70: adrp    x8, #0x6269000                             
02d13c74: ldr     x8, [x8, #0x820]                           T:type56853(k15)
02d13c78: ldr     x0, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d13c7c: bl      #0x2b7104c                                 fn_2b7104c
02d13c80: adrp    x8, #0x6269000                             
02d13c84: mov     x21, x0                                    
02d13c88: ldr     x8, [x8, #0x828]                           MS:System.Collections.Generic.List`1::.ctor
02d13c8c: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d13c90: bl      #0x3627f54                                 fn_3627f54
02d13c94: mov     x0, x19                                    
02d13c98: str     x21, [x0, #0x28]!                          .<>4__this
02d13c9c: mov     x1, x21                                    
02d13ca0: bl      #0x2b70d54                                 fn_2b70d54
02d13ca4: cbz     x20, #0x2d13cd0                            
02d13ca8: ldr     x8, [x20, #0x60]                           &2b7072c(=14cc752491004000)
02d13cac: cbz     x8, #0x2d13cd4                             
02d13cb0: ldr     w8, [x8, #0x18]                            M:Trading.TradingSession::<ValidateTrade>b__57_0
02d13cb4: b       #0x2d13f28                                 
02d13cb8: ldur    q0, [x19, #0x38]                           .<moveCoinTask>5__2
02d13cbc: mov     w8, #-1                                    
02d13cc0: stp     xzr, xzr, [x19, #0x38]                     .<moveCoinTask>5__2
02d13cc4: str     w8, [x19]                                  
02d13cc8: str     q0, [sp, #0x10]                            
02d13ccc: b       #0x2d13e98                                 
02d13cd0: bl      #0x2b7105c                                 fn_2b7105c
02d13cd4: bl      #0x2b7105c                                 fn_2b7105c
02d13cd8: b       #0x2d1406c                                 
02d13cdc: b       #0x2d1406c                                 
02d13ce0: b       #0x2d1406c                                 
02d13ce4: cbz     x20, #0x2d14034                            
02d13ce8: ldr     x0, [x20, #0x60]                           &2b7072c(=14cc752491004000)
02d13cec: cbz     x0, #0x2d14038                             
02d13cf0: ldr     x21, [x19, #0x28]                          .<>4__this
02d13cf4: ldr     x2, [x23]                                  S:'{0}/2'
02d13cf8: bl      #0x35a8f3c                                 fn_35a8f3c
02d13cfc: mov     x1, x0                                     
02d13d00: ldr     x2, [x19, #0x20]                           
02d13d04: mov     x0, x20                                    
02d13d08: bl      #0x2d12660                                 JobGame.CollectingCoin::MoveCoinTask
02d13d0c: cbz     x21, #0x2d14030                            
02d13d10: ldr     w11, [x21, #0x1c]                          
02d13d14: ldr     x9, [x21, #0x10]                           .<>1__state
02d13d18: ldr     x10, [x24]                                 T:Trading.TradingSession/<>c__DisplayClass56_0
02d13d1c: add     w11, w11, #1                               
02d13d20: str     w11, [x21, #0x1c]                          
02d13d24: cbz     x9, #0x2d14030                             
02d13d28: ldrsw   x11, [x21, #0x18]                          .<>t__builder
02d13d2c: ldr     w12, [x9, #0x18]                           
02d13d30: mov     x8, x0                                     
02d13d34: mov     x2, x1                                     
02d13d38: cmp     w11, w12                                   
02d13d3c: b.hs    #0x2d13d5c                                 
02d13d40: add     x0, x9, x11, lsl #4                        
02d13d44: add     w10, w11, #1                               
02d13d48: str     w10, [x21, #0x18]                          .<>t__builder
02d13d4c: stp     x8, x2, [x0, #0x20]!                       
02d13d50: mov     x1, xzr                                    
02d13d54: bl      #0x2b70d54                                 fn_2b70d54
02d13d58: b       #0x2d13d74                                 
02d13d5c: ldr     x9, [x10, #0x20]                           
02d13d60: ldr     x9, [x9, #0xc0]                            
02d13d64: ldr     x3, [x9, #0x70]                            
02d13d68: mov     x0, x21                                    
02d13d6c: mov     x1, x8                                     
02d13d70: bl      #0x3628800                                 fn_3628800
02d13d74: ldr     x0, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d13d78: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d13d7c: cbnz    w8, #0x2d13d84                             
02d13d80: bl      #0x2b70f30                                 fn_2b70f30
02d13d84: adrp    x8, #0x1040000                             
02d13d88: mov     x0, xzr                                    
02d13d8c: ldr     d0, [x8, #0x618]                           [1040618]=3f947ae140000000 f=2,1.16
02d13d90: bl      #0x4e29964                                 System.TimeSpan::FromSeconds
02d13d94: mov     x21, x0                                    
02d13d98: ldr     x0, [x26]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d13d9c: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d13da0: cbnz    w8, #0x2d13da8                             
02d13da4: bl      #0x2b70f30                                 fn_2b70f30
02d13da8: mov     x0, x21                                    
02d13dac: mov     w1, wzr                                    
02d13db0: mov     w2, #8                                     
02d13db4: mov     x3, xzr                                    
02d13db8: mov     w4, wzr                                    
02d13dbc: mov     x5, xzr                                    
02d13dc0: bl      #0x54481c8                                 Cysharp.Threading.Tasks.UniTask::Delay
02d13dc4: stp     x0, x1, [sp, #0x20]                        
02d13dc8: add     x0, sp, #0x20                              
02d13dcc: mov     x1, xzr                                    
02d13dd0: bl      #0x2b70d54                                 fn_2b70d54
02d13dd4: adrp    x28, #0x662f000                            
02d13dd8: ldp     x21, x22, [sp, #0x20]                      
02d13ddc: ldrb    w8, [x28, #0xbdc]                          
02d13de0: stp     x21, x22, [sp, #0x10]                      
02d13de4: cbnz    w8, #0x2d13dfc                             
02d13de8: adrp    x0, #0x6266000                             
02d13dec: ldr     x0, [x0, #0xcc8]                           T:Cysharp.Threading.Tasks.UniTask
02d13df0: bl      #0x2b70db0                                 fn_2b70db0
02d13df4: mov     w8, #1                                     
02d13df8: strb    w8, [x28, #0xbdc]                          
02d13dfc: ldr     x0, [x26]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d13e00: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d13e04: cbnz    w8, #0x2d13e0c                             
02d13e08: bl      #0x2b70f30                                 fn_2b70f30
02d13e0c: adrp    x28, #0x662f000                            
02d13e10: ldrb    w8, [x28, #0xbdd]                          
02d13e14: cbz     w8, #0x2d13e20                             
02d13e18: cbnz    x21, #0x2d13e38                            
02d13e1c: b       #0x2d13e98                                 
02d13e20: adrp    x0, #0x6266000                             
02d13e24: ldr     x0, [x0, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02d13e28: bl      #0x2b70db0                                 fn_2b70db0
02d13e2c: mov     w8, #1                                     
02d13e30: strb    w8, [x28, #0xbdd]                          
02d13e34: cbz     x21, #0x2d13e98                            
02d13e38: ldr     x8, [x21]                                  
02d13e3c: ldr     x1, [x27]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d13e40: ldrh    w9, [x8, #0x12e]                           
02d13e44: cbz     x9, #0x2d13e68                             
02d13e48: ldr     x10, [x8, #0xb0]                           [10400b0]=0 f=0,0
02d13e4c: add     x10, x10, #8                               
02d13e50: ldur    x11, [x10, #-8]                            
02d13e54: cmp     x11, x1                                    
02d13e58: b.eq    #0x2d13e78                                 
02d13e5c: subs    x9, x9, #1                                 
02d13e60: add     x10, x10, #0x10                            
02d13e64: b.ne    #0x2d13e50                                 
02d13e68: mov     x0, x21                                    
02d13e6c: mov     w2, wzr                                    
02d13e70: bl      #0x2baa05c                                 fn_2baa05c
02d13e74: b       #0x2d13e84                                 
02d13e78: ldrsw   x9, [x10]                                  
02d13e7c: add     x8, x8, x9, lsl #4                         &1040000
02d13e80: add     x0, x8, #0x138                             &1040138
02d13e84: ldp     x8, x2, [x0]                               
02d13e88: mov     x0, x21                                    
02d13e8c: mov     w1, w22                                    
02d13e90: blr     x8                                         
02d13e94: cbz     w0, #0x2d13fbc                             
02d13e98: adrp    x21, #0x662f000                            
02d13e9c: ldrb    w8, [x21, #0xbde]                          
02d13ea0: cbnz    w8, #0x2d13eb8                             
02d13ea4: adrp    x0, #0x6266000                             
02d13ea8: ldr     x0, [x0, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02d13eac: bl      #0x2b70db0                                 fn_2b70db0
02d13eb0: mov     w8, #1                                     
02d13eb4: strb    w8, [x21, #0xbde]                          
02d13eb8: ldr     x21, [sp, #0x10]                           
02d13ebc: cbz     x21, #0x2d13f24                            
02d13ec0: ldr     x8, [x21]                                  &2b706c4(=eb01011ff9400808)
02d13ec4: ldrh    w22, [sp, #0x18]                           
02d13ec8: ldr     x1, [x27]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d13ecc: ldrh    w9, [x8, #0x12e]                           
02d13ed0: cbz     x9, #0x2d13ef4                             
02d13ed4: ldr     x10, [x8, #0xb0]                           [10400b0]=0 f=0,0
02d13ed8: add     x10, x10, #8                               
02d13edc: ldur    x11, [x10, #-8]                            
02d13ee0: cmp     x11, x1                                    
02d13ee4: b.eq    #0x2d13f04                                 
02d13ee8: subs    x9, x9, #1                                 
02d13eec: add     x10, x10, #0x10                            
02d13ef0: b.ne    #0x2d13edc                                 
02d13ef4: mov     x0, x21                                    
02d13ef8: mov     w2, #2                                     
02d13efc: bl      #0x2baa05c                                 fn_2baa05c
02d13f00: b       #0x2d13f14                                 
02d13f04: ldr     w9, [x10]                                  
02d13f08: add     w9, w9, #2                                 
02d13f0c: add     x8, x8, w9, sxtw #4                        &1040000
02d13f10: add     x0, x8, #0x138                             &1040138
02d13f14: ldp     x8, x2, [x0]                               
02d13f18: mov     x0, x21                                    
02d13f1c: mov     w1, w22                                    
02d13f20: blr     x8                                         
02d13f24: ldr     w8, [x19, #0x30]                           .onCoinCollected
02d13f28: sub     w1, w8, #1                                 
02d13f2c: str     w1, [x19, #0x30]                           .onCoinCollected
02d13f30: tbz     w1, #0x1f, #0x2d13ce4                      
02d13f34: mov     w8, #-2                                    
02d13f38: mov     x0, x19                                    
02d13f3c: mov     x1, xzr                                    
02d13f40: str     w8, [x19]                                  
02d13f44: str     xzr, [x0, #0x28]!                          .<>4__this
02d13f48: bl      #0x2b70d54                                 fn_2b70d54
02d13f4c: adrp    x20, #0x662f000                            
02d13f50: ldrb    w8, [x20, #0xe25]                          
02d13f54: cbnz    w8, #0x2d13f6c                             
02d13f58: adrp    x0, #0x6268000                             
02d13f5c: ldr     x0, [x0, #0xd8]                            T:Cysharp.Threading.Tasks.CompilerServices.IStateMachineRunnerPromise
02d13f60: bl      #0x2b70db0                                 fn_2b70db0
02d13f64: mov     w8, #1                                     
02d13f68: strb    w8, [x20, #0xe25]                          
02d13f6c: ldr     x19, [x19, #8]                             
02d13f70: cbz     x19, #0x2d14010                            
02d13f74: adrp    x10, #0x6268000                            
02d13f78: ldr     x8, [x19]                                  
02d13f7c: ldr     x10, [x10, #0xd8]                          T:Cysharp.Threading.Tasks.CompilerServices.IStateMachineRunnerPromise
02d13f80: ldrh    w9, [x8, #0x12e]                           
02d13f84: ldr     x1, [x10]                                  S:'{0}/2'
02d13f88: cbz     x9, #0x2d13fac                             
02d13f8c: ldr     x10, [x8, #0xb0]                           [10400b0]=0 f=0,0
02d13f90: add     x10, x10, #8                               &6268008
02d13f94: ldur    x11, [x10, #-8]                            
02d13f98: cmp     x11, x1                                    
02d13f9c: b.eq    #0x2d13ff4                                 
02d13fa0: subs    x9, x9, #1                                 
02d13fa4: add     x10, x10, #0x10                            &6268010
02d13fa8: b.ne    #0x2d13f94                                 
02d13fac: mov     x0, x19                                    
02d13fb0: mov     w2, #2                                     
02d13fb4: bl      #0x2baa05c                                 fn_2baa05c
02d13fb8: b       #0x2d14004                                 
02d13fbc: ldr     q0, [sp, #0x10]                            
02d13fc0: str     wzr, [x19]                                 
02d13fc4: stur    q0, [x19, #0x38]                           .<moveCoinTask>5__2
02d13fc8: add     x0, x19, #0x38                             
02d13fcc: mov     x1, xzr                                    
02d13fd0: bl      #0x2b70d54                                 fn_2b70d54
02d13fd4: adrp    x8, #0x6269000                             
02d13fd8: ldr     x8, [x8, #0x848]                           MS:Cysharp.Threading.Tasks.CompilerServices.AsyncUniTaskMethodBuilder::AwaitUnsafeOnCompleted
02d13fdc: ldr     x3, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d13fe0: add     x0, x19, #8                                
02d13fe4: add     x1, sp, #0x10                              
02d13fe8: mov     x2, x19                                    
02d13fec: bl      #0x2d19014                                 fn_2d19014
02d13ff0: b       #0x2d14010                                 
02d13ff4: ldr     w9, [x10]                                  S:'{0}/2'
02d13ff8: add     w9, w9, #2                                 
02d13ffc: add     x8, x8, w9, sxtw #4                        &6269000
02d14000: add     x0, x8, #0x138                             &6269138
02d14004: ldp     x8, x1, [x0]                               
02d14008: mov     x0, x19                                    
02d1400c: blr     x8                                         
02d14010: ldp     x20, x19, [sp, #0x80]                      
02d14014: ldr     x30, [sp, #0x30]                           
02d14018: ldp     x22, x21, [sp, #0x70]                      
02d1401c: ldp     x24, x23, [sp, #0x60]                      
02d14020: ldp     x26, x25, [sp, #0x50]                      
02d14024: ldp     x28, x27, [sp, #0x40]                      
02d14028: add     sp, sp, #0x90                              
02d1402c: ret                                                
02d14030: bl      #0x2b7105c                                 fn_2b7105c
02d14034: bl      #0x2b7105c                                 fn_2b7105c
02d14038: bl      #0x2b7105c                                 fn_2b7105c
02d1403c: b       #0x2d1406c                                 
02d14040: b       #0x2d1406c                                 
02d14044: b       #0x2d1406c                                 
02d14048: b       #0x2d1406c                                 
02d1404c: b       #0x2d1406c                                 
02d14050: b       #0x2d1406c                                 
02d14054: b       #0x2d1406c                                 
02d14058: b       #0x2d1406c                                 
02d1405c: b       #0x2d1406c                                 
02d14060: b       #0x2d1406c                                 
02d14064: b       #0x2d1406c                                 
02d14068: b       #0x2d1406c                                 
02d1406c: mov     x20, x0                                    
02d14070: cmp     w1, #1                                     
02d14074: b.ne    #0x2d14114                                 
02d14078: mov     x0, x20                                    
02d1407c: bl      #0x5e90260                                 fn_5e90260
02d14080: mov     x20, x0                                    
02d14084: adrp    x0, #0x6263000                             
02d14088: ldr     x0, [x0, #0xae0]                           T:System.Exception
02d1408c: bl      #0x2b70dc4                                 fn_2b70dc4
02d14090: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02d14094: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d14098: bl      #0x2b71464                                 fn_2b71464
02d1409c: tbz     w0, #0, #0x2d140ec                         
02d140a0: ldrsw   x21, [sp, #8]                              
02d140a4: ldr     x20, [x20]                                 &2b706c4(=eb01011ff9400808)
02d140a8: mov     x8, sp                                     
02d140ac: str     x20, [x8, x21, lsl #3]                     
02d140b0: add     w8, w21, #1                                
02d140b4: str     w8, [sp, #8]                               
02d140b8: bl      #0x5e90270                                 fn_5e90270
02d140bc: mov     w8, #-2                                    
02d140c0: mov     x0, x19                                    
02d140c4: mov     x1, xzr                                    
02d140c8: str     w8, [x19]                                  
02d140cc: str     xzr, [x0, #0x28]!                          .<>4__this
02d140d0: bl      #0x2b70d54                                 fn_2b70d54
02d140d4: add     x0, x19, #8                                
02d140d8: mov     x1, x20                                    
02d140dc: mov     x2, xzr                                    
02d140e0: bl      #0x2ceaea8                                 fn_2ceaea8
02d140e4: str     w21, [sp, #8]                              
02d140e8: b       #0x2d14010                                 
02d140ec: mov     w0, #8                                     
02d140f0: bl      #0x5e90290                                 fn_5e90290
02d140f4: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02d140f8: str     x8, [x0]                                   
02d140fc: adrp    x1, #0x5e96000                             
02d14100: add     x1, x1, #0x758                             &5e96758
02d14104: mov     x2, xzr                                    
02d14108: bl      #0x5e902a0                                 fn_5e902a0
02d1410c: mov     x20, x0                                    
02d14110: bl      #0x5e90270                                 fn_5e90270
02d14114: mov     x0, x20                                    
02d14118: bl      #0x2c6051c                                 fn_2c6051c
02d1411c: bl      #0x27369b8                                 fn_27369b8
## SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine stateMachine) -> void
---- JobGame.CollectingCoin/<MoveCoinsTask>d__23::SetStateMachine 0x2d14120
02d14120: add     x0, x0, #8                                 
02d14124: mov     x2, xzr                                    
02d14128: b       #0x545f130                                 Cysharp.Threading.Tasks.CompilerServices.AsyncUniTaskMethodBuilder::SetStateMachine
#### CLASS JobGame.CollectingCoin/<ReactToCollectionCoin>d__25 parent= System.ValueType
#   field <>1__state                     int                                                off=0x10 attr=6 
#   field <>t__builder                   Cysharp.Threading.Tasks.CompilerServices.AsyncUniTaskMethodBuilder off=0x18 attr=6 
#   field <>4__this                      JobGame.CollectingCoin                             off=0x28 attr=6 
#   field <>u__1                         Cysharp.Threading.Tasks.UniTask/Awaiter            off=0x30 attr=1 
## MoveNext() -> void
---- JobGame.CollectingCoin/<ReactToCollectionCoin>d__25::MoveNext 0x2d1412c
02d1412c: sub     sp, sp, #0x70                              
02d14130: str     x30, [sp, #0x30]                           
02d14134: stp     x24, x23, [sp, #0x40]                      
02d14138: stp     x22, x21, [sp, #0x50]                      
02d1413c: stp     x20, x19, [sp, #0x60]                      
02d14140: adrp    x20, #0x662f000                            
02d14144: mov     x19, x0                                    
02d14148: ldrb    w8, [x20, #0xfc8]                          
02d1414c: tbnz    w8, #0, #0x2d1417c                         
02d14150: adrp    x0, #0x6269000                             
02d14154: ldr     x0, [x0, #0x858]                           MS:Cysharp.Threading.Tasks.CompilerServices.AsyncUniTaskMethodBuilder::AwaitUnsafeOnCompleted
02d14158: bl      #0x2b70db0                                 fn_2b70db0
02d1415c: adrp    x0, #0x6264000                             
02d14160: ldr     x0, [x0, #0x108]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d14164: bl      #0x2b70db0                                 fn_2b70db0
02d14168: adrp    x0, #0x6266000                             
02d1416c: ldr     x0, [x0, #0xcc8]                           T:Cysharp.Threading.Tasks.UniTask
02d14170: bl      #0x2b70db0                                 fn_2b70db0
02d14174: mov     w8, #1                                     
02d14178: strb    w8, [x20, #0xfc8]                          
02d1417c: ldr     w8, [x19]                                  
02d14180: ldr     x20, [x19, #0x18]                          .<>t__builder
02d14184: stp     xzr, xzr, [sp, #0x10]                      
02d14188: str     wzr, [sp, #8]                              
02d1418c: cbz     w8, #0x2d1427c                             
02d14190: cbz     x20, #0x2d1449c                            
02d14194: mov     x21, x20                                   
02d14198: ldr     x8, [x21, #0x70]!                          
02d1419c: cbnz    x8, #0x2d14338                             
02d141a0: ldr     x0, [x20, #0x40]                           &2b70700(=14cc750491004000)
02d141a4: adrp    x8, #0x1084000                             
02d141a8: fmov    s0, #0.50000000                            
02d141ac: fmov    s1, #0.50000000                            
02d141b0: fmov    s2, #0.50000000                            
02d141b4: fmov    s4, #1.00000000                            
02d141b8: ldr     s3, [x8, #0xeec]                           [1084eec]=457ff0003dcccccd f=0.1,4095
02d141bc: mov     w1, #0xa                                   
02d141c0: mov     x2, xzr                                    
02d141c4: bl      #0x2d9982c                                 DG.Tweening.ShortcutExtensions::DOPunchScale
02d141c8: adrp    x8, #0x6264000                             
02d141cc: ldr     x8, [x8, #0x108]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d141d0: ldr     x2, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d141d4: mov     w1, #0x19                                  
02d141d8: bl      #0x336fa0c                                 fn_336fa0c
02d141dc: mov     x1, x0                                     
02d141e0: str     x1, [x21]                                  
02d141e4: mov     x0, x21                                    
02d141e8: bl      #0x2b70d54                                 fn_2b70d54
02d141ec: ldr     x0, [x21]                                  
02d141f0: mov     w1, wzr                                    
02d141f4: mov     x2, xzr                                    
02d141f8: mov     x3, xzr                                    
02d141fc: bl      #0x545d870                                 Cysharp.Threading.Tasks.DOTweenAsyncExtensions::ToUniTask
02d14200: adrp    x23, #0x6266000                            
02d14204: mov     x21, x0                                    
02d14208: mov     x22, x1                                    
02d1420c: ldr     x23, [x23, #0xcc8]                         T:Cysharp.Threading.Tasks.UniTask
02d14210: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d14214: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d14218: cbnz    w8, #0x2d14220                             
02d1421c: bl      #0x2b70f30                                 fn_2b70f30
02d14220: stp     x21, x22, [sp, #0x20]                      
02d14224: add     x0, sp, #0x20                              
02d14228: mov     x1, xzr                                    
02d1422c: bl      #0x2b70d54                                 fn_2b70d54
02d14230: adrp    x24, #0x662f000                            
02d14234: ldp     x21, x22, [sp, #0x20]                      
02d14238: ldrb    w8, [x24, #0xbdc]                          
02d1423c: stp     x21, x22, [sp, #0x10]                      
02d14240: cbnz    w8, #0x2d14258                             
02d14244: adrp    x0, #0x6266000                             
02d14248: ldr     x0, [x0, #0xcc8]                           T:Cysharp.Threading.Tasks.UniTask
02d1424c: bl      #0x2b70db0                                 fn_2b70db0
02d14250: mov     w8, #1                                     
02d14254: strb    w8, [x24, #0xbdc]                          
02d14258: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1425c: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d14260: cbnz    w8, #0x2d14268                             
02d14264: bl      #0x2b70f30                                 fn_2b70f30
02d14268: adrp    x23, #0x662f000                            
02d1426c: ldrb    w8, [x23, #0xbdd]                          
02d14270: cbz     w8, #0x2d143e4                             
02d14274: cbnz    x21, #0x2d143fc                            
02d14278: b       #0x2d14290                                 
02d1427c: ldr     q0, [x19, #0x20]                           
02d14280: mov     w8, #-1                                    
02d14284: stp     xzr, xzr, [x19, #0x20]                     
02d14288: str     w8, [x19]                                  
02d1428c: str     q0, [sp, #0x10]                            
02d14290: adrp    x21, #0x662f000                            
02d14294: ldrb    w8, [x21, #0xbde]                          
02d14298: cbnz    w8, #0x2d142b0                             
02d1429c: adrp    x0, #0x6266000                             
02d142a0: ldr     x0, [x0, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02d142a4: bl      #0x2b70db0                                 fn_2b70db0
02d142a8: mov     w8, #1                                     
02d142ac: strb    w8, [x21, #0xbde]                          
02d142b0: ldr     x21, [sp, #0x10]                           
02d142b4: cbz     x21, #0x2d14324                            
02d142b8: adrp    x10, #0x6266000                            
02d142bc: ldr     x8, [x21]                                  &2b706c4(=eb01011ff9400808)
02d142c0: ldr     x10, [x10, #0xcd0]                         T:Cysharp.Threading.Tasks.IUniTaskSource
02d142c4: ldrh    w22, [sp, #0x18]                           
02d142c8: ldrh    w9, [x8, #0x12e]                           
02d142cc: ldr     x1, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d142d0: cbz     x9, #0x2d142f4                             
02d142d4: ldr     x10, [x8, #0xb0]                           T:DG.Tweening.DOTweenModulePhysics/<>c__DisplayClass5_0
02d142d8: add     x10, x10, #8                               &6266008
02d142dc: ldur    x11, [x10, #-8]                            
02d142e0: cmp     x11, x1                                    
02d142e4: b.eq    #0x2d14304                                 
02d142e8: subs    x9, x9, #1                                 
02d142ec: add     x10, x10, #0x10                            &6266010
02d142f0: b.ne    #0x2d142dc                                 
02d142f4: mov     x0, x21                                    
02d142f8: mov     w2, #2                                     
02d142fc: bl      #0x2baa05c                                 fn_2baa05c
02d14300: b       #0x2d14314                                 
02d14304: ldr     w9, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d14308: add     w9, w9, #2                                 
02d1430c: add     x8, x8, w9, sxtw #4                        &6264000
02d14310: add     x0, x8, #0x138                             &6264138
02d14314: ldp     x8, x2, [x0]                               
02d14318: mov     x0, x21                                    
02d1431c: mov     w1, w22                                    
02d14320: blr     x8                                         
02d14324: cbz     x20, #0x2d144a0                            
02d14328: str     xzr, [x20, #0x70]!                         
02d1432c: mov     x0, x20                                    
02d14330: mov     x1, xzr                                    
02d14334: bl      #0x2b70d54                                 fn_2b70d54
02d14338: adrp    x20, #0x662f000                            
02d1433c: mov     w9, #-2                                    
02d14340: ldrb    w8, [x20, #0xe25]                          
02d14344: str     w9, [x19]                                  
02d14348: cbnz    w8, #0x2d14360                             
02d1434c: adrp    x0, #0x6268000                             
02d14350: ldr     x0, [x0, #0xd8]                            T:Cysharp.Threading.Tasks.CompilerServices.IStateMachineRunnerPromise
02d14354: bl      #0x2b70db0                                 fn_2b70db0
02d14358: mov     w8, #1                                     
02d1435c: strb    w8, [x20, #0xe25]                          
02d14360: ldr     x19, [x19, #8]                             
02d14364: cbz     x19, #0x2d143cc                            
02d14368: adrp    x10, #0x6268000                            
02d1436c: ldr     x8, [x19]                                  
02d14370: ldr     x10, [x10, #0xd8]                          T:Cysharp.Threading.Tasks.CompilerServices.IStateMachineRunnerPromise
02d14374: ldrh    w9, [x8, #0x12e]                           
02d14378: ldr     x1, [x10]                                  S:'{0}/2'
02d1437c: cbz     x9, #0x2d143a0                             
02d14380: ldr     x10, [x8, #0xb0]                           T:DG.Tweening.DOTweenModulePhysics/<>c__DisplayClass5_0
02d14384: add     x10, x10, #8                               &6268008
02d14388: ldur    x11, [x10, #-8]                            
02d1438c: cmp     x11, x1                                    
02d14390: b.eq    #0x2d143b0                                 
02d14394: subs    x9, x9, #1                                 
02d14398: add     x10, x10, #0x10                            &6268010
02d1439c: b.ne    #0x2d14388                                 
02d143a0: mov     x0, x19                                    
02d143a4: mov     w2, #2                                     
02d143a8: bl      #0x2baa05c                                 fn_2baa05c
02d143ac: b       #0x2d143c0                                 
02d143b0: ldr     w9, [x10]                                  S:'{0}/2'
02d143b4: add     w9, w9, #2                                 
02d143b8: add     x8, x8, w9, sxtw #4                        &6264000
02d143bc: add     x0, x8, #0x138                             &6264138
02d143c0: ldp     x8, x1, [x0]                               
02d143c4: mov     x0, x19                                    
02d143c8: blr     x8                                         
02d143cc: ldp     x20, x19, [sp, #0x60]                      
02d143d0: ldr     x30, [sp, #0x30]                           
02d143d4: ldp     x22, x21, [sp, #0x50]                      
02d143d8: ldp     x24, x23, [sp, #0x40]                      
02d143dc: add     sp, sp, #0x70                              
02d143e0: ret                                                
02d143e4: adrp    x0, #0x6266000                             
02d143e8: ldr     x0, [x0, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02d143ec: bl      #0x2b70db0                                 fn_2b70db0
02d143f0: mov     w8, #1                                     
02d143f4: strb    w8, [x23, #0xbdd]                          
02d143f8: cbz     x21, #0x2d14290                            
02d143fc: adrp    x10, #0x6266000                            
02d14400: ldr     x8, [x21]                                  &2b706c4(=eb01011ff9400808)
02d14404: ldr     x10, [x10, #0xcd0]                         T:Cysharp.Threading.Tasks.IUniTaskSource
02d14408: ldrh    w9, [x8, #0x12e]                           
02d1440c: ldr     x1, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d14410: cbz     x9, #0x2d14434                             
02d14414: ldr     x10, [x8, #0xb0]                           T:DG.Tweening.DOTweenModulePhysics/<>c__DisplayClass5_0
02d14418: add     x10, x10, #8                               &6266008
02d1441c: ldur    x11, [x10, #-8]                            
02d14420: cmp     x11, x1                                    
02d14424: b.eq    #0x2d14444                                 
02d14428: subs    x9, x9, #1                                 
02d1442c: add     x10, x10, #0x10                            &6266010
02d14430: b.ne    #0x2d1441c                                 
02d14434: mov     x0, x21                                    
02d14438: mov     w2, wzr                                    
02d1443c: bl      #0x2baa05c                                 fn_2baa05c
02d14440: b       #0x2d14450                                 
02d14444: ldrsw   x9, [x10]                                  
02d14448: add     x8, x8, x9, lsl #4                         &6264000
02d1444c: add     x0, x8, #0x138                             &6264138
02d14450: ldp     x8, x2, [x0]                               
02d14454: mov     x0, x21                                    
02d14458: mov     w1, w22                                    
02d1445c: blr     x8                                         
02d14460: cbnz    w0, #0x2d14290                             
02d14464: ldr     q0, [sp, #0x10]                            
02d14468: str     wzr, [x19]                                 
02d1446c: str     q0, [x19, #0x20]                           
02d14470: add     x0, x19, #0x20                             
02d14474: mov     x1, xzr                                    
02d14478: bl      #0x2b70d54                                 fn_2b70d54
02d1447c: adrp    x8, #0x6269000                             
02d14480: ldr     x8, [x8, #0x858]                           MS:Cysharp.Threading.Tasks.CompilerServices.AsyncUniTaskMethodBuilder::AwaitUnsafeOnCompleted
02d14484: ldr     x3, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d14488: add     x0, x19, #8                                
02d1448c: add     x1, sp, #0x10                              
02d14490: mov     x2, x19                                    
02d14494: bl      #0x2d19120                                 fn_2d19120
02d14498: b       #0x2d143cc                                 
02d1449c: bl      #0x2b7105c                                 fn_2b7105c
02d144a0: bl      #0x2b7105c                                 fn_2b7105c
02d144a4: b       #0x2d144cc                                 
02d144a8: b       #0x2d144cc                                 
02d144ac: b       #0x2d144cc                                 
02d144b0: b       #0x2d144cc                                 
02d144b4: b       #0x2d144cc                                 
02d144b8: b       #0x2d144cc                                 
02d144bc: b       #0x2d144cc                                 
02d144c0: b       #0x2d144cc                                 
02d144c4: b       #0x2d144cc                                 
02d144c8: b       #0x2d144cc                                 
02d144cc: mov     x20, x0                                    
02d144d0: cmp     w1, #1                                     
02d144d4: b.ne    #0x2d14564                                 
02d144d8: mov     x0, x20                                    
02d144dc: bl      #0x5e90260                                 fn_5e90260
02d144e0: mov     x20, x0                                    
02d144e4: adrp    x0, #0x6263000                             
02d144e8: ldr     x0, [x0, #0xae0]                           T:System.Exception
02d144ec: bl      #0x2b70dc4                                 fn_2b70dc4
02d144f0: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02d144f4: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d144f8: bl      #0x2b71464                                 fn_2b71464
02d144fc: tbz     w0, #0, #0x2d1453c                         
02d14500: ldrsw   x21, [sp, #8]                              
02d14504: ldr     x20, [x20]                                 &2b706c4(=eb01011ff9400808)
02d14508: mov     x8, sp                                     
02d1450c: str     x20, [x8, x21, lsl #3]                     
02d14510: add     w8, w21, #1                                
02d14514: str     w8, [sp, #8]                               
02d14518: bl      #0x5e90270                                 fn_5e90270
02d1451c: mov     w8, #-2                                    
02d14520: mov     x1, x20                                    
02d14524: mov     x2, xzr                                    
02d14528: str     w8, [x19], #8                              
02d1452c: mov     x0, x19                                    
02d14530: bl      #0x2ceaea8                                 fn_2ceaea8
02d14534: str     w21, [sp, #8]                              
02d14538: b       #0x2d143cc                                 
02d1453c: mov     w0, #8                                     
02d14540: bl      #0x5e90290                                 fn_5e90290
02d14544: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02d14548: str     x8, [x0]                                   
02d1454c: adrp    x1, #0x5e96000                             
02d14550: add     x1, x1, #0x758                             &5e96758
02d14554: mov     x2, xzr                                    
02d14558: bl      #0x5e902a0                                 fn_5e902a0
02d1455c: mov     x20, x0                                    
02d14560: bl      #0x5e90270                                 fn_5e90270
02d14564: mov     x0, x20                                    
02d14568: bl      #0x2c6051c                                 fn_2c6051c
02d1456c: bl      #0x27369b8                                 fn_27369b8
## SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine stateMachine) -> void
---- JobGame.CollectingCoin/<ReactToCollectionCoin>d__25::SetStateMachine 0x2d14570
02d14570: add     x0, x0, #8                                 
02d14574: mov     x2, xzr                                    
02d14578: b       #0x545f130                                 Cysharp.Threading.Tasks.CompilerServices.AsyncUniTaskMethodBuilder::SetStateMachine
#### CLASS JobGame.CollectingCoin/<SpawnCoin>d__22 parent= System.ValueType
#   field <>1__state                     int                                                off=0x10 attr=6 
#   field <>t__builder                   Cysharp.Threading.Tasks.CompilerServices.AsyncUniTaskMethodBuilder off=0x18 attr=6 
#   field spawnPos                       UnityEngine.Vector3                                off=0x28 attr=6 
#   field <>4__this                      JobGame.CollectingCoin                             off=0x38 attr=6 
#   field coinAmount                     int                                                off=0x40 attr=6 
#   field <i>5__2                        int                                                off=0x44 attr=1 
#   field <>u__1                         Cysharp.Threading.Tasks.UniTask/Awaiter            off=0x48 attr=1 
## MoveNext() -> void
---- JobGame.CollectingCoin/<SpawnCoin>d__22::MoveNext 0x2d1457c
02d1457c: sub     sp, sp, #0xb0                              
02d14580: stp     d11, d10, [sp, #0x30]                      
02d14584: stp     d9, d8, [sp, #0x40]                        
02d14588: stp     x29, x30, [sp, #0x50]                      
02d1458c: stp     x28, x27, [sp, #0x60]                      
02d14590: stp     x26, x25, [sp, #0x70]                      
02d14594: stp     x24, x23, [sp, #0x80]                      
02d14598: stp     x22, x21, [sp, #0x90]                      
02d1459c: stp     x20, x19, [sp, #0xa0]                      
02d145a0: adrp    x20, #0x662f000                            
02d145a4: mov     x19, x0                                    
02d145a8: ldrb    w8, [x20, #0xfc9]                          
02d145ac: tbnz    w8, #0, #0x2d1460c                         
02d145b0: adrp    x0, #0x6269000                             
02d145b4: ldr     x0, [x0, #0x860]                           MS:Cysharp.Threading.Tasks.CompilerServices.AsyncUniTaskMethodBuilder::AwaitUnsafeOnCompleted
02d145b8: bl      #0x2b70db0                                 fn_2b70db0
02d145bc: adrp    x0, #0x6268000                             
02d145c0: ldr     x0, [x0, #0x908]                           MS:System.Collections.Generic.List`1::Add
02d145c4: bl      #0x2b70db0                                 fn_2b70db0
02d145c8: adrp    x0, #0x6269000                             
02d145cc: ldr     x0, [x0, #0x850]                           MS:System.Collections.Generic.List`1::Add
02d145d0: bl      #0x2b70db0                                 fn_2b70db0
02d145d4: adrp    x0, #0x6266000                             
02d145d8: ldr     x0, [x0, #0xd20]                           MS:MonoSingleton`1::get_Instance
02d145dc: bl      #0x2b70db0                                 fn_2b70db0
02d145e0: adrp    x0, #0x6265000                             
02d145e4: ldr     x0, [x0, #0xf98]                           T:System.TimeSpan
02d145e8: bl      #0x2b70db0                                 fn_2b70db0
02d145ec: adrp    x0, #0x6264000                             
02d145f0: ldr     x0, [x0, #0x108]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d145f4: bl      #0x2b70db0                                 fn_2b70db0
02d145f8: adrp    x0, #0x6266000                             
02d145fc: ldr     x0, [x0, #0xcc8]                           T:Cysharp.Threading.Tasks.UniTask
02d14600: bl      #0x2b70db0                                 fn_2b70db0
02d14604: mov     w8, #1                                     
02d14608: strb    w8, [x20, #0xfc9]                          
02d1460c: adrp    x28, #0x6269000                            
02d14610: adrp    x29, #0x6268000                            
02d14614: adrp    x26, #0x6265000                            
02d14618: adrp    x25, #0x6266000                            
02d1461c: ldr     x28, [x28, #0x850]                         MS:System.Collections.Generic.List`1::Add
02d14620: ldr     x29, [x29, #0x908]                         MS:System.Collections.Generic.List`1::Add
02d14624: ldr     x26, [x26, #0xf98]                         T:System.TimeSpan
02d14628: ldr     x25, [x25, #0xcc8]                         T:Cysharp.Threading.Tasks.UniTask
02d1462c: stp     xzr, xzr, [sp, #0x10]                      
02d14630: adrp    x23, #0x6266000                            
02d14634: ldr     w8, [x19]                                  
02d14638: ldr     x27, [x19, #0x28]                          .spawnPos
02d1463c: ldr     x23, [x23, #0xcd0]                         T:Cysharp.Threading.Tasks.IUniTaskSource
02d14640: adrp    x24, #0x662f000                            
02d14644: str     wzr, [sp, #8]                              
02d14648: cbz     w8, #0x2d1466c                             
02d1464c: cmp     w8, #1                                     
02d14650: b.ne    #0x2d14684                                 
02d14654: ldur    q0, [x19, #0x38]                           .<>4__this
02d14658: mov     w8, #-1                                    
02d1465c: stp     xzr, xzr, [x19, #0x38]                     .<>4__this
02d14660: str     w8, [x19]                                  
02d14664: str     q0, [sp, #0x10]                            
02d14668: b       #0x2d14bd4                                 
02d1466c: ldur    q0, [x19, #0x38]                           .<>4__this
02d14670: mov     w8, #-1                                    
02d14674: stp     xzr, xzr, [x19, #0x38]                     .<>4__this
02d14678: str     w8, [x19]                                  
02d1467c: str     q0, [sp, #0x10]                            
02d14680: b       #0x2d14a04                                 
02d14684: mov     w8, wzr                                    
02d14688: str     wzr, [x19, #0x34]                          
02d1468c: b       #0x2d14a98                                 
02d14690: adrp    x8, #0x6266000                             
02d14694: ldr     x8, [x8, #0xd20]                           MS:MonoSingleton`1::get_Instance
02d14698: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1469c: bl      #0x3769600                                 fn_3769600
02d146a0: cbz     x27, #0x2d14d64                            
02d146a4: adrp    x22, #0x662f000                            
02d146a8: ldr     w21, [x27, #0x20]                          
02d146ac: mov     x20, x0                                    
02d146b0: ldrb    w8, [x22, #0x91a]                          
02d146b4: cbnz    w8, #0x2d146cc                             
02d146b8: adrp    x0, #0x6264000                             
02d146bc: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d146c0: bl      #0x2b70db0                                 fn_2b70db0
02d146c4: mov     w8, #1                                     
02d146c8: strb    w8, [x22, #0x91a]                          
02d146cc: adrp    x8, #0x6264000                             
02d146d0: adrp    x22, #0x662f000                            
02d146d4: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02d146d8: ldrb    w9, [x22, #0xbdf]                          
02d146dc: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d146e0: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d146e4: ldp     s8, s9, [x8]                               
02d146e8: ldr     s10, [x8, #8]                              T:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0
02d146ec: cbnz    w9, #0x2d14704                             
02d146f0: adrp    x0, #0x6266000                             
02d146f4: ldr     x0, [x0, #0xd30]                           T:UnityEngine.Quaternion
02d146f8: bl      #0x2b70db0                                 fn_2b70db0
02d146fc: mov     w8, #1                                     
02d14700: strb    w8, [x22, #0xbdf]                          
02d14704: cbz     x20, #0x2d14d68                            
02d14708: adrp    x8, #0x6266000                             
02d1470c: ldr     x8, [x8, #0xd30]                           T:UnityEngine.Quaternion
02d14710: ldr     x2, [x27, #0x28]                           
02d14714: ldr     x8, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d14718: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02d1471c: ldp     s5, s6, [x8, #8]                           
02d14720: ldp     s3, s4, [x8]                               
02d14724: fmov    s0, s8                                     
02d14728: fmov    s1, s9                                     
02d1472c: mov     x0, x20                                    
02d14730: fmov    s2, s10                                    
02d14734: mov     w1, w21                                    
02d14738: mov     x3, xzr                                    
02d1473c: bl      #0x2cdcef0                                 PoolManager::SpawnObject
02d14740: fmov    s0, #1.00000000                            
02d14744: mov     x1, xzr                                    
02d14748: mov     x20, x0                                    
02d1474c: bl      #0x2dc060c                                 Redcode.Extensions.TransformExtensions::SetLocalScale
02d14750: ldp     s0, s1, [x27, #0x4c]                       
02d14754: ldr     s10, [x19, #0x18]                          .<>t__builder
02d14758: mov     x0, xzr                                    
02d1475c: bl      #0x5b2dfc0                                 UnityEngine.Random::Range
02d14760: fmov    s8, s0                                     
02d14764: ldp     s0, s1, [x27, #0x54]                       
02d14768: ldr     s11, [x19, #0x1c]                          
02d1476c: mov     x0, xzr                                    
02d14770: bl      #0x5b2dfc0                                 UnityEngine.Random::Range
02d14774: cbz     x20, #0x2d14d60                            
02d14778: mov     x0, x20                                    
02d1477c: mov     x1, xzr                                    
02d14780: fmov    s9, s0                                     
02d14784: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d14788: cbz     x0, #0x2d14d5c                             
02d1478c: fadd    s0, s10, s8                                
02d14790: fadd    s1, s11, s9                                
02d14794: mov     x1, xzr                                    
02d14798: movi    d2, #0000000000000000                      
02d1479c: bl      #0x5b45cec                                 UnityEngine.Transform::set_localPosition
02d147a0: ldr     x21, [x27, #0x68]                          
02d147a4: mov     x0, x20                                    
02d147a8: mov     x1, xzr                                    
02d147ac: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d147b0: movi    d0, #0000000000000000                      
02d147b4: adrp    x8, #0x1084000                             
02d147b8: mov     x22, x0                                    
02d147bc: ldr     s1, [x8, #0xf10]                           [1084f10]=4110bc863e99999a f=0.3,9.04603
02d147c0: mov     x0, xzr                                    
02d147c4: bl      #0x5b2dfc0                                 UnityEngine.Random::Range
02d147c8: fmov    s3, s0                                     
02d147cc: movi    d0, #0000000000000000                      
02d147d0: mov     x0, x22                                    
02d147d4: fmov    s1, #30.00000000                           
02d147d8: fmov    s2, #1.00000000                            
02d147dc: mov     w1, #0xa                                   
02d147e0: fmov    s4, #1.00000000                            
02d147e4: mov     w2, wzr                                    
02d147e8: mov     x3, xzr                                    
02d147ec: bl      #0x2d995c4                                 DG.Tweening.ShortcutExtensions::DOPunchPosition
02d147f0: adrp    x8, #0x6264000                             
02d147f4: ldr     x8, [x8, #0x108]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d147f8: ldr     x2, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d147fc: mov     w1, #0x19                                  
02d14800: bl      #0x336fa0c                                 fn_336fa0c
02d14804: mov     w1, wzr                                    
02d14808: mov     x2, xzr                                    
02d1480c: mov     x3, xzr                                    
02d14810: bl      #0x545d870                                 Cysharp.Threading.Tasks.DOTweenAsyncExtensions::ToUniTask
02d14814: cbz     x21, #0x2d14d54                            
02d14818: ldr     w11, [x21, #0x1c]                          
02d1481c: ldr     x9, [x21, #0x10]                           .<>1__state
02d14820: ldr     x10, [x28]                                 T:Trading.TradingSession/<>c__DisplayClass56_0
02d14824: add     w11, w11, #1                               
02d14828: str     w11, [x21, #0x1c]                          
02d1482c: cbz     x9, #0x2d14d54                             
02d14830: ldrsw   x11, [x21, #0x18]                          .<>t__builder
02d14834: ldr     w12, [x9, #0x18]                           
02d14838: mov     x8, x0                                     
02d1483c: mov     x2, x1                                     
02d14840: cmp     w11, w12                                   
02d14844: b.hs    #0x2d14864                                 
02d14848: add     x0, x9, x11, lsl #4                        
02d1484c: add     w10, w11, #1                               
02d14850: str     w10, [x21, #0x18]                          .<>t__builder
02d14854: stp     x8, x2, [x0, #0x20]!                       
02d14858: mov     x1, xzr                                    
02d1485c: bl      #0x2b70d54                                 fn_2b70d54
02d14860: b       #0x2d1487c                                 
02d14864: ldr     x9, [x10, #0x20]                           
02d14868: ldr     x9, [x9, #0xc0]                            
02d1486c: ldr     x3, [x9, #0x70]                            
02d14870: mov     x0, x21                                    
02d14874: mov     x1, x8                                     
02d14878: bl      #0x3628800                                 fn_3628800
02d1487c: ldr     x0, [x27, #0x60]                           
02d14880: cbz     x0, #0x2d14d58                             
02d14884: ldr     w10, [x0, #0x1c]                           [626601c]=0 f=0,0
02d14888: ldr     x8, [x0, #0x10]                            S:'mrec_ad_on_off' .<>1__state
02d1488c: ldr     x9, [x29]                                  S:'{0}/2'
02d14890: add     w10, w10, #1                               
02d14894: str     w10, [x0, #0x1c]                           
02d14898: cbz     x8, #0x2d14d58                             
02d1489c: ldrsw   x10, [x0, #0x18]                           .<>t__builder
02d148a0: ldr     w11, [x8, #0x18]                           M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0::<DOSetFloat>b__1
02d148a4: cmp     w10, w11                                   
02d148a8: b.hs    #0x2d148cc                                 
02d148ac: add     x8, x8, x10, lsl #3                        &6264000
02d148b0: add     w9, w10, #1                                
02d148b4: str     w9, [x0, #0x18]                            .<>t__builder
02d148b8: str     x20, [x8, #0x20]!                          
02d148bc: mov     x0, x8                                     
02d148c0: mov     x1, x20                                    
02d148c4: bl      #0x2b70d54                                 fn_2b70d54
02d148c8: b       #0x2d148e0                                 
02d148cc: ldr     x8, [x9, #0x20]                            
02d148d0: ldr     x8, [x8, #0xc0]                            MS:System.Nullable`1::get_HasValue
02d148d4: ldr     x2, [x8, #0x70]                            T:DG.Tweening.DOTweenModulePhysics/<>c__DisplayClass3_0
02d148d8: mov     x1, x20                                    
02d148dc: bl      #0x35a920c                                 fn_35a920c
02d148e0: ldr     x0, [x26]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d148e4: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d148e8: cbnz    w8, #0x2d148f0                             
02d148ec: bl      #0x2b70f30                                 fn_2b70f30
02d148f0: adrp    x8, #0x1041000                             
02d148f4: mov     x0, xzr                                    
02d148f8: ldr     d0, [x8, #0x220]                           [1041220]=3f747ae140000000 f=2,0.955
02d148fc: bl      #0x4e29964                                 System.TimeSpan::FromSeconds
02d14900: mov     x20, x0                                    
02d14904: ldr     x0, [x25]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d14908: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d1490c: cbnz    w8, #0x2d14914                             
02d14910: bl      #0x2b70f30                                 fn_2b70f30
02d14914: mov     x0, x20                                    
02d14918: mov     w1, wzr                                    
02d1491c: mov     w2, #8                                     
02d14920: mov     x3, xzr                                    
02d14924: mov     w4, wzr                                    
02d14928: mov     x5, xzr                                    
02d1492c: bl      #0x54481c8                                 Cysharp.Threading.Tasks.UniTask::Delay
02d14930: stp     x0, x1, [sp, #0x20]                        
02d14934: add     x0, sp, #0x20                              
02d14938: mov     x1, xzr                                    
02d1493c: bl      #0x2b70d54                                 fn_2b70d54
02d14940: adrp    x20, #0x662f000                            
02d14944: ldr     q0, [sp, #0x20]                            
02d14948: ldrb    w8, [x20, #0xbdc]                          
02d1494c: str     q0, [sp, #0x10]                            
02d14950: cbnz    w8, #0x2d14968                             
02d14954: adrp    x0, #0x6266000                             
02d14958: ldr     x0, [x0, #0xcc8]                           T:Cysharp.Threading.Tasks.UniTask
02d1495c: bl      #0x2b70db0                                 fn_2b70db0
02d14960: mov     w8, #1                                     
02d14964: strb    w8, [x20, #0xbdc]                          
02d14968: ldr     x0, [x25]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1496c: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d14970: cbnz    w8, #0x2d14978                             
02d14974: bl      #0x2b70f30                                 fn_2b70f30
02d14978: adrp    x20, #0x662f000                            
02d1497c: ldrb    w8, [x20, #0xbdd]                          
02d14980: cbnz    w8, #0x2d14998                             
02d14984: adrp    x0, #0x6266000                             
02d14988: ldr     x0, [x0, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02d1498c: bl      #0x2b70db0                                 fn_2b70db0
02d14990: mov     w8, #1                                     
02d14994: strb    w8, [x20, #0xbdd]                          
02d14998: ldr     x20, [sp, #0x10]                           
02d1499c: cbz     x20, #0x2d14a04                            
02d149a0: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02d149a4: ldrh    w21, [sp, #0x18]                           
02d149a8: ldr     x1, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d149ac: ldrh    w9, [x8, #0x12e]                           
02d149b0: cbz     x9, #0x2d149d4                             
02d149b4: ldr     x10, [x8, #0xb0]                           [10410b0]=412e848000000000 f=0,10.9073
02d149b8: add     x10, x10, #8                               
02d149bc: ldur    x11, [x10, #-8]                            
02d149c0: cmp     x11, x1                                    
02d149c4: b.eq    #0x2d149e4                                 
02d149c8: subs    x9, x9, #1                                 
02d149cc: add     x10, x10, #0x10                            
02d149d0: b.ne    #0x2d149bc                                 
02d149d4: mov     x0, x20                                    
02d149d8: mov     w2, wzr                                    
02d149dc: bl      #0x2baa05c                                 fn_2baa05c
02d149e0: b       #0x2d149f0                                 
02d149e4: ldrsw   x9, [x10]                                  
02d149e8: add     x8, x8, x9, lsl #4                         &1041000
02d149ec: add     x0, x8, #0x138                             &1041138
02d149f0: ldp     x8, x2, [x0]                               
02d149f4: mov     x0, x20                                    
02d149f8: mov     w1, w21                                    
02d149fc: blr     x8                                         
02d14a00: cbz     w0, #0x2d14b7c                             
02d14a04: ldrb    w8, [x24, #0xbde]                          
02d14a08: cbnz    w8, #0x2d14a20                             
02d14a0c: adrp    x0, #0x6266000                             
02d14a10: ldr     x0, [x0, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02d14a14: bl      #0x2b70db0                                 fn_2b70db0
02d14a18: mov     w8, #1                                     
02d14a1c: strb    w8, [x24, #0xbde]                          
02d14a20: ldr     x20, [sp, #0x10]                           
02d14a24: cbz     x20, #0x2d14a8c                            
02d14a28: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02d14a2c: ldrh    w21, [sp, #0x18]                           
02d14a30: ldr     x1, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d14a34: ldrh    w9, [x8, #0x12e]                           
02d14a38: cbz     x9, #0x2d14a5c                             
02d14a3c: ldr     x10, [x8, #0xb0]                           [10410b0]=412e848000000000 f=0,10.9073
02d14a40: add     x10, x10, #8                               
02d14a44: ldur    x11, [x10, #-8]                            
02d14a48: cmp     x11, x1                                    
02d14a4c: b.eq    #0x2d14a6c                                 
02d14a50: subs    x9, x9, #1                                 
02d14a54: add     x10, x10, #0x10                            
02d14a58: b.ne    #0x2d14a44                                 
02d14a5c: mov     x0, x20                                    
02d14a60: mov     w2, #2                                     
02d14a64: bl      #0x2baa05c                                 fn_2baa05c
02d14a68: b       #0x2d14a7c                                 
02d14a6c: ldr     w9, [x10]                                  
02d14a70: add     w9, w9, #2                                 
02d14a74: add     x8, x8, w9, sxtw #4                        &1041000
02d14a78: add     x0, x8, #0x138                             &1041138
02d14a7c: ldp     x8, x2, [x0]                               
02d14a80: mov     x0, x20                                    
02d14a84: mov     w1, w21                                    
02d14a88: blr     x8                                         
02d14a8c: ldr     w8, [x19, #0x34]                           
02d14a90: add     w8, w8, #1                                 
02d14a94: str     w8, [x19, #0x34]                           
02d14a98: ldr     w9, [x19, #0x30]                           
02d14a9c: cmp     w8, w9                                     
02d14aa0: b.lt    #0x2d14690                                 
02d14aa4: cbz     x27, #0x2d14d6c                            
02d14aa8: ldr     x0, [x25]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d14aac: ldr     x20, [x27, #0x68]                          
02d14ab0: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d14ab4: cbnz    w8, #0x2d14abc                             
02d14ab8: bl      #0x2b70f30                                 fn_2b70f30
02d14abc: mov     x0, x20                                    
02d14ac0: mov     x1, xzr                                    
02d14ac4: bl      #0x544ae1c                                 Cysharp.Threading.Tasks.UniTask::WhenAll
02d14ac8: stp     x0, x1, [sp, #0x20]                        
02d14acc: add     x0, sp, #0x20                              
02d14ad0: mov     x1, xzr                                    
02d14ad4: bl      #0x2b70d54                                 fn_2b70d54
02d14ad8: adrp    x20, #0x662f000                            
02d14adc: ldr     q0, [sp, #0x20]                            
02d14ae0: ldrb    w8, [x20, #0xbdc]                          
02d14ae4: str     q0, [sp, #0x10]                            
02d14ae8: cbnz    w8, #0x2d14b00                             
02d14aec: adrp    x0, #0x6266000                             
02d14af0: ldr     x0, [x0, #0xcc8]                           T:Cysharp.Threading.Tasks.UniTask
02d14af4: bl      #0x2b70db0                                 fn_2b70db0
02d14af8: mov     w8, #1                                     
02d14afc: strb    w8, [x20, #0xbdc]                          
02d14b00: ldr     x0, [x25]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d14b04: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d14b08: cbnz    w8, #0x2d14b10                             
02d14b0c: bl      #0x2b70f30                                 fn_2b70f30
02d14b10: adrp    x20, #0x662f000                            
02d14b14: ldrb    w8, [x20, #0xbdd]                          
02d14b18: cbnz    w8, #0x2d14b30                             
02d14b1c: adrp    x0, #0x6266000                             
02d14b20: ldr     x0, [x0, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02d14b24: bl      #0x2b70db0                                 fn_2b70db0
02d14b28: mov     w8, #1                                     
02d14b2c: strb    w8, [x20, #0xbdd]                          
02d14b30: ldr     x20, [sp, #0x10]                           
02d14b34: cbz     x20, #0x2d14bd4                            
02d14b38: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02d14b3c: ldrh    w21, [sp, #0x18]                           
02d14b40: ldr     x1, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d14b44: ldrh    w9, [x8, #0x12e]                           
02d14b48: cbz     x9, #0x2d14b6c                             
02d14b4c: ldr     x10, [x8, #0xb0]                           [10410b0]=412e848000000000 f=0,10.9073
02d14b50: add     x10, x10, #8                               
02d14b54: ldur    x11, [x10, #-8]                            
02d14b58: cmp     x11, x1                                    
02d14b5c: b.eq    #0x2d14bb4                                 
02d14b60: subs    x9, x9, #1                                 
02d14b64: add     x10, x10, #0x10                            
02d14b68: b.ne    #0x2d14b54                                 
02d14b6c: mov     x0, x20                                    
02d14b70: mov     w2, wzr                                    
02d14b74: bl      #0x2baa05c                                 fn_2baa05c
02d14b78: b       #0x2d14bc0                                 
02d14b7c: ldr     q0, [sp, #0x10]                            
02d14b80: str     wzr, [x19]                                 
02d14b84: stur    q0, [x19, #0x38]                           .<>4__this
02d14b88: add     x0, x19, #0x38                             
02d14b8c: mov     x1, xzr                                    
02d14b90: bl      #0x2b70d54                                 fn_2b70d54
02d14b94: adrp    x8, #0x6269000                             
02d14b98: ldr     x8, [x8, #0x860]                           MS:Cysharp.Threading.Tasks.CompilerServices.AsyncUniTaskMethodBuilder::AwaitUnsafeOnCompleted
02d14b9c: ldr     x3, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d14ba0: add     x0, x19, #8                                
02d14ba4: add     x1, sp, #0x10                              
02d14ba8: mov     x2, x19                                    
02d14bac: bl      #0x2d1922c                                 fn_2d1922c
02d14bb0: b       #0x2d14cf0                                 
02d14bb4: ldrsw   x9, [x10]                                  
02d14bb8: add     x8, x8, x9, lsl #4                         &6269000
02d14bbc: add     x0, x8, #0x138                             &6269138
02d14bc0: ldp     x8, x2, [x0]                               
02d14bc4: mov     x0, x20                                    
02d14bc8: mov     w1, w21                                    
02d14bcc: blr     x8                                         
02d14bd0: cbz     w0, #0x2d14d18                             
02d14bd4: ldrb    w8, [x24, #0xbde]                          
02d14bd8: cbnz    w8, #0x2d14bf0                             
02d14bdc: adrp    x0, #0x6266000                             
02d14be0: ldr     x0, [x0, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02d14be4: bl      #0x2b70db0                                 fn_2b70db0
02d14be8: mov     w8, #1                                     
02d14bec: strb    w8, [x24, #0xbde]                          
02d14bf0: ldr     x20, [sp, #0x10]                           
02d14bf4: cbz     x20, #0x2d14c5c                            
02d14bf8: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02d14bfc: ldrh    w21, [sp, #0x18]                           
02d14c00: ldr     x1, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d14c04: ldrh    w9, [x8, #0x12e]                           
02d14c08: cbz     x9, #0x2d14c2c                             
02d14c0c: ldr     x10, [x8, #0xb0]                           M:Trading.TradingSession/<>c__DisplayClass65_0::<BuildResult>b__0
02d14c10: add     x10, x10, #8                               
02d14c14: ldur    x11, [x10, #-8]                            
02d14c18: cmp     x11, x1                                    
02d14c1c: b.eq    #0x2d14c3c                                 
02d14c20: subs    x9, x9, #1                                 
02d14c24: add     x10, x10, #0x10                            
02d14c28: b.ne    #0x2d14c14                                 
02d14c2c: mov     x0, x20                                    
02d14c30: mov     w2, #2                                     
02d14c34: bl      #0x2baa05c                                 fn_2baa05c
02d14c38: b       #0x2d14c4c                                 
02d14c3c: ldr     w9, [x10]                                  
02d14c40: add     w9, w9, #2                                 
02d14c44: add     x8, x8, w9, sxtw #4                        &6269000
02d14c48: add     x0, x8, #0x138                             &6269138
02d14c4c: ldp     x8, x2, [x0]                               
02d14c50: mov     x0, x20                                    
02d14c54: mov     w1, w21                                    
02d14c58: blr     x8                                         
02d14c5c: adrp    x20, #0x662f000                            
02d14c60: mov     w9, #-2                                    
02d14c64: ldrb    w8, [x20, #0xe25]                          
02d14c68: str     w9, [x19]                                  
02d14c6c: cbnz    w8, #0x2d14c84                             
02d14c70: adrp    x0, #0x6268000                             
02d14c74: ldr     x0, [x0, #0xd8]                            T:Cysharp.Threading.Tasks.CompilerServices.IStateMachineRunnerPromise
02d14c78: bl      #0x2b70db0                                 fn_2b70db0
02d14c7c: mov     w8, #1                                     
02d14c80: strb    w8, [x20, #0xe25]                          
02d14c84: ldr     x19, [x19, #8]                             
02d14c88: cbz     x19, #0x2d14cf0                            
02d14c8c: adrp    x10, #0x6268000                            
02d14c90: ldr     x8, [x19]                                  
02d14c94: ldr     x10, [x10, #0xd8]                          T:Cysharp.Threading.Tasks.CompilerServices.IStateMachineRunnerPromise
02d14c98: ldrh    w9, [x8, #0x12e]                           
02d14c9c: ldr     x1, [x10]                                  S:'{0}/2'
02d14ca0: cbz     x9, #0x2d14cc4                             
02d14ca4: ldr     x10, [x8, #0xb0]                           M:Trading.TradingSession/<>c__DisplayClass65_0::<BuildResult>b__0
02d14ca8: add     x10, x10, #8                               &6268008
02d14cac: ldur    x11, [x10, #-8]                            
02d14cb0: cmp     x11, x1                                    
02d14cb4: b.eq    #0x2d14cd4                                 
02d14cb8: subs    x9, x9, #1                                 
02d14cbc: add     x10, x10, #0x10                            &6268010
02d14cc0: b.ne    #0x2d14cac                                 
02d14cc4: mov     x0, x19                                    
02d14cc8: mov     w2, #2                                     
02d14ccc: bl      #0x2baa05c                                 fn_2baa05c
02d14cd0: b       #0x2d14ce4                                 
02d14cd4: ldr     w9, [x10]                                  S:'{0}/2'
02d14cd8: add     w9, w9, #2                                 
02d14cdc: add     x8, x8, w9, sxtw #4                        &6269000
02d14ce0: add     x0, x8, #0x138                             &6269138
02d14ce4: ldp     x8, x1, [x0]                               
02d14ce8: mov     x0, x19                                    
02d14cec: blr     x8                                         
02d14cf0: ldp     x20, x19, [sp, #0xa0]                      
02d14cf4: ldp     x22, x21, [sp, #0x90]                      
02d14cf8: ldp     x24, x23, [sp, #0x80]                      
02d14cfc: ldp     x26, x25, [sp, #0x70]                      
02d14d00: ldp     x28, x27, [sp, #0x60]                      
02d14d04: ldp     x29, x30, [sp, #0x50]                      
02d14d08: ldp     d9, d8, [sp, #0x40]                        
02d14d0c: ldp     d11, d10, [sp, #0x30]                      
02d14d10: add     sp, sp, #0xb0                              
02d14d14: ret                                                
02d14d18: ldr     q0, [sp, #0x10]                            
02d14d1c: mov     w8, #1                                     
02d14d20: str     w8, [x19]                                  
02d14d24: stur    q0, [x19, #0x38]                           .<>4__this
02d14d28: add     x0, x19, #0x38                             
02d14d2c: mov     x1, xzr                                    
02d14d30: bl      #0x2b70d54                                 fn_2b70d54
02d14d34: adrp    x8, #0x6269000                             
02d14d38: ldr     x8, [x8, #0x860]                           MS:Cysharp.Threading.Tasks.CompilerServices.AsyncUniTaskMethodBuilder::AwaitUnsafeOnCompleted
02d14d3c: ldr     x3, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d14d40: add     x0, x19, #8                                
02d14d44: add     x1, sp, #0x10                              
02d14d48: mov     x2, x19                                    
02d14d4c: bl      #0x2d1922c                                 fn_2d1922c
02d14d50: b       #0x2d14cf0                                 
02d14d54: bl      #0x2b7105c                                 fn_2b7105c
02d14d58: bl      #0x2b7105c                                 fn_2b7105c
02d14d5c: bl      #0x2b7105c                                 fn_2b7105c
02d14d60: bl      #0x2b7105c                                 fn_2b7105c
02d14d64: bl      #0x2b7105c                                 fn_2b7105c
02d14d68: bl      #0x2b7105c                                 fn_2b7105c
02d14d6c: bl      #0x2b7105c                                 fn_2b7105c
02d14d70: b       #0x2d14df4                                 
02d14d74: b       #0x2d14df4                                 
02d14d78: b       #0x2d14df4                                 
02d14d7c: b       #0x2d14df4                                 
02d14d80: b       #0x2d14df4                                 
02d14d84: b       #0x2d14df4                                 
02d14d88: b       #0x2d14df4                                 
02d14d8c: b       #0x2d14df4                                 
02d14d90: b       #0x2d14df4                                 
02d14d94: b       #0x2d14df4                                 
02d14d98: b       #0x2d14df4                                 
02d14d9c: b       #0x2d14df4                                 
02d14da0: b       #0x2d14df4                                 
02d14da4: b       #0x2d14df4                                 
02d14da8: b       #0x2d14df4                                 
02d14dac: b       #0x2d14df4                                 
02d14db0: b       #0x2d14df4                                 
02d14db4: b       #0x2d14df4                                 
02d14db8: b       #0x2d14df4                                 
02d14dbc: b       #0x2d14df4                                 
02d14dc0: b       #0x2d14df4                                 
02d14dc4: b       #0x2d14df4                                 
02d14dc8: b       #0x2d14df4                                 
02d14dcc: b       #0x2d14df4                                 
02d14dd0: b       #0x2d14df4                                 
02d14dd4: b       #0x2d14df4                                 
02d14dd8: b       #0x2d14df4                                 
02d14ddc: b       #0x2d14df4                                 
02d14de0: b       #0x2d14df4                                 
02d14de4: b       #0x2d14df4                                 
02d14de8: b       #0x2d14df4                                 
02d14dec: b       #0x2d14df4                                 
02d14df0: b       #0x2d14df4                                 
02d14df4: mov     x20, x0                                    
02d14df8: cmp     w1, #1                                     
02d14dfc: b.ne    #0x2d14e8c                                 
02d14e00: mov     x0, x20                                    
02d14e04: bl      #0x5e90260                                 fn_5e90260
02d14e08: mov     x20, x0                                    
02d14e0c: adrp    x0, #0x6263000                             
02d14e10: ldr     x0, [x0, #0xae0]                           T:System.Exception
02d14e14: bl      #0x2b70dc4                                 fn_2b70dc4
02d14e18: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02d14e1c: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d14e20: bl      #0x2b71464                                 fn_2b71464
02d14e24: tbz     w0, #0, #0x2d14e64                         
02d14e28: ldrsw   x21, [sp, #8]                              
02d14e2c: ldr     x20, [x20]                                 &2b706c4(=eb01011ff9400808)
02d14e30: mov     x8, sp                                     
02d14e34: str     x20, [x8, x21, lsl #3]                     
02d14e38: add     w8, w21, #1                                
02d14e3c: str     w8, [sp, #8]                               
02d14e40: bl      #0x5e90270                                 fn_5e90270
02d14e44: mov     w8, #-2                                    
02d14e48: mov     x1, x20                                    
02d14e4c: mov     x2, xzr                                    
02d14e50: str     w8, [x19], #8                              
02d14e54: mov     x0, x19                                    
02d14e58: bl      #0x2ceaea8                                 fn_2ceaea8
02d14e5c: str     w21, [sp, #8]                              
02d14e60: b       #0x2d14cf0                                 
02d14e64: mov     w0, #8                                     
02d14e68: bl      #0x5e90290                                 fn_5e90290
02d14e6c: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02d14e70: str     x8, [x0]                                   
02d14e74: adrp    x1, #0x5e96000                             
02d14e78: add     x1, x1, #0x758                             &5e96758
02d14e7c: mov     x2, xzr                                    
02d14e80: bl      #0x5e902a0                                 fn_5e902a0
02d14e84: mov     x20, x0                                    
02d14e88: bl      #0x5e90270                                 fn_5e90270
02d14e8c: mov     x0, x20                                    
02d14e90: bl      #0x2c6051c                                 fn_2c6051c
02d14e94: bl      #0x27369b8                                 fn_27369b8
## SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine stateMachine) -> void
---- JobGame.CollectingCoin/<SpawnCoin>d__22::SetStateMachine 0x2d14e98
02d14e98: add     x0, x0, #8                                 
02d14e9c: mov     x2, xzr                                    
02d14ea0: b       #0x545f130                                 Cysharp.Threading.Tasks.CompilerServices.AsyncUniTaskMethodBuilder::SetStateMachine
#### CLASS JobGame.CollectingCoin parent= UnityEngine.MonoBehaviour
#   field _prefabType                    PoolType                                           off=0x20 attr=1 SerializeField
#   field _coinParent                    UnityEngine.Transform                              off=0x28 attr=1 SerializeField
#   field _spawnLocation                 UnityEngine.Transform                              off=0x30 attr=1 SerializeField
#   field _endPosition                   UnityEngine.RectTransform                          off=0x38 attr=1 SerializeField
#   field _coinLabel                     UnityEngine.RectTransform                          off=0x40 attr=1 SerializeField
#   field _duration                      float                                              off=0x48 attr=1 SerializeField
#   field _minX                          float                                              off=0x4c attr=1 HeaderAttribute,SerializeField
#   field _maxX                          float                                              off=0x50 attr=1 SerializeField
#   field _minY                          float                                              off=0x54 attr=1 SerializeField
#   field _maxY                          float                                              off=0x58 attr=1 SerializeField
#   field _coins                         System.Collections.Generic.List`1<UnityEngine.Transform> off=0x60 attr=1 
#   field _spawnCoinTaskList             System.Collections.Generic.List`1<Cysharp.Threading.Tasks.UniTask> off=0x68 attr=1 
#   field _coinReactionTween             DG.Tweening.Tween                                  off=0x70 attr=1 
#   field _firstCoinMoved                bool                                               off=0x78 attr=1 
#   field _isCollecting                  bool                                               off=0x79 attr=1 
#   field _defaultSpawnPosition          UnityEngine.Vector3                                off=0x7c attr=1 
## get_IsCollecting() -> bool
---- JobGame.CollectingCoin::get_IsCollecting 0x2d12144
02d12144: ldrb    w0, [x0, #0x79]                            ._isCollecting
02d12148: ret                                                
## Start() -> void
---- JobGame.CollectingCoin::Start 0x2d1214c
02d1214c: stp     x30, x21, [sp, #-0x20]!                    
02d12150: stp     x20, x19, [sp, #0x10]                      
02d12154: adrp    x21, #0x662f000                            
02d12158: adrp    x20, #0x6263000                            
02d1215c: mov     x19, x0                                    
02d12160: ldrb    w8, [x21, #0xfbd]                          
02d12164: ldr     x20, [x20, #0x918]                         T:UnityEngine.Object
02d12168: tbnz    w8, #0, #0x2d12180                         
02d1216c: adrp    x0, #0x6263000                             
02d12170: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d12174: bl      #0x2b70db0                                 fn_2b70db0
02d12178: mov     w8, #1                                     
02d1217c: strb    w8, [x21, #0xfbd]                          
02d12180: ldr     x0, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d12184: ldr     x20, [x19, #0x30]                          ._spawnLocation
02d12188: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d1218c: cbnz    w8, #0x2d12194                             
02d12190: bl      #0x2b70f30                                 fn_2b70f30
02d12194: mov     x0, x20                                    
02d12198: mov     x1, xzr                                    
02d1219c: mov     x2, xzr                                    
02d121a0: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d121a4: tbz     w0, #0, #0x2d121bc                         
02d121a8: ldr     x0, [x19, #0x30]                           ._spawnLocation
02d121ac: cbz     x0, #0x2d121f8                             
02d121b0: mov     x1, xzr                                    
02d121b4: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d121b8: b       #0x2d121d4                                 
02d121bc: mov     x0, x19                                    
02d121c0: mov     x1, xzr                                    
02d121c4: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d121c8: cbz     x0, #0x2d121f8                             
02d121cc: mov     x1, xzr                                    
02d121d0: bl      #0x5b45c24                                 UnityEngine.Transform::get_localPosition
02d121d4: fmov    s3, #0.50000000                            
02d121d8: ldr     s4, [x19, #0x48]                           ._duration
02d121dc: stp     s0, s1, [x19, #0x7c]                       ._defaultSpawnPosition
02d121e0: str     s2, [x19, #0x84]                           
02d121e4: fmul    s3, s4, s3                                 
02d121e8: str     s3, [x19, #0x48]                           ._duration
02d121ec: ldp     x20, x19, [sp, #0x10]                      
02d121f0: ldp     x30, x21, [sp], #0x20                      
02d121f4: ret                                                
02d121f8: bl      #0x2b7105c                                 fn_2b7105c
## SetSpawnLocation(UnityEngine.Vector3 spawnLocation) -> JobGame.CollectingCoin
---- JobGame.CollectingCoin::SetSpawnLocation 0x2d121fc
02d121fc: stp     x30, x19, [sp, #-0x10]!                    
02d12200: mov     x19, x0                                    
02d12204: ldr     x0, [x0, #0x30]                            ._spawnLocation
02d12208: cbz     x0, #0x2d12220                             
02d1220c: mov     x1, xzr                                    
02d12210: bl      #0x5b46888                                 UnityEngine.Transform::set_position
02d12214: mov     x0, x19                                    
02d12218: ldp     x30, x19, [sp], #0x10                      
02d1221c: ret                                                
02d12220: bl      #0x2b7105c                                 fn_2b7105c
## CollectCoins(int coinAmount, System.Action onCoinCollected) -> void
---- JobGame.CollectingCoin::CollectCoins 0x2d12224
02d12224: sub     sp, sp, #0xa0                              
02d12228: stp     x30, x23, [sp, #0x70]                      
02d1222c: stp     x22, x21, [sp, #0x80]                      
02d12230: stp     x20, x19, [sp, #0x90]                      
02d12234: adrp    x23, #0x662f000                            
02d12238: adrp    x22, #0x6269000                            
02d1223c: mov     x19, x2                                    
02d12240: ldrb    w8, [x23, #0xfbe]                          
02d12244: ldr     x22, [x22, #0x7f0]                         MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::Start
02d12248: mov     w20, w1                                    
02d1224c: mov     x21, x0                                    
02d12250: tbnz    w8, #0, #0x2d12268                         
02d12254: adrp    x0, #0x6269000                             
02d12258: ldr     x0, [x0, #0x7f0]                           MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::Start
02d1225c: bl      #0x2b70db0                                 fn_2b70db0
02d12260: mov     w8, #1                                     
02d12264: strb    w8, [x23, #0xfbe]                          
02d12268: movi    v0.2d, #0000000000000000                   
02d1226c: mov     x8, sp                                     
02d12270: mov     x0, xzr                                    
02d12274: stp     q0, q0, [sp, #0x30]                        
02d12278: stp     q0, q0, [sp, #0x50]                        
02d1227c: str     q0, [sp, #0x20]                            
02d12280: bl      #0x4d43a24                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::Create
02d12284: ldp     q0, q1, [sp]                               
02d12288: add     x23, sp, #0x20                             
02d1228c: orr     x0, x23, #8                                
02d12290: mov     x1, xzr                                    
02d12294: stur    q0, [sp, #0x28]                            
02d12298: stur    q1, [sp, #0x38]                            
02d1229c: bl      #0x2b70d54                                 fn_2b70d54
02d122a0: add     x0, x23, #0x28                             &662f028
02d122a4: mov     x1, x21                                    
02d122a8: str     x21, [sp, #0x48]                           
02d122ac: bl      #0x2b70d54                                 fn_2b70d54
02d122b0: add     x0, x23, #0x38                             &662f038
02d122b4: mov     x1, x19                                    
02d122b8: str     w20, [sp, #0x50]                           
02d122bc: str     x19, [sp, #0x58]                           
02d122c0: bl      #0x2b70d54                                 fn_2b70d54
02d122c4: ldr     x2, [x22]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d122c8: mov     w8, #-1                                    
02d122cc: orr     x0, x23, #8                                
02d122d0: add     x1, sp, #0x20                              
02d122d4: str     w8, [sp, #0x20]                            
02d122d8: bl      #0x30c66ac                                 fn_30c66ac
02d122dc: ldp     x20, x19, [sp, #0x90]                      
02d122e0: ldp     x22, x21, [sp, #0x80]                      
02d122e4: ldp     x30, x23, [sp, #0x70]                      
02d122e8: add     sp, sp, #0xa0                              
02d122ec: ret                                                
## ResetCoins() -> void
---- JobGame.CollectingCoin::ResetCoins 0x2d122f0
02d122f0: sub     sp, sp, #0x60                              
02d122f4: stp     x30, x23, [sp, #0x30]                      
02d122f8: stp     x22, x21, [sp, #0x40]                      
02d122fc: stp     x20, x19, [sp, #0x50]                      
02d12300: adrp    x20, #0x662f000                            
02d12304: mov     x19, x0                                    
02d12308: ldrb    w8, [x20, #0xfbf]                          
02d1230c: tbnz    w8, #0, #0x2d1236c                         
02d12310: adrp    x0, #0x6268000                             
02d12314: ldr     x0, [x0, #0x9d0]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d12318: bl      #0x2b70db0                                 fn_2b70db0
02d1231c: adrp    x0, #0x6268000                             
02d12320: ldr     x0, [x0, #0x9d8]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d12324: bl      #0x2b70db0                                 fn_2b70db0
02d12328: adrp    x0, #0x6268000                             
02d1232c: ldr     x0, [x0, #0x9e0]                           MS:System.Collections.Generic.List`1/Enumerator::get_Current
02d12330: bl      #0x2b70db0                                 fn_2b70db0
02d12334: adrp    x0, #0x6268000                             
02d12338: ldr     x0, [x0, #0x998]                           MS:System.Collections.Generic.List`1::Clear
02d1233c: bl      #0x2b70db0                                 fn_2b70db0
02d12340: adrp    x0, #0x6269000                             
02d12344: ldr     x0, [x0, #0x7f8]                           MS:System.Collections.Generic.List`1::Clear
02d12348: bl      #0x2b70db0                                 fn_2b70db0
02d1234c: adrp    x0, #0x6268000                             
02d12350: ldr     x0, [x0, #0x9e8]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d12354: bl      #0x2b70db0                                 fn_2b70db0
02d12358: adrp    x0, #0x6263000                             
02d1235c: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d12360: bl      #0x2b70db0                                 fn_2b70db0
02d12364: mov     w8, #1                                     
02d12368: strb    w8, [x20, #0xfbf]                          
02d1236c: ldr     x0, [x19, #0x60]                           ._coins
02d12370: stp     xzr, xzr, [sp, #0x18]                      
02d12374: str     xzr, [sp, #0x28]                           
02d12378: cbz     x0, #0x2d12474                             
02d1237c: adrp    x8, #0x6268000                             
02d12380: adrp    x22, #0x6268000                            
02d12384: adrp    x23, #0x6263000                            
02d12388: ldr     x8, [x8, #0x9e8]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d1238c: adrp    x21, #0x6268000                            
02d12390: ldr     x22, [x22, #0x9d8]                         MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d12394: ldr     x23, [x23, #0x918]                         T:UnityEngine.Object
02d12398: ldr     x21, [x21, #0x9d0]                         MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d1239c: add     x20, sp, #0x18                             
02d123a0: ldr     x1, [x8]                                   S:'{0}/2'
02d123a4: add     x8, sp, #0x18                              
02d123a8: bl      #0x35a9d9c                                 fn_35a9d9c
02d123ac: stp     xzr, x20, [sp, #8]                         
02d123b0: ldr     x1, [x22]                                  S:'{0}/2'
02d123b4: add     x0, sp, #0x18                              
02d123b8: bl      #0x4690474                                 fn_4690474
02d123bc: tbz     w0, #0, #0x2d123f4                         
02d123c0: ldr     x0, [sp, #0x28]                            
02d123c4: cbz     x0, #0x2d12470                             
02d123c8: mov     x1, xzr                                    
02d123cc: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d123d0: mov     x20, x0                                    
02d123d4: ldr     x0, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d123d8: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d123dc: cbnz    w8, #0x2d123e4                             
02d123e0: bl      #0x2b70f30                                 fn_2b70f30
02d123e4: mov     x0, x20                                    
02d123e8: mov     x1, xzr                                    
02d123ec: bl      #0x5b3ca38                                 UnityEngine.Object::Destroy
02d123f0: b       #0x2d123b0                                 
02d123f4: ldr     x1, [x21]                                  S:'{0}/2'
02d123f8: add     x0, sp, #0x18                              
02d123fc: bl      #0x4690470                                 fn_4690470
02d12400: ldr     x8, [x19, #0x60]                           ._coins
02d12404: cbz     x8, #0x2d12474                             
02d12408: ldp     w2, w9, [x8, #0x18]                        
02d1240c: add     w9, w9, #1                                 
02d12410: cmp     w2, #1                                     
02d12414: stp     wzr, w9, [x8, #0x18]                       
02d12418: b.lt    #0x2d1242c                                 
02d1241c: ldr     x0, [x8, #0x10]                            MS:DG.Tweening.TweenSettingsExtensions::SetLoops
02d12420: mov     w1, wzr                                    
02d12424: mov     x3, xzr                                    
02d12428: bl      #0x4e3494c                                 System.Array::Clear
02d1242c: ldr     x8, [x19, #0x68]                           ._spawnCoinTaskList
02d12430: cbz     x8, #0x2d12474                             
02d12434: ldp     w2, w9, [x8, #0x18]                        
02d12438: add     w9, w9, #1                                 
02d1243c: cmp     w2, #1                                     
02d12440: stp     wzr, w9, [x8, #0x18]                       
02d12444: b.lt    #0x2d12458                                 
02d12448: ldr     x0, [x8, #0x10]                            MS:DG.Tweening.TweenSettingsExtensions::SetLoops
02d1244c: mov     w1, wzr                                    
02d12450: mov     x3, xzr                                    
02d12454: bl      #0x4e3494c                                 System.Array::Clear
02d12458: strb    wzr, [x19, #0x78]                          ._firstCoinMoved
02d1245c: ldp     x20, x19, [sp, #0x50]                      
02d12460: ldp     x22, x21, [sp, #0x40]                      
02d12464: ldp     x30, x23, [sp, #0x30]                      
02d12468: add     sp, sp, #0x60                              
02d1246c: ret                                                
02d12470: bl      #0x2b7105c                                 fn_2b7105c
02d12474: bl      #0x2b7105c                                 fn_2b7105c
02d12478: b       #0x2d12480                                 
02d1247c: b       #0x2d12480                                 
02d12480: cmp     w1, #1                                     
02d12484: b.ne    #0x2d124b0                                 
02d12488: bl      #0x5e90260                                 fn_5e90260
02d1248c: ldr     x20, [x0]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d12490: str     x20, [sp, #8]                              
02d12494: bl      #0x5e90270                                 fn_5e90270
02d12498: ldr     x0, [sp, #0x10]                            
02d1249c: ldr     x1, [x21]                                  S:'{0}/2'
02d124a0: bl      #0x4690470                                 fn_4690470
02d124a4: cbz     x20, #0x2d12400                            
02d124a8: mov     x0, x20                                    
02d124ac: bl      #0x2b71054                                 fn_2b71054
02d124b0: mov     x19, x0                                    
02d124b4: add     x0, sp, #8                                 
02d124b8: bl      #0x2737cf8                                 fn_2737cf8
02d124bc: mov     x0, x19                                    
02d124c0: bl      #0x2c6051c                                 fn_2c6051c
02d124c4: bl      #0x27369b8                                 fn_27369b8
## SpawnCoin(int coinAmount, UnityEngine.Vector3 spawnPos) -> Cysharp.Threading.Tasks.UniTask
---- JobGame.CollectingCoin::SpawnCoin 0x2d124c8
02d124c8: sub     sp, sp, #0x90                              
02d124cc: str     d10, [sp, #0x50]                           
02d124d0: stp     d9, d8, [sp, #0x58]                        
02d124d4: str     x30, [sp, #0x68]                           
02d124d8: stp     x22, x21, [sp, #0x70]                      
02d124dc: stp     x20, x19, [sp, #0x80]                      
02d124e0: fmov    s8, s2                                     
02d124e4: fmov    s9, s1                                     
02d124e8: adrp    x21, #0x662f000                            
02d124ec: fmov    s10, s0                                    
02d124f0: adrp    x22, #0x6269000                            
02d124f4: ldrb    w8, [x21, #0xfc0]                          
02d124f8: ldr     x22, [x22, #0x800]                         MS:Cysharp.Threading.Tasks.CompilerServices.AsyncUniTaskMethodBuilder::Start
02d124fc: mov     w19, w1                                    
02d12500: mov     x20, x0                                    
02d12504: tbnz    w8, #0, #0x2d1251c                         
02d12508: adrp    x0, #0x6269000                             
02d1250c: ldr     x0, [x0, #0x800]                           MS:Cysharp.Threading.Tasks.CompilerServices.AsyncUniTaskMethodBuilder::Start
02d12510: bl      #0x2b70db0                                 fn_2b70db0
02d12514: mov     w8, #1                                     
02d12518: strb    w8, [x21, #0xfc0]                          
02d1251c: movi    v0.2d, #0000000000000000                   
02d12520: mov     x21, sp                                    
02d12524: mov     x1, xzr                                    
02d12528: orr     x0, x21, #8                                
02d1252c: str     xzr, [sp, #0x40]                           
02d12530: stp     q0, q0, [sp]                               
02d12534: stp     q0, q0, [sp, #0x20]                        
02d12538: bl      #0x2b70d54                                 fn_2b70d54
02d1253c: add     x0, x21, #0x28                             &662f028
02d12540: mov     x1, x20                                    
02d12544: str     x20, [sp, #0x28]                           
02d12548: bl      #0x2b70d54                                 fn_2b70d54
02d1254c: ldr     x0, [x22]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d12550: mov     w9, #-1                                    
02d12554: str     w19, [sp, #0x30]                           
02d12558: stp     s10, s9, [sp, #0x18]                       
02d1255c: ldr     x8, [x0, #0x38]                            MS:System.Collections.Generic.Dictionary`2::get_Count ._endPosition
02d12560: str     s8, [sp, #0x20]                            
02d12564: str     w9, [sp]                                   
02d12568: cbnz    x8, #0x2d12570                             
02d1256c: bl      #0x2ba9d7c                                 fn_2ba9d7c
02d12570: mov     x0, sp                                     
02d12574: bl      #0x2d1457c                                 JobGame.CollectingCoin/<SpawnCoin>d__22::MoveNext
02d12578: orr     x0, x21, #8                                
02d1257c: mov     x1, xzr                                    
02d12580: bl      #0x2ceadb0                                 fn_2ceadb0
02d12584: ldp     x20, x19, [sp, #0x80]                      
02d12588: ldr     x30, [sp, #0x68]                           
02d1258c: ldp     x22, x21, [sp, #0x70]                      
02d12590: ldr     d10, [sp, #0x50]                           
02d12594: ldp     d9, d8, [sp, #0x58]                        
02d12598: add     sp, sp, #0x90                              
02d1259c: ret                                                
## MoveCoinsTask(System.Action onCoinCollected) -> Cysharp.Threading.Tasks.UniTask
---- JobGame.CollectingCoin::MoveCoinsTask 0x2d125a0
02d125a0: sub     sp, sp, #0x80                              
02d125a4: str     x30, [sp, #0x50]                           
02d125a8: stp     x22, x21, [sp, #0x60]                      
02d125ac: stp     x20, x19, [sp, #0x70]                      
02d125b0: adrp    x22, #0x662f000                            
02d125b4: adrp    x21, #0x6269000                            
02d125b8: mov     x19, x1                                    
02d125bc: ldrb    w8, [x22, #0xfc1]                          
02d125c0: ldr     x21, [x21, #0x808]                         MS:Cysharp.Threading.Tasks.CompilerServices.AsyncUniTaskMethodBuilder::Start
02d125c4: mov     x20, x0                                    
02d125c8: tbnz    w8, #0, #0x2d125e0                         
02d125cc: adrp    x0, #0x6269000                             
02d125d0: ldr     x0, [x0, #0x808]                           MS:Cysharp.Threading.Tasks.CompilerServices.AsyncUniTaskMethodBuilder::Start
02d125d4: bl      #0x2b70db0                                 fn_2b70db0
02d125d8: mov     w8, #1                                     
02d125dc: strb    w8, [x22, #0xfc1]                          
02d125e0: movi    v0.2d, #0000000000000000                   
02d125e4: mov     x22, sp                                    
02d125e8: mov     x1, xzr                                    
02d125ec: orr     x0, x22, #8                                
02d125f0: str     xzr, [sp, #0x40]                           
02d125f4: stp     q0, q0, [sp]                               
02d125f8: stp     q0, q0, [sp, #0x20]                        
02d125fc: bl      #0x2b70d54                                 fn_2b70d54
02d12600: add     x0, x22, #0x18                             &662f018
02d12604: mov     x1, x20                                    
02d12608: str     x20, [sp, #0x18]                           
02d1260c: bl      #0x2b70d54                                 fn_2b70d54
02d12610: add     x0, x22, #0x20                             &662f020
02d12614: mov     x1, x19                                    
02d12618: str     x19, [sp, #0x20]                           
02d1261c: bl      #0x2b70d54                                 fn_2b70d54
02d12620: ldr     x0, [x21]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d12624: mov     w9, #-1                                    
02d12628: str     w9, [sp]                                   
02d1262c: ldr     x8, [x0, #0x38]                            MS:System.Collections.Generic.Dictionary`2::get_Count ._endPosition
02d12630: cbnz    x8, #0x2d12638                             
02d12634: bl      #0x2ba9d7c                                 fn_2ba9d7c
02d12638: mov     x0, sp                                     
02d1263c: bl      #0x2d13ba0                                 JobGame.CollectingCoin/<MoveCoinsTask>d__23::MoveNext
02d12640: orr     x0, x22, #8                                
02d12644: mov     x1, xzr                                    
02d12648: bl      #0x2ceadb0                                 fn_2ceadb0
02d1264c: ldp     x20, x19, [sp, #0x70]                      
02d12650: ldr     x30, [sp, #0x50]                           
02d12654: ldp     x22, x21, [sp, #0x60]                      
02d12658: add     sp, sp, #0x80                              
02d1265c: ret                                                
## MoveCoinTask(UnityEngine.Transform coinInstance, System.Action onCompleted) -> Cysharp.Threading.Tasks.UniTask
---- JobGame.CollectingCoin::MoveCoinTask 0x2d12660
02d12660: sub     sp, sp, #0x70                              
02d12664: stp     x30, x23, [sp, #0x40]                      
02d12668: stp     x22, x21, [sp, #0x50]                      
02d1266c: stp     x20, x19, [sp, #0x60]                      
02d12670: adrp    x22, #0x662f000                            
02d12674: adrp    x23, #0x6269000                            
02d12678: mov     x19, x2                                    
02d1267c: ldrb    w8, [x22, #0xfc2]                          
02d12680: ldr     x23, [x23, #0x810]                         MS:Cysharp.Threading.Tasks.CompilerServices.AsyncUniTaskMethodBuilder::Start
02d12684: mov     x20, x1                                    
02d12688: mov     x21, x0                                    
02d1268c: tbnz    w8, #0, #0x2d126a4                         
02d12690: adrp    x0, #0x6269000                             
02d12694: ldr     x0, [x0, #0x810]                           MS:Cysharp.Threading.Tasks.CompilerServices.AsyncUniTaskMethodBuilder::Start
02d12698: bl      #0x2b70db0                                 fn_2b70db0
02d1269c: mov     w8, #1                                     
02d126a0: strb    w8, [x22, #0xfc2]                          
02d126a4: movi    v0.2d, #0000000000000000                   
02d126a8: mov     x22, sp                                    
02d126ac: mov     x1, xzr                                    
02d126b0: orr     x0, x22, #8                                
02d126b4: stp     q0, q0, [sp]                               
02d126b8: stp     q0, q0, [sp, #0x20]                        
02d126bc: bl      #0x2b70d54                                 fn_2b70d54
02d126c0: add     x0, x22, #0x18                             &662f018
02d126c4: mov     x1, x21                                    
02d126c8: str     x21, [sp, #0x18]                           
02d126cc: bl      #0x2b70d54                                 fn_2b70d54
02d126d0: add     x0, x22, #0x20                             &662f020
02d126d4: mov     x1, x20                                    
02d126d8: str     x20, [sp, #0x20]                           
02d126dc: bl      #0x2b70d54                                 fn_2b70d54
02d126e0: add     x0, x22, #0x28                             &662f028
02d126e4: mov     x1, x19                                    
02d126e8: str     x19, [sp, #0x28]                           
02d126ec: bl      #0x2b70d54                                 fn_2b70d54
02d126f0: ldr     x0, [x23]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d126f4: mov     w9, #-1                                    
02d126f8: str     w9, [sp]                                   
02d126fc: ldr     x8, [x0, #0x38]                            MS:System.Collections.Generic.Dictionary`2::get_Count ._endPosition
02d12700: cbnz    x8, #0x2d12708                             
02d12704: bl      #0x2ba9d7c                                 fn_2ba9d7c
02d12708: mov     x0, sp                                     
02d1270c: bl      #0x2d13170                                 JobGame.CollectingCoin/<MoveCoinTask>d__24::MoveNext
02d12710: orr     x0, x22, #8                                
02d12714: mov     x1, xzr                                    
02d12718: bl      #0x2ceadb0                                 fn_2ceadb0
02d1271c: ldp     x20, x19, [sp, #0x60]                      
02d12720: ldp     x22, x21, [sp, #0x50]                      
02d12724: ldp     x30, x23, [sp, #0x40]                      
02d12728: add     sp, sp, #0x70                              
02d1272c: ret                                                
## ReactToCollectionCoin() -> Cysharp.Threading.Tasks.UniTask
---- JobGame.CollectingCoin::ReactToCollectionCoin 0x2d12730
02d12730: sub     sp, sp, #0x50                              
02d12734: stp     x30, x21, [sp, #0x30]                      
02d12738: stp     x20, x19, [sp, #0x40]                      
02d1273c: adrp    x20, #0x662f000                            
02d12740: adrp    x21, #0x6269000                            
02d12744: mov     x19, x0                                    
02d12748: ldrb    w8, [x20, #0xfc3]                          
02d1274c: ldr     x21, [x21, #0x818]                         MS:Cysharp.Threading.Tasks.CompilerServices.AsyncUniTaskMethodBuilder::Start
02d12750: tbnz    w8, #0, #0x2d12768                         
02d12754: adrp    x0, #0x6269000                             
02d12758: ldr     x0, [x0, #0x818]                           MS:Cysharp.Threading.Tasks.CompilerServices.AsyncUniTaskMethodBuilder::Start
02d1275c: bl      #0x2b70db0                                 fn_2b70db0
02d12760: mov     w8, #1                                     
02d12764: strb    w8, [x20, #0xfc3]                          
02d12768: movi    v0.2d, #0000000000000000                   
02d1276c: mov     x20, sp                                    
02d12770: mov     x1, xzr                                    
02d12774: orr     x0, x20, #8                                
02d12778: stp     q0, q0, [sp, #0x10]                        
02d1277c: str     q0, [sp]                                   
02d12780: bl      #0x2b70d54                                 fn_2b70d54
02d12784: add     x0, x20, #0x18                             &662f018
02d12788: mov     x1, x19                                    
02d1278c: str     x19, [sp, #0x18]                           
02d12790: bl      #0x2b70d54                                 fn_2b70d54
02d12794: ldr     x0, [x21]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d12798: mov     w9, #-1                                    
02d1279c: str     w9, [sp]                                   
02d127a0: ldr     x8, [x0, #0x38]                            MS:System.Collections.Generic.Dictionary`2::get_Count ._endPosition
02d127a4: cbnz    x8, #0x2d127ac                             
02d127a8: bl      #0x2ba9d7c                                 fn_2ba9d7c
02d127ac: mov     x0, sp                                     
02d127b0: bl      #0x2d1412c                                 JobGame.CollectingCoin/<ReactToCollectionCoin>d__25::MoveNext
02d127b4: orr     x0, x20, #8                                
02d127b8: mov     x1, xzr                                    
02d127bc: bl      #0x2ceadb0                                 fn_2ceadb0
02d127c0: ldp     x20, x19, [sp, #0x40]                      
02d127c4: ldp     x30, x21, [sp, #0x30]                      
02d127c8: add     sp, sp, #0x50                              
02d127cc: ret                                                
## .ctor() -> void
---- JobGame.CollectingCoin::.ctor 0x2d127d0
02d127d0: str     x30, [sp, #-0x40]!                         
02d127d4: stp     x24, x23, [sp, #0x10]                      
02d127d8: stp     x22, x21, [sp, #0x20]                      
02d127dc: stp     x20, x19, [sp, #0x30]                      
02d127e0: adrp    x23, #0x6268000                            
02d127e4: adrp    x24, #0x662f000                            
02d127e8: adrp    x20, #0x6268000                            
02d127ec: adrp    x22, #0x6269000                            
02d127f0: adrp    x21, #0x6269000                            
02d127f4: ldr     x23, [x23, #0x970]                         T:type15473(k15)
02d127f8: ldr     x20, [x20, #0x968]                         MS:System.Collections.Generic.List`1::.ctor
02d127fc: ldrb    w8, [x24, #0xfc4]                          
02d12800: ldr     x22, [x22, #0x820]                         T:type56853(k15)
02d12804: ldr     x21, [x21, #0x828]                         MS:System.Collections.Generic.List`1::.ctor
02d12808: mov     x19, x0                                    
02d1280c: tbnz    w8, #0, #0x2d12848                         
02d12810: adrp    x0, #0x6269000                             
02d12814: ldr     x0, [x0, #0x828]                           MS:System.Collections.Generic.List`1::.ctor
02d12818: bl      #0x2b70db0                                 fn_2b70db0
02d1281c: adrp    x0, #0x6268000                             
02d12820: ldr     x0, [x0, #0x968]                           MS:System.Collections.Generic.List`1::.ctor
02d12824: bl      #0x2b70db0                                 fn_2b70db0
02d12828: adrp    x0, #0x6269000                             
02d1282c: ldr     x0, [x0, #0x820]                           T:type56853(k15)
02d12830: bl      #0x2b70db0                                 fn_2b70db0
02d12834: adrp    x0, #0x6268000                             
02d12838: ldr     x0, [x0, #0x970]                           T:type15473(k15)
02d1283c: bl      #0x2b70db0                                 fn_2b70db0
02d12840: mov     w8, #1                                     
02d12844: strb    w8, [x24, #0xfc4]                          
02d12848: ldr     x0, [x23]                                  S:'{0}/2'
02d1284c: mov     w8, #5                                     
02d12850: str     w8, [x19, #0x20]                           ._prefabType
02d12854: bl      #0x2b7104c                                 fn_2b7104c
02d12858: ldr     x1, [x20]                                  S:'{0}/2'
02d1285c: mov     x20, x0                                    
02d12860: bl      #0x35a89a4                                 fn_35a89a4
02d12864: mov     x0, x19                                    
02d12868: mov     x1, x20                                    
02d1286c: str     x20, [x0, #0x60]!                          ._coins
02d12870: bl      #0x2b70d54                                 fn_2b70d54
02d12874: ldr     x0, [x22]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d12878: bl      #0x2b7104c                                 fn_2b7104c
02d1287c: ldr     x1, [x21]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d12880: mov     x20, x0                                    
02d12884: bl      #0x3627f54                                 fn_3627f54
02d12888: mov     x0, x19                                    
02d1288c: mov     x1, x20                                    
02d12890: str     x20, [x0, #0x68]!                          ._spawnCoinTaskList
02d12894: bl      #0x2b70d54                                 fn_2b70d54
02d12898: mov     x0, x19                                    
02d1289c: ldp     x20, x19, [sp, #0x30]                      
02d128a0: ldp     x22, x21, [sp, #0x20]                      
02d128a4: mov     x1, xzr                                    
02d128a8: ldp     x24, x23, [sp, #0x10]                      
02d128ac: ldr     x30, [sp], #0x40                           
02d128b0: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
## <CollectCoins>b__20_0() -> bool
---- JobGame.CollectingCoin::<CollectCoins>b__20_0 0x2d128b4
02d128b4: ldrb    w8, [x0, #0x79]                            ._isCollecting
02d128b8: cmp     w8, #0                                     
02d128bc: cset    w0, eq                                     
02d128c0: ret                                                
