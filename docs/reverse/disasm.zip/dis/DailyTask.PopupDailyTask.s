#### CLASS DailyTask.PopupDailyTask/<>c__DisplayClass20_0 parent= object
#   field taskId                         int                                                off=0x10 attr=6 
#   field <>4__this                      DailyTask.PopupDailyTask                           off=0x18 attr=6 
#   field <>9__2                         System.Action                                      off=0x20 attr=6 
## .ctor() -> void
---- DailyTask.PopupDailyTask/<>c__DisplayClass20_0::.ctor 0x2d2dc68
02d2dc68: mov     x1, xzr                                    
02d2dc6c: b       #0x4e53e9c                                 System.Object::.ctor
## <OnTaskCompletedCallback>b__0(DailyTask.DailyTaskItemUI n) -> bool
---- DailyTask.PopupDailyTask/<>c__DisplayClass20_0::<OnTaskCompletedCallback>b__0 0x2d2e000
02d2e000: str     x30, [sp, #-0x10]!                         
02d2e004: cbz     x1, #0x2d2e028                             
02d2e008: ldr     x8, [x1, #0x80]                            
02d2e00c: cbz     x8, #0x2d2e028                             
02d2e010: ldr     w8, [x8, #0x10]                            
02d2e014: ldr     w9, [x0, #0x10]                            .taskId
02d2e018: cmp     w8, w9                                     
02d2e01c: cset    w0, eq                                     
02d2e020: ldr     x30, [sp], #0x10                           
02d2e024: ret                                                
02d2e028: bl      #0x2b7105c                                 fn_2b7105c
## <OnTaskCompletedCallback>b__1() -> void
---- DailyTask.PopupDailyTask/<>c__DisplayClass20_0::<OnTaskCompletedCallback>b__1 0x2d2e02c
02d2e02c: str     x30, [sp, #-0x30]!                         
02d2e030: stp     x22, x21, [sp, #0x10]                      
02d2e034: stp     x20, x19, [sp, #0x20]                      
02d2e038: adrp    x20, #0x6630000                            
02d2e03c: mov     x19, x0                                    
02d2e040: ldrb    w8, [x20, #0xdc]                           
02d2e044: tbnz    w8, #0, #0x2d2e068                         
02d2e048: adrp    x0, #0x6264000                             
02d2e04c: ldr     x0, [x0, #0xf90]                           T:System.Action
02d2e050: bl      #0x2b70db0                                 fn_2b70db0
02d2e054: adrp    x0, #0x626a000                             
02d2e058: ldr     x0, [x0, #0x580]                           M:DailyTask.PopupDailyTask/<>c__DisplayClass20_0::<OnTaskCompletedCallback>b__2
02d2e05c: bl      #0x2b70db0                                 fn_2b70db0
02d2e060: mov     w8, #1                                     
02d2e064: strb    w8, [x20, #0xdc]                           
02d2e068: mov     x21, x19                                   
02d2e06c: ldr     x22, [x21, #0x20]!                         .<>9__2
02d2e070: ldur    x20, [x21, #-8]                            
02d2e074: cbnz    x22, #0x2d2e0b4                            
02d2e078: adrp    x8, #0x6264000                             
02d2e07c: ldr     x8, [x8, #0xf90]                           T:System.Action
02d2e080: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d2e084: bl      #0x2b7104c                                 fn_2b7104c
02d2e088: adrp    x8, #0x626a000                             
02d2e08c: mov     x1, x19                                    
02d2e090: mov     x3, xzr                                    
02d2e094: ldr     x8, [x8, #0x580]                           M:DailyTask.PopupDailyTask/<>c__DisplayClass20_0::<OnTaskCompletedCallback>b__2
02d2e098: mov     x22, x0                                    
02d2e09c: ldr     x2, [x8]                                   T:type56879(k15)
02d2e0a0: bl      #0x4d8ddbc                                 System.Action::.ctor
02d2e0a4: mov     x0, x21                                    
02d2e0a8: mov     x1, x22                                    
02d2e0ac: str     x22, [x19, #0x20]                          .<>9__2
02d2e0b0: bl      #0x2b70d54                                 fn_2b70d54
02d2e0b4: mov     x0, x20                                    
02d2e0b8: mov     x1, x22                                    
02d2e0bc: fmov    s0, #0.50000000                            
02d2e0c0: ldp     x20, x19, [sp, #0x20]                      
02d2e0c4: mov     x2, xzr                                    
02d2e0c8: ldp     x22, x21, [sp, #0x10]                      
02d2e0cc: ldr     x30, [sp], #0x30                           
02d2e0d0: b       #0x2cb91ec                                 Framework.MonoBehaviorExtension::InvokeDelay
## <OnTaskCompletedCallback>b__2() -> void
---- DailyTask.PopupDailyTask/<>c__DisplayClass20_0::<OnTaskCompletedCallback>b__2 0x2d2e0d4
02d2e0d4: stp     x30, x19, [sp, #-0x10]!                    
02d2e0d8: ldr     x8, [x0, #0x18]                            .<>4__this
02d2e0dc: cbz     x8, #0x2d2e10c                             
02d2e0e0: mov     x19, x0                                    
02d2e0e4: ldr     x0, [x8, #0x70]                            
02d2e0e8: cbz     x0, #0x2d2e10c                             
02d2e0ec: mov     w1, wzr                                    
02d2e0f0: mov     x2, xzr                                    
02d2e0f4: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d2e0f8: ldr     x8, [x19, #0x18]                           .<>4__this
02d2e0fc: cbz     x8, #0x2d2e10c                             
02d2e100: strb    wzr, [x8, #0x90]                           
02d2e104: ldp     x30, x19, [sp], #0x10                      
02d2e108: ret                                                
02d2e10c: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS DailyTask.PopupDailyTask/<>c__DisplayClass21_0 parent= object
#   field taskId                         int                                                off=0x10 attr=6 
## .ctor() -> void
---- DailyTask.PopupDailyTask/<>c__DisplayClass21_0::.ctor 0x2d2dd58
02d2dd58: mov     x1, xzr                                    
02d2dd5c: b       #0x4e53e9c                                 System.Object::.ctor
## <OnTaskProgressedCallback>b__0(DailyTask.DailyTaskItemUI n) -> bool
---- DailyTask.PopupDailyTask/<>c__DisplayClass21_0::<OnTaskProgressedCallback>b__0 0x2d2e110
02d2e110: str     x30, [sp, #-0x10]!                         
02d2e114: cbz     x1, #0x2d2e138                             
02d2e118: ldr     x8, [x1, #0x80]                            
02d2e11c: cbz     x8, #0x2d2e138                             
02d2e120: ldr     w8, [x8, #0x10]                            
02d2e124: ldr     w9, [x0, #0x10]                            .taskId
02d2e128: cmp     w8, w9                                     
02d2e12c: cset    w0, eq                                     
02d2e130: ldr     x30, [sp], #0x10                           
02d2e134: ret                                                
02d2e138: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS DailyTask.PopupDailyTask/<OnAllTasksCompletedCallback>d__22 parent= System.ValueType
#   field <>1__state                     int                                                off=0x10 attr=6 
#   field <>t__builder                   System.Runtime.CompilerServices.AsyncVoidMethodBuilder off=0x18 attr=6 
#   field <>4__this                      DailyTask.PopupDailyTask                           off=0x38 attr=6 
#   field <>u__1                         Cysharp.Threading.Tasks.UniTask/Awaiter            off=0x40 attr=1 
## MoveNext() -> void
---- DailyTask.PopupDailyTask/<OnAllTasksCompletedCallback>d__22::MoveNext 0x2d2e13c
02d2e13c: sub     sp, sp, #0x70                              
02d2e140: str     x30, [sp, #0x40]                           
02d2e144: stp     x22, x21, [sp, #0x50]                      
02d2e148: stp     x20, x19, [sp, #0x60]                      
02d2e14c: adrp    x20, #0x6630000                            
02d2e150: mov     x19, x0                                    
02d2e154: ldrb    w8, [x20, #0xdd]                           
02d2e158: tbnz    w8, #0, #0x2d2e1a0                         
02d2e15c: adrp    x0, #0x626a000                             
02d2e160: ldr     x0, [x0, #0x588]                           MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::AwaitUnsafeOnCompleted
02d2e164: bl      #0x2b70db0                                 fn_2b70db0
02d2e168: adrp    x0, #0x6265000                             
02d2e16c: ldr     x0, [x0, #0xfb0]                           T:type9979(k15)
02d2e170: bl      #0x2b70db0                                 fn_2b70db0
02d2e174: adrp    x0, #0x626a000                             
02d2e178: ldr     x0, [x0, #0x590]                           M:DailyTask.PopupDailyTask::<OnAllTasksCompletedCallback>b__22_0
02d2e17c: bl      #0x2b70db0                                 fn_2b70db0
02d2e180: adrp    x0, #0x626a000                             
02d2e184: ldr     x0, [x0, #0x598]                           MS:UIManager::ShowPopup
02d2e188: bl      #0x2b70db0                                 fn_2b70db0
02d2e18c: adrp    x0, #0x6266000                             
02d2e190: ldr     x0, [x0, #0xcc8]                           T:Cysharp.Threading.Tasks.UniTask
02d2e194: bl      #0x2b70db0                                 fn_2b70db0
02d2e198: mov     w8, #1                                     
02d2e19c: strb    w8, [x20, #0xdd]                           
02d2e1a0: ldr     w8, [x19]                                  
02d2e1a4: ldr     x20, [x19, #0x28]                          
02d2e1a8: stp     xzr, xzr, [sp, #0x20]                      
02d2e1ac: str     wzr, [sp, #0x18]                           
02d2e1b0: cbz     w8, #0x2d2e2cc                             
02d2e1b4: adrp    x8, #0x6265000                             
02d2e1b8: ldr     x8, [x8, #0xfb0]                           T:type9979(k15)
02d2e1bc: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02d2e1c0: bl      #0x2b7104c                                 fn_2b7104c
02d2e1c4: adrp    x8, #0x626a000                             
02d2e1c8: mov     x21, x0                                    
02d2e1cc: ldr     x8, [x8, #0x590]                           M:DailyTask.PopupDailyTask::<OnAllTasksCompletedCallback>b__22_0
02d2e1d0: ldr     x2, [x8]                                   T:type56879(k15)
02d2e1d4: mov     x1, x20                                    
02d2e1d8: mov     x3, xzr                                    
02d2e1dc: bl      #0x4932dc8                                 fn_4932dc8
02d2e1e0: adrp    x22, #0x6266000                            
02d2e1e4: ldr     x22, [x22, #0xcc8]                         T:Cysharp.Threading.Tasks.UniTask
02d2e1e8: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d2e1ec: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d2e1f0: cbnz    w8, #0x2d2e1f8                             
02d2e1f4: bl      #0x2b70f30                                 fn_2b70f30
02d2e1f8: mov     x0, x21                                    
02d2e1fc: mov     w1, #8                                     
02d2e200: mov     x2, xzr                                    
02d2e204: mov     w3, wzr                                    
02d2e208: mov     x4, xzr                                    
02d2e20c: bl      #0x5449e4c                                 Cysharp.Threading.Tasks.UniTask::WaitUntil
02d2e210: stp     x0, x1, [sp, #0x30]                        
02d2e214: add     x0, sp, #0x30                              
02d2e218: mov     x1, xzr                                    
02d2e21c: bl      #0x2b70d54                                 fn_2b70d54
02d2e220: adrp    x21, #0x662f000                            
02d2e224: ldr     q0, [sp, #0x30]                            
02d2e228: ldrb    w8, [x21, #0xbdc]                          
02d2e22c: str     q0, [sp, #0x20]                            
02d2e230: cbnz    w8, #0x2d2e248                             
02d2e234: adrp    x0, #0x6266000                             
02d2e238: ldr     x0, [x0, #0xcc8]                           T:Cysharp.Threading.Tasks.UniTask
02d2e23c: bl      #0x2b70db0                                 fn_2b70db0
02d2e240: mov     w8, #1                                     
02d2e244: strb    w8, [x21, #0xbdc]                          
02d2e248: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d2e24c: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d2e250: cbnz    w8, #0x2d2e258                             
02d2e254: bl      #0x2b70f30                                 fn_2b70f30
02d2e258: adrp    x21, #0x662f000                            
02d2e25c: ldrb    w8, [x21, #0xbdd]                          
02d2e260: cbnz    w8, #0x2d2e278                             
02d2e264: adrp    x0, #0x6266000                             
02d2e268: ldr     x0, [x0, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02d2e26c: bl      #0x2b70db0                                 fn_2b70db0
02d2e270: mov     w8, #1                                     
02d2e274: strb    w8, [x21, #0xbdd]                          
02d2e278: ldr     x21, [sp, #0x20]                           
02d2e27c: cbz     x21, #0x2d2e304                            
02d2e280: adrp    x10, #0x6266000                            
02d2e284: ldr     x8, [x21]                                  &2b706c4(=eb01011ff9400808)
02d2e288: ldr     x10, [x10, #0xcd0]                         T:Cysharp.Threading.Tasks.IUniTaskSource
02d2e28c: ldrh    w22, [sp, #0x28]                           
02d2e290: ldrh    w9, [x8, #0x12e]                           
02d2e294: ldr     x1, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d2e298: cbz     x9, #0x2d2e2bc                             
02d2e29c: ldr     x10, [x8, #0xb0]                           T:type56715(k15)
02d2e2a0: add     x10, x10, #8                               &6266008
02d2e2a4: ldur    x11, [x10, #-8]                            
02d2e2a8: cmp     x11, x1                                    
02d2e2ac: b.eq    #0x2d2e2e4                                 
02d2e2b0: subs    x9, x9, #1                                 
02d2e2b4: add     x10, x10, #0x10                            &6266010
02d2e2b8: b.ne    #0x2d2e2a4                                 
02d2e2bc: mov     x0, x21                                    
02d2e2c0: mov     w2, wzr                                    
02d2e2c4: bl      #0x2baa05c                                 fn_2baa05c
02d2e2c8: b       #0x2d2e2f0                                 
02d2e2cc: ldr     q0, [x19, #0x30]                           
02d2e2d0: mov     w8, #-1                                    
02d2e2d4: stp     xzr, xzr, [x19, #0x30]                     
02d2e2d8: str     w8, [x19]                                  
02d2e2dc: str     q0, [sp, #0x20]                            
02d2e2e0: b       #0x2d2e304                                 
02d2e2e4: ldrsw   x9, [x10]                                  
02d2e2e8: add     x8, x8, x9, lsl #4                         &626a000
02d2e2ec: add     x0, x8, #0x138                             &626a138
02d2e2f0: ldp     x8, x2, [x0]                               
02d2e2f4: mov     x0, x21                                    
02d2e2f8: mov     w1, w22                                    
02d2e2fc: blr     x8                                         
02d2e300: cbz     w0, #0x2d2e3ec                             
02d2e304: adrp    x21, #0x662f000                            
02d2e308: ldrb    w8, [x21, #0xbde]                          
02d2e30c: cbnz    w8, #0x2d2e324                             
02d2e310: adrp    x0, #0x6266000                             
02d2e314: ldr     x0, [x0, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02d2e318: bl      #0x2b70db0                                 fn_2b70db0
02d2e31c: mov     w8, #1                                     
02d2e320: strb    w8, [x21, #0xbde]                          
02d2e324: ldr     x21, [sp, #0x20]                           
02d2e328: cbz     x21, #0x2d2e398                            
02d2e32c: adrp    x10, #0x6266000                            
02d2e330: ldr     x8, [x21]                                  &2b706c4(=eb01011ff9400808)
02d2e334: ldr     x10, [x10, #0xcd0]                         T:Cysharp.Threading.Tasks.IUniTaskSource
02d2e338: ldrh    w22, [sp, #0x28]                           
02d2e33c: ldrh    w9, [x8, #0x12e]                           
02d2e340: ldr     x1, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d2e344: cbz     x9, #0x2d2e368                             
02d2e348: ldr     x10, [x8, #0xb0]                           T:type56715(k15)
02d2e34c: add     x10, x10, #8                               &6266008
02d2e350: ldur    x11, [x10, #-8]                            
02d2e354: cmp     x11, x1                                    
02d2e358: b.eq    #0x2d2e378                                 
02d2e35c: subs    x9, x9, #1                                 
02d2e360: add     x10, x10, #0x10                            &6266010
02d2e364: b.ne    #0x2d2e350                                 
02d2e368: mov     x0, x21                                    
02d2e36c: mov     w2, #2                                     
02d2e370: bl      #0x2baa05c                                 fn_2baa05c
02d2e374: b       #0x2d2e388                                 
02d2e378: ldr     w9, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d2e37c: add     w9, w9, #2                                 
02d2e380: add     x8, x8, w9, sxtw #4                        &626a000
02d2e384: add     x0, x8, #0x138                             &626a138
02d2e388: ldp     x8, x2, [x0]                               
02d2e38c: mov     x0, x21                                    
02d2e390: mov     w1, w22                                    
02d2e394: blr     x8                                         
02d2e398: cbz     x20, #0x2d2e424                            
02d2e39c: ldr     x8, [x20]                                  
02d2e3a0: ldp     x9, x1, [x8, #0x198]                       
02d2e3a4: mov     x0, x20                                    
02d2e3a8: blr     x9                                         
02d2e3ac: ldr     x0, [x20, #0x30]                           
02d2e3b0: cbz     x0, #0x2d2e428                             
02d2e3b4: adrp    x8, #0x626a000                             
02d2e3b8: ldr     x8, [x8, #0x598]                           MS:UIManager::ShowPopup
02d2e3bc: ldr     x1, [x8]                                   T:type56879(k15)
02d2e3c0: bl      #0x33fbfac                                 fn_33fbfac
02d2e3c4: mov     w8, #-2                                    
02d2e3c8: mov     x1, xzr                                    
02d2e3cc: str     w8, [x19], #8                              
02d2e3d0: mov     x0, x19                                    
02d2e3d4: bl      #0x4d43b50                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::SetResult
02d2e3d8: ldp     x20, x19, [sp, #0x60]                      
02d2e3dc: ldr     x30, [sp, #0x40]                           
02d2e3e0: ldp     x22, x21, [sp, #0x50]                      
02d2e3e4: add     sp, sp, #0x70                              
02d2e3e8: ret                                                
02d2e3ec: ldr     q0, [sp, #0x20]                            
02d2e3f0: str     wzr, [x19]                                 
02d2e3f4: str     q0, [x19, #0x30]                           
02d2e3f8: add     x0, x19, #0x30                             
02d2e3fc: mov     x1, xzr                                    
02d2e400: bl      #0x2b70d54                                 fn_2b70d54
02d2e404: adrp    x8, #0x626a000                             
02d2e408: ldr     x8, [x8, #0x588]                           MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::AwaitUnsafeOnCompleted
02d2e40c: ldr     x3, [x8]                                   T:type56879(k15)
02d2e410: add     x0, x19, #8                                
02d2e414: add     x1, sp, #0x20                              
02d2e418: mov     x2, x19                                    
02d2e41c: bl      #0x30c40b8                                 fn_30c40b8
02d2e420: b       #0x2d2e3d8                                 
02d2e424: bl      #0x2b7105c                                 fn_2b7105c
02d2e428: bl      #0x2b7105c                                 fn_2b7105c
02d2e42c: b       #0x2d2e458                                 
02d2e430: b       #0x2d2e458                                 
02d2e434: b       #0x2d2e458                                 
02d2e438: b       #0x2d2e458                                 
02d2e43c: b       #0x2d2e458                                 
02d2e440: b       #0x2d2e458                                 
02d2e444: b       #0x2d2e458                                 
02d2e448: b       #0x2d2e458                                 
02d2e44c: b       #0x2d2e458                                 
02d2e450: mov     x20, x0                                    
02d2e454: b       #0x2d2e45c                                 
02d2e458: mov     x20, x0                                    
02d2e45c: cmp     w1, #1                                     
02d2e460: b.ne    #0x2d2e554                                 
02d2e464: mov     x0, x20                                    
02d2e468: bl      #0x5e90260                                 fn_5e90260
02d2e46c: mov     x20, x0                                    
02d2e470: adrp    x0, #0x6263000                             
02d2e474: ldr     x0, [x0, #0xae0]                           T:System.Exception
02d2e478: bl      #0x2b70dc4                                 fn_2b70dc4
02d2e47c: ldr     x8, [x20]                                  
02d2e480: ldr     x1, [x8]                                   T:type56879(k15)
02d2e484: bl      #0x2b71464                                 fn_2b71464
02d2e488: tbz     w0, #0, #0x2d2e508                         
02d2e48c: ldrsw   x21, [sp, #0x18]                           
02d2e490: ldr     x20, [x20]                                 
02d2e494: add     x8, sp, #8                                 
02d2e498: str     x20, [x8, x21, lsl #3]                     
02d2e49c: add     w8, w21, #1                                
02d2e4a0: str     w8, [sp, #0x18]                            
02d2e4a4: bl      #0x5e90270                                 fn_5e90270
02d2e4a8: cbz     x20, #0x2d2e52c                            
02d2e4ac: ldr     x8, [x20]                                  
02d2e4b0: ldp     x9, x1, [x8, #0x188]                       
02d2e4b4: mov     x0, x20                                    
02d2e4b8: blr     x9                                         
02d2e4bc: mov     x20, x0                                    
02d2e4c0: adrp    x0, #0x626a000                             
02d2e4c4: ldr     x0, [x0, #0x5a0]                           S:'Error while waiting for collecting star: '
02d2e4c8: bl      #0x2b70dc4                                 fn_2b70dc4
02d2e4cc: mov     x1, x20                                    
02d2e4d0: mov     x2, xzr                                    
02d2e4d4: bl      #0x4c9c514                                 System.String::Concat
02d2e4d8: mov     x20, x0                                    
02d2e4dc: adrp    x0, #0x6263000                             
02d2e4e0: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02d2e4e4: bl      #0x2b70dc4                                 fn_2b70dc4
02d2e4e8: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d2e4ec: cbnz    w8, #0x2d2e4f4                             
02d2e4f0: bl      #0x2b70f30                                 fn_2b70f30
02d2e4f4: mov     x0, x20                                    
02d2e4f8: mov     x1, xzr                                    
02d2e4fc: bl      #0x5af2840                                 UnityEngine.Debug::LogError
02d2e500: str     w21, [sp, #0x18]                           
02d2e504: b       #0x2d2e3c4                                 
02d2e508: mov     w0, #8                                     
02d2e50c: bl      #0x5e90290                                 fn_5e90290
02d2e510: ldr     x8, [x20]                                  
02d2e514: str     x8, [x0]                                   
02d2e518: adrp    x1, #0x5e96000                             
02d2e51c: add     x1, x1, #0x758                             &5e96758
02d2e520: mov     x2, xzr                                    
02d2e524: bl      #0x5e902a0                                 fn_5e902a0
02d2e528: b       #0x2d2e5e4                                 
02d2e52c: bl      #0x2b7105c                                 fn_2b7105c
02d2e530: b       #0x2d2e550                                 
02d2e534: b       #0x2d2e550                                 
02d2e538: b       #0x2d2e550                                 
02d2e53c: mov     x21, x1                                    
02d2e540: mov     x20, x0                                    
02d2e544: bl      #0x5e90270                                 fn_5e90270
02d2e548: mov     w1, w21                                    
02d2e54c: b       #0x2d2e554                                 
02d2e550: mov     x20, x0                                    
02d2e554: mov     w8, #1                                     
02d2e558: cmp     w1, w8                                     
02d2e55c: b.ne    #0x2d2e5ec                                 
02d2e560: mov     x0, x20                                    
02d2e564: bl      #0x5e90260                                 fn_5e90260
02d2e568: mov     x20, x0                                    
02d2e56c: adrp    x0, #0x6263000                             
02d2e570: ldr     x0, [x0, #0xae0]                           T:System.Exception
02d2e574: bl      #0x2b70dc4                                 fn_2b70dc4
02d2e578: ldr     x8, [x20]                                  
02d2e57c: ldr     x1, [x8]                                   T:type56879(k15)
02d2e580: bl      #0x2b71464                                 fn_2b71464
02d2e584: tbz     w0, #0, #0x2d2e5c4                         
02d2e588: ldrsw   x21, [sp, #0x18]                           
02d2e58c: ldr     x20, [x20]                                 
02d2e590: add     x8, sp, #8                                 
02d2e594: str     x20, [x8, x21, lsl #3]                     
02d2e598: add     w8, w21, #1                                
02d2e59c: str     w8, [sp, #0x18]                            
02d2e5a0: bl      #0x5e90270                                 fn_5e90270
02d2e5a4: mov     w8, #-2                                    
02d2e5a8: mov     x1, x20                                    
02d2e5ac: mov     x2, xzr                                    
02d2e5b0: str     w8, [x19], #8                              
02d2e5b4: mov     x0, x19                                    
02d2e5b8: bl      #0x4d43cc0                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::SetException
02d2e5bc: str     w21, [sp, #0x18]                           
02d2e5c0: b       #0x2d2e3d8                                 
02d2e5c4: mov     w0, #8                                     
02d2e5c8: bl      #0x5e90290                                 fn_5e90290
02d2e5cc: ldr     x8, [x20]                                  
02d2e5d0: str     x8, [x0]                                   
02d2e5d4: adrp    x1, #0x5e96000                             
02d2e5d8: add     x1, x1, #0x758                             &5e96758
02d2e5dc: mov     x2, xzr                                    
02d2e5e0: bl      #0x5e902a0                                 fn_5e902a0
02d2e5e4: mov     x20, x0                                    
02d2e5e8: bl      #0x5e90270                                 fn_5e90270
02d2e5ec: mov     x0, x20                                    
02d2e5f0: bl      #0x2c6051c                                 fn_2c6051c
02d2e5f4: bl      #0x27369b8                                 fn_27369b8
## SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine stateMachine) -> void
---- DailyTask.PopupDailyTask/<OnAllTasksCompletedCallback>d__22::SetStateMachine 0x2d2e5f8
02d2e5f8: add     x0, x0, #8                                 
02d2e5fc: mov     x2, xzr                                    
02d2e600: b       #0x4d43a8c                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::SetStateMachine
#### CLASS DailyTask.PopupDailyTask parent= PopupBase
#   field _itemPrefab                    DailyTask.DailyTaskItemUI                          off=0x38 attr=1 SerializeField
#   field _contentRect                   UnityEngine.RectTransform                          off=0x40 attr=1 SerializeField
#   field _scrollRect                    UnityEngine.UI.ScrollRect                          off=0x48 attr=1 SerializeField
#   field _panel                         UnityEngine.RectTransform                          off=0x50 attr=1 SerializeField
#   field _btnClose                      UnityEngine.UI.Button                              off=0x58 attr=1 SerializeField
#   field _btnClose2                     UnityEngine.UI.Button                              off=0x60 attr=1 SerializeField
#   field _collectingStar                JobGame.CollectingCoin                             off=0x68 attr=1 SerializeField
#   field _blockObject                   UnityEngine.GameObject                             off=0x70 attr=1 SerializeField
#   field _notiObject                    UnityEngine.GameObject                             off=0x78 attr=1 SerializeField
#   field _items                         System.Collections.Generic.List`1<DailyTask.DailyTaskItemUI> off=0x80 attr=1 SerializeField
#   field _rewardProgressBar             DreamHouse.ProgressBar                             off=0x88 attr=1 HeaderAttribute,SerializeField
#   field _isCollecting                  bool                                               off=0x90 attr=1 
#   field _actionHide                    System.Action                                      off=0x98 attr=1 
#   field _dailyTaskController           DailyTask.DailyTaskController                      off=0xa0 attr=1 
## OnDestroy() -> void
---- DailyTask.PopupDailyTask::OnDestroy 0x2d2cf34
02d2cf34: str     x30, [sp, #-0x30]!                         
02d2cf38: stp     x22, x21, [sp, #0x10]                      
02d2cf3c: stp     x20, x19, [sp, #0x20]                      
02d2cf40: adrp    x20, #0x6630000                            
02d2cf44: adrp    x22, #0x6263000                            
02d2cf48: mov     x19, x0                                    
02d2cf4c: ldrb    w8, [x20, #0xd2]                           
02d2cf50: ldr     x22, [x22, #0x918]                         T:UnityEngine.Object
02d2cf54: tbnz    w8, #0, #0x2d2cfb4                         
02d2cf58: adrp    x0, #0x6263000                             
02d2cf5c: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d2cf60: bl      #0x2b70db0                                 fn_2b70db0
02d2cf64: adrp    x0, #0x626a000                             
02d2cf68: ldr     x0, [x0, #0x4c0]                           M:DailyTask.PopupDailyTask::OnAllTasksCompletedCallback
02d2cf6c: bl      #0x2b70db0                                 fn_2b70db0
02d2cf70: adrp    x0, #0x626a000                             
02d2cf74: ldr     x0, [x0, #0x4c8]                           M:DailyTask.PopupDailyTask::OnButtonCloseClicked
02d2cf78: bl      #0x2b70db0                                 fn_2b70db0
02d2cf7c: adrp    x0, #0x626a000                             
02d2cf80: ldr     x0, [x0, #0x4d0]                           M:DailyTask.PopupDailyTask::OnTaskCompletedCallback
02d2cf84: bl      #0x2b70db0                                 fn_2b70db0
02d2cf88: adrp    x0, #0x626a000                             
02d2cf8c: ldr     x0, [x0, #0x4d8]                           M:DailyTask.PopupDailyTask::OnTaskProgressedCallback
02d2cf90: bl      #0x2b70db0                                 fn_2b70db0
02d2cf94: adrp    x0, #0x6269000                             
02d2cf98: ldr     x0, [x0, #0xa68]                           T:type19683(k15)
02d2cf9c: bl      #0x2b70db0                                 fn_2b70db0
02d2cfa0: adrp    x0, #0x6265000                             
02d2cfa4: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d2cfa8: bl      #0x2b70db0                                 fn_2b70db0
02d2cfac: mov     w8, #1                                     
02d2cfb0: strb    w8, [x20, #0xd2]                           
02d2cfb4: ldr     x0, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d2cfb8: ldr     x20, [x19, #0x58]                          ._btnClose
02d2cfbc: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02d2cfc0: cbnz    w8, #0x2d2cfc8                             
02d2cfc4: bl      #0x2b70f30                                 fn_2b70f30
02d2cfc8: mov     x0, x20                                    
02d2cfcc: mov     x1, xzr                                    
02d2cfd0: mov     x2, xzr                                    
02d2cfd4: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d2cfd8: tbz     w0, #0, #0x2d2d028                         
02d2cfdc: ldr     x8, [x19, #0x58]                           ._btnClose
02d2cfe0: cbz     x8, #0x2d2d198                             
02d2cfe4: adrp    x9, #0x6265000                             
02d2cfe8: ldr     x9, [x9, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d2cfec: ldr     x20, [x8, #0x100]                          
02d2cff0: ldr     x0, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02d2cff4: bl      #0x2b7104c                                 fn_2b7104c
02d2cff8: adrp    x8, #0x626a000                             
02d2cffc: mov     x1, x19                                    
02d2d000: mov     x3, xzr                                    
02d2d004: ldr     x8, [x8, #0x4c8]                           M:DailyTask.PopupDailyTask::OnButtonCloseClicked
02d2d008: mov     x21, x0                                    
02d2d00c: ldr     x2, [x8]                                   T:type56879(k15)
02d2d010: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d2d014: cbz     x20, #0x2d2d198                            
02d2d018: mov     x0, x20                                    
02d2d01c: mov     x1, x21                                    
02d2d020: mov     x2, xzr                                    
02d2d024: bl      #0x5b4d13c                                 UnityEngine.Events.UnityEvent::RemoveListener
02d2d028: ldr     x0, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d2d02c: ldr     x20, [x19, #0x60]                          ._btnClose2
02d2d030: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02d2d034: cbnz    w8, #0x2d2d03c                             
02d2d038: bl      #0x2b70f30                                 fn_2b70f30
02d2d03c: mov     x0, x20                                    
02d2d040: mov     x1, xzr                                    
02d2d044: mov     x2, xzr                                    
02d2d048: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d2d04c: tbz     w0, #0, #0x2d2d09c                         
02d2d050: ldr     x8, [x19, #0x60]                           ._btnClose2
02d2d054: cbz     x8, #0x2d2d198                             
02d2d058: adrp    x9, #0x6265000                             
02d2d05c: ldr     x9, [x9, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d2d060: ldr     x20, [x8, #0x100]                          M:Decor.DecorController/<>c__DisplayClass11_0::<OnOptionSelected>b__0
02d2d064: ldr     x0, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02d2d068: bl      #0x2b7104c                                 fn_2b7104c
02d2d06c: adrp    x8, #0x626a000                             
02d2d070: mov     x1, x19                                    
02d2d074: mov     x3, xzr                                    
02d2d078: ldr     x8, [x8, #0x4c8]                           M:DailyTask.PopupDailyTask::OnButtonCloseClicked
02d2d07c: mov     x21, x0                                    
02d2d080: ldr     x2, [x8]                                   T:type56879(k15)
02d2d084: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d2d088: cbz     x20, #0x2d2d198                            
02d2d08c: mov     x0, x20                                    
02d2d090: mov     x1, x21                                    
02d2d094: mov     x2, xzr                                    
02d2d098: bl      #0x5b4d13c                                 UnityEngine.Events.UnityEvent::RemoveListener
02d2d09c: ldr     x0, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d2d0a0: ldr     x20, [x19, #0xa0]                          ._dailyTaskController
02d2d0a4: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02d2d0a8: cbnz    w8, #0x2d2d0b0                             
02d2d0ac: bl      #0x2b70f30                                 fn_2b70f30
02d2d0b0: mov     x0, x20                                    
02d2d0b4: mov     x1, xzr                                    
02d2d0b8: mov     x2, xzr                                    
02d2d0bc: bl      #0x5b37d84                                 UnityEngine.Object::op_Equality
02d2d0c0: tbz     w0, #0, #0x2d2d0d4                         
02d2d0c4: ldp     x20, x19, [sp, #0x20]                      
02d2d0c8: ldp     x22, x21, [sp, #0x10]                      
02d2d0cc: ldr     x30, [sp], #0x30                           
02d2d0d0: ret                                                
02d2d0d4: adrp    x22, #0x6269000                            
02d2d0d8: ldr     x22, [x22, #0xa68]                         T:type19683(k15)
02d2d0dc: ldr     x20, [x19, #0xa0]                          ._dailyTaskController
02d2d0e0: ldr     x0, [x22]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d2d0e4: bl      #0x2b7104c                                 fn_2b7104c
02d2d0e8: adrp    x8, #0x626a000                             
02d2d0ec: mov     x1, x19                                    
02d2d0f0: mov     x3, xzr                                    
02d2d0f4: ldr     x8, [x8, #0x4d0]                           M:DailyTask.PopupDailyTask::OnTaskCompletedCallback
02d2d0f8: mov     x21, x0                                    
02d2d0fc: ldr     x2, [x8]                                   T:type56879(k15)
02d2d100: bl      #0x3edf86c                                 fn_3edf86c
02d2d104: cbz     x20, #0x2d2d198                            
02d2d108: mov     x0, x20                                    
02d2d10c: mov     x1, x21                                    
02d2d110: bl      #0x2d29d0c                                 DailyTask.DailyTaskController::remove_OnTaskCompleted
02d2d114: ldr     x0, [x22]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d2d118: ldr     x20, [x19, #0xa0]                          ._dailyTaskController
02d2d11c: bl      #0x2b7104c                                 fn_2b7104c
02d2d120: adrp    x8, #0x626a000                             
02d2d124: mov     x1, x19                                    
02d2d128: mov     x3, xzr                                    
02d2d12c: ldr     x8, [x8, #0x4d8]                           M:DailyTask.PopupDailyTask::OnTaskProgressedCallback
02d2d130: mov     x21, x0                                    
02d2d134: ldr     x2, [x8]                                   T:type56879(k15)
02d2d138: bl      #0x3edf86c                                 fn_3edf86c
02d2d13c: cbz     x20, #0x2d2d198                            
02d2d140: mov     x0, x20                                    
02d2d144: mov     x1, x21                                    
02d2d148: bl      #0x2d29e6c                                 DailyTask.DailyTaskController::remove_OnTaskProgressed
02d2d14c: adrp    x8, #0x6265000                             
02d2d150: ldr     x8, [x8, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d2d154: ldr     x20, [x19, #0xa0]                          ._dailyTaskController
02d2d158: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02d2d15c: bl      #0x2b7104c                                 fn_2b7104c
02d2d160: adrp    x8, #0x626a000                             
02d2d164: mov     x1, x19                                    
02d2d168: mov     x3, xzr                                    
02d2d16c: ldr     x8, [x8, #0x4c0]                           M:DailyTask.PopupDailyTask::OnAllTasksCompletedCallback
02d2d170: mov     x21, x0                                    
02d2d174: ldr     x2, [x8]                                   T:type56879(k15)
02d2d178: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d2d17c: cbz     x20, #0x2d2d198                            
02d2d180: mov     x0, x20                                    
02d2d184: mov     x1, x21                                    
02d2d188: ldp     x20, x19, [sp, #0x20]                      
02d2d18c: ldp     x22, x21, [sp, #0x10]                      
02d2d190: ldr     x30, [sp], #0x30                           
02d2d194: b       #0x2d29bc0                                 DailyTask.DailyTaskController::remove_OnAllTasksCompleted
02d2d198: bl      #0x2b7105c                                 fn_2b7105c
## OnInit(UIManager uiManager) -> void
---- DailyTask.PopupDailyTask::OnInit 0x2d2d19c
02d2d19c: sub     sp, sp, #0xa0                              
02d2d1a0: stp     x29, x30, [sp, #0x40]                      
02d2d1a4: stp     x28, x27, [sp, #0x50]                      
02d2d1a8: stp     x26, x25, [sp, #0x60]                      
02d2d1ac: stp     x24, x23, [sp, #0x70]                      
02d2d1b0: stp     x22, x21, [sp, #0x80]                      
02d2d1b4: stp     x20, x19, [sp, #0x90]                      
02d2d1b8: adrp    x21, #0x6630000                            
02d2d1bc: mov     x20, x1                                    
02d2d1c0: mov     x19, x0                                    
02d2d1c4: ldrb    w8, [x21, #0xd3]                           
02d2d1c8: tbnz    w8, #0, #0x2d2d27c                         
02d2d1cc: adrp    x0, #0x626a000                             
02d2d1d0: ldr     x0, [x0, #0x2d8]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d2d1d4: bl      #0x2b70db0                                 fn_2b70db0
02d2d1d8: adrp    x0, #0x626a000                             
02d2d1dc: ldr     x0, [x0, #0x2e0]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d2d1e0: bl      #0x2b70db0                                 fn_2b70db0
02d2d1e4: adrp    x0, #0x626a000                             
02d2d1e8: ldr     x0, [x0, #0x2e8]                           MS:System.Collections.Generic.List`1/Enumerator::get_Current
02d2d1ec: bl      #0x2b70db0                                 fn_2b70db0
02d2d1f0: adrp    x0, #0x626a000                             
02d2d1f4: ldr     x0, [x0, #0x4e0]                           MS:System.Collections.Generic.List`1::Add
02d2d1f8: bl      #0x2b70db0                                 fn_2b70db0
02d2d1fc: adrp    x0, #0x626a000                             
02d2d200: ldr     x0, [x0, #0x2f0]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d2d204: bl      #0x2b70db0                                 fn_2b70db0
02d2d208: adrp    x0, #0x6267000                             
02d2d20c: ldr     x0, [x0, #0xbb0]                           MS:MonoSingleton`1::get_Instance
02d2d210: bl      #0x2b70db0                                 fn_2b70db0
02d2d214: adrp    x0, #0x626a000                             
02d2d218: ldr     x0, [x0, #0x4e8]                           MS:UnityEngine.Object::Instantiate
02d2d21c: bl      #0x2b70db0                                 fn_2b70db0
02d2d220: adrp    x0, #0x6263000                             
02d2d224: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d2d228: bl      #0x2b70db0                                 fn_2b70db0
02d2d22c: adrp    x0, #0x626a000                             
02d2d230: ldr     x0, [x0, #0x4c0]                           M:DailyTask.PopupDailyTask::OnAllTasksCompletedCallback
02d2d234: bl      #0x2b70db0                                 fn_2b70db0
02d2d238: adrp    x0, #0x626a000                             
02d2d23c: ldr     x0, [x0, #0x4c8]                           M:DailyTask.PopupDailyTask::OnButtonCloseClicked
02d2d240: bl      #0x2b70db0                                 fn_2b70db0
02d2d244: adrp    x0, #0x626a000                             
02d2d248: ldr     x0, [x0, #0x4d0]                           M:DailyTask.PopupDailyTask::OnTaskCompletedCallback
02d2d24c: bl      #0x2b70db0                                 fn_2b70db0
02d2d250: adrp    x0, #0x626a000                             
02d2d254: ldr     x0, [x0, #0x4d8]                           M:DailyTask.PopupDailyTask::OnTaskProgressedCallback
02d2d258: bl      #0x2b70db0                                 fn_2b70db0
02d2d25c: adrp    x0, #0x6269000                             
02d2d260: ldr     x0, [x0, #0xa68]                           T:type19683(k15)
02d2d264: bl      #0x2b70db0                                 fn_2b70db0
02d2d268: adrp    x0, #0x6265000                             
02d2d26c: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d2d270: bl      #0x2b70db0                                 fn_2b70db0
02d2d274: mov     w8, #1                                     
02d2d278: strb    w8, [x21, #0xd3]                           
02d2d27c: mov     x0, x19                                    
02d2d280: mov     x1, x20                                    
02d2d284: mov     x2, xzr                                    
02d2d288: stp     xzr, xzr, [sp, #0x20]                      
02d2d28c: str     xzr, [sp, #0x30]                           
02d2d290: bl      #0x2cdd3c4                                 UIBase::OnInit
02d2d294: ldr     x0, [x19, #0x70]                           ._blockObject
02d2d298: cbz     x0, #0x2d2d5b0                             
02d2d29c: adrp    x20, #0x6267000                            
02d2d2a0: adrp    x23, #0x6269000                            
02d2d2a4: adrp    x22, #0x626a000                            
02d2d2a8: ldr     x20, [x20, #0xbb0]                         MS:MonoSingleton`1::get_Instance
02d2d2ac: ldr     x23, [x23, #0xa68]                         T:type19683(k15)
02d2d2b0: ldr     x22, [x22, #0x4d0]                         M:DailyTask.PopupDailyTask::OnTaskCompletedCallback
02d2d2b4: mov     w1, wzr                                    
02d2d2b8: mov     x2, xzr                                    
02d2d2bc: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d2d2c0: ldr     x0, [x20]                                  S:'didu'
02d2d2c4: bl      #0x3769600                                 fn_3769600
02d2d2c8: mov     x20, x19                                   
02d2d2cc: mov     x1, x0                                     
02d2d2d0: str     x0, [x20, #0xa0]!                          ._dailyTaskController
02d2d2d4: mov     x0, x20                                    
02d2d2d8: bl      #0x2b70d54                                 fn_2b70d54
02d2d2dc: ldr     x0, [x23]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d2d2e0: ldr     x21, [x20]                                 S:'didu'
02d2d2e4: bl      #0x2b7104c                                 fn_2b7104c
02d2d2e8: ldr     x2, [x22]                                  T:type56879(k15)
02d2d2ec: mov     x1, x19                                    
02d2d2f0: mov     x3, xzr                                    
02d2d2f4: mov     x22, x0                                    
02d2d2f8: bl      #0x3edf86c                                 fn_3edf86c
02d2d2fc: cbz     x21, #0x2d2d5b0                            
02d2d300: adrp    x24, #0x626a000                            
02d2d304: mov     x0, x21                                    
02d2d308: mov     x1, x22                                    
02d2d30c: ldr     x24, [x24, #0x4d8]                         M:DailyTask.PopupDailyTask::OnTaskProgressedCallback
02d2d310: bl      #0x2d29c5c                                 DailyTask.DailyTaskController::add_OnTaskCompleted
02d2d314: ldr     x0, [x23]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d2d318: ldr     x21, [x19, #0xa0]                          ._dailyTaskController
02d2d31c: bl      #0x2b7104c                                 fn_2b7104c
02d2d320: ldr     x2, [x24]                                  T:type56879(k15)
02d2d324: mov     x1, x19                                    
02d2d328: mov     x3, xzr                                    
02d2d32c: mov     x22, x0                                    
02d2d330: bl      #0x3edf86c                                 fn_3edf86c
02d2d334: cbz     x21, #0x2d2d5b0                            
02d2d338: adrp    x23, #0x6265000                            
02d2d33c: adrp    x24, #0x626a000                            
02d2d340: mov     x0, x21                                    
02d2d344: ldr     x23, [x23, #0x3f0]                         T:UnityEngine.Events.UnityAction
02d2d348: ldr     x24, [x24, #0x4c0]                         M:DailyTask.PopupDailyTask::OnAllTasksCompletedCallback
02d2d34c: mov     x1, x22                                    
02d2d350: bl      #0x2d29dbc                                 DailyTask.DailyTaskController::add_OnTaskProgressed
02d2d354: ldr     x0, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d2d358: ldr     x21, [x19, #0xa0]                          ._dailyTaskController
02d2d35c: bl      #0x2b7104c                                 fn_2b7104c
02d2d360: ldr     x2, [x24]                                  T:type56879(k15)
02d2d364: mov     x1, x19                                    
02d2d368: mov     x3, xzr                                    
02d2d36c: mov     x22, x0                                    
02d2d370: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d2d374: cbz     x21, #0x2d2d5b0                            
02d2d378: mov     x0, x21                                    
02d2d37c: mov     x1, x22                                    
02d2d380: bl      #0x2d29b24                                 DailyTask.DailyTaskController::add_OnAllTasksCompleted
02d2d384: ldr     x21, [x19, #0x88]                          ._rewardProgressBar
02d2d388: cbz     x21, #0x2d2d5b0                            
02d2d38c: mov     w8, #0x64                                  
02d2d390: mov     x0, x21                                    
02d2d394: mov     w1, #1                                     
02d2d398: str     w8, [x21, #0x30]                           
02d2d39c: bl      #0x2d1c4c0                                 DreamHouse.ProgressBar::SetActive
02d2d3a0: mov     x0, x21                                    
02d2d3a4: mov     w1, wzr                                    
02d2d3a8: bl      #0x2d1c528                                 DreamHouse.ProgressBar::SetProgressValue
02d2d3ac: ldr     x8, [x19, #0x58]                           ._btnClose
02d2d3b0: cbz     x8, #0x2d2d5b0                             
02d2d3b4: adrp    x24, #0x626a000                            
02d2d3b8: ldr     x24, [x24, #0x4c8]                         M:DailyTask.PopupDailyTask::OnButtonCloseClicked
02d2d3bc: ldr     x0, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d2d3c0: ldr     x21, [x8, #0x100]                          
02d2d3c4: bl      #0x2b7104c                                 fn_2b7104c
02d2d3c8: ldr     x2, [x24]                                  T:type56879(k15)
02d2d3cc: mov     x1, x19                                    
02d2d3d0: mov     x3, xzr                                    
02d2d3d4: mov     x22, x0                                    
02d2d3d8: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d2d3dc: cbz     x21, #0x2d2d5b0                            
02d2d3e0: mov     x0, x21                                    
02d2d3e4: mov     x1, x22                                    
02d2d3e8: mov     x2, xzr                                    
02d2d3ec: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d2d3f0: ldr     x8, [x19, #0x60]                           ._btnClose2
02d2d3f4: cbz     x8, #0x2d2d5b0                             
02d2d3f8: ldr     x0, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d2d3fc: ldr     x21, [x8, #0x100]                          
02d2d400: bl      #0x2b7104c                                 fn_2b7104c
02d2d404: ldr     x2, [x24]                                  T:type56879(k15)
02d2d408: mov     x1, x19                                    
02d2d40c: mov     x3, xzr                                    
02d2d410: mov     x22, x0                                    
02d2d414: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d2d418: cbz     x21, #0x2d2d5b0                            
02d2d41c: mov     x0, x21                                    
02d2d420: mov     x1, x22                                    
02d2d424: mov     x2, xzr                                    
02d2d428: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d2d42c: ldr     x8, [x20]                                  S:'didu'
02d2d430: cbz     x8, #0x2d2d5b0                             
02d2d434: ldr     x0, [x8, #0x48]                            
02d2d438: cbz     x0, #0x2d2d5b0                             
02d2d43c: adrp    x8, #0x626a000                             
02d2d440: adrp    x26, #0x626a000                            
02d2d444: adrp    x27, #0x6263000                            
02d2d448: ldr     x8, [x8, #0x2f0]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d2d44c: adrp    x28, #0x626a000                            
02d2d450: adrp    x29, #0x626a000                            
02d2d454: adrp    x25, #0x626a000                            
02d2d458: ldr     x26, [x26, #0x2e0]                         MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d2d45c: ldr     x27, [x27, #0x918]                         T:UnityEngine.Object
02d2d460: ldr     x28, [x28, #0x4e8]                         MS:UnityEngine.Object::Instantiate
02d2d464: ldr     x29, [x29, #0x4e0]                         MS:System.Collections.Generic.List`1::Add
02d2d468: ldr     x25, [x25, #0x2d8]                         MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d2d46c: ldr     x1, [x8]                                   T:type56879(k15)
02d2d470: add     x8, sp, #8                                 
02d2d474: bl      #0x35a9d9c                                 fn_35a9d9c
02d2d478: ldr     x8, [sp, #0x18]                            
02d2d47c: ldur    q0, [sp, #8]                               
02d2d480: str     x8, [sp, #0x30]                            
02d2d484: add     x8, sp, #0x20                              
02d2d488: str     q0, [sp, #0x20]                            
02d2d48c: stp     xzr, x8, [sp, #8]                          
02d2d490: ldr     x1, [x26]                                  T:type56879(k15)
02d2d494: add     x0, sp, #0x20                              
02d2d498: bl      #0x4690474                                 fn_4690474
02d2d49c: tbz     w0, #0, #0x2d2d568                         
02d2d4a0: ldr     x9, [x20]                                  S:'didu'
02d2d4a4: cbz     x9, #0x2d2d5a8                             
02d2d4a8: ldr     x8, [sp, #0x30]                            
02d2d4ac: cbz     x8, #0x2d2d5ac                             
02d2d4b0: ldr     x0, [x9, #0x40]                            
02d2d4b4: cbz     x0, #0x2d2d5a0                             
02d2d4b8: ldr     w1, [x8, #0x10]                            T:Decor.DataDecor/CategoryData
02d2d4bc: bl      #0x2d2b6fc                                 DailyTask.DailyTaskSO::GetMissionById
02d2d4c0: mov     x23, x0                                    
02d2d4c4: ldr     x0, [x27]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d2d4c8: ldr     x21, [x19, #0x80]                          ._items
02d2d4cc: ldp     x22, x24, [x19, #0x38]                     ._itemPrefab
02d2d4d0: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02d2d4d4: cbnz    w8, #0x2d2d4dc                             
02d2d4d8: bl      #0x2b70f30                                 fn_2b70f30
02d2d4dc: ldr     x2, [x28]                                  T:type56879(k15)
02d2d4e0: mov     x0, x22                                    
02d2d4e4: mov     x1, x24                                    
02d2d4e8: bl      #0x3275fcc                                 fn_3275fcc
02d2d4ec: mov     x22, x0                                    
02d2d4f0: cbz     x0, #0x2d2d5a4                             
02d2d4f4: mov     x0, x22                                    
02d2d4f8: mov     x1, x23                                    
02d2d4fc: mov     x2, x19                                    
02d2d500: bl      #0x2d2c698                                 DailyTask.DailyTaskItemUI::OnInit
02d2d504: cbz     x21, #0x2d2d59c                            
02d2d508: ldr     w10, [x21, #0x1c]                          
02d2d50c: ldr     x8, [x21, #0x10]                           
02d2d510: ldr     x9, [x29]                                  T:type56879(k15)
02d2d514: add     w10, w10, #1                               
02d2d518: str     w10, [x21, #0x1c]                          
02d2d51c: cbz     x8, #0x2d2d59c                             
02d2d520: ldrsw   x10, [x21, #0x18]                          
02d2d524: ldr     w11, [x8, #0x18]                           MS:System.Collections.Generic.List`1::Add
02d2d528: cmp     w10, w11                                   
02d2d52c: b.hs    #0x2d2d54c                                 
02d2d530: add     x0, x8, x10, lsl #3                        &626a000
02d2d534: add     w9, w10, #1                                
02d2d538: str     w9, [x21, #0x18]                           
02d2d53c: str     x22, [x0, #0x20]!                          
02d2d540: mov     x1, x22                                    
02d2d544: bl      #0x2b70d54                                 fn_2b70d54
02d2d548: b       #0x2d2d490                                 
02d2d54c: ldr     x8, [x9, #0x20]                            
02d2d550: ldr     x8, [x8, #0xc0]                            S:'Main character is null'
02d2d554: ldr     x2, [x8, #0x70]                            MS:System.Collections.Generic.List`1::FindIndex
02d2d558: mov     x0, x21                                    
02d2d55c: mov     x1, x22                                    
02d2d560: bl      #0x35a920c                                 fn_35a920c
02d2d564: b       #0x2d2d490                                 
02d2d568: ldr     x1, [x25]                                  T:type56879(k15)
02d2d56c: add     x0, sp, #0x20                              
02d2d570: bl      #0x4690470                                 fn_4690470
02d2d574: mov     x0, x19                                    
02d2d578: bl      #0x2d2d644                                 DailyTask.PopupDailyTask::RefreshNotification
02d2d57c: ldp     x20, x19, [sp, #0x90]                      
02d2d580: ldp     x22, x21, [sp, #0x80]                      
02d2d584: ldp     x24, x23, [sp, #0x70]                      
02d2d588: ldp     x26, x25, [sp, #0x60]                      
02d2d58c: ldp     x28, x27, [sp, #0x50]                      
02d2d590: ldp     x29, x30, [sp, #0x40]                      
02d2d594: add     sp, sp, #0xa0                              
02d2d598: ret                                                
02d2d59c: bl      #0x2b7105c                                 fn_2b7105c
02d2d5a0: bl      #0x2b7105c                                 fn_2b7105c
02d2d5a4: bl      #0x2b7105c                                 fn_2b7105c
02d2d5a8: bl      #0x2b7105c                                 fn_2b7105c
02d2d5ac: bl      #0x2b7105c                                 fn_2b7105c
02d2d5b0: bl      #0x2b7105c                                 fn_2b7105c
02d2d5b4: b       #0x2d2d5d8                                 
02d2d5b8: b       #0x2d2d5d8                                 
02d2d5bc: b       #0x2d2d5d8                                 
02d2d5c0: b       #0x2d2d5d8                                 
02d2d5c4: b       #0x2d2d5d8                                 
02d2d5c8: b       #0x2d2d5d8                                 
02d2d5cc: b       #0x2d2d5d8                                 
02d2d5d0: b       #0x2d2d5d8                                 
02d2d5d4: b       #0x2d2d5d8                                 
02d2d5d8: mov     x20, x0                                    
02d2d5dc: cmp     w1, #1                                     
02d2d5e0: b.ne    #0x2d2d614                                 
02d2d5e4: mov     x0, x20                                    
02d2d5e8: bl      #0x5e90260                                 fn_5e90260
02d2d5ec: ldr     x20, [x0]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d2d5f0: str     x20, [sp, #8]                              
02d2d5f4: bl      #0x5e90270                                 fn_5e90270
02d2d5f8: ldr     x0, [sp, #0x10]                            
02d2d5fc: ldr     x1, [x25]                                  T:type56879(k15)
02d2d600: bl      #0x4690470                                 fn_4690470
02d2d604: cbz     x20, #0x2d2d574                            
02d2d608: mov     x0, x20                                    
02d2d60c: bl      #0x2b71054                                 fn_2b71054
02d2d610: mov     x20, x0                                    
02d2d614: add     x0, sp, #8                                 
02d2d618: bl      #0x2738168                                 fn_2738168
02d2d61c: mov     x0, x20                                    
02d2d620: bl      #0x2c6051c                                 fn_2c6051c
02d2d624: bl      #0x27369b8                                 fn_27369b8
## OnShow() -> void
---- DailyTask.PopupDailyTask::OnShow 0x2d2d6f0
02d2d6f0: str     x30, [sp, #-0x30]!                         
02d2d6f4: stp     x22, x21, [sp, #0x10]                      
02d2d6f8: stp     x20, x19, [sp, #0x20]                      
02d2d6fc: adrp    x20, #0x6630000                            
02d2d700: mov     x19, x0                                    
02d2d704: ldrb    w8, [x20, #0xd4]                           
02d2d708: tbnz    w8, #0, #0x2d2d750                         
02d2d70c: adrp    x0, #0x626a000                             
02d2d710: ldr     x0, [x0, #0x4f0]                           M:DailyTask.PopupDailyTask::<OnShow>b__16_0
02d2d714: bl      #0x2b70db0                                 fn_2b70db0
02d2d718: adrp    x0, #0x6264000                             
02d2d71c: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d2d720: bl      #0x2b70db0                                 fn_2b70db0
02d2d724: adrp    x0, #0x6266000                             
02d2d728: ldr     x0, [x0, #0x928]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d2d72c: bl      #0x2b70db0                                 fn_2b70db0
02d2d730: adrp    x0, #0x6266000                             
02d2d734: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d2d738: bl      #0x2b70db0                                 fn_2b70db0
02d2d73c: adrp    x0, #0x626a000                             
02d2d740: ldr     x0, [x0, #0x4f8]                           MS:UIManager::ShowPopup
02d2d744: bl      #0x2b70db0                                 fn_2b70db0
02d2d748: mov     w8, #1                                     
02d2d74c: strb    w8, [x20, #0xd4]                           
02d2d750: ldr     x8, [x19, #0xa0]                           ._dailyTaskController
02d2d754: cbz     x8, #0x2d2d8f8                             
02d2d758: ldr     x8, [x8, #0x38]                            
02d2d75c: cbz     x8, #0x2d2d8f8                             
02d2d760: ldr     x8, [x8, #0x20]                            
02d2d764: cbz     x8, #0x2d2d8f8                             
02d2d768: ldrb    w8, [x8, #0x10]                            
02d2d76c: cbz     w8, #0x2d2d7c0                             
02d2d770: ldr     x0, [x19, #0x30]                           
02d2d774: cbz     x0, #0x2d2d8f8                             
02d2d778: adrp    x8, #0x626a000                             
02d2d77c: ldr     x8, [x8, #0x4f8]                           MS:UIManager::ShowPopup
02d2d780: ldr     x1, [x8]                                   T:type56879(k15)
02d2d784: bl      #0x33fbfac                                 fn_33fbfac
02d2d788: ldr     x8, [x19, #0xa0]                           ._dailyTaskController
02d2d78c: cbz     x8, #0x2d2d8f8                             
02d2d790: ldr     x0, [x8, #0x38]                            MS:System.Collections.Generic.List`1::get_Item
02d2d794: cbz     x0, #0x2d2d8f8                             
02d2d798: ldr     x8, [x0, #0x20]                            M:Decor.DataDecor/<>c__DisplayClass8_0::<NewData>b__0
02d2d79c: cbz     x8, #0x2d2d8f8                             
02d2d7a0: strb    wzr, [x8, #0x10]                           
02d2d7a4: ldp     x20, x19, [sp, #0x20]                      
02d2d7a8: ldr     x8, [x0]                                   T:type56879(k15)
02d2d7ac: ldp     x22, x21, [sp, #0x10]                      
02d2d7b0: ldr     x1, [x8, #0x260]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d2d7b4: ldr     x2, [x8, #0x258]                           M:Decor.OptionPanel::<Refresh>b__19_0
02d2d7b8: ldr     x30, [sp], #0x30                           
02d2d7bc: br      x2                                         
02d2d7c0: ldr     x0, [x19, #0x48]                           ._scrollRect
02d2d7c4: cbz     x0, #0x2d2d8f8                             
02d2d7c8: fmov    s0, #1.00000000                            
02d2d7cc: mov     x1, xzr                                    
02d2d7d0: bl      #0x5e64a60                                 UnityEngine.UI.ScrollRect::set_verticalNormalizedPosition
02d2d7d4: mov     x0, x19                                    
02d2d7d8: bl      #0x2d2d8fc                                 DailyTask.PopupDailyTask::Refresh
02d2d7dc: mov     x0, x19                                    
02d2d7e0: mov     x1, xzr                                    
02d2d7e4: bl      #0x2cdd6b8                                 UIBase::OnShow
02d2d7e8: ldr     x0, [x19, #0x50]                           ._panel
02d2d7ec: mov     w1, wzr                                    
02d2d7f0: mov     x2, xzr                                    
02d2d7f4: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d2d7f8: adrp    x21, #0x662f000                            
02d2d7fc: ldr     x20, [x19, #0x50]                          ._panel
02d2d800: ldrb    w8, [x21, #0x91a]                          
02d2d804: cbnz    w8, #0x2d2d81c                             
02d2d808: adrp    x0, #0x6264000                             
02d2d80c: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d2d810: bl      #0x2b70db0                                 fn_2b70db0
02d2d814: mov     w8, #1                                     
02d2d818: strb    w8, [x21, #0x91a]                          
02d2d81c: cbz     x20, #0x2d2d8f8                            
02d2d820: adrp    x21, #0x6264000                            
02d2d824: mov     x0, x20                                    
02d2d828: mov     x1, xzr                                    
02d2d82c: ldr     x21, [x21, #0xd8]                          T:UnityEngine.Vector3
02d2d830: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d2d834: ldr     x8, [x8, #0xb8]                            MS:UnityEngine.Object::FindObjectsOfType
02d2d838: ldp     s1, s2, [x8, #4]                           
02d2d83c: ldr     s0, [x8]                                   T:type56879(k15)
02d2d840: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d2d844: adrp    x22, #0x662f000                            
02d2d848: ldr     x20, [x19, #0x50]                          ._panel
02d2d84c: ldrb    w8, [x22, #0xa74]                          
02d2d850: cbnz    w8, #0x2d2d868                             
02d2d854: adrp    x0, #0x6264000                             
02d2d858: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d2d85c: bl      #0x2b70db0                                 fn_2b70db0
02d2d860: mov     w8, #1                                     
02d2d864: strb    w8, [x22, #0xa74]                          
02d2d868: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d2d86c: mov     x0, x20                                    
02d2d870: mov     x1, xzr                                    
02d2d874: ldr     x8, [x8, #0xb8]                            MS:UnityEngine.Object::FindObjectsOfType
02d2d878: ldp     s0, s1, [x8, #0xc]                         
02d2d87c: ldr     s2, [x8, #0x14]                            [626a014]=0 f=0,0
02d2d880: adrp    x8, #0x1084000                             
02d2d884: ldr     s3, [x8, #0xe60]                           [1084e60]=bc8efa353eb33333 f=0.35,-0.0174533
02d2d888: bl      #0x2d98af8                                 DG.Tweening.ShortcutExtensions::DOScale
02d2d88c: adrp    x8, #0x6266000                             
02d2d890: mov     w1, #0x1b                                  
02d2d894: ldr     x8, [x8, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d2d898: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d2d89c: bl      #0x336fa0c                                 fn_336fa0c
02d2d8a0: adrp    x8, #0x6264000                             
02d2d8a4: mov     x20, x0                                    
02d2d8a8: ldr     x8, [x8, #0xe8]                            T:DG.Tweening.TweenCallback
02d2d8ac: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d2d8b0: mov     x0, x8                                     
02d2d8b4: bl      #0x2b7104c                                 fn_2b7104c
02d2d8b8: adrp    x8, #0x626a000                             
02d2d8bc: mov     x1, x19                                    
02d2d8c0: mov     x3, xzr                                    
02d2d8c4: ldr     x8, [x8, #0x4f0]                           M:DailyTask.PopupDailyTask::<OnShow>b__16_0
02d2d8c8: mov     x21, x0                                    
02d2d8cc: ldr     x2, [x8]                                   T:type56879(k15)
02d2d8d0: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d2d8d4: adrp    x8, #0x6266000                             
02d2d8d8: mov     x0, x20                                    
02d2d8dc: mov     x1, x21                                    
02d2d8e0: ldr     x8, [x8, #0x928]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d2d8e4: ldp     x20, x19, [sp, #0x20]                      
02d2d8e8: ldp     x22, x21, [sp, #0x10]                      
02d2d8ec: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d2d8f0: ldr     x30, [sp], #0x30                           
02d2d8f4: b       #0x336f26c                                 
02d2d8f8: bl      #0x2b7105c                                 fn_2b7105c
## ShowWithHideAction(System.Action actionHide) -> void
---- DailyTask.PopupDailyTask::ShowWithHideAction 0x2d2da54
02d2da54: str     x1, [x0, #0x98]!                           ._actionHide
02d2da58: b       #0x2b70d54                                 
## OnHide() -> void
---- DailyTask.PopupDailyTask::OnHide 0x2d2da5c
02d2da5c: stp     x30, x19, [sp, #-0x10]!                    
02d2da60: mov     x19, x0                                    
02d2da64: ldr     x0, [x0, #0x58]                            ._btnClose
02d2da68: cbz     x0, #0x2d2dac4                             
02d2da6c: mov     w1, wzr                                    
02d2da70: mov     x2, xzr                                    
02d2da74: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d2da78: ldr     x0, [x19, #0x60]                           ._btnClose2
02d2da7c: cbz     x0, #0x2d2dac4                             
02d2da80: mov     w1, wzr                                    
02d2da84: mov     x2, xzr                                    
02d2da88: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d2da8c: mov     x0, x19                                    
02d2da90: mov     x1, xzr                                    
02d2da94: bl      #0x2cddc10                                 UIBase::OnHide
02d2da98: ldr     x8, [x19, #0x98]!                          ._actionHide
02d2da9c: cbz     x8, #0x2d2dab0                             
02d2daa0: ldr     x9, [x8, #0x18]                            
02d2daa4: ldr     x0, [x8, #0x40]                            
02d2daa8: ldr     x1, [x8, #0x28]                            
02d2daac: blr     x9                                         
02d2dab0: mov     x0, x19                                    
02d2dab4: mov     x1, xzr                                    
02d2dab8: str     xzr, [x19]                                 
02d2dabc: ldp     x30, x19, [sp], #0x10                      
02d2dac0: b       #0x2b70d54                                 
02d2dac4: bl      #0x2b7105c                                 fn_2b7105c
## SetActiveBlockObject(bool value) -> void
---- DailyTask.PopupDailyTask::SetActiveBlockObject 0x2d2d628
02d2d628: ldr     x0, [x0, #0x70]                            ._blockObject
02d2d62c: cbz     x0, #0x2d2d63c                             
02d2d630: and     w1, w1, #1                                 
02d2d634: mov     x2, xzr                                    
02d2d638: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d2d63c: str     x30, [sp, #-0x10]!                         
02d2d640: bl      #0x2b7105c                                 fn_2b7105c
## OnTaskCompletedCallback(int taskId) -> void
---- DailyTask.PopupDailyTask::OnTaskCompletedCallback 0x2d2dac8
02d2dac8: stp     x30, x23, [sp, #-0x30]!                    
02d2dacc: stp     x22, x21, [sp, #0x10]                      
02d2dad0: stp     x20, x19, [sp, #0x20]                      
02d2dad4: adrp    x20, #0x6630000                            
02d2dad8: adrp    x22, #0x626a000                            
02d2dadc: mov     w21, w1                                    
02d2dae0: ldrb    w8, [x20, #0xd5]                           
02d2dae4: ldr     x22, [x22, #0x520]                         T:DailyTask.PopupDailyTask/<>c__DisplayClass20_0
02d2dae8: mov     x19, x0                                    
02d2daec: tbnz    w8, #0, #0x2d2db40                         
02d2daf0: adrp    x0, #0x6264000                             
02d2daf4: ldr     x0, [x0, #0xf90]                           T:System.Action
02d2daf8: bl      #0x2b70db0                                 fn_2b70db0
02d2dafc: adrp    x0, #0x626a000                             
02d2db00: ldr     x0, [x0, #0x528]                           MS:System.Collections.Generic.List`1::Find
02d2db04: bl      #0x2b70db0                                 fn_2b70db0
02d2db08: adrp    x0, #0x626a000                             
02d2db0c: ldr     x0, [x0, #0x530]                           T:type57239(k15)
02d2db10: bl      #0x2b70db0                                 fn_2b70db0
02d2db14: adrp    x0, #0x626a000                             
02d2db18: ldr     x0, [x0, #0x538]                           M:DailyTask.PopupDailyTask/<>c__DisplayClass20_0::<OnTaskCompletedCallback>b__0
02d2db1c: bl      #0x2b70db0                                 fn_2b70db0
02d2db20: adrp    x0, #0x626a000                             
02d2db24: ldr     x0, [x0, #0x540]                           M:DailyTask.PopupDailyTask/<>c__DisplayClass20_0::<OnTaskCompletedCallback>b__1
02d2db28: bl      #0x2b70db0                                 fn_2b70db0
02d2db2c: adrp    x0, #0x626a000                             
02d2db30: ldr     x0, [x0, #0x520]                           T:DailyTask.PopupDailyTask/<>c__DisplayClass20_0
02d2db34: bl      #0x2b70db0                                 fn_2b70db0
02d2db38: mov     w8, #1                                     
02d2db3c: strb    w8, [x20, #0xd5]                           
02d2db40: ldr     x0, [x22]                                  T:type56879(k15)
02d2db44: bl      #0x2b7104c                                 fn_2b7104c
02d2db48: mov     x1, xzr                                    
02d2db4c: mov     x20, x0                                    
02d2db50: bl      #0x4e53e9c                                 System.Object::.ctor
02d2db54: cbz     x20, #0x2d2dc64                            
02d2db58: mov     x0, x20                                    
02d2db5c: mov     x1, x19                                    
02d2db60: str     x19, [x0, #0x18]!                          
02d2db64: stur    w21, [x0, #-8]                             
02d2db68: bl      #0x2b70d54                                 fn_2b70d54
02d2db6c: ldr     x0, [x19, #0x70]                           ._blockObject
02d2db70: mov     w8, #1                                     
02d2db74: strb    w8, [x19, #0x90]                           ._isCollecting
02d2db78: cbz     x0, #0x2d2dc64                             
02d2db7c: adrp    x22, #0x626a000                            
02d2db80: adrp    x23, #0x626a000                            
02d2db84: mov     w1, #1                                     
02d2db88: ldr     x22, [x22, #0x530]                         T:type57239(k15)
02d2db8c: ldr     x23, [x23, #0x538]                         M:DailyTask.PopupDailyTask/<>c__DisplayClass20_0::<OnTaskCompletedCallback>b__0
02d2db90: mov     x2, xzr                                    
02d2db94: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d2db98: ldr     x0, [x22]                                  T:type56879(k15)
02d2db9c: ldr     x21, [x19, #0x80]                          ._items
02d2dba0: bl      #0x2b7104c                                 fn_2b7104c
02d2dba4: ldr     x2, [x23]                                  T:type56879(k15)
02d2dba8: mov     x1, x20                                    
02d2dbac: mov     x3, xzr                                    
02d2dbb0: mov     x22, x0                                    
02d2dbb4: bl      #0x399ba10                                 fn_399ba10
02d2dbb8: cbz     x21, #0x2d2dc64                            
02d2dbbc: adrp    x8, #0x626a000                             
02d2dbc0: mov     x0, x21                                    
02d2dbc4: mov     x1, x22                                    
02d2dbc8: ldr     x8, [x8, #0x528]                           MS:System.Collections.Generic.List`1::Find
02d2dbcc: ldr     x2, [x8]                                   T:type56879(k15)
02d2dbd0: bl      #0x35a9868                                 fn_35a9868
02d2dbd4: cbz     x0, #0x2d2dc64                             
02d2dbd8: ldr     x0, [x0, #0x78]                            M:Decor.DecorAsset/<>c__DisplayClass5_0::<GetCategoryIndexByName>b__0 ._notiObject
02d2dbdc: cbz     x0, #0x2d2dc64                             
02d2dbe0: ldr     x21, [x19, #0x68]                          ._collectingStar
02d2dbe4: mov     x1, xzr                                    
02d2dbe8: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d2dbec: cbz     x21, #0x2d2dc64                            
02d2dbf0: adrp    x22, #0x6264000                            
02d2dbf4: adrp    x23, #0x626a000                            
02d2dbf8: mov     x0, x21                                    
02d2dbfc: ldr     x22, [x22, #0xf90]                         T:System.Action
02d2dc00: ldr     x23, [x23, #0x540]                         M:DailyTask.PopupDailyTask/<>c__DisplayClass20_0::<OnTaskCompletedCallback>b__1
02d2dc04: mov     x1, xzr                                    
02d2dc08: bl      #0x2d121fc                                 JobGame.CollectingCoin::SetSpawnLocation
02d2dc0c: ldr     x8, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d2dc10: mov     x21, x0                                    
02d2dc14: mov     x0, x8                                     
02d2dc18: bl      #0x2b7104c                                 fn_2b7104c
02d2dc1c: ldr     x2, [x23]                                  T:type56879(k15)
02d2dc20: mov     x1, x20                                    
02d2dc24: mov     x3, xzr                                    
02d2dc28: mov     x22, x0                                    
02d2dc2c: bl      #0x4d8ddbc                                 System.Action::.ctor
02d2dc30: cbz     x21, #0x2d2dc64                            
02d2dc34: mov     x0, x21                                    
02d2dc38: mov     w1, #5                                     
02d2dc3c: mov     x2, x22                                    
02d2dc40: mov     x3, xzr                                    
02d2dc44: bl      #0x2d12224                                 JobGame.CollectingCoin::CollectCoins
02d2dc48: mov     x0, x19                                    
02d2dc4c: bl      #0x2d2d8fc                                 DailyTask.PopupDailyTask::Refresh
02d2dc50: mov     x0, x19                                    
02d2dc54: ldp     x20, x19, [sp, #0x20]                      
02d2dc58: ldp     x22, x21, [sp, #0x10]                      
02d2dc5c: ldp     x30, x23, [sp], #0x30                      
02d2dc60: b       #0x2d2d644                                 DailyTask.PopupDailyTask::RefreshNotification
02d2dc64: bl      #0x2b7105c                                 fn_2b7105c
## OnTaskProgressedCallback(int taskId) -> void
---- DailyTask.PopupDailyTask::OnTaskProgressedCallback 0x2d2dc70
02d2dc70: stp     x30, x23, [sp, #-0x30]!                    
02d2dc74: stp     x22, x21, [sp, #0x10]                      
02d2dc78: stp     x20, x19, [sp, #0x20]                      
02d2dc7c: adrp    x21, #0x6630000                            
02d2dc80: adrp    x22, #0x626a000                            
02d2dc84: mov     w20, w1                                    
02d2dc88: ldrb    w8, [x21, #0xd6]                           
02d2dc8c: ldr     x22, [x22, #0x548]                         T:DailyTask.PopupDailyTask/<>c__DisplayClass21_0
02d2dc90: mov     x19, x0                                    
02d2dc94: tbnz    w8, #0, #0x2d2dcd0                         
02d2dc98: adrp    x0, #0x626a000                             
02d2dc9c: ldr     x0, [x0, #0x528]                           MS:System.Collections.Generic.List`1::Find
02d2dca0: bl      #0x2b70db0                                 fn_2b70db0
02d2dca4: adrp    x0, #0x626a000                             
02d2dca8: ldr     x0, [x0, #0x530]                           T:type57239(k15)
02d2dcac: bl      #0x2b70db0                                 fn_2b70db0
02d2dcb0: adrp    x0, #0x626a000                             
02d2dcb4: ldr     x0, [x0, #0x550]                           M:DailyTask.PopupDailyTask/<>c__DisplayClass21_0::<OnTaskProgressedCallback>b__0
02d2dcb8: bl      #0x2b70db0                                 fn_2b70db0
02d2dcbc: adrp    x0, #0x626a000                             
02d2dcc0: ldr     x0, [x0, #0x548]                           T:DailyTask.PopupDailyTask/<>c__DisplayClass21_0
02d2dcc4: bl      #0x2b70db0                                 fn_2b70db0
02d2dcc8: mov     w8, #1                                     
02d2dccc: strb    w8, [x21, #0xd6]                           
02d2dcd0: ldr     x0, [x22]                                  T:type56879(k15)
02d2dcd4: bl      #0x2b7104c                                 fn_2b7104c
02d2dcd8: mov     x1, xzr                                    
02d2dcdc: mov     x21, x0                                    
02d2dce0: bl      #0x4e53e9c                                 System.Object::.ctor
02d2dce4: cbz     x21, #0x2d2dd54                            
02d2dce8: adrp    x8, #0x626a000                             
02d2dcec: adrp    x23, #0x626a000                            
02d2dcf0: ldr     x8, [x8, #0x530]                           T:type57239(k15)
02d2dcf4: ldr     x23, [x23, #0x550]                         M:DailyTask.PopupDailyTask/<>c__DisplayClass21_0::<OnTaskProgressedCallback>b__0
02d2dcf8: ldr     x22, [x19, #0x80]                          ._items
02d2dcfc: str     w20, [x21, #0x10]                          
02d2dd00: ldr     x0, [x8]                                   T:type56879(k15)
02d2dd04: bl      #0x2b7104c                                 fn_2b7104c
02d2dd08: ldr     x2, [x23]                                  T:type56879(k15)
02d2dd0c: mov     x1, x21                                    
02d2dd10: mov     x3, xzr                                    
02d2dd14: mov     x20, x0                                    
02d2dd18: bl      #0x399ba10                                 fn_399ba10
02d2dd1c: cbz     x22, #0x2d2dd54                            
02d2dd20: adrp    x8, #0x626a000                             
02d2dd24: mov     x0, x22                                    
02d2dd28: mov     x1, x20                                    
02d2dd2c: ldr     x8, [x8, #0x528]                           MS:System.Collections.Generic.List`1::Find
02d2dd30: ldr     x2, [x8]                                   T:type56879(k15)
02d2dd34: bl      #0x35a9868                                 fn_35a9868
02d2dd38: cbz     x0, #0x2d2dd40                             
02d2dd3c: bl      #0x2d2c95c                                 DailyTask.DailyTaskItemUI::UpdateProperties
02d2dd40: mov     x0, x19                                    
02d2dd44: ldp     x20, x19, [sp, #0x20]                      
02d2dd48: ldp     x22, x21, [sp, #0x10]                      
02d2dd4c: ldp     x30, x23, [sp], #0x30                      
02d2dd50: b       #0x2d2d644                                 DailyTask.PopupDailyTask::RefreshNotification
02d2dd54: bl      #0x2b7105c                                 fn_2b7105c
## OnAllTasksCompletedCallback() -> void
---- DailyTask.PopupDailyTask::OnAllTasksCompletedCallback 0x2d2dd60
02d2dd60: sub     sp, sp, #0x80                              
02d2dd64: stp     x30, x21, [sp, #0x60]                      
02d2dd68: stp     x20, x19, [sp, #0x70]                      
02d2dd6c: adrp    x21, #0x6630000                            
02d2dd70: adrp    x20, #0x626a000                            
02d2dd74: mov     x19, x0                                    
02d2dd78: ldrb    w8, [x21, #0xd7]                           
02d2dd7c: ldr     x20, [x20, #0x558]                         MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::Start
02d2dd80: tbnz    w8, #0, #0x2d2dd98                         
02d2dd84: adrp    x0, #0x626a000                             
02d2dd88: ldr     x0, [x0, #0x558]                           MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::Start
02d2dd8c: bl      #0x2b70db0                                 fn_2b70db0
02d2dd90: mov     w8, #1                                     
02d2dd94: strb    w8, [x21, #0xd7]                           
02d2dd98: movi    v0.2d, #0000000000000000                   
02d2dd9c: mov     x8, sp                                     
02d2dda0: mov     x0, xzr                                    
02d2dda4: stp     q0, q0, [sp, #0x20]                        
02d2dda8: stp     q0, q0, [sp, #0x40]                        
02d2ddac: bl      #0x4d43a24                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::Create
02d2ddb0: ldp     q0, q1, [sp]                               
02d2ddb4: add     x21, sp, #0x20                             
02d2ddb8: orr     x0, x21, #8                                
02d2ddbc: mov     x1, xzr                                    
02d2ddc0: stur    q0, [sp, #0x28]                            
02d2ddc4: stur    q1, [sp, #0x38]                            
02d2ddc8: bl      #0x2b70d54                                 fn_2b70d54
02d2ddcc: add     x0, x21, #0x28                             &6630028
02d2ddd0: mov     x1, x19                                    
02d2ddd4: str     x19, [sp, #0x48]                           
02d2ddd8: bl      #0x2b70d54                                 fn_2b70d54
02d2dddc: ldr     x2, [x20]                                  T:type56879(k15)
02d2dde0: mov     w8, #-1                                    
02d2dde4: orr     x0, x21, #8                                
02d2dde8: add     x1, sp, #0x20                              
02d2ddec: str     w8, [sp, #0x20]                            
02d2ddf0: bl      #0x30c852c                                 fn_30c852c
02d2ddf4: ldp     x20, x19, [sp, #0x70]                      
02d2ddf8: ldp     x30, x21, [sp, #0x60]                      
02d2ddfc: add     sp, sp, #0x80                              
02d2de00: ret                                                
## RefreshNotification() -> void
---- DailyTask.PopupDailyTask::RefreshNotification 0x2d2d644
02d2d644: str     x30, [sp, #-0x20]!                         
02d2d648: stp     x20, x19, [sp, #0x10]                      
02d2d64c: adrp    x20, #0x6630000                            
02d2d650: mov     x19, x0                                    
02d2d654: ldrb    w8, [x20, #0xd8]                           
02d2d658: tbnz    w8, #0, #0x2d2d67c                         
02d2d65c: adrp    x0, #0x6266000                             
02d2d660: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d2d664: bl      #0x2b70db0                                 fn_2b70db0
02d2d668: adrp    x0, #0x6266000                             
02d2d66c: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d2d670: bl      #0x2b70db0                                 fn_2b70db0
02d2d674: mov     w8, #1                                     
02d2d678: strb    w8, [x20, #0xd8]                           
02d2d67c: ldr     x0, [x19, #0xa0]                           ._dailyTaskController
02d2d680: cbz     x0, #0x2d2d6ec                             
02d2d684: ldr     x19, [x19, #0x78]                          ._notiObject
02d2d688: bl      #0x2d2b7d4                                 DailyTask.DailyTaskController::AnyTaskClaimable
02d2d68c: tbz     w0, #0, #0x2d2d6d0                         
02d2d690: adrp    x8, #0x6266000                             
02d2d694: ldr     x8, [x8, #0x658]                           MS:MonoSingleton`1::get_Instance
02d2d698: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d2d69c: bl      #0x3769600                                 fn_3769600
02d2d6a0: cbz     x0, #0x2d2d6ec                             
02d2d6a4: adrp    x8, #0x6266000                             
02d2d6a8: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02d2d6ac: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d2d6b0: bl      #0x3168dd0                                 fn_3168dd0
02d2d6b4: cbz     x0, #0x2d2d6ec                             
02d2d6b8: ldr     x8, [x0, #0x20]                            S:'inter_ad_capping_time'
02d2d6bc: cbz     x8, #0x2d2d6ec                             
02d2d6c0: ldrb    w8, [x8, #0x40]                            
02d2d6c4: cmp     w8, #0                                     
02d2d6c8: cset    w1, ne                                     
02d2d6cc: b       #0x2d2d6d4                                 
02d2d6d0: mov     w1, wzr                                    
02d2d6d4: cbz     x19, #0x2d2d6ec                            
02d2d6d8: mov     x0, x19                                    
02d2d6dc: ldp     x20, x19, [sp, #0x10]                      
02d2d6e0: mov     x2, xzr                                    
02d2d6e4: ldr     x30, [sp], #0x20                           
02d2d6e8: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d2d6ec: bl      #0x2b7105c                                 fn_2b7105c
## Refresh() -> void
---- DailyTask.PopupDailyTask::Refresh 0x2d2d8fc
02d2d8fc: sub     sp, sp, #0x60                              
02d2d900: str     x30, [sp, #0x30]                           
02d2d904: stp     x22, x21, [sp, #0x40]                      
02d2d908: stp     x20, x19, [sp, #0x50]                      
02d2d90c: adrp    x20, #0x6630000                            
02d2d910: mov     x19, x0                                    
02d2d914: ldrb    w8, [x20, #0xd9]                           
02d2d918: tbnz    w8, #0, #0x2d2d954                         
02d2d91c: adrp    x0, #0x626a000                             
02d2d920: ldr     x0, [x0, #0x500]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d2d924: bl      #0x2b70db0                                 fn_2b70db0
02d2d928: adrp    x0, #0x626a000                             
02d2d92c: ldr     x0, [x0, #0x508]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d2d930: bl      #0x2b70db0                                 fn_2b70db0
02d2d934: adrp    x0, #0x626a000                             
02d2d938: ldr     x0, [x0, #0x510]                           MS:System.Collections.Generic.List`1/Enumerator::get_Current
02d2d93c: bl      #0x2b70db0                                 fn_2b70db0
02d2d940: adrp    x0, #0x626a000                             
02d2d944: ldr     x0, [x0, #0x518]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d2d948: bl      #0x2b70db0                                 fn_2b70db0
02d2d94c: mov     w8, #1                                     
02d2d950: strb    w8, [x20, #0xd9]                           
02d2d954: ldr     x0, [x19, #0x80]                           ._items
02d2d958: stp     xzr, xzr, [sp, #0x18]                      
02d2d95c: str     xzr, [sp, #0x28]                           
02d2d960: cbz     x0, #0x2d2d9f8                             
02d2d964: adrp    x8, #0x626a000                             
02d2d968: adrp    x20, #0x626a000                            
02d2d96c: adrp    x21, #0x626a000                            
02d2d970: ldr     x8, [x8, #0x518]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d2d974: ldr     x20, [x20, #0x508]                         MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d2d978: ldr     x21, [x21, #0x500]                         MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d2d97c: add     x22, sp, #0x18                             
02d2d980: ldr     x1, [x8]                                   T:type56879(k15)
02d2d984: add     x8, sp, #0x18                              
02d2d988: bl      #0x35a9d9c                                 fn_35a9d9c
02d2d98c: stp     xzr, x22, [sp, #8]                         
02d2d990: ldr     x1, [x20]                                  T:type56879(k15)
02d2d994: add     x0, sp, #0x18                              
02d2d998: bl      #0x4690474                                 fn_4690474
02d2d99c: tbz     w0, #0, #0x2d2d9b0                         
02d2d9a0: ldr     x0, [sp, #0x28]                            
02d2d9a4: cbz     x0, #0x2d2d9f4                             
02d2d9a8: bl      #0x2d2c95c                                 DailyTask.DailyTaskItemUI::UpdateProperties
02d2d9ac: b       #0x2d2d990                                 
02d2d9b0: ldr     x1, [x21]                                  T:type56879(k15)
02d2d9b4: add     x0, sp, #0x18                              
02d2d9b8: bl      #0x4690470                                 fn_4690470
02d2d9bc: ldr     x0, [x19, #0xa0]                           ._dailyTaskController
02d2d9c0: cbz     x0, #0x2d2d9f8                             
02d2d9c4: ldr     x19, [x19, #0x88]                          ._rewardProgressBar
02d2d9c8: bl      #0x2d2ba0c                                 DailyTask.DailyTaskController::GetTotalRewardCompletedTasks
02d2d9cc: cbz     x19, #0x2d2d9f8                            
02d2d9d0: fmov    s0, #1.00000000                            
02d2d9d4: mov     w1, w0                                     
02d2d9d8: mov     x0, x19                                    
02d2d9dc: bl      #0x2d1c608                                 DreamHouse.ProgressBar::DoProgressValue
02d2d9e0: ldp     x20, x19, [sp, #0x50]                      
02d2d9e4: ldr     x30, [sp, #0x30]                           
02d2d9e8: ldp     x22, x21, [sp, #0x40]                      
02d2d9ec: add     sp, sp, #0x60                              
02d2d9f0: ret                                                
02d2d9f4: bl      #0x2b7105c                                 fn_2b7105c
02d2d9f8: bl      #0x2b7105c                                 fn_2b7105c
02d2d9fc: b       #0x2d2da04                                 
02d2da00: b       #0x2d2da04                                 
02d2da04: mov     x20, x0                                    
02d2da08: cmp     w1, #1                                     
02d2da0c: b.ne    #0x2d2da40                                 
02d2da10: mov     x0, x20                                    
02d2da14: bl      #0x5e90260                                 fn_5e90260
02d2da18: ldr     x20, [x0]                                  T:type56879(k15)
02d2da1c: str     x20, [sp, #8]                              
02d2da20: bl      #0x5e90270                                 fn_5e90270
02d2da24: ldr     x0, [sp, #0x10]                            
02d2da28: ldr     x1, [x21]                                  T:type56879(k15)
02d2da2c: bl      #0x4690470                                 fn_4690470
02d2da30: cbz     x20, #0x2d2d9bc                            
02d2da34: mov     x0, x20                                    
02d2da38: bl      #0x2b71054                                 fn_2b71054
02d2da3c: mov     x20, x0                                    
02d2da40: add     x0, sp, #8                                 
02d2da44: bl      #0x27381c8                                 fn_27381c8
02d2da48: mov     x0, x20                                    
02d2da4c: bl      #0x2c6051c                                 fn_2c6051c
02d2da50: bl      #0x27369b8                                 fn_27369b8
## OnButtonCloseClicked() -> void
---- DailyTask.PopupDailyTask::OnButtonCloseClicked 0x2d2de04
02d2de04: str     x30, [sp, #-0x30]!                         
02d2de08: stp     x22, x21, [sp, #0x10]                      
02d2de0c: stp     x20, x19, [sp, #0x20]                      
02d2de10: adrp    x20, #0x6630000                            
02d2de14: mov     x19, x0                                    
02d2de18: ldrb    w8, [x20, #0xda]                           
02d2de1c: tbnz    w8, #0, #0x2d2de58                         
02d2de20: adrp    x0, #0x6264000                             
02d2de24: ldr     x0, [x0, #0xf90]                           T:System.Action
02d2de28: bl      #0x2b70db0                                 fn_2b70db0
02d2de2c: adrp    x0, #0x626a000                             
02d2de30: ldr     x0, [x0, #0x560]                           M:DailyTask.PopupDailyTask::<OnButtonCloseClicked>b__25_0
02d2de34: bl      #0x2b70db0                                 fn_2b70db0
02d2de38: adrp    x0, #0x6265000                             
02d2de3c: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02d2de40: bl      #0x2b70db0                                 fn_2b70db0
02d2de44: adrp    x0, #0x626a000                             
02d2de48: ldr     x0, [x0, #0x568]                           S:'daily_task_close'
02d2de4c: bl      #0x2b70db0                                 fn_2b70db0
02d2de50: mov     w8, #1                                     
02d2de54: strb    w8, [x20, #0xda]                           
02d2de58: mov     x0, xzr                                    
02d2de5c: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d2de60: cbz     x0, #0x2d2def8                             
02d2de64: movi    d1, #0000000000000000                      
02d2de68: movi    d2, #0000000000000000                      
02d2de6c: adrp    x20, #0x6265000                            
02d2de70: fmov    s0, #1.00000000                            
02d2de74: adrp    x21, #0x6264000                            
02d2de78: adrp    x22, #0x626a000                            
02d2de7c: ldr     x20, [x20, #0x310]                         MS:WejoyService.Singleton`1::get_Instance
02d2de80: ldr     x21, [x21, #0xf90]                         T:System.Action
02d2de84: ldr     x22, [x22, #0x560]                         M:DailyTask.PopupDailyTask::<OnButtonCloseClicked>b__25_0
02d2de88: mov     w1, #1                                     
02d2de8c: mov     w2, wzr                                    
02d2de90: mov     w3, wzr                                    
02d2de94: mov     x4, xzr                                    
02d2de98: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d2de9c: ldr     x0, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d2dea0: bl      #0x3be7218                                 fn_3be7218
02d2dea4: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d2dea8: mov     x20, x0                                    
02d2deac: mov     x0, x8                                     
02d2deb0: bl      #0x2b7104c                                 fn_2b7104c
02d2deb4: ldr     x2, [x22]                                  T:type56879(k15)
02d2deb8: mov     x1, x19                                    
02d2debc: mov     x3, xzr                                    
02d2dec0: mov     x21, x0                                    
02d2dec4: bl      #0x4d8ddbc                                 System.Action::.ctor
02d2dec8: cbz     x20, #0x2d2def8                            
02d2decc: adrp    x8, #0x626a000                             
02d2ded0: mov     x0, x20                                    
02d2ded4: mov     x2, x21                                    
02d2ded8: ldr     x8, [x8, #0x568]                           S:'daily_task_close'
02d2dedc: ldp     x20, x19, [sp, #0x20]                      
02d2dee0: ldp     x22, x21, [sp, #0x10]                      
02d2dee4: mov     w3, wzr                                    
02d2dee8: ldr     x1, [x8]                                   T:type56879(k15)
02d2deec: mov     x4, xzr                                    
02d2def0: ldr     x30, [sp], #0x30                           
02d2def4: b       #0x2c89698                                 AdsManager::ShowInter
02d2def8: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- DailyTask.PopupDailyTask::.ctor 0x2d2defc
02d2defc: str     x30, [sp, #-0x30]!                         
02d2df00: stp     x22, x21, [sp, #0x10]                      
02d2df04: stp     x20, x19, [sp, #0x20]                      
02d2df08: adrp    x21, #0x6630000                            
02d2df0c: adrp    x22, #0x626a000                            
02d2df10: adrp    x20, #0x626a000                            
02d2df14: ldrb    w8, [x21, #0xdb]                           
02d2df18: ldr     x22, [x22, #0x570]                         T:type56665(k15)
02d2df1c: ldr     x20, [x20, #0x578]                         MS:System.Collections.Generic.List`1::.ctor
02d2df20: mov     x19, x0                                    
02d2df24: tbnz    w8, #0, #0x2d2df48                         
02d2df28: adrp    x0, #0x626a000                             
02d2df2c: ldr     x0, [x0, #0x578]                           MS:System.Collections.Generic.List`1::.ctor
02d2df30: bl      #0x2b70db0                                 fn_2b70db0
02d2df34: adrp    x0, #0x626a000                             
02d2df38: ldr     x0, [x0, #0x570]                           T:type56665(k15)
02d2df3c: bl      #0x2b70db0                                 fn_2b70db0
02d2df40: mov     w8, #1                                     
02d2df44: strb    w8, [x21, #0xdb]                           
02d2df48: ldr     x0, [x22]                                  T:type56879(k15)
02d2df4c: bl      #0x2b7104c                                 fn_2b7104c
02d2df50: ldr     x1, [x20]                                  T:type56879(k15)
02d2df54: mov     x20, x0                                    
02d2df58: bl      #0x35a89a4                                 fn_35a89a4
02d2df5c: mov     x0, x19                                    
02d2df60: mov     x1, x20                                    
02d2df64: str     x20, [x0, #0x80]!                          ._items
02d2df68: bl      #0x2b70d54                                 fn_2b70d54
02d2df6c: mov     x0, x19                                    
02d2df70: ldp     x20, x19, [sp, #0x20]                      
02d2df74: ldp     x22, x21, [sp, #0x10]                      
02d2df78: mov     x1, xzr                                    
02d2df7c: ldr     x30, [sp], #0x30                           
02d2df80: b       #0x2cddba8                                 PopupBase::.ctor
## <OnShow>b__16_0() -> void
---- DailyTask.PopupDailyTask::<OnShow>b__16_0 0x2d2df84
02d2df84: stp     x30, x19, [sp, #-0x10]!                    
02d2df88: mov     x19, x0                                    
02d2df8c: ldr     x0, [x0, #0x58]                            ._btnClose
02d2df90: cbz     x0, #0x2d2dfb8                             
02d2df94: mov     w1, #1                                     
02d2df98: mov     x2, xzr                                    
02d2df9c: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d2dfa0: ldr     x0, [x19, #0x60]                           ._btnClose2
02d2dfa4: cbz     x0, #0x2d2dfb8                             
02d2dfa8: mov     w1, #1                                     
02d2dfac: mov     x2, xzr                                    
02d2dfb0: ldp     x30, x19, [sp], #0x10                      
02d2dfb4: b       #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d2dfb8: bl      #0x2b7105c                                 fn_2b7105c
## <OnAllTasksCompletedCallback>b__22_0() -> bool
---- DailyTask.PopupDailyTask::<OnAllTasksCompletedCallback>b__22_0 0x2d2dfbc
02d2dfbc: ldrb    w8, [x0, #0x90]                            ._isCollecting
02d2dfc0: cmp     w8, #0                                     
02d2dfc4: cset    w0, eq                                     
02d2dfc8: ret                                                
## <OnButtonCloseClicked>b__25_0() -> void
---- DailyTask.PopupDailyTask::<OnButtonCloseClicked>b__25_0 0x2d2dfcc
02d2dfcc: stp     x30, x19, [sp, #-0x10]!                    
02d2dfd0: mov     x19, x0                                    
02d2dfd4: ldr     x0, [x0, #0x58]                            ._btnClose
02d2dfd8: cbz     x0, #0x2d2dffc                             
02d2dfdc: mov     w1, wzr                                    
02d2dfe0: mov     x2, xzr                                    
02d2dfe4: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d2dfe8: ldr     x8, [x19]                                  
02d2dfec: mov     x0, x19                                    
02d2dff0: ldp     x2, x1, [x8, #0x198]                       
02d2dff4: ldp     x30, x19, [sp], #0x10                      
02d2dff8: br      x2                                         
02d2dffc: bl      #0x2b7105c                                 fn_2b7105c
