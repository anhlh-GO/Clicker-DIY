#### CLASS Framework.ParticleSystemCallback parent= UnityEngine.MonoBehaviour
#   field EventOnParticleCollision       UnityEngine.Events.UnityEvent`1<UnityEngine.GameObject> off=0x20 attr=6 
#   field EventOnParticleSystemStopped   UnityEngine.Events.UnityEvent                      off=0x28 attr=6 
#   field EventOnParticleTrigger         UnityEngine.Events.UnityEvent                      off=0x30 attr=6 
#   field EventOnParticleUpdateJobScheduled UnityEngine.Events.UnityEvent                      off=0x38 attr=6 
#   field _constrainOnStoppedTriggerOneTime bool                                               off=0x40 attr=1 SerializeField
#   field <ParticleSystem>k__BackingField UnityEngine.ParticleSystem                         off=0x48 attr=1 CompilerGeneratedAttribute
#   field _triggered                     bool                                               off=0x50 attr=1 
## get_ParticleSystem() -> UnityEngine.ParticleSystem
---- Framework.ParticleSystemCallback::get_ParticleSystem 0x2cc6a3c
02cc6a3c: ldr     x0, [x0, #0x48]                            .<ParticleSystem>k__BackingField
02cc6a40: ret                                                
## set_ParticleSystem(UnityEngine.ParticleSystem value) -> void
---- Framework.ParticleSystemCallback::set_ParticleSystem 0x2cc6a44
02cc6a44: str     x1, [x0, #0x48]!                           .<ParticleSystem>k__BackingField
02cc6a48: b       #0x2b70d54                                 
## Awake() -> void
---- Framework.ParticleSystemCallback::Awake 0x2cc6a4c
02cc6a4c: stp     x30, x21, [sp, #-0x20]!                    
02cc6a50: stp     x20, x19, [sp, #0x10]                      
02cc6a54: adrp    x20, #0x662f000                            
02cc6a58: adrp    x21, #0x6267000                            
02cc6a5c: mov     x19, x0                                    
02cc6a60: ldrb    w8, [x20, #0xc58]                          
02cc6a64: ldr     x21, [x21, #0x2d8]                         MS:UnityEngine.Component::GetComponent
02cc6a68: tbnz    w8, #0, #0x2cc6a80                         
02cc6a6c: adrp    x0, #0x6267000                             
02cc6a70: ldr     x0, [x0, #0x2d8]                           MS:UnityEngine.Component::GetComponent
02cc6a74: bl      #0x2b70db0                                 fn_2b70db0
02cc6a78: mov     w8, #1                                     
02cc6a7c: strb    w8, [x20, #0xc58]                          
02cc6a80: ldr     x1, [x21]                                  S:'didu'
02cc6a84: mov     x0, x19                                    
02cc6a88: bl      #0x3140c84                                 fn_3140c84
02cc6a8c: str     x0, [x19, #0x48]!                          .<ParticleSystem>k__BackingField
02cc6a90: mov     x1, x0                                     
02cc6a94: mov     x0, x19                                    
02cc6a98: ldp     x20, x19, [sp, #0x10]                      
02cc6a9c: ldp     x30, x21, [sp], #0x20                      
02cc6aa0: b       #0x2b70d54                                 
## OnEnable() -> void
---- Framework.ParticleSystemCallback::OnEnable 0x2cc6aa4
02cc6aa4: strb    wzr, [x0, #0x50]                           ._triggered
02cc6aa8: ret                                                
## OnParticleCollision(UnityEngine.GameObject other) -> void
---- Framework.ParticleSystemCallback::OnParticleCollision 0x2cc6aac
02cc6aac: stp     x30, x21, [sp, #-0x20]!                    
02cc6ab0: stp     x20, x19, [sp, #0x10]                      
02cc6ab4: adrp    x21, #0x662f000                            
02cc6ab8: mov     x19, x1                                    
02cc6abc: mov     x20, x0                                    
02cc6ac0: ldrb    w8, [x21, #0xc59]                          
02cc6ac4: tbnz    w8, #0, #0x2cc6adc                         
02cc6ac8: adrp    x0, #0x6267000                             
02cc6acc: ldr     x0, [x0, #0x2e0]                           MS:UnityEngine.Events.UnityEvent`1::Invoke
02cc6ad0: bl      #0x2b70db0                                 fn_2b70db0
02cc6ad4: mov     w8, #1                                     
02cc6ad8: strb    w8, [x21, #0xc59]                          
02cc6adc: ldr     x0, [x20, #0x20]                           .EventOnParticleCollision
02cc6ae0: cbz     x0, #0x2cc6b00                             
02cc6ae4: adrp    x8, #0x6267000                             
02cc6ae8: mov     x1, x19                                    
02cc6aec: ldr     x8, [x8, #0x2e0]                           MS:UnityEngine.Events.UnityEvent`1::Invoke
02cc6af0: ldp     x20, x19, [sp, #0x10]                      
02cc6af4: ldr     x2, [x8]                                   S:'didu'
02cc6af8: ldp     x30, x21, [sp], #0x20                      
02cc6afc: b       #0x3ee674c                                 
02cc6b00: ldp     x20, x19, [sp, #0x10]                      
02cc6b04: ldp     x30, x21, [sp], #0x20                      
02cc6b08: ret                                                
## OnParticleSystemStopped() -> void
---- Framework.ParticleSystemCallback::OnParticleSystemStopped 0x2cc6b0c
02cc6b0c: ldrb    w8, [x0, #0x40]                            ._constrainOnStoppedTriggerOneTime
02cc6b10: cbz     w8, #0x2cc6b1c                             
02cc6b14: ldrb    w8, [x0, #0x50]                            ._triggered
02cc6b18: cbnz    w8, #0x2cc6b38                             
02cc6b1c: ldr     x8, [x0, #0x28]                            .EventOnParticleSystemStopped
02cc6b20: mov     w9, #1                                     
02cc6b24: strb    w9, [x0, #0x50]                            ._triggered
02cc6b28: cbz     x8, #0x2cc6b38                             
02cc6b2c: mov     x0, x8                                     
02cc6b30: mov     x1, xzr                                    
02cc6b34: b       #0x5b4d278                                 UnityEngine.Events.UnityEvent::Invoke
02cc6b38: ret                                                
## OnParticleTrigger() -> void
---- Framework.ParticleSystemCallback::OnParticleTrigger 0x2cc6b3c
02cc6b3c: ldr     x0, [x0, #0x30]                            .EventOnParticleTrigger
02cc6b40: cbz     x0, #0x2cc6b4c                             
02cc6b44: mov     x1, xzr                                    
02cc6b48: b       #0x5b4d278                                 UnityEngine.Events.UnityEvent::Invoke
02cc6b4c: ret                                                
## OnParticleUpdateJobScheduled() -> void
---- Framework.ParticleSystemCallback::OnParticleUpdateJobScheduled 0x2cc6b50
02cc6b50: ldr     x0, [x0, #0x38]                            .EventOnParticleUpdateJobScheduled
02cc6b54: cbz     x0, #0x2cc6b60                             
02cc6b58: mov     x1, xzr                                    
02cc6b5c: b       #0x5b4d278                                 UnityEngine.Events.UnityEvent::Invoke
02cc6b60: ret                                                
## .ctor() -> void
---- Framework.ParticleSystemCallback::.ctor 0x2cc6b64
02cc6b64: mov     w8, #1                                     
02cc6b68: mov     x1, xzr                                    
02cc6b6c: strb    w8, [x0, #0x40]                            ._constrainOnStoppedTriggerOneTime
02cc6b70: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
