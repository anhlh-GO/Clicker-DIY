#### CLASS Clicker.DeleteKeycapPopup/<>c__DisplayClass8_0 parent= object
#   field onConfirmDelete                System.Action                                      off=0x10 attr=6 
## .ctor() -> void
---- Clicker.DeleteKeycapPopup/<>c__DisplayClass8_0::.ctor 0x2d6adb0
02d6adb0: mov     x1, xzr                                    
02d6adb4: b       #0x4e53e9c                                 System.Object::.ctor
## <SetEventCallback>b__0() -> void
---- Clicker.DeleteKeycapPopup/<>c__DisplayClass8_0::<SetEventCallback>b__0 0x2d6b19c
02d6b19c: ldr     x8, [x0, #0x10]                            .onConfirmDelete
02d6b1a0: cbz     x8, #0x2d6b1b4                             
02d6b1a4: ldr     x0, [x8, #0x40]                            
02d6b1a8: ldr     x1, [x8, #0x28]                            
02d6b1ac: ldr     x2, [x8, #0x18]                            
02d6b1b0: br      x2                                         
02d6b1b4: ret                                                
#### CLASS Clicker.DeleteKeycapPopup parent= PopupBase
#   field _deleteCamera                  UnityEngine.GameObject                             off=0x38 attr=1 SerializeField
#   field _btnDelete                     UnityEngine.UI.Button                              off=0x40 attr=1 SerializeField
#   field _btnClose                      UnityEngine.UI.Button                              off=0x48 attr=1 SerializeField
#   field _btnClose2                     UnityEngine.UI.Button                              off=0x50 attr=1 SerializeField
#   field _tfPanel                       UnityEngine.Transform                              off=0x58 attr=1 SerializeField
#   field _onConfirmDelete               UnityEngine.Events.UnityEvent                      off=0x60 attr=1 
## OnInit(UIManager uiManager) -> void
---- Clicker.DeleteKeycapPopup::OnInit 0x2d6aa54
02d6aa54: stp     x30, x23, [sp, #-0x30]!                    
02d6aa58: stp     x22, x21, [sp, #0x10]                      
02d6aa5c: stp     x20, x19, [sp, #0x20]                      
02d6aa60: adrp    x21, #0x6630000                            
02d6aa64: mov     x20, x1                                    
02d6aa68: mov     x19, x0                                    
02d6aa6c: ldrb    w8, [x21, #0x35a]                          
02d6aa70: tbnz    w8, #0, #0x2d6aaa0                         
02d6aa74: adrp    x0, #0x626c000                             
02d6aa78: ldr     x0, [x0, #0x3c8]                           M:Clicker.DeleteKeycapPopup::OnBtnDeleteClick
02d6aa7c: bl      #0x2b70db0                                 fn_2b70db0
02d6aa80: adrp    x0, #0x626c000                             
02d6aa84: ldr     x0, [x0, #0x3d0]                           M:Clicker.DeleteKeycapPopup::OnBtnNoThankClick
02d6aa88: bl      #0x2b70db0                                 fn_2b70db0
02d6aa8c: adrp    x0, #0x6265000                             
02d6aa90: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d6aa94: bl      #0x2b70db0                                 fn_2b70db0
02d6aa98: mov     w8, #1                                     
02d6aa9c: strb    w8, [x21, #0x35a]                          
02d6aaa0: mov     x0, x19                                    
02d6aaa4: mov     x1, x20                                    
02d6aaa8: mov     x2, xzr                                    
02d6aaac: bl      #0x2cdd3c4                                 UIBase::OnInit
02d6aab0: ldr     x0, [x19, #0x38]                           ._deleteCamera
02d6aab4: cbz     x0, #0x2d6abe4                             
02d6aab8: mov     w1, wzr                                    
02d6aabc: mov     x2, xzr                                    
02d6aac0: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d6aac4: ldr     x8, [x19, #0x40]                           ._btnDelete
02d6aac8: cbz     x8, #0x2d6abe4                             
02d6aacc: ldr     x0, [x8, #0x100]                           
02d6aad0: cbz     x0, #0x2d6abe4                             
02d6aad4: mov     x1, xzr                                    
02d6aad8: bl      #0x5b4ce48                                 UnityEngine.Events.UnityEventBase::RemoveAllListeners
02d6aadc: ldr     x8, [x19, #0x48]                           ._btnClose
02d6aae0: cbz     x8, #0x2d6abe4                             
02d6aae4: ldr     x0, [x8, #0x100]                           
02d6aae8: cbz     x0, #0x2d6abe4                             
02d6aaec: mov     x1, xzr                                    
02d6aaf0: bl      #0x5b4ce48                                 UnityEngine.Events.UnityEventBase::RemoveAllListeners
02d6aaf4: ldr     x8, [x19, #0x50]                           ._btnClose2
02d6aaf8: cbz     x8, #0x2d6abe4                             
02d6aafc: ldr     x0, [x8, #0x100]                           
02d6ab00: cbz     x0, #0x2d6abe4                             
02d6ab04: mov     x1, xzr                                    
02d6ab08: bl      #0x5b4ce48                                 UnityEngine.Events.UnityEventBase::RemoveAllListeners
02d6ab0c: ldr     x8, [x19, #0x40]                           ._btnDelete
02d6ab10: cbz     x8, #0x2d6abe4                             
02d6ab14: adrp    x22, #0x6265000                            
02d6ab18: adrp    x21, #0x626c000                            
02d6ab1c: ldr     x22, [x22, #0x3f0]                         T:UnityEngine.Events.UnityAction
02d6ab20: ldr     x21, [x21, #0x3c8]                         M:Clicker.DeleteKeycapPopup::OnBtnDeleteClick
02d6ab24: ldr     x20, [x8, #0x100]                          
02d6ab28: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d6ab2c: bl      #0x2b7104c                                 fn_2b7104c
02d6ab30: ldr     x2, [x21]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6ab34: mov     x1, x19                                    
02d6ab38: mov     x3, xzr                                    
02d6ab3c: mov     x21, x0                                    
02d6ab40: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d6ab44: cbz     x20, #0x2d6abe4                            
02d6ab48: mov     x0, x20                                    
02d6ab4c: mov     x1, x21                                    
02d6ab50: mov     x2, xzr                                    
02d6ab54: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d6ab58: ldr     x8, [x19, #0x48]                           ._btnClose
02d6ab5c: cbz     x8, #0x2d6abe4                             
02d6ab60: adrp    x23, #0x626c000                            
02d6ab64: ldr     x23, [x23, #0x3d0]                         M:Clicker.DeleteKeycapPopup::OnBtnNoThankClick
02d6ab68: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d6ab6c: ldr     x20, [x8, #0x100]                          
02d6ab70: bl      #0x2b7104c                                 fn_2b7104c
02d6ab74: ldr     x2, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6ab78: mov     x1, x19                                    
02d6ab7c: mov     x3, xzr                                    
02d6ab80: mov     x21, x0                                    
02d6ab84: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d6ab88: cbz     x20, #0x2d6abe4                            
02d6ab8c: mov     x0, x20                                    
02d6ab90: mov     x1, x21                                    
02d6ab94: mov     x2, xzr                                    
02d6ab98: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d6ab9c: ldr     x8, [x19, #0x50]                           ._btnClose2
02d6aba0: cbz     x8, #0x2d6abe4                             
02d6aba4: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d6aba8: ldr     x20, [x8, #0x100]                          
02d6abac: bl      #0x2b7104c                                 fn_2b7104c
02d6abb0: ldr     x2, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6abb4: mov     x1, x19                                    
02d6abb8: mov     x3, xzr                                    
02d6abbc: mov     x21, x0                                    
02d6abc0: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d6abc4: cbz     x20, #0x2d6abe4                            
02d6abc8: mov     x0, x20                                    
02d6abcc: mov     x1, x21                                    
02d6abd0: mov     x2, xzr                                    
02d6abd4: ldp     x20, x19, [sp, #0x20]                      
02d6abd8: ldp     x22, x21, [sp, #0x10]                      
02d6abdc: ldp     x30, x23, [sp], #0x30                      
02d6abe0: b       #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d6abe4: bl      #0x2b7105c                                 fn_2b7105c
## OnShow() -> void
---- Clicker.DeleteKeycapPopup::OnShow 0x2d6abe8
02d6abe8: stp     x30, x25, [sp, #-0x40]!                    
02d6abec: stp     x24, x23, [sp, #0x10]                      
02d6abf0: stp     x22, x21, [sp, #0x20]                      
02d6abf4: stp     x20, x19, [sp, #0x30]                      
02d6abf8: adrp    x20, #0x6630000                            
02d6abfc: mov     x19, x0                                    
02d6ac00: ldrb    w8, [x20, #0x35b]                          
02d6ac04: tbnz    w8, #0, #0x2d6ac4c                         
02d6ac08: adrp    x0, #0x626c000                             
02d6ac0c: ldr     x0, [x0, #0x3d8]                           M:Clicker.DeleteKeycapPopup::<OnShow>b__7_0
02d6ac10: bl      #0x2b70db0                                 fn_2b70db0
02d6ac14: adrp    x0, #0x6265000                             
02d6ac18: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02d6ac1c: bl      #0x2b70db0                                 fn_2b70db0
02d6ac20: adrp    x0, #0x6264000                             
02d6ac24: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d6ac28: bl      #0x2b70db0                                 fn_2b70db0
02d6ac2c: adrp    x0, #0x6266000                             
02d6ac30: ldr     x0, [x0, #0x928]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d6ac34: bl      #0x2b70db0                                 fn_2b70db0
02d6ac38: adrp    x0, #0x6266000                             
02d6ac3c: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d6ac40: bl      #0x2b70db0                                 fn_2b70db0
02d6ac44: mov     w8, #1                                     
02d6ac48: strb    w8, [x20, #0x35b]                          
02d6ac4c: mov     x0, x19                                    
02d6ac50: mov     x1, xzr                                    
02d6ac54: bl      #0x2cdd6b8                                 UIBase::OnShow
02d6ac58: ldr     x0, [x19, #0x38]                           ._deleteCamera
02d6ac5c: cbz     x0, #0x2d6adac                             
02d6ac60: mov     w1, #1                                     
02d6ac64: mov     x2, xzr                                    
02d6ac68: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d6ac6c: ldr     x0, [x19, #0x40]                           ._btnDelete
02d6ac70: cbz     x0, #0x2d6adac                             
02d6ac74: mov     w1, wzr                                    
02d6ac78: mov     x2, xzr                                    
02d6ac7c: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d6ac80: ldr     x0, [x19, #0x48]                           ._btnClose
02d6ac84: cbz     x0, #0x2d6adac                             
02d6ac88: mov     w1, wzr                                    
02d6ac8c: mov     x2, xzr                                    
02d6ac90: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d6ac94: ldr     x0, [x19, #0x50]                           ._btnClose2
02d6ac98: cbz     x0, #0x2d6adac                             
02d6ac9c: mov     w1, wzr                                    
02d6aca0: mov     x2, xzr                                    
02d6aca4: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d6aca8: ldr     x0, [x19, #0x58]                           ._tfPanel
02d6acac: mov     w1, wzr                                    
02d6acb0: mov     x2, xzr                                    
02d6acb4: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d6acb8: adrp    x21, #0x662f000                            
02d6acbc: ldr     x20, [x19, #0x58]                          ._tfPanel
02d6acc0: ldrb    w8, [x21, #0x91a]                          
02d6acc4: cbnz    w8, #0x2d6acdc                             
02d6acc8: adrp    x0, #0x6264000                             
02d6accc: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d6acd0: bl      #0x2b70db0                                 fn_2b70db0
02d6acd4: mov     w8, #1                                     
02d6acd8: strb    w8, [x21, #0x91a]                          
02d6acdc: cbz     x20, #0x2d6adac                            
02d6ace0: adrp    x8, #0x6264000                             
02d6ace4: adrp    x21, #0x6266000                            
02d6ace8: adrp    x22, #0x6264000                            
02d6acec: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02d6acf0: ldr     x21, [x21, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d6acf4: ldr     x22, [x22, #0xe8]                          T:DG.Tweening.TweenCallback
02d6acf8: adrp    x23, #0x626c000                            
02d6acfc: adrp    x24, #0x6266000                            
02d6ad00: adrp    x25, #0x6265000                            
02d6ad04: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d6ad08: ldr     x23, [x23, #0x3d8]                         M:Clicker.DeleteKeycapPopup::<OnShow>b__7_0
02d6ad0c: ldr     x24, [x24, #0x928]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d6ad10: mov     x0, x20                                    
02d6ad14: mov     x1, xzr                                    
02d6ad18: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d6ad1c: ldr     x25, [x25, #0x310]                         MS:WejoyService.Singleton`1::get_Instance
02d6ad20: ldp     s1, s2, [x8, #4]                           
02d6ad24: ldr     s0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d6ad28: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d6ad2c: adrp    x8, #0x1084000                             
02d6ad30: fmov    s0, #1.00000000                            
02d6ad34: ldr     x0, [x19, #0x58]                           ._tfPanel
02d6ad38: ldr     s1, [x8, #0xf10]                           [1084f10]=4110bc863e99999a f=0.3,9.04603
02d6ad3c: mov     x1, xzr                                    
02d6ad40: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d6ad44: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6ad48: mov     w1, #0x1b                                  
02d6ad4c: bl      #0x336fa0c                                 fn_336fa0c
02d6ad50: ldr     x8, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d6ad54: mov     x20, x0                                    
02d6ad58: mov     x0, x8                                     
02d6ad5c: bl      #0x2b7104c                                 fn_2b7104c
02d6ad60: ldr     x2, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6ad64: mov     x1, x19                                    
02d6ad68: mov     x3, xzr                                    
02d6ad6c: mov     x21, x0                                    
02d6ad70: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d6ad74: ldr     x2, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6ad78: mov     x0, x20                                    
02d6ad7c: mov     x1, x21                                    
02d6ad80: bl      #0x336f26c                                 fn_336f26c
02d6ad84: ldr     x0, [x25]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d6ad88: bl      #0x3be7218                                 fn_3be7218
02d6ad8c: cbz     x0, #0x2d6adac                             
02d6ad90: ldp     x20, x19, [sp, #0x30]                      
02d6ad94: mov     w1, #4                                     
02d6ad98: ldp     x22, x21, [sp, #0x20]                      
02d6ad9c: mov     x2, xzr                                    
02d6ada0: ldp     x24, x23, [sp, #0x10]                      
02d6ada4: ldp     x30, x25, [sp], #0x40                      
02d6ada8: b       #0x2c8a650                                 AdsManager::ShowMREC
02d6adac: bl      #0x2b7105c                                 fn_2b7105c
## SetEventCallback(System.Action onConfirmDelete) -> void
---- Clicker.DeleteKeycapPopup::SetEventCallback 0x2d5d014
02d5d014: str     x30, [sp, #-0x30]!                         
02d5d018: stp     x22, x21, [sp, #0x10]                      
02d5d01c: stp     x20, x19, [sp, #0x20]                      
02d5d020: adrp    x21, #0x6630000                            
02d5d024: adrp    x22, #0x626b000                            
02d5d028: mov     x20, x1                                    
02d5d02c: ldrb    w8, [x21, #0x35c]                          
02d5d030: ldr     x22, [x22, #0xd68]                         T:Clicker.DeleteKeycapPopup/<>c__DisplayClass8_0
02d5d034: mov     x19, x0                                    
02d5d038: tbnz    w8, #0, #0x2d5d068                         
02d5d03c: adrp    x0, #0x626b000                             
02d5d040: ldr     x0, [x0, #0xd70]                           M:Clicker.DeleteKeycapPopup/<>c__DisplayClass8_0::<SetEventCallback>b__0
02d5d044: bl      #0x2b70db0                                 fn_2b70db0
02d5d048: adrp    x0, #0x626b000                             
02d5d04c: ldr     x0, [x0, #0xd68]                           T:Clicker.DeleteKeycapPopup/<>c__DisplayClass8_0
02d5d050: bl      #0x2b70db0                                 fn_2b70db0
02d5d054: adrp    x0, #0x6265000                             
02d5d058: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d5d05c: bl      #0x2b70db0                                 fn_2b70db0
02d5d060: mov     w8, #1                                     
02d5d064: strb    w8, [x21, #0x35c]                          
02d5d068: ldr     x0, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5d06c: bl      #0x2b7104c                                 fn_2b7104c
02d5d070: mov     x1, xzr                                    
02d5d074: mov     x21, x0                                    
02d5d078: bl      #0x4e53e9c                                 System.Object::.ctor
02d5d07c: cbz     x21, #0x2d5d0f0                            
02d5d080: mov     x0, x21                                    
02d5d084: mov     x1, x20                                    
02d5d088: str     x20, [x0, #0x10]!                          
02d5d08c: bl      #0x2b70d54                                 fn_2b70d54
02d5d090: ldr     x0, [x19, #0x60]                           ._onConfirmDelete
02d5d094: cbz     x0, #0x2d5d0f0                             
02d5d098: adrp    x20, #0x6265000                            
02d5d09c: adrp    x22, #0x626b000                            
02d5d0a0: mov     x1, xzr                                    
02d5d0a4: ldr     x20, [x20, #0x3f0]                         T:UnityEngine.Events.UnityAction
02d5d0a8: ldr     x22, [x22, #0xd70]                         M:Clicker.DeleteKeycapPopup/<>c__DisplayClass8_0::<SetEventCallback>b__0
02d5d0ac: bl      #0x5b4ce48                                 UnityEngine.Events.UnityEventBase::RemoveAllListeners
02d5d0b0: ldr     x0, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d5d0b4: ldr     x19, [x19, #0x60]                          ._onConfirmDelete
02d5d0b8: bl      #0x2b7104c                                 fn_2b7104c
02d5d0bc: ldr     x2, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5d0c0: mov     x1, x21                                    
02d5d0c4: mov     x3, xzr                                    
02d5d0c8: mov     x20, x0                                    
02d5d0cc: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d5d0d0: cbz     x19, #0x2d5d0f0                            
02d5d0d4: mov     x0, x19                                    
02d5d0d8: mov     x1, x20                                    
02d5d0dc: mov     x2, xzr                                    
02d5d0e0: ldp     x20, x19, [sp, #0x20]                      
02d5d0e4: ldp     x22, x21, [sp, #0x10]                      
02d5d0e8: ldr     x30, [sp], #0x30                           
02d5d0ec: b       #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d5d0f0: bl      #0x2b7105c                                 fn_2b7105c
## OnBtnDeleteClick() -> void
---- Clicker.DeleteKeycapPopup::OnBtnDeleteClick 0x2d6adb8
02d6adb8: str     x30, [sp, #-0x30]!                         
02d6adbc: stp     x22, x21, [sp, #0x10]                      
02d6adc0: stp     x20, x19, [sp, #0x20]                      
02d6adc4: adrp    x20, #0x6630000                            
02d6adc8: mov     x19, x0                                    
02d6adcc: ldrb    w8, [x20, #0x35d]                          
02d6add0: tbnz    w8, #0, #0x2d6ae0c                         
02d6add4: adrp    x0, #0x6264000                             
02d6add8: ldr     x0, [x0, #0xf90]                           T:System.Action
02d6addc: bl      #0x2b70db0                                 fn_2b70db0
02d6ade0: adrp    x0, #0x626c000                             
02d6ade4: ldr     x0, [x0, #0x3e0]                           M:Clicker.DeleteKeycapPopup::<OnBtnDeleteClick>b__9_0
02d6ade8: bl      #0x2b70db0                                 fn_2b70db0
02d6adec: adrp    x0, #0x6265000                             
02d6adf0: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02d6adf4: bl      #0x2b70db0                                 fn_2b70db0
02d6adf8: adrp    x0, #0x626c000                             
02d6adfc: ldr     x0, [x0, #0x3e8]                           S:'collection_delete'
02d6ae00: bl      #0x2b70db0                                 fn_2b70db0
02d6ae04: mov     w8, #1                                     
02d6ae08: strb    w8, [x20, #0x35d]                          
02d6ae0c: mov     x0, xzr                                    
02d6ae10: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d6ae14: cbz     x0, #0x2d6aeac                             
02d6ae18: movi    d1, #0000000000000000                      
02d6ae1c: movi    d2, #0000000000000000                      
02d6ae20: adrp    x20, #0x6265000                            
02d6ae24: fmov    s0, #1.00000000                            
02d6ae28: adrp    x21, #0x6264000                            
02d6ae2c: adrp    x22, #0x626c000                            
02d6ae30: ldr     x20, [x20, #0x310]                         MS:WejoyService.Singleton`1::get_Instance
02d6ae34: ldr     x21, [x21, #0xf90]                         T:System.Action
02d6ae38: ldr     x22, [x22, #0x3e0]                         M:Clicker.DeleteKeycapPopup::<OnBtnDeleteClick>b__9_0
02d6ae3c: mov     w1, #1                                     
02d6ae40: mov     w2, wzr                                    
02d6ae44: mov     w3, wzr                                    
02d6ae48: mov     x4, xzr                                    
02d6ae4c: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d6ae50: ldr     x0, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d6ae54: bl      #0x3be7218                                 fn_3be7218
02d6ae58: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d6ae5c: mov     x20, x0                                    
02d6ae60: mov     x0, x8                                     
02d6ae64: bl      #0x2b7104c                                 fn_2b7104c
02d6ae68: ldr     x2, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6ae6c: mov     x1, x19                                    
02d6ae70: mov     x3, xzr                                    
02d6ae74: mov     x21, x0                                    
02d6ae78: bl      #0x4d8ddbc                                 System.Action::.ctor
02d6ae7c: cbz     x20, #0x2d6aeac                            
02d6ae80: adrp    x8, #0x626c000                             
02d6ae84: mov     x0, x20                                    
02d6ae88: mov     x2, x21                                    
02d6ae8c: ldr     x8, [x8, #0x3e8]                           S:'collection_delete'
02d6ae90: ldp     x20, x19, [sp, #0x20]                      
02d6ae94: ldp     x22, x21, [sp, #0x10]                      
02d6ae98: mov     w3, wzr                                    
02d6ae9c: ldr     x1, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6aea0: mov     x4, xzr                                    
02d6aea4: ldr     x30, [sp], #0x30                           
02d6aea8: b       #0x2c89698                                 AdsManager::ShowInter
02d6aeac: bl      #0x2b7105c                                 fn_2b7105c
## OnBtnNoThankClick() -> void
---- Clicker.DeleteKeycapPopup::OnBtnNoThankClick 0x2d6aeb0
02d6aeb0: str     x30, [sp, #-0x30]!                         
02d6aeb4: stp     x22, x21, [sp, #0x10]                      
02d6aeb8: stp     x20, x19, [sp, #0x20]                      
02d6aebc: adrp    x20, #0x6630000                            
02d6aec0: mov     x19, x0                                    
02d6aec4: ldrb    w8, [x20, #0x35e]                          
02d6aec8: tbnz    w8, #0, #0x2d6af04                         
02d6aecc: adrp    x0, #0x6264000                             
02d6aed0: ldr     x0, [x0, #0xf90]                           T:System.Action
02d6aed4: bl      #0x2b70db0                                 fn_2b70db0
02d6aed8: adrp    x0, #0x626c000                             
02d6aedc: ldr     x0, [x0, #0x3f0]                           M:Clicker.DeleteKeycapPopup::<OnBtnNoThankClick>b__10_0
02d6aee0: bl      #0x2b70db0                                 fn_2b70db0
02d6aee4: adrp    x0, #0x6265000                             
02d6aee8: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02d6aeec: bl      #0x2b70db0                                 fn_2b70db0
02d6aef0: adrp    x0, #0x626c000                             
02d6aef4: ldr     x0, [x0, #0x3f8]                           S:'collection_delete_cancel'
02d6aef8: bl      #0x2b70db0                                 fn_2b70db0
02d6aefc: mov     w8, #1                                     
02d6af00: strb    w8, [x20, #0x35e]                          
02d6af04: mov     x0, xzr                                    
02d6af08: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d6af0c: cbz     x0, #0x2d6afa4                             
02d6af10: movi    d1, #0000000000000000                      
02d6af14: movi    d2, #0000000000000000                      
02d6af18: adrp    x20, #0x6265000                            
02d6af1c: fmov    s0, #1.00000000                            
02d6af20: adrp    x21, #0x6264000                            
02d6af24: adrp    x22, #0x626c000                            
02d6af28: ldr     x20, [x20, #0x310]                         MS:WejoyService.Singleton`1::get_Instance
02d6af2c: ldr     x21, [x21, #0xf90]                         T:System.Action
02d6af30: ldr     x22, [x22, #0x3f0]                         M:Clicker.DeleteKeycapPopup::<OnBtnNoThankClick>b__10_0
02d6af34: mov     w1, #1                                     
02d6af38: mov     w2, wzr                                    
02d6af3c: mov     w3, wzr                                    
02d6af40: mov     x4, xzr                                    
02d6af44: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d6af48: ldr     x0, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d6af4c: bl      #0x3be7218                                 fn_3be7218
02d6af50: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d6af54: mov     x20, x0                                    
02d6af58: mov     x0, x8                                     
02d6af5c: bl      #0x2b7104c                                 fn_2b7104c
02d6af60: ldr     x2, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6af64: mov     x1, x19                                    
02d6af68: mov     x3, xzr                                    
02d6af6c: mov     x21, x0                                    
02d6af70: bl      #0x4d8ddbc                                 System.Action::.ctor
02d6af74: cbz     x20, #0x2d6afa4                            
02d6af78: adrp    x8, #0x626c000                             
02d6af7c: mov     x0, x20                                    
02d6af80: mov     x2, x21                                    
02d6af84: ldr     x8, [x8, #0x3f8]                           S:'collection_delete_cancel'
02d6af88: ldp     x20, x19, [sp, #0x20]                      
02d6af8c: ldp     x22, x21, [sp, #0x10]                      
02d6af90: mov     w3, wzr                                    
02d6af94: ldr     x1, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6af98: mov     x4, xzr                                    
02d6af9c: ldr     x30, [sp], #0x30                           
02d6afa0: b       #0x2c89698                                 AdsManager::ShowInter
02d6afa4: bl      #0x2b7105c                                 fn_2b7105c
## OnHide() -> void
---- Clicker.DeleteKeycapPopup::OnHide 0x2d6afa8
02d6afa8: stp     x30, x21, [sp, #-0x20]!                    
02d6afac: stp     x20, x19, [sp, #0x10]                      
02d6afb0: adrp    x21, #0x6630000                            
02d6afb4: adrp    x20, #0x6265000                            
02d6afb8: mov     x19, x0                                    
02d6afbc: ldrb    w8, [x21, #0x35f]                          
02d6afc0: ldr     x20, [x20, #0x310]                         MS:WejoyService.Singleton`1::get_Instance
02d6afc4: tbnz    w8, #0, #0x2d6afdc                         
02d6afc8: adrp    x0, #0x6265000                             
02d6afcc: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02d6afd0: bl      #0x2b70db0                                 fn_2b70db0
02d6afd4: mov     w8, #1                                     
02d6afd8: strb    w8, [x21, #0x35f]                          
02d6afdc: mov     x0, x19                                    
02d6afe0: mov     x1, xzr                                    
02d6afe4: bl      #0x2cddc10                                 UIBase::OnHide
02d6afe8: ldr     x0, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d6afec: bl      #0x3be7218                                 fn_3be7218
02d6aff0: cbz     x0, #0x2d6b018                             
02d6aff4: mov     x1, xzr                                    
02d6aff8: bl      #0x2c88cec                                 AdsManager::HideMREC
02d6affc: ldr     x0, [x19, #0x38]                           ._deleteCamera
02d6b000: cbz     x0, #0x2d6b018                             
02d6b004: ldp     x20, x19, [sp, #0x10]                      
02d6b008: mov     w1, wzr                                    
02d6b00c: mov     x2, xzr                                    
02d6b010: ldp     x30, x21, [sp], #0x20                      
02d6b014: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d6b018: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Clicker.DeleteKeycapPopup::.ctor 0x2d6b01c
02d6b01c: stp     x30, x21, [sp, #-0x20]!                    
02d6b020: stp     x20, x19, [sp, #0x10]                      
02d6b024: adrp    x20, #0x6630000                            
02d6b028: adrp    x21, #0x6267000                            
02d6b02c: mov     x19, x0                                    
02d6b030: ldrb    w8, [x20, #0x360]                          
02d6b034: ldr     x21, [x21, #0xff0]                         T:UnityEngine.Events.UnityEvent
02d6b038: tbnz    w8, #0, #0x2d6b050                         
02d6b03c: adrp    x0, #0x6267000                             
02d6b040: ldr     x0, [x0, #0xff0]                           T:UnityEngine.Events.UnityEvent
02d6b044: bl      #0x2b70db0                                 fn_2b70db0
02d6b048: mov     w8, #1                                     
02d6b04c: strb    w8, [x20, #0x360]                          
02d6b050: ldr     x0, [x21]                                  S:'didu'
02d6b054: bl      #0x2b7104c                                 fn_2b7104c
02d6b058: mov     x1, xzr                                    
02d6b05c: mov     x20, x0                                    
02d6b060: bl      #0x5b4d048                                 UnityEngine.Events.UnityEvent::.ctor
02d6b064: mov     x0, x19                                    
02d6b068: mov     x1, x20                                    
02d6b06c: str     x20, [x0, #0x60]!                          ._onConfirmDelete
02d6b070: bl      #0x2b70d54                                 fn_2b70d54
02d6b074: mov     x0, x19                                    
02d6b078: ldp     x20, x19, [sp, #0x10]                      
02d6b07c: mov     x1, xzr                                    
02d6b080: ldp     x30, x21, [sp], #0x20                      
02d6b084: b       #0x2cddba8                                 PopupBase::.ctor
## <OnShow>b__7_0() -> void
---- Clicker.DeleteKeycapPopup::<OnShow>b__7_0 0x2d6b088
02d6b088: stp     x30, x19, [sp, #-0x10]!                    
02d6b08c: mov     x19, x0                                    
02d6b090: ldr     x0, [x0, #0x40]                            ._btnDelete
02d6b094: cbz     x0, #0x2d6b0d0                             
02d6b098: mov     w1, #1                                     
02d6b09c: mov     x2, xzr                                    
02d6b0a0: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d6b0a4: ldr     x0, [x19, #0x48]                           ._btnClose
02d6b0a8: cbz     x0, #0x2d6b0d0                             
02d6b0ac: mov     w1, #1                                     
02d6b0b0: mov     x2, xzr                                    
02d6b0b4: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d6b0b8: ldr     x0, [x19, #0x50]                           ._btnClose2
02d6b0bc: cbz     x0, #0x2d6b0d0                             
02d6b0c0: mov     w1, #1                                     
02d6b0c4: mov     x2, xzr                                    
02d6b0c8: ldp     x30, x19, [sp], #0x10                      
02d6b0cc: b       #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d6b0d0: bl      #0x2b7105c                                 fn_2b7105c
## <OnBtnDeleteClick>b__9_0() -> void
---- Clicker.DeleteKeycapPopup::<OnBtnDeleteClick>b__9_0 0x2d6b0d4
02d6b0d4: stp     x30, x19, [sp, #-0x10]!                    
02d6b0d8: mov     x19, x0                                    
02d6b0dc: ldr     x0, [x0, #0x40]                            ._btnDelete
02d6b0e0: cbz     x0, #0x2d6b13c                             
02d6b0e4: mov     w1, wzr                                    
02d6b0e8: mov     x2, xzr                                    
02d6b0ec: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d6b0f0: ldr     x0, [x19, #0x48]                           ._btnClose
02d6b0f4: cbz     x0, #0x2d6b13c                             
02d6b0f8: mov     w1, wzr                                    
02d6b0fc: mov     x2, xzr                                    
02d6b100: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d6b104: ldr     x0, [x19, #0x50]                           ._btnClose2
02d6b108: cbz     x0, #0x2d6b13c                             
02d6b10c: mov     w1, wzr                                    
02d6b110: mov     x2, xzr                                    
02d6b114: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d6b118: ldr     x0, [x19, #0x60]                           ._onConfirmDelete
02d6b11c: cbz     x0, #0x2d6b128                             
02d6b120: mov     x1, xzr                                    
02d6b124: bl      #0x5b4d278                                 UnityEngine.Events.UnityEvent::Invoke
02d6b128: ldr     x8, [x19]                                  
02d6b12c: mov     x0, x19                                    
02d6b130: ldp     x2, x1, [x8, #0x198]                       
02d6b134: ldp     x30, x19, [sp], #0x10                      
02d6b138: br      x2                                         
02d6b13c: bl      #0x2b7105c                                 fn_2b7105c
## <OnBtnNoThankClick>b__10_0() -> void
---- Clicker.DeleteKeycapPopup::<OnBtnNoThankClick>b__10_0 0x2d6b140
02d6b140: stp     x30, x19, [sp, #-0x10]!                    
02d6b144: mov     x19, x0                                    
02d6b148: ldr     x0, [x0, #0x40]                            ._btnDelete
02d6b14c: cbz     x0, #0x2d6b198                             
02d6b150: mov     w1, wzr                                    
02d6b154: mov     x2, xzr                                    
02d6b158: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d6b15c: ldr     x0, [x19, #0x48]                           ._btnClose
02d6b160: cbz     x0, #0x2d6b198                             
02d6b164: mov     w1, wzr                                    
02d6b168: mov     x2, xzr                                    
02d6b16c: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d6b170: ldr     x0, [x19, #0x50]                           ._btnClose2
02d6b174: cbz     x0, #0x2d6b198                             
02d6b178: mov     w1, wzr                                    
02d6b17c: mov     x2, xzr                                    
02d6b180: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d6b184: ldr     x8, [x19]                                  
02d6b188: mov     x0, x19                                    
02d6b18c: ldp     x2, x1, [x8, #0x198]                       
02d6b190: ldp     x30, x19, [sp], #0x10                      
02d6b194: br      x2                                         
02d6b198: bl      #0x2b7105c                                 fn_2b7105c
