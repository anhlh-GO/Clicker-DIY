#### CLASS KeyTest parent= object
#   field APP_OPEN_GAM                   string                                             off=0x0 attr=16 
#   field INTER_GAM                      string                                             off=0x8 attr=16 
#   field BANNER_GAM                     string                                             off=0x10 attr=16 
#   field REWARDED_GAM                   string                                             off=0x18 attr=16 
#   field NATIVE_GAM                     string                                             off=0x20 attr=16 
## .cctor() -> void
---- KeyTest::.cctor 0x2c9be34
02c9be34: stp     x30, x25, [sp, #-0x40]!                    
02c9be38: stp     x24, x23, [sp, #0x10]                      
02c9be3c: stp     x22, x21, [sp, #0x20]                      
02c9be40: stp     x20, x19, [sp, #0x30]                      
02c9be44: adrp    x24, #0x6265000                            
02c9be48: adrp    x19, #0x6265000                            
02c9be4c: adrp    x23, #0x6265000                            
02c9be50: adrp    x25, #0x662f000                            
02c9be54: adrp    x22, #0x6265000                            
02c9be58: adrp    x21, #0x6265000                            
02c9be5c: adrp    x20, #0x6265000                            
02c9be60: ldr     x24, [x24, #0xae8]                         S:'ca-app-pub-3940256099942544/9257395921'
02c9be64: ldr     x19, [x19, #0x488]                         T:KeyTest
02c9be68: ldr     x23, [x23, #0xaf0]                         S:'ca-app-pub-3940256099942544/1033173712'
02c9be6c: ldr     x22, [x22, #0xaf8]                         S:'ca-app-pub-3940256099942544/6300978111'
02c9be70: ldrb    w8, [x25, #0xa4a]                          
02c9be74: ldr     x21, [x21, #0xb00]                         S:'ca-app-pub-3940256099942544/5224354917'
02c9be78: ldr     x20, [x20, #0xb08]                         S:'ca-app-pub-3940256099942544/2247696110'
02c9be7c: tbnz    w8, #0, #0x2c9bed0                         
02c9be80: adrp    x0, #0x6265000                             
02c9be84: ldr     x0, [x0, #0x488]                           T:KeyTest
02c9be88: bl      #0x2b70db0                                 fn_2b70db0
02c9be8c: adrp    x0, #0x6265000                             
02c9be90: ldr     x0, [x0, #0xb00]                           S:'ca-app-pub-3940256099942544/5224354917'
02c9be94: bl      #0x2b70db0                                 fn_2b70db0
02c9be98: adrp    x0, #0x6265000                             
02c9be9c: ldr     x0, [x0, #0xae8]                           S:'ca-app-pub-3940256099942544/9257395921'
02c9bea0: bl      #0x2b70db0                                 fn_2b70db0
02c9bea4: adrp    x0, #0x6265000                             
02c9bea8: ldr     x0, [x0, #0xb08]                           S:'ca-app-pub-3940256099942544/2247696110'
02c9beac: bl      #0x2b70db0                                 fn_2b70db0
02c9beb0: adrp    x0, #0x6265000                             
02c9beb4: ldr     x0, [x0, #0xaf0]                           S:'ca-app-pub-3940256099942544/1033173712'
02c9beb8: bl      #0x2b70db0                                 fn_2b70db0
02c9bebc: adrp    x0, #0x6265000                             
02c9bec0: ldr     x0, [x0, #0xaf8]                           S:'ca-app-pub-3940256099942544/6300978111'
02c9bec4: bl      #0x2b70db0                                 fn_2b70db0
02c9bec8: mov     w8, #1                                     
02c9becc: strb    w8, [x25, #0xa4a]                          
02c9bed0: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9bed4: ldr     x1, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9bed8: ldr     x8, [x8, #0xb8]                            
02c9bedc: str     x1, [x8]                                   
02c9bee0: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9bee4: ldr     x0, [x8, #0xb8]                            
02c9bee8: bl      #0x2b70d54                                 fn_2b70d54
02c9beec: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9bef0: ldr     x1, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9bef4: ldr     x0, [x8, #0xb8]                            
02c9bef8: str     x1, [x0, #8]!                              
02c9befc: bl      #0x2b70d54                                 fn_2b70d54
02c9bf00: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9bf04: ldr     x1, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9bf08: ldr     x0, [x8, #0xb8]                            
02c9bf0c: str     x1, [x0, #0x10]!                           .BANNER_GAM
02c9bf10: bl      #0x2b70d54                                 fn_2b70d54
02c9bf14: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9bf18: ldr     x1, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9bf1c: ldr     x0, [x8, #0xb8]                            
02c9bf20: str     x1, [x0, #0x18]!                           .REWARDED_GAM
02c9bf24: bl      #0x2b70d54                                 fn_2b70d54
02c9bf28: ldr     x8, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9bf2c: ldr     x1, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9bf30: ldp     x20, x19, [sp, #0x30]                      
02c9bf34: ldr     x0, [x8, #0xb8]                            
02c9bf38: ldp     x22, x21, [sp, #0x20]                      
02c9bf3c: ldp     x24, x23, [sp, #0x10]                      
02c9bf40: str     x1, [x0, #0x20]!                           .NATIVE_GAM
02c9bf44: ldp     x30, x25, [sp], #0x40                      
02c9bf48: b       #0x2b70d54                                 
