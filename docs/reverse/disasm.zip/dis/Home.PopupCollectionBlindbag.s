#### CLASS Home.PopupCollectionBlindbag/<>c parent= object
#   field <>9                            Home.PopupCollectionBlindbag/<>c                   off=0x0 attr=36 
#   field <>9__7_0                       System.Action                                      off=0x8 attr=16 
## .cctor() -> void
---- Home.PopupCollectionBlindbag/<>c::.cctor 0x2d1f444
02d1f444: str     x30, [sp, #-0x20]!                         
02d1f448: stp     x20, x19, [sp, #0x10]                      
02d1f44c: adrp    x19, #0x6630000                            
02d1f450: adrp    x20, #0x6269000                            
02d1f454: ldrb    w8, [x19, #0x3c]                           
02d1f458: ldr     x20, [x20, #0xd70]                         T:Home.PopupCollectionBlindbag/<>c
02d1f45c: tbnz    w8, #0, #0x2d1f474                         
02d1f460: adrp    x0, #0x6269000                             
02d1f464: ldr     x0, [x0, #0xd70]                           T:Home.PopupCollectionBlindbag/<>c
02d1f468: bl      #0x2b70db0                                 fn_2b70db0
02d1f46c: mov     w8, #1                                     
02d1f470: strb    w8, [x19, #0x3c]                           
02d1f474: ldr     x0, [x20]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1f478: bl      #0x2b7104c                                 fn_2b7104c
02d1f47c: mov     x1, xzr                                    
02d1f480: mov     x19, x0                                    
02d1f484: bl      #0x4e53e9c                                 System.Object::.ctor
02d1f488: ldr     x8, [x20]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1f48c: mov     x1, x19                                    
02d1f490: ldr     x8, [x8, #0xb8]                            
02d1f494: str     x19, [x8]                                  
02d1f498: ldr     x8, [x20]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1f49c: ldp     x20, x19, [sp, #0x10]                      
02d1f4a0: ldr     x0, [x8, #0xb8]                            
02d1f4a4: ldr     x30, [sp], #0x20                           
02d1f4a8: b       #0x2b70d54                                 
## .ctor() -> void
---- Home.PopupCollectionBlindbag/<>c::.ctor 0x2d1f4ac
02d1f4ac: mov     x1, xzr                                    
02d1f4b0: b       #0x4e53e9c                                 System.Object::.ctor
## <OnBtnBackClick>b__7_0() -> void
---- Home.PopupCollectionBlindbag/<>c::<OnBtnBackClick>b__7_0 0x2d1f4b4
02d1f4b4: ret                                                
#### CLASS Home.PopupCollectionBlindbag parent= PopupBase
#   field _backButton                    UnityEngine.UI.Button                              off=0x38 attr=1 SerializeField
#   field _playButton                    UnityEngine.UI.Button                              off=0x40 attr=1 SerializeField
#   field _blindBagCollection            BlindBagCollection.CollectionSelector              off=0x48 attr=1 SerializeField
#   field _homeController                Home.HomeController                                off=0x50 attr=1 SerializeField
#   field _physics2DRaycaster            UnityEngine.EventSystems.Physics2DRaycaster        off=0x58 attr=1 SerializeField
## OnInit(UIManager uiManager) -> void
---- Home.PopupCollectionBlindbag::OnInit 0x2d1ec60
02d1ec60: str     x30, [sp, #-0x30]!                         
02d1ec64: stp     x22, x21, [sp, #0x10]                      
02d1ec68: stp     x20, x19, [sp, #0x20]                      
02d1ec6c: adrp    x22, #0x6630000                            
02d1ec70: adrp    x21, #0x6269000                            
02d1ec74: mov     x20, x1                                    
02d1ec78: ldrb    w8, [x22, #0x37]                           
02d1ec7c: ldr     x21, [x21, #0xd50]                         MS:Framework.GameObjectExtension::SetActive
02d1ec80: mov     x19, x0                                    
02d1ec84: tbnz    w8, #0, #0x2d1ecc0                         
02d1ec88: adrp    x0, #0x6269000                             
02d1ec8c: ldr     x0, [x0, #0xd50]                           MS:Framework.GameObjectExtension::SetActive
02d1ec90: bl      #0x2b70db0                                 fn_2b70db0
02d1ec94: adrp    x0, #0x6269000                             
02d1ec98: ldr     x0, [x0, #0xd58]                           M:Home.PopupCollectionBlindbag::OnBtnBackClick
02d1ec9c: bl      #0x2b70db0                                 fn_2b70db0
02d1eca0: adrp    x0, #0x6269000                             
02d1eca4: ldr     x0, [x0, #0xd60]                           M:Home.PopupCollectionBlindbag::OnButtonPlayClicked
02d1eca8: bl      #0x2b70db0                                 fn_2b70db0
02d1ecac: adrp    x0, #0x6265000                             
02d1ecb0: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d1ecb4: bl      #0x2b70db0                                 fn_2b70db0
02d1ecb8: mov     w8, #1                                     
02d1ecbc: strb    w8, [x22, #0x37]                           
02d1ecc0: mov     x0, x19                                    
02d1ecc4: mov     x1, x20                                    
02d1ecc8: mov     x2, xzr                                    
02d1eccc: bl      #0x2cdd3c4                                 UIBase::OnInit
02d1ecd0: ldr     x0, [x19, #0x48]                           ._blindBagCollection
02d1ecd4: ldr     x2, [x21]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1ecd8: mov     w1, wzr                                    
02d1ecdc: bl      #0x31d24a4                                 fn_31d24a4
02d1ece0: ldr     x8, [x19, #0x38]                           ._backButton
02d1ece4: cbz     x8, #0x2d1edac                             
02d1ece8: ldr     x0, [x8, #0x100]                           
02d1ecec: cbz     x0, #0x2d1edac                             
02d1ecf0: mov     x1, xzr                                    
02d1ecf4: bl      #0x5b4ce48                                 UnityEngine.Events.UnityEventBase::RemoveAllListeners
02d1ecf8: ldr     x8, [x19, #0x38]                           ._backButton
02d1ecfc: cbz     x8, #0x2d1edac                             
02d1ed00: adrp    x22, #0x6265000                            
02d1ed04: adrp    x21, #0x6269000                            
02d1ed08: ldr     x22, [x22, #0x3f0]                         T:UnityEngine.Events.UnityAction
02d1ed0c: ldr     x21, [x21, #0xd58]                         M:Home.PopupCollectionBlindbag::OnBtnBackClick
02d1ed10: ldr     x20, [x8, #0x100]                          
02d1ed14: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d1ed18: bl      #0x2b7104c                                 fn_2b7104c
02d1ed1c: ldr     x2, [x21]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1ed20: mov     x1, x19                                    
02d1ed24: mov     x3, xzr                                    
02d1ed28: mov     x21, x0                                    
02d1ed2c: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d1ed30: cbz     x20, #0x2d1edac                            
02d1ed34: mov     x0, x20                                    
02d1ed38: mov     x1, x21                                    
02d1ed3c: mov     x2, xzr                                    
02d1ed40: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d1ed44: ldr     x8, [x19, #0x40]                           ._playButton
02d1ed48: cbz     x8, #0x2d1edac                             
02d1ed4c: ldr     x0, [x8, #0x100]                           
02d1ed50: cbz     x0, #0x2d1edac                             
02d1ed54: mov     x1, xzr                                    
02d1ed58: bl      #0x5b4ce48                                 UnityEngine.Events.UnityEventBase::RemoveAllListeners
02d1ed5c: ldr     x8, [x19, #0x40]                           ._playButton
02d1ed60: cbz     x8, #0x2d1edac                             
02d1ed64: adrp    x21, #0x6269000                            
02d1ed68: ldr     x21, [x21, #0xd60]                         M:Home.PopupCollectionBlindbag::OnButtonPlayClicked
02d1ed6c: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d1ed70: ldr     x20, [x8, #0x100]                          
02d1ed74: bl      #0x2b7104c                                 fn_2b7104c
02d1ed78: ldr     x2, [x21]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1ed7c: mov     x1, x19                                    
02d1ed80: mov     x3, xzr                                    
02d1ed84: mov     x21, x0                                    
02d1ed88: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d1ed8c: cbz     x20, #0x2d1edac                            
02d1ed90: mov     x0, x20                                    
02d1ed94: mov     x1, x21                                    
02d1ed98: mov     x2, xzr                                    
02d1ed9c: ldp     x20, x19, [sp, #0x20]                      
02d1eda0: ldp     x22, x21, [sp, #0x10]                      
02d1eda4: ldr     x30, [sp], #0x30                           
02d1eda8: b       #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d1edac: bl      #0x2b7105c                                 fn_2b7105c
## OnShow() -> void
---- Home.PopupCollectionBlindbag::OnShow 0x2d1edb0
02d1edb0: str     x30, [sp, #-0x30]!                         
02d1edb4: stp     x22, x21, [sp, #0x10]                      
02d1edb8: stp     x20, x19, [sp, #0x20]                      
02d1edbc: adrp    x22, #0x6630000                            
02d1edc0: adrp    x21, #0x6269000                            
02d1edc4: adrp    x20, #0x6269000                            
02d1edc8: ldrb    w8, [x22, #0x38]                           
02d1edcc: ldr     x21, [x21, #0xd50]                         MS:Framework.GameObjectExtension::SetActive
02d1edd0: ldr     x20, [x20, #0xd68]                         MS:Framework.GameObjectExtension::SetActive
02d1edd4: mov     x19, x0                                    
02d1edd8: tbnz    w8, #0, #0x2d1edfc                         
02d1eddc: adrp    x0, #0x6269000                             
02d1ede0: ldr     x0, [x0, #0xd50]                           MS:Framework.GameObjectExtension::SetActive
02d1ede4: bl      #0x2b70db0                                 fn_2b70db0
02d1ede8: adrp    x0, #0x6269000                             
02d1edec: ldr     x0, [x0, #0xd68]                           MS:Framework.GameObjectExtension::SetActive
02d1edf0: bl      #0x2b70db0                                 fn_2b70db0
02d1edf4: mov     w8, #1                                     
02d1edf8: strb    w8, [x22, #0x38]                           
02d1edfc: mov     x0, x19                                    
02d1ee00: mov     x1, xzr                                    
02d1ee04: bl      #0x2cdd6b8                                 UIBase::OnShow
02d1ee08: ldr     x0, [x19, #0x48]                           ._blindBagCollection
02d1ee0c: ldr     x2, [x21]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1ee10: mov     w1, #1                                     
02d1ee14: bl      #0x31d24a4                                 fn_31d24a4
02d1ee18: ldr     x0, [x19, #0x50]                           ._homeController
02d1ee1c: ldr     x2, [x20]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1ee20: mov     w1, wzr                                    
02d1ee24: bl      #0x31d24a4                                 fn_31d24a4
02d1ee28: ldr     x0, [x19, #0x58]                           ._physics2DRaycaster
02d1ee2c: cbz     x0, #0x2d1ee48                             
02d1ee30: ldp     x20, x19, [sp, #0x20]                      
02d1ee34: mov     w1, #1                                     
02d1ee38: ldp     x22, x21, [sp, #0x10]                      
02d1ee3c: mov     x2, xzr                                    
02d1ee40: ldr     x30, [sp], #0x30                           
02d1ee44: b       #0x5b33110                                 UnityEngine.Behaviour::set_enabled
02d1ee48: bl      #0x2b7105c                                 fn_2b7105c
## OnBtnBackClick() -> void
---- Home.PopupCollectionBlindbag::OnBtnBackClick 0x2d1ee4c
02d1ee4c: str     x30, [sp, #-0x40]!                         
02d1ee50: stp     x24, x23, [sp, #0x10]                      
02d1ee54: stp     x22, x21, [sp, #0x20]                      
02d1ee58: stp     x20, x19, [sp, #0x30]                      
02d1ee5c: adrp    x21, #0x6630000                            
02d1ee60: adrp    x20, #0x6265000                            
02d1ee64: adrp    x24, #0x6269000                            
02d1ee68: ldrb    w8, [x21, #0x39]                           
02d1ee6c: ldr     x20, [x20, #0x310]                         MS:WejoyService.Singleton`1::get_Instance
02d1ee70: ldr     x24, [x24, #0xd70]                         T:Home.PopupCollectionBlindbag/<>c
02d1ee74: mov     x19, x0                                    
02d1ee78: tbnz    w8, #0, #0x2d1eef0                         
02d1ee7c: adrp    x0, #0x6264000                             
02d1ee80: ldr     x0, [x0, #0xf90]                           T:System.Action
02d1ee84: bl      #0x2b70db0                                 fn_2b70db0
02d1ee88: adrp    x0, #0x6269000                             
02d1ee8c: ldr     x0, [x0, #0xd50]                           MS:Framework.GameObjectExtension::SetActive
02d1ee90: bl      #0x2b70db0                                 fn_2b70db0
02d1ee94: adrp    x0, #0x6269000                             
02d1ee98: ldr     x0, [x0, #0xd68]                           MS:Framework.GameObjectExtension::SetActive
02d1ee9c: bl      #0x2b70db0                                 fn_2b70db0
02d1eea0: adrp    x0, #0x6266000                             
02d1eea4: ldr     x0, [x0, #0xac0]                           MS:MonoSingleton`1::get_Instance
02d1eea8: bl      #0x2b70db0                                 fn_2b70db0
02d1eeac: adrp    x0, #0x6265000                             
02d1eeb0: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02d1eeb4: bl      #0x2b70db0                                 fn_2b70db0
02d1eeb8: adrp    x0, #0x6269000                             
02d1eebc: ldr     x0, [x0, #0xd78]                           M:Home.PopupCollectionBlindbag/<>c::<OnBtnBackClick>b__7_0
02d1eec0: bl      #0x2b70db0                                 fn_2b70db0
02d1eec4: adrp    x0, #0x6269000                             
02d1eec8: ldr     x0, [x0, #0xd70]                           T:Home.PopupCollectionBlindbag/<>c
02d1eecc: bl      #0x2b70db0                                 fn_2b70db0
02d1eed0: adrp    x0, #0x6269000                             
02d1eed4: ldr     x0, [x0, #0xd80]                           MS:UIManager::GetPopup
02d1eed8: bl      #0x2b70db0                                 fn_2b70db0
02d1eedc: adrp    x0, #0x6269000                             
02d1eee0: ldr     x0, [x0, #0xd88]                           S:'blind_bag_back_click'
02d1eee4: bl      #0x2b70db0                                 fn_2b70db0
02d1eee8: mov     w8, #1                                     
02d1eeec: strb    w8, [x21, #0x39]                           
02d1eef0: adrp    x21, #0x6269000                            
02d1eef4: mov     x0, xzr                                    
02d1eef8: ldr     x21, [x21, #0xd88]                         S:'blind_bag_back_click'
02d1eefc: bl      #0x2d6ff04                                 Framework.AudioHelper::PlayClickSound
02d1ef00: ldr     x0, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d1ef04: bl      #0x3be7218                                 fn_3be7218
02d1ef08: ldr     x8, [x24]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1ef0c: mov     x20, x0                                    
02d1ef10: ldr     w9, [x8, #0xe4]                            
02d1ef14: cbnz    w9, #0x2d1ef24                             
02d1ef18: mov     x0, x8                                     
02d1ef1c: bl      #0x2b70f30                                 fn_2b70f30
02d1ef20: ldr     x8, [x24]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1ef24: ldr     x9, [x8, #0xb8]                            
02d1ef28: ldr     x21, [x21]                                 T:Trading.TradingSession/<>c__DisplayClass56_0
02d1ef2c: ldr     x22, [x9, #8]                              
02d1ef30: cbnz    x22, #0x2d1ef90                            
02d1ef34: ldr     w10, [x8, #0xe4]                           
02d1ef38: cbnz    w10, #0x2d1ef4c                            
02d1ef3c: mov     x0, x8                                     
02d1ef40: bl      #0x2b70f30                                 fn_2b70f30
02d1ef44: ldr     x8, [x24]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1ef48: ldr     x9, [x8, #0xb8]                            
02d1ef4c: adrp    x8, #0x6264000                             
02d1ef50: ldr     x8, [x8, #0xf90]                           T:System.Action
02d1ef54: ldr     x23, [x9]                                  
02d1ef58: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d1ef5c: bl      #0x2b7104c                                 fn_2b7104c
02d1ef60: adrp    x8, #0x6269000                             
02d1ef64: mov     x1, x23                                    
02d1ef68: mov     x3, xzr                                    
02d1ef6c: ldr     x8, [x8, #0xd78]                           M:Home.PopupCollectionBlindbag/<>c::<OnBtnBackClick>b__7_0
02d1ef70: mov     x22, x0                                    
02d1ef74: ldr     x2, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d1ef78: bl      #0x4d8ddbc                                 System.Action::.ctor
02d1ef7c: ldr     x8, [x24]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1ef80: mov     x1, x22                                    
02d1ef84: ldr     x0, [x8, #0xb8]                            T:Trading.TradingSession/<>c__DisplayClass68_0
02d1ef88: str     x22, [x0, #8]!                             
02d1ef8c: bl      #0x2b70d54                                 fn_2b70d54
02d1ef90: cbz     x20, #0x2d1f054                            
02d1ef94: adrp    x23, #0x6266000                            
02d1ef98: mov     x0, x20                                    
02d1ef9c: mov     x1, x21                                    
02d1efa0: ldr     x23, [x23, #0xac0]                         MS:MonoSingleton`1::get_Instance
02d1efa4: mov     x2, x22                                    
02d1efa8: mov     w3, #1                                     
02d1efac: mov     x4, xzr                                    
02d1efb0: bl      #0x2c89698                                 AdsManager::ShowInter
02d1efb4: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1efb8: bl      #0x3769600                                 fn_3769600
02d1efbc: cbz     x0, #0x2d1f054                             
02d1efc0: adrp    x20, #0x6269000                            
02d1efc4: mov     w1, #1                                     
02d1efc8: mov     x2, xzr                                    
02d1efcc: ldr     x20, [x20, #0xd68]                         MS:Framework.GameObjectExtension::SetActive
02d1efd0: bl      #0x2cacd8c                                 GameSession::SetActiveCharacter
02d1efd4: ldr     x0, [x19, #0x50]                           ._homeController
02d1efd8: ldr     x2, [x20]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1efdc: mov     w1, #1                                     
02d1efe0: bl      #0x31d24a4                                 fn_31d24a4
02d1efe4: ldr     x8, [x19]                                  
02d1efe8: mov     x0, x19                                    
02d1efec: ldp     x9, x1, [x8, #0x198]                       
02d1eff0: blr     x9                                         
02d1eff4: ldr     x0, [x19, #0x58]                           ._physics2DRaycaster
02d1eff8: cbz     x0, #0x2d1f054                             
02d1effc: adrp    x20, #0x6269000                            
02d1f000: mov     w1, wzr                                    
02d1f004: mov     x2, xzr                                    
02d1f008: ldr     x20, [x20, #0xd50]                         MS:Framework.GameObjectExtension::SetActive
02d1f00c: bl      #0x5b33110                                 UnityEngine.Behaviour::set_enabled
02d1f010: ldr     x0, [x19, #0x48]                           ._blindBagCollection
02d1f014: ldr     x2, [x20]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1f018: mov     w1, wzr                                    
02d1f01c: bl      #0x31d24a4                                 fn_31d24a4
02d1f020: ldr     x0, [x19, #0x30]                           
02d1f024: cbz     x0, #0x2d1f054                             
02d1f028: adrp    x8, #0x6269000                             
02d1f02c: ldr     x8, [x8, #0xd80]                           MS:UIManager::GetPopup
02d1f030: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d1f034: bl      #0x33fbae4                                 fn_33fbae4
02d1f038: cbz     x0, #0x2d1f054                             
02d1f03c: ldp     x20, x19, [sp, #0x30]                      
02d1f040: mov     w1, #1                                     
02d1f044: ldp     x22, x21, [sp, #0x20]                      
02d1f048: ldp     x24, x23, [sp, #0x10]                      
02d1f04c: ldr     x30, [sp], #0x40                           
02d1f050: b       #0x2d1f058                                 Home.PopupIntroBlindbag::ShowVisual
02d1f054: bl      #0x2b7105c                                 fn_2b7105c
## OnButtonPlayClicked() -> void
---- Home.PopupCollectionBlindbag::OnButtonPlayClicked 0x2d1f0bc
02d1f0bc: str     x30, [sp, #-0x30]!                         
02d1f0c0: stp     x22, x21, [sp, #0x10]                      
02d1f0c4: stp     x20, x19, [sp, #0x20]                      
02d1f0c8: adrp    x20, #0x6630000                            
02d1f0cc: mov     x19, x0                                    
02d1f0d0: ldrb    w8, [x20, #0x3a]                           
02d1f0d4: tbnz    w8, #0, #0x2d1f11c                         
02d1f0d8: adrp    x0, #0x6264000                             
02d1f0dc: ldr     x0, [x0, #0xf90]                           T:System.Action
02d1f0e0: bl      #0x2b70db0                                 fn_2b70db0
02d1f0e4: adrp    x0, #0x6267000                             
02d1f0e8: ldr     x0, [x0, #0xd50]                           MS:MonoSingleton`1::get_Instance
02d1f0ec: bl      #0x2b70db0                                 fn_2b70db0
02d1f0f0: adrp    x0, #0x6269000                             
02d1f0f4: ldr     x0, [x0, #0xd90]                           M:Home.PopupCollectionBlindbag::<OnButtonPlayClicked>b__8_0
02d1f0f8: bl      #0x2b70db0                                 fn_2b70db0
02d1f0fc: adrp    x0, #0x6265000                             
02d1f100: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02d1f104: bl      #0x2b70db0                                 fn_2b70db0
02d1f108: adrp    x0, #0x6269000                             
02d1f10c: ldr     x0, [x0, #0xd98]                           S:'blind_bag_play_click'
02d1f110: bl      #0x2b70db0                                 fn_2b70db0
02d1f114: mov     w8, #1                                     
02d1f118: strb    w8, [x20, #0x3a]                           
02d1f11c: mov     x0, xzr                                    
02d1f120: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d1f124: cbz     x0, #0x2d1f1dc                             
02d1f128: movi    d1, #0000000000000000                      
02d1f12c: movi    d2, #0000000000000000                      
02d1f130: adrp    x20, #0x6267000                            
02d1f134: fmov    s0, #1.00000000                            
02d1f138: ldr     x20, [x20, #0xd50]                         MS:MonoSingleton`1::get_Instance
02d1f13c: mov     w1, #1                                     
02d1f140: mov     w2, wzr                                    
02d1f144: mov     w3, wzr                                    
02d1f148: mov     x4, xzr                                    
02d1f14c: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d1f150: ldr     x0, [x20]                                  S:'didu'
02d1f154: bl      #0x3769600                                 fn_3769600
02d1f158: cbz     x0, #0x2d1f1dc                             
02d1f15c: adrp    x20, #0x6265000                            
02d1f160: adrp    x21, #0x6264000                            
02d1f164: adrp    x22, #0x6269000                            
02d1f168: ldr     x20, [x20, #0x310]                         MS:WejoyService.Singleton`1::get_Instance
02d1f16c: ldr     x21, [x21, #0xf90]                         T:System.Action
02d1f170: ldr     x22, [x22, #0xd90]                         M:Home.PopupCollectionBlindbag::<OnButtonPlayClicked>b__8_0
02d1f174: mov     w1, #4                                     
02d1f178: mov     x2, xzr                                    
02d1f17c: bl      #0x2cc6ee0                                 Framework.VibrationManager::Haptic
02d1f180: ldr     x0, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d1f184: bl      #0x3be7218                                 fn_3be7218
02d1f188: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d1f18c: mov     x20, x0                                    
02d1f190: mov     x0, x8                                     
02d1f194: bl      #0x2b7104c                                 fn_2b7104c
02d1f198: ldr     x2, [x22]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1f19c: mov     x1, x19                                    
02d1f1a0: mov     x3, xzr                                    
02d1f1a4: mov     x21, x0                                    
02d1f1a8: bl      #0x4d8ddbc                                 System.Action::.ctor
02d1f1ac: cbz     x20, #0x2d1f1dc                            
02d1f1b0: adrp    x8, #0x6269000                             
02d1f1b4: mov     x0, x20                                    
02d1f1b8: mov     x2, x21                                    
02d1f1bc: ldr     x8, [x8, #0xd98]                           S:'blind_bag_play_click'
02d1f1c0: ldp     x20, x19, [sp, #0x20]                      
02d1f1c4: ldp     x22, x21, [sp, #0x10]                      
02d1f1c8: mov     w3, #1                                     
02d1f1cc: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d1f1d0: mov     x4, xzr                                    
02d1f1d4: ldr     x30, [sp], #0x30                           
02d1f1d8: b       #0x2c89698                                 AdsManager::ShowInter
02d1f1dc: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Home.PopupCollectionBlindbag::.ctor 0x2d1f1e0
02d1f1e0: mov     x1, xzr                                    
02d1f1e4: b       #0x2cddba8                                 PopupBase::.ctor
## <OnButtonPlayClicked>b__8_0() -> void
---- Home.PopupCollectionBlindbag::<OnButtonPlayClicked>b__8_0 0x2d1f1e8
02d1f1e8: str     x30, [sp, #-0x30]!                         
02d1f1ec: stp     x22, x21, [sp, #0x10]                      
02d1f1f0: stp     x20, x19, [sp, #0x20]                      
02d1f1f4: adrp    x20, #0x6630000                            
02d1f1f8: mov     x19, x0                                    
02d1f1fc: ldrb    w8, [x20, #0x3b]                           
02d1f200: tbnz    w8, #0, #0x2d1f254                         
02d1f204: adrp    x0, #0x6266000                             
02d1f208: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d1f20c: bl      #0x2b70db0                                 fn_2b70db0
02d1f210: adrp    x0, #0x6265000                             
02d1f214: ldr     x0, [x0, #0xb38]                           T:DevTrack
02d1f218: bl      #0x2b70db0                                 fn_2b70db0
02d1f21c: adrp    x0, #0x6266000                             
02d1f220: ldr     x0, [x0, #0x5e0]                           T:GameConfig
02d1f224: bl      #0x2b70db0                                 fn_2b70db0
02d1f228: adrp    x0, #0x6265000                             
02d1f22c: ldr     x0, [x0, #0x10]                            MS:MonoSingleton`1::get_Instance
02d1f230: bl      #0x2b70db0                                 fn_2b70db0
02d1f234: adrp    x0, #0x6266000                             
02d1f238: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d1f23c: bl      #0x2b70db0                                 fn_2b70db0
02d1f240: adrp    x0, #0x6266000                             
02d1f244: ldr     x0, [x0, #0xb48]                           MS:MonoSingleton`1::get_Instance
02d1f248: bl      #0x2b70db0                                 fn_2b70db0
02d1f24c: mov     w8, #1                                     
02d1f250: strb    w8, [x20, #0x3b]                           
02d1f254: ldr     x0, [x19, #0x40]                           ._playButton
02d1f258: cbz     x0, #0x2d1f440                             
02d1f25c: mov     w1, wzr                                    
02d1f260: mov     x2, xzr                                    
02d1f264: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d1f268: ldr     x0, [x19, #0x38]                           ._backButton
02d1f26c: cbz     x0, #0x2d1f440                             
02d1f270: adrp    x19, #0x6265000                            
02d1f274: adrp    x20, #0x6266000                            
02d1f278: mov     w1, wzr                                    
02d1f27c: ldr     x19, [x19, #0x10]                          MS:MonoSingleton`1::get_Instance
02d1f280: ldr     x20, [x20, #0x5e0]                         T:GameConfig
02d1f284: mov     x2, xzr                                    
02d1f288: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d1f28c: ldr     x0, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d1f290: bl      #0x3769600                                 fn_3769600
02d1f294: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1f298: mov     x19, x0                                    
02d1f29c: ldr     w9, [x8, #0xe4]                            
02d1f2a0: cbnz    w9, #0x2d1f2ac                             
02d1f2a4: mov     x0, x8                                     
02d1f2a8: bl      #0x2b70f30                                 fn_2b70f30
02d1f2ac: cbz     x19, #0x2d1f440                            
02d1f2b0: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1f2b4: adrp    x20, #0x6266000                            
02d1f2b8: mov     x0, x19                                    
02d1f2bc: mov     w2, wzr                                    
02d1f2c0: mov     x3, xzr                                    
02d1f2c4: ldr     x8, [x8, #0xb8]                            
02d1f2c8: ldr     x20, [x20, #0x658]                         MS:MonoSingleton`1::get_Instance
02d1f2cc: ldr     x1, [x8, #0x18]                            
02d1f2d0: bl      #0x2ce9e58                                 SimpleSceneTransition::FlashIn
02d1f2d4: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1f2d8: bl      #0x3769600                                 fn_3769600
02d1f2dc: cbz     x0, #0x2d1f440                             
02d1f2e0: adrp    x8, #0x6266000                             
02d1f2e4: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02d1f2e8: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1f2ec: bl      #0x3168dd0                                 fn_3168dd0
02d1f2f0: cbz     x0, #0x2d1f440                             
02d1f2f4: ldr     x8, [x0, #0x20]                            S:'inter_ad_capping_time'
02d1f2f8: mov     x19, x0                                    
02d1f2fc: cbz     x8, #0x2d1f440                             
02d1f300: adrp    x21, #0x6266000                            
02d1f304: ldrb    w8, [x8, #0x45]                            
02d1f308: ldr     x21, [x21, #0xb48]                         MS:MonoSingleton`1::get_Instance
02d1f30c: cbnz    w8, #0x2d1f32c                             
02d1f310: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1f314: bl      #0x3769600                                 fn_3769600
02d1f318: mov     x20, x0                                    
02d1f31c: mov     x0, xzr                                    
02d1f320: bl      #0x5b432fc                                 UnityEngine.Time::get_time
02d1f324: cbz     x20, #0x2d1f440                            
02d1f328: str     s0, [x20, #0x28]                           
02d1f32c: adrp    x22, #0x6265000                            
02d1f330: ldr     x22, [x22, #0xb38]                         T:DevTrack
02d1f334: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1f338: bl      #0x3769600                                 fn_3769600
02d1f33c: ldr     x8, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d1f340: mov     x20, x0                                    
02d1f344: ldr     w9, [x8, #0xe4]                            [62660e4]=0 f=0,0
02d1f348: cbnz    w9, #0x2d1f354                             
02d1f34c: mov     x0, x8                                     
02d1f350: bl      #0x2b70f30                                 fn_2b70f30
02d1f354: cbz     x20, #0x2d1f440                            
02d1f358: ldr     x8, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d1f35c: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02d1f360: ldr     x1, [x8, #0x350]                           S:"OnProductPurchased handler error for '{0}': {1}"
02d1f364: str     x1, [x20, #0x30]!                          
02d1f368: mov     x0, x20                                    
02d1f36c: bl      #0x2b70d54                                 fn_2b70d54
02d1f370: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1f374: bl      #0x3769600                                 fn_3769600
02d1f378: ldr     x8, [x19, #0x20]                           S:'dev log AdsManager show app open ad'
02d1f37c: cbz     x8, #0x2d1f440                             
02d1f380: cbz     x0, #0x2d1f440                             
02d1f384: ldr     w8, [x8, #0x50]                            S:'native_fullscreen_on_off'
02d1f388: add     w9, w8, #1                                 
02d1f38c: ldr     x8, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1f390: str     w9, [x0, #0x3c]                            
02d1f394: mov     x0, x8                                     
02d1f398: bl      #0x3769600                                 fn_3769600
02d1f39c: mov     x20, x0                                    
02d1f3a0: mov     x0, xzr                                    
02d1f3a4: bl      #0x5b432fc                                 UnityEngine.Time::get_time
02d1f3a8: cbz     x20, #0x2d1f440                            
02d1f3ac: ldr     x8, [x19, #0x20]                           S:'dev log AdsManager show app open ad'
02d1f3b0: str     s0, [x20, #0x38]                           ._backButton
02d1f3b4: cbz     x8, #0x2d1f440                             
02d1f3b8: ldr     x9, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d1f3bc: ldr     w8, [x8, #0x50]                            S:'native_fullscreen_on_off'
02d1f3c0: mov     x3, xzr                                    
02d1f3c4: ldr     x9, [x9, #0xb8]                            
02d1f3c8: add     w1, w8, #1                                 
02d1f3cc: ldr     x0, [x9, #0x350]                           
02d1f3d0: ldr     x2, [x9, #0x1e8]                           
02d1f3d4: bl      #0x2c9c5c4                                 DevTrack::GameModeStart
02d1f3d8: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1f3dc: bl      #0x3769600                                 fn_3769600
02d1f3e0: cbz     x0, #0x2d1f440                             
02d1f3e4: ldr     x19, [x0, #0x30]                           S:'popup_rate_on_off'
02d1f3e8: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1f3ec: bl      #0x3769600                                 fn_3769600
02d1f3f0: cbz     x0, #0x2d1f440                             
02d1f3f4: ldr     x8, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d1f3f8: ldr     w1, [x0, #0x3c]                            [626603c]=0 f=0,0
02d1f3fc: mov     x0, x19                                    
02d1f400: mov     x4, xzr                                    
02d1f404: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02d1f408: ldr     x2, [x8, #0x218]                           MS:System.Collections.Generic.List`1::.ctor
02d1f40c: ldr     w3, [x8, #0x270]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d1f410: bl      #0x2c9c714                                 DevTrack::GameModeStepEnter
02d1f414: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1f418: bl      #0x3769600                                 fn_3769600
02d1f41c: cbz     x0, #0x2d1f440                             
02d1f420: ldr     x8, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d1f424: ldp     x20, x19, [sp, #0x20]                      
02d1f428: ldp     x22, x21, [sp, #0x10]                      
02d1f42c: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02d1f430: ldr     x1, [x8, #0x218]                           MS:System.Collections.Generic.List`1::.ctor
02d1f434: str     x1, [x0, #0x40]!                           ._playButton
02d1f438: ldr     x30, [sp], #0x30                           
02d1f43c: b       #0x2b70d54                                 
02d1f440: bl      #0x2b7105c                                 fn_2b7105c
