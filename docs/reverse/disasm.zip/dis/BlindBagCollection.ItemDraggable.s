#### CLASS BlindBagCollection.ItemDraggable parent= UnityEngine.MonoBehaviour
#   field _collectionItemType            BlindBagCollection.CollectionItemType              off=0x20 attr=1 HeaderAttribute,SerializeField
#   field _collectionBoxsetType          BlindBagCollection.CollectionBoxsetType            off=0x24 attr=1 SerializeField
#   field _spriteRenderer                UnityEngine.SpriteRenderer                         off=0x28 attr=1 SpaceAttribute,HeaderAttribute,SerializeField
#   field _collider                      UnityEngine.Collider2D                             off=0x30 attr=1 
#   field _initialPosition               UnityEngine.Vector3                                off=0x38 attr=1 
#   field _initialScale                  UnityEngine.Vector3                                off=0x44 attr=1 
#   field _initialRotation               UnityEngine.Quaternion                             off=0x50 attr=1 
#   field _tween1                        DG.Tweening.Tween                                  off=0x60 attr=1 
#   field _tween2                        DG.Tweening.Tween                                  off=0x68 attr=1 
#   field maxWidth                       float                                              off=0x0 attr=8051 
#   field maxHeight                      float                                              off=0x0 attr=8051 
## get_BoxsetType() -> BlindBagCollection.CollectionBoxsetType
---- BlindBagCollection.ItemDraggable::get_BoxsetType 0x2d3b81c
02d3b81c: ldr     w0, [x0, #0x24]                            ._collectionBoxsetType
02d3b820: ret                                                
## get_CollectionItemType() -> BlindBagCollection.CollectionItemType
---- BlindBagCollection.ItemDraggable::get_CollectionItemType 0x2d3b824
02d3b824: ldr     w0, [x0, #0x20]                            ._collectionItemType
02d3b828: ret                                                
## Awake() -> void
---- BlindBagCollection.ItemDraggable::Awake 0x2d3b82c
02d3b82c: stp     x30, x21, [sp, #-0x20]!                    
02d3b830: stp     x20, x19, [sp, #0x10]                      
02d3b834: adrp    x20, #0x6630000                            
02d3b838: adrp    x21, #0x6269000                            
02d3b83c: mov     x19, x0                                    
02d3b840: ldrb    w8, [x20, #0x150]                          
02d3b844: ldr     x21, [x21, #0x8f0]                         MS:UnityEngine.Component::GetComponent
02d3b848: tbnz    w8, #0, #0x2d3b860                         
02d3b84c: adrp    x0, #0x6269000                             
02d3b850: ldr     x0, [x0, #0x8f0]                           MS:UnityEngine.Component::GetComponent
02d3b854: bl      #0x2b70db0                                 fn_2b70db0
02d3b858: mov     w8, #1                                     
02d3b85c: strb    w8, [x20, #0x150]                          
02d3b860: ldr     x1, [x21]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d3b864: mov     x0, x19                                    
02d3b868: bl      #0x3140c84                                 fn_3140c84
02d3b86c: str     x0, [x19, #0x30]!                          ._collider
02d3b870: mov     x1, x0                                     
02d3b874: mov     x0, x19                                    
02d3b878: ldp     x20, x19, [sp, #0x10]                      
02d3b87c: ldp     x30, x21, [sp], #0x20                      
02d3b880: b       #0x2b70d54                                 
## Start() -> void
---- BlindBagCollection.ItemDraggable::Start 0x2d3b884
02d3b884: stp     x30, x19, [sp, #-0x10]!                    
02d3b888: mov     x1, xzr                                    
02d3b88c: mov     x19, x0                                    
02d3b890: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d3b894: cbz     x0, #0x2d3b8f0                             
02d3b898: mov     x1, xzr                                    
02d3b89c: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d3b8a0: mov     x0, x19                                    
02d3b8a4: mov     x1, xzr                                    
02d3b8a8: stp     s0, s1, [x19, #0x38]                       ._initialPosition
02d3b8ac: str     s2, [x19, #0x40]                           
02d3b8b0: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d3b8b4: cbz     x0, #0x2d3b8f0                             
02d3b8b8: mov     x1, xzr                                    
02d3b8bc: bl      #0x5b46a30                                 UnityEngine.Transform::get_rotation
02d3b8c0: mov     x0, x19                                    
02d3b8c4: mov     x1, xzr                                    
02d3b8c8: stp     s0, s1, [x19, #0x50]                       ._initialRotation
02d3b8cc: stp     s2, s3, [x19, #0x58]                       
02d3b8d0: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d3b8d4: cbz     x0, #0x2d3b8f0                             
02d3b8d8: mov     x1, xzr                                    
02d3b8dc: bl      #0x5b46ff0                                 UnityEngine.Transform::get_localScale
02d3b8e0: stp     s0, s1, [x19, #0x44]                       ._initialScale
02d3b8e4: str     s2, [x19, #0x4c]                           
02d3b8e8: ldp     x30, x19, [sp], #0x10                      
02d3b8ec: ret                                                
02d3b8f0: bl      #0x2b7105c                                 fn_2b7105c
## SetData(BlindBagCollection.CollectionItemType itemType, BlindBagCollection.CollectionBoxsetType boxsetType, UnityEngine.Sprite sprite) -> void
---- BlindBagCollection.ItemDraggable::SetData 0x2d36a74
02d36a74: sub     sp, sp, #0x60                              
02d36a78: stp     d9, d8, [sp, #0x20]                        
02d36a7c: stp     x30, x23, [sp, #0x30]                      
02d36a80: stp     x22, x21, [sp, #0x40]                      
02d36a84: stp     x20, x19, [sp, #0x50]                      
02d36a88: adrp    x23, #0x6630000                            
02d36a8c: mov     x20, x3                                    
02d36a90: mov     w21, w2                                    
02d36a94: ldrb    w8, [x23, #0x151]                          
02d36a98: mov     w22, w1                                    
02d36a9c: mov     x19, x0                                    
02d36aa0: tbnz    w8, #0, #0x2d36ab8                         
02d36aa4: adrp    x0, #0x626a000                             
02d36aa8: ldr     x0, [x0, #0x760]                           T:type24618(k1d)
02d36aac: bl      #0x2b70db0                                 fn_2b70db0
02d36ab0: mov     w8, #1                                     
02d36ab4: strb    w8, [x23, #0x151]                          
02d36ab8: ldr     x0, [x19, #0x28]                           ._spriteRenderer
02d36abc: stp     w22, w21, [x19, #0x20]                     ._collectionItemType
02d36ac0: cbz     x0, #0x2d36c10                             
02d36ac4: mov     x1, x20                                    
02d36ac8: mov     x2, xzr                                    
02d36acc: bl      #0x5ae6dcc                                 UnityEngine.SpriteRenderer::set_sprite
02d36ad0: ldr     x0, [x19, #0x28]                           ._spriteRenderer
02d36ad4: cbz     x0, #0x2d36c10                             
02d36ad8: mov     x1, xzr                                    
02d36adc: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d36ae0: adrp    x21, #0x662f000                            
02d36ae4: mov     x20, x0                                    
02d36ae8: ldrb    w8, [x21, #0xa74]                          
02d36aec: cbnz    w8, #0x2d36b04                             
02d36af0: adrp    x0, #0x6264000                             
02d36af4: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d36af8: bl      #0x2b70db0                                 fn_2b70db0
02d36afc: mov     w8, #1                                     
02d36b00: strb    w8, [x21, #0xa74]                          
02d36b04: cbz     x20, #0x2d36c10                            
02d36b08: adrp    x8, #0x6264000                             
02d36b0c: mov     x0, x20                                    
02d36b10: mov     x1, xzr                                    
02d36b14: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02d36b18: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d36b1c: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d36b20: ldp     s1, s2, [x8, #0x10]                        
02d36b24: ldr     s0, [x8, #0xc]                             [626400c]=0 f=0,0
02d36b28: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d36b2c: ldr     x0, [x19, #0x28]                           ._spriteRenderer
02d36b30: cbz     x0, #0x2d36c10                             
02d36b34: adrp    x20, #0x626a000                            
02d36b38: add     x8, sp, #8                                 
02d36b3c: mov     x1, xzr                                    
02d36b40: ldr     x20, [x20, #0x760]                         T:type24618(k1d)
02d36b44: bl      #0x5b02028                                 UnityEngine.Renderer::get_bounds
02d36b48: ldp     s9, s8, [sp, #0x14]                        
02d36b4c: mov     w1, #3                                     
02d36b50: ldr     x0, [x20]                                  T:type56879(k15)
02d36b54: bl      #0x2b70ea0                                 fn_2b70ea0
02d36b58: cbz     x0, #0x2d36c10                             
02d36b5c: ldr     x8, [x0, #0x18]                            M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0::<DOSetFloat>b__1
02d36b60: cbz     w8, #0x2d36c14                             
02d36b64: mov     w9, #0x3f800000                            
02d36b68: cmp     w8, #1                                     
02d36b6c: str     w9, [x0, #0x20]                            ._collectionItemType
02d36b70: b.eq    #0x2d36c14                                 
02d36b74: fadd    s1, s9, s9                                 
02d36b78: fmov    s0, #4.00000000                            
02d36b7c: cmp     w8, #2                                     
02d36b80: fdiv    s1, s0, s1                                 
02d36b84: str     s1, [x0, #0x24]                            ._collectionBoxsetType
02d36b88: b.ls    #0x2d36c14                                 
02d36b8c: fadd    s1, s8, s8                                 
02d36b90: fmov    s8, #1.00000000                            
02d36b94: fdiv    s0, s0, s1                                 
02d36b98: str     s0, [x0, #0x28]                            ._spriteRenderer
02d36b9c: b.lt    #0x2d36bc0                                 
02d36ba0: and     x8, x8, #0xffffffff                        
02d36ba4: add     x9, x0, #0x24                              &6264024
02d36ba8: sub     x8, x8, #1                                 
02d36bac: ldr     s0, [x9], #4                               
02d36bb0: fcmp    s0, s8                                     
02d36bb4: fcsel   s8, s0, s8, mi                             
02d36bb8: subs    x8, x8, #1                                 
02d36bbc: b.ne    #0x2d36bac                                 
02d36bc0: ldr     x0, [x19, #0x28]                           ._spriteRenderer
02d36bc4: cbz     x0, #0x2d36c10                             
02d36bc8: mov     x1, xzr                                    
02d36bcc: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d36bd0: cbz     x0, #0x2d36c10                             
02d36bd4: mov     x1, xzr                                    
02d36bd8: mov     x19, x0                                    
02d36bdc: bl      #0x5b46ff0                                 UnityEngine.Transform::get_localScale
02d36be0: fmul    s0, s8, s0                                 
02d36be4: fmul    s1, s8, s1                                 
02d36be8: mov     x0, x19                                    
02d36bec: fmul    s2, s8, s2                                 
02d36bf0: mov     x1, xzr                                    
02d36bf4: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d36bf8: ldp     x20, x19, [sp, #0x50]                      
02d36bfc: ldp     x22, x21, [sp, #0x40]                      
02d36c00: ldp     x30, x23, [sp, #0x30]                      
02d36c04: ldp     d9, d8, [sp, #0x20]                        
02d36c08: add     sp, sp, #0x60                              
02d36c0c: ret                                                
02d36c10: bl      #0x2b7105c                                 fn_2b7105c
02d36c14: bl      #0x2b71064                                 fn_2b71064
## CompareData(BlindBagCollection.CollectionBoxsetType boxsetType) -> bool
---- BlindBagCollection.ItemDraggable::CompareData 0x2d3b584
02d3b584: ldr     w8, [x0, #0x24]                            ._collectionBoxsetType
02d3b588: cmp     w8, w1                                     
02d3b58c: cset    w0, eq                                     
02d3b590: ret                                                
## OnDragEnded() -> void
---- BlindBagCollection.ItemDraggable::OnDragEnded 0x2d372e0
02d372e0: stp     x30, x21, [sp, #-0x20]!                    
02d372e4: stp     x20, x19, [sp, #0x10]                      
02d372e8: adrp    x20, #0x6630000                            
02d372ec: mov     x19, x0                                    
02d372f0: ldrb    w8, [x20, #0x152]                          
02d372f4: tbnz    w8, #0, #0x2d3730c                         
02d372f8: adrp    x0, #0x6266000                             
02d372fc: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d37300: bl      #0x2b70db0                                 fn_2b70db0
02d37304: mov     w8, #1                                     
02d37308: strb    w8, [x20, #0x152]                          
02d3730c: mov     x20, x19                                   
02d37310: ldr     x0, [x20, #0x60]!                          ._tween1
02d37314: cbz     x0, #0x2d37324                             
02d37318: mov     w1, wzr                                    
02d3731c: mov     x2, xzr                                    
02d37320: bl      #0x2d8fe94                                 DG.Tweening.TweenExtensions::Kill
02d37324: ldr     x0, [x19, #0x68]                           ._tween2
02d37328: cbz     x0, #0x2d37338                             
02d3732c: mov     w1, wzr                                    
02d37330: mov     x2, xzr                                    
02d37334: bl      #0x2d8fe94                                 DG.Tweening.TweenExtensions::Kill
02d37338: ldr     x0, [x19, #0x30]                           ._collider
02d3733c: cbz     x0, #0x2d373e0                             
02d37340: mov     w1, #1                                     
02d37344: mov     x2, xzr                                    
02d37348: bl      #0x5b33110                                 UnityEngine.Behaviour::set_enabled
02d3734c: mov     x0, x19                                    
02d37350: mov     x1, xzr                                    
02d37354: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d37358: cbz     x0, #0x2d373e0                             
02d3735c: adrp    x21, #0x6266000                            
02d37360: mov     x1, xzr                                    
02d37364: ldr     x21, [x21, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d37368: ldp     s5, s6, [x19, #0x58]                       
02d3736c: ldp     s3, s4, [x19, #0x50]                       ._initialRotation
02d37370: ldr     s0, [x19, #0x38]                           ._initialPosition
02d37374: ldp     s1, s2, [x19, #0x3c]                       
02d37378: bl      #0x5b47570                                 UnityEngine.Transform::SetPositionAndRotation
02d3737c: mov     x0, x19                                    
02d37380: mov     x1, xzr                                    
02d37384: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d37388: ldp     s0, s1, [x19, #0x44]                       ._initialScale
02d3738c: adrp    x8, #0x1084000                             
02d37390: ldr     s2, [x19, #0x4c]                           
02d37394: ldr     s3, [x8, #0xeec]                           [1084eec]=457ff0003dcccccd f=0.1,4095
02d37398: mov     x1, xzr                                    
02d3739c: bl      #0x2d98af8                                 DG.Tweening.ShortcutExtensions::DOScale
02d373a0: fmov    s0, #0.50000000                            
02d373a4: ldr     s1, [x19, #0x44]                           ._initialScale
02d373a8: mov     w1, #1                                     
02d373ac: mov     w2, wzr                                    
02d373b0: mov     x3, xzr                                    
02d373b4: fmul    s0, s1, s0                                 
02d373b8: bl      #0x2da0560                                 DG.Tweening.TweenSettingsExtensions::From
02d373bc: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d373c0: mov     w1, #0x1b                                  
02d373c4: bl      #0x336fa0c                                 fn_336fa0c
02d373c8: mov     x1, x0                                     
02d373cc: mov     x0, x20                                    
02d373d0: str     x1, [x19, #0x60]                           ._tween1
02d373d4: ldp     x20, x19, [sp, #0x10]                      
02d373d8: ldp     x30, x21, [sp], #0x20                      
02d373dc: b       #0x2b70d54                                 
02d373e0: bl      #0x2b7105c                                 fn_2b7105c
## OnPointerDown(UnityEngine.EventSystems.PointerEventData eventData) -> void
---- BlindBagCollection.ItemDraggable::OnPointerDown 0x2d3b8f4
02d3b8f4: str     d8, [sp, #-0x50]!                          
02d3b8f8: stp     x30, x25, [sp, #0x10]                      
02d3b8fc: stp     x24, x23, [sp, #0x20]                      
02d3b900: stp     x22, x21, [sp, #0x30]                      
02d3b904: stp     x20, x19, [sp, #0x40]                      
02d3b908: adrp    x20, #0x6630000                            
02d3b90c: mov     x19, x0                                    
02d3b910: ldrb    w8, [x20, #0x153]                          
02d3b914: tbnz    w8, #0, #0x2d3b944                         
02d3b918: adrp    x0, #0x626a000                             
02d3b91c: ldr     x0, [x0, #0xb18]                           T:BlindBagCollection.BlindbagDragController
02d3b920: bl      #0x2b70db0                                 fn_2b70db0
02d3b924: adrp    x0, #0x6267000                             
02d3b928: ldr     x0, [x0, #0xd38]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d3b92c: bl      #0x2b70db0                                 fn_2b70db0
02d3b930: adrp    x0, #0x6266000                             
02d3b934: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d3b938: bl      #0x2b70db0                                 fn_2b70db0
02d3b93c: mov     w8, #1                                     
02d3b940: strb    w8, [x20, #0x153]                          
02d3b944: ldr     x0, [x19, #0x30]                           ._collider
02d3b948: cbz     x0, #0x2d3bac4                             
02d3b94c: adrp    x20, #0x626a000                            
02d3b950: mov     w1, wzr                                    
02d3b954: mov     x2, xzr                                    
02d3b958: ldr     x20, [x20, #0xb18]                         T:BlindBagCollection.BlindbagDragController
02d3b95c: bl      #0x5b33110                                 UnityEngine.Behaviour::set_enabled
02d3b960: ldr     x8, [x20]                                  T:type56879(k15)
02d3b964: ldr     x8, [x8, #0xb8]                            
02d3b968: ldr     x8, [x8]                                   
02d3b96c: cbz     x8, #0x2d3b984                             
02d3b970: ldr     x9, [x8, #0x18]                            
02d3b974: ldr     x0, [x8, #0x40]                            
02d3b978: mov     x1, x19                                    
02d3b97c: ldr     x2, [x8, #0x28]                            
02d3b980: blr     x9                                         
02d3b984: mov     x21, x19                                   
02d3b988: ldr     x0, [x21, #0x60]!                          ._tween1
02d3b98c: cbz     x0, #0x2d3b99c                             
02d3b990: mov     w1, wzr                                    
02d3b994: mov     x2, xzr                                    
02d3b998: bl      #0x2d8fe94                                 DG.Tweening.TweenExtensions::Kill
02d3b99c: mov     x20, x19                                   
02d3b9a0: ldr     x0, [x20, #0x68]!                          T:Decor.DecorAsset/<>c__DisplayClass5_0 ._tween2
02d3b9a4: cbz     x0, #0x2d3b9b4                             
02d3b9a8: mov     w1, wzr                                    
02d3b9ac: mov     x2, xzr                                    
02d3b9b0: bl      #0x2d8fe94                                 DG.Tweening.TweenExtensions::Kill
02d3b9b4: adrp    x25, #0x6267000                            
02d3b9b8: mov     x0, x19                                    
02d3b9bc: mov     x1, xzr                                    
02d3b9c0: ldr     x25, [x25, #0xd38]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d3b9c4: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d3b9c8: adrp    x23, #0x662f000                            
02d3b9cc: mov     x22, x0                                    
02d3b9d0: ldrb    w8, [x23, #0x91a]                          
02d3b9d4: cbnz    w8, #0x2d3b9ec                             
02d3b9d8: adrp    x0, #0x6264000                             
02d3b9dc: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d3b9e0: bl      #0x2b70db0                                 fn_2b70db0
02d3b9e4: mov     w8, #1                                     
02d3b9e8: strb    w8, [x23, #0x91a]                          
02d3b9ec: adrp    x24, #0x6264000                            
02d3b9f0: adrp    x23, #0x6266000                            
02d3b9f4: mov     x0, x22                                    
02d3b9f8: ldr     x24, [x24, #0xd8]                          T:UnityEngine.Vector3
02d3b9fc: mov     w1, wzr                                    
02d3ba00: mov     x2, xzr                                    
02d3ba04: ldr     x8, [x24]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d3ba08: ldr     x8, [x8, #0xb8]                            
02d3ba0c: ldr     x23, [x23, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d3ba10: ldp     s0, s1, [x8]                               
02d3ba14: ldr     s2, [x8, #8]                               
02d3ba18: adrp    x8, #0x1084000                             
02d3ba1c: ldr     s8, [x8, #0xeec]                           [1084eec]=457ff0003dcccccd f=0.1,4095
02d3ba20: fmov    s3, s8                                     
02d3ba24: bl      #0x2d983c8                                 DG.Tweening.ShortcutExtensions::DORotate
02d3ba28: ldr     x2, [x25]                                  S:'didu'
02d3ba2c: mov     w1, #6                                     
02d3ba30: bl      #0x336fa0c                                 fn_336fa0c
02d3ba34: mov     x1, x0                                     
02d3ba38: str     x0, [x19, #0x60]                           ._tween1
02d3ba3c: mov     x0, x21                                    
02d3ba40: bl      #0x2b70d54                                 fn_2b70d54
02d3ba44: mov     x0, x19                                    
02d3ba48: mov     x1, xzr                                    
02d3ba4c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d3ba50: adrp    x21, #0x662f000                            
02d3ba54: mov     x19, x0                                    
02d3ba58: ldrb    w8, [x21, #0xa74]                          
02d3ba5c: cbnz    w8, #0x2d3ba74                             
02d3ba60: adrp    x0, #0x6264000                             
02d3ba64: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d3ba68: bl      #0x2b70db0                                 fn_2b70db0
02d3ba6c: mov     w8, #1                                     
02d3ba70: strb    w8, [x21, #0xa74]                          
02d3ba74: ldr     x8, [x24]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d3ba78: fmov    s3, s8                                     
02d3ba7c: mov     x0, x19                                    
02d3ba80: mov     x1, xzr                                    
02d3ba84: ldr     x8, [x8, #0xb8]                            [10840b8]=2632726f74636556 f=7.20646e+31,6.19112e-16
02d3ba88: ldp     s0, s1, [x8, #0xc]                         
02d3ba8c: ldr     s2, [x8, #0x14]                            [1084014]=6974554955472e65 f=1.36876e+13,1.84613e+25
02d3ba90: bl      #0x2d98af8                                 DG.Tweening.ShortcutExtensions::DOScale
02d3ba94: ldr     x2, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d3ba98: mov     w1, #6                                     
02d3ba9c: bl      #0x336fa0c                                 fn_336fa0c
02d3baa0: mov     x1, x0                                     
02d3baa4: mov     x0, x20                                    
02d3baa8: str     x1, [x20]                                  
02d3baac: ldp     x20, x19, [sp, #0x40]                      
02d3bab0: ldp     x22, x21, [sp, #0x30]                      
02d3bab4: ldp     x24, x23, [sp, #0x20]                      
02d3bab8: ldp     x30, x25, [sp, #0x10]                      
02d3babc: ldr     d8, [sp], #0x50                            
02d3bac0: b       #0x2b70d54                                 
02d3bac4: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- BlindBagCollection.ItemDraggable::.ctor 0x2d3bac8
02d3bac8: mov     x1, xzr                                    
02d3bacc: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
