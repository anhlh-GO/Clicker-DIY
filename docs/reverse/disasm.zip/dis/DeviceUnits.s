#### CLASS DeviceUnits parent= object
## IsTablet() -> bool
---- DeviceUnits::IsTablet 0x2ca3948
02ca3948: str     d8, [sp, #-0x20]!                          
02ca394c: stp     x30, x19, [sp, #0x10]                      
02ca3950: mov     x0, xzr                                    
02ca3954: bl      #0x5afb74c                                 UnityEngine.Screen::get_dpi
02ca3958: mov     x0, xzr                                    
02ca395c: fmov    s8, s0                                     
02ca3960: bl      #0x5afb6fc                                 UnityEngine.Screen::get_width
02ca3964: mov     w19, w0                                    
02ca3968: mov     x0, xzr                                    
02ca396c: bl      #0x5afb724                                 UnityEngine.Screen::get_height
02ca3970: scvtf   s0, w19                                    
02ca3974: scvtf   s1, w0                                     
02ca3978: ldp     x30, x19, [sp, #0x10]                      
02ca397c: fdiv    s0, s0, s8                                 
02ca3980: fdiv    s1, s1, s8                                 
02ca3984: fmul    s0, s0, s0                                 
02ca3988: fmul    s1, s1, s1                                 
02ca398c: fadd    s0, s0, s1                                 
02ca3990: fmov    s1, #7.00000000                            
02ca3994: fsqrt   s0, s0                                     
02ca3998: fcmp    s0, s1                                     
02ca399c: cset    w0, ge                                     
02ca39a0: ldr     d8, [sp], #0x20                            
02ca39a4: ret                                                
## IsiPad() -> bool
---- DeviceUnits::IsiPad 0x2ca39a8
02ca39a8: mov     w0, wzr                                    
02ca39ac: ret                                                
## IsTabletOriPad() -> bool
---- DeviceUnits::IsTabletOriPad 0x2ca39b0
02ca39b0: b       #0x2ca3948                                 DeviceUnits::IsTablet
