#### CLASS Home.PopupIntroScoop/<OnShow>d__19 parent= System.ValueType
#   field <>1__state                     int                                                off=0x10 attr=6 
#   field <>t__builder                   System.Runtime.CompilerServices.AsyncVoidMethodBuilder off=0x18 attr=6 
#   field <>4__this                      Home.PopupIntroScoop                               off=0x38 attr=6 
#   field <>u__1                         Cysharp.Threading.Tasks.UniTask/Awaiter            off=0x40 attr=1 
## MoveNext() -> void
---- Home.PopupIntroScoop/<OnShow>d__19::MoveNext 0x2d21298
02d21298: sub     sp, sp, #0x70                              
02d2129c: stp     x30, x25, [sp, #0x30]                      
02d212a0: stp     x24, x23, [sp, #0x40]                      
02d212a4: stp     x22, x21, [sp, #0x50]                      
02d212a8: stp     x20, x19, [sp, #0x60]                      
02d212ac: adrp    x20, #0x6630000                            
02d212b0: mov     x19, x0                                    
02d212b4: ldrb    w8, [x20, #0x4b]                           
02d212b8: tbnz    w8, #0, #0x2d21360                         
02d212bc: adrp    x0, #0x6269000                             
02d212c0: ldr     x0, [x0, #0xe18]                           MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::AwaitUnsafeOnCompleted
02d212c4: bl      #0x2b70db0                                 fn_2b70db0
02d212c8: adrp    x0, #0x6266000                             
02d212cc: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d212d0: bl      #0x2b70db0                                 fn_2b70db0
02d212d4: adrp    x0, #0x6265000                             
02d212d8: ldr     x0, [x0, #0xb38]                           T:DevTrack
02d212dc: bl      #0x2b70db0                                 fn_2b70db0
02d212e0: adrp    x0, #0x6266000                             
02d212e4: ldr     x0, [x0, #0x9f0]                           T:Assets.SimpleLocalization.Scripts.LocalizationManager
02d212e8: bl      #0x2b70db0                                 fn_2b70db0
02d212ec: adrp    x0, #0x6266000                             
02d212f0: ldr     x0, [x0, #0xac0]                           MS:MonoSingleton`1::get_Instance
02d212f4: bl      #0x2b70db0                                 fn_2b70db0
02d212f8: adrp    x0, #0x6266000                             
02d212fc: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d21300: bl      #0x2b70db0                                 fn_2b70db0
02d21304: adrp    x0, #0x6263000                             
02d21308: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d2130c: bl      #0x2b70db0                                 fn_2b70db0
02d21310: adrp    x0, #0x6269000                             
02d21314: ldr     x0, [x0, #0xe20]                           M:Home.PopupIntroScoop::<OnShow>b__19_0
02d21318: bl      #0x2b70db0                                 fn_2b70db0
02d2131c: adrp    x0, #0x6264000                             
02d21320: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d21324: bl      #0x2b70db0                                 fn_2b70db0
02d21328: adrp    x0, #0x6266000                             
02d2132c: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d21330: bl      #0x2b70db0                                 fn_2b70db0
02d21334: adrp    x0, #0x6266000                             
02d21338: ldr     x0, [x0, #0xcc8]                           T:Cysharp.Threading.Tasks.UniTask
02d2133c: bl      #0x2b70db0                                 fn_2b70db0
02d21340: adrp    x0, #0x6267000                             
02d21344: ldr     x0, [x0, #0xea8]                           T:Framework.Vibration
02d21348: bl      #0x2b70db0                                 fn_2b70db0
02d2134c: adrp    x0, #0x6266000                             
02d21350: ldr     x0, [x0, #0xd68]                           S:'Welcome !'
02d21354: bl      #0x2b70db0                                 fn_2b70db0
02d21358: mov     w8, #1                                     
02d2135c: strb    w8, [x20, #0x4b]                           
02d21360: adrp    x25, #0x6266000                            
02d21364: adrp    x24, #0x6266000                            
02d21368: adrp    x23, #0x662f000                            
02d2136c: ldr     x25, [x25, #0xac0]                         MS:MonoSingleton`1::get_Instance
02d21370: ldr     x24, [x24, #0xcc8]                         T:Cysharp.Threading.Tasks.UniTask
02d21374: ldr     w8, [x19]                                  
02d21378: ldr     x20, [x19, #0x28]                          
02d2137c: stp     xzr, xzr, [sp, #0x10]                      
02d21380: str     wzr, [sp, #8]                              
02d21384: cbz     w8, #0x2d213a8                             
02d21388: cmp     w8, #1                                     
02d2138c: b.ne    #0x2d213c0                                 
02d21390: ldr     q0, [x19, #0x30]                           
02d21394: mov     w8, #-1                                    
02d21398: stp     xzr, xzr, [x19, #0x30]                     
02d2139c: str     w8, [x19]                                  
02d213a0: str     q0, [sp, #0x10]                            
02d213a4: b       #0x2d2195c                                 
02d213a8: ldr     q0, [x19, #0x30]                           
02d213ac: mov     w8, #-1                                    
02d213b0: stp     xzr, xzr, [x19, #0x30]                     
02d213b4: str     w8, [x19]                                  
02d213b8: str     q0, [sp, #0x10]                            
02d213bc: b       #0x2d216e8                                 
02d213c0: adrp    x8, #0x6266000                             
02d213c4: ldr     x8, [x8, #0x658]                           MS:MonoSingleton`1::get_Instance
02d213c8: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d213cc: bl      #0x3769600                                 fn_3769600
02d213d0: cbz     x0, #0x2d21b18                             
02d213d4: adrp    x8, #0x6266000                             
02d213d8: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02d213dc: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d213e0: bl      #0x3168dd0                                 fn_3168dd0
02d213e4: cbz     x0, #0x2d21b1c                             
02d213e8: ldr     x8, [x0, #0x20]                            S:'inter_ad_capping_time'
02d213ec: cbz     x8, #0x2d21b20                             
02d213f0: ldr     w8, [x8, #0x4c]                            [626604c]=0 f=0,0
02d213f4: cbz     w8, #0x2d21420                             
02d213f8: cbz     x20, #0x2d21b5c                            
02d213fc: ldr     x0, [x20, #0x48]                           
02d21400: cbz     x0, #0x2d21b60                             
02d21404: mov     x1, xzr                                    
02d21408: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d2140c: cbz     x0, #0x2d21b64                             
02d21410: mov     w1, #1                                     
02d21414: mov     x2, xzr                                    
02d21418: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d2141c: b       #0x2d21444                                 
02d21420: cbz     x20, #0x2d21b68                            
02d21424: ldr     x0, [x20, #0x48]                           
02d21428: cbz     x0, #0x2d21b6c                             
02d2142c: mov     x1, xzr                                    
02d21430: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d21434: cbz     x0, #0x2d21b70                             
02d21438: mov     w1, wzr                                    
02d2143c: mov     x2, xzr                                    
02d21440: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d21444: adrp    x21, #0x6265000                            
02d21448: ldr     x21, [x21, #0xb38]                         T:DevTrack
02d2144c: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d21450: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d21454: cbnz    w8, #0x2d21460                             
02d21458: bl      #0x2b70f30                                 fn_2b70f30
02d2145c: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d21460: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time'
02d21464: ldr     x0, [x8, #0x358]                           MS:UnityEngine.JsonUtility::FromJson
02d21468: mov     x1, xzr                                    
02d2146c: bl      #0x2c9c4e4                                 DevTrack::GameModeEnter
02d21470: ldr     x0, [x20, #0x98]                           
02d21474: cbz     x0, #0x2d21b24                             
02d21478: mov     x1, xzr                                    
02d2147c: bl      #0x2cddf7c                                 ProfilePanel::UpdateAvatar
02d21480: cbz     x0, #0x2d21b28                             
02d21484: mov     x1, xzr                                    
02d21488: bl      #0x2cddfec                                 ProfilePanel::UpdateLevel
02d2148c: cbz     x0, #0x2d21b2c                             
02d21490: mov     x1, xzr                                    
02d21494: bl      #0x2cdda80                                 ProfilePanel::UpdateName
02d21498: cbz     x0, #0x2d21b30                             
02d2149c: mov     x1, xzr                                    
02d214a0: bl      #0x2cdddfc                                 ProfilePanel::UpdateProgress
02d214a4: cbz     x0, #0x2d21b34                             
02d214a8: mov     x1, xzr                                    
02d214ac: bl      #0x2cdddbc                                 ProfilePanel::OnShow
02d214b0: ldr     x0, [x20, #0x40]                           .<>u__1
02d214b4: cbz     x0, #0x2d21b38                             
02d214b8: mov     x1, xzr                                    
02d214bc: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d214c0: cbz     x0, #0x2d21b3c                             
02d214c4: mov     w1, wzr                                    
02d214c8: mov     x2, xzr                                    
02d214cc: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d214d0: ldr     x0, [x20, #0x40]                           .<>u__1
02d214d4: cbz     x0, #0x2d21b40                             
02d214d8: mov     w1, wzr                                    
02d214dc: mov     x2, xzr                                    
02d214e0: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d214e4: mov     x0, x20                                    
02d214e8: mov     x1, xzr                                    
02d214ec: bl      #0x2cdd6b8                                 UIBase::OnShow
02d214f0: adrp    x8, #0x6263000                             
02d214f4: ldr     x8, [x8, #0x918]                           T:UnityEngine.Object
02d214f8: ldr     x21, [x20, #0xa0]                          
02d214fc: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02d21500: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d21504: cbnz    w8, #0x2d2150c                             
02d21508: bl      #0x2b70f30                                 fn_2b70f30
02d2150c: mov     x0, x21                                    
02d21510: mov     x1, xzr                                    
02d21514: mov     x2, xzr                                    
02d21518: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d2151c: tbz     w0, #0, #0x2d21530                         
02d21520: ldr     x0, [x20, #0xa0]                           
02d21524: cbz     x0, #0x2d21530                             
02d21528: mov     x1, xzr                                    
02d2152c: bl      #0x2d11ba0                                 Livestream.LivestreamPanel::OnShow
02d21530: adrp    x8, #0x6266000                             
02d21534: ldr     x8, [x8, #0x9f0]                           T:Assets.SimpleLocalization.Scripts.LocalizationManager
02d21538: ldr     x21, [x20, #0x38]                          .<>4__this
02d2153c: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d21540: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d21544: cbnz    w8, #0x2d2154c                             
02d21548: bl      #0x2b70f30                                 fn_2b70f30
02d2154c: adrp    x8, #0x6266000                             
02d21550: ldr     x8, [x8, #0xd68]                           S:'Welcome !'
02d21554: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d21558: mov     x1, xzr                                    
02d2155c: bl      #0x2d76794                                 Assets.SimpleLocalization.Scripts.LocalizationManager::Localize
02d21560: mov     x1, x0                                     
02d21564: cbz     x21, #0x2d21b44                            
02d21568: mov     x0, x21                                    
02d2156c: mov     x2, xzr                                    
02d21570: bl      #0x2cb6c58                                 CommentHandler::UserComment
02d21574: ldr     x8, [x20, #0x38]                           .<>4__this
02d21578: cbz     x8, #0x2d21b48                             
02d2157c: mov     w9, #1                                     
02d21580: strb    w9, [x8, #0x20]                            
02d21584: ldr     x0, [x20, #0xb0]                           
02d21588: cbz     x0, #0x2d21b4c                             
02d2158c: mov     x1, xzr                                    
02d21590: bl      #0x2d4275c                                 ScoopGame.CharmBlindBoxAsset::GetOrder
02d21594: mov     x21, x0                                    
02d21598: cbz     x0, #0x2d21b50                             
02d2159c: ldr     x22, [x20, #0x78]                          
02d215a0: ldr     x0, [x21, #0x20]                           S:'dev log AdsManager show app open ad'
02d215a4: mov     x1, xzr                                    
02d215a8: bl      #0x2d76794                                 Assets.SimpleLocalization.Scripts.LocalizationManager::Localize
02d215ac: mov     x1, x0                                     
02d215b0: cbz     x22, #0x2d21b54                            
02d215b4: ldr     x8, [x22]                                  
02d215b8: ldr     x9, [x8, #0x558]                           MS:NFramework.GoogleSheetConfigSO`1::.ctor
02d215bc: ldr     x2, [x8, #0x560]                           MS:NFramework.GoogleSheetConfigSO`1::OpenSheet
02d215c0: mov     x0, x22                                    
02d215c4: blr     x9                                         
02d215c8: ldr     x0, [x25]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d215cc: bl      #0x3769600                                 fn_3769600
02d215d0: cbz     x0, #0x2d21b58                             
02d215d4: ldr     w9, [x21, #0x10]                           MS:MonoSingleton`1::get_Instance .<>1__state
02d215d8: ldr     x8, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d215dc: str     w9, [x0, #0x48]                            
02d215e0: ldr     w9, [x8, #0xe4]                            [62660e4]=0 f=0,0
02d215e4: cbnz    w9, #0x2d215f0                             
02d215e8: mov     x0, x8                                     
02d215ec: bl      #0x2b70f30                                 fn_2b70f30
02d215f0: fmov    s0, #1.00000000                            
02d215f4: mov     w0, wzr                                    
02d215f8: mov     w1, #8                                     
02d215fc: mov     x2, xzr                                    
02d21600: mov     w3, wzr                                    
02d21604: mov     x4, xzr                                    
02d21608: bl      #0x5447b08                                 Cysharp.Threading.Tasks.UniTask::WaitForSeconds
02d2160c: stp     x0, x1, [sp, #0x20]                        
02d21610: add     x0, sp, #0x20                              
02d21614: mov     x1, xzr                                    
02d21618: bl      #0x2b70d54                                 fn_2b70d54
02d2161c: adrp    x21, #0x662f000                            
02d21620: ldr     q0, [sp, #0x20]                            
02d21624: ldrb    w8, [x21, #0xbdc]                          
02d21628: str     q0, [sp, #0x10]                            
02d2162c: cbnz    w8, #0x2d21644                             
02d21630: adrp    x0, #0x6266000                             
02d21634: ldr     x0, [x0, #0xcc8]                           T:Cysharp.Threading.Tasks.UniTask
02d21638: bl      #0x2b70db0                                 fn_2b70db0
02d2163c: mov     w8, #1                                     
02d21640: strb    w8, [x21, #0xbdc]                          
02d21644: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d21648: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d2164c: cbnz    w8, #0x2d21654                             
02d21650: bl      #0x2b70f30                                 fn_2b70f30
02d21654: adrp    x21, #0x662f000                            
02d21658: ldrb    w8, [x21, #0xbdd]                          
02d2165c: cbnz    w8, #0x2d21674                             
02d21660: adrp    x0, #0x6266000                             
02d21664: ldr     x0, [x0, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02d21668: bl      #0x2b70db0                                 fn_2b70db0
02d2166c: mov     w8, #1                                     
02d21670: strb    w8, [x21, #0xbdd]                          
02d21674: ldr     x21, [sp, #0x10]                           
02d21678: cbz     x21, #0x2d216e8                            
02d2167c: adrp    x10, #0x6266000                            
02d21680: ldr     x8, [x21]                                  &2b706c4(=eb01011ff9400808)
02d21684: ldr     x10, [x10, #0xcd0]                         T:Cysharp.Threading.Tasks.IUniTaskSource
02d21688: ldrh    w22, [sp, #0x18]                           
02d2168c: ldrh    w9, [x8, #0x12e]                           
02d21690: ldr     x1, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d21694: cbz     x9, #0x2d216b8                             
02d21698: ldr     x10, [x8, #0xb0]                           S:'native_banner_ad_on_off'
02d2169c: add     x10, x10, #8                               &6266008
02d216a0: ldur    x11, [x10, #-8]                            
02d216a4: cmp     x11, x1                                    
02d216a8: b.eq    #0x2d216c8                                 
02d216ac: subs    x9, x9, #1                                 
02d216b0: add     x10, x10, #0x10                            &6266010
02d216b4: b.ne    #0x2d216a0                                 
02d216b8: mov     x0, x21                                    
02d216bc: mov     w2, wzr                                    
02d216c0: bl      #0x2baa05c                                 fn_2baa05c
02d216c4: b       #0x2d216d4                                 
02d216c8: ldrsw   x9, [x10]                                  
02d216cc: add     x8, x8, x9, lsl #4                         &6266000
02d216d0: add     x0, x8, #0x138                             &6266138
02d216d4: ldp     x8, x2, [x0]                               
02d216d8: mov     x0, x21                                    
02d216dc: mov     w1, w22                                    
02d216e0: blr     x8                                         
02d216e4: cbz     w0, #0x2d21ac0                             
02d216e8: ldrb    w8, [x23, #0xbde]                          
02d216ec: cbnz    w8, #0x2d21704                             
02d216f0: adrp    x0, #0x6266000                             
02d216f4: ldr     x0, [x0, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02d216f8: bl      #0x2b70db0                                 fn_2b70db0
02d216fc: mov     w8, #1                                     
02d21700: strb    w8, [x23, #0xbde]                          
02d21704: ldr     x21, [sp, #0x10]                           
02d21708: cbz     x21, #0x2d21778                            
02d2170c: adrp    x10, #0x6266000                            
02d21710: ldr     x8, [x21]                                  &2b706c4(=eb01011ff9400808)
02d21714: ldr     x10, [x10, #0xcd0]                         T:Cysharp.Threading.Tasks.IUniTaskSource
02d21718: ldrh    w22, [sp, #0x18]                           
02d2171c: ldrh    w9, [x8, #0x12e]                           
02d21720: ldr     x1, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d21724: cbz     x9, #0x2d21748                             
02d21728: ldr     x10, [x8, #0xb0]                           S:'native_banner_ad_on_off'
02d2172c: add     x10, x10, #8                               &6266008
02d21730: ldur    x11, [x10, #-8]                            
02d21734: cmp     x11, x1                                    
02d21738: b.eq    #0x2d21758                                 
02d2173c: subs    x9, x9, #1                                 
02d21740: add     x10, x10, #0x10                            &6266010
02d21744: b.ne    #0x2d21730                                 
02d21748: mov     x0, x21                                    
02d2174c: mov     w2, #2                                     
02d21750: bl      #0x2baa05c                                 fn_2baa05c
02d21754: b       #0x2d21768                                 
02d21758: ldr     w9, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d2175c: add     w9, w9, #2                                 
02d21760: add     x8, x8, w9, sxtw #4                        &6266000
02d21764: add     x0, x8, #0x138                             &6266138
02d21768: ldp     x8, x2, [x0]                               
02d2176c: mov     x0, x21                                    
02d21770: mov     w1, w22                                    
02d21774: blr     x8                                         
02d21778: cbz     x20, #0x2d21af8                            
02d2177c: ldr     x0, [x20, #0x88]                           
02d21780: cbz     x0, #0x2d21afc                             
02d21784: mov     x1, xzr                                    
02d21788: bl      #0x2cb4bfc                                 ViewerNameAsset::PickRandomContent
02d2178c: mov     x22, x0                                    
02d21790: ldr     x0, [x20, #0x90]                           
02d21794: cbz     x0, #0x2d21b00                             
02d21798: mov     x1, xzr                                    
02d2179c: bl      #0x2cb4b80                                 ViewerAvatarAsset::PickRandom
02d217a0: mov     x21, x0                                    
02d217a4: ldr     x0, [x20, #0x70]                           
02d217a8: cbz     x0, #0x2d21b04                             
02d217ac: ldr     x8, [x0]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d217b0: ldr     x9, [x8, #0x558]                           MS:NFramework.GoogleSheetConfigSO`1::.ctor
02d217b4: ldr     x2, [x8, #0x560]                           MS:NFramework.GoogleSheetConfigSO`1::OpenSheet
02d217b8: mov     x1, x22                                    
02d217bc: blr     x9                                         
02d217c0: ldr     x0, [x20, #0x58]                           
02d217c4: cbz     x0, #0x2d21b08                             
02d217c8: mov     x1, x21                                    
02d217cc: mov     x2, xzr                                    
02d217d0: bl      #0x5c45aa0                                 UnityEngine.UI.Image::set_sprite
02d217d4: ldr     x0, [x25]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d217d8: bl      #0x3769600                                 fn_3769600
02d217dc: cbz     x0, #0x2d21b0c                             
02d217e0: str     x21, [x0, #0x68]!                          
02d217e4: mov     x1, x21                                    
02d217e8: bl      #0x2b70d54                                 fn_2b70d54
02d217ec: mov     x0, xzr                                    
02d217f0: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d217f4: cbz     x0, #0x2d21b10                             
02d217f8: movi    d1, #0000000000000000                      
02d217fc: movi    d2, #0000000000000000                      
02d21800: mov     w1, #4                                     
02d21804: fmov    s0, #1.00000000                            
02d21808: mov     w2, wzr                                    
02d2180c: mov     w3, wzr                                    
02d21810: mov     x4, xzr                                    
02d21814: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d21818: ldrb    w8, [x20, #0x20]                           
02d2181c: cbz     w8, #0x2d21854                             
02d21820: ldr     x0, [x20, #0xa8]                           
02d21824: cbz     x0, #0x2d21b14                             
02d21828: mov     x1, xzr                                    
02d2182c: bl      #0x5b368f0                                 UnityEngine.GameObject::get_transform
02d21830: fmov    s0, #1.00000000                            
02d21834: fmov    s1, #0.50000000                            
02d21838: mov     x1, xzr                                    
02d2183c: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d21840: adrp    x8, #0x6266000                             
02d21844: ldr     x8, [x8, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d21848: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d2184c: mov     w1, #0x1b                                  
02d21850: bl      #0x336fa0c                                 fn_336fa0c
02d21854: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d21858: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d2185c: cbnz    w8, #0x2d21864                             
02d21860: bl      #0x2b70f30                                 fn_2b70f30
02d21864: fmov    s0, #1.00000000                            
02d21868: mov     w0, wzr                                    
02d2186c: mov     w1, #8                                     
02d21870: mov     x2, xzr                                    
02d21874: mov     w3, wzr                                    
02d21878: mov     x4, xzr                                    
02d2187c: bl      #0x5447b08                                 Cysharp.Threading.Tasks.UniTask::WaitForSeconds
02d21880: stp     x0, x1, [sp, #0x20]                        
02d21884: add     x0, sp, #0x20                              
02d21888: mov     x1, xzr                                    
02d2188c: bl      #0x2b70d54                                 fn_2b70d54
02d21890: adrp    x21, #0x662f000                            
02d21894: ldr     q0, [sp, #0x20]                            
02d21898: ldrb    w8, [x21, #0xbdc]                          
02d2189c: str     q0, [sp, #0x10]                            
02d218a0: cbnz    w8, #0x2d218b8                             
02d218a4: adrp    x0, #0x6266000                             
02d218a8: ldr     x0, [x0, #0xcc8]                           T:Cysharp.Threading.Tasks.UniTask
02d218ac: bl      #0x2b70db0                                 fn_2b70db0
02d218b0: mov     w8, #1                                     
02d218b4: strb    w8, [x21, #0xbdc]                          
02d218b8: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d218bc: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d218c0: cbnz    w8, #0x2d218c8                             
02d218c4: bl      #0x2b70f30                                 fn_2b70f30
02d218c8: adrp    x21, #0x662f000                            
02d218cc: ldrb    w8, [x21, #0xbdd]                          
02d218d0: cbnz    w8, #0x2d218e8                             
02d218d4: adrp    x0, #0x6266000                             
02d218d8: ldr     x0, [x0, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02d218dc: bl      #0x2b70db0                                 fn_2b70db0
02d218e0: mov     w8, #1                                     
02d218e4: strb    w8, [x21, #0xbdd]                          
02d218e8: ldr     x21, [sp, #0x10]                           
02d218ec: cbz     x21, #0x2d2195c                            
02d218f0: adrp    x10, #0x6266000                            
02d218f4: ldr     x8, [x21]                                  &2b706c4(=eb01011ff9400808)
02d218f8: ldr     x10, [x10, #0xcd0]                         T:Cysharp.Threading.Tasks.IUniTaskSource
02d218fc: ldrh    w22, [sp, #0x18]                           
02d21900: ldrh    w9, [x8, #0x12e]                           
02d21904: ldr     x1, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d21908: cbz     x9, #0x2d2192c                             
02d2190c: ldr     x10, [x8, #0xb0]                           S:'native_banner_ad_on_off'
02d21910: add     x10, x10, #8                               &6266008
02d21914: ldur    x11, [x10, #-8]                            
02d21918: cmp     x11, x1                                    
02d2191c: b.eq    #0x2d2193c                                 
02d21920: subs    x9, x9, #1                                 
02d21924: add     x10, x10, #0x10                            &6266010
02d21928: b.ne    #0x2d21914                                 
02d2192c: mov     x0, x21                                    
02d21930: mov     w2, wzr                                    
02d21934: bl      #0x2baa05c                                 fn_2baa05c
02d21938: b       #0x2d21948                                 
02d2193c: ldrsw   x9, [x10]                                  
02d21940: add     x8, x8, x9, lsl #4                         &6266000
02d21944: add     x0, x8, #0x138                             &6266138
02d21948: ldp     x8, x2, [x0]                               
02d2194c: mov     x0, x21                                    
02d21950: mov     w1, w22                                    
02d21954: blr     x8                                         
02d21958: cbz     w0, #0x2d21a84                             
02d2195c: ldrb    w8, [x23, #0xbde]                          
02d21960: cbnz    w8, #0x2d21978                             
02d21964: adrp    x0, #0x6266000                             
02d21968: ldr     x0, [x0, #0xcd0]                           T:Cysharp.Threading.Tasks.IUniTaskSource
02d2196c: bl      #0x2b70db0                                 fn_2b70db0
02d21970: mov     w8, #1                                     
02d21974: strb    w8, [x23, #0xbde]                          
02d21978: ldr     x21, [sp, #0x10]                           
02d2197c: cbz     x21, #0x2d219ec                            
02d21980: adrp    x10, #0x6266000                            
02d21984: ldr     x8, [x21]                                  &2b706c4(=eb01011ff9400808)
02d21988: ldr     x10, [x10, #0xcd0]                         T:Cysharp.Threading.Tasks.IUniTaskSource
02d2198c: ldrh    w22, [sp, #0x18]                           
02d21990: ldrh    w9, [x8, #0x12e]                           
02d21994: ldr     x1, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d21998: cbz     x9, #0x2d219bc                             
02d2199c: ldr     x10, [x8, #0xb0]                           S:'native_banner_ad_on_off'
02d219a0: add     x10, x10, #8                               &6266008
02d219a4: ldur    x11, [x10, #-8]                            
02d219a8: cmp     x11, x1                                    
02d219ac: b.eq    #0x2d219cc                                 
02d219b0: subs    x9, x9, #1                                 
02d219b4: add     x10, x10, #0x10                            &6266010
02d219b8: b.ne    #0x2d219a4                                 
02d219bc: mov     x0, x21                                    
02d219c0: mov     w2, #2                                     
02d219c4: bl      #0x2baa05c                                 fn_2baa05c
02d219c8: b       #0x2d219dc                                 
02d219cc: ldr     w9, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d219d0: add     w9, w9, #2                                 
02d219d4: add     x8, x8, w9, sxtw #4                        &6266000
02d219d8: add     x0, x8, #0x138                             &6266138
02d219dc: ldp     x8, x2, [x0]                               
02d219e0: mov     x0, x21                                    
02d219e4: mov     w1, w22                                    
02d219e8: blr     x8                                         
02d219ec: adrp    x8, #0x6267000                             
02d219f0: ldr     x8, [x8, #0xea8]                           T:Framework.Vibration
02d219f4: ldr     x0, [x8]                                   S:'didu'
02d219f8: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d219fc: cbnz    w8, #0x2d21a04                             
02d21a00: bl      #0x2b70f30                                 fn_2b70f30
02d21a04: mov     w0, #0x64                                  
02d21a08: mov     w1, #-1                                    
02d21a0c: mov     w2, wzr                                    
02d21a10: mov     x3, xzr                                    
02d21a14: bl      #0x2d6e144                                 Framework.Vibration::Vibrate
02d21a18: adrp    x8, #0x6264000                             
02d21a1c: ldr     x8, [x8, #0xe8]                            T:DG.Tweening.TweenCallback
02d21a20: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d21a24: bl      #0x2b7104c                                 fn_2b7104c
02d21a28: adrp    x8, #0x6269000                             
02d21a2c: mov     x21, x0                                    
02d21a30: ldr     x8, [x8, #0xe20]                           M:Home.PopupIntroScoop::<OnShow>b__19_0
02d21a34: ldr     x2, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d21a38: mov     x1, x20                                    
02d21a3c: mov     x3, xzr                                    
02d21a40: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d21a44: fmov    s0, #0.50000000                            
02d21a48: mov     x0, x21                                    
02d21a4c: mov     w1, #1                                     
02d21a50: mov     x2, xzr                                    
02d21a54: bl      #0x2d8f37c                                 DG.Tweening.DOVirtual::DelayedCall
02d21a58: mov     w8, #-2                                    
02d21a5c: mov     x1, xzr                                    
02d21a60: str     w8, [x19], #8                              
02d21a64: mov     x0, x19                                    
02d21a68: bl      #0x4d43b50                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::SetResult
02d21a6c: ldp     x20, x19, [sp, #0x60]                      
02d21a70: ldp     x22, x21, [sp, #0x50]                      
02d21a74: ldp     x24, x23, [sp, #0x40]                      
02d21a78: ldp     x30, x25, [sp, #0x30]                      
02d21a7c: add     sp, sp, #0x70                              
02d21a80: ret                                                
02d21a84: ldr     q0, [sp, #0x10]                            
02d21a88: mov     w8, #1                                     
02d21a8c: str     w8, [x19]                                  
02d21a90: str     q0, [x19, #0x30]                           
02d21a94: add     x0, x19, #0x30                             
02d21a98: mov     x1, xzr                                    
02d21a9c: bl      #0x2b70d54                                 fn_2b70d54
02d21aa0: adrp    x8, #0x6269000                             
02d21aa4: ldr     x8, [x8, #0xe18]                           MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::AwaitUnsafeOnCompleted
02d21aa8: ldr     x3, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d21aac: add     x0, x19, #8                                
02d21ab0: add     x1, sp, #0x10                              
02d21ab4: mov     x2, x19                                    
02d21ab8: bl      #0x30c4590                                 fn_30c4590
02d21abc: b       #0x2d21a6c                                 
02d21ac0: ldr     q0, [sp, #0x10]                            
02d21ac4: str     wzr, [x19]                                 
02d21ac8: str     q0, [x19, #0x30]                           
02d21acc: add     x0, x19, #0x30                             
02d21ad0: mov     x1, xzr                                    
02d21ad4: bl      #0x2b70d54                                 fn_2b70d54
02d21ad8: adrp    x8, #0x6269000                             
02d21adc: ldr     x8, [x8, #0xe18]                           MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::AwaitUnsafeOnCompleted
02d21ae0: ldr     x3, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d21ae4: add     x0, x19, #8                                
02d21ae8: add     x1, sp, #0x10                              
02d21aec: mov     x2, x19                                    
02d21af0: bl      #0x30c4590                                 fn_30c4590
02d21af4: b       #0x2d21a6c                                 
02d21af8: bl      #0x2b7105c                                 fn_2b7105c
02d21afc: bl      #0x2b7105c                                 fn_2b7105c
02d21b00: bl      #0x2b7105c                                 fn_2b7105c
02d21b04: bl      #0x2b7105c                                 fn_2b7105c
02d21b08: bl      #0x2b7105c                                 fn_2b7105c
02d21b0c: bl      #0x2b7105c                                 fn_2b7105c
02d21b10: bl      #0x2b7105c                                 fn_2b7105c
02d21b14: bl      #0x2b7105c                                 fn_2b7105c
02d21b18: bl      #0x2b7105c                                 fn_2b7105c
02d21b1c: bl      #0x2b7105c                                 fn_2b7105c
02d21b20: bl      #0x2b7105c                                 fn_2b7105c
02d21b24: bl      #0x2b7105c                                 fn_2b7105c
02d21b28: bl      #0x2b7105c                                 fn_2b7105c
02d21b2c: bl      #0x2b7105c                                 fn_2b7105c
02d21b30: bl      #0x2b7105c                                 fn_2b7105c
02d21b34: bl      #0x2b7105c                                 fn_2b7105c
02d21b38: bl      #0x2b7105c                                 fn_2b7105c
02d21b3c: bl      #0x2b7105c                                 fn_2b7105c
02d21b40: bl      #0x2b7105c                                 fn_2b7105c
02d21b44: bl      #0x2b7105c                                 fn_2b7105c
02d21b48: bl      #0x2b7105c                                 fn_2b7105c
02d21b4c: bl      #0x2b7105c                                 fn_2b7105c
02d21b50: bl      #0x2b7105c                                 fn_2b7105c
02d21b54: bl      #0x2b7105c                                 fn_2b7105c
02d21b58: bl      #0x2b7105c                                 fn_2b7105c
02d21b5c: bl      #0x2b7105c                                 fn_2b7105c
02d21b60: bl      #0x2b7105c                                 fn_2b7105c
02d21b64: bl      #0x2b7105c                                 fn_2b7105c
02d21b68: bl      #0x2b7105c                                 fn_2b7105c
02d21b6c: bl      #0x2b7105c                                 fn_2b7105c
02d21b70: bl      #0x2b7105c                                 fn_2b7105c
02d21b74: b       #0x2d21c60                                 
02d21b78: b       #0x2d21c60                                 
02d21b7c: b       #0x2d21c60                                 
02d21b80: b       #0x2d21c60                                 
02d21b84: b       #0x2d21c60                                 
02d21b88: b       #0x2d21c60                                 
02d21b8c: b       #0x2d21c60                                 
02d21b90: b       #0x2d21c60                                 
02d21b94: b       #0x2d21c60                                 
02d21b98: b       #0x2d21c60                                 
02d21b9c: b       #0x2d21c60                                 
02d21ba0: b       #0x2d21c60                                 
02d21ba4: b       #0x2d21c60                                 
02d21ba8: b       #0x2d21c60                                 
02d21bac: b       #0x2d21c60                                 
02d21bb0: b       #0x2d21c60                                 
02d21bb4: b       #0x2d21c60                                 
02d21bb8: b       #0x2d21c60                                 
02d21bbc: b       #0x2d21c60                                 
02d21bc0: b       #0x2d21c60                                 
02d21bc4: b       #0x2d21c60                                 
02d21bc8: b       #0x2d21c60                                 
02d21bcc: b       #0x2d21c60                                 
02d21bd0: b       #0x2d21c60                                 
02d21bd4: b       #0x2d21c60                                 
02d21bd8: b       #0x2d21c60                                 
02d21bdc: b       #0x2d21c60                                 
02d21be0: b       #0x2d21c60                                 
02d21be4: b       #0x2d21c60                                 
02d21be8: b       #0x2d21c60                                 
02d21bec: b       #0x2d21c60                                 
02d21bf0: b       #0x2d21c60                                 
02d21bf4: b       #0x2d21c60                                 
02d21bf8: b       #0x2d21c60                                 
02d21bfc: b       #0x2d21c60                                 
02d21c00: b       #0x2d21c60                                 
02d21c04: b       #0x2d21c60                                 
02d21c08: b       #0x2d21c60                                 
02d21c0c: b       #0x2d21c60                                 
02d21c10: b       #0x2d21c60                                 
02d21c14: b       #0x2d21c60                                 
02d21c18: b       #0x2d21c60                                 
02d21c1c: b       #0x2d21c60                                 
02d21c20: b       #0x2d21c60                                 
02d21c24: b       #0x2d21c60                                 
02d21c28: b       #0x2d21c60                                 
02d21c2c: b       #0x2d21c60                                 
02d21c30: b       #0x2d21c60                                 
02d21c34: b       #0x2d21c60                                 
02d21c38: b       #0x2d21c60                                 
02d21c3c: b       #0x2d21c60                                 
02d21c40: b       #0x2d21c60                                 
02d21c44: b       #0x2d21c60                                 
02d21c48: b       #0x2d21c60                                 
02d21c4c: b       #0x2d21c60                                 
02d21c50: b       #0x2d21c60                                 
02d21c54: b       #0x2d21c60                                 
02d21c58: b       #0x2d21c60                                 
02d21c5c: b       #0x2d21c60                                 
02d21c60: mov     x20, x0                                    
02d21c64: cmp     w1, #1                                     
02d21c68: b.ne    #0x2d21cf8                                 
02d21c6c: mov     x0, x20                                    
02d21c70: bl      #0x5e90260                                 fn_5e90260
02d21c74: mov     x20, x0                                    
02d21c78: adrp    x0, #0x6263000                             
02d21c7c: ldr     x0, [x0, #0xae0]                           T:System.Exception
02d21c80: bl      #0x2b70dc4                                 fn_2b70dc4
02d21c84: ldr     x8, [x20]                                  
02d21c88: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d21c8c: bl      #0x2b71464                                 fn_2b71464
02d21c90: tbz     w0, #0, #0x2d21cd0                         
02d21c94: ldrsw   x21, [sp, #8]                              
02d21c98: ldr     x20, [x20]                                 
02d21c9c: mov     x8, sp                                     
02d21ca0: str     x20, [x8, x21, lsl #3]                     
02d21ca4: add     w8, w21, #1                                
02d21ca8: str     w8, [sp, #8]                               
02d21cac: bl      #0x5e90270                                 fn_5e90270
02d21cb0: mov     w8, #-2                                    
02d21cb4: mov     x1, x20                                    
02d21cb8: mov     x2, xzr                                    
02d21cbc: str     w8, [x19], #8                              
02d21cc0: mov     x0, x19                                    
02d21cc4: bl      #0x4d43cc0                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::SetException
02d21cc8: str     w21, [sp, #8]                              
02d21ccc: b       #0x2d21a6c                                 
02d21cd0: mov     w0, #8                                     
02d21cd4: bl      #0x5e90290                                 fn_5e90290
02d21cd8: ldr     x8, [x20]                                  
02d21cdc: str     x8, [x0]                                   
02d21ce0: adrp    x1, #0x5e96000                             
02d21ce4: add     x1, x1, #0x758                             &5e96758
02d21ce8: mov     x2, xzr                                    
02d21cec: bl      #0x5e902a0                                 fn_5e902a0
02d21cf0: mov     x20, x0                                    
02d21cf4: bl      #0x5e90270                                 fn_5e90270
02d21cf8: mov     x0, x20                                    
02d21cfc: bl      #0x2c6051c                                 fn_2c6051c
02d21d00: bl      #0x27369b8                                 fn_27369b8
## SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine stateMachine) -> void
---- Home.PopupIntroScoop/<OnShow>d__19::SetStateMachine 0x2d21d04
02d21d04: add     x0, x0, #8                                 
02d21d08: mov     x2, xzr                                    
02d21d0c: b       #0x4d43a8c                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::SetStateMachine
#### CLASS Home.PopupIntroScoop parent= PopupBase
#   field _commentHandler                CommentHandler                                     off=0x38 attr=1 SerializeField
#   field _playButton                    UnityEngine.UI.Button                              off=0x40 attr=1 SerializeField
#   field _backButton                    UnityEngine.UI.Button                              off=0x48 attr=1 SerializeField
#   field _playButtonImage               UnityEngine.UI.Image                               off=0x50 attr=1 SerializeField
#   field _customerAvatar                UnityEngine.UI.Image                               off=0x58 attr=1 SerializeField
#   field _txtPlayButton                 TMPro.TextMeshProUGUI                              off=0x60 attr=1 SerializeField
#   field _txtPlayButtonOff              TMPro.TextMeshProUGUI                              off=0x68 attr=1 SerializeField
#   field _txtCustomerName               TMPro.TextMeshProUGUI                              off=0x70 attr=1 SerializeField
#   field _txtOrder                      TMPro.TextMeshProUGUI                              off=0x78 attr=1 SerializeField
#   field _txtTipMoney                   TMPro.TextMeshProUGUI                              off=0x80 attr=1 SerializeField
#   field _viewerNameAsset               ViewerNameAsset                                    off=0x88 attr=1 SerializeField
#   field _viewerAvatarAsset             ViewerAvatarAsset                                  off=0x90 attr=1 SerializeField
#   field _profilePanel                  ProfilePanel                                       off=0x98 attr=1 SerializeField
#   field _livestreamPanel               Livestream.LivestreamPanel                         off=0xa0 attr=1 SerializeField
#   field _missionBoard                  UnityEngine.GameObject                             off=0xa8 attr=1 SerializeField
#   field _charmBlindBoxAsset            ScoopGame.CharmBlindBoxAsset                       off=0xb0 attr=1 SerializeField
#   field _coroutineSpawnComment         UnityEngine.Coroutine                              off=0xb8 attr=1 
## OnInit(UIManager uiManager) -> void
---- Home.PopupIntroScoop::OnInit 0x2d20838
02d20838: str     x30, [sp, #-0x30]!                         
02d2083c: stp     x22, x21, [sp, #0x10]                      
02d20840: stp     x20, x19, [sp, #0x20]                      
02d20844: adrp    x21, #0x6630000                            
02d20848: mov     x20, x1                                    
02d2084c: mov     x19, x0                                    
02d20850: ldrb    w8, [x21, #0x45]                           
02d20854: tbnz    w8, #0, #0x2d2089c                         
02d20858: adrp    x0, #0x6269000                             
02d2085c: ldr     x0, [x0, #0xdf0]                           M:Home.PopupIntroScoop::OnButtonBackClicked
02d20860: bl      #0x2b70db0                                 fn_2b70db0
02d20864: adrp    x0, #0x6269000                             
02d20868: ldr     x0, [x0, #0xdf8]                           M:Home.PopupIntroScoop::OnButtonPlayClicked
02d2086c: bl      #0x2b70db0                                 fn_2b70db0
02d20870: adrp    x0, #0x6264000                             
02d20874: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02d20878: bl      #0x2b70db0                                 fn_2b70db0
02d2087c: adrp    x0, #0x6265000                             
02d20880: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d20884: bl      #0x2b70db0                                 fn_2b70db0
02d20888: adrp    x0, #0x6269000                             
02d2088c: ldr     x0, [x0, #0xdb8]                           S:'+{0}'
02d20890: bl      #0x2b70db0                                 fn_2b70db0
02d20894: mov     w8, #1                                     
02d20898: strb    w8, [x21, #0x45]                           
02d2089c: mov     x0, x19                                    
02d208a0: mov     x1, x20                                    
02d208a4: mov     x2, xzr                                    
02d208a8: bl      #0x2cdd3c4                                 UIBase::OnInit
02d208ac: ldr     x8, [x19, #0x40]                           ._playButton
02d208b0: cbz     x8, #0x2d20a70                             
02d208b4: adrp    x22, #0x6265000                            
02d208b8: adrp    x21, #0x6269000                            
02d208bc: ldr     x22, [x22, #0x3f0]                         T:UnityEngine.Events.UnityAction
02d208c0: ldr     x21, [x21, #0xdf8]                         M:Home.PopupIntroScoop::OnButtonPlayClicked
02d208c4: ldr     x20, [x8, #0x100]                          
02d208c8: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d208cc: bl      #0x2b7104c                                 fn_2b7104c
02d208d0: ldr     x2, [x21]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d208d4: mov     x1, x19                                    
02d208d8: mov     x3, xzr                                    
02d208dc: mov     x21, x0                                    
02d208e0: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d208e4: cbz     x20, #0x2d20a70                            
02d208e8: mov     x0, x20                                    
02d208ec: mov     x1, x21                                    
02d208f0: mov     x2, xzr                                    
02d208f4: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d208f8: ldr     x8, [x19, #0x48]                           ._backButton
02d208fc: cbz     x8, #0x2d20a70                             
02d20900: adrp    x21, #0x6269000                            
02d20904: ldr     x21, [x21, #0xdf0]                         M:Home.PopupIntroScoop::OnButtonBackClicked
02d20908: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d2090c: ldr     x20, [x8, #0x100]                          
02d20910: bl      #0x2b7104c                                 fn_2b7104c
02d20914: ldr     x2, [x21]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d20918: mov     x1, x19                                    
02d2091c: mov     x3, xzr                                    
02d20920: mov     x21, x0                                    
02d20924: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d20928: cbz     x20, #0x2d20a70                            
02d2092c: mov     x0, x20                                    
02d20930: mov     x1, x21                                    
02d20934: mov     x2, xzr                                    
02d20938: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d2093c: ldr     x0, [x19, #0xa0]                           ._livestreamPanel
02d20940: cbz     x0, #0x2d20a70                             
02d20944: mov     x1, xzr                                    
02d20948: bl      #0x2d11b9c                                 Livestream.LivestreamPanel::Initialized
02d2094c: ldr     x0, [x19, #0xa8]                           ._missionBoard
02d20950: cbz     x0, #0x2d20a70                             
02d20954: mov     x1, xzr                                    
02d20958: bl      #0x5b368f0                                 UnityEngine.GameObject::get_transform
02d2095c: adrp    x21, #0x662f000                            
02d20960: mov     x20, x0                                    
02d20964: ldrb    w8, [x21, #0x91a]                          
02d20968: cbnz    w8, #0x2d20980                             
02d2096c: adrp    x0, #0x6264000                             
02d20970: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d20974: bl      #0x2b70db0                                 fn_2b70db0
02d20978: mov     w8, #1                                     
02d2097c: strb    w8, [x21, #0x91a]                          
02d20980: cbz     x20, #0x2d20a70                            
02d20984: adrp    x8, #0x6264000                             
02d20988: adrp    x21, #0x6264000                            
02d2098c: mov     x0, x20                                    
02d20990: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02d20994: mov     x1, xzr                                    
02d20998: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d2099c: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d209a0: ldr     x21, [x21, #0xfc0]                         T:RemoteConfigManager
02d209a4: ldp     s1, s2, [x8, #4]                           
02d209a8: ldr     s0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d209ac: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d209b0: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d209b4: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02d209b8: cbnz    w8, #0x2d209c0                             
02d209bc: bl      #0x2b70f30                                 fn_2b70f30
02d209c0: adrp    x20, #0x662f000                            
02d209c4: ldrb    w8, [x20, #0xbc1]                          
02d209c8: cbnz    w8, #0x2d209e0                             
02d209cc: adrp    x0, #0x6264000                             
02d209d0: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02d209d4: bl      #0x2b70db0                                 fn_2b70db0
02d209d8: mov     w8, #1                                     
02d209dc: strb    w8, [x20, #0xbc1]                          
02d209e0: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d209e4: adrp    x20, #0x6269000                            
02d209e8: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02d209ec: ldr     x20, [x20, #0xdb8]                         S:'+{0}'
02d209f0: cbnz    w8, #0x2d209fc                             
02d209f4: bl      #0x2b70f30                                 fn_2b70f30
02d209f8: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d209fc: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode ._coroutineSpawnComment
02d20a00: adrp    x9, #0x6263000                             
02d20a04: mov     w10, #0x12c                                
02d20a08: add     x1, sp, #0xc                               
02d20a0c: ldr     w8, [x8, #0x10]                            M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0::<DOSetFloat>b__0
02d20a10: ldr     x9, [x9, #0x970]                           &6645c70(=0)
02d20a14: ldr     x19, [x19, #0x80]                          ._txtTipMoney
02d20a18: cmp     w8, #1                                     
02d20a1c: mov     w8, #0xc8                                  
02d20a20: ldr     x0, [x9, #0x48]                            &6263098(=0)
02d20a24: csel    w8, w10, w8, eq                            
02d20a28: str     w8, [sp, #0xc]                             
02d20a2c: bl      #0x2b70f38                                 fn_2b70f38
02d20a30: ldr     x8, [x20]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d20a34: mov     x1, x0                                     
02d20a38: mov     x2, xzr                                    
02d20a3c: mov     x0, x8                                     
02d20a40: bl      #0x4c9d0ec                                 System.String::Format
02d20a44: cbz     x19, #0x2d20a70                            
02d20a48: ldr     x8, [x19]                                  
02d20a4c: mov     x1, x0                                     
02d20a50: mov     x0, x19                                    
02d20a54: ldr     x9, [x8, #0x558]                           M:DG.Tweening.DOTweenModuleUI/<>c__DisplayClass23_0::<DOPivotX>b__1
02d20a58: ldr     x2, [x8, #0x560]                           T:DG.Tweening.DOTweenModuleUI/<>c__DisplayClass24_0
02d20a5c: blr     x9                                         
02d20a60: ldp     x20, x19, [sp, #0x20]                      
02d20a64: ldp     x22, x21, [sp, #0x10]                      
02d20a68: ldr     x30, [sp], #0x30                           
02d20a6c: ret                                                
02d20a70: bl      #0x2b7105c                                 fn_2b7105c
## OnHide() -> void
---- Home.PopupIntroScoop::OnHide 0x2d20a74
02d20a74: stp     x30, x19, [sp, #-0x10]!                    
02d20a78: mov     x1, xzr                                    
02d20a7c: mov     x19, x0                                    
02d20a80: bl      #0x2cddc10                                 UIBase::OnHide
02d20a84: ldr     x0, [x19, #0xa0]                           ._livestreamPanel
02d20a88: cbz     x0, #0x2d20a98                             
02d20a8c: mov     x1, xzr                                    
02d20a90: ldp     x30, x19, [sp], #0x10                      
02d20a94: b       #0x2d11cdc                                 Livestream.LivestreamPanel::OnHide
02d20a98: bl      #0x2b7105c                                 fn_2b7105c
## OnShow() -> void
---- Home.PopupIntroScoop::OnShow 0x2d20a9c
02d20a9c: sub     sp, sp, #0x80                              
02d20aa0: stp     x30, x21, [sp, #0x60]                      
02d20aa4: stp     x20, x19, [sp, #0x70]                      
02d20aa8: adrp    x21, #0x6630000                            
02d20aac: adrp    x20, #0x6269000                            
02d20ab0: mov     x19, x0                                    
02d20ab4: ldrb    w8, [x21, #0x46]                           
02d20ab8: ldr     x20, [x20, #0xe00]                         MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::Start
02d20abc: tbnz    w8, #0, #0x2d20ad4                         
02d20ac0: adrp    x0, #0x6269000                             
02d20ac4: ldr     x0, [x0, #0xe00]                           MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::Start
02d20ac8: bl      #0x2b70db0                                 fn_2b70db0
02d20acc: mov     w8, #1                                     
02d20ad0: strb    w8, [x21, #0x46]                           
02d20ad4: movi    v0.2d, #0000000000000000                   
02d20ad8: mov     x8, sp                                     
02d20adc: mov     x0, xzr                                    
02d20ae0: stp     q0, q0, [sp, #0x20]                        
02d20ae4: stp     q0, q0, [sp, #0x40]                        
02d20ae8: bl      #0x4d43a24                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::Create
02d20aec: ldp     q0, q1, [sp]                               
02d20af0: add     x21, sp, #0x20                             
02d20af4: orr     x0, x21, #8                                
02d20af8: mov     x1, xzr                                    
02d20afc: stur    q0, [sp, #0x28]                            
02d20b00: stur    q1, [sp, #0x38]                            
02d20b04: bl      #0x2b70d54                                 fn_2b70d54
02d20b08: add     x0, x21, #0x28                             &6630028
02d20b0c: mov     x1, x19                                    
02d20b10: str     x19, [sp, #0x48]                           
02d20b14: bl      #0x2b70d54                                 fn_2b70d54
02d20b18: ldr     x2, [x20]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d20b1c: mov     w8, #-1                                    
02d20b20: orr     x0, x21, #8                                
02d20b24: add     x1, sp, #0x20                              
02d20b28: str     w8, [sp, #0x20]                            
02d20b2c: bl      #0x30c8714                                 fn_30c8714
02d20b30: ldp     x20, x19, [sp, #0x70]                      
02d20b34: ldp     x30, x21, [sp, #0x60]                      
02d20b38: add     sp, sp, #0x80                              
02d20b3c: ret                                                
## OnButtonPlayClicked() -> void
---- Home.PopupIntroScoop::OnButtonPlayClicked 0x2d20b40
02d20b40: str     x30, [sp, #-0x30]!                         
02d20b44: stp     x22, x21, [sp, #0x10]                      
02d20b48: stp     x20, x19, [sp, #0x20]                      
02d20b4c: adrp    x20, #0x6630000                            
02d20b50: mov     x19, x0                                    
02d20b54: ldrb    w8, [x20, #0x47]                           
02d20b58: tbnz    w8, #0, #0x2d20bb8                         
02d20b5c: adrp    x0, #0x6266000                             
02d20b60: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d20b64: bl      #0x2b70db0                                 fn_2b70db0
02d20b68: adrp    x0, #0x6265000                             
02d20b6c: ldr     x0, [x0, #0xb38]                           T:DevTrack
02d20b70: bl      #0x2b70db0                                 fn_2b70db0
02d20b74: adrp    x0, #0x6266000                             
02d20b78: ldr     x0, [x0, #0x5e0]                           T:GameConfig
02d20b7c: bl      #0x2b70db0                                 fn_2b70db0
02d20b80: adrp    x0, #0x6267000                             
02d20b84: ldr     x0, [x0, #0xd50]                           MS:MonoSingleton`1::get_Instance
02d20b88: bl      #0x2b70db0                                 fn_2b70db0
02d20b8c: adrp    x0, #0x6265000                             
02d20b90: ldr     x0, [x0, #0x10]                            MS:MonoSingleton`1::get_Instance
02d20b94: bl      #0x2b70db0                                 fn_2b70db0
02d20b98: adrp    x0, #0x6266000                             
02d20b9c: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d20ba0: bl      #0x2b70db0                                 fn_2b70db0
02d20ba4: adrp    x0, #0x6266000                             
02d20ba8: ldr     x0, [x0, #0xb48]                           MS:MonoSingleton`1::get_Instance
02d20bac: bl      #0x2b70db0                                 fn_2b70db0
02d20bb0: mov     w8, #1                                     
02d20bb4: strb    w8, [x20, #0x47]                           
02d20bb8: mov     x0, xzr                                    
02d20bbc: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d20bc0: cbz     x0, #0x2d20e00                             
02d20bc4: movi    d1, #0000000000000000                      
02d20bc8: movi    d2, #0000000000000000                      
02d20bcc: adrp    x20, #0x6267000                            
02d20bd0: fmov    s0, #1.00000000                            
02d20bd4: ldr     x20, [x20, #0xd50]                         MS:MonoSingleton`1::get_Instance
02d20bd8: mov     w1, #1                                     
02d20bdc: mov     w2, wzr                                    
02d20be0: mov     w3, wzr                                    
02d20be4: mov     x4, xzr                                    
02d20be8: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d20bec: ldr     x0, [x20]                                  S:'didu'
02d20bf0: bl      #0x3769600                                 fn_3769600
02d20bf4: cbz     x0, #0x2d20e00                             
02d20bf8: mov     w1, #4                                     
02d20bfc: mov     x2, xzr                                    
02d20c00: bl      #0x2cc6ee0                                 Framework.VibrationManager::Haptic
02d20c04: mov     x0, x19                                    
02d20c08: bl      #0x2d20e04                                 Home.PopupIntroScoop::StartButtonPlayClickEffect
02d20c0c: ldr     x0, [x19, #0x40]                           ._playButton
02d20c10: cbz     x0, #0x2d20e00                             
02d20c14: mov     w1, wzr                                    
02d20c18: mov     x2, xzr                                    
02d20c1c: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d20c20: ldr     x8, [x19, #0x38]                           ._commentHandler
02d20c24: cbz     x8, #0x2d20e00                             
02d20c28: adrp    x9, #0x6265000                             
02d20c2c: adrp    x20, #0x6266000                            
02d20c30: ldr     x9, [x9, #0x10]                            MS:MonoSingleton`1::get_Instance
02d20c34: ldr     x20, [x20, #0x5e0]                         T:GameConfig
02d20c38: strb    wzr, [x8, #0x20]                           
02d20c3c: ldr     x0, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02d20c40: bl      #0x3769600                                 fn_3769600
02d20c44: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d20c48: mov     x19, x0                                    
02d20c4c: ldr     w9, [x8, #0xe4]                            
02d20c50: cbnz    w9, #0x2d20c5c                             
02d20c54: mov     x0, x8                                     
02d20c58: bl      #0x2b70f30                                 fn_2b70f30
02d20c5c: cbz     x19, #0x2d20e00                            
02d20c60: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d20c64: adrp    x20, #0x6266000                            
02d20c68: mov     x0, x19                                    
02d20c6c: mov     w2, wzr                                    
02d20c70: mov     x3, xzr                                    
02d20c74: ldr     x8, [x8, #0xb8]                            
02d20c78: ldr     x20, [x20, #0x658]                         MS:MonoSingleton`1::get_Instance
02d20c7c: ldr     x1, [x8, #0x30]                            
02d20c80: bl      #0x2ce9e58                                 SimpleSceneTransition::FlashIn
02d20c84: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d20c88: bl      #0x3769600                                 fn_3769600
02d20c8c: cbz     x0, #0x2d20e00                             
02d20c90: adrp    x8, #0x6266000                             
02d20c94: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02d20c98: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d20c9c: bl      #0x3168dd0                                 fn_3168dd0
02d20ca0: cbz     x0, #0x2d20e00                             
02d20ca4: ldr     x8, [x0, #0x20]                            S:'inter_ad_capping_time'
02d20ca8: mov     x19, x0                                    
02d20cac: cbz     x8, #0x2d20e00                             
02d20cb0: adrp    x21, #0x6265000                            
02d20cb4: adrp    x22, #0x6266000                            
02d20cb8: ldr     x21, [x21, #0xb38]                         T:DevTrack
02d20cbc: ldrb    w8, [x8, #0x3a]                            
02d20cc0: ldr     x22, [x22, #0xb48]                         MS:MonoSingleton`1::get_Instance
02d20cc4: cbz     w8, #0x2d20cf4                             
02d20cc8: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d20ccc: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d20cd0: cbnz    w8, #0x2d20cdc                             
02d20cd4: bl      #0x2b70f30                                 fn_2b70f30
02d20cd8: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d20cdc: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time' ._coroutineSpawnComment
02d20ce0: mov     x3, xzr                                    
02d20ce4: ldr     x0, [x8, #0x208]                           MS:System.Collections.Generic.List`1::Add
02d20ce8: ldr     x1, [x8, #0x218]                           MS:System.Collections.Generic.List`1::.ctor
02d20cec: ldr     w2, [x8, #0x270]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d20cf0: bl      #0x2c9c1e0                                 DevTrack::OnboardingStep
02d20cf4: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d20cf8: bl      #0x3769600                                 fn_3769600
02d20cfc: ldr     x8, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d20d00: mov     x20, x0                                    
02d20d04: ldr     w9, [x8, #0xe4]                            [62660e4]=0 f=0,0
02d20d08: cbnz    w9, #0x2d20d14                             
02d20d0c: mov     x0, x8                                     
02d20d10: bl      #0x2b70f30                                 fn_2b70f30
02d20d14: cbz     x20, #0x2d20e00                            
02d20d18: ldr     x8, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d20d1c: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02d20d20: ldr     x1, [x8, #0x358]                           MS:UnityEngine.JsonUtility::FromJson
02d20d24: str     x1, [x20, #0x30]!                          
02d20d28: mov     x0, x20                                    
02d20d2c: bl      #0x2b70d54                                 fn_2b70d54
02d20d30: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d20d34: bl      #0x3769600                                 fn_3769600
02d20d38: ldr     x8, [x19, #0x20]                           
02d20d3c: cbz     x8, #0x2d20e00                             
02d20d40: cbz     x0, #0x2d20e00                             
02d20d44: ldr     w8, [x8, #0x54]                            [6266054]=0 f=0,0
02d20d48: add     w9, w8, #1                                 
02d20d4c: ldr     x8, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d20d50: str     w9, [x0, #0x3c]                            
02d20d54: mov     x0, x8                                     
02d20d58: bl      #0x3769600                                 fn_3769600
02d20d5c: mov     x20, x0                                    
02d20d60: mov     x0, xzr                                    
02d20d64: bl      #0x5b432fc                                 UnityEngine.Time::get_time
02d20d68: cbz     x20, #0x2d20e00                            
02d20d6c: ldr     x8, [x19, #0x20]                           
02d20d70: str     s0, [x20, #0x38]                           ._commentHandler
02d20d74: cbz     x8, #0x2d20e00                             
02d20d78: ldr     x9, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d20d7c: ldr     w8, [x8, #0x54]                            [6266054]=0 f=0,0
02d20d80: mov     x3, xzr                                    
02d20d84: ldr     x9, [x9, #0xb8]                            T:AdsManager/<>c__DisplayClass42_0
02d20d88: add     w1, w8, #1                                 
02d20d8c: ldr     x0, [x9, #0x358]                           T:type7234(k15)
02d20d90: ldr     x2, [x9, #0x1e0]                           S:'_OnAdLoadedEvent'
02d20d94: bl      #0x2c9c5c4                                 DevTrack::GameModeStart
02d20d98: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d20d9c: bl      #0x3769600                                 fn_3769600
02d20da0: cbz     x0, #0x2d20e00                             
02d20da4: ldr     x19, [x0, #0x30]                           S:'popup_rate_on_off'
02d20da8: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d20dac: bl      #0x3769600                                 fn_3769600
02d20db0: cbz     x0, #0x2d20e00                             
02d20db4: ldr     x8, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d20db8: ldr     w1, [x0, #0x3c]                            [626603c]=0 f=0,0
02d20dbc: mov     x0, x19                                    
02d20dc0: mov     x4, xzr                                    
02d20dc4: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02d20dc8: ldr     x2, [x8, #0x218]                           MS:System.Collections.Generic.List`1::.ctor
02d20dcc: ldr     w3, [x8, #0x270]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d20dd0: bl      #0x2c9c714                                 DevTrack::GameModeStepEnter
02d20dd4: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d20dd8: bl      #0x3769600                                 fn_3769600
02d20ddc: cbz     x0, #0x2d20e00                             
02d20de0: ldr     x8, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d20de4: ldp     x20, x19, [sp, #0x20]                      
02d20de8: ldp     x22, x21, [sp, #0x10]                      
02d20dec: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02d20df0: ldr     x1, [x8, #0x218]                           MS:System.Collections.Generic.List`1::.ctor
02d20df4: str     x1, [x0, #0x40]!                           ._playButton
02d20df8: ldr     x30, [sp], #0x30                           
02d20dfc: b       #0x2b70d54                                 
02d20e00: bl      #0x2b7105c                                 fn_2b7105c
## OnButtonBackClicked() -> void
---- Home.PopupIntroScoop::OnButtonBackClicked 0x2d20ea8
02d20ea8: str     x30, [sp, #-0x30]!                         
02d20eac: stp     x22, x21, [sp, #0x10]                      
02d20eb0: stp     x20, x19, [sp, #0x20]                      
02d20eb4: adrp    x20, #0x6630000                            
02d20eb8: mov     x19, x0                                    
02d20ebc: ldrb    w8, [x20, #0x48]                           ._backButton
02d20ec0: tbnz    w8, #0, #0x2d20efc                         
02d20ec4: adrp    x0, #0x6264000                             
02d20ec8: ldr     x0, [x0, #0xf90]                           T:System.Action
02d20ecc: bl      #0x2b70db0                                 fn_2b70db0
02d20ed0: adrp    x0, #0x6269000                             
02d20ed4: ldr     x0, [x0, #0xe08]                           M:Home.PopupIntroScoop::<OnButtonBackClicked>b__21_0
02d20ed8: bl      #0x2b70db0                                 fn_2b70db0
02d20edc: adrp    x0, #0x6265000                             
02d20ee0: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02d20ee4: bl      #0x2b70db0                                 fn_2b70db0
02d20ee8: adrp    x0, #0x6269000                             
02d20eec: ldr     x0, [x0, #0xe10]                           S:'scoop_home_click'
02d20ef0: bl      #0x2b70db0                                 fn_2b70db0
02d20ef4: mov     w8, #1                                     
02d20ef8: strb    w8, [x20, #0x48]                           ._backButton
02d20efc: mov     x0, xzr                                    
02d20f00: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d20f04: cbz     x0, #0x2d20f9c                             
02d20f08: movi    d1, #0000000000000000                      
02d20f0c: movi    d2, #0000000000000000                      
02d20f10: adrp    x20, #0x6265000                            
02d20f14: fmov    s0, #1.00000000                            
02d20f18: adrp    x21, #0x6264000                            
02d20f1c: adrp    x22, #0x6269000                            
02d20f20: ldr     x20, [x20, #0x310]                         MS:WejoyService.Singleton`1::get_Instance
02d20f24: ldr     x21, [x21, #0xf90]                         T:System.Action
02d20f28: ldr     x22, [x22, #0xe08]                         M:Home.PopupIntroScoop::<OnButtonBackClicked>b__21_0
02d20f2c: mov     w1, #1                                     
02d20f30: mov     w2, wzr                                    
02d20f34: mov     w3, wzr                                    
02d20f38: mov     x4, xzr                                    
02d20f3c: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d20f40: ldr     x0, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d20f44: bl      #0x3be7218                                 fn_3be7218
02d20f48: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d20f4c: mov     x20, x0                                    
02d20f50: mov     x0, x8                                     
02d20f54: bl      #0x2b7104c                                 fn_2b7104c
02d20f58: ldr     x2, [x22]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d20f5c: mov     x1, x19                                    
02d20f60: mov     x3, xzr                                    
02d20f64: mov     x21, x0                                    
02d20f68: bl      #0x4d8ddbc                                 System.Action::.ctor
02d20f6c: cbz     x20, #0x2d20f9c                            
02d20f70: adrp    x8, #0x6269000                             
02d20f74: mov     x0, x20                                    
02d20f78: mov     x2, x21                                    
02d20f7c: ldr     x8, [x8, #0xe10]                           S:'scoop_home_click'
02d20f80: ldp     x20, x19, [sp, #0x20]                      
02d20f84: ldp     x22, x21, [sp, #0x10]                      
02d20f88: mov     w3, #1                                     
02d20f8c: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d20f90: mov     x4, xzr                                    
02d20f94: ldr     x30, [sp], #0x30                           
02d20f98: b       #0x2c89698                                 AdsManager::ShowInter
02d20f9c: bl      #0x2b7105c                                 fn_2b7105c
## StartButtonPlayClickEffect() -> void
---- Home.PopupIntroScoop::StartButtonPlayClickEffect 0x2d20e04
02d20e04: str     x30, [sp, #-0x20]!                         
02d20e08: stp     x20, x19, [sp, #0x10]                      
02d20e0c: mov     x19, x0                                    
02d20e10: bl      #0x2d20fa0                                 Home.PopupIntroScoop::StopButtonPlayAnim
02d20e14: ldr     x0, [x19, #0x40]                           ._playButton
02d20e18: cbz     x0, #0x2d20ea4                             
02d20e1c: mov     x1, xzr                                    
02d20e20: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d20e24: adrp    x20, #0x662f000                            
02d20e28: mov     x19, x0                                    
02d20e2c: ldrb    w8, [x20, #0xa74]                          
02d20e30: cbnz    w8, #0x2d20e48                             
02d20e34: adrp    x0, #0x6264000                             
02d20e38: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d20e3c: bl      #0x2b70db0                                 fn_2b70db0
02d20e40: mov     w8, #1                                     
02d20e44: strb    w8, [x20, #0xa74]                          
02d20e48: adrp    x8, #0x6264000                             
02d20e4c: mov     w9, #0xcccd                                
02d20e50: mov     x0, x19                                    
02d20e54: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02d20e58: movk    w9, #0x3dcc, lsl #16                       
02d20e5c: fmov    s4, #1.00000000                            
02d20e60: dup     v0.2s, w9                                  
02d20e64: adrp    x9, #0x1084000                             
02d20e68: mov     w1, #0xa                                   
02d20e6c: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d20e70: ldp     x20, x19, [sp, #0x10]                      
02d20e74: mov     x2, xzr                                    
02d20e78: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d20e7c: ldur    d1, [x8, #0xc]                             
02d20e80: ldr     s2, [x8, #0x14]                            [6264014]=0 f=0,0
02d20e84: adrp    x8, #0x1084000                             
02d20e88: ldr     s3, [x8, #0xdd8]                           [1084dd8]=3f7333333e4ccccd f=0.2,0.95
02d20e8c: fmul    v0.2s, v1.2s, v0.2s                        
02d20e90: ldr     s1, [x9, #0xeec]                           [1084eec]=457ff0003dcccccd f=0.1,4095
02d20e94: fmul    s2, s2, s1                                 
02d20e98: mov     s1, v0.s[1]                                
02d20e9c: ldr     x30, [sp], #0x20                           
02d20ea0: b       #0x2d9982c                                 DG.Tweening.ShortcutExtensions::DOPunchScale
02d20ea4: bl      #0x2b7105c                                 fn_2b7105c
## StartButtonPlayAnim() -> void
---- Home.PopupIntroScoop::StartButtonPlayAnim 0x2d21030
02d21030: str     x30, [sp, #-0x30]!                         
02d21034: stp     x22, x21, [sp, #0x10]                      
02d21038: stp     x20, x19, [sp, #0x20]                      
02d2103c: adrp    x20, #0x6630000                            
02d21040: mov     x19, x0                                    
02d21044: ldrb    w8, [x20, #0x49]                           
02d21048: tbnz    w8, #0, #0x2d2106c                         
02d2104c: adrp    x0, #0x6266000                             
02d21050: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d21054: bl      #0x2b70db0                                 fn_2b70db0
02d21058: adrp    x0, #0x6268000                             
02d2105c: ldr     x0, [x0, #0x10]                            MS:DG.Tweening.TweenSettingsExtensions::SetLoops
02d21060: bl      #0x2b70db0                                 fn_2b70db0
02d21064: mov     w8, #1                                     
02d21068: strb    w8, [x20, #0x49]                           
02d2106c: mov     x0, x19                                    
02d21070: bl      #0x2d20fa0                                 Home.PopupIntroScoop::StopButtonPlayAnim
02d21074: ldr     x0, [x19, #0x40]                           ._playButton
02d21078: cbz     x0, #0x2d2112c                             
02d2107c: adrp    x21, #0x6266000                            
02d21080: adrp    x20, #0x6268000                            
02d21084: mov     x1, xzr                                    
02d21088: ldr     x21, [x21, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d2108c: ldr     x20, [x20, #0x10]                          MS:DG.Tweening.TweenSettingsExtensions::SetLoops
02d21090: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d21094: adrp    x22, #0x662f000                            
02d21098: mov     x19, x0                                    
02d2109c: ldrb    w8, [x22, #0xa74]                          
02d210a0: cbnz    w8, #0x2d210b8                             
02d210a4: adrp    x0, #0x6264000                             
02d210a8: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d210ac: bl      #0x2b70db0                                 fn_2b70db0
02d210b0: mov     w8, #1                                     
02d210b4: strb    w8, [x22, #0xa74]                          
02d210b8: adrp    x8, #0x6264000                             
02d210bc: mov     w9, #0xcccd                                
02d210c0: mov     x0, x19                                    
02d210c4: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02d210c8: movk    w9, #0x3f8c, lsl #16                       
02d210cc: mov     x1, xzr                                    
02d210d0: dup     v0.2s, w9                                  
02d210d4: adrp    x9, #0x1084000                             
02d210d8: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d210dc: ldr     s2, [x9, #0xcfc]                           [1084cfc]=3e58658c3f8ccccd f=1.1,0.211325
02d210e0: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d210e4: ldur    d1, [x8, #0xc]                             
02d210e8: fmul    v0.2s, v1.2s, v0.2s                        
02d210ec: ldr     s1, [x8, #0x14]                            [6264014]=0 f=0,0
02d210f0: adrp    x8, #0x1084000                             
02d210f4: ldr     s3, [x8, #0xda8]                           [1084da8]=da242603eb851ec f=0.36,1e-30
02d210f8: fmul    s2, s1, s2                                 
02d210fc: mov     s1, v0.s[1]                                
02d21100: bl      #0x2d98af8                                 DG.Tweening.ShortcutExtensions::DOScale
02d21104: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d21108: mov     w1, #4                                     
02d2110c: bl      #0x336fa0c                                 fn_336fa0c
02d21110: ldr     x3, [x20]                                  S:'{0}/2'
02d21114: ldp     x20, x19, [sp, #0x20]                      
02d21118: ldp     x22, x21, [sp, #0x10]                      
02d2111c: mov     w1, #-1                                    
02d21120: mov     w2, #1                                     
02d21124: ldr     x30, [sp], #0x30                           
02d21128: b       #0x336fe74                                 
02d2112c: bl      #0x2b7105c                                 fn_2b7105c
## OnDestroy() -> void
---- Home.PopupIntroScoop::OnDestroy 0x2d21130
02d21130: stp     x30, x19, [sp, #-0x10]!                    
02d21134: mov     x19, x0                                    
02d21138: ldr     x0, [x0, #0xa0]                            ._livestreamPanel
02d2113c: cbz     x0, #0x2d21184                             
02d21140: mov     x1, xzr                                    
02d21144: bl      #0x2d11cdc                                 Livestream.LivestreamPanel::OnHide
02d21148: ldr     x0, [x19, #0x40]                           ._playButton
02d2114c: cbz     x0, #0x2d21184                             
02d21150: mov     x1, xzr                                    
02d21154: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d21158: mov     w1, wzr                                    
02d2115c: mov     x2, xzr                                    
02d21160: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d21164: ldr     x1, [x19, #0xb8]                           ._coroutineSpawnComment
02d21168: cbz     x1, #0x2d2117c                             
02d2116c: mov     x0, x19                                    
02d21170: mov     x2, xzr                                    
02d21174: ldp     x30, x19, [sp], #0x10                      
02d21178: b       #0x5b38c4c                                 UnityEngine.MonoBehaviour::StopCoroutine
02d2117c: ldp     x30, x19, [sp], #0x10                      
02d21180: ret                                                
02d21184: bl      #0x2b7105c                                 fn_2b7105c
## StopButtonPlayAnim() -> void
---- Home.PopupIntroScoop::StopButtonPlayAnim 0x2d20fa0
02d20fa0: str     x30, [sp, #-0x20]!                         
02d20fa4: stp     x20, x19, [sp, #0x10]                      
02d20fa8: mov     x19, x0                                    
02d20fac: ldr     x0, [x0, #0x40]                            ._playButton
02d20fb0: cbz     x0, #0x2d2102c                             
02d20fb4: mov     x1, xzr                                    
02d20fb8: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d20fbc: mov     w1, wzr                                    
02d20fc0: mov     x2, xzr                                    
02d20fc4: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d20fc8: ldr     x0, [x19, #0x40]                           ._playButton
02d20fcc: cbz     x0, #0x2d2102c                             
02d20fd0: mov     x1, xzr                                    
02d20fd4: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d20fd8: adrp    x20, #0x662f000                            
02d20fdc: mov     x19, x0                                    
02d20fe0: ldrb    w8, [x20, #0xa74]                          
02d20fe4: cbnz    w8, #0x2d20ffc                             
02d20fe8: adrp    x0, #0x6264000                             
02d20fec: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d20ff0: bl      #0x2b70db0                                 fn_2b70db0
02d20ff4: mov     w8, #1                                     
02d20ff8: strb    w8, [x20, #0xa74]                          
02d20ffc: cbz     x19, #0x2d2102c                            
02d21000: adrp    x8, #0x6264000                             
02d21004: mov     x0, x19                                    
02d21008: mov     x1, xzr                                    
02d2100c: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02d21010: ldp     x20, x19, [sp, #0x10]                      
02d21014: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d21018: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d2101c: ldp     s0, s1, [x8, #0xc]                         
02d21020: ldr     s2, [x8, #0x14]                            [6264014]=0 f=0,0
02d21024: ldr     x30, [sp], #0x20                           
02d21028: b       #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d2102c: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Home.PopupIntroScoop::.ctor 0x2d21188
02d21188: mov     x1, xzr                                    
02d2118c: b       #0x2cddba8                                 PopupBase::.ctor
## <OnShow>b__19_0() -> void
---- Home.PopupIntroScoop::<OnShow>b__19_0 0x2d21190
02d21190: stp     x30, x19, [sp, #-0x10]!                    
02d21194: mov     x19, x0                                    
02d21198: ldr     x0, [x0, #0x40]                            ._playButton
02d2119c: cbz     x0, #0x2d211d8                             
02d211a0: mov     w1, #1                                     
02d211a4: mov     x2, xzr                                    
02d211a8: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d211ac: ldr     x0, [x19, #0x40]                           ._playButton
02d211b0: cbz     x0, #0x2d211d8                             
02d211b4: mov     x1, xzr                                    
02d211b8: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d211bc: cbz     x0, #0x2d211d8                             
02d211c0: mov     w1, #1                                     
02d211c4: mov     x2, xzr                                    
02d211c8: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d211cc: mov     x0, x19                                    
02d211d0: ldp     x30, x19, [sp], #0x10                      
02d211d4: b       #0x2d21030                                 Home.PopupIntroScoop::StartButtonPlayAnim
02d211d8: bl      #0x2b7105c                                 fn_2b7105c
## <>n__0() -> void
---- Home.PopupIntroScoop::<>n__0 0x2d211dc
02d211dc: mov     x1, xzr                                    
02d211e0: b       #0x2cdd6b8                                 UIBase::OnShow
## <OnButtonBackClicked>b__21_0() -> void
---- Home.PopupIntroScoop::<OnButtonBackClicked>b__21_0 0x2d211e4
02d211e4: str     x30, [sp, #-0x20]!                         
02d211e8: stp     x20, x19, [sp, #0x10]                      
02d211ec: adrp    x20, #0x6630000                            
02d211f0: mov     x19, x0                                    
02d211f4: ldrb    w8, [x20, #0x4a]                           
02d211f8: tbnz    w8, #0, #0x2d21210                         
02d211fc: adrp    x0, #0x6268000                             
02d21200: ldr     x0, [x0, #0x108]                           MS:UIManager::ShowScreen
02d21204: bl      #0x2b70db0                                 fn_2b70db0
02d21208: mov     w8, #1                                     
02d2120c: strb    w8, [x20, #0x4a]                           
02d21210: ldr     x8, [x19, #0x38]                           ._commentHandler
02d21214: cbz     x8, #0x2d21294                             
02d21218: strb    wzr, [x8, #0x20]                           
02d2121c: mov     x0, x19                                    
02d21220: ldr     x8, [x19]                                  
02d21224: ldp     x9, x1, [x8, #0x198]                       
02d21228: blr     x9                                         
02d2122c: ldr     x0, [x19, #0xa8]                           ._missionBoard
02d21230: cbz     x0, #0x2d21294                             
02d21234: mov     x1, xzr                                    
02d21238: bl      #0x5b368f0                                 UnityEngine.GameObject::get_transform
02d2123c: mov     w1, wzr                                    
02d21240: mov     x2, xzr                                    
02d21244: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d21248: ldr     x0, [x19, #0xa8]                           ._missionBoard
02d2124c: cbz     x0, #0x2d21294                             
02d21250: mov     x1, xzr                                    
02d21254: bl      #0x5b368f0                                 UnityEngine.GameObject::get_transform
02d21258: movi    d0, #0000000000000000                      
02d2125c: movi    d1, #0000000000000000                      
02d21260: mov     x1, xzr                                    
02d21264: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d21268: ldr     x0, [x19, #0x30]                           
02d2126c: cbz     x0, #0x2d21294                             
02d21270: adrp    x8, #0x6268000                             
02d21274: ldr     x8, [x8, #0x108]                           MS:UIManager::ShowScreen
02d21278: ldr     x1, [x8]                                   S:'{0}/2'
02d2127c: bl      #0x33fc0e8                                 fn_33fc0e8
02d21280: cbz     x0, #0x2d21294                             
02d21284: ldp     x20, x19, [sp, #0x10]                      
02d21288: mov     x1, xzr                                    
02d2128c: ldr     x30, [sp], #0x20                           
02d21290: b       #0x2cb2bd0                                 ScreenHome::MoveMoneyLeft
02d21294: bl      #0x2b7105c                                 fn_2b7105c
