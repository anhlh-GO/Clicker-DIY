#### CLASS ESaveType parent= int
#   field value__                        int                                                off=0x10 attr=606 
#   field PlayerPrefs                    ESaveType                                          off=0x0 attr=8056 
#   field File                           ESaveType                                          off=0x0 attr=8056 
