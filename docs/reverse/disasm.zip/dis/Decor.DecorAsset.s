#### CLASS Decor.DecorAsset/<>c__DisplayClass4_0 parent= object
#   field name                           string                                             off=0x10 attr=6 
## .ctor() -> void
---- Decor.DecorAsset/<>c__DisplayClass4_0::.ctor 0x2d25fb8
02d25fb8: mov     x1, xzr                                    
02d25fbc: b       #0x4e53e9c                                 System.Object::.ctor
## <GetCategoryAssetByName>b__0(Decor.CategoryAsset x) -> bool
---- Decor.DecorAsset/<>c__DisplayClass4_0::<GetCategoryAssetByName>b__0 0x2d26134
02d26134: cbz     x1, #0x2d2614c                             
02d26138: ldr     x8, [x1, #0x18]                            
02d2613c: ldr     x1, [x0, #0x10]                            .name
02d26140: mov     x2, xzr                                    
02d26144: mov     x0, x8                                     
02d26148: b       #0x4ca52b8                                 System.String::op_Equality
02d2614c: str     x30, [sp, #-0x10]!                         
02d26150: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Decor.DecorAsset/<>c__DisplayClass5_0 parent= object
#   field categoryName                   string                                             off=0x10 attr=6 
## .ctor() -> void
---- Decor.DecorAsset/<>c__DisplayClass5_0::.ctor 0x2d260a4
02d260a4: mov     x1, xzr                                    
02d260a8: b       #0x4e53e9c                                 System.Object::.ctor
## <GetCategoryIndexByName>b__0(Decor.CategoryAsset x) -> bool
---- Decor.DecorAsset/<>c__DisplayClass5_0::<GetCategoryIndexByName>b__0 0x2d26154
02d26154: cbz     x1, #0x2d2616c                             
02d26158: ldr     x8, [x1, #0x18]                            
02d2615c: ldr     x1, [x0, #0x10]                            .categoryName
02d26160: mov     x2, xzr                                    
02d26164: mov     x0, x8                                     
02d26168: b       #0x4ca52b8                                 System.String::op_Equality
02d2616c: str     x30, [sp, #-0x10]!                         
02d26170: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Decor.DecorAsset parent= UnityEngine.ScriptableObject
#   field CategoryAssets                 System.Collections.Generic.List`1<Decor.CategoryAsset> off=0x18 attr=6 
## GetCategoryAssetByIndex(int index) -> Decor.CategoryAsset
---- Decor.DecorAsset::GetCategoryAssetByIndex 0x2d249f4
02d249f4: stp     x30, x21, [sp, #-0x20]!                    
02d249f8: stp     x20, x19, [sp, #0x10]                      
02d249fc: adrp    x21, #0x6630000                            
02d24a00: mov     w19, w1                                    
02d24a04: mov     x20, x0                                    
02d24a08: ldrb    w8, [x21, #0x79]                           
02d24a0c: tbnz    w8, #0, #0x2d24a24                         
02d24a10: adrp    x0, #0x6269000                             
02d24a14: ldr     x0, [x0, #0xf20]                           MS:System.Collections.Generic.List`1::get_Item
02d24a18: bl      #0x2b70db0                                 fn_2b70db0
02d24a1c: mov     w8, #1                                     
02d24a20: strb    w8, [x21, #0x79]                           
02d24a24: ldr     x0, [x20, #0x18]                           .CategoryAssets
02d24a28: cbz     x0, #0x2d24a48                             
02d24a2c: adrp    x8, #0x6269000                             
02d24a30: mov     w1, w19                                    
02d24a34: ldr     x8, [x8, #0xf20]                           MS:System.Collections.Generic.List`1::get_Item
02d24a38: ldp     x20, x19, [sp, #0x10]                      
02d24a3c: ldr     x2, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d24a40: ldp     x30, x21, [sp], #0x20                      
02d24a44: b       #0x35a8f3c                                 
02d24a48: bl      #0x2b7105c                                 fn_2b7105c
## GetCategoryAssetCount() -> int
---- Decor.DecorAsset::GetCategoryAssetCount 0x2d255ec
02d255ec: str     x30, [sp, #-0x20]!                         
02d255f0: stp     x20, x19, [sp, #0x10]                      
02d255f4: adrp    x20, #0x6630000                            
02d255f8: mov     x19, x0                                    
02d255fc: ldrb    w8, [x20, #0x7a]                           
02d25600: tbnz    w8, #0, #0x2d25618                         
02d25604: adrp    x0, #0x6269000                             
02d25608: ldr     x0, [x0, #0xff0]                           MS:System.Collections.Generic.List`1::get_Count
02d2560c: bl      #0x2b70db0                                 fn_2b70db0
02d25610: mov     w8, #1                                     
02d25614: strb    w8, [x20, #0x7a]                           
02d25618: ldr     x8, [x19, #0x18]                           .CategoryAssets
02d2561c: cbz     x8, #0x2d25630                             
02d25620: ldp     x20, x19, [sp, #0x10]                      
02d25624: ldr     w0, [x8, #0x18]                            
02d25628: ldr     x30, [sp], #0x20                           
02d2562c: ret                                                
02d25630: bl      #0x2b7105c                                 fn_2b7105c
## GetCategoryAssetIndex(Decor.CategoryAsset categoryAsset) -> int
---- Decor.DecorAsset::GetCategoryAssetIndex 0x2d25e7c
02d25e7c: stp     x30, x21, [sp, #-0x20]!                    
02d25e80: stp     x20, x19, [sp, #0x10]                      
02d25e84: adrp    x21, #0x6630000                            
02d25e88: mov     x19, x1                                    
02d25e8c: mov     x20, x0                                    
02d25e90: ldrb    w8, [x21, #0x7b]                           
02d25e94: tbnz    w8, #0, #0x2d25eac                         
02d25e98: adrp    x0, #0x626a000                             
02d25e9c: ldr     x0, [x0, #0x40]                            MS:System.Collections.Generic.List`1::IndexOf
02d25ea0: bl      #0x2b70db0                                 fn_2b70db0
02d25ea4: mov     w8, #1                                     
02d25ea8: strb    w8, [x21, #0x7b]                           
02d25eac: ldr     x0, [x20, #0x18]                           .CategoryAssets
02d25eb0: cbz     x0, #0x2d25ed0                             
02d25eb4: adrp    x8, #0x626a000                             
02d25eb8: mov     x1, x19                                    
02d25ebc: ldr     x8, [x8, #0x40]                            MS:System.Collections.Generic.List`1::IndexOf
02d25ec0: ldp     x20, x19, [sp, #0x10]                      
02d25ec4: ldr     x2, [x8]                                   T:type56879(k15)
02d25ec8: ldp     x30, x21, [sp], #0x20                      
02d25ecc: b       #0x35a9f48                                 
02d25ed0: bl      #0x2b7105c                                 fn_2b7105c
## GetCategoryAssetByName(string name) -> Decor.CategoryAsset
---- Decor.DecorAsset::GetCategoryAssetByName 0x2d25ed4
02d25ed4: stp     x30, x23, [sp, #-0x30]!                    
02d25ed8: stp     x22, x21, [sp, #0x10]                      
02d25edc: stp     x20, x19, [sp, #0x20]                      
02d25ee0: adrp    x21, #0x6630000                            
02d25ee4: adrp    x22, #0x626a000                            
02d25ee8: mov     x19, x1                                    
02d25eec: ldrb    w8, [x21, #0x7c]                           
02d25ef0: ldr     x22, [x22, #0x48]                          T:Decor.DecorAsset/<>c__DisplayClass4_0
02d25ef4: mov     x20, x0                                    
02d25ef8: tbnz    w8, #0, #0x2d25f34                         
02d25efc: adrp    x0, #0x626a000                             
02d25f00: ldr     x0, [x0, #0x50]                            MS:System.Collections.Generic.List`1::Find
02d25f04: bl      #0x2b70db0                                 fn_2b70db0
02d25f08: adrp    x0, #0x626a000                             
02d25f0c: ldr     x0, [x0, #0x58]                            T:type57228(k15)
02d25f10: bl      #0x2b70db0                                 fn_2b70db0
02d25f14: adrp    x0, #0x626a000                             
02d25f18: ldr     x0, [x0, #0x60]                            M:Decor.DecorAsset/<>c__DisplayClass4_0::<GetCategoryAssetByName>b__0
02d25f1c: bl      #0x2b70db0                                 fn_2b70db0
02d25f20: adrp    x0, #0x626a000                             
02d25f24: ldr     x0, [x0, #0x48]                            T:Decor.DecorAsset/<>c__DisplayClass4_0
02d25f28: bl      #0x2b70db0                                 fn_2b70db0
02d25f2c: mov     w8, #1                                     
02d25f30: strb    w8, [x21, #0x7c]                           
02d25f34: ldr     x0, [x22]                                  T:type56879(k15)
02d25f38: bl      #0x2b7104c                                 fn_2b7104c
02d25f3c: mov     x1, xzr                                    
02d25f40: mov     x21, x0                                    
02d25f44: bl      #0x4e53e9c                                 System.Object::.ctor
02d25f48: cbz     x21, #0x2d25fb4                            
02d25f4c: adrp    x22, #0x626a000                            
02d25f50: adrp    x23, #0x626a000                            
02d25f54: mov     x0, x21                                    
02d25f58: ldr     x22, [x22, #0x58]                          T:type57228(k15)
02d25f5c: ldr     x23, [x23, #0x60]                          M:Decor.DecorAsset/<>c__DisplayClass4_0::<GetCategoryAssetByName>b__0
02d25f60: mov     x1, x19                                    
02d25f64: str     x19, [x0, #0x10]!                          
02d25f68: bl      #0x2b70d54                                 fn_2b70d54
02d25f6c: ldr     x0, [x22]                                  T:type56879(k15)
02d25f70: ldr     x19, [x20, #0x18]                          .CategoryAssets
02d25f74: bl      #0x2b7104c                                 fn_2b7104c
02d25f78: ldr     x2, [x23]                                  T:type56879(k15)
02d25f7c: mov     x1, x21                                    
02d25f80: mov     x3, xzr                                    
02d25f84: mov     x20, x0                                    
02d25f88: bl      #0x399ba10                                 fn_399ba10
02d25f8c: cbz     x19, #0x2d25fb4                            
02d25f90: adrp    x8, #0x626a000                             
02d25f94: mov     x0, x19                                    
02d25f98: mov     x1, x20                                    
02d25f9c: ldr     x8, [x8, #0x50]                            MS:System.Collections.Generic.List`1::Find
02d25fa0: ldp     x20, x19, [sp, #0x20]                      
02d25fa4: ldp     x22, x21, [sp, #0x10]                      
02d25fa8: ldr     x2, [x8]                                   T:type56879(k15)
02d25fac: ldp     x30, x23, [sp], #0x30                      
02d25fb0: b       #0x35a9868                                 
02d25fb4: bl      #0x2b7105c                                 fn_2b7105c
## GetCategoryIndexByName(string categoryName) -> int
---- Decor.DecorAsset::GetCategoryIndexByName 0x2d25fc0
02d25fc0: stp     x30, x23, [sp, #-0x30]!                    
02d25fc4: stp     x22, x21, [sp, #0x10]                      
02d25fc8: stp     x20, x19, [sp, #0x20]                      
02d25fcc: adrp    x21, #0x6630000                            
02d25fd0: adrp    x22, #0x626a000                            
02d25fd4: mov     x19, x1                                    
02d25fd8: ldrb    w8, [x21, #0x7d]                           
02d25fdc: ldr     x22, [x22, #0x68]                          T:Decor.DecorAsset/<>c__DisplayClass5_0
02d25fe0: mov     x20, x0                                    
02d25fe4: tbnz    w8, #0, #0x2d26020                         
02d25fe8: adrp    x0, #0x626a000                             
02d25fec: ldr     x0, [x0, #0x70]                            MS:System.Collections.Generic.List`1::FindIndex
02d25ff0: bl      #0x2b70db0                                 fn_2b70db0
02d25ff4: adrp    x0, #0x626a000                             
02d25ff8: ldr     x0, [x0, #0x58]                            T:type57228(k15)
02d25ffc: bl      #0x2b70db0                                 fn_2b70db0
02d26000: adrp    x0, #0x626a000                             
02d26004: ldr     x0, [x0, #0x78]                            M:Decor.DecorAsset/<>c__DisplayClass5_0::<GetCategoryIndexByName>b__0
02d26008: bl      #0x2b70db0                                 fn_2b70db0
02d2600c: adrp    x0, #0x626a000                             
02d26010: ldr     x0, [x0, #0x68]                            T:Decor.DecorAsset/<>c__DisplayClass5_0
02d26014: bl      #0x2b70db0                                 fn_2b70db0
02d26018: mov     w8, #1                                     
02d2601c: strb    w8, [x21, #0x7d]                           
02d26020: ldr     x0, [x22]                                  T:type56879(k15)
02d26024: bl      #0x2b7104c                                 fn_2b7104c
02d26028: mov     x1, xzr                                    
02d2602c: mov     x21, x0                                    
02d26030: bl      #0x4e53e9c                                 System.Object::.ctor
02d26034: cbz     x21, #0x2d260a0                            
02d26038: adrp    x22, #0x626a000                            
02d2603c: adrp    x23, #0x626a000                            
02d26040: mov     x0, x21                                    
02d26044: ldr     x22, [x22, #0x58]                          T:type57228(k15)
02d26048: ldr     x23, [x23, #0x78]                          M:Decor.DecorAsset/<>c__DisplayClass5_0::<GetCategoryIndexByName>b__0
02d2604c: mov     x1, x19                                    
02d26050: str     x19, [x0, #0x10]!                          
02d26054: bl      #0x2b70d54                                 fn_2b70d54
02d26058: ldr     x0, [x22]                                  T:type56879(k15)
02d2605c: ldr     x19, [x20, #0x18]                          .CategoryAssets
02d26060: bl      #0x2b7104c                                 fn_2b7104c
02d26064: ldr     x2, [x23]                                  T:type56879(k15)
02d26068: mov     x1, x21                                    
02d2606c: mov     x3, xzr                                    
02d26070: mov     x20, x0                                    
02d26074: bl      #0x399ba10                                 fn_399ba10
02d26078: cbz     x19, #0x2d260a0                            
02d2607c: adrp    x8, #0x626a000                             
02d26080: mov     x0, x19                                    
02d26084: mov     x1, x20                                    
02d26088: ldr     x8, [x8, #0x70]                            MS:System.Collections.Generic.List`1::FindIndex
02d2608c: ldp     x20, x19, [sp, #0x20]                      
02d26090: ldp     x22, x21, [sp, #0x10]                      
02d26094: ldr     x2, [x8]                                   T:type56879(k15)
02d26098: ldp     x30, x23, [sp], #0x30                      
02d2609c: b       #0x35a9a60                                 
02d260a0: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Decor.DecorAsset::.ctor 0x2d260ac
02d260ac: str     x30, [sp, #-0x30]!                         
02d260b0: stp     x22, x21, [sp, #0x10]                      
02d260b4: stp     x20, x19, [sp, #0x20]                      
02d260b8: adrp    x21, #0x6630000                            
02d260bc: adrp    x22, #0x626a000                            
02d260c0: adrp    x20, #0x626a000                            
02d260c4: ldrb    w8, [x21, #0x7e]                           
02d260c8: ldr     x22, [x22, #0x80]                          T:type56651(k15)
02d260cc: ldr     x20, [x20, #0x88]                          MS:System.Collections.Generic.List`1::.ctor
02d260d0: mov     x19, x0                                    
02d260d4: tbnz    w8, #0, #0x2d260f8                         
02d260d8: adrp    x0, #0x626a000                             
02d260dc: ldr     x0, [x0, #0x88]                            MS:System.Collections.Generic.List`1::.ctor
02d260e0: bl      #0x2b70db0                                 fn_2b70db0
02d260e4: adrp    x0, #0x626a000                             
02d260e8: ldr     x0, [x0, #0x80]                            T:type56651(k15)
02d260ec: bl      #0x2b70db0                                 fn_2b70db0
02d260f0: mov     w8, #1                                     
02d260f4: strb    w8, [x21, #0x7e]                           
02d260f8: ldr     x0, [x22]                                  T:type56879(k15)
02d260fc: bl      #0x2b7104c                                 fn_2b7104c
02d26100: ldr     x1, [x20]                                  T:type56879(k15)
02d26104: mov     x20, x0                                    
02d26108: bl      #0x35a89a4                                 fn_35a89a4
02d2610c: mov     x0, x19                                    
02d26110: mov     x1, x20                                    
02d26114: str     x20, [x0, #0x18]!                          .CategoryAssets
02d26118: bl      #0x2b70d54                                 fn_2b70d54
02d2611c: mov     x0, x19                                    
02d26120: ldp     x20, x19, [sp, #0x20]                      
02d26124: ldp     x22, x21, [sp, #0x10]                      
02d26128: mov     x1, xzr                                    
02d2612c: ldr     x30, [sp], #0x30                           
02d26130: b       #0x5b398f0                                 UnityEngine.ScriptableObject::.ctor
