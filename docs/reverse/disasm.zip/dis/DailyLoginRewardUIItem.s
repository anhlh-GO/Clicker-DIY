#### CLASS DailyLoginRewardUIItem/<>c parent= object
#   field <>9                            DailyLoginRewardUIItem/<>c                         off=0x0 attr=36 
#   field <>9__24_0                      System.Action`1<UnityEngine.GameObject>            off=0x8 attr=16 
#   field <>9__28_0                      System.Action`1<UnityEngine.GameObject>            off=0x10 attr=16 
#   field <>9__28_1                      System.Action`1<UnityEngine.GameObject>            off=0x18 attr=16 
## .cctor() -> void
---- DailyLoginRewardUIItem/<>c::.cctor 0x2cd509c
02cd509c: str     x30, [sp, #-0x20]!                         
02cd50a0: stp     x20, x19, [sp, #0x10]                      
02cd50a4: adrp    x19, #0x662f000                            
02cd50a8: adrp    x20, #0x6266000                            
02cd50ac: ldrb    w8, [x19, #0xd1f]                          
02cd50b0: ldr     x20, [x20, #0xda0]                         T:DailyLoginRewardUIItem/<>c
02cd50b4: tbnz    w8, #0, #0x2cd50cc                         
02cd50b8: adrp    x0, #0x6266000                             
02cd50bc: ldr     x0, [x0, #0xda0]                           T:DailyLoginRewardUIItem/<>c
02cd50c0: bl      #0x2b70db0                                 fn_2b70db0
02cd50c4: mov     w8, #1                                     
02cd50c8: strb    w8, [x19, #0xd1f]                          
02cd50cc: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cd50d0: bl      #0x2b7104c                                 fn_2b7104c
02cd50d4: mov     x1, xzr                                    
02cd50d8: mov     x19, x0                                    
02cd50dc: bl      #0x4e53e9c                                 System.Object::.ctor
02cd50e0: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cd50e4: mov     x1, x19                                    
02cd50e8: ldr     x8, [x8, #0xb8]                            
02cd50ec: str     x19, [x8]                                  
02cd50f0: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cd50f4: ldp     x20, x19, [sp, #0x10]                      
02cd50f8: ldr     x0, [x8, #0xb8]                            
02cd50fc: ldr     x30, [sp], #0x20                           
02cd5100: b       #0x2b70d54                                 
## .ctor() -> void
---- DailyLoginRewardUIItem/<>c::.ctor 0x2cd5104
02cd5104: mov     x1, xzr                                    
02cd5108: b       #0x4e53e9c                                 System.Object::.ctor
## <SetData>b__24_0(UnityEngine.GameObject x) -> void
---- DailyLoginRewardUIItem/<>c::<SetData>b__24_0 0x2cd510c
02cd510c: cbz     x1, #0x2cd5120                             
02cd5110: mov     x0, x1                                     
02cd5114: mov     w1, wzr                                    
02cd5118: mov     x2, xzr                                    
02cd511c: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cd5120: str     x30, [sp, #-0x10]!                         
02cd5124: bl      #0x2b7105c                                 fn_2b7105c
## <UpdateProcess>b__28_0(UnityEngine.GameObject x) -> void
---- DailyLoginRewardUIItem/<>c::<UpdateProcess>b__28_0 0x2cd5128
02cd5128: cbz     x1, #0x2cd513c                             
02cd512c: mov     x0, x1                                     
02cd5130: mov     w1, wzr                                    
02cd5134: mov     x2, xzr                                    
02cd5138: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cd513c: str     x30, [sp, #-0x10]!                         
02cd5140: bl      #0x2b7105c                                 fn_2b7105c
## <UpdateProcess>b__28_1(UnityEngine.GameObject x) -> void
---- DailyLoginRewardUIItem/<>c::<UpdateProcess>b__28_1 0x2cd5144
02cd5144: cbz     x1, #0x2cd5158                             
02cd5148: mov     x0, x1                                     
02cd514c: mov     w1, wzr                                    
02cd5150: mov     x2, xzr                                    
02cd5154: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cd5158: str     x30, [sp, #-0x10]!                         
02cd515c: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS DailyLoginRewardUIItem parent= UnityEngine.MonoBehaviour
#   field _goClaimed                     UnityEngine.GameObject                             off=0x20 attr=1 SerializeField
#   field _goLock                        UnityEngine.GameObject                             off=0x28 attr=1 SerializeField
#   field _goCanClaim                    UnityEngine.GameObject                             off=0x30 attr=1 SerializeField
#   field _txtMinutes                    TMPro.TextMeshProUGUI                              off=0x38 attr=1 SerializeField
#   field _rewardContents                System.Collections.Generic.List`1<UnityEngine.GameObject> off=0x40 attr=1 SerializeField
#   field _coinContent                   UnityEngine.GameObject                             off=0x48 attr=1 SerializeField
#   field _charmContent                  UnityEngine.GameObject                             off=0x50 attr=1 SerializeField
#   field _skinContent                   UnityEngine.GameObject                             off=0x58 attr=1 SerializeField
#   field _txtCoinAmount                 TMPro.TextMeshProUGUI                              off=0x60 attr=1 SerializeField
#   field _rewardButtons                 System.Collections.Generic.List`1<UnityEngine.GameObject> off=0x68 attr=1 SerializeField
#   field _claimFreeButton               UnityEngine.UI.Button                              off=0x70 attr=1 SerializeField
#   field _watchAdButton                 UnityEngine.UI.Button                              off=0x78 attr=1 SerializeField
#   field _doneButton                    UnityEngine.GameObject                             off=0x80 attr=1 SerializeField
#   field _notDoneButton                 UnityEngine.GameObject                             off=0x88 attr=1 SerializeField
#   field _imgHorizontalLine             UnityEngine.UI.Image                               off=0x90 attr=1 SerializeField
#   field _canvasGroup                   UnityEngine.CanvasGroup                            off=0x98 attr=1 SerializeField
#   field _rewardBoard                   UnityEngine.UI.Image                               off=0xa0 attr=1 SerializeField
#   field _readyBoardSprite              UnityEngine.Sprite                                 off=0xa8 attr=1 SerializeField
#   field _claimedBoardSprite            UnityEngine.Sprite                                 off=0xb0 attr=1 SerializeField
#   field _data                          LoginTimeReward.LoginTimeRewardDataItem            off=0xb8 attr=1 
#   field _loginTimeRewardPopup          LoginTimeReward.LoginTimeRewardPopup               off=0xc0 attr=1 
## get_Data() -> LoginTimeReward.LoginTimeRewardDataItem
---- DailyLoginRewardUIItem::get_Data 0x2cb731c
02cb731c: ldr     x0, [x0, #0xb8]                            ._data
02cb7320: ret                                                
## Init(LoginTimeReward.LoginTimeRewardPopup loginTimeRewardPopup) -> void
---- DailyLoginRewardUIItem::Init 0x2cb7324
02cb7324: str     x30, [sp, #-0x30]!                         
02cb7328: stp     x22, x21, [sp, #0x10]                      
02cb732c: stp     x20, x19, [sp, #0x20]                      
02cb7330: adrp    x21, #0x662f000                            
02cb7334: mov     x20, x1                                    
02cb7338: mov     x19, x0                                    
02cb733c: ldrb    w8, [x21, #0xbb9]                          
02cb7340: tbnz    w8, #0, #0x2cb7370                         
02cb7344: adrp    x0, #0x6266000                             
02cb7348: ldr     x0, [x0, #0xd90]                           M:DailyLoginRewardUIItem::OnClaimFreeClick
02cb734c: bl      #0x2b70db0                                 fn_2b70db0
02cb7350: adrp    x0, #0x6266000                             
02cb7354: ldr     x0, [x0, #0xd98]                           M:DailyLoginRewardUIItem::OnWatchAdClick
02cb7358: bl      #0x2b70db0                                 fn_2b70db0
02cb735c: adrp    x0, #0x6265000                             
02cb7360: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02cb7364: bl      #0x2b70db0                                 fn_2b70db0
02cb7368: mov     w8, #1                                     
02cb736c: strb    w8, [x21, #0xbb9]                          
02cb7370: mov     x21, x19                                   
02cb7374: mov     x1, x20                                    
02cb7378: str     x20, [x21, #0xc0]!                         ._loginTimeRewardPopup
02cb737c: mov     x0, x21                                    
02cb7380: bl      #0x2b70d54                                 fn_2b70d54
02cb7384: ldur    x8, [x21, #-0x50]                          
02cb7388: cbz     x8, #0x2cb7448                             
02cb738c: adrp    x22, #0x6265000                            
02cb7390: adrp    x21, #0x6266000                            
02cb7394: ldr     x22, [x22, #0x3f0]                         T:UnityEngine.Events.UnityAction
02cb7398: ldr     x21, [x21, #0xd90]                         M:DailyLoginRewardUIItem::OnClaimFreeClick
02cb739c: ldr     x20, [x8, #0x100]                          
02cb73a0: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02cb73a4: bl      #0x2b7104c                                 fn_2b7104c
02cb73a8: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb73ac: mov     x1, x19                                    
02cb73b0: mov     x3, xzr                                    
02cb73b4: mov     x21, x0                                    
02cb73b8: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02cb73bc: cbz     x20, #0x2cb7448                            
02cb73c0: mov     x0, x20                                    
02cb73c4: mov     x1, x21                                    
02cb73c8: mov     x2, xzr                                    
02cb73cc: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02cb73d0: ldr     x8, [x19, #0x78]                           ._watchAdButton
02cb73d4: cbz     x8, #0x2cb7448                             
02cb73d8: adrp    x21, #0x6266000                            
02cb73dc: ldr     x21, [x21, #0xd98]                         M:DailyLoginRewardUIItem::OnWatchAdClick
02cb73e0: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02cb73e4: ldr     x20, [x8, #0x100]                          
02cb73e8: bl      #0x2b7104c                                 fn_2b7104c
02cb73ec: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb73f0: mov     x1, x19                                    
02cb73f4: mov     x3, xzr                                    
02cb73f8: mov     x21, x0                                    
02cb73fc: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02cb7400: cbz     x20, #0x2cb7448                            
02cb7404: mov     x0, x20                                    
02cb7408: mov     x1, x21                                    
02cb740c: mov     x2, xzr                                    
02cb7410: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02cb7414: ldr     x0, [x19, #0x98]                           ._canvasGroup
02cb7418: cbz     x0, #0x2cb7448                             
02cb741c: mov     w1, wzr                                    
02cb7420: mov     x2, xzr                                    
02cb7424: bl      #0x5e45290                                 UnityEngine.CanvasGroup::set_interactable
02cb7428: ldr     x0, [x19, #0x98]                           ._canvasGroup
02cb742c: cbz     x0, #0x2cb7448                             
02cb7430: ldp     x20, x19, [sp, #0x20]                      
02cb7434: mov     w1, wzr                                    
02cb7438: ldp     x22, x21, [sp, #0x10]                      
02cb743c: mov     x2, xzr                                    
02cb7440: ldr     x30, [sp], #0x30                           
02cb7444: b       #0x5e45408                                 UnityEngine.CanvasGroup::set_blocksRaycasts
02cb7448: bl      #0x2b7105c                                 fn_2b7105c
## SetData(LoginTimeReward.LoginTimeRewardDataItem data) -> void
---- DailyLoginRewardUIItem::SetData 0x2cb744c
02cb744c: str     x30, [sp, #-0x40]!                         
02cb7450: stp     x24, x23, [sp, #0x10]                      
02cb7454: stp     x22, x21, [sp, #0x20]                      
02cb7458: stp     x20, x19, [sp, #0x30]                      
02cb745c: adrp    x21, #0x662f000                            
02cb7460: adrp    x24, #0x6266000                            
02cb7464: mov     x20, x1                                    
02cb7468: ldrb    w8, [x21, #0xbba]                          
02cb746c: ldr     x24, [x24, #0xda0]                         T:DailyLoginRewardUIItem/<>c
02cb7470: mov     x19, x0                                    
02cb7474: tbnz    w8, #0, #0x2cb74e0                         
02cb7478: adrp    x0, #0x6266000                             
02cb747c: ldr     x0, [x0, #0xda8]                           T:type6904(k15)
02cb7480: bl      #0x2b70db0                                 fn_2b70db0
02cb7484: adrp    x0, #0x6266000                             
02cb7488: ldr     x0, [x0, #0xdb0]                           MS:System.Collections.Generic.List`1::ForEach
02cb748c: bl      #0x2b70db0                                 fn_2b70db0
02cb7490: adrp    x0, #0x6266000                             
02cb7494: ldr     x0, [x0, #0x9f0]                           T:Assets.SimpleLocalization.Scripts.LocalizationManager
02cb7498: bl      #0x2b70db0                                 fn_2b70db0
02cb749c: adrp    x0, #0x6266000                             
02cb74a0: ldr     x0, [x0, #0xdb8]                           M:DailyLoginRewardUIItem/<>c::<SetData>b__24_0
02cb74a4: bl      #0x2b70db0                                 fn_2b70db0
02cb74a8: adrp    x0, #0x6266000                             
02cb74ac: ldr     x0, [x0, #0xda0]                           T:DailyLoginRewardUIItem/<>c
02cb74b0: bl      #0x2b70db0                                 fn_2b70db0
02cb74b4: adrp    x0, #0x6266000                             
02cb74b8: ldr     x0, [x0, #0xdc0]                           S:'$ mins'
02cb74bc: bl      #0x2b70db0                                 fn_2b70db0
02cb74c0: adrp    x0, #0x6266000                             
02cb74c4: ldr     x0, [x0, #0xdc8]                           S:'$'
02cb74c8: bl      #0x2b70db0                                 fn_2b70db0
02cb74cc: adrp    x0, #0x6266000                             
02cb74d0: ldr     x0, [x0, #0xdd0]                           S:'1 min'
02cb74d4: bl      #0x2b70db0                                 fn_2b70db0
02cb74d8: mov     w8, #1                                     
02cb74dc: strb    w8, [x21, #0xbba]                          
02cb74e0: mov     x21, x19                                   
02cb74e4: mov     x1, x20                                    
02cb74e8: str     x20, [x21, #0xb8]!                         ._data
02cb74ec: mov     x0, x21                                    
02cb74f0: bl      #0x2b70d54                                 fn_2b70d54
02cb74f4: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb74f8: ldur    x21, [x21, #-0x78]                         
02cb74fc: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02cb7500: cbnz    w8, #0x2cb750c                             
02cb7504: bl      #0x2b70f30                                 fn_2b70f30
02cb7508: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb750c: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time' ._data
02cb7510: ldr     x22, [x8, #8]                              
02cb7514: cbnz    x22, #0x2cb7570                            
02cb7518: ldr     w9, [x0, #0xe4]                            [62660e4]=0 f=0,0
02cb751c: cbnz    w9, #0x2cb752c                             
02cb7520: bl      #0x2b70f30                                 fn_2b70f30
02cb7524: ldr     x8, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb7528: ldr     x8, [x8, #0xb8]                            
02cb752c: adrp    x9, #0x6266000                             
02cb7530: ldr     x9, [x9, #0xda8]                           T:type6904(k15)
02cb7534: ldr     x23, [x8]                                  
02cb7538: ldr     x0, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb753c: bl      #0x2b7104c                                 fn_2b7104c
02cb7540: adrp    x8, #0x6266000                             
02cb7544: mov     x1, x23                                    
02cb7548: mov     x3, xzr                                    
02cb754c: ldr     x8, [x8, #0xdb8]                           M:DailyLoginRewardUIItem/<>c::<SetData>b__24_0
02cb7550: mov     x22, x0                                    
02cb7554: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb7558: bl      #0x453418c                                 fn_453418c
02cb755c: ldr     x8, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb7560: mov     x1, x22                                    
02cb7564: ldr     x0, [x8, #0xb8]                            S:'banner_native_refresh_time'
02cb7568: str     x22, [x0, #8]!                             
02cb756c: bl      #0x2b70d54                                 fn_2b70d54
02cb7570: cbz     x21, #0x2cb76d8                            
02cb7574: adrp    x8, #0x6266000                             
02cb7578: mov     x0, x21                                    
02cb757c: mov     x1, x22                                    
02cb7580: ldr     x8, [x8, #0xdb0]                           MS:System.Collections.Generic.List`1::ForEach
02cb7584: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb7588: bl      #0x35a9ce4                                 fn_35a9ce4
02cb758c: cbz     x20, #0x2cb76d8                            
02cb7590: ldr     x0, [x19, #0x48]                           ._coinContent
02cb7594: cbz     x0, #0x2cb76d8                             
02cb7598: ldr     w8, [x20, #0x18]                           
02cb759c: mov     x2, xzr                                    
02cb75a0: cmp     w8, #0                                     
02cb75a4: cset    w1, eq                                     
02cb75a8: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cb75ac: ldr     x0, [x19, #0x50]                           ._charmContent
02cb75b0: cbz     x0, #0x2cb76d8                             
02cb75b4: ldr     w8, [x20, #0x18]                           
02cb75b8: mov     x2, xzr                                    
02cb75bc: and     w8, w8, #0xfffffffd                        
02cb75c0: cmp     w8, #1                                     
02cb75c4: cset    w1, eq                                     
02cb75c8: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cb75cc: ldr     x0, [x19, #0x58]                           ._skinContent
02cb75d0: cbz     x0, #0x2cb76d8                             
02cb75d4: ldr     w8, [x20, #0x18]                           
02cb75d8: mov     x2, xzr                                    
02cb75dc: cmp     w8, #2                                     
02cb75e0: cset    w1, eq                                     
02cb75e4: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cb75e8: ldr     x21, [x19, #0x60]                          ._txtCoinAmount
02cb75ec: add     x0, x20, #0x1c                             
02cb75f0: mov     x1, xzr                                    
02cb75f4: bl      #0x4e0ea3c                                 System.Int32::ToString
02cb75f8: cbz     x21, #0x2cb76d8                            
02cb75fc: ldr     x8, [x21]                                  &2b706c4(=eb01011ff9400808)
02cb7600: adrp    x22, #0x6266000                            
02cb7604: mov     x1, x0                                     
02cb7608: ldr     x22, [x22, #0x9f0]                         T:Assets.SimpleLocalization.Scripts.LocalizationManager
02cb760c: mov     x0, x21                                    
02cb7610: ldr     x9, [x8, #0x558]                           MS:NFramework.GoogleSheetConfigSO`1::.ctor
02cb7614: ldr     x2, [x8, #0x560]                           MS:NFramework.GoogleSheetConfigSO`1::OpenSheet
02cb7618: blr     x9                                         
02cb761c: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb7620: ldr     w9, [x20, #0x14]!                          
02cb7624: ldr     x21, [x19, #0x38]                          ._txtMinutes
02cb7628: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02cb762c: cmp     w9, #1                                     
02cb7630: b.ne    #0x2cb7658                                 
02cb7634: cbnz    w8, #0x2cb763c                             
02cb7638: bl      #0x2b70f30                                 fn_2b70f30
02cb763c: adrp    x8, #0x6266000                             
02cb7640: mov     x1, xzr                                    
02cb7644: ldr     x8, [x8, #0xdd0]                           S:'1 min'
02cb7648: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb764c: bl      #0x2d76794                                 Assets.SimpleLocalization.Scripts.LocalizationManager::Localize
02cb7650: cbnz    x21, #0x2cb76a8                            
02cb7654: b       #0x2cb76d8                                 
02cb7658: cbnz    w8, #0x2cb7660                             
02cb765c: bl      #0x2b70f30                                 fn_2b70f30
02cb7660: adrp    x8, #0x6266000                             
02cb7664: mov     x1, xzr                                    
02cb7668: ldr     x8, [x8, #0xdc0]                           S:'$ mins'
02cb766c: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb7670: bl      #0x2d76794                                 Assets.SimpleLocalization.Scripts.LocalizationManager::Localize
02cb7674: mov     x22, x0                                    
02cb7678: mov     x0, x20                                    
02cb767c: mov     x1, xzr                                    
02cb7680: bl      #0x4e0ea3c                                 System.Int32::ToString
02cb7684: cbz     x22, #0x2cb76d8                            
02cb7688: adrp    x8, #0x6266000                             
02cb768c: mov     x2, x0                                     
02cb7690: mov     x0, x22                                    
02cb7694: ldr     x8, [x8, #0xdc8]                           S:'$'
02cb7698: mov     x3, xzr                                    
02cb769c: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb76a0: bl      #0x4ca8ca8                                 System.String::Replace
02cb76a4: cbz     x21, #0x2cb76d8                            
02cb76a8: ldr     x8, [x21]                                  &2b706c4(=eb01011ff9400808)
02cb76ac: mov     x1, x0                                     
02cb76b0: mov     x0, x21                                    
02cb76b4: ldr     x9, [x8, #0x558]                           MS:NFramework.GoogleSheetConfigSO`1::.ctor
02cb76b8: ldr     x2, [x8, #0x560]                           MS:NFramework.GoogleSheetConfigSO`1::OpenSheet
02cb76bc: blr     x9                                         
02cb76c0: mov     x0, x19                                    
02cb76c4: ldp     x20, x19, [sp, #0x30]                      
02cb76c8: ldp     x22, x21, [sp, #0x20]                      
02cb76cc: ldp     x24, x23, [sp, #0x10]                      
02cb76d0: ldr     x30, [sp], #0x40                           
02cb76d4: b       #0x2cb76dc                                 DailyLoginRewardUIItem::UpdateProcess
02cb76d8: bl      #0x2b7105c                                 fn_2b7105c
## AnimShow(float delay) -> void
---- DailyLoginRewardUIItem::AnimShow 0x2cb7b14
02cb7b14: str     d8, [sp, #-0x50]!                          
02cb7b18: stp     x30, x25, [sp, #0x10]                      
02cb7b1c: stp     x24, x23, [sp, #0x20]                      
02cb7b20: stp     x22, x21, [sp, #0x30]                      
02cb7b24: stp     x20, x19, [sp, #0x40]                      
02cb7b28: fmov    s8, s0                                     
02cb7b2c: adrp    x20, #0x662f000                            
02cb7b30: mov     x19, x0                                    
02cb7b34: ldrb    w8, [x20, #0xbbb]                          
02cb7b38: tbnz    w8, #0, #0x2cb7b8c                         
02cb7b3c: adrp    x0, #0x6266000                             
02cb7b40: ldr     x0, [x0, #0xdf8]                           M:DailyLoginRewardUIItem::<AnimShow>b__25_0
02cb7b44: bl      #0x2b70db0                                 fn_2b70db0
02cb7b48: adrp    x0, #0x6264000                             
02cb7b4c: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02cb7b50: bl      #0x2b70db0                                 fn_2b70db0
02cb7b54: adrp    x0, #0x6266000                             
02cb7b58: ldr     x0, [x0, #0x928]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02cb7b5c: bl      #0x2b70db0                                 fn_2b70db0
02cb7b60: adrp    x0, #0x6266000                             
02cb7b64: ldr     x0, [x0, #0xe00]                           MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02cb7b68: bl      #0x2b70db0                                 fn_2b70db0
02cb7b6c: adrp    x0, #0x6266000                             
02cb7b70: ldr     x0, [x0, #0xe08]                           MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02cb7b74: bl      #0x2b70db0                                 fn_2b70db0
02cb7b78: adrp    x0, #0x6266000                             
02cb7b7c: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02cb7b80: bl      #0x2b70db0                                 fn_2b70db0
02cb7b84: mov     w8, #1                                     
02cb7b88: strb    w8, [x20, #0xbbb]                          
02cb7b8c: mov     x0, x19                                    
02cb7b90: bl      #0x2cb7d3c                                 DailyLoginRewardUIItem::AlsoLocalize
02cb7b94: mov     x0, x19                                    
02cb7b98: mov     x1, xzr                                    
02cb7b9c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cb7ba0: mov     w1, wzr                                    
02cb7ba4: mov     x2, xzr                                    
02cb7ba8: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02cb7bac: mov     x0, x19                                    
02cb7bb0: mov     x1, xzr                                    
02cb7bb4: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cb7bb8: adrp    x21, #0x662f000                            
02cb7bbc: mov     x20, x0                                    
02cb7bc0: ldrb    w8, [x21, #0xa74]                          
02cb7bc4: cbnz    w8, #0x2cb7bdc                             
02cb7bc8: adrp    x0, #0x6264000                             
02cb7bcc: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02cb7bd0: bl      #0x2b70db0                                 fn_2b70db0
02cb7bd4: mov     w8, #1                                     
02cb7bd8: strb    w8, [x21, #0xa74]                          
02cb7bdc: cbz     x20, #0x2cb7d38                            
02cb7be0: adrp    x8, #0x6264000                             
02cb7be4: movi    v0.2s, #0x3f, lsl #24                      
02cb7be8: mov     x0, x20                                    
02cb7bec: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02cb7bf0: mov     x1, xzr                                    
02cb7bf4: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cb7bf8: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02cb7bfc: ldur    d1, [x8, #0xc]                             
02cb7c00: ldr     s2, [x8, #0x14]                            [6264014]=0 f=0,0
02cb7c04: fmul    v0.2s, v1.2s, v0.2s                        
02cb7c08: fmov    s1, #0.50000000                            
02cb7c0c: fmul    s2, s2, s1                                 
02cb7c10: mov     s1, v0.s[1]                                
02cb7c14: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02cb7c18: ldr     x0, [x19, #0x98]                           ._canvasGroup
02cb7c1c: cbz     x0, #0x2cb7d38                             
02cb7c20: movi    d0, #0000000000000000                      
02cb7c24: mov     x1, xzr                                    
02cb7c28: bl      #0x5e45108                                 UnityEngine.CanvasGroup::set_alpha
02cb7c2c: ldr     x0, [x19, #0x98]                           ._canvasGroup
02cb7c30: cbz     x0, #0x2cb7d38                             
02cb7c34: mov     w1, wzr                                    
02cb7c38: mov     x2, xzr                                    
02cb7c3c: bl      #0x5e45290                                 UnityEngine.CanvasGroup::set_interactable
02cb7c40: ldr     x0, [x19, #0x98]                           ._canvasGroup
02cb7c44: cbz     x0, #0x2cb7d38                             
02cb7c48: adrp    x24, #0x6266000                            
02cb7c4c: adrp    x25, #0x6266000                            
02cb7c50: adrp    x23, #0x6266000                            
02cb7c54: adrp    x20, #0x6264000                            
02cb7c58: adrp    x21, #0x6266000                            
02cb7c5c: adrp    x22, #0x6266000                            
02cb7c60: ldr     x24, [x24, #0xe00]                         MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02cb7c64: ldr     x25, [x25, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02cb7c68: ldr     x23, [x23, #0xe08]                         MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02cb7c6c: ldr     x20, [x20, #0xe8]                          T:DG.Tweening.TweenCallback
02cb7c70: ldr     x21, [x21, #0xdf8]                         M:DailyLoginRewardUIItem::<AnimShow>b__25_0
02cb7c74: ldr     x22, [x22, #0x928]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02cb7c78: mov     w1, wzr                                    
02cb7c7c: mov     x2, xzr                                    
02cb7c80: bl      #0x5e45408                                 UnityEngine.CanvasGroup::set_blocksRaycasts
02cb7c84: movi    d0, #0000000000000000                      
02cb7c88: movi    d1, #0000000000000000                      
02cb7c8c: ldr     x0, [x19, #0x90]                           ._imgHorizontalLine
02cb7c90: mov     x1, xzr                                    
02cb7c94: bl      #0x2c789b8                                 DG.Tweening.DOTweenModuleUI::DOFade
02cb7c98: adrp    x8, #0x1084000                             
02cb7c9c: fmov    s0, #1.00000000                            
02cb7ca0: ldr     x0, [x19, #0x98]                           ._canvasGroup
02cb7ca4: ldr     s1, [x8, #0xf10]                           [1084f10]=4110bc863e99999a f=0.3,9.04603
02cb7ca8: mov     x1, xzr                                    
02cb7cac: bl      #0x2c78338                                 DG.Tweening.DOTweenModuleUI::DOFade
02cb7cb0: fmov    s0, s8                                     
02cb7cb4: ldr     x1, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb7cb8: bl      #0x336f7fc                                 fn_336f7fc
02cb7cbc: mov     x0, x19                                    
02cb7cc0: mov     x1, xzr                                    
02cb7cc4: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cb7cc8: fmov    s0, #1.00000000                            
02cb7ccc: fmov    s1, #0.50000000                            
02cb7cd0: mov     x1, xzr                                    
02cb7cd4: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02cb7cd8: ldr     x2, [x25]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb7cdc: mov     w1, #0x1b                                  
02cb7ce0: bl      #0x336fa0c                                 fn_336fa0c
02cb7ce4: fmov    s0, s8                                     
02cb7ce8: ldr     x1, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb7cec: bl      #0x336f7fc                                 fn_336f7fc
02cb7cf0: ldr     x8, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cb7cf4: mov     x20, x0                                    
02cb7cf8: mov     x0, x8                                     
02cb7cfc: bl      #0x2b7104c                                 fn_2b7104c
02cb7d00: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb7d04: mov     x1, x19                                    
02cb7d08: mov     x3, xzr                                    
02cb7d0c: mov     x21, x0                                    
02cb7d10: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02cb7d14: ldr     x2, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb7d18: mov     x0, x20                                    
02cb7d1c: mov     x1, x21                                    
02cb7d20: ldp     x20, x19, [sp, #0x40]                      
02cb7d24: ldp     x22, x21, [sp, #0x30]                      
02cb7d28: ldp     x24, x23, [sp, #0x20]                      
02cb7d2c: ldp     x30, x25, [sp, #0x10]                      
02cb7d30: ldr     d8, [sp], #0x50                            
02cb7d34: b       #0x336f26c                                 
02cb7d38: bl      #0x2b7105c                                 fn_2b7105c
## AlsoLocalize() -> void
---- DailyLoginRewardUIItem::AlsoLocalize 0x2cb7d3c
02cb7d3c: str     x30, [sp, #-0x20]!                         
02cb7d40: stp     x20, x19, [sp, #0x10]                      
02cb7d44: adrp    x19, #0x662f000                            
02cb7d48: mov     x20, x0                                    
02cb7d4c: ldrb    w8, [x19, #0xbbc]                          
02cb7d50: tbnz    w8, #0, #0x2cb7d8c                         
02cb7d54: adrp    x0, #0x6266000                             
02cb7d58: ldr     x0, [x0, #0x9f0]                           T:Assets.SimpleLocalization.Scripts.LocalizationManager
02cb7d5c: bl      #0x2b70db0                                 fn_2b70db0
02cb7d60: adrp    x0, #0x6266000                             
02cb7d64: ldr     x0, [x0, #0xdc0]                           S:'$ mins'
02cb7d68: bl      #0x2b70db0                                 fn_2b70db0
02cb7d6c: adrp    x0, #0x6266000                             
02cb7d70: ldr     x0, [x0, #0xdc8]                           S:'$'
02cb7d74: bl      #0x2b70db0                                 fn_2b70db0
02cb7d78: adrp    x0, #0x6266000                             
02cb7d7c: ldr     x0, [x0, #0xdd0]                           S:'1 min'
02cb7d80: bl      #0x2b70db0                                 fn_2b70db0
02cb7d84: mov     w8, #1                                     
02cb7d88: strb    w8, [x19, #0xbbc]                          
02cb7d8c: ldr     x8, [x20, #0xb8]                           ._data
02cb7d90: cbz     x8, #0x2cb7e50                             
02cb7d94: adrp    x9, #0x6266000                             
02cb7d98: ldr     x9, [x9, #0x9f0]                           T:Assets.SimpleLocalization.Scripts.LocalizationManager
02cb7d9c: ldr     w10, [x8, #0x14]                           
02cb7da0: ldr     x19, [x20, #0x38]                          ._txtMinutes
02cb7da4: ldr     x0, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb7da8: cmp     w10, #1                                    
02cb7dac: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02cb7db0: b.ne    #0x2cb7dd8                                 
02cb7db4: cbnz    w8, #0x2cb7dbc                             
02cb7db8: bl      #0x2b70f30                                 fn_2b70f30
02cb7dbc: adrp    x8, #0x6266000                             
02cb7dc0: mov     x1, xzr                                    
02cb7dc4: ldr     x8, [x8, #0xdd0]                           S:'1 min'
02cb7dc8: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb7dcc: bl      #0x2d76794                                 Assets.SimpleLocalization.Scripts.LocalizationManager::Localize
02cb7dd0: cbnz    x19, #0x2cb7e30                            
02cb7dd4: b       #0x2cb7e50                                 
02cb7dd8: cbnz    w8, #0x2cb7de0                             
02cb7ddc: bl      #0x2b70f30                                 fn_2b70f30
02cb7de0: adrp    x8, #0x6266000                             
02cb7de4: mov     x1, xzr                                    
02cb7de8: ldr     x8, [x8, #0xdc0]                           S:'$ mins'
02cb7dec: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb7df0: bl      #0x2d76794                                 Assets.SimpleLocalization.Scripts.LocalizationManager::Localize
02cb7df4: ldr     x8, [x20, #0xb8]                           ._data
02cb7df8: cbz     x8, #0x2cb7e50                             
02cb7dfc: mov     x20, x0                                    
02cb7e00: add     x0, x8, #0x14                              &6266014
02cb7e04: mov     x1, xzr                                    
02cb7e08: bl      #0x4e0ea3c                                 System.Int32::ToString
02cb7e0c: cbz     x20, #0x2cb7e50                            
02cb7e10: adrp    x8, #0x6266000                             
02cb7e14: mov     x2, x0                                     
02cb7e18: mov     x0, x20                                    
02cb7e1c: ldr     x8, [x8, #0xdc8]                           S:'$'
02cb7e20: mov     x3, xzr                                    
02cb7e24: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb7e28: bl      #0x4ca8ca8                                 System.String::Replace
02cb7e2c: cbz     x19, #0x2cb7e50                            
02cb7e30: ldr     x8, [x19]                                  &2b706c4(=eb01011ff9400808)
02cb7e34: mov     x1, x0                                     
02cb7e38: mov     x0, x19                                    
02cb7e3c: ldp     x20, x19, [sp, #0x10]                      
02cb7e40: ldr     x2, [x8, #0x560]                           MS:NFramework.GoogleSheetConfigSO`1::OpenSheet
02cb7e44: ldr     x3, [x8, #0x558]                           MS:NFramework.GoogleSheetConfigSO`1::.ctor
02cb7e48: ldr     x30, [sp], #0x20                           
02cb7e4c: br      x3                                         
02cb7e50: bl      #0x2b7105c                                 fn_2b7105c
## HideVisual() -> void
---- DailyLoginRewardUIItem::HideVisual 0x2cb7e54
02cb7e54: stp     x30, x19, [sp, #-0x10]!                    
02cb7e58: mov     x1, xzr                                    
02cb7e5c: mov     x19, x0                                    
02cb7e60: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cb7e64: mov     w1, wzr                                    
02cb7e68: mov     x2, xzr                                    
02cb7e6c: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02cb7e70: ldr     x0, [x19, #0x98]                           ._canvasGroup
02cb7e74: cbz     x0, #0x2cb7e9c                             
02cb7e78: mov     w1, wzr                                    
02cb7e7c: mov     x2, xzr                                    
02cb7e80: bl      #0x5e45290                                 UnityEngine.CanvasGroup::set_interactable
02cb7e84: ldr     x0, [x19, #0x98]                           ._canvasGroup
02cb7e88: cbz     x0, #0x2cb7e9c                             
02cb7e8c: mov     w1, wzr                                    
02cb7e90: mov     x2, xzr                                    
02cb7e94: ldp     x30, x19, [sp], #0x10                      
02cb7e98: b       #0x5e45408                                 UnityEngine.CanvasGroup::set_blocksRaycasts
02cb7e9c: bl      #0x2b7105c                                 fn_2b7105c
## UpdateProcess() -> void
---- DailyLoginRewardUIItem::UpdateProcess 0x2cb76dc
02cb76dc: str     x30, [sp, #-0x40]!                         
02cb76e0: stp     x24, x23, [sp, #0x10]                      
02cb76e4: stp     x22, x21, [sp, #0x20]                      
02cb76e8: stp     x20, x19, [sp, #0x30]                      
02cb76ec: adrp    x20, #0x662f000                            
02cb76f0: adrp    x23, #0x6266000                            
02cb76f4: mov     x19, x0                                    
02cb76f8: ldrb    w8, [x20, #0xbbd]                          
02cb76fc: ldr     x23, [x23, #0xda0]                         T:DailyLoginRewardUIItem/<>c
02cb7700: tbnz    w8, #0, #0x2cb7778                         
02cb7704: adrp    x0, #0x6266000                             
02cb7708: ldr     x0, [x0, #0xda8]                           T:type6904(k15)
02cb770c: bl      #0x2b70db0                                 fn_2b70db0
02cb7710: adrp    x0, #0x6266000                             
02cb7714: ldr     x0, [x0, #0x8d0]                           MS:DataManager::GetData
02cb7718: bl      #0x2b70db0                                 fn_2b70db0
02cb771c: adrp    x0, #0x6266000                             
02cb7720: ldr     x0, [x0, #0xdb0]                           MS:System.Collections.Generic.List`1::ForEach
02cb7724: bl      #0x2b70db0                                 fn_2b70db0
02cb7728: adrp    x0, #0x6266000                             
02cb772c: ldr     x0, [x0, #0xdd8]                           MS:System.Collections.Generic.List`1::get_Item
02cb7730: bl      #0x2b70db0                                 fn_2b70db0
02cb7734: adrp    x0, #0x6266000                             
02cb7738: ldr     x0, [x0, #0xde0]                           MS:MonoSingleton`1::get_Instance
02cb773c: bl      #0x2b70db0                                 fn_2b70db0
02cb7740: adrp    x0, #0x6266000                             
02cb7744: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02cb7748: bl      #0x2b70db0                                 fn_2b70db0
02cb774c: adrp    x0, #0x6266000                             
02cb7750: ldr     x0, [x0, #0xde8]                           M:DailyLoginRewardUIItem/<>c::<UpdateProcess>b__28_0
02cb7754: bl      #0x2b70db0                                 fn_2b70db0
02cb7758: adrp    x0, #0x6266000                             
02cb775c: ldr     x0, [x0, #0xdf0]                           M:DailyLoginRewardUIItem/<>c::<UpdateProcess>b__28_1
02cb7760: bl      #0x2b70db0                                 fn_2b70db0
02cb7764: adrp    x0, #0x6266000                             
02cb7768: ldr     x0, [x0, #0xda0]                           T:DailyLoginRewardUIItem/<>c
02cb776c: bl      #0x2b70db0                                 fn_2b70db0
02cb7770: mov     w8, #1                                     
02cb7774: strb    w8, [x20, #0xbbd]                          
02cb7778: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb777c: ldr     x20, [x19, #0x68]                          ._rewardButtons
02cb7780: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02cb7784: cbnz    w8, #0x2cb7790                             
02cb7788: bl      #0x2b70f30                                 fn_2b70f30
02cb778c: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb7790: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time' ._data
02cb7794: ldr     x21, [x8, #0x10]                           
02cb7798: cbnz    x21, #0x2cb77f4                            
02cb779c: ldr     w9, [x0, #0xe4]                            [62660e4]=0 f=0,0
02cb77a0: cbnz    w9, #0x2cb77b0                             
02cb77a4: bl      #0x2b70f30                                 fn_2b70f30
02cb77a8: ldr     x8, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb77ac: ldr     x8, [x8, #0xb8]                            
02cb77b0: adrp    x9, #0x6266000                             
02cb77b4: ldr     x9, [x9, #0xda8]                           T:type6904(k15)
02cb77b8: ldr     x22, [x8]                                  
02cb77bc: ldr     x0, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb77c0: bl      #0x2b7104c                                 fn_2b7104c
02cb77c4: adrp    x8, #0x6266000                             
02cb77c8: mov     x1, x22                                    
02cb77cc: mov     x3, xzr                                    
02cb77d0: ldr     x8, [x8, #0xde8]                           M:DailyLoginRewardUIItem/<>c::<UpdateProcess>b__28_0
02cb77d4: mov     x21, x0                                    
02cb77d8: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb77dc: bl      #0x453418c                                 fn_453418c
02cb77e0: ldr     x8, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb77e4: mov     x1, x21                                    
02cb77e8: ldr     x0, [x8, #0xb8]                            S:'banner_native_refresh_time'
02cb77ec: str     x21, [x0, #0x10]!                          
02cb77f0: bl      #0x2b70d54                                 fn_2b70d54
02cb77f4: cbz     x20, #0x2cb7b10                            
02cb77f8: adrp    x24, #0x6266000                            
02cb77fc: adrp    x22, #0x6266000                            
02cb7800: mov     x0, x20                                    
02cb7804: ldr     x24, [x24, #0xdb0]                         MS:System.Collections.Generic.List`1::ForEach
02cb7808: ldr     x22, [x22, #0xde0]                         MS:MonoSingleton`1::get_Instance
02cb780c: mov     x1, x21                                    
02cb7810: ldr     x2, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb7814: bl      #0x35a9ce4                                 fn_35a9ce4
02cb7818: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb781c: bl      #0x3769600                                 fn_3769600
02cb7820: cbz     x0, #0x2cb7b10                             
02cb7824: bl      #0x2cade40                                 PlayTimeTracker::GetMinuteRoundDown
02cb7828: ldr     x8, [x19, #0xb8]                           ._data
02cb782c: cbz     x8, #0x2cb7b10                             
02cb7830: mov     w20, w0                                    
02cb7834: ldr     x0, [x19, #0xa0]                           ._rewardBoard
02cb7838: cbz     x0, #0x2cb7b10                             
02cb783c: ldr     x1, [x19, #0xa8]                           ._readyBoardSprite
02cb7840: ldr     w21, [x8, #0x14]                           [6266014]=0 f=0,0
02cb7844: mov     x2, xzr                                    
02cb7848: bl      #0x5c45aa0                                 UnityEngine.UI.Image::set_sprite
02cb784c: cmp     w20, w21                                   
02cb7850: b.ge    #0x2cb78b4                                 
02cb7854: ldr     x0, [x19, #0x88]                           ._notDoneButton
02cb7858: cbz     x0, #0x2cb7b10                             
02cb785c: mov     w1, #1                                     
02cb7860: mov     x2, xzr                                    
02cb7864: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cb7868: ldr     x0, [x19, #0x28]                           ._goLock
02cb786c: cbz     x0, #0x2cb7b10                             
02cb7870: mov     w1, #1                                     
02cb7874: mov     x2, xzr                                    
02cb7878: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cb787c: ldr     x0, [x19, #0x20]                           ._goClaimed
02cb7880: cbz     x0, #0x2cb7b10                             
02cb7884: mov     w1, wzr                                    
02cb7888: mov     x2, xzr                                    
02cb788c: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cb7890: ldr     x0, [x19, #0x30]                           ._goCanClaim
02cb7894: cbz     x0, #0x2cb7b10                             
02cb7898: mov     w1, wzr                                    
02cb789c: ldp     x20, x19, [sp, #0x30]                      
02cb78a0: mov     x2, xzr                                    
02cb78a4: ldp     x22, x21, [sp, #0x20]                      
02cb78a8: ldp     x24, x23, [sp, #0x10]                      
02cb78ac: ldr     x30, [sp], #0x40                           
02cb78b0: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cb78b4: adrp    x8, #0x6266000                             
02cb78b8: ldr     x8, [x8, #0x658]                           MS:MonoSingleton`1::get_Instance
02cb78bc: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb78c0: bl      #0x3769600                                 fn_3769600
02cb78c4: cbz     x0, #0x2cb7b10                             
02cb78c8: adrp    x8, #0x6266000                             
02cb78cc: ldr     x8, [x8, #0x8d0]                           MS:DataManager::GetData
02cb78d0: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb78d4: bl      #0x3168dd0                                 fn_3168dd0
02cb78d8: cbz     x0, #0x2cb7b10                             
02cb78dc: ldr     x9, [x0, #0x20]                            S:'inter_ad_capping_time' ._goClaimed
02cb78e0: cbz     x9, #0x2cb7b10                             
02cb78e4: ldr     x8, [x19, #0xb8]                           ._data
02cb78e8: cbz     x8, #0x2cb7b10                             
02cb78ec: ldr     x0, [x9, #0x20]                            S:'inter_ad_capping_time'
02cb78f0: cbz     x0, #0x2cb7b10                             
02cb78f4: adrp    x9, #0x6266000                             
02cb78f8: ldr     x9, [x9, #0xdd8]                           MS:System.Collections.Generic.List`1::get_Item
02cb78fc: ldr     w1, [x8, #0x10]                            S:'mrec_ad_on_off'
02cb7900: ldr     x2, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb7904: bl      #0x4baf438                                 fn_4baf438
02cb7908: tbz     w0, #0, #0x2cb7994                         
02cb790c: ldr     x0, [x19, #0x80]                           ._doneButton
02cb7910: cbz     x0, #0x2cb7b10                             
02cb7914: mov     w1, #1                                     
02cb7918: mov     x2, xzr                                    
02cb791c: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cb7920: ldr     x0, [x19, #0x20]                           ._goClaimed
02cb7924: cbz     x0, #0x2cb7b10                             
02cb7928: mov     w1, #1                                     
02cb792c: mov     x2, xzr                                    
02cb7930: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cb7934: ldr     x0, [x19, #0x28]                           ._goLock
02cb7938: cbz     x0, #0x2cb7b10                             
02cb793c: mov     w1, wzr                                    
02cb7940: mov     x2, xzr                                    
02cb7944: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cb7948: ldr     x0, [x19, #0x20]                           ._goClaimed
02cb794c: cbz     x0, #0x2cb7b10                             
02cb7950: mov     w1, #1                                     
02cb7954: mov     x2, xzr                                    
02cb7958: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cb795c: ldr     x0, [x19, #0x30]                           ._goCanClaim
02cb7960: cbz     x0, #0x2cb7b10                             
02cb7964: mov     w1, wzr                                    
02cb7968: mov     x2, xzr                                    
02cb796c: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cb7970: ldr     x0, [x19, #0xa0]                           ._rewardBoard
02cb7974: cbz     x0, #0x2cb7b10                             
02cb7978: ldr     x1, [x19, #0xb0]                           ._claimedBoardSprite
02cb797c: ldp     x20, x19, [sp, #0x30]                      
02cb7980: ldp     x22, x21, [sp, #0x20]                      
02cb7984: mov     x2, xzr                                    
02cb7988: ldp     x24, x23, [sp, #0x10]                      
02cb798c: ldr     x30, [sp], #0x40                           
02cb7990: b       #0x5c45aa0                                 UnityEngine.UI.Image::set_sprite
02cb7994: ldr     x0, [x19, #0x70]                           ._claimFreeButton
02cb7998: cbz     x0, #0x2cb7b10                             
02cb799c: mov     x1, xzr                                    
02cb79a0: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02cb79a4: ldr     x8, [x19, #0xb8]                           ._data
02cb79a8: cbz     x8, #0x2cb7b10                             
02cb79ac: cbz     x0, #0x2cb7b10                             
02cb79b0: ldr     w8, [x8, #0x20]                            S:'inter_ad_capping_time'
02cb79b4: mov     x2, xzr                                    
02cb79b8: cmp     w8, #0                                     
02cb79bc: cset    w1, eq                                     
02cb79c0: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cb79c4: ldr     x0, [x19, #0x78]                           ._watchAdButton
02cb79c8: cbz     x0, #0x2cb7b10                             
02cb79cc: mov     x1, xzr                                    
02cb79d0: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02cb79d4: ldr     x8, [x19, #0xb8]                           ._data
02cb79d8: cbz     x8, #0x2cb7b10                             
02cb79dc: cbz     x0, #0x2cb7b10                             
02cb79e0: ldr     w8, [x8, #0x20]                            S:'inter_ad_capping_time'
02cb79e4: mov     x2, xzr                                    
02cb79e8: cmp     w8, #1                                     
02cb79ec: cset    w1, eq                                     
02cb79f0: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cb79f4: ldr     x0, [x19, #0x28]                           ._goLock
02cb79f8: cbz     x0, #0x2cb7b10                             
02cb79fc: mov     w1, wzr                                    
02cb7a00: mov     x2, xzr                                    
02cb7a04: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cb7a08: ldr     x0, [x19, #0x20]                           ._goClaimed
02cb7a0c: cbz     x0, #0x2cb7b10                             
02cb7a10: mov     w1, wzr                                    
02cb7a14: mov     x2, xzr                                    
02cb7a18: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cb7a1c: ldr     x0, [x19, #0x30]                           ._goCanClaim
02cb7a20: cbz     x0, #0x2cb7b10                             
02cb7a24: mov     w1, #1                                     
02cb7a28: mov     x2, xzr                                    
02cb7a2c: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cb7a30: ldr     x0, [x19, #0x30]                           ._goCanClaim
02cb7a34: cbz     x0, #0x2cb7b10                             
02cb7a38: mov     x1, xzr                                    
02cb7a3c: bl      #0x5b37654                                 UnityEngine.GameObject::get_gameObject
02cb7a40: cbz     x0, #0x2cb7b10                             
02cb7a44: mov     x1, xzr                                    
02cb7a48: bl      #0x5b36bfc                                 UnityEngine.GameObject::get_activeSelf
02cb7a4c: tbz     w0, #0, #0x2cb7a5c                         
02cb7a50: mov     x0, x19                                    
02cb7a54: bl      #0x2cb7ea0                                 DailyLoginRewardUIItem::CanClaimThisReward
02cb7a58: tbz     w0, #0, #0x2cb7a70                         
02cb7a5c: ldp     x20, x19, [sp, #0x30]                      
02cb7a60: ldp     x22, x21, [sp, #0x20]                      
02cb7a64: ldp     x24, x23, [sp, #0x10]                      
02cb7a68: ldr     x30, [sp], #0x40                           
02cb7a6c: ret                                                
02cb7a70: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb7a74: ldr     x20, [x19, #0x68]                          ._rewardButtons
02cb7a78: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02cb7a7c: cbnz    w8, #0x2cb7a88                             
02cb7a80: bl      #0x2b70f30                                 fn_2b70f30
02cb7a84: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb7a88: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time' ._data
02cb7a8c: ldr     x21, [x8, #0x18]                           S:'level_show_popuprate'
02cb7a90: cbnz    x21, #0x2cb7aec                            
02cb7a94: ldr     w9, [x0, #0xe4]                            [62660e4]=0 f=0,0
02cb7a98: cbnz    w9, #0x2cb7aa8                             
02cb7a9c: bl      #0x2b70f30                                 fn_2b70f30
02cb7aa0: ldr     x8, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb7aa4: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02cb7aa8: adrp    x9, #0x6266000                             
02cb7aac: ldr     x9, [x9, #0xda8]                           T:type6904(k15)
02cb7ab0: ldr     x22, [x8]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb7ab4: ldr     x0, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb7ab8: bl      #0x2b7104c                                 fn_2b7104c
02cb7abc: adrp    x8, #0x6266000                             
02cb7ac0: mov     x1, x22                                    
02cb7ac4: mov     x3, xzr                                    
02cb7ac8: ldr     x8, [x8, #0xdf0]                           M:DailyLoginRewardUIItem/<>c::<UpdateProcess>b__28_1
02cb7acc: mov     x21, x0                                    
02cb7ad0: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb7ad4: bl      #0x453418c                                 fn_453418c
02cb7ad8: ldr     x8, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb7adc: mov     x1, x21                                    
02cb7ae0: ldr     x0, [x8, #0xb8]                            S:'banner_native_refresh_time'
02cb7ae4: str     x21, [x0, #0x18]!                          
02cb7ae8: bl      #0x2b70d54                                 fn_2b70d54
02cb7aec: cbz     x20, #0x2cb7b10                            
02cb7af0: ldr     x2, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb7af4: mov     x0, x20                                    
02cb7af8: mov     x1, x21                                    
02cb7afc: bl      #0x35a9ce4                                 fn_35a9ce4
02cb7b00: ldr     x0, [x19, #0x88]                           ._notDoneButton
02cb7b04: cbz     x0, #0x2cb7b10                             
02cb7b08: mov     w1, #1                                     
02cb7b0c: b       #0x2cb789c                                 
02cb7b10: bl      #0x2b7105c                                 fn_2b7105c
## OnClaimFreeClick() -> void
---- DailyLoginRewardUIItem::OnClaimFreeClick 0x2cb7f68
02cb7f68: stp     x30, x19, [sp, #-0x10]!                    
02cb7f6c: mov     x19, x0                                    
02cb7f70: mov     x0, xzr                                    
02cb7f74: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02cb7f78: cbz     x0, #0x2cb7fc8                             
02cb7f7c: movi    d1, #0000000000000000                      
02cb7f80: movi    d2, #0000000000000000                      
02cb7f84: mov     w1, #1                                     
02cb7f88: fmov    s0, #1.00000000                            
02cb7f8c: mov     w2, wzr                                    
02cb7f90: mov     w3, wzr                                    
02cb7f94: mov     x4, xzr                                    
02cb7f98: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02cb7f9c: mov     x0, x19                                    
02cb7fa0: bl      #0x2cb7ea0                                 DailyLoginRewardUIItem::CanClaimThisReward
02cb7fa4: tbz     w0, #0, #0x2cb7fc0                         
02cb7fa8: ldr     x0, [x19, #0xc0]                           ._loginTimeRewardPopup
02cb7fac: cbz     x0, #0x2cb7fc8                             
02cb7fb0: mov     x1, x19                                    
02cb7fb4: mov     x2, xzr                                    
02cb7fb8: ldp     x30, x19, [sp], #0x10                      
02cb7fbc: b       #0x2d5a074                                 LoginTimeReward.LoginTimeRewardPopup::ClaimReward
02cb7fc0: ldp     x30, x19, [sp], #0x10                      
02cb7fc4: ret                                                
02cb7fc8: bl      #0x2b7105c                                 fn_2b7105c
## CanClaimThisReward() -> bool
---- DailyLoginRewardUIItem::CanClaimThisReward 0x2cb7ea0
02cb7ea0: str     x30, [sp, #-0x20]!                         
02cb7ea4: stp     x20, x19, [sp, #0x10]                      
02cb7ea8: adrp    x20, #0x662f000                            
02cb7eac: mov     x19, x0                                    
02cb7eb0: ldrb    w8, [x20, #0xbbe]                          
02cb7eb4: tbnz    w8, #0, #0x2cb7ee4                         
02cb7eb8: adrp    x0, #0x6266000                             
02cb7ebc: ldr     x0, [x0, #0x8d0]                           MS:DataManager::GetData
02cb7ec0: bl      #0x2b70db0                                 fn_2b70db0
02cb7ec4: adrp    x0, #0x6266000                             
02cb7ec8: ldr     x0, [x0, #0xdd8]                           MS:System.Collections.Generic.List`1::get_Item
02cb7ecc: bl      #0x2b70db0                                 fn_2b70db0
02cb7ed0: adrp    x0, #0x6266000                             
02cb7ed4: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02cb7ed8: bl      #0x2b70db0                                 fn_2b70db0
02cb7edc: mov     w8, #1                                     
02cb7ee0: strb    w8, [x20, #0xbbe]                          
02cb7ee4: ldr     x8, [x19, #0xb8]                           ._data
02cb7ee8: cbz     x8, #0x2cb7f64                             
02cb7eec: ldr     w8, [x8, #0x10]                            
02cb7ef0: cbz     w8, #0x2cb7f54                             
02cb7ef4: adrp    x8, #0x6266000                             
02cb7ef8: ldr     x8, [x8, #0x658]                           MS:MonoSingleton`1::get_Instance
02cb7efc: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb7f00: bl      #0x3769600                                 fn_3769600
02cb7f04: cbz     x0, #0x2cb7f64                             
02cb7f08: adrp    x8, #0x6266000                             
02cb7f0c: ldr     x8, [x8, #0x8d0]                           MS:DataManager::GetData
02cb7f10: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb7f14: bl      #0x3168dd0                                 fn_3168dd0
02cb7f18: cbz     x0, #0x2cb7f64                             
02cb7f1c: ldr     x9, [x0, #0x20]                            S:'inter_ad_capping_time' ._goClaimed
02cb7f20: cbz     x9, #0x2cb7f64                             
02cb7f24: ldr     x8, [x19, #0xb8]                           ._data
02cb7f28: cbz     x8, #0x2cb7f64                             
02cb7f2c: ldr     x0, [x9, #0x20]                            
02cb7f30: cbz     x0, #0x2cb7f64                             
02cb7f34: adrp    x9, #0x6266000                             
02cb7f38: ldr     x9, [x9, #0xdd8]                           MS:System.Collections.Generic.List`1::get_Item
02cb7f3c: ldr     w8, [x8, #0x10]                            S:'mrec_ad_on_off'
02cb7f40: ldp     x20, x19, [sp, #0x10]                      
02cb7f44: ldr     x2, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb7f48: sub     w1, w8, #1                                 
02cb7f4c: ldr     x30, [sp], #0x20                           
02cb7f50: b       #0x4baf438                                 
02cb7f54: ldp     x20, x19, [sp, #0x10]                      
02cb7f58: mov     w0, #1                                     
02cb7f5c: ldr     x30, [sp], #0x20                           
02cb7f60: ret                                                
02cb7f64: bl      #0x2b7105c                                 fn_2b7105c
## OnWatchAdClick() -> void
---- DailyLoginRewardUIItem::OnWatchAdClick 0x2cb7fcc
02cb7fcc: str     x30, [sp, #-0x30]!                         
02cb7fd0: stp     x22, x21, [sp, #0x10]                      
02cb7fd4: stp     x20, x19, [sp, #0x20]                      
02cb7fd8: adrp    x20, #0x662f000                            
02cb7fdc: mov     x19, x0                                    
02cb7fe0: ldrb    w8, [x20, #0xbbf]                          
02cb7fe4: tbnz    w8, #0, #0x2cb8020                         
02cb7fe8: adrp    x0, #0x6264000                             
02cb7fec: ldr     x0, [x0, #0xf90]                           T:System.Action
02cb7ff0: bl      #0x2b70db0                                 fn_2b70db0
02cb7ff4: adrp    x0, #0x6266000                             
02cb7ff8: ldr     x0, [x0, #0xe10]                           M:DailyLoginRewardUIItem::<OnWatchAdClick>b__31_0
02cb7ffc: bl      #0x2b70db0                                 fn_2b70db0
02cb8000: adrp    x0, #0x6265000                             
02cb8004: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02cb8008: bl      #0x2b70db0                                 fn_2b70db0
02cb800c: adrp    x0, #0x6266000                             
02cb8010: ldr     x0, [x0, #0xe18]                           S:'online_rewards'
02cb8014: bl      #0x2b70db0                                 fn_2b70db0
02cb8018: mov     w8, #1                                     
02cb801c: strb    w8, [x20, #0xbbf]                          
02cb8020: mov     x0, xzr                                    
02cb8024: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02cb8028: cbz     x0, #0x2cb80bc                             
02cb802c: movi    d1, #0000000000000000                      
02cb8030: movi    d2, #0000000000000000                      
02cb8034: adrp    x20, #0x6265000                            
02cb8038: fmov    s0, #1.00000000                            
02cb803c: adrp    x21, #0x6264000                            
02cb8040: adrp    x22, #0x6266000                            
02cb8044: ldr     x20, [x20, #0x310]                         MS:WejoyService.Singleton`1::get_Instance
02cb8048: ldr     x21, [x21, #0xf90]                         T:System.Action
02cb804c: ldr     x22, [x22, #0xe10]                         M:DailyLoginRewardUIItem::<OnWatchAdClick>b__31_0
02cb8050: mov     w1, #1                                     
02cb8054: mov     w2, wzr                                    
02cb8058: mov     w3, wzr                                    
02cb805c: mov     x4, xzr                                    
02cb8060: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02cb8064: ldr     x0, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02cb8068: bl      #0x3be7218                                 fn_3be7218
02cb806c: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cb8070: mov     x20, x0                                    
02cb8074: mov     x0, x8                                     
02cb8078: bl      #0x2b7104c                                 fn_2b7104c
02cb807c: ldr     x2, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb8080: mov     x1, x19                                    
02cb8084: mov     x3, xzr                                    
02cb8088: mov     x21, x0                                    
02cb808c: bl      #0x4d8ddbc                                 System.Action::.ctor
02cb8090: cbz     x20, #0x2cb80bc                            
02cb8094: adrp    x8, #0x6266000                             
02cb8098: mov     x0, x20                                    
02cb809c: mov     x2, x21                                    
02cb80a0: ldr     x8, [x8, #0xe18]                           S:'online_rewards'
02cb80a4: ldp     x20, x19, [sp, #0x20]                      
02cb80a8: ldp     x22, x21, [sp, #0x10]                      
02cb80ac: mov     x3, xzr                                    
02cb80b0: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb80b4: ldr     x30, [sp], #0x30                           
02cb80b8: b       #0x2c8a2c0                                 AdsManager::ShowRewarded
02cb80bc: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- DailyLoginRewardUIItem::.ctor 0x2cb80c0
02cb80c0: mov     x1, xzr                                    
02cb80c4: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
## <AnimShow>b__25_0() -> void
---- DailyLoginRewardUIItem::<AnimShow>b__25_0 0x2cb80c8
02cb80c8: stp     x30, x19, [sp, #-0x10]!                    
02cb80cc: mov     x19, x0                                    
02cb80d0: ldr     x0, [x0, #0x98]                            ._canvasGroup
02cb80d4: cbz     x0, #0x2cb8114                             
02cb80d8: mov     w1, #1                                     
02cb80dc: mov     x2, xzr                                    
02cb80e0: bl      #0x5e45290                                 UnityEngine.CanvasGroup::set_interactable
02cb80e4: ldr     x0, [x19, #0x98]                           ._canvasGroup
02cb80e8: cbz     x0, #0x2cb8114                             
02cb80ec: mov     w1, #1                                     
02cb80f0: mov     x2, xzr                                    
02cb80f4: bl      #0x5e45408                                 UnityEngine.CanvasGroup::set_blocksRaycasts
02cb80f8: adrp    x8, #0x1084000                             
02cb80fc: ldr     x0, [x19, #0x90]                           ._imgHorizontalLine
02cb8100: fmov    s0, #1.00000000                            
02cb8104: ldr     s1, [x8, #0xf10]                           [1084f10]=4110bc863e99999a f=0.3,9.04603
02cb8108: mov     x1, xzr                                    
02cb810c: ldp     x30, x19, [sp], #0x10                      
02cb8110: b       #0x2c789b8                                 DG.Tweening.DOTweenModuleUI::DOFade
02cb8114: bl      #0x2b7105c                                 fn_2b7105c
## <OnWatchAdClick>b__31_0() -> void
---- DailyLoginRewardUIItem::<OnWatchAdClick>b__31_0 0x2cb8118
02cb8118: stp     x30, x19, [sp, #-0x10]!                    
02cb811c: mov     x19, x0                                    
02cb8120: bl      #0x2cb7ea0                                 DailyLoginRewardUIItem::CanClaimThisReward
02cb8124: tbz     w0, #0, #0x2cb8140                         
02cb8128: ldr     x0, [x19, #0xc0]                           ._loginTimeRewardPopup
02cb812c: cbz     x0, #0x2cb8148                             
02cb8130: mov     x1, x19                                    
02cb8134: mov     x2, xzr                                    
02cb8138: ldp     x30, x19, [sp], #0x10                      
02cb813c: b       #0x2d5a074                                 LoginTimeReward.LoginTimeRewardPopup::ClaimReward
02cb8140: ldp     x30, x19, [sp], #0x10                      
02cb8144: ret                                                
02cb8148: bl      #0x2b7105c                                 fn_2b7105c
