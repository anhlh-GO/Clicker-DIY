#### CLASS DailyMission.DailyItemBase parent= UnityEngine.MonoBehaviour
#   field Config                         DailyMission.DailyItemConfig                       off=0x20 attr=4 SerializeField
#   field DayTextClaimed                 TMPro.TextMeshProUGUI                              off=0x28 attr=4 SerializeField
#   field DayTextSelected                TMPro.TextMeshProUGUI                              off=0x30 attr=4 SerializeField
#   field DayTextNormal                  TMPro.TextMeshProUGUI                              off=0x38 attr=4 SerializeField
#   field PanelImage                     UnityEngine.UI.Image                               off=0x40 attr=4 SerializeField
#   field DayIndex                       int                                                off=0x48 attr=4 
#   field DailyConfig                    DailyMission.DailyConfig                           off=0x50 attr=4 
#   field Controller                     DailyReward.DailyLoginController                   off=0x58 attr=4 
#   field Content                        DailyMission.DailyContent                          off=0x60 attr=4 
## OnInit(int index, DailyMission.DailyConfig dailyConfig, DailyReward.DailyLoginController dailyLoginController) -> void
---- DailyMission.DailyItemBase::OnInit 0x2d764b8
02d764b8: stp     x30, x21, [sp, #-0x20]!                    
02d764bc: stp     x20, x19, [sp, #0x10]                      
02d764c0: mov     x21, x0                                    
02d764c4: mov     x19, x0                                    
02d764c8: str     w1, [x0, #0x48]                            .DayIndex
02d764cc: str     x2, [x21, #0x50]!                          .DailyConfig
02d764d0: mov     x0, x21                                    
02d764d4: mov     x1, x2                                     
02d764d8: mov     x20, x3                                    
02d764dc: bl      #0x2b70d54                                 fn_2b70d54
02d764e0: mov     x0, x19                                    
02d764e4: mov     x1, x20                                    
02d764e8: str     x20, [x0, #0x58]!                          .Controller
02d764ec: bl      #0x2b70d54                                 fn_2b70d54
02d764f0: ldr     x0, [x21]                                  
02d764f4: cbz     x0, #0x2d76528                             
02d764f8: ldr     w1, [x19, #0x48]                           .DayIndex
02d764fc: bl      #0x2d76398                                 DailyMission.DailyConfig::GetConfig
02d76500: mov     x1, x0                                     
02d76504: mov     x0, x19                                    
02d76508: str     x1, [x0, #0x60]!                           .Content
02d7650c: bl      #0x2b70d54                                 fn_2b70d54
02d76510: ldr     x8, [x19]                                  
02d76514: mov     x0, x19                                    
02d76518: ldp     x20, x19, [sp, #0x10]                      
02d7651c: ldp     x2, x1, [x8, #0x188]                       
02d76520: ldp     x30, x21, [sp], #0x20                      
02d76524: br      x2                                         
02d76528: bl      #0x2b7105c                                 fn_2b7105c
## SetUpData() -> void
---- DailyMission.DailyItemBase::SetUpData 0x2d7652c
02d7652c: ret                                                
## OnRefresh() -> void
---- DailyMission.DailyItemBase::OnRefresh 0x2d76530
02d76530: str     x30, [sp, #-0x40]!                         
02d76534: stp     x24, x23, [sp, #0x10]                      
02d76538: stp     x22, x21, [sp, #0x20]                      
02d7653c: stp     x20, x19, [sp, #0x30]                      
02d76540: adrp    x21, #0x6630000                            
02d76544: adrp    x20, #0x6266000                            
02d76548: mov     x19, x0                                    
02d7654c: ldrb    w8, [x21, #0x3da]                          
02d76550: ldr     x20, [x20, #0x9f0]                         T:Assets.SimpleLocalization.Scripts.LocalizationManager
02d76554: tbnz    w8, #0, #0x2d76584                         
02d76558: adrp    x0, #0x6266000                             
02d7655c: ldr     x0, [x0, #0x9f0]                           T:Assets.SimpleLocalization.Scripts.LocalizationManager
02d76560: bl      #0x2b70db0                                 fn_2b70db0
02d76564: adrp    x0, #0x6266000                             
02d76568: ldr     x0, [x0, #0xdc8]                           S:'$'
02d7656c: bl      #0x2b70db0                                 fn_2b70db0
02d76570: adrp    x0, #0x626a000                             
02d76574: ldr     x0, [x0, #0x208]                           S:'Day $'
02d76578: bl      #0x2b70db0                                 fn_2b70db0
02d7657c: mov     w8, #1                                     
02d76580: strb    w8, [x21, #0x3da]                          
02d76584: adrp    x23, #0x626a000                            
02d76588: mov     x0, x19                                    
02d7658c: ldr     x23, [x23, #0x208]                         S:'Day $'
02d76590: str     wzr, [sp, #0xc]                            
02d76594: bl      #0x2d7675c                                 DailyMission.DailyItemBase::GetStatus
02d76598: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7659c: ldr     x21, [x19, #0x28]                          .DayTextClaimed
02d765a0: mov     w20, w0                                    
02d765a4: ldr     w9, [x8, #0xe4]                            
02d765a8: cbnz    w9, #0x2d765b4                             
02d765ac: mov     x0, x8                                     
02d765b0: bl      #0x2b70f30                                 fn_2b70f30
02d765b4: ldr     x0, [x23]                                  T:type56879(k15)
02d765b8: bl      #0x2d76794                                 Assets.SimpleLocalization.Scripts.LocalizationManager::Localize
02d765bc: ldr     w8, [x19, #0x48]                           .DayIndex
02d765c0: mov     x22, x0                                    
02d765c4: add     x0, sp, #0xc                               
02d765c8: mov     x1, xzr                                    
02d765cc: add     w8, w8, #1                                 
02d765d0: str     w8, [sp, #0xc]                             
02d765d4: bl      #0x4e0ea3c                                 System.Int32::ToString
02d765d8: cbz     x22, #0x2d76758                            
02d765dc: adrp    x24, #0x6266000                            
02d765e0: mov     x2, x0                                     
02d765e4: mov     x0, x22                                    
02d765e8: ldr     x24, [x24, #0xdc8]                         S:'$'
02d765ec: mov     x3, xzr                                    
02d765f0: ldr     x1, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d765f4: bl      #0x4ca8ca8                                 System.String::Replace
02d765f8: cbz     x21, #0x2d76758                            
02d765fc: ldr     x8, [x21]                                  
02d76600: mov     x1, x0                                     
02d76604: mov     x0, x21                                    
02d76608: ldr     x9, [x8, #0x558]                           
02d7660c: ldr     x2, [x8, #0x560]                           
02d76610: blr     x9                                         
02d76614: ldr     x0, [x23]                                  T:type56879(k15)
02d76618: ldr     x21, [x19, #0x30]                          .DayTextSelected
02d7661c: bl      #0x2d76794                                 Assets.SimpleLocalization.Scripts.LocalizationManager::Localize
02d76620: ldr     w8, [x19, #0x48]                           .DayIndex
02d76624: mov     x22, x0                                    
02d76628: add     x0, sp, #0xc                               
02d7662c: mov     x1, xzr                                    
02d76630: add     w8, w8, #1                                 
02d76634: str     w8, [sp, #0xc]                             
02d76638: bl      #0x4e0ea3c                                 System.Int32::ToString
02d7663c: cbz     x22, #0x2d76758                            
02d76640: ldr     x1, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d76644: mov     x2, x0                                     
02d76648: mov     x0, x22                                    
02d7664c: mov     x3, xzr                                    
02d76650: bl      #0x4ca8ca8                                 System.String::Replace
02d76654: cbz     x21, #0x2d76758                            
02d76658: ldr     x8, [x21]                                  
02d7665c: mov     x1, x0                                     
02d76660: mov     x0, x21                                    
02d76664: ldr     x9, [x8, #0x558]                           
02d76668: ldr     x2, [x8, #0x560]                           
02d7666c: blr     x9                                         
02d76670: ldr     x0, [x23]                                  T:type56879(k15)
02d76674: ldr     x21, [x19, #0x38]                          .DayTextNormal
02d76678: bl      #0x2d76794                                 Assets.SimpleLocalization.Scripts.LocalizationManager::Localize
02d7667c: ldr     w8, [x19, #0x48]                           .DayIndex
02d76680: mov     x22, x0                                    
02d76684: add     x0, sp, #0xc                               
02d76688: mov     x1, xzr                                    
02d7668c: add     w8, w8, #1                                 
02d76690: str     w8, [sp, #0xc]                             
02d76694: bl      #0x4e0ea3c                                 System.Int32::ToString
02d76698: cbz     x22, #0x2d76758                            
02d7669c: ldr     x1, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d766a0: mov     x2, x0                                     
02d766a4: mov     x0, x22                                    
02d766a8: mov     x3, xzr                                    
02d766ac: bl      #0x4ca8ca8                                 System.String::Replace
02d766b0: cbz     x21, #0x2d76758                            
02d766b4: ldr     x8, [x21]                                  
02d766b8: mov     x1, x0                                     
02d766bc: mov     x0, x21                                    
02d766c0: ldr     x9, [x8, #0x558]                           
02d766c4: ldr     x2, [x8, #0x560]                           
02d766c8: blr     x9                                         
02d766cc: ldr     x0, [x19, #0x28]                           .DayTextClaimed
02d766d0: cbz     x0, #0x2d76758                             
02d766d4: mov     x1, xzr                                    
02d766d8: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d766dc: cbz     x0, #0x2d76758                             
02d766e0: cmp     w20, #1                                    
02d766e4: mov     x2, xzr                                    
02d766e8: cset    w1, eq                                     
02d766ec: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d766f0: ldr     x0, [x19, #0x30]                           .DayTextSelected
02d766f4: cbz     x0, #0x2d76758                             
02d766f8: mov     x1, xzr                                    
02d766fc: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d76700: cbz     x0, #0x2d76758                             
02d76704: cmp     w20, #0                                    
02d76708: mov     x2, xzr                                    
02d7670c: cset    w1, eq                                     
02d76710: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d76714: ldr     x0, [x19, #0x38]                           .DayTextNormal
02d76718: cbz     x0, #0x2d76758                             
02d7671c: mov     x1, xzr                                    
02d76720: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d76724: cbz     x0, #0x2d76758                             
02d76728: cmp     w20, #2                                    
02d7672c: mov     x2, xzr                                    
02d76730: cset    w1, eq                                     
02d76734: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d76738: mov     x0, x19                                    
02d7673c: mov     w1, w20                                    
02d76740: bl      #0x2d76cf0                                 DailyMission.DailyItemBase::ChangePanelItem
02d76744: ldp     x20, x19, [sp, #0x30]                      
02d76748: ldp     x22, x21, [sp, #0x20]                      
02d7674c: ldp     x24, x23, [sp, #0x10]                      
02d76750: ldr     x30, [sp], #0x40                           
02d76754: ret                                                
02d76758: bl      #0x2b7105c                                 fn_2b7105c
## OnReward() -> void
---- DailyMission.DailyItemBase::OnReward 0x2d76d44
02d76d44: sub     sp, sp, #0x90                              
02d76d48: stp     x30, x27, [sp, #0x40]                      
02d76d4c: stp     x26, x25, [sp, #0x50]                      
02d76d50: stp     x24, x23, [sp, #0x60]                      
02d76d54: stp     x22, x21, [sp, #0x70]                      
02d76d58: stp     x20, x19, [sp, #0x80]                      
02d76d5c: adrp    x19, #0x6630000                            
02d76d60: mov     x21, x0                                    
02d76d64: ldrb    w8, [x19, #0x3db]                          
02d76d68: tbnz    w8, #0, #0x2d76df8                         
02d76d6c: adrp    x0, #0x6266000                             
02d76d70: ldr     x0, [x0, #0x870]                           MS:DataManager::GetAsset
02d76d74: bl      #0x2b70db0                                 fn_2b70db0
02d76d78: adrp    x0, #0x6266000                             
02d76d7c: ldr     x0, [x0, #0x878]                           MS:DataManager::GetData
02d76d80: bl      #0x2b70db0                                 fn_2b70db0
02d76d84: adrp    x0, #0x6266000                             
02d76d88: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d76d8c: bl      #0x2b70db0                                 fn_2b70db0
02d76d90: adrp    x0, #0x626c000                             
02d76d94: ldr     x0, [x0, #0x890]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d76d98: bl      #0x2b70db0                                 fn_2b70db0
02d76d9c: adrp    x0, #0x626c000                             
02d76da0: ldr     x0, [x0, #0x898]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d76da4: bl      #0x2b70db0                                 fn_2b70db0
02d76da8: adrp    x0, #0x626c000                             
02d76dac: ldr     x0, [x0, #0x8a0]                           MS:System.Collections.Generic.List`1/Enumerator::get_Current
02d76db0: bl      #0x2b70db0                                 fn_2b70db0
02d76db4: adrp    x0, #0x626c000                             
02d76db8: ldr     x0, [x0, #0x8a8]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d76dbc: bl      #0x2b70db0                                 fn_2b70db0
02d76dc0: adrp    x0, #0x6266000                             
02d76dc4: ldr     x0, [x0, #0xaa0]                           MS:MonoSingleton`1::get_Instance
02d76dc8: bl      #0x2b70db0                                 fn_2b70db0
02d76dcc: adrp    x0, #0x6266000                             
02d76dd0: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d76dd4: bl      #0x2b70db0                                 fn_2b70db0
02d76dd8: adrp    x0, #0x6264000                             
02d76ddc: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02d76de0: bl      #0x2b70db0                                 fn_2b70db0
02d76de4: adrp    x0, #0x626c000                             
02d76de8: ldr     x0, [x0, #0x8b0]                           S:'Keycap'
02d76dec: bl      #0x2b70db0                                 fn_2b70db0
02d76df0: mov     w8, #1                                     
02d76df4: strb    w8, [x19, #0x3db]                          
02d76df8: ldr     x8, [x21, #0x60]                           .Content
02d76dfc: stp     xzr, xzr, [sp, #0x20]                      
02d76e00: str     xzr, [sp, #0x30]                           
02d76e04: cbz     x8, #0x2d77054                             
02d76e08: ldrb    w8, [x8, #0x18]                            
02d76e0c: cbz     w8, #0x2d76e58                             
02d76e10: adrp    x8, #0x6266000                             
02d76e14: ldr     x8, [x8, #0xaa0]                           MS:MonoSingleton`1::get_Instance
02d76e18: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d76e1c: bl      #0x3769600                                 fn_3769600
02d76e20: ldr     x8, [x21, #0x60]                           .Content
02d76e24: cbz     x8, #0x2d77054                             
02d76e28: cbz     x0, #0x2d77054                             
02d76e2c: ldp     x20, x19, [sp, #0x80]                      
02d76e30: mov     w2, #0xa                                   
02d76e34: ldp     x22, x21, [sp, #0x70]                      
02d76e38: mov     x3, xzr                                    
02d76e3c: ldp     x24, x23, [sp, #0x60]                      
02d76e40: mov     x4, xzr                                    
02d76e44: ldp     x26, x25, [sp, #0x50]                      
02d76e48: ldr     w1, [x8, #0x1c]                            [626601c]=0 f=0,0
02d76e4c: ldp     x30, x27, [sp, #0x40]                      
02d76e50: add     sp, sp, #0x90                              
02d76e54: b       #0x2cdaf30                                 MoneyManager::CollectMoney
02d76e58: adrp    x8, #0x6266000                             
02d76e5c: ldr     x8, [x8, #0x658]                           MS:MonoSingleton`1::get_Instance
02d76e60: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d76e64: bl      #0x3769600                                 fn_3769600
02d76e68: cbz     x0, #0x2d77054                             
02d76e6c: adrp    x8, #0x6266000                             
02d76e70: mov     x22, x0                                    
02d76e74: ldr     x8, [x8, #0x870]                           MS:DataManager::GetAsset
02d76e78: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d76e7c: bl      #0x3168af0                                 fn_3168af0
02d76e80: adrp    x8, #0x6266000                             
02d76e84: mov     x19, x0                                    
02d76e88: mov     x0, x22                                    
02d76e8c: ldr     x8, [x8, #0x878]                           MS:DataManager::GetData
02d76e90: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d76e94: bl      #0x3168dd0                                 fn_3168dd0
02d76e98: adrp    x8, #0x6266000                             
02d76e9c: mov     x20, x0                                    
02d76ea0: mov     x0, x22                                    
02d76ea4: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02d76ea8: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d76eac: bl      #0x3168dd0                                 fn_3168dd0
02d76eb0: ldr     x8, [x21, #0x60]                           .Content
02d76eb4: cbz     x8, #0x2d77054                             
02d76eb8: ldr     x8, [x8, #0x20]                            S:'inter_ad_capping_time'
02d76ebc: cbz     x8, #0x2d77054                             
02d76ec0: mov     x21, x0                                    
02d76ec4: ldr     x0, [x8, #0x10]                            S:'mrec_ad_on_off'
02d76ec8: cbz     x0, #0x2d77054                             
02d76ecc: adrp    x8, #0x626c000                             
02d76ed0: ldr     x8, [x8, #0x8a8]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d76ed4: ldr     x1, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d76ed8: add     x8, sp, #8                                 
02d76edc: bl      #0x35a9d9c                                 fn_35a9d9c
02d76ee0: ldur    q0, [sp, #8]                               
02d76ee4: ldr     x8, [sp, #0x18]                            
02d76ee8: adrp    x23, #0x626c000                            
02d76eec: ldr     x23, [x23, #0x898]                         MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d76ef0: adrp    x24, #0x626c000                            
02d76ef4: adrp    x22, #0x6264000                            
02d76ef8: str     q0, [sp, #0x20]                            
02d76efc: add     x9, sp, #0x20                              
02d76f00: adrp    x25, #0x662f000                            
02d76f04: ldr     x24, [x24, #0x8b0]                         S:'Keycap'
02d76f08: str     x8, [sp, #0x30]                            
02d76f0c: mov     w26, #1                                    
02d76f10: ldr     x22, [x22, #0xfc0]                         T:RemoteConfigManager
02d76f14: stp     xzr, x9, [sp, #8]                          
02d76f18: ldr     x1, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d76f1c: add     x0, sp, #0x20                              
02d76f20: bl      #0x4690474                                 fn_4690474
02d76f24: tbz     w0, #0, #0x2d7701c                         
02d76f28: ldr     x27, [sp, #0x30]                           
02d76f2c: cbz     x27, #0x2d7704c                            
02d76f30: ldr     x0, [x27, #0x10]                           
02d76f34: ldr     x1, [x24]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d76f38: mov     x2, xzr                                    
02d76f3c: bl      #0x4ca52b8                                 System.String::op_Equality
02d76f40: tbz     w0, #0, #0x2d76fb8                         
02d76f44: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d76f48: ldr     w8, [x0, #0xe4]                            [626c0e4]=0 f=0,0
02d76f4c: cbnz    w8, #0x2d76f54                             
02d76f50: bl      #0x2b70f30                                 fn_2b70f30
02d76f54: ldrb    w8, [x25, #0xbc1]                          
02d76f58: cbnz    w8, #0x2d76f68                             
02d76f5c: mov     x0, x22                                    
02d76f60: bl      #0x2b70db0                                 fn_2b70db0
02d76f64: strb    w26, [x25, #0xbc1]                         
02d76f68: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d76f6c: ldr     w8, [x0, #0xe4]                            [626c0e4]=0 f=0,0
02d76f70: cbnz    w8, #0x2d76f7c                             
02d76f74: bl      #0x2b70f30                                 fn_2b70f30
02d76f78: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d76f7c: ldr     x8, [x0, #0xb8]                            MS:System.Collections.Generic.List`1::Add
02d76f80: ldr     w8, [x8, #0x10]                            M:Clicker.GlowSprite2DItem::<DoGlow>b__10_4
02d76f84: cmp     w8, #1                                     
02d76f88: b.ne    #0x2d76ff0                                 
02d76f8c: cbz     x21, #0x2d7705c                            
02d76f90: ldr     w1, [x27, #0x18]                           
02d76f94: mov     x0, x21                                    
02d76f98: mov     x2, xzr                                    
02d76f9c: bl      #0x2cabd24                                 DataUser::HasUnlockedKeycapDecor
02d76fa0: tbnz    w0, #0, #0x2d76f18                         
02d76fa4: ldr     w1, [x27, #0x18]                           
02d76fa8: mov     x0, x21                                    
02d76fac: mov     x2, xzr                                    
02d76fb0: bl      #0x2cabc2c                                 DataUser::UnlockClickerDecor
02d76fb4: b       #0x2d76f18                                 
02d76fb8: cbz     x19, #0x2d77050                            
02d76fbc: ldr     x1, [x27, #0x10]                           
02d76fc0: mov     x0, x19                                    
02d76fc4: mov     x2, xzr                                    
02d76fc8: bl      #0x2d25fc0                                 Decor.DecorAsset::GetCategoryIndexByName
02d76fcc: mov     w1, w0                                     
02d76fd0: cmn     w1, #1                                     
02d76fd4: b.eq    #0x2d76f18                                 
02d76fd8: cbz     x20, #0x2d77058                            
02d76fdc: ldr     w2, [x27, #0x18]                           
02d76fe0: mov     x0, x20                                    
02d76fe4: mov     x3, xzr                                    
02d76fe8: bl      #0x2d259d8                                 Decor.DataDecor::UnlockItem
02d76fec: b       #0x2d76f18                                 
02d76ff0: cbz     x21, #0x2d77060                            
02d76ff4: ldr     w1, [x27, #0x1c]                           
02d76ff8: mov     x0, x21                                    
02d76ffc: mov     x2, xzr                                    
02d77000: bl      #0x2cabd24                                 DataUser::HasUnlockedKeycapDecor
02d77004: tbnz    w0, #0, #0x2d76f18                         
02d77008: ldr     w1, [x27, #0x1c]                           
02d7700c: mov     x0, x21                                    
02d77010: mov     x2, xzr                                    
02d77014: bl      #0x2cabc2c                                 DataUser::UnlockClickerDecor
02d77018: b       #0x2d76f18                                 
02d7701c: adrp    x8, #0x626c000                             
02d77020: add     x0, sp, #0x20                              
02d77024: ldr     x8, [x8, #0x890]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d77028: ldr     x1, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7702c: bl      #0x4690470                                 fn_4690470
02d77030: ldp     x20, x19, [sp, #0x80]                      
02d77034: ldp     x22, x21, [sp, #0x70]                      
02d77038: ldp     x24, x23, [sp, #0x60]                      
02d7703c: ldp     x26, x25, [sp, #0x50]                      
02d77040: ldp     x30, x27, [sp, #0x40]                      
02d77044: add     sp, sp, #0x90                              
02d77048: ret                                                
02d7704c: bl      #0x2b7105c                                 fn_2b7105c
02d77050: bl      #0x2b7105c                                 fn_2b7105c
02d77054: bl      #0x2b7105c                                 fn_2b7105c
02d77058: bl      #0x2b7105c                                 fn_2b7105c
02d7705c: bl      #0x2b7105c                                 fn_2b7105c
02d77060: bl      #0x2b7105c                                 fn_2b7105c
02d77064: b       #0x2d7709c                                 
02d77068: b       #0x2d7709c                                 
02d7706c: b       #0x2d7709c                                 
02d77070: b       #0x2d7709c                                 
02d77074: b       #0x2d7709c                                 
02d77078: b       #0x2d7709c                                 
02d7707c: b       #0x2d7709c                                 
02d77080: b       #0x2d7709c                                 
02d77084: b       #0x2d7709c                                 
02d77088: b       #0x2d7709c                                 
02d7708c: b       #0x2d7709c                                 
02d77090: b       #0x2d7709c                                 
02d77094: b       #0x2d7709c                                 
02d77098: b       #0x2d7709c                                 
02d7709c: mov     x19, x0                                    
02d770a0: cmp     w1, #1                                     
02d770a4: b.ne    #0x2d770e0                                 
02d770a8: mov     x0, x19                                    
02d770ac: bl      #0x5e90260                                 fn_5e90260
02d770b0: ldr     x19, [x0]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d770b4: str     x19, [sp, #8]                              
02d770b8: bl      #0x5e90270                                 fn_5e90270
02d770bc: adrp    x8, #0x626c000                             
02d770c0: ldr     x8, [x8, #0x890]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d770c4: ldr     x0, [sp, #0x10]                            
02d770c8: ldr     x1, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d770cc: bl      #0x4690470                                 fn_4690470
02d770d0: cbz     x19, #0x2d77030                            
02d770d4: mov     x0, x19                                    
02d770d8: bl      #0x2b71054                                 fn_2b71054
02d770dc: mov     x19, x0                                    
02d770e0: add     x0, sp, #8                                 
02d770e4: bl      #0x2738888                                 fn_2738888
02d770e8: mov     x0, x19                                    
02d770ec: bl      #0x2c6051c                                 fn_2c6051c
02d770f0: bl      #0x27369b8                                 fn_27369b8
## ChangePanelItem(DailyMission.DailyItemStatus status) -> void
---- DailyMission.DailyItemBase::ChangePanelItem 0x2d76cf0
02d76cf0: str     x30, [sp, #-0x10]!                         
02d76cf4: mov     x8, x0                                     
02d76cf8: ldr     x0, [x0, #0x40]                            .PanelImage
02d76cfc: ldr     x8, [x8, #0x20]                            
02d76d00: cbz     w1, #0x2d76d18                             
02d76d04: cmp     w1, #1                                     
02d76d08: b.ne    #0x2d76d24                                 
02d76d0c: cbz     x8, #0x2d76d40                             
02d76d10: add     x8, x8, #0x18                              
02d76d14: b       #0x2d76d2c                                 
02d76d18: cbz     x8, #0x2d76d40                             
02d76d1c: add     x8, x8, #0x20                              
02d76d20: b       #0x2d76d2c                                 
02d76d24: cbz     x8, #0x2d76d40                             
02d76d28: add     x8, x8, #0x28                              
02d76d2c: cbz     x0, #0x2d76d40                             
02d76d30: ldr     x1, [x8]                                   
02d76d34: mov     x2, xzr                                    
02d76d38: ldr     x30, [sp], #0x10                           
02d76d3c: b       #0x5c45aa0                                 UnityEngine.UI.Image::set_sprite
02d76d40: bl      #0x2b7105c                                 fn_2b7105c
## GetStatus() -> DailyMission.DailyItemStatus
---- DailyMission.DailyItemBase::GetStatus 0x2d7675c
02d7675c: stp     x30, x19, [sp, #-0x10]!                    
02d76760: mov     x19, x0                                    
02d76764: ldr     x0, [x0, #0x58]                            .Controller
02d76768: cbz     x0, #0x2d76790                             
02d7676c: mov     x1, xzr                                    
02d76770: bl      #0x2cf3b90                                 DailyReward.DailyLoginController::GetLoginDayIndex
02d76774: ldr     w8, [x19, #0x48]                           .DayIndex
02d76778: cmp     w8, w0                                     
02d7677c: cset    w8, ne                                     
02d76780: lsl     w8, w8, #1                                 
02d76784: csinc   w0, w8, wzr, ge                            
02d76788: ldp     x30, x19, [sp], #0x10                      
02d7678c: ret                                                
02d76790: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- DailyMission.DailyItemBase::.ctor 0x2d770f4
02d770f4: mov     x1, xzr                                    
02d770f8: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
