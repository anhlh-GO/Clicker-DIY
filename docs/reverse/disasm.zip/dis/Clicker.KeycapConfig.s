#### CLASS Clicker.KeycapConfig/<>c__DisplayClass5_0 parent= object
#   field id                             int                                                off=0x10 attr=6 
## .ctor() -> void
---- Clicker.KeycapConfig/<>c__DisplayClass5_0::.ctor 0x2d5b8f8
02d5b8f8: mov     x1, xzr                                    
02d5b8fc: b       #0x4e53e9c                                 System.Object::.ctor
## <GetData>b__0(Clicker.KeycapItemData data) -> bool
---- Clicker.KeycapConfig/<>c__DisplayClass5_0::<GetData>b__0 0x2d5b908
02d5b908: cbz     x1, #0x2d5b920                             
02d5b90c: ldr     w8, [x1, #0x10]                            
02d5b910: ldr     w9, [x0, #0x10]                            .id
02d5b914: cmp     w8, w9                                     
02d5b918: cset    w0, eq                                     
02d5b91c: ret                                                
02d5b920: str     x30, [sp, #-0x10]!                         
02d5b924: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Clicker.KeycapConfig parent= Clicker.GameConfig
#   field _dataList                      System.Collections.Generic.List`1<Clicker.KeycapItemData> off=0x18 attr=1 SerializeField
## get_DataList() -> System.Collections.Generic.List`1<Clicker.KeycapItemData>
---- Clicker.KeycapConfig::get_DataList 0x2d5b7d0
02d5b7d0: ldr     x0, [x0, #0x18]                            ._dataList
02d5b7d4: ret                                                
## get_Count() -> int
---- Clicker.KeycapConfig::get_Count 0x2d5b7d8
02d5b7d8: str     x30, [sp, #-0x20]!                         
02d5b7dc: stp     x20, x19, [sp, #0x10]                      
02d5b7e0: adrp    x20, #0x6630000                            
02d5b7e4: mov     x19, x0                                    
02d5b7e8: ldrb    w8, [x20, #0x2c3]                          
02d5b7ec: tbnz    w8, #0, #0x2d5b804                         
02d5b7f0: adrp    x0, #0x626b000                             
02d5b7f4: ldr     x0, [x0, #0xc48]                           MS:System.Collections.Generic.List`1::get_Count
02d5b7f8: bl      #0x2b70db0                                 fn_2b70db0
02d5b7fc: mov     w8, #1                                     
02d5b800: strb    w8, [x20, #0x2c3]                          
02d5b804: ldr     x8, [x19, #0x18]                           ._dataList
02d5b808: cbz     x8, #0x2d5b81c                             
02d5b80c: ldp     x20, x19, [sp, #0x10]                      
02d5b810: ldr     w0, [x8, #0x18]                            
02d5b814: ldr     x30, [sp], #0x20                           
02d5b818: ret                                                
02d5b81c: bl      #0x2b7105c                                 fn_2b7105c
## GetData(int id) -> Clicker.KeycapItemData
---- Clicker.KeycapConfig::GetData 0x2d5b820
02d5b820: str     x30, [sp, #-0x30]!                         
02d5b824: stp     x22, x21, [sp, #0x10]                      
02d5b828: stp     x20, x19, [sp, #0x20]                      
02d5b82c: adrp    x21, #0x6630000                            
02d5b830: adrp    x22, #0x626b000                            
02d5b834: mov     w19, w1                                    
02d5b838: ldrb    w8, [x21, #0x2c4]                          
02d5b83c: ldr     x22, [x22, #0xc50]                         T:Clicker.KeycapConfig/<>c__DisplayClass5_0
02d5b840: mov     x20, x0                                    
02d5b844: tbnz    w8, #0, #0x2d5b880                         
02d5b848: adrp    x0, #0x626b000                             
02d5b84c: ldr     x0, [x0, #0xc58]                           MS:System.Collections.Generic.List`1::Find
02d5b850: bl      #0x2b70db0                                 fn_2b70db0
02d5b854: adrp    x0, #0x626b000                             
02d5b858: ldr     x0, [x0, #0xc60]                           T:type57255(k15)
02d5b85c: bl      #0x2b70db0                                 fn_2b70db0
02d5b860: adrp    x0, #0x626b000                             
02d5b864: ldr     x0, [x0, #0xc68]                           M:Clicker.KeycapConfig/<>c__DisplayClass5_0::<GetData>b__0
02d5b868: bl      #0x2b70db0                                 fn_2b70db0
02d5b86c: adrp    x0, #0x626b000                             
02d5b870: ldr     x0, [x0, #0xc50]                           T:Clicker.KeycapConfig/<>c__DisplayClass5_0
02d5b874: bl      #0x2b70db0                                 fn_2b70db0
02d5b878: mov     w8, #1                                     
02d5b87c: strb    w8, [x21, #0x2c4]                          
02d5b880: ldr     x0, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5b884: bl      #0x2b7104c                                 fn_2b7104c
02d5b888: mov     x1, xzr                                    
02d5b88c: mov     x21, x0                                    
02d5b890: bl      #0x4e53e9c                                 System.Object::.ctor
02d5b894: cbz     x21, #0x2d5b8f4                            
02d5b898: adrp    x8, #0x626b000                             
02d5b89c: adrp    x22, #0x626b000                            
02d5b8a0: ldr     x8, [x8, #0xc60]                           T:type57255(k15)
02d5b8a4: ldr     x22, [x22, #0xc68]                         M:Clicker.KeycapConfig/<>c__DisplayClass5_0::<GetData>b__0
02d5b8a8: ldr     x20, [x20, #0x18]                          ._dataList
02d5b8ac: str     w19, [x21, #0x10]                          
02d5b8b0: ldr     x0, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5b8b4: bl      #0x2b7104c                                 fn_2b7104c
02d5b8b8: ldr     x2, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5b8bc: mov     x1, x21                                    
02d5b8c0: mov     x3, xzr                                    
02d5b8c4: mov     x19, x0                                    
02d5b8c8: bl      #0x399ba10                                 fn_399ba10
02d5b8cc: cbz     x20, #0x2d5b8f4                            
02d5b8d0: adrp    x8, #0x626b000                             
02d5b8d4: mov     x0, x20                                    
02d5b8d8: mov     x1, x19                                    
02d5b8dc: ldr     x8, [x8, #0xc58]                           MS:System.Collections.Generic.List`1::Find
02d5b8e0: ldp     x20, x19, [sp, #0x20]                      
02d5b8e4: ldp     x22, x21, [sp, #0x10]                      
02d5b8e8: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5b8ec: ldr     x30, [sp], #0x30                           
02d5b8f0: b       #0x35a9868                                 
02d5b8f4: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Clicker.KeycapConfig::.ctor 0x2d5b900
02d5b900: mov     x1, xzr                                    
02d5b904: b       #0x5b398f0                                 UnityEngine.ScriptableObject::.ctor
