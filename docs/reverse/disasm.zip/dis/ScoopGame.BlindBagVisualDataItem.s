#### CLASS ScoopGame.BlindBagVisualDataItem parent= object
#   field ID                             int                                                off=0x10 attr=6 
#   field SkinName                       string                                             off=0x18 attr=6 
#   field Full                           UnityEngine.Sprite                                 off=0x20 attr=6 
#   field Half1                          UnityEngine.Sprite                                 off=0x28 attr=6 
#   field Half2                          UnityEngine.Sprite                                 off=0x30 attr=6 
## .ctor() -> void
---- ScoopGame.BlindBagVisualDataItem::.ctor 0x2d42410
02d42410: mov     x1, xzr                                    
02d42414: b       #0x4e53e9c                                 System.Object::.ctor
