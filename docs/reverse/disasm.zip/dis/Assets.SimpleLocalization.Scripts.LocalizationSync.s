#### CLASS Assets.SimpleLocalization.Scripts.LocalizationSync parent= UnityEngine.MonoBehaviour
#   field TableId                        string                                             off=0x20 attr=6 
#   field Sheets                         Assets.SimpleLocalization.Scripts.Sheet[]          off=0x28 attr=6 
#   field SaveFolder                     UnityEngine.Object                                 off=0x30 attr=6 
#   field UrlPattern                     string                                             off=0x0 attr=8051 
## .ctor() -> void
---- Assets.SimpleLocalization.Scripts.LocalizationSync::.ctor 0x2d7c5d8
02d7c5d8: mov     x1, xzr                                    
02d7c5dc: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
