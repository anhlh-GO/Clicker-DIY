#### CLASS Framework.AutoInvokeWithDelay parent= UnityEngine.MonoBehaviour
#   field OnInvoke                       UnityEngine.Events.UnityEvent                      off=0x20 attr=6 
#   field _delay                         float                                              off=0x28 attr=1 SerializeField
#   field _useRealtime                   bool                                               off=0x2c attr=1 SerializeField
## OnEnable() -> void
---- Framework.AutoInvokeWithDelay::OnEnable 0x2cc604c
02cc604c: str     d8, [sp, #-0x30]!                          
02cc6050: stp     x30, x21, [sp, #0x10]                      
02cc6054: stp     x20, x19, [sp, #0x20]                      
02cc6058: adrp    x21, #0x662f000                            
02cc605c: adrp    x20, #0x6264000                            
02cc6060: mov     x19, x0                                    
02cc6064: ldrb    w8, [x21, #0xc4f]                          
02cc6068: ldr     x20, [x20, #0xf90]                         T:System.Action
02cc606c: tbnz    w8, #0, #0x2cc609c                         
02cc6070: adrp    x0, #0x6264000                             
02cc6074: ldr     x0, [x0, #0xf90]                           T:System.Action
02cc6078: bl      #0x2b70db0                                 fn_2b70db0
02cc607c: adrp    x0, #0x6267000                             
02cc6080: ldr     x0, [x0, #0x2a8]                           M:Framework.AutoInvokeWithDelay::<OnEnable>b__3_0
02cc6084: bl      #0x2b70db0                                 fn_2b70db0
02cc6088: adrp    x0, #0x6267000                             
02cc608c: ldr     x0, [x0, #0x2b0]                           M:Framework.AutoInvokeWithDelay::<OnEnable>b__3_1
02cc6090: bl      #0x2b70db0                                 fn_2b70db0
02cc6094: mov     w8, #1                                     
02cc6098: strb    w8, [x21, #0xc4f]                          
02cc609c: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cc60a0: ldrb    w21, [x19, #0x2c]                          ._useRealtime
02cc60a4: ldr     s8, [x19, #0x28]                           ._delay
02cc60a8: bl      #0x2b7104c                                 fn_2b7104c
02cc60ac: mov     x20, x0                                    
02cc60b0: cbz     w21, #0x2cc60ec                            
02cc60b4: adrp    x8, #0x6267000                             
02cc60b8: mov     x0, x20                                    
02cc60bc: mov     x1, x19                                    
02cc60c0: ldr     x8, [x8, #0x2a8]                           M:Framework.AutoInvokeWithDelay::<OnEnable>b__3_0
02cc60c4: mov     x3, xzr                                    
02cc60c8: ldr     x2, [x8]                                   S:'didu'
02cc60cc: bl      #0x4d8ddbc                                 System.Action::.ctor
02cc60d0: mov     x0, x19                                    
02cc60d4: mov     x1, x20                                    
02cc60d8: fmov    s0, s8                                     
02cc60dc: ldp     x20, x19, [sp, #0x20]                      
02cc60e0: ldp     x30, x21, [sp, #0x10]                      
02cc60e4: ldr     d8, [sp], #0x30                            
02cc60e8: b       #0x2cb9294                                 Framework.MonoBehaviorExtension::InvokeDelayRealtime
02cc60ec: adrp    x8, #0x6267000                             
02cc60f0: mov     x0, x20                                    
02cc60f4: mov     x1, x19                                    
02cc60f8: ldr     x8, [x8, #0x2b0]                           M:Framework.AutoInvokeWithDelay::<OnEnable>b__3_1
02cc60fc: mov     x3, xzr                                    
02cc6100: ldr     x2, [x8]                                   S:'didu'
02cc6104: bl      #0x4d8ddbc                                 System.Action::.ctor
02cc6108: mov     x0, x19                                    
02cc610c: mov     x1, x20                                    
02cc6110: fmov    s0, s8                                     
02cc6114: ldp     x20, x19, [sp, #0x20]                      
02cc6118: ldp     x30, x21, [sp, #0x10]                      
02cc611c: ldr     d8, [sp], #0x30                            
02cc6120: b       #0x2cb91ec                                 Framework.MonoBehaviorExtension::InvokeDelay
## DestroySelf() -> void
---- Framework.AutoInvokeWithDelay::DestroySelf 0x2cc6124
02cc6124: stp     x30, x21, [sp, #-0x20]!                    
02cc6128: stp     x20, x19, [sp, #0x10]                      
02cc612c: adrp    x21, #0x662f000                            
02cc6130: adrp    x20, #0x6263000                            
02cc6134: mov     x19, x0                                    
02cc6138: ldrb    w8, [x21, #0xc50]                          
02cc613c: ldr     x20, [x20, #0x918]                         T:UnityEngine.Object
02cc6140: tbnz    w8, #0, #0x2cc6158                         
02cc6144: adrp    x0, #0x6263000                             
02cc6148: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02cc614c: bl      #0x2b70db0                                 fn_2b70db0
02cc6150: mov     w8, #1                                     
02cc6154: strb    w8, [x21, #0xc50]                          
02cc6158: mov     x0, x19                                    
02cc615c: mov     x1, xzr                                    
02cc6160: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02cc6164: ldr     x8, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cc6168: mov     x19, x0                                    
02cc616c: ldr     w9, [x8, #0xe4]                            
02cc6170: cbnz    w9, #0x2cc617c                             
02cc6174: mov     x0, x8                                     
02cc6178: bl      #0x2b70f30                                 fn_2b70f30
02cc617c: mov     x0, x19                                    
02cc6180: ldp     x20, x19, [sp, #0x10]                      
02cc6184: mov     x1, xzr                                    
02cc6188: ldp     x30, x21, [sp], #0x20                      
02cc618c: b       #0x5b3ca38                                 UnityEngine.Object::Destroy
## .ctor() -> void
---- Framework.AutoInvokeWithDelay::.ctor 0x2cc6190
02cc6190: mov     x1, xzr                                    
02cc6194: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
## <OnEnable>b__3_0() -> void
---- Framework.AutoInvokeWithDelay::<OnEnable>b__3_0 0x2cc6198
02cc6198: ldr     x0, [x0, #0x20]                            .OnInvoke
02cc619c: cbz     x0, #0x2cc61a8                             
02cc61a0: mov     x1, xzr                                    
02cc61a4: b       #0x5b4d278                                 UnityEngine.Events.UnityEvent::Invoke
02cc61a8: ret                                                
## <OnEnable>b__3_1() -> void
---- Framework.AutoInvokeWithDelay::<OnEnable>b__3_1 0x2cc61ac
02cc61ac: ldr     x0, [x0, #0x20]                            .OnInvoke
02cc61b0: cbz     x0, #0x2cc61bc                             
02cc61b4: mov     x1, xzr                                    
02cc61b8: b       #0x5b4d278                                 UnityEngine.Events.UnityEvent::Invoke
02cc61bc: ret                                                
