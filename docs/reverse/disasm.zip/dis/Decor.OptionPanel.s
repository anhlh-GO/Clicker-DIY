#### CLASS Decor.OptionPanel/<>c__DisplayClass23_0 parent= object
#   field <>4__this                      Decor.OptionPanel                                  off=0x10 attr=6 
#   field optionItem                     Decor.OptionItem                                   off=0x18 attr=6 
## .ctor() -> void
---- Decor.OptionPanel/<>c__DisplayClass23_0::.ctor 0x2d299ac
02d299ac: mov     x1, xzr                                    
02d299b0: b       #0x4e53e9c                                 System.Object::.ctor
## <OnOptionItemBuyClicked>b__0() -> void
---- Decor.OptionPanel/<>c__DisplayClass23_0::<OnOptionItemBuyClicked>b__0 0x2d29b08
02d29b08: ldr     x8, [x0, #0x10]                            .<>4__this
02d29b0c: cbz     x8, #0x2d29b1c                             
02d29b10: ldr     x1, [x0, #0x18]                            .optionItem
02d29b14: mov     x0, x8                                     
02d29b18: b       #0x2d28c78                                 Decor.OptionPanel::UnlockOptionItem
02d29b1c: str     x30, [sp, #-0x10]!                         
02d29b20: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Decor.OptionPanel parent= UnityEngine.MonoBehaviour
#   field OnOptionSelected               UnityEngine.Events.UnityAction`2<int,int>          off=0x0 attr=11 CompilerGeneratedAttribute
#   field _contentParent                 UnityEngine.RectTransform                          off=0x20 attr=1 SerializeField
#   field _scrollRect                    UnityEngine.UI.ScrollRect                          off=0x28 attr=1 SerializeField
#   field _optionItems                   System.Collections.Generic.List`1<Decor.OptionItem> off=0x30 attr=1 SerializeField
#   field _decorPanel                    Decor.DecorPanel                                   off=0x38 attr=1 
#   field _selectedOptionItem            Decor.OptionItem                                   off=0x40 attr=1 
#   field _categoryAsset                 Decor.CategoryAsset                                off=0x48 attr=1 
#   field _dataDecor                     Decor.DataDecor                                    off=0x50 attr=1 
#   field _selectedCategoryIndex         int                                                off=0x58 attr=1 
## add_OnOptionSelected(UnityEngine.Events.UnityAction`2<int,int> value) -> void
---- Decor.OptionPanel::add_OnOptionSelected 0x2d26604
02d26604: str     x30, [sp, #-0x40]!                         
02d26608: stp     x24, x23, [sp, #0x10]                      
02d2660c: stp     x22, x21, [sp, #0x20]                      
02d26610: stp     x20, x19, [sp, #0x30]                      
02d26614: adrp    x20, #0x6630000                            
02d26618: adrp    x23, #0x626a000                            
02d2661c: mov     x19, x0                                    
02d26620: ldrb    w8, [x20, #0x9a]                           
02d26624: ldr     x23, [x23, #0xd8]                          T:Decor.OptionPanel
02d26628: tbnz    w8, #0, #0x2d2664c                         
02d2662c: adrp    x0, #0x626a000                             
02d26630: ldr     x0, [x0, #0xd8]                            T:Decor.OptionPanel
02d26634: bl      #0x2b70db0                                 fn_2b70db0
02d26638: adrp    x0, #0x626a000                             
02d2663c: ldr     x0, [x0, #0xc8]                            T:type19696(k15)
02d26640: bl      #0x2b70db0                                 fn_2b70db0
02d26644: mov     w8, #1                                     
02d26648: strb    w8, [x20, #0x9a]                           
02d2664c: ldr     x8, [x23]                                  T:type56879(k15)
02d26650: adrp    x24, #0x626a000                            
02d26654: ldr     x8, [x8, #0xb8]                            
02d26658: ldr     x24, [x24, #0xc8]                          T:type19696(k15)
02d2665c: ldr     x20, [x8]                                  
02d26660: mov     x0, x20                                    
02d26664: mov     x1, x19                                    
02d26668: mov     x2, xzr                                    
02d2666c: bl      #0x4e570ac                                 System.Delegate::Combine
02d26670: cbz     x0, #0x2d26690                             
02d26674: ldr     x22, [x24]                                 T:type56879(k15)
02d26678: mov     x21, x0                                    
02d2667c: mov     x1, x22                                    
02d26680: bl      #0x2b70f34                                 fn_2b70f34
02d26684: mov     x1, x0                                     
02d26688: cbnz    x0, #0x2d26694                             
02d2668c: b       #0x2d266c4                                 
02d26690: mov     x1, xzr                                    
02d26694: ldr     x8, [x23]                                  T:type56879(k15)
02d26698: mov     x2, x20                                    
02d2669c: ldr     x0, [x8, #0xb8]                            
02d266a0: bl      #0x2ba9880                                 fn_2ba9880
02d266a4: cmp     x0, x20                                    
02d266a8: mov     x20, x0                                    
02d266ac: b.ne    #0x2d26660                                 
02d266b0: ldp     x20, x19, [sp, #0x30]                      
02d266b4: ldp     x22, x21, [sp, #0x20]                      
02d266b8: ldp     x24, x23, [sp, #0x10]                      
02d266bc: ldr     x30, [sp], #0x40                           
02d266c0: ret                                                
02d266c4: mov     x0, x21                                    
02d266c8: mov     x1, x22                                    
02d266cc: bl      #0x2b713dc                                 fn_2b713dc
## remove_OnOptionSelected(UnityEngine.Events.UnityAction`2<int,int> value) -> void
---- Decor.OptionPanel::remove_OnOptionSelected 0x2d2674c
02d2674c: str     x30, [sp, #-0x40]!                         
02d26750: stp     x24, x23, [sp, #0x10]                      
02d26754: stp     x22, x21, [sp, #0x20]                      
02d26758: stp     x20, x19, [sp, #0x30]                      
02d2675c: adrp    x20, #0x6630000                            
02d26760: adrp    x23, #0x626a000                            
02d26764: mov     x19, x0                                    
02d26768: ldrb    w8, [x20, #0x9b]                           
02d2676c: ldr     x23, [x23, #0xd8]                          T:Decor.OptionPanel
02d26770: tbnz    w8, #0, #0x2d26794                         
02d26774: adrp    x0, #0x626a000                             
02d26778: ldr     x0, [x0, #0xd8]                            T:Decor.OptionPanel
02d2677c: bl      #0x2b70db0                                 fn_2b70db0
02d26780: adrp    x0, #0x626a000                             
02d26784: ldr     x0, [x0, #0xc8]                            T:type19696(k15)
02d26788: bl      #0x2b70db0                                 fn_2b70db0
02d2678c: mov     w8, #1                                     
02d26790: strb    w8, [x20, #0x9b]                           
02d26794: ldr     x8, [x23]                                  T:type56879(k15)
02d26798: adrp    x24, #0x626a000                            
02d2679c: ldr     x8, [x8, #0xb8]                            
02d267a0: ldr     x24, [x24, #0xc8]                          T:type19696(k15)
02d267a4: ldr     x20, [x8]                                  
02d267a8: mov     x0, x20                                    
02d267ac: mov     x1, x19                                    
02d267b0: mov     x2, xzr                                    
02d267b4: bl      #0x4e57298                                 System.Delegate::Remove
02d267b8: cbz     x0, #0x2d267d8                             
02d267bc: ldr     x22, [x24]                                 T:type56879(k15)
02d267c0: mov     x21, x0                                    
02d267c4: mov     x1, x22                                    
02d267c8: bl      #0x2b70f34                                 fn_2b70f34
02d267cc: mov     x1, x0                                     
02d267d0: cbnz    x0, #0x2d267dc                             
02d267d4: b       #0x2d2680c                                 
02d267d8: mov     x1, xzr                                    
02d267dc: ldr     x8, [x23]                                  T:type56879(k15)
02d267e0: mov     x2, x20                                    
02d267e4: ldr     x0, [x8, #0xb8]                            
02d267e8: bl      #0x2ba9880                                 fn_2ba9880
02d267ec: cmp     x0, x20                                    
02d267f0: mov     x20, x0                                    
02d267f4: b.ne    #0x2d267a8                                 
02d267f8: ldp     x20, x19, [sp, #0x30]                      
02d267fc: ldp     x22, x21, [sp, #0x20]                      
02d26800: ldp     x24, x23, [sp, #0x10]                      
02d26804: ldr     x30, [sp], #0x40                           
02d26808: ret                                                
02d2680c: mov     x0, x21                                    
02d26810: mov     x1, x22                                    
02d26814: bl      #0x2b713dc                                 fn_2b713dc
## OnInit(Decor.DecorPanel decorPanel) -> void
---- Decor.OptionPanel::OnInit 0x2d27e50
02d27e50: str     x30, [sp, #-0x30]!                         
02d27e54: stp     x22, x21, [sp, #0x10]                      
02d27e58: stp     x20, x19, [sp, #0x20]                      
02d27e5c: adrp    x22, #0x6630000                            
02d27e60: adrp    x21, #0x6266000                            
02d27e64: mov     x20, x1                                    
02d27e68: ldrb    w8, [x22, #0x9c]                           
02d27e6c: ldr     x21, [x21, #0x658]                         MS:MonoSingleton`1::get_Instance
02d27e70: mov     x19, x0                                    
02d27e74: tbnz    w8, #0, #0x2d27e98                         
02d27e78: adrp    x0, #0x6266000                             
02d27e7c: ldr     x0, [x0, #0x878]                           MS:DataManager::GetData
02d27e80: bl      #0x2b70db0                                 fn_2b70db0
02d27e84: adrp    x0, #0x6266000                             
02d27e88: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d27e8c: bl      #0x2b70db0                                 fn_2b70db0
02d27e90: mov     w8, #1                                     
02d27e94: strb    w8, [x22, #0x9c]                           
02d27e98: mov     x0, x19                                    
02d27e9c: mov     x1, x20                                    
02d27ea0: str     x20, [x0, #0x38]!                          ._decorPanel
02d27ea4: bl      #0x2b70d54                                 fn_2b70d54
02d27ea8: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d27eac: bl      #0x3769600                                 fn_3769600
02d27eb0: cbz     x0, #0x2d27ee0                             
02d27eb4: adrp    x8, #0x6266000                             
02d27eb8: ldr     x8, [x8, #0x878]                           MS:DataManager::GetData
02d27ebc: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d27ec0: bl      #0x3168dd0                                 fn_3168dd0
02d27ec4: str     x0, [x19, #0x50]!                          ._dataDecor
02d27ec8: mov     x1, x0                                     
02d27ecc: mov     x0, x19                                    
02d27ed0: ldp     x20, x19, [sp, #0x20]                      
02d27ed4: ldp     x22, x21, [sp, #0x10]                      
02d27ed8: ldr     x30, [sp], #0x30                           
02d27edc: b       #0x2b70d54                                 
02d27ee0: bl      #0x2b7105c                                 fn_2b7105c
## Setup(int categoryIndex) -> Decor.OptionPanel
---- Decor.OptionPanel::Setup 0x2d27864
02d27864: stp     x29, x30, [sp, #-0x60]!                    
02d27868: stp     x28, x27, [sp, #0x10]                      
02d2786c: stp     x26, x25, [sp, #0x20]                      
02d27870: stp     x24, x23, [sp, #0x30]                      
02d27874: stp     x22, x21, [sp, #0x40]                      
02d27878: stp     x20, x19, [sp, #0x50]                      
02d2787c: adrp    x21, #0x6630000                            
02d27880: mov     w20, w1                                    
02d27884: mov     x19, x0                                    
02d27888: ldrb    w8, [x21, #0x9d]                           
02d2788c: tbnz    w8, #0, #0x2d278f8                         
02d27890: adrp    x0, #0x626a000                             
02d27894: ldr     x0, [x0, #0x198]                           T:type6970(k15)
02d27898: bl      #0x2b70db0                                 fn_2b70db0
02d2789c: adrp    x0, #0x6266000                             
02d278a0: ldr     x0, [x0, #0x870]                           MS:DataManager::GetAsset
02d278a4: bl      #0x2b70db0                                 fn_2b70db0
02d278a8: adrp    x0, #0x6266000                             
02d278ac: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d278b0: bl      #0x2b70db0                                 fn_2b70db0
02d278b4: adrp    x0, #0x626a000                             
02d278b8: ldr     x0, [x0, #0x1a0]                           MS:System.Collections.Generic.List`1::get_Count
02d278bc: bl      #0x2b70db0                                 fn_2b70db0
02d278c0: adrp    x0, #0x626a000                             
02d278c4: ldr     x0, [x0, #0x1a8]                           MS:System.Collections.Generic.List`1::get_Item
02d278c8: bl      #0x2b70db0                                 fn_2b70db0
02d278cc: adrp    x0, #0x6266000                             
02d278d0: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d278d4: bl      #0x2b70db0                                 fn_2b70db0
02d278d8: adrp    x0, #0x626a000                             
02d278dc: ldr     x0, [x0, #0x1b0]                           M:Decor.OptionPanel::OnOptionItemBuyClicked
02d278e0: bl      #0x2b70db0                                 fn_2b70db0
02d278e4: adrp    x0, #0x626a000                             
02d278e8: ldr     x0, [x0, #0x1b8]                           M:Decor.OptionPanel::OnOptionItemClicked
02d278ec: bl      #0x2b70db0                                 fn_2b70db0
02d278f0: mov     w8, #1                                     
02d278f4: strb    w8, [x21, #0x9d]                           
02d278f8: adrp    x8, #0x6266000                             
02d278fc: ldr     x8, [x8, #0x658]                           MS:MonoSingleton`1::get_Instance
02d27900: str     w20, [x19, #0x58]                          ._selectedCategoryIndex
02d27904: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d27908: bl      #0x3769600                                 fn_3769600
02d2790c: cbz     x0, #0x2d27b24                             
02d27910: adrp    x8, #0x6266000                             
02d27914: ldr     x8, [x8, #0x870]                           MS:DataManager::GetAsset
02d27918: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d2791c: bl      #0x3168af0                                 fn_3168af0
02d27920: cbz     x0, #0x2d27b24                             
02d27924: mov     w1, w20                                    
02d27928: bl      #0x2d249f4                                 Decor.DecorAsset::GetCategoryAssetByIndex
02d2792c: mov     x20, x19                                   
02d27930: mov     x1, x0                                     
02d27934: str     x0, [x20, #0x48]!                          ._categoryAsset
02d27938: mov     x0, x20                                    
02d2793c: bl      #0x2b70d54                                 fn_2b70d54
02d27940: mov     x0, x19                                    
02d27944: bl      #0x2d28a4c                                 Decor.OptionPanel::AdjustOptionItemSize
02d27948: ldr     x8, [x19, #0x30]                           ._optionItems
02d2794c: cbz     x8, #0x2d27b24                             
02d27950: adrp    x29, #0x626a000                            
02d27954: mov     w21, wzr                                   
02d27958: mov     w28, #1                                    
02d2795c: ldr     x29, [x29, #0x198]                         T:type6970(k15)
02d27960: ldr     w8, [x8, #0x18]                            S:'level_show_popuprate'
02d27964: cmp     w21, w8                                    
02d27968: b.ge    #0x2d27b28                                 
02d2796c: ldr     x0, [x20]                                  
02d27970: cbz     x0, #0x2d27b24                             
02d27974: mov     w1, w21                                    
02d27978: bl      #0x2d2511c                                 Decor.CategoryAsset::GetOptionDataByIndex
02d2797c: cbz     x0, #0x2d27b24                             
02d27980: mov     x23, x0                                    
02d27984: ldr     x0, [x19, #0x50]                           ._dataDecor
02d27988: cbz     x0, #0x2d27b24                             
02d2798c: ldr     w1, [x19, #0x58]                           ._selectedCategoryIndex
02d27990: ldr     w2, [x23, #0x10]                           
02d27994: bl      #0x2d25b24                                 Decor.DataDecor::HasUnlockedItem
02d27998: adrp    x8, #0x6266000                             
02d2799c: mov     w22, w0                                    
02d279a0: ldr     x8, [x8, #0x658]                           MS:MonoSingleton`1::get_Instance
02d279a4: ldr     x8, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d279a8: mov     x0, x8                                     
02d279ac: bl      #0x3769600                                 fn_3769600
02d279b0: cbz     x0, #0x2d27b24                             
02d279b4: adrp    x8, #0x6266000                             
02d279b8: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02d279bc: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d279c0: bl      #0x3168dd0                                 fn_3168dd0
02d279c4: cbz     x0, #0x2d27b24                             
02d279c8: mov     x1, xzr                                    
02d279cc: bl      #0x2cabaf8                                 DataUser::GetMoney
02d279d0: ldr     w8, [x23, #0x24]                           
02d279d4: cmp     w0, w8                                     
02d279d8: cset    w8, lt                                     
02d279dc: orr     w8, w8, w22                                
02d279e0: tbz     w8, #0, #0x2d279ec                         
02d279e4: mov     w24, wzr                                   
02d279e8: b       #0x2d279f8                                 
02d279ec: ldr     w8, [x23, #0x20]                           
02d279f0: cmp     w8, #3                                     
02d279f4: cset    w24, ne                                    
02d279f8: ldr     x0, [x19, #0x30]                           ._optionItems
02d279fc: cbz     x0, #0x2d27b24                             
02d27a00: adrp    x8, #0x626a000                             
02d27a04: mov     w1, w21                                    
02d27a08: ldr     x8, [x8, #0x1a8]                           MS:System.Collections.Generic.List`1::get_Item
02d27a0c: ldr     x2, [x8]                                   T:type56879(k15)
02d27a10: bl      #0x35a8f3c                                 fn_35a8f3c
02d27a14: ldr     x8, [x29]                                  T:type56879(k15)
02d27a18: mov     x25, x0                                    
02d27a1c: mov     x0, x8                                     
02d27a20: bl      #0x2b7104c                                 fn_2b7104c
02d27a24: adrp    x8, #0x626a000                             
02d27a28: mov     x1, x19                                    
02d27a2c: mov     x3, xzr                                    
02d27a30: ldr     x8, [x8, #0x1b8]                           M:Decor.OptionPanel::OnOptionItemClicked
02d27a34: mov     x26, x0                                    
02d27a38: ldr     x2, [x8]                                   T:type56879(k15)
02d27a3c: bl      #0x453418c                                 fn_453418c
02d27a40: ldr     x0, [x29]                                  T:type56879(k15)
02d27a44: bl      #0x2b7104c                                 fn_2b7104c
02d27a48: adrp    x8, #0x626a000                             
02d27a4c: mov     x1, x19                                    
02d27a50: mov     x3, xzr                                    
02d27a54: ldr     x8, [x8, #0x1b0]                           M:Decor.OptionPanel::OnOptionItemBuyClicked
02d27a58: mov     x27, x0                                    
02d27a5c: ldr     x2, [x8]                                   T:type56879(k15)
02d27a60: bl      #0x453418c                                 fn_453418c
02d27a64: cbz     x25, #0x2d27b24                            
02d27a68: mov     x0, x25                                    
02d27a6c: mov     x1, x26                                    
02d27a70: mov     x2, x27                                    
02d27a74: bl      #0x2d282b4                                 Decor.OptionItem::OnInit
02d27a78: ldr     x0, [x25, #0x30]                           
02d27a7c: cbz     x0, #0x2d27b24                             
02d27a80: ldr     x1, [x23, #0x18]                           
02d27a84: mov     x2, xzr                                    
02d27a88: bl      #0x5c45aa0                                 UnityEngine.UI.Image::set_sprite
02d27a8c: ldr     w8, [x23, #0x10]                           
02d27a90: ldr     w1, [x23, #0x24]                           
02d27a94: mov     x0, x25                                    
02d27a98: str     w8, [x25, #0x28]                           
02d27a9c: bl      #0x2d286a8                                 Decor.OptionItem::SetPrice
02d27aa0: ldr     w1, [x23, #0x24]                           
02d27aa4: bl      #0x2d286f8                                 Decor.OptionItem::SetDay
02d27aa8: ldr     w1, [x23, #0x20]                           
02d27aac: bl      #0x2d28540                                 Decor.OptionItem::SetUnlockType
02d27ab0: orr     w8, w22, w24                               
02d27ab4: tbz     w8, #0, #0x2d27ac0                         
02d27ab8: mov     w1, #1                                     
02d27abc: b       #0x2d27acc                                 
02d27ac0: ldr     w8, [x23, #0x20]                           
02d27ac4: cmp     w8, #1                                     
02d27ac8: cset    w1, eq                                     
02d27acc: ldr     x0, [x25, #0x38]                           
02d27ad0: cbz     x0, #0x2d27b24                             
02d27ad4: mov     x2, xzr                                    
02d27ad8: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d27adc: and     w1, w22, #1                                
02d27ae0: mov     x0, x25                                    
02d27ae4: bl      #0x2d287d8                                 Decor.OptionItem::SetActiveStatus
02d27ae8: bic     w1, w28, w22                               
02d27aec: bl      #0x2d28874                                 Decor.OptionItem::SetActiveBuyButton
02d27af0: ldr     x0, [x25, #0x40]                           
02d27af4: cbz     x0, #0x2d27b24                             
02d27af8: mov     w1, #1                                     
02d27afc: mov     x2, xzr                                    
02d27b00: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d27b04: ldr     x0, [x25, #0x70]                           
02d27b08: cbz     x0, #0x2d27b24                             
02d27b0c: mov     w1, w24                                    
02d27b10: mov     x2, xzr                                    
02d27b14: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d27b18: ldr     x8, [x19, #0x30]                           ._optionItems
02d27b1c: add     w21, w21, #1                               
02d27b20: cbnz    x8, #0x2d27960                             
02d27b24: bl      #0x2b7105c                                 fn_2b7105c
02d27b28: mov     x0, x19                                    
02d27b2c: ldp     x20, x19, [sp, #0x50]                      
02d27b30: ldp     x22, x21, [sp, #0x40]                      
02d27b34: ldp     x24, x23, [sp, #0x30]                      
02d27b38: ldp     x26, x25, [sp, #0x20]                      
02d27b3c: ldp     x28, x27, [sp, #0x10]                      
02d27b40: ldp     x29, x30, [sp], #0x60                      
02d27b44: ret                                                
## SelectedOptionItemByIndex(int optionIndex) -> void
---- Decor.OptionPanel::SelectedOptionItemByIndex 0x2d27b48
02d27b48: stp     x30, x21, [sp, #-0x20]!                    
02d27b4c: stp     x20, x19, [sp, #0x10]                      
02d27b50: adrp    x21, #0x6630000                            
02d27b54: mov     w20, w1                                    
02d27b58: mov     x19, x0                                    
02d27b5c: ldrb    w8, [x21, #0x9e]                           
02d27b60: tbnz    w8, #0, #0x2d27b84                         
02d27b64: adrp    x0, #0x626a000                             
02d27b68: ldr     x0, [x0, #0x1a0]                           MS:System.Collections.Generic.List`1::get_Count
02d27b6c: bl      #0x2b70db0                                 fn_2b70db0
02d27b70: adrp    x0, #0x626a000                             
02d27b74: ldr     x0, [x0, #0x1a8]                           MS:System.Collections.Generic.List`1::get_Item
02d27b78: bl      #0x2b70db0                                 fn_2b70db0
02d27b7c: mov     w8, #1                                     
02d27b80: strb    w8, [x21, #0x9e]                           
02d27b84: tbnz    w20, #0x1f, #0x2d27bc4                     
02d27b88: ldr     x0, [x19, #0x30]                           ._optionItems
02d27b8c: cbz     x0, #0x2d27bd0                             
02d27b90: ldr     w8, [x0, #0x18]                            MS:System.Collections.Generic.List`1::Add
02d27b94: cmp     w8, w20                                    
02d27b98: b.le    #0x2d27bc4                                 
02d27b9c: adrp    x8, #0x626a000                             
02d27ba0: mov     w1, w20                                    
02d27ba4: ldr     x8, [x8, #0x1a8]                           MS:System.Collections.Generic.List`1::get_Item
02d27ba8: ldr     x2, [x8]                                   T:type56879(k15)
02d27bac: bl      #0x35a8f3c                                 fn_35a8f3c
02d27bb0: mov     x1, x0                                     
02d27bb4: mov     x0, x19                                    
02d27bb8: ldp     x20, x19, [sp, #0x10]                      
02d27bbc: ldp     x30, x21, [sp], #0x20                      
02d27bc0: b       #0x2d28b5c                                 Decor.OptionPanel::SelectedOptionItem
02d27bc4: ldp     x20, x19, [sp, #0x10]                      
02d27bc8: ldp     x30, x21, [sp], #0x20                      
02d27bcc: ret                                                
02d27bd0: bl      #0x2b7105c                                 fn_2b7105c
## UnlockOptionItem(Decor.OptionItem optionItem) -> void
---- Decor.OptionPanel::UnlockOptionItem 0x2d28c78
02d28c78: stp     x30, x21, [sp, #-0x20]!                    
02d28c7c: stp     x20, x19, [sp, #0x10]                      
02d28c80: adrp    x21, #0x6630000                            
02d28c84: mov     x20, x1                                    
02d28c88: mov     x19, x0                                    
02d28c8c: ldrb    w8, [x21, #0x9f]                           
02d28c90: tbnz    w8, #0, #0x2d28cfc                         
02d28c94: adrp    x0, #0x6266000                             
02d28c98: ldr     x0, [x0, #0x870]                           MS:DataManager::GetAsset
02d28c9c: bl      #0x2b70db0                                 fn_2b70db0
02d28ca0: adrp    x0, #0x6263000                             
02d28ca4: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02d28ca8: bl      #0x2b70db0                                 fn_2b70db0
02d28cac: adrp    x0, #0x6266000                             
02d28cb0: ldr     x0, [x0, #0x5e0]                           T:GameConfig
02d28cb4: bl      #0x2b70db0                                 fn_2b70db0
02d28cb8: adrp    x0, #0x6267000                             
02d28cbc: ldr     x0, [x0, #0xbb0]                           MS:MonoSingleton`1::get_Instance
02d28cc0: bl      #0x2b70db0                                 fn_2b70db0
02d28cc4: adrp    x0, #0x6266000                             
02d28cc8: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d28ccc: bl      #0x2b70db0                                 fn_2b70db0
02d28cd0: adrp    x0, #0x6263000                             
02d28cd4: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d28cd8: bl      #0x2b70db0                                 fn_2b70db0
02d28cdc: adrp    x0, #0x6266000                             
02d28ce0: ldr     x0, [x0, #0x888]                           S:'CharacterChanger'
02d28ce4: bl      #0x2b70db0                                 fn_2b70db0
02d28ce8: adrp    x0, #0x626a000                             
02d28cec: ldr     x0, [x0, #0x218]                           S:'=====dev log Decor.OptionPanel.UnlockOptionItem(), optionItem is null,'
02d28cf0: bl      #0x2b70db0                                 fn_2b70db0
02d28cf4: mov     w8, #1                                     
02d28cf8: strb    w8, [x21, #0x9f]                           
02d28cfc: cbz     x20, #0x2d28ee8                            
02d28d00: ldr     x0, [x19, #0x48]                           ._categoryAsset
02d28d04: cbz     x0, #0x2d28ee8                             
02d28d08: ldr     w1, [x20, #0x28]                           ._scrollRect
02d28d0c: bl      #0x2d24a4c                                 Decor.CategoryAsset::GetOptionDataByID
02d28d10: ldr     x0, [x19, #0x50]                           ._dataDecor
02d28d14: cbz     x0, #0x2d28ee8                             
02d28d18: ldr     w2, [x20, #0x28]                           ._scrollRect
02d28d1c: ldr     w1, [x19, #0x58]                           ._selectedCategoryIndex
02d28d20: bl      #0x2d259d8                                 Decor.DataDecor::UnlockItem
02d28d24: ldr     x0, [x20, #0x38]                           ._decorPanel
02d28d28: cbz     x0, #0x2d28ee8                             
02d28d2c: mov     w1, #1                                     
02d28d30: mov     x2, xzr                                    
02d28d34: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d28d38: mov     x0, x20                                    
02d28d3c: mov     w1, #1                                     
02d28d40: bl      #0x2d287d8                                 Decor.OptionItem::SetActiveStatus
02d28d44: mov     w1, wzr                                    
02d28d48: bl      #0x2d28874                                 Decor.OptionItem::SetActiveBuyButton
02d28d4c: ldr     x0, [x20, #0x70]                           
02d28d50: cbz     x0, #0x2d28ee8                             
02d28d54: adrp    x21, #0x6263000                            
02d28d58: mov     w1, wzr                                    
02d28d5c: mov     x2, xzr                                    
02d28d60: ldr     x21, [x21, #0x918]                         T:UnityEngine.Object
02d28d64: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d28d68: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d28d6c: ldr     w8, [x0, #0xe4]                            [626a0e4]=0 f=0,0
02d28d70: cbnz    w8, #0x2d28d78                             
02d28d74: bl      #0x2b70f30                                 fn_2b70f30
02d28d78: mov     x0, x20                                    
02d28d7c: mov     x1, xzr                                    
02d28d80: mov     x2, xzr                                    
02d28d84: bl      #0x5b37d84                                 UnityEngine.Object::op_Equality
02d28d88: tbz     w0, #0, #0x2d28dc0                         
02d28d8c: adrp    x8, #0x6263000                             
02d28d90: ldr     x8, [x8, #0x928]                           T:UnityEngine.Debug
02d28d94: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02d28d98: ldr     w8, [x0, #0xe4]                            [626a0e4]=0 f=0,0
02d28d9c: cbnz    w8, #0x2d28da4                             
02d28da0: bl      #0x2b70f30                                 fn_2b70f30
02d28da4: adrp    x8, #0x626a000                             
02d28da8: mov     x1, xzr                                    
02d28dac: ldr     x8, [x8, #0x218]                           S:'=====dev log Decor.OptionPanel.UnlockOptionItem(), optionItem is null,'
02d28db0: ldp     x20, x19, [sp, #0x10]                      
02d28db4: ldr     x0, [x8]                                   T:type56879(k15)
02d28db8: ldp     x30, x21, [sp], #0x20                      
02d28dbc: b       #0x5af2840                                 UnityEngine.Debug::LogError
02d28dc0: mov     x0, x19                                    
02d28dc4: mov     x1, x20                                    
02d28dc8: bl      #0x2d28b5c                                 Decor.OptionPanel::SelectedOptionItem
02d28dcc: ldr     x8, [x19, #0x38]                           ._decorPanel
02d28dd0: cbz     x8, #0x2d28ee8                             
02d28dd4: ldr     x0, [x8, #0x40]                            MS:System.Collections.Generic.List`1::IndexOf
02d28dd8: cbz     x0, #0x2d28ee8                             
02d28ddc: bl      #0x2d27568                                 Decor.CategoryPanel::Refresh
02d28de0: adrp    x8, #0x6266000                             
02d28de4: ldr     x8, [x8, #0x658]                           MS:MonoSingleton`1::get_Instance
02d28de8: ldr     x19, [x19, #0x48]                          ._categoryAsset
02d28dec: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d28df0: bl      #0x3769600                                 fn_3769600
02d28df4: cbz     x0, #0x2d28ee8                             
02d28df8: adrp    x8, #0x6266000                             
02d28dfc: ldr     x8, [x8, #0x870]                           MS:DataManager::GetAsset
02d28e00: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d28e04: bl      #0x3168af0                                 fn_3168af0
02d28e08: cbz     x0, #0x2d28ee8                             
02d28e0c: adrp    x8, #0x6266000                             
02d28e10: ldr     x8, [x8, #0x888]                           S:'CharacterChanger'
02d28e14: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d28e18: bl      #0x2d25ed4                                 Decor.DecorAsset::GetCategoryAssetByName
02d28e1c: ldr     x8, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d28e20: mov     x20, x0                                    
02d28e24: ldr     w9, [x8, #0xe4]                            [62660e4]=0 f=0,0
02d28e28: cbnz    w9, #0x2d28e34                             
02d28e2c: mov     x0, x8                                     
02d28e30: bl      #0x2b70f30                                 fn_2b70f30
02d28e34: mov     x0, x19                                    
02d28e38: mov     x1, x20                                    
02d28e3c: mov     x2, xzr                                    
02d28e40: bl      #0x5b37d84                                 UnityEngine.Object::op_Equality
02d28e44: tbz     w0, #0, #0x2d28e94                         
02d28e48: adrp    x8, #0x6267000                             
02d28e4c: ldr     x8, [x8, #0xbb0]                           MS:MonoSingleton`1::get_Instance
02d28e50: ldr     x0, [x8]                                   S:'didu'
02d28e54: bl      #0x3769600                                 fn_3769600
02d28e58: adrp    x20, #0x6266000                            
02d28e5c: mov     x19, x0                                    
02d28e60: ldr     x20, [x20, #0x5e0]                         T:GameConfig
02d28e64: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d28e68: ldr     w9, [x8, #0xe4]                            [62670e4]=0 f=0,0
02d28e6c: cbnz    w9, #0x2d28e78                             
02d28e70: mov     x0, x8                                     
02d28e74: bl      #0x2b70f30                                 fn_2b70f30
02d28e78: cbz     x19, #0x2d28ee8                            
02d28e7c: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d28e80: mov     x0, x19                                    
02d28e84: mov     w2, #1                                     
02d28e88: ldr     x8, [x8, #0xb8]                            M:Framework.SceneUtils/<CRUnloadSceneAsync>d__2::System.Collections.IEnumerator.Reset
02d28e8c: ldr     w1, [x8, #0xa0]                            M:Framework.SceneUtils/<CRLoadSceneAsync>d__0::System.Collections.IEnumerator.Reset
02d28e90: bl      #0x2d28eec                                 DailyTask.DailyTaskController::ProgressTask
02d28e94: adrp    x8, #0x6267000                             
02d28e98: ldr     x8, [x8, #0xbb0]                           MS:MonoSingleton`1::get_Instance
02d28e9c: ldr     x0, [x8]                                   S:'didu'
02d28ea0: bl      #0x3769600                                 fn_3769600
02d28ea4: adrp    x20, #0x6266000                            
02d28ea8: mov     x19, x0                                    
02d28eac: ldr     x20, [x20, #0x5e0]                         T:GameConfig
02d28eb0: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d28eb4: ldr     w9, [x8, #0xe4]                            [62670e4]=0 f=0,0
02d28eb8: cbnz    w9, #0x2d28ec4                             
02d28ebc: mov     x0, x8                                     
02d28ec0: bl      #0x2b70f30                                 fn_2b70f30
02d28ec4: cbz     x19, #0x2d28ee8                            
02d28ec8: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d28ecc: mov     x0, x19                                    
02d28ed0: mov     w2, #1                                     
02d28ed4: ldp     x20, x19, [sp, #0x10]                      
02d28ed8: ldr     x8, [x8, #0xb8]                            M:Framework.SceneUtils/<CRUnloadSceneAsync>d__2::System.Collections.IEnumerator.Reset
02d28edc: ldr     w1, [x8, #0xb0]                            M:Framework.SceneUtils/<CRLoadSceneAsync>d__1::System.Collections.IEnumerator.Reset
02d28ee0: ldp     x30, x21, [sp], #0x20                      
02d28ee4: b       #0x2d28eec                                 DailyTask.DailyTaskController::ProgressTask
02d28ee8: bl      #0x2b7105c                                 fn_2b7105c
## OnEnable() -> void
---- Decor.OptionPanel::OnEnable 0x2d290f8
02d290f8: str     x30, [sp, #-0x30]!                         
02d290fc: stp     x22, x21, [sp, #0x10]                      
02d29100: stp     x20, x19, [sp, #0x20]                      
02d29104: adrp    x21, #0x6630000                            
02d29108: adrp    x22, #0x6265000                            
02d2910c: adrp    x20, #0x626a000                            
02d29110: ldrb    w8, [x21, #0xa0]                           
02d29114: ldr     x22, [x22, #0x3f0]                         T:UnityEngine.Events.UnityAction
02d29118: ldr     x20, [x20, #0x248]                         M:Decor.OptionPanel::Refresh
02d2911c: mov     x19, x0                                    
02d29120: tbnz    w8, #0, #0x2d29144                         
02d29124: adrp    x0, #0x626a000                             
02d29128: ldr     x0, [x0, #0x248]                           M:Decor.OptionPanel::Refresh
02d2912c: bl      #0x2b70db0                                 fn_2b70db0
02d29130: adrp    x0, #0x6265000                             
02d29134: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d29138: bl      #0x2b70db0                                 fn_2b70db0
02d2913c: mov     w8, #1                                     
02d29140: strb    w8, [x21, #0xa0]                           
02d29144: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d29148: bl      #0x2b7104c                                 fn_2b7104c
02d2914c: ldr     x2, [x20]                                  T:type56879(k15)
02d29150: mov     x1, x19                                    
02d29154: mov     x3, xzr                                    
02d29158: mov     x20, x0                                    
02d2915c: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d29160: mov     x0, x20                                    
02d29164: ldp     x20, x19, [sp, #0x20]                      
02d29168: ldp     x22, x21, [sp, #0x10]                      
02d2916c: mov     x1, xzr                                    
02d29170: ldr     x30, [sp], #0x30                           
02d29174: b       #0x2cda8a8                                 MoneyManager::add_OnMoneyChanged
## OnDisable() -> void
---- Decor.OptionPanel::OnDisable 0x2d29178
02d29178: str     x30, [sp, #-0x30]!                         
02d2917c: stp     x22, x21, [sp, #0x10]                      
02d29180: stp     x20, x19, [sp, #0x20]                      
02d29184: adrp    x21, #0x6630000                            
02d29188: adrp    x22, #0x6265000                            
02d2918c: adrp    x20, #0x626a000                            
02d29190: ldrb    w8, [x21, #0xa1]                           
02d29194: ldr     x22, [x22, #0x3f0]                         T:UnityEngine.Events.UnityAction
02d29198: ldr     x20, [x20, #0x248]                         M:Decor.OptionPanel::Refresh
02d2919c: mov     x19, x0                                    
02d291a0: tbnz    w8, #0, #0x2d291c4                         
02d291a4: adrp    x0, #0x626a000                             
02d291a8: ldr     x0, [x0, #0x248]                           M:Decor.OptionPanel::Refresh
02d291ac: bl      #0x2b70db0                                 fn_2b70db0
02d291b0: adrp    x0, #0x6265000                             
02d291b4: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d291b8: bl      #0x2b70db0                                 fn_2b70db0
02d291bc: mov     w8, #1                                     
02d291c0: strb    w8, [x21, #0xa1]                           
02d291c4: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d291c8: bl      #0x2b7104c                                 fn_2b7104c
02d291cc: ldr     x2, [x20]                                  T:type56879(k15)
02d291d0: mov     x1, x19                                    
02d291d4: mov     x3, xzr                                    
02d291d8: mov     x20, x0                                    
02d291dc: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d291e0: mov     x0, x20                                    
02d291e4: ldp     x20, x19, [sp, #0x20]                      
02d291e8: ldp     x22, x21, [sp, #0x10]                      
02d291ec: mov     x1, xzr                                    
02d291f0: ldr     x30, [sp], #0x30                           
02d291f4: b       #0x2cda960                                 MoneyManager::remove_OnMoneyChanged
## UpdateDefaultOption() -> void
---- Decor.OptionPanel::UpdateDefaultOption 0x2d28b58
02d28b58: ret                                                
## SelectedOptionItem(Decor.OptionItem optionItem) -> void
---- Decor.OptionPanel::SelectedOptionItem 0x2d28b5c
02d28b5c: str     x30, [sp, #-0x30]!                         
02d28b60: stp     x22, x21, [sp, #0x10]                      
02d28b64: stp     x20, x19, [sp, #0x20]                      
02d28b68: adrp    x22, #0x6630000                            
02d28b6c: adrp    x21, #0x6263000                            
02d28b70: mov     x19, x1                                    
02d28b74: ldrb    w8, [x22, #0xa2]                           
02d28b78: ldr     x21, [x21, #0x918]                         T:UnityEngine.Object
02d28b7c: mov     x20, x0                                    
02d28b80: tbnz    w8, #0, #0x2d28ba4                         
02d28b84: adrp    x0, #0x6263000                             
02d28b88: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d28b8c: bl      #0x2b70db0                                 fn_2b70db0
02d28b90: adrp    x0, #0x626a000                             
02d28b94: ldr     x0, [x0, #0xd8]                            T:Decor.OptionPanel
02d28b98: bl      #0x2b70db0                                 fn_2b70db0
02d28b9c: mov     w8, #1                                     
02d28ba0: strb    w8, [x22, #0xa2]                           
02d28ba4: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d28ba8: mov     x21, x20                                   
02d28bac: ldr     x22, [x21, #0x40]!                         [6263040]=0 f=0,0 ._selectedOptionItem
02d28bb0: ldr     w8, [x0, #0xe4]                            [626a0e4]=0 f=0,0
02d28bb4: cbnz    w8, #0x2d28bbc                             
02d28bb8: bl      #0x2b70f30                                 fn_2b70f30
02d28bbc: mov     x0, x22                                    
02d28bc0: mov     x1, xzr                                    
02d28bc4: mov     x2, xzr                                    
02d28bc8: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d28bcc: tbz     w0, #0, #0x2d28bf0                         
02d28bd0: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d28bd4: cbz     x0, #0x2d28c74                             
02d28bd8: mov     w1, wzr                                    
02d28bdc: bl      #0x2d28444                                 Decor.OptionItem::SetSelected
02d28be0: mov     x0, x21                                    
02d28be4: mov     x1, xzr                                    
02d28be8: str     xzr, [x21]                                 
02d28bec: bl      #0x2b70d54                                 fn_2b70d54
02d28bf0: mov     x0, x21                                    
02d28bf4: mov     x1, x19                                    
02d28bf8: str     x19, [x21]                                 
02d28bfc: bl      #0x2b70d54                                 fn_2b70d54
02d28c00: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d28c04: cbz     x0, #0x2d28c74                             
02d28c08: mov     w1, #1                                     
02d28c0c: bl      #0x2d28444                                 Decor.OptionItem::SetSelected
02d28c10: cbz     x19, #0x2d28c74                            
02d28c14: ldr     x0, [x20, #0x50]                           ._dataDecor
02d28c18: cbz     x0, #0x2d28c74                             
02d28c1c: adrp    x21, #0x626a000                            
02d28c20: ldr     x21, [x21, #0xd8]                          T:Decor.OptionPanel
02d28c24: ldr     w1, [x20, #0x58]                           ._selectedCategoryIndex
02d28c28: ldr     w2, [x19, #0x28]                           ._scrollRect
02d28c2c: bl      #0x2d25bbc                                 Decor.DataDecor::SetSelectedItem
02d28c30: ldr     x8, [x21]                                  T:type56879(k15)
02d28c34: ldr     x8, [x8, #0xb8]                            
02d28c38: ldr     x8, [x8]                                   
02d28c3c: cbz     x8, #0x2d28c64                             
02d28c40: ldr     w2, [x19, #0x28]                           ._scrollRect
02d28c44: ldr     w1, [x20, #0x58]                           ._selectedCategoryIndex
02d28c48: ldr     x0, [x8, #0x40]                            
02d28c4c: ldp     x20, x19, [sp, #0x20]                      
02d28c50: ldr     x3, [x8, #0x28]                            
02d28c54: ldr     x4, [x8, #0x18]                            
02d28c58: ldp     x22, x21, [sp, #0x10]                      
02d28c5c: ldr     x30, [sp], #0x30                           
02d28c60: br      x4                                         
02d28c64: ldp     x20, x19, [sp, #0x20]                      
02d28c68: ldp     x22, x21, [sp, #0x10]                      
02d28c6c: ldr     x30, [sp], #0x30                           
02d28c70: ret                                                
02d28c74: bl      #0x2b7105c                                 fn_2b7105c
## Refresh() -> void
---- Decor.OptionPanel::Refresh 0x2d291f8
02d291f8: sub     sp, sp, #0x90                              
02d291fc: str     x30, [sp, #0x40]                           
02d29200: stp     x26, x25, [sp, #0x50]                      
02d29204: stp     x24, x23, [sp, #0x60]                      
02d29208: stp     x22, x21, [sp, #0x70]                      
02d2920c: stp     x20, x19, [sp, #0x80]                      
02d29210: adrp    x20, #0x6630000                            
02d29214: adrp    x22, #0x626a000                            
02d29218: adrp    x21, #0x626a000                            
02d2921c: ldrb    w8, [x20, #0xa3]                           
02d29220: ldr     x22, [x22, #0x250]                         T:type57266(k15)
02d29224: ldr     x21, [x21, #0x258]                         M:Decor.OptionPanel::<Refresh>b__19_0
02d29228: mov     x19, x0                                    
02d2922c: tbnz    w8, #0, #0x2d292a4                         
02d29230: adrp    x0, #0x6266000                             
02d29234: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d29238: bl      #0x2b70db0                                 fn_2b70db0
02d2923c: adrp    x0, #0x626a000                             
02d29240: ldr     x0, [x0, #0x260]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d29244: bl      #0x2b70db0                                 fn_2b70db0
02d29248: adrp    x0, #0x626a000                             
02d2924c: ldr     x0, [x0, #0x268]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d29250: bl      #0x2b70db0                                 fn_2b70db0
02d29254: adrp    x0, #0x626a000                             
02d29258: ldr     x0, [x0, #0x270]                           MS:System.Collections.Generic.List`1/Enumerator::get_Current
02d2925c: bl      #0x2b70db0                                 fn_2b70db0
02d29260: adrp    x0, #0x626a000                             
02d29264: ldr     x0, [x0, #0x278]                           MS:System.Collections.Generic.List`1::FindAll
02d29268: bl      #0x2b70db0                                 fn_2b70db0
02d2926c: adrp    x0, #0x626a000                             
02d29270: ldr     x0, [x0, #0x280]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d29274: bl      #0x2b70db0                                 fn_2b70db0
02d29278: adrp    x0, #0x6266000                             
02d2927c: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d29280: bl      #0x2b70db0                                 fn_2b70db0
02d29284: adrp    x0, #0x626a000                             
02d29288: ldr     x0, [x0, #0x258]                           M:Decor.OptionPanel::<Refresh>b__19_0
02d2928c: bl      #0x2b70db0                                 fn_2b70db0
02d29290: adrp    x0, #0x626a000                             
02d29294: ldr     x0, [x0, #0x250]                           T:type57266(k15)
02d29298: bl      #0x2b70db0                                 fn_2b70db0
02d2929c: mov     w8, #1                                     
02d292a0: strb    w8, [x20, #0xa3]                           
02d292a4: ldr     x0, [x22]                                  T:type56879(k15)
02d292a8: ldr     x20, [x19, #0x30]                          ._optionItems
02d292ac: stp     xzr, xzr, [sp, #0x20]                      
02d292b0: str     xzr, [sp, #0x30]                           
02d292b4: bl      #0x2b7104c                                 fn_2b7104c
02d292b8: ldr     x2, [x21]                                  T:type56879(k15)
02d292bc: mov     x1, x19                                    
02d292c0: mov     x3, xzr                                    
02d292c4: mov     x21, x0                                    
02d292c8: bl      #0x399ba10                                 fn_399ba10
02d292cc: cbz     x20, #0x2d29408                            
02d292d0: adrp    x8, #0x626a000                             
02d292d4: mov     x0, x20                                    
02d292d8: mov     x1, x21                                    
02d292dc: ldr     x8, [x8, #0x278]                           MS:System.Collections.Generic.List`1::FindAll
02d292e0: ldr     x2, [x8]                                   T:type56879(k15)
02d292e4: bl      #0x35a9914                                 fn_35a9914
02d292e8: cbz     x0, #0x2d29408                             
02d292ec: adrp    x8, #0x626a000                             
02d292f0: adrp    x23, #0x626a000                            
02d292f4: adrp    x24, #0x6266000                            
02d292f8: ldr     x8, [x8, #0x280]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d292fc: adrp    x25, #0x6266000                            
02d29300: adrp    x22, #0x626a000                            
02d29304: ldr     x23, [x23, #0x268]                         MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d29308: ldr     x24, [x24, #0x658]                         MS:MonoSingleton`1::get_Instance
02d2930c: ldr     x25, [x25, #0x750]                         MS:DataManager::GetData
02d29310: ldr     x22, [x22, #0x260]                         MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d29314: ldr     x1, [x8]                                   T:type56879(k15)
02d29318: add     x8, sp, #8                                 
02d2931c: bl      #0x35a9d9c                                 fn_35a9d9c
02d29320: ldr     x8, [sp, #0x18]                            
02d29324: ldur    q0, [sp, #8]                               
02d29328: str     x8, [sp, #0x30]                            
02d2932c: add     x8, sp, #0x20                              
02d29330: str     q0, [sp, #0x20]                            
02d29334: stp     xzr, x8, [sp, #8]                          
02d29338: ldr     x1, [x23]                                  T:type56879(k15)
02d2933c: add     x0, sp, #0x20                              
02d29340: bl      #0x4690474                                 fn_4690474
02d29344: tbz     w0, #0, #0x2d293c4                         
02d29348: ldr     x26, [sp, #0x30]                           
02d2934c: cbz     x26, #0x2d293f8                            
02d29350: ldr     x0, [x19, #0x48]                           ._categoryAsset
02d29354: cbz     x0, #0x2d293fc                             
02d29358: ldr     w1, [x26, #0x28]                           
02d2935c: bl      #0x2d24a4c                                 Decor.CategoryAsset::GetOptionDataByID
02d29360: mov     x20, x0                                    
02d29364: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d29368: bl      #0x3769600                                 fn_3769600
02d2936c: cbz     x0, #0x2d293f0                             
02d29370: ldr     x1, [x25]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d29374: bl      #0x3168dd0                                 fn_3168dd0
02d29378: cbz     x0, #0x2d293f4                             
02d2937c: mov     x1, xzr                                    
02d29380: bl      #0x2cabaf8                                 DataUser::GetMoney
02d29384: cbz     x20, #0x2d293ec                            
02d29388: mov     w21, w0                                    
02d2938c: ldr     x0, [x26, #0x70]                           
02d29390: cbz     x0, #0x2d29400                             
02d29394: ldr     w20, [x20, #0x24]                          
02d29398: cmp     w21, w20                                   
02d2939c: cset    w1, ge                                     
02d293a0: mov     x2, xzr                                    
02d293a4: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d293a8: ldr     x0, [x26, #0x38]                           
02d293ac: cbz     x0, #0x2d29404                             
02d293b0: cmp     w21, w20                                   
02d293b4: cset    w1, ge                                     
02d293b8: mov     x2, xzr                                    
02d293bc: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d293c0: b       #0x2d29338                                 
02d293c4: ldr     x1, [x22]                                  T:type56879(k15)
02d293c8: add     x0, sp, #0x20                              
02d293cc: bl      #0x4690470                                 fn_4690470
02d293d0: ldp     x20, x19, [sp, #0x80]                      
02d293d4: ldr     x30, [sp, #0x40]                           
02d293d8: ldp     x22, x21, [sp, #0x70]                      
02d293dc: ldp     x24, x23, [sp, #0x60]                      
02d293e0: ldp     x26, x25, [sp, #0x50]                      
02d293e4: add     sp, sp, #0x90                              
02d293e8: ret                                                
02d293ec: bl      #0x2b7105c                                 fn_2b7105c
02d293f0: bl      #0x2b7105c                                 fn_2b7105c
02d293f4: bl      #0x2b7105c                                 fn_2b7105c
02d293f8: bl      #0x2b7105c                                 fn_2b7105c
02d293fc: bl      #0x2b7105c                                 fn_2b7105c
02d29400: bl      #0x2b7105c                                 fn_2b7105c
02d29404: bl      #0x2b7105c                                 fn_2b7105c
02d29408: bl      #0x2b7105c                                 fn_2b7105c
02d2940c: b       #0x2d29440                                 
02d29410: b       #0x2d29440                                 
02d29414: b       #0x2d29440                                 
02d29418: b       #0x2d29440                                 
02d2941c: b       #0x2d29440                                 
02d29420: b       #0x2d29440                                 
02d29424: b       #0x2d29440                                 
02d29428: b       #0x2d29440                                 
02d2942c: b       #0x2d29440                                 
02d29430: b       #0x2d29440                                 
02d29434: b       #0x2d29440                                 
02d29438: b       #0x2d29440                                 
02d2943c: b       #0x2d29440                                 
02d29440: mov     x19, x0                                    
02d29444: cmp     w1, #1                                     
02d29448: b.ne    #0x2d2947c                                 
02d2944c: mov     x0, x19                                    
02d29450: bl      #0x5e90260                                 fn_5e90260
02d29454: ldr     x19, [x0]                                  T:type56879(k15)
02d29458: str     x19, [sp, #8]                              
02d2945c: bl      #0x5e90270                                 fn_5e90270
02d29460: ldr     x0, [sp, #0x10]                            
02d29464: ldr     x1, [x22]                                  T:type56879(k15)
02d29468: bl      #0x4690470                                 fn_4690470
02d2946c: cbz     x19, #0x2d293d0                            
02d29470: mov     x0, x19                                    
02d29474: bl      #0x2b71054                                 fn_2b71054
02d29478: mov     x19, x0                                    
02d2947c: add     x0, sp, #8                                 
02d29480: bl      #0x2738138                                 fn_2738138
02d29484: mov     x0, x19                                    
02d29488: bl      #0x2c6051c                                 fn_2c6051c
02d2948c: bl      #0x27369b8                                 fn_27369b8
## AdjustOptionItemSize() -> void
---- Decor.OptionPanel::AdjustOptionItemSize 0x2d28a4c
02d28a4c: str     x30, [sp, #-0x30]!                         
02d28a50: stp     x22, x21, [sp, #0x10]                      
02d28a54: stp     x20, x19, [sp, #0x20]                      
02d28a58: adrp    x20, #0x6630000                            
02d28a5c: mov     x19, x0                                    
02d28a60: ldrb    w8, [x20, #0xa4]                           
02d28a64: tbnz    w8, #0, #0x2d28aa0                         
02d28a68: adrp    x0, #0x626a000                             
02d28a6c: ldr     x0, [x0, #0x210]                           MS:System.Collections.Generic.List`1::RemoveAt
02d28a70: bl      #0x2b70db0                                 fn_2b70db0
02d28a74: adrp    x0, #0x626a000                             
02d28a78: ldr     x0, [x0, #0x1a0]                           MS:System.Collections.Generic.List`1::get_Count
02d28a7c: bl      #0x2b70db0                                 fn_2b70db0
02d28a80: adrp    x0, #0x626a000                             
02d28a84: ldr     x0, [x0, #0x1a8]                           MS:System.Collections.Generic.List`1::get_Item
02d28a88: bl      #0x2b70db0                                 fn_2b70db0
02d28a8c: mov     w8, #1                                     
02d28a90: strb    w8, [x20, #0xa4]                           
02d28a94: b       #0x2d28aa0                                 
02d28a98: mov     x0, x19                                    
02d28a9c: bl      #0x2d29490                                 Decor.OptionPanel::CreateOptionItem
02d28aa0: ldr     x8, [x19, #0x30]                           ._optionItems
02d28aa4: cbz     x8, #0x2d28b34                             
02d28aa8: ldr     x0, [x19, #0x48]                           ._categoryAsset
02d28aac: cbz     x0, #0x2d28b34                             
02d28ab0: ldr     w20, [x8, #0x18]                           
02d28ab4: bl      #0x2d25174                                 Decor.CategoryAsset::GetOptionDataCount
02d28ab8: cmp     w20, w0                                    
02d28abc: b.lt    #0x2d28a98                                 
02d28ac0: ldr     x8, [x19, #0x30]                           ._optionItems
02d28ac4: cbz     x8, #0x2d28b34                             
02d28ac8: adrp    x20, #0x626a000                            
02d28acc: adrp    x21, #0x626a000                            
02d28ad0: ldr     x20, [x20, #0x1a8]                         MS:System.Collections.Generic.List`1::get_Item
02d28ad4: ldr     x21, [x21, #0x210]                         MS:System.Collections.Generic.List`1::RemoveAt
02d28ad8: ldr     x0, [x19, #0x48]                           ._categoryAsset
02d28adc: cbz     x0, #0x2d28b34                             
02d28ae0: ldr     w22, [x8, #0x18]                           
02d28ae4: bl      #0x2d25174                                 Decor.CategoryAsset::GetOptionDataCount
02d28ae8: cmp     w22, w0                                    
02d28aec: b.le    #0x2d28b38                                 
02d28af0: ldr     x0, [x19, #0x30]                           ._optionItems
02d28af4: cbz     x0, #0x2d28b34                             
02d28af8: ldr     w8, [x0, #0x18]                            MS:System.Collections.Generic.List`1::Add
02d28afc: ldr     x2, [x20]                                  T:type56879(k15)
02d28b00: sub     w1, w8, #1                                 
02d28b04: bl      #0x35a8f3c                                 fn_35a8f3c
02d28b08: cbz     x0, #0x2d28b34                             
02d28b0c: mov     x1, xzr                                    
02d28b10: bl      #0x2cdc880                                 PoolElement::DespawnSelf
02d28b14: ldr     x0, [x19, #0x30]                           ._optionItems
02d28b18: cbz     x0, #0x2d28b34                             
02d28b1c: ldr     w8, [x0, #0x18]                            MS:System.Collections.Generic.List`1::Add
02d28b20: ldr     x2, [x21]                                  T:type56879(k15)
02d28b24: sub     w1, w8, #1                                 
02d28b28: bl      #0x35aaa5c                                 fn_35aaa5c
02d28b2c: ldr     x8, [x19, #0x30]                           ._optionItems
02d28b30: cbnz    x8, #0x2d28ad8                             
02d28b34: bl      #0x2b7105c                                 fn_2b7105c
02d28b38: ldr     x0, [x19, #0x28]                           ._scrollRect
02d28b3c: cbz     x0, #0x2d28b34                             
02d28b40: ldp     x20, x19, [sp, #0x20]                      
02d28b44: movi    d0, #0000000000000000                      
02d28b48: ldp     x22, x21, [sp, #0x10]                      
02d28b4c: mov     x1, xzr                                    
02d28b50: ldr     x30, [sp], #0x30                           
02d28b54: b       #0x5e64a4c                                 UnityEngine.UI.ScrollRect::set_horizontalNormalizedPosition
## CreateOptionItem() -> Decor.OptionItem
---- Decor.OptionPanel::CreateOptionItem 0x2d29490
02d29490: str     d10, [sp, #-0x40]!                         
02d29494: stp     d9, d8, [sp, #8]                           
02d29498: str     x30, [sp, #0x18]                           
02d2949c: stp     x22, x21, [sp, #0x20]                      
02d294a0: stp     x20, x19, [sp, #0x30]                      
02d294a4: adrp    x20, #0x6630000                            
02d294a8: adrp    x21, #0x6266000                            
02d294ac: mov     x19, x0                                    
02d294b0: ldrb    w8, [x20, #0xa5]                           
02d294b4: ldr     x21, [x21, #0xd20]                         MS:MonoSingleton`1::get_Instance
02d294b8: tbnz    w8, #0, #0x2d294e8                         
02d294bc: adrp    x0, #0x626a000                             
02d294c0: ldr     x0, [x0, #0x288]                           MS:UnityEngine.Component::GetComponent
02d294c4: bl      #0x2b70db0                                 fn_2b70db0
02d294c8: adrp    x0, #0x626a000                             
02d294cc: ldr     x0, [x0, #0x290]                           MS:System.Collections.Generic.List`1::Add
02d294d0: bl      #0x2b70db0                                 fn_2b70db0
02d294d4: adrp    x0, #0x6266000                             
02d294d8: ldr     x0, [x0, #0xd20]                           MS:MonoSingleton`1::get_Instance
02d294dc: bl      #0x2b70db0                                 fn_2b70db0
02d294e0: mov     w8, #1                                     
02d294e4: strb    w8, [x20, #0xa5]                           
02d294e8: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d294ec: bl      #0x3769600                                 fn_3769600
02d294f0: adrp    x21, #0x662f000                            
02d294f4: mov     x20, x0                                    
02d294f8: ldrb    w8, [x21, #0x91a]                          
02d294fc: cbnz    w8, #0x2d29514                             
02d29500: adrp    x0, #0x6264000                             
02d29504: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d29508: bl      #0x2b70db0                                 fn_2b70db0
02d2950c: mov     w8, #1                                     
02d29510: strb    w8, [x21, #0x91a]                          
02d29514: adrp    x21, #0x6264000                            
02d29518: adrp    x22, #0x662f000                            
02d2951c: ldr     x21, [x21, #0xd8]                          T:UnityEngine.Vector3
02d29520: ldrb    w9, [x22, #0xbdf]                          
02d29524: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d29528: ldr     x8, [x8, #0xb8]                            
02d2952c: ldp     s8, s9, [x8]                               
02d29530: ldr     s10, [x8, #8]                              
02d29534: cbnz    w9, #0x2d2954c                             
02d29538: adrp    x0, #0x6266000                             
02d2953c: ldr     x0, [x0, #0xd30]                           T:UnityEngine.Quaternion
02d29540: bl      #0x2b70db0                                 fn_2b70db0
02d29544: mov     w8, #1                                     
02d29548: strb    w8, [x22, #0xbdf]                          
02d2954c: cbz     x20, #0x2d2966c                            
02d29550: adrp    x8, #0x6266000                             
02d29554: fmov    s0, s8                                     
02d29558: fmov    s1, s9                                     
02d2955c: ldr     x8, [x8, #0xd30]                           T:UnityEngine.Quaternion
02d29560: fmov    s2, s10                                    
02d29564: ldr     x2, [x19, #0x20]                           ._contentParent
02d29568: mov     x0, x20                                    
02d2956c: mov     w1, #7                                     
02d29570: mov     x3, xzr                                    
02d29574: ldr     x8, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d29578: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02d2957c: ldp     s5, s6, [x8, #8]                           
02d29580: ldp     s3, s4, [x8]                               
02d29584: bl      #0x2cdcef0                                 PoolManager::SpawnObject
02d29588: cbz     x0, #0x2d2966c                             
02d2958c: adrp    x8, #0x626a000                             
02d29590: ldr     x8, [x8, #0x288]                           MS:UnityEngine.Component::GetComponent
02d29594: ldr     x1, [x8]                                   T:type56879(k15)
02d29598: bl      #0x3140c84                                 fn_3140c84
02d2959c: adrp    x22, #0x662f000                            
02d295a0: mov     x20, x0                                    
02d295a4: ldrb    w8, [x22, #0xa74]                          
02d295a8: cbnz    w8, #0x2d295c0                             
02d295ac: adrp    x0, #0x6264000                             
02d295b0: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d295b4: bl      #0x2b70db0                                 fn_2b70db0
02d295b8: mov     w8, #1                                     
02d295bc: strb    w8, [x22, #0xa74]                          
02d295c0: cbz     x20, #0x2d2966c                            
02d295c4: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d295c8: ldr     x9, [x20]                                  
02d295cc: mov     x0, x20                                    
02d295d0: ldr     x8, [x8, #0xb8]                            MS:UnityEngine.Object::FindObjectsOfType
02d295d4: ldp     s1, s2, [x8, #0x10]                        
02d295d8: ldr     s0, [x8, #0xc]                             [626a00c]=0 f=0,0
02d295dc: ldp     x8, x1, [x9, #0x1b8]                       
02d295e0: blr     x8                                         
02d295e4: ldr     x0, [x19, #0x30]                           ._optionItems
02d295e8: cbz     x0, #0x2d2966c                             
02d295ec: adrp    x9, #0x626a000                             
02d295f0: ldr     x9, [x9, #0x290]                           MS:System.Collections.Generic.List`1::Add
02d295f4: ldr     w10, [x0, #0x1c]                           [626401c]=0 f=0,0
02d295f8: ldr     x8, [x0, #0x10]                            M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0::<DOSetFloat>b__0
02d295fc: ldr     x9, [x9]                                   T:type56879(k15)
02d29600: add     w10, w10, #1                               
02d29604: str     w10, [x0, #0x1c]                           
02d29608: cbz     x8, #0x2d2966c                             
02d2960c: ldrsw   x10, [x0, #0x18]                           
02d29610: ldr     w11, [x8, #0x18]                           MS:System.Collections.Generic.List`1::Add
02d29614: cmp     w10, w11                                   
02d29618: b.hs    #0x2d2963c                                 
02d2961c: add     x8, x8, x10, lsl #3                        &626a000
02d29620: add     w9, w10, #1                                
02d29624: mov     x1, x20                                    
02d29628: str     w9, [x0, #0x18]                            
02d2962c: str     x20, [x8, #0x20]!                          
02d29630: mov     x0, x8                                     
02d29634: bl      #0x2b70d54                                 fn_2b70d54
02d29638: b       #0x2d29650                                 
02d2963c: ldr     x8, [x9, #0x20]                            M:Decor.DataDecor/<>c__DisplayClass8_0::<NewData>b__0
02d29640: mov     x1, x20                                    
02d29644: ldr     x8, [x8, #0xc0]                            S:'Main character is null'
02d29648: ldr     x2, [x8, #0x70]                            MS:System.Collections.Generic.List`1::FindIndex
02d2964c: bl      #0x35a920c                                 fn_35a920c
02d29650: mov     x0, x20                                    
02d29654: ldp     x20, x19, [sp, #0x30]                      
02d29658: ldp     x22, x21, [sp, #0x20]                      
02d2965c: ldr     x30, [sp, #0x18]                           
02d29660: ldp     d9, d8, [sp, #8]                           
02d29664: ldr     d10, [sp], #0x40                           
02d29668: ret                                                
02d2966c: bl      #0x2b7105c                                 fn_2b7105c
## HandleClickOptionItem(Decor.OptionItem optionItem) -> void
---- Decor.OptionPanel::HandleClickOptionItem 0x2d29670
02d29670: str     x30, [sp, #-0x20]!                         
02d29674: stp     x20, x19, [sp, #0x10]                      
02d29678: cbz     x1, #0x2d296cc                             
02d2967c: mov     x20, x0                                    
02d29680: mov     x0, x1                                     
02d29684: mov     x19, x1                                    
02d29688: bl      #0x2d2890c                                 Decor.OptionItem::StartClickEffect
02d2968c: ldr     x0, [x20, #0x50]                           ._dataDecor
02d29690: cbz     x0, #0x2d296cc                             
02d29694: ldr     w2, [x19, #0x28]                           ._scrollRect
02d29698: ldr     w1, [x20, #0x58]                           ._selectedCategoryIndex
02d2969c: bl      #0x2d25b24                                 Decor.DataDecor::HasUnlockedItem
02d296a0: tbz     w0, #0, #0x2d296b8                         
02d296a4: mov     x0, x20                                    
02d296a8: mov     x1, x19                                    
02d296ac: ldp     x20, x19, [sp, #0x10]                      
02d296b0: ldr     x30, [sp], #0x20                           
02d296b4: b       #0x2d28b5c                                 Decor.OptionPanel::SelectedOptionItem
02d296b8: mov     x0, x20                                    
02d296bc: mov     x1, x19                                    
02d296c0: ldp     x20, x19, [sp, #0x10]                      
02d296c4: ldr     x30, [sp], #0x20                           
02d296c8: b       #0x2d296d0                                 Decor.OptionPanel::OnOptionItemBuyClicked
02d296cc: bl      #0x2b7105c                                 fn_2b7105c
## OnOptionItemBuyClicked(Decor.OptionItem optionItem) -> void
---- Decor.OptionPanel::OnOptionItemBuyClicked 0x2d296d0
02d296d0: str     x30, [sp, #-0x30]!                         
02d296d4: stp     x22, x21, [sp, #0x10]                      
02d296d8: stp     x20, x19, [sp, #0x20]                      
02d296dc: adrp    x20, #0x6630000                            
02d296e0: adrp    x21, #0x626a000                            
02d296e4: mov     x22, x1                                    
02d296e8: ldrb    w8, [x20, #0xa6]                           
02d296ec: ldr     x21, [x21, #0x298]                         T:Decor.OptionPanel/<>c__DisplayClass23_0
02d296f0: mov     x19, x0                                    
02d296f4: tbnz    w8, #0, #0x2d29784                         
02d296f8: adrp    x0, #0x6264000                             
02d296fc: ldr     x0, [x0, #0xf90]                           T:System.Action
02d29700: bl      #0x2b70db0                                 fn_2b70db0
02d29704: adrp    x0, #0x6266000                             
02d29708: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d2970c: bl      #0x2b70db0                                 fn_2b70db0
02d29710: adrp    x0, #0x6267000                             
02d29714: ldr     x0, [x0, #0xbd0]                           MS:MonoSingleton`1::get_Instance
02d29718: bl      #0x2b70db0                                 fn_2b70db0
02d2971c: adrp    x0, #0x6267000                             
02d29720: ldr     x0, [x0, #0xd50]                           MS:MonoSingleton`1::get_Instance
02d29724: bl      #0x2b70db0                                 fn_2b70db0
02d29728: adrp    x0, #0x6266000                             
02d2972c: ldr     x0, [x0, #0xaa0]                           MS:MonoSingleton`1::get_Instance
02d29730: bl      #0x2b70db0                                 fn_2b70db0
02d29734: adrp    x0, #0x6266000                             
02d29738: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d2973c: bl      #0x2b70db0                                 fn_2b70db0
02d29740: adrp    x0, #0x6265000                             
02d29744: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02d29748: bl      #0x2b70db0                                 fn_2b70db0
02d2974c: adrp    x0, #0x626a000                             
02d29750: ldr     x0, [x0, #0x2a0]                           M:Decor.OptionPanel/<>c__DisplayClass23_0::<OnOptionItemBuyClicked>b__0
02d29754: bl      #0x2b70db0                                 fn_2b70db0
02d29758: adrp    x0, #0x626a000                             
02d2975c: ldr     x0, [x0, #0x298]                           T:Decor.OptionPanel/<>c__DisplayClass23_0
02d29760: bl      #0x2b70db0                                 fn_2b70db0
02d29764: adrp    x0, #0x6269000                             
02d29768: ldr     x0, [x0, #0xb40]                           MS:UIManager::ShowPopup
02d2976c: bl      #0x2b70db0                                 fn_2b70db0
02d29770: adrp    x0, #0x6269000                             
02d29774: ldr     x0, [x0, #0xb58]                           S:'unlock_decor'
02d29778: bl      #0x2b70db0                                 fn_2b70db0
02d2977c: mov     w8, #1                                     
02d29780: strb    w8, [x20, #0xa6]                           
02d29784: ldr     x0, [x21]                                  T:type56879(k15)
02d29788: bl      #0x2b7104c                                 fn_2b7104c
02d2978c: mov     x1, xzr                                    
02d29790: mov     x21, x0                                    
02d29794: bl      #0x4e53e9c                                 System.Object::.ctor
02d29798: cbz     x21, #0x2d299a8                            
02d2979c: mov     x0, x21                                    
02d297a0: mov     x1, x19                                    
02d297a4: str     x19, [x0, #0x10]!                          
02d297a8: bl      #0x2b70d54                                 fn_2b70d54
02d297ac: mov     x20, x21                                   
02d297b0: mov     x1, x22                                    
02d297b4: str     x22, [x20, #0x18]!                         
02d297b8: mov     x0, x20                                    
02d297bc: bl      #0x2b70d54                                 fn_2b70d54
02d297c0: mov     x0, xzr                                    
02d297c4: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d297c8: cbz     x0, #0x2d299a8                             
02d297cc: movi    d1, #0000000000000000                      
02d297d0: movi    d2, #0000000000000000                      
02d297d4: adrp    x22, #0x6267000                            
02d297d8: fmov    s0, #1.00000000                            
02d297dc: ldr     x22, [x22, #0xd50]                         MS:MonoSingleton`1::get_Instance
02d297e0: mov     w1, #1                                     
02d297e4: mov     w2, wzr                                    
02d297e8: mov     w3, wzr                                    
02d297ec: mov     x4, xzr                                    
02d297f0: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d297f4: ldr     x0, [x22]                                  S:'didu'
02d297f8: bl      #0x3769600                                 fn_3769600
02d297fc: cbz     x0, #0x2d299a8                             
02d29800: mov     w1, #4                                     
02d29804: mov     x2, xzr                                    
02d29808: bl      #0x2cc6ee0                                 Framework.VibrationManager::Haptic
02d2980c: ldr     x8, [x20]                                  
02d29810: cbz     x8, #0x2d299a8                             
02d29814: ldr     x0, [x19, #0x48]                           ._categoryAsset
02d29818: cbz     x0, #0x2d299a8                             
02d2981c: ldr     w1, [x8, #0x28]                            
02d29820: bl      #0x2d24a4c                                 Decor.CategoryAsset::GetOptionDataByID
02d29824: cbz     x0, #0x2d299a8                             
02d29828: ldr     w8, [x0, #0x20]                            M:Trading.TradingSession::<ValidateTrade>b__57_1 ._contentParent
02d2982c: mov     x22, x0                                    
02d29830: cmp     w8, #1                                     
02d29834: b.eq    #0x2d29858                                 
02d29838: cmp     w8, #3                                     
02d2983c: b.eq    #0x2d29848                                 
02d29840: cmp     w8, #5                                     
02d29844: b.ne    #0x2d298c8                                 
02d29848: ldp     x20, x19, [sp, #0x20]                      
02d2984c: ldp     x22, x21, [sp, #0x10]                      
02d29850: ldr     x30, [sp], #0x30                           
02d29854: ret                                                
02d29858: adrp    x8, #0x6265000                             
02d2985c: ldr     x8, [x8, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02d29860: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02d29864: bl      #0x3be7218                                 fn_3be7218
02d29868: adrp    x8, #0x6264000                             
02d2986c: mov     x19, x0                                    
02d29870: ldr     x8, [x8, #0xf90]                           T:System.Action
02d29874: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d29878: mov     x0, x8                                     
02d2987c: bl      #0x2b7104c                                 fn_2b7104c
02d29880: adrp    x8, #0x626a000                             
02d29884: mov     x1, x21                                    
02d29888: mov     x3, xzr                                    
02d2988c: ldr     x8, [x8, #0x2a0]                           M:Decor.OptionPanel/<>c__DisplayClass23_0::<OnOptionItemBuyClicked>b__0
02d29890: mov     x20, x0                                    
02d29894: ldr     x2, [x8]                                   T:type56879(k15)
02d29898: bl      #0x4d8ddbc                                 System.Action::.ctor
02d2989c: cbz     x19, #0x2d299a8                            
02d298a0: adrp    x8, #0x6269000                             
02d298a4: mov     x0, x19                                    
02d298a8: mov     x2, x20                                    
02d298ac: ldr     x8, [x8, #0xb58]                           S:'unlock_decor'
02d298b0: ldp     x20, x19, [sp, #0x20]                      
02d298b4: ldp     x22, x21, [sp, #0x10]                      
02d298b8: mov     x3, xzr                                    
02d298bc: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d298c0: ldr     x30, [sp], #0x30                           
02d298c4: b       #0x2c8a2c0                                 AdsManager::ShowRewarded
02d298c8: adrp    x8, #0x6266000                             
02d298cc: ldr     x8, [x8, #0x658]                           MS:MonoSingleton`1::get_Instance
02d298d0: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d298d4: bl      #0x3769600                                 fn_3769600
02d298d8: cbz     x0, #0x2d299a8                             
02d298dc: adrp    x8, #0x6266000                             
02d298e0: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02d298e4: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d298e8: bl      #0x3168dd0                                 fn_3168dd0
02d298ec: cbz     x0, #0x2d299a8                             
02d298f0: mov     x1, xzr                                    
02d298f4: bl      #0x2cabaf8                                 DataUser::GetMoney
02d298f8: ldr     w8, [x22, #0x24]                           [6267024]=0 f=0,0
02d298fc: cmp     w8, w0                                     
02d29900: b.le    #0x2d29940                                 
02d29904: ldr     x0, [x20]                                  
02d29908: cbz     x0, #0x2d299a8                             
02d2990c: bl      #0x2d2890c                                 Decor.OptionItem::StartClickEffect
02d29910: adrp    x8, #0x6267000                             
02d29914: ldr     x8, [x8, #0xbd0]                           MS:MonoSingleton`1::get_Instance
02d29918: ldr     x0, [x8]                                   S:'didu'
02d2991c: bl      #0x3769600                                 fn_3769600
02d29920: cbz     x0, #0x2d299a8                             
02d29924: adrp    x8, #0x6269000                             
02d29928: ldr     x8, [x8, #0xb40]                           MS:UIManager::ShowPopup
02d2992c: ldp     x20, x19, [sp, #0x20]                      
02d29930: ldp     x22, x21, [sp, #0x10]                      
02d29934: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d29938: ldr     x30, [sp], #0x30                           
02d2993c: b       #0x33fbfac                                 
02d29940: mov     x0, xzr                                    
02d29944: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d29948: cbz     x0, #0x2d299a8                             
02d2994c: movi    d1, #0000000000000000                      
02d29950: movi    d2, #0000000000000000                      
02d29954: mov     w1, #0x2f                                  
02d29958: fmov    s0, #1.00000000                            
02d2995c: mov     w2, wzr                                    
02d29960: mov     w3, wzr                                    
02d29964: mov     x4, xzr                                    
02d29968: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d2996c: adrp    x8, #0x6266000                             
02d29970: ldr     x8, [x8, #0xaa0]                           MS:MonoSingleton`1::get_Instance
02d29974: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d29978: bl      #0x3769600                                 fn_3769600
02d2997c: cbz     x0, #0x2d299a8                             
02d29980: ldr     w8, [x22, #0x24]                           [6267024]=0 f=0,0
02d29984: mov     x2, xzr                                    
02d29988: neg     w1, w8                                     
02d2998c: bl      #0x2cdac78                                 MoneyManager::UpdateMoney
02d29990: ldr     x1, [x20]                                  
02d29994: mov     x0, x19                                    
02d29998: ldp     x20, x19, [sp, #0x20]                      
02d2999c: ldp     x22, x21, [sp, #0x10]                      
02d299a0: ldr     x30, [sp], #0x30                           
02d299a4: b       #0x2d28c78                                 Decor.OptionPanel::UnlockOptionItem
02d299a8: bl      #0x2b7105c                                 fn_2b7105c
## OnOptionItemClicked(Decor.OptionItem optionItem) -> void
---- Decor.OptionPanel::OnOptionItemClicked 0x2d299b4
02d299b4: stp     x30, x21, [sp, #-0x20]!                    
02d299b8: stp     x20, x19, [sp, #0x10]                      
02d299bc: adrp    x21, #0x6630000                            
02d299c0: mov     x19, x1                                    
02d299c4: mov     x20, x0                                    
02d299c8: ldrb    w8, [x21, #0xa7]                           
02d299cc: tbnz    w8, #0, #0x2d299e4                         
02d299d0: adrp    x0, #0x6267000                             
02d299d4: ldr     x0, [x0, #0xd50]                           MS:MonoSingleton`1::get_Instance
02d299d8: bl      #0x2b70db0                                 fn_2b70db0
02d299dc: mov     w8, #1                                     
02d299e0: strb    w8, [x21, #0xa7]                           
02d299e4: mov     x0, xzr                                    
02d299e8: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d299ec: cbz     x0, #0x2d29a44                             
02d299f0: movi    d1, #0000000000000000                      
02d299f4: movi    d2, #0000000000000000                      
02d299f8: adrp    x21, #0x6267000                            
02d299fc: fmov    s0, #1.00000000                            
02d29a00: ldr     x21, [x21, #0xd50]                         MS:MonoSingleton`1::get_Instance
02d29a04: mov     w1, #1                                     
02d29a08: mov     w2, wzr                                    
02d29a0c: mov     w3, wzr                                    
02d29a10: mov     x4, xzr                                    
02d29a14: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d29a18: ldr     x0, [x21]                                  S:'didu'
02d29a1c: bl      #0x3769600                                 fn_3769600
02d29a20: cbz     x0, #0x2d29a44                             
02d29a24: mov     w1, #4                                     
02d29a28: mov     x2, xzr                                    
02d29a2c: bl      #0x2cc6ee0                                 Framework.VibrationManager::Haptic
02d29a30: mov     x0, x20                                    
02d29a34: mov     x1, x19                                    
02d29a38: ldp     x20, x19, [sp, #0x10]                      
02d29a3c: ldp     x30, x21, [sp], #0x20                      
02d29a40: b       #0x2d29670                                 Decor.OptionPanel::HandleClickOptionItem
02d29a44: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Decor.OptionPanel::.ctor 0x2d29a48
02d29a48: str     x30, [sp, #-0x30]!                         
02d29a4c: stp     x22, x21, [sp, #0x10]                      
02d29a50: stp     x20, x19, [sp, #0x20]                      
02d29a54: adrp    x21, #0x6630000                            
02d29a58: adrp    x22, #0x626a000                            
02d29a5c: adrp    x20, #0x626a000                            
02d29a60: ldrb    w8, [x21, #0xa8]                           
02d29a64: ldr     x22, [x22, #0x2a8]                         T:type56771(k15)
02d29a68: ldr     x20, [x20, #0x2b0]                         MS:System.Collections.Generic.List`1::.ctor
02d29a6c: mov     x19, x0                                    
02d29a70: tbnz    w8, #0, #0x2d29a94                         
02d29a74: adrp    x0, #0x626a000                             
02d29a78: ldr     x0, [x0, #0x2b0]                           MS:System.Collections.Generic.List`1::.ctor
02d29a7c: bl      #0x2b70db0                                 fn_2b70db0
02d29a80: adrp    x0, #0x626a000                             
02d29a84: ldr     x0, [x0, #0x2a8]                           T:type56771(k15)
02d29a88: bl      #0x2b70db0                                 fn_2b70db0
02d29a8c: mov     w8, #1                                     
02d29a90: strb    w8, [x21, #0xa8]                           
02d29a94: ldr     x0, [x22]                                  T:type56879(k15)
02d29a98: bl      #0x2b7104c                                 fn_2b7104c
02d29a9c: ldr     x1, [x20]                                  T:type56879(k15)
02d29aa0: mov     x20, x0                                    
02d29aa4: bl      #0x35a89a4                                 fn_35a89a4
02d29aa8: mov     x0, x19                                    
02d29aac: mov     x1, x20                                    
02d29ab0: str     x20, [x0, #0x30]!                          ._optionItems
02d29ab4: bl      #0x2b70d54                                 fn_2b70d54
02d29ab8: mov     x0, x19                                    
02d29abc: ldp     x20, x19, [sp, #0x20]                      
02d29ac0: ldp     x22, x21, [sp, #0x10]                      
02d29ac4: mov     x1, xzr                                    
02d29ac8: ldr     x30, [sp], #0x30                           
02d29acc: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
## <Refresh>b__19_0(Decor.OptionItem optionItem) -> bool
---- Decor.OptionPanel::<Refresh>b__19_0 0x2d29ad0
02d29ad0: str     x30, [sp, #-0x10]!                         
02d29ad4: cbz     x1, #0x2d29b04                             
02d29ad8: ldr     x8, [x0, #0x50]                            ._dataDecor
02d29adc: cbz     x8, #0x2d29b04                             
02d29ae0: ldr     w9, [x0, #0x58]                            ._selectedCategoryIndex
02d29ae4: ldr     w2, [x1, #0x28]                            
02d29ae8: mov     x0, x8                                     
02d29aec: mov     w1, w9                                     
02d29af0: bl      #0x2d25b24                                 Decor.DataDecor::HasUnlockedItem
02d29af4: mov     w8, #1                                     
02d29af8: bic     w0, w8, w0                                 
02d29afc: ldr     x30, [sp], #0x10                           
02d29b00: ret                                                
02d29b04: bl      #0x2b7105c                                 fn_2b7105c
