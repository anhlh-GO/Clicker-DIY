#### CLASS InterstitialAdScene/<>c parent= object
#   field <>9                            InterstitialAdScene/<>c                            off=0x0 attr=36 
#   field <>9__5_2                       AudienceNetwork.FBInterstitialAdBridgeCallback     off=0x8 attr=16 
#   field <>9__5_3                       AudienceNetwork.FBInterstitialAdBridgeCallback     off=0x10 attr=16 
## .cctor() -> void
---- InterstitialAdScene/<>c::.cctor 0x2c8554c
02c8554c: str     x30, [sp, #-0x20]!                         
02c85550: stp     x20, x19, [sp, #0x10]                      
02c85554: adrp    x19, #0x662f000                            
02c85558: adrp    x20, #0x6264000                            
02c8555c: ldrb    w8, [x19, #0x933]                          
02c85560: ldr     x20, [x20, #0xc00]                         T:InterstitialAdScene/<>c
02c85564: tbnz    w8, #0, #0x2c8557c                         
02c85568: adrp    x0, #0x6264000                             
02c8556c: ldr     x0, [x0, #0xc00]                           T:InterstitialAdScene/<>c
02c85570: bl      #0x2b70db0                                 fn_2b70db0
02c85574: mov     w8, #1                                     
02c85578: strb    w8, [x19, #0x933]                          
02c8557c: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c85580: bl      #0x2b7104c                                 fn_2b7104c
02c85584: mov     x1, xzr                                    
02c85588: mov     x19, x0                                    
02c8558c: bl      #0x4e53e9c                                 System.Object::.ctor
02c85590: ldr     x8, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c85594: mov     x1, x19                                    
02c85598: ldr     x8, [x8, #0xb8]                            
02c8559c: str     x19, [x8]                                  
02c855a0: ldr     x8, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c855a4: ldp     x20, x19, [sp, #0x10]                      
02c855a8: ldr     x0, [x8, #0xb8]                            
02c855ac: ldr     x30, [sp], #0x20                           
02c855b0: b       #0x2b70d54                                 
## .ctor() -> void
---- InterstitialAdScene/<>c::.ctor 0x2c855b4
02c855b4: mov     x1, xzr                                    
02c855b8: b       #0x4e53e9c                                 System.Object::.ctor
## <LoadInterstitial>b__5_2() -> void
---- InterstitialAdScene/<>c::<LoadInterstitial>b__5_2 0x2c855bc
02c855bc: str     x30, [sp, #-0x20]!                         
02c855c0: stp     x20, x19, [sp, #0x10]                      
02c855c4: adrp    x20, #0x662f000                            
02c855c8: adrp    x19, #0x6263000                            
02c855cc: ldrb    w8, [x20, #0x934]                          
02c855d0: ldr     x19, [x19, #0x928]                         T:UnityEngine.Debug
02c855d4: tbnz    w8, #0, #0x2c855f8                         
02c855d8: adrp    x0, #0x6263000                             
02c855dc: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c855e0: bl      #0x2b70db0                                 fn_2b70db0
02c855e4: adrp    x0, #0x6264000                             
02c855e8: ldr     x0, [x0, #0xc68]                           S:'Interstitial ad logged impression.'
02c855ec: bl      #0x2b70db0                                 fn_2b70db0
02c855f0: mov     w8, #1                                     
02c855f4: strb    w8, [x20, #0x934]                          
02c855f8: ldr     x0, [x19]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c855fc: adrp    x19, #0x6264000                            
02c85600: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c85604: ldr     x19, [x19, #0xc68]                         S:'Interstitial ad logged impression.'
02c85608: cbnz    w8, #0x2c85610                             
02c8560c: bl      #0x2b70f30                                 fn_2b70f30
02c85610: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c85614: ldp     x20, x19, [sp, #0x10]                      
02c85618: mov     x1, xzr                                    
02c8561c: ldr     x30, [sp], #0x20                           
02c85620: b       #0x5af21f4                                 UnityEngine.Debug::Log
## <LoadInterstitial>b__5_3() -> void
---- InterstitialAdScene/<>c::<LoadInterstitial>b__5_3 0x2c85624
02c85624: str     x30, [sp, #-0x20]!                         
02c85628: stp     x20, x19, [sp, #0x10]                      
02c8562c: adrp    x20, #0x662f000                            
02c85630: adrp    x19, #0x6263000                            
02c85634: ldrb    w8, [x20, #0x935]                          
02c85638: ldr     x19, [x19, #0x928]                         T:UnityEngine.Debug
02c8563c: tbnz    w8, #0, #0x2c85660                         
02c85640: adrp    x0, #0x6263000                             
02c85644: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c85648: bl      #0x2b70db0                                 fn_2b70db0
02c8564c: adrp    x0, #0x6264000                             
02c85650: ldr     x0, [x0, #0xc70]                           S:'Interstitial ad clicked.'
02c85654: bl      #0x2b70db0                                 fn_2b70db0
02c85658: mov     w8, #1                                     
02c8565c: strb    w8, [x20, #0x935]                          
02c85660: ldr     x0, [x19]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c85664: adrp    x19, #0x6264000                            
02c85668: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c8566c: ldr     x19, [x19, #0xc70]                         S:'Interstitial ad clicked.'
02c85670: cbnz    w8, #0x2c85678                             
02c85674: bl      #0x2b70f30                                 fn_2b70f30
02c85678: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c8567c: ldp     x20, x19, [sp, #0x10]                      
02c85680: mov     x1, xzr                                    
02c85684: ldr     x30, [sp], #0x20                           
02c85688: b       #0x5af21f4                                 UnityEngine.Debug::Log
#### CLASS InterstitialAdScene parent= BaseScene
#   field interstitialAd                 AudienceNetwork.InterstitialAd                     off=0x20 attr=1 
#   field isLoaded                       bool                                               off=0x28 attr=1 
#   field didClose                       bool                                               off=0x29 attr=1 
#   field statusLabel                    UnityEngine.UI.Text                                off=0x30 attr=6 
## Awake() -> void
---- InterstitialAdScene::Awake 0x2c84cec
02c84cec: str     x30, [sp, #-0x20]!                         
02c84cf0: stp     x20, x19, [sp, #0x10]                      
02c84cf4: adrp    x20, #0x662f000                            
02c84cf8: adrp    x19, #0x6264000                            
02c84cfc: ldrb    w8, [x20, #0x92a]                          
02c84d00: ldr     x19, [x19, #0xae8]                         T:SettingsScene
02c84d04: tbnz    w8, #0, #0x2c84d1c                         
02c84d08: adrp    x0, #0x6264000                             
02c84d0c: ldr     x0, [x0, #0xae8]                           T:SettingsScene
02c84d10: bl      #0x2b70db0                                 fn_2b70db0
02c84d14: mov     w8, #1                                     
02c84d18: strb    w8, [x20, #0x92a]                          
02c84d1c: mov     x0, xzr                                    
02c84d20: bl      #0x2ccc9d4                                 AudienceNetwork.AudienceNetworkAds::Initialize
02c84d24: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c84d28: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c84d2c: cbnz    w8, #0x2c84d34                             
02c84d30: bl      #0x2b70f30                                 fn_2b70f30
02c84d34: ldp     x20, x19, [sp, #0x10]                      
02c84d38: ldr     x30, [sp], #0x20                           
02c84d3c: b       #0x2c84340                                 SettingsScene::InitializeSettings
## LoadInterstitial() -> void
---- InterstitialAdScene::LoadInterstitial 0x2c84d40
02c84d40: stp     x30, x25, [sp, #-0x40]!                    
02c84d44: stp     x24, x23, [sp, #0x10]                      
02c84d48: stp     x22, x21, [sp, #0x20]                      
02c84d4c: stp     x20, x19, [sp, #0x30]                      
02c84d50: adrp    x20, #0x662f000                            
02c84d54: mov     x19, x0                                    
02c84d58: ldrb    w8, [x20, #0x92b]                          
02c84d5c: tbnz    w8, #0, #0x2c84df8                         
02c84d60: adrp    x0, #0x6264000                             
02c84d64: ldr     x0, [x0, #0xbb8]                           T:AudienceNetwork.FBInterstitialAdBridgeCallback
02c84d68: bl      #0x2b70db0                                 fn_2b70db0
02c84d6c: adrp    x0, #0x6264000                             
02c84d70: ldr     x0, [x0, #0xbc0]                           T:AudienceNetwork.FBInterstitialAdBridgeErrorCallback
02c84d74: bl      #0x2b70db0                                 fn_2b70db0
02c84d78: adrp    x0, #0x6264000                             
02c84d7c: ldr     x0, [x0, #0xbc8]                           M:InterstitialAdScene::<LoadInterstitial>b__5_0
02c84d80: bl      #0x2b70db0                                 fn_2b70db0
02c84d84: adrp    x0, #0x6264000                             
02c84d88: ldr     x0, [x0, #0xbd0]                           M:InterstitialAdScene::<LoadInterstitial>b__5_1
02c84d8c: bl      #0x2b70db0                                 fn_2b70db0
02c84d90: adrp    x0, #0x6264000                             
02c84d94: ldr     x0, [x0, #0xbd8]                           M:InterstitialAdScene::<LoadInterstitial>b__5_4
02c84d98: bl      #0x2b70db0                                 fn_2b70db0
02c84d9c: adrp    x0, #0x6264000                             
02c84da0: ldr     x0, [x0, #0xbe0]                           M:InterstitialAdScene::<LoadInterstitial>b__5_5
02c84da4: bl      #0x2b70db0                                 fn_2b70db0
02c84da8: adrp    x0, #0x6264000                             
02c84dac: ldr     x0, [x0, #0xbe8]                           T:AudienceNetwork.InterstitialAd
02c84db0: bl      #0x2b70db0                                 fn_2b70db0
02c84db4: adrp    x0, #0x6264000                             
02c84db8: ldr     x0, [x0, #0xbf0]                           M:InterstitialAdScene/<>c::<LoadInterstitial>b__5_2
02c84dbc: bl      #0x2b70db0                                 fn_2b70db0
02c84dc0: adrp    x0, #0x6264000                             
02c84dc4: ldr     x0, [x0, #0xbf8]                           M:InterstitialAdScene/<>c::<LoadInterstitial>b__5_3
02c84dc8: bl      #0x2b70db0                                 fn_2b70db0
02c84dcc: adrp    x0, #0x6264000                             
02c84dd0: ldr     x0, [x0, #0xc00]                           T:InterstitialAdScene/<>c
02c84dd4: bl      #0x2b70db0                                 fn_2b70db0
02c84dd8: adrp    x0, #0x6264000                             
02c84ddc: ldr     x0, [x0, #0xc08]                           S:'Loading interstitial ad...'
02c84de0: bl      #0x2b70db0                                 fn_2b70db0
02c84de4: adrp    x0, #0x6264000                             
02c84de8: ldr     x0, [x0, #0xb50]                           S:'YOUR_PLACEMENT_ID'
02c84dec: bl      #0x2b70db0                                 fn_2b70db0
02c84df0: mov     w8, #1                                     
02c84df4: strb    w8, [x20, #0x92b]                          
02c84df8: ldr     x0, [x19, #0x30]                           .statusLabel
02c84dfc: cbz     x0, #0x2c850b4                             
02c84e00: adrp    x8, #0x6264000                             
02c84e04: adrp    x20, #0x6264000                            
02c84e08: adrp    x21, #0x6264000                            
02c84e0c: ldr     x8, [x8, #0xc08]                           S:'Loading interstitial ad...'
02c84e10: ldr     x20, [x20, #0xbe8]                         T:AudienceNetwork.InterstitialAd
02c84e14: ldr     x9, [x0]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c84e18: ldr     x21, [x21, #0xb50]                         S:'YOUR_PLACEMENT_ID'
02c84e1c: ldr     x1, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c84e20: ldr     x8, [x9, #0x5e8]                           
02c84e24: ldr     x2, [x9, #0x5f0]                           
02c84e28: blr     x8                                         
02c84e2c: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c84e30: bl      #0x2b7104c                                 fn_2b7104c
02c84e34: ldr     x1, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c84e38: mov     x2, xzr                                    
02c84e3c: mov     x21, x0                                    
02c84e40: bl      #0x2cce1c4                                 AudienceNetwork.InterstitialAd::.ctor
02c84e44: mov     x20, x19                                   
02c84e48: mov     x1, x21                                    
02c84e4c: str     x21, [x20, #0x20]!                         .interstitialAd
02c84e50: mov     x0, x20                                    
02c84e54: bl      #0x2b70d54                                 fn_2b70d54
02c84e58: ldr     x21, [x20]                                 M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c84e5c: mov     x0, x19                                    
02c84e60: mov     x1, xzr                                    
02c84e64: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02c84e68: cbz     x21, #0x2c850b4                            
02c84e6c: adrp    x24, #0x6264000                            
02c84e70: adrp    x22, #0x6264000                            
02c84e74: mov     x1, x0                                     
02c84e78: ldr     x24, [x24, #0xbb8]                         T:AudienceNetwork.FBInterstitialAdBridgeCallback
02c84e7c: ldr     x22, [x22, #0xbc8]                         M:InterstitialAdScene::<LoadInterstitial>b__5_0
02c84e80: mov     x0, x21                                    
02c84e84: mov     x2, xzr                                    
02c84e88: bl      #0x2cceac4                                 AudienceNetwork.InterstitialAd::Register
02c84e8c: ldr     x0, [x24]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c84e90: ldr     x21, [x19, #0x20]                          .interstitialAd
02c84e94: bl      #0x2b7104c                                 fn_2b7104c
02c84e98: ldr     x2, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c84e9c: mov     x1, x19                                    
02c84ea0: mov     x3, xzr                                    
02c84ea4: mov     x22, x0                                    
02c84ea8: bl      #0x2ccd684                                 AudienceNetwork.FBInterstitialAdBridgeCallback::.ctor
02c84eac: cbz     x21, #0x2c850b4                            
02c84eb0: adrp    x23, #0x6264000                            
02c84eb4: adrp    x25, #0x6264000                            
02c84eb8: mov     x0, x21                                    
02c84ebc: ldr     x23, [x23, #0xbc0]                         T:AudienceNetwork.FBInterstitialAdBridgeErrorCallback
02c84ec0: ldr     x25, [x25, #0xbd0]                         M:InterstitialAdScene::<LoadInterstitial>b__5_1
02c84ec4: mov     x1, x22                                    
02c84ec8: mov     x2, xzr                                    
02c84ecc: bl      #0x2ccdab0                                 AudienceNetwork.InterstitialAd::set_InterstitialAdDidLoad
02c84ed0: ldr     x0, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c84ed4: ldr     x21, [x19, #0x20]                          .interstitialAd
02c84ed8: bl      #0x2b7104c                                 fn_2b7104c
02c84edc: ldr     x2, [x25]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c84ee0: mov     x1, x19                                    
02c84ee4: mov     x3, xzr                                    
02c84ee8: mov     x22, x0                                    
02c84eec: bl      #0x2ccd75c                                 AudienceNetwork.FBInterstitialAdBridgeErrorCallback::.ctor
02c84ef0: cbz     x21, #0x2c850b4                            
02c84ef4: adrp    x25, #0x6264000                            
02c84ef8: mov     x0, x21                                    
02c84efc: mov     x1, x22                                    
02c84f00: ldr     x25, [x25, #0xc00]                         T:InterstitialAdScene/<>c
02c84f04: mov     x2, xzr                                    
02c84f08: bl      #0x2ccdcb8                                 AudienceNetwork.InterstitialAd::set_InterstitialAdDidFailWithError
02c84f0c: ldr     x0, [x25]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c84f10: ldr     x21, [x20]                                 M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c84f14: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c84f18: cbnz    w8, #0x2c84f24                             
02c84f1c: bl      #0x2b70f30                                 fn_2b70f30
02c84f20: ldr     x0, [x25]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c84f24: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02c84f28: ldr     x22, [x8, #8]                              T:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0
02c84f2c: cbnz    x22, #0x2c84f80                            
02c84f30: ldr     w9, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c84f34: cbnz    w9, #0x2c84f44                             
02c84f38: bl      #0x2b70f30                                 fn_2b70f30
02c84f3c: ldr     x8, [x25]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c84f40: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02c84f44: ldr     x0, [x24]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c84f48: ldr     x23, [x8]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c84f4c: bl      #0x2b7104c                                 fn_2b7104c
02c84f50: adrp    x8, #0x6264000                             
02c84f54: mov     x1, x23                                    
02c84f58: mov     x3, xzr                                    
02c84f5c: ldr     x8, [x8, #0xbf0]                           M:InterstitialAdScene/<>c::<LoadInterstitial>b__5_2
02c84f60: mov     x22, x0                                    
02c84f64: ldr     x2, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c84f68: bl      #0x2ccd684                                 AudienceNetwork.FBInterstitialAdBridgeCallback::.ctor
02c84f6c: ldr     x8, [x25]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c84f70: mov     x1, x22                                    
02c84f74: ldr     x0, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02c84f78: str     x22, [x0, #8]!                             
02c84f7c: bl      #0x2b70d54                                 fn_2b70d54
02c84f80: cbz     x21, #0x2c850b4                            
02c84f84: mov     x0, x21                                    
02c84f88: mov     x1, x22                                    
02c84f8c: mov     x2, xzr                                    
02c84f90: bl      #0x2ccdbb4                                 AudienceNetwork.InterstitialAd::set_InterstitialAdWillLogImpression
02c84f94: ldr     x0, [x25]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c84f98: ldr     x21, [x20]                                 M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c84f9c: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c84fa0: cbnz    w8, #0x2c84fac                             
02c84fa4: bl      #0x2b70f30                                 fn_2b70f30
02c84fa8: ldr     x0, [x25]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c84fac: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02c84fb0: ldr     x22, [x8, #0x10]                           M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0::<DOSetFloat>b__0
02c84fb4: cbnz    x22, #0x2c85008                            
02c84fb8: ldr     w9, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c84fbc: cbnz    w9, #0x2c84fcc                             
02c84fc0: bl      #0x2b70f30                                 fn_2b70f30
02c84fc4: ldr     x8, [x25]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c84fc8: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02c84fcc: ldr     x0, [x24]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c84fd0: ldr     x23, [x8]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c84fd4: bl      #0x2b7104c                                 fn_2b7104c
02c84fd8: adrp    x8, #0x6264000                             
02c84fdc: mov     x1, x23                                    
02c84fe0: mov     x3, xzr                                    
02c84fe4: ldr     x8, [x8, #0xbf8]                           M:InterstitialAdScene/<>c::<LoadInterstitial>b__5_3
02c84fe8: mov     x22, x0                                    
02c84fec: ldr     x2, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c84ff0: bl      #0x2ccd684                                 AudienceNetwork.FBInterstitialAdBridgeCallback::.ctor
02c84ff4: ldr     x8, [x25]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c84ff8: mov     x1, x22                                    
02c84ffc: ldr     x0, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02c85000: str     x22, [x0, #0x10]!                          
02c85004: bl      #0x2b70d54                                 fn_2b70d54
02c85008: cbz     x21, #0x2c850b4                            
02c8500c: adrp    x23, #0x6264000                            
02c85010: mov     x0, x21                                    
02c85014: mov     x1, x22                                    
02c85018: ldr     x23, [x23, #0xbd8]                         M:InterstitialAdScene::<LoadInterstitial>b__5_4
02c8501c: mov     x2, xzr                                    
02c85020: bl      #0x2ccddbc                                 AudienceNetwork.InterstitialAd::set_InterstitialAdDidClick
02c85024: ldr     x0, [x24]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c85028: ldr     x21, [x19, #0x20]                          .interstitialAd
02c8502c: bl      #0x2b7104c                                 fn_2b7104c
02c85030: ldr     x2, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c85034: mov     x1, x19                                    
02c85038: mov     x3, xzr                                    
02c8503c: mov     x22, x0                                    
02c85040: bl      #0x2ccd684                                 AudienceNetwork.FBInterstitialAdBridgeCallback::.ctor
02c85044: cbz     x21, #0x2c850b4                            
02c85048: adrp    x23, #0x6264000                            
02c8504c: mov     x0, x21                                    
02c85050: mov     x1, x22                                    
02c85054: ldr     x23, [x23, #0xbe0]                         M:InterstitialAdScene::<LoadInterstitial>b__5_5
02c85058: mov     x2, xzr                                    
02c8505c: bl      #0x2ccdfc4                                 AudienceNetwork.InterstitialAd::set_InterstitialAdDidClose
02c85060: ldr     x0, [x24]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c85064: ldr     x21, [x19, #0x20]                          .interstitialAd
02c85068: bl      #0x2b7104c                                 fn_2b7104c
02c8506c: ldr     x2, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c85070: mov     x1, x19                                    
02c85074: mov     x3, xzr                                    
02c85078: mov     x22, x0                                    
02c8507c: bl      #0x2ccd684                                 AudienceNetwork.FBInterstitialAdBridgeCallback::.ctor
02c85080: cbz     x21, #0x2c850b4                            
02c85084: str     x22, [x21, #0x58]!                         
02c85088: mov     x0, x21                                    
02c8508c: mov     x1, x22                                    
02c85090: bl      #0x2b70d54                                 fn_2b70d54
02c85094: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c85098: cbz     x0, #0x2c850b4                             
02c8509c: ldp     x20, x19, [sp, #0x30]                      
02c850a0: mov     x1, xzr                                    
02c850a4: ldp     x22, x21, [sp, #0x20]                      
02c850a8: ldp     x24, x23, [sp, #0x10]                      
02c850ac: ldp     x30, x25, [sp], #0x40                      
02c850b0: b       #0x2cceb28                                 AudienceNetwork.InterstitialAd::LoadAd
02c850b4: bl      #0x2b7105c                                 fn_2b7105c
## ShowInterstitial() -> void
---- InterstitialAdScene::ShowInterstitial 0x2c850b8
02c850b8: str     x30, [sp, #-0x20]!                         
02c850bc: stp     x20, x19, [sp, #0x10]                      
02c850c0: adrp    x20, #0x662f000                            
02c850c4: mov     x19, x0                                    
02c850c8: ldrb    w8, [x20, #0x92c]                          
02c850cc: tbnz    w8, #0, #0x2c850f0                         
02c850d0: adrp    x0, #0x6264000                             
02c850d4: ldr     x0, [x0, #0xc10]                           S:'Ad not loaded. Click load to request an ad.'
02c850d8: bl      #0x2b70db0                                 fn_2b70db0
02c850dc: adrp    x0, #0x6263000                             
02c850e0: ldr     x0, [x0, #0xa90]                           S:''
02c850e4: bl      #0x2b70db0                                 fn_2b70db0
02c850e8: mov     w8, #1                                     
02c850ec: strb    w8, [x20, #0x92c]                          
02c850f0: ldrb    w8, [x19, #0x28]                           .isLoaded
02c850f4: cbz     w8, #0x2c85120                             
02c850f8: ldr     x0, [x19, #0x20]                           .interstitialAd
02c850fc: cbz     x0, #0x2c8514c                             
02c85100: mov     x1, xzr                                    
02c85104: bl      #0x2ccef58                                 AudienceNetwork.InterstitialAd::Show
02c85108: ldr     x0, [x19, #0x30]                           .statusLabel
02c8510c: strb    wzr, [x19, #0x28]                          .isLoaded
02c85110: cbz     x0, #0x2c8514c                             
02c85114: adrp    x8, #0x6263000                             
02c85118: ldr     x8, [x8, #0xa90]                           S:''
02c8511c: b       #0x2c85130                                 
02c85120: ldr     x0, [x19, #0x30]                           .statusLabel
02c85124: cbz     x0, #0x2c8514c                             
02c85128: adrp    x8, #0x6264000                             
02c8512c: ldr     x8, [x8, #0xc10]                           S:'Ad not loaded. Click load to request an ad.'
02c85130: ldr     x9, [x0]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c85134: ldp     x20, x19, [sp, #0x10]                      
02c85138: ldr     x1, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c8513c: ldr     x2, [x9, #0x5f0]                           
02c85140: ldr     x3, [x9, #0x5e8]                           
02c85144: ldr     x30, [sp], #0x20                           
02c85148: br      x3                                         
02c8514c: bl      #0x2b7105c                                 fn_2b7105c
## OnDestroy() -> void
---- InterstitialAdScene::OnDestroy 0x2c85150
02c85150: str     x30, [sp, #-0x20]!                         
02c85154: stp     x20, x19, [sp, #0x10]                      
02c85158: adrp    x20, #0x662f000                            
02c8515c: mov     x19, x0                                    
02c85160: ldrb    w8, [x20, #0x92d]                          
02c85164: tbnz    w8, #0, #0x2c85188                         
02c85168: adrp    x0, #0x6263000                             
02c8516c: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c85170: bl      #0x2b70db0                                 fn_2b70db0
02c85174: adrp    x0, #0x6264000                             
02c85178: ldr     x0, [x0, #0xc18]                           S:'InterstitialAdTest was destroyed!'
02c8517c: bl      #0x2b70db0                                 fn_2b70db0
02c85180: mov     w8, #1                                     
02c85184: strb    w8, [x20, #0x92d]                          
02c85188: ldr     x0, [x19, #0x20]                           .interstitialAd
02c8518c: adrp    x19, #0x6263000                            
02c85190: ldr     x19, [x19, #0x928]                         T:UnityEngine.Debug
02c85194: cbz     x0, #0x2c851a0                             
02c85198: mov     x1, xzr                                    
02c8519c: bl      #0x2cce81c                                 AudienceNetwork.InterstitialAd::Dispose
02c851a0: ldr     x0, [x19]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c851a4: adrp    x19, #0x6264000                            
02c851a8: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c851ac: ldr     x19, [x19, #0xc18]                         S:'InterstitialAdTest was destroyed!'
02c851b0: cbnz    w8, #0x2c851b8                             
02c851b4: bl      #0x2b70f30                                 fn_2b70f30
02c851b8: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c851bc: ldp     x20, x19, [sp, #0x10]                      
02c851c0: mov     x1, xzr                                    
02c851c4: ldr     x30, [sp], #0x20                           
02c851c8: b       #0x5af21f4                                 UnityEngine.Debug::Log
## NextScene() -> void
---- InterstitialAdScene::NextScene 0x2c851cc
02c851cc: str     x30, [sp, #-0x20]!                         
02c851d0: stp     x20, x19, [sp, #0x10]                      
02c851d4: adrp    x20, #0x662f000                            
02c851d8: adrp    x19, #0x6264000                            
02c851dc: ldrb    w8, [x20, #0x92e]                          
02c851e0: ldr     x19, [x19, #0xb58]                         T:UnityEngine.SceneManagement.SceneManager
02c851e4: tbnz    w8, #0, #0x2c85208                         
02c851e8: adrp    x0, #0x6264000                             
02c851ec: ldr     x0, [x0, #0xb58]                           T:UnityEngine.SceneManagement.SceneManager
02c851f0: bl      #0x2b70db0                                 fn_2b70db0
02c851f4: adrp    x0, #0x6264000                             
02c851f8: ldr     x0, [x0, #0xc20]                           S:'AdViewScene'
02c851fc: bl      #0x2b70db0                                 fn_2b70db0
02c85200: mov     w8, #1                                     
02c85204: strb    w8, [x20, #0x92e]                          
02c85208: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c8520c: adrp    x19, #0x6264000                            
02c85210: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c85214: ldr     x19, [x19, #0xc20]                         S:'AdViewScene'
02c85218: cbnz    w8, #0x2c85220                             
02c8521c: bl      #0x2b70f30                                 fn_2b70f30
02c85220: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c85224: ldp     x20, x19, [sp, #0x10]                      
02c85228: mov     x1, xzr                                    
02c8522c: ldr     x30, [sp], #0x20                           
02c85230: b       #0x5b4f55c                                 UnityEngine.SceneManagement.SceneManager::LoadScene
## .ctor() -> void
---- InterstitialAdScene::.ctor 0x2c85234
02c85234: mov     x1, xzr                                    
02c85238: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
## <LoadInterstitial>b__5_0() -> void
---- InterstitialAdScene::<LoadInterstitial>b__5_0 0x2c8523c
02c8523c: stp     x30, x23, [sp, #-0x30]!                    
02c85240: stp     x22, x21, [sp, #0x10]                      
02c85244: stp     x20, x19, [sp, #0x20]                      
02c85248: adrp    x21, #0x662f000                            
02c8524c: adrp    x20, #0x6263000                            
02c85250: mov     x19, x0                                    
02c85254: ldrb    w8, [x21, #0x92f]                          
02c85258: ldr     x20, [x20, #0x928]                         T:UnityEngine.Debug
02c8525c: tbnz    w8, #0, #0x2c852b0                         
02c85260: adrp    x0, #0x6263000                             
02c85264: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c85268: bl      #0x2b70db0                                 fn_2b70db0
02c8526c: adrp    x0, #0x6264000                             
02c85270: ldr     x0, [x0, #0xc28]                           S:'Ad loaded and is '
02c85274: bl      #0x2b70db0                                 fn_2b70db0
02c85278: adrp    x0, #0x6264000                             
02c8527c: ldr     x0, [x0, #0xb88]                           S:'invalid'
02c85280: bl      #0x2b70db0                                 fn_2b70db0
02c85284: adrp    x0, #0x6264000                             
02c85288: ldr     x0, [x0, #0xb90]                           S:'valid'
02c8528c: bl      #0x2b70db0                                 fn_2b70db0
02c85290: adrp    x0, #0x6264000                             
02c85294: ldr     x0, [x0, #0xc30]                           S:'. Click show to present!'
02c85298: bl      #0x2b70db0                                 fn_2b70db0
02c8529c: adrp    x0, #0x6264000                             
02c852a0: ldr     x0, [x0, #0xc38]                           S:'Interstitial ad loaded.'
02c852a4: bl      #0x2b70db0                                 fn_2b70db0
02c852a8: mov     w8, #1                                     
02c852ac: strb    w8, [x21, #0x92f]                          
02c852b0: ldr     x0, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c852b4: adrp    x20, #0x6264000                            
02c852b8: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c852bc: ldr     x20, [x20, #0xc38]                         S:'Interstitial ad loaded.'
02c852c0: cbnz    w8, #0x2c852c8                             
02c852c4: bl      #0x2b70f30                                 fn_2b70f30
02c852c8: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c852cc: mov     x1, xzr                                    
02c852d0: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02c852d4: ldr     x0, [x19, #0x20]                           .interstitialAd
02c852d8: mov     w8, #1                                     
02c852dc: strh    w8, [x19, #0x28]                           .isLoaded
02c852e0: cbz     x0, #0x2c85354                             
02c852e4: adrp    x20, #0x6264000                            
02c852e8: adrp    x21, #0x6264000                            
02c852ec: adrp    x22, #0x6264000                            
02c852f0: adrp    x23, #0x6264000                            
02c852f4: ldr     x20, [x20, #0xb90]                         S:'valid'
02c852f8: ldr     x21, [x21, #0xb88]                         S:'invalid'
02c852fc: ldr     x22, [x22, #0xc28]                         S:'Ad loaded and is '
02c85300: ldr     x23, [x23, #0xc30]                         S:'. Click show to present!'
02c85304: mov     x1, xzr                                    
02c85308: bl      #0x2cced8c                                 AudienceNetwork.InterstitialAd::IsValid
02c8530c: tst     w0, #1                                     
02c85310: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c85314: ldr     x2, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c85318: csel    x8, x20, x21, ne                           
02c8531c: ldr     x19, [x19, #0x30]                          .statusLabel
02c85320: mov     x3, xzr                                    
02c85324: ldr     x1, [x8]                                   
02c85328: bl      #0x4ca6dbc                                 System.String::Concat
02c8532c: cbz     x19, #0x2c85354                            
02c85330: ldr     x8, [x19]                                  
02c85334: mov     x1, x0                                     
02c85338: mov     x0, x19                                    
02c8533c: ldp     x20, x19, [sp, #0x20]                      
02c85340: ldp     x22, x21, [sp, #0x10]                      
02c85344: ldr     x2, [x8, #0x5f0]                           
02c85348: ldr     x3, [x8, #0x5e8]                           
02c8534c: ldp     x30, x23, [sp], #0x30                      
02c85350: br      x3                                         
02c85354: bl      #0x2b7105c                                 fn_2b7105c
## <LoadInterstitial>b__5_1(string error) -> void
---- InterstitialAdScene::<LoadInterstitial>b__5_1 0x2c85358
02c85358: stp     x30, x23, [sp, #-0x30]!                    
02c8535c: stp     x22, x21, [sp, #0x10]                      
02c85360: stp     x20, x19, [sp, #0x20]                      
02c85364: adrp    x22, #0x662f000                            
02c85368: adrp    x23, #0x6264000                            
02c8536c: adrp    x21, #0x6263000                            
02c85370: ldrb    w8, [x22, #0x930]                          
02c85374: ldr     x23, [x23, #0xc40]                         S:'Interstitial ad failed to load with error: '
02c85378: ldr     x21, [x21, #0x928]                         T:UnityEngine.Debug
02c8537c: mov     x20, x1                                    
02c85380: mov     x19, x0                                    
02c85384: tbnz    w8, #0, #0x2c853b4                         
02c85388: adrp    x0, #0x6263000                             
02c8538c: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c85390: bl      #0x2b70db0                                 fn_2b70db0
02c85394: adrp    x0, #0x6264000                             
02c85398: ldr     x0, [x0, #0xc48]                           S:'Interstitial ad failed to load. Check console for details.'
02c8539c: bl      #0x2b70db0                                 fn_2b70db0
02c853a0: adrp    x0, #0x6264000                             
02c853a4: ldr     x0, [x0, #0xc40]                           S:'Interstitial ad failed to load with error: '
02c853a8: bl      #0x2b70db0                                 fn_2b70db0
02c853ac: mov     w8, #1                                     
02c853b0: strb    w8, [x22, #0x930]                          
02c853b4: ldr     x0, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c853b8: mov     x1, x20                                    
02c853bc: mov     x2, xzr                                    
02c853c0: bl      #0x4c9c514                                 System.String::Concat
02c853c4: ldr     x8, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c853c8: mov     x20, x0                                    
02c853cc: ldr     w9, [x8, #0xe4]                            
02c853d0: cbnz    w9, #0x2c853dc                             
02c853d4: mov     x0, x8                                     
02c853d8: bl      #0x2b70f30                                 fn_2b70f30
02c853dc: mov     x0, x20                                    
02c853e0: mov     x1, xzr                                    
02c853e4: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02c853e8: ldr     x0, [x19, #0x30]                           .statusLabel
02c853ec: cbz     x0, #0x2c85418                             
02c853f0: adrp    x8, #0x6264000                             
02c853f4: ldr     x8, [x8, #0xc48]                           S:'Interstitial ad failed to load. Check console for details.'
02c853f8: ldr     x9, [x0]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c853fc: ldp     x20, x19, [sp, #0x20]                      
02c85400: ldp     x22, x21, [sp, #0x10]                      
02c85404: ldr     x1, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c85408: ldr     x2, [x9, #0x5f0]                           
02c8540c: ldr     x3, [x9, #0x5e8]                           
02c85410: ldp     x30, x23, [sp], #0x30                      
02c85414: br      x3                                         
02c85418: bl      #0x2b7105c                                 fn_2b7105c
## <LoadInterstitial>b__5_4() -> void
---- InterstitialAdScene::<LoadInterstitial>b__5_4 0x2c8541c
02c8541c: stp     x30, x21, [sp, #-0x20]!                    
02c85420: stp     x20, x19, [sp, #0x10]                      
02c85424: adrp    x21, #0x662f000                            
02c85428: adrp    x20, #0x6263000                            
02c8542c: mov     x19, x0                                    
02c85430: ldrb    w8, [x21, #0x931]                          
02c85434: ldr     x20, [x20, #0x928]                         T:UnityEngine.Debug
02c85438: tbnz    w8, #0, #0x2c8545c                         
02c8543c: adrp    x0, #0x6263000                             
02c85440: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c85444: bl      #0x2b70db0                                 fn_2b70db0
02c85448: adrp    x0, #0x6264000                             
02c8544c: ldr     x0, [x0, #0xc50]                           S:'Interstitial ad did close.'
02c85450: bl      #0x2b70db0                                 fn_2b70db0
02c85454: mov     w8, #1                                     
02c85458: strb    w8, [x21, #0x931]                          
02c8545c: ldr     x0, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c85460: adrp    x20, #0x6264000                            
02c85464: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c85468: ldr     x20, [x20, #0xc50]                         S:'Interstitial ad did close.'
02c8546c: cbnz    w8, #0x2c85474                             
02c85470: bl      #0x2b70f30                                 fn_2b70f30
02c85474: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c85478: mov     x1, xzr                                    
02c8547c: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02c85480: ldr     x0, [x19, #0x20]                           .interstitialAd
02c85484: mov     w8, #1                                     
02c85488: strb    w8, [x19, #0x29]                           .didClose
02c8548c: cbz     x0, #0x2c854a0                             
02c85490: ldp     x20, x19, [sp, #0x10]                      
02c85494: mov     x1, xzr                                    
02c85498: ldp     x30, x21, [sp], #0x20                      
02c8549c: b       #0x2cce81c                                 AudienceNetwork.InterstitialAd::Dispose
02c854a0: ldp     x20, x19, [sp, #0x10]                      
02c854a4: ldp     x30, x21, [sp], #0x20                      
02c854a8: ret                                                
## <LoadInterstitial>b__5_5() -> void
---- InterstitialAdScene::<LoadInterstitial>b__5_5 0x2c854ac
02c854ac: str     x30, [sp, #-0x20]!                         
02c854b0: stp     x20, x19, [sp, #0x10]                      
02c854b4: adrp    x20, #0x662f000                            
02c854b8: mov     x19, x0                                    
02c854bc: ldrb    w8, [x20, #0x932]                          
02c854c0: tbnz    w8, #0, #0x2c854f0                         
02c854c4: adrp    x0, #0x6263000                             
02c854c8: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c854cc: bl      #0x2b70db0                                 fn_2b70db0
02c854d0: adrp    x0, #0x6264000                             
02c854d4: ldr     x0, [x0, #0xc58]                           S:'Interstitial activity destroyed without being closed first.'
02c854d8: bl      #0x2b70db0                                 fn_2b70db0
02c854dc: adrp    x0, #0x6264000                             
02c854e0: ldr     x0, [x0, #0xc60]                           S:'Game should resume.'
02c854e4: bl      #0x2b70db0                                 fn_2b70db0
02c854e8: mov     w8, #1                                     
02c854ec: strb    w8, [x20, #0x932]                          
02c854f0: ldrb    w8, [x19, #0x29]                           .didClose
02c854f4: cbz     w8, #0x2c85504                             
02c854f8: ldp     x20, x19, [sp, #0x10]                      
02c854fc: ldr     x30, [sp], #0x20                           
02c85500: ret                                                
02c85504: adrp    x8, #0x6263000                             
02c85508: ldr     x8, [x8, #0x928]                           T:UnityEngine.Debug
02c8550c: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c85510: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c85514: cbnz    w8, #0x2c8551c                             
02c85518: bl      #0x2b70f30                                 fn_2b70f30
02c8551c: adrp    x8, #0x6264000                             
02c85520: mov     x1, xzr                                    
02c85524: ldr     x8, [x8, #0xc58]                           S:'Interstitial activity destroyed without being closed first.'
02c85528: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c8552c: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02c85530: adrp    x8, #0x6264000                             
02c85534: mov     x1, xzr                                    
02c85538: ldr     x8, [x8, #0xc60]                           S:'Game should resume.'
02c8553c: ldp     x20, x19, [sp, #0x10]                      
02c85540: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c85544: ldr     x30, [sp], #0x20                           
02c85548: b       #0x5af21f4                                 UnityEngine.Debug::Log
