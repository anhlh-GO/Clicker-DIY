#### CLASS LanguageUIItem parent= UnityEngine.MonoBehaviour
#   field _imgFlag                       UnityEngine.UI.Image                               off=0x20 attr=1 SerializeField
#   field _txtRegion                     TMPro.TextMeshProUGUI                              off=0x28 attr=1 SerializeField
#   field _goSelected                    UnityEngine.GameObject                             off=0x30 attr=1 SerializeField
#   field _colorSelected                 UnityEngine.Color                                  off=0x38 attr=1 SerializeField
#   field _colorNormal                   UnityEngine.Color                                  off=0x48 attr=1 SerializeField
#   field _cachedData                    LanguageDataItem                                   off=0x58 attr=1 
#   field Selected                       bool                                               off=0x60 attr=6 
## get_Data() -> LanguageDataItem
---- LanguageUIItem::get_Data 0x2caff8c
02caff8c: ldr     x0, [x0, #0x58]                            ._cachedData
02caff90: ret                                                
## SetData(LanguageDataItem data) -> void
---- LanguageUIItem::SetData 0x2caff94
02caff94: stp     x30, x21, [sp, #-0x20]!                    
02caff98: stp     x20, x19, [sp, #0x10]                      
02caff9c: adrp    x21, #0x662f000                            
02caffa0: mov     x20, x1                                    
02caffa4: mov     x19, x0                                    
02caffa8: ldrb    w8, [x21, #0xb61]                          
02caffac: tbnz    w8, #0, #0x2caffc4                         
02caffb0: adrp    x0, #0x6266000                             
02caffb4: ldr     x0, [x0, #0x9f0]                           T:Assets.SimpleLocalization.Scripts.LocalizationManager
02caffb8: bl      #0x2b70db0                                 fn_2b70db0
02caffbc: mov     w8, #1                                     
02caffc0: strb    w8, [x21, #0xb61]                          
02caffc4: mov     x0, x19                                    
02caffc8: mov     x1, xzr                                    
02caffcc: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02caffd0: cbz     x20, #0x2cb0094                            
02caffd4: cbz     x0, #0x2cb0098                             
02caffd8: mov     w1, #1                                     
02caffdc: mov     x2, xzr                                    
02caffe0: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02caffe4: mov     x21, x19                                   
02caffe8: mov     x1, x20                                    
02caffec: str     x20, [x21, #0x58]!                         ._cachedData
02cafff0: mov     x0, x21                                    
02cafff4: bl      #0x2b70d54                                 fn_2b70d54
02cafff8: ldur    x0, [x21, #-0x38]                          
02cafffc: cbz     x0, #0x2cb0098                             
02cb0000: adrp    x21, #0x6266000                            
02cb0004: mov     x2, xzr                                    
02cb0008: ldr     x21, [x21, #0x9f0]                         T:Assets.SimpleLocalization.Scripts.LocalizationManager
02cb000c: ldr     x1, [x20, #0x20]                           ._imgFlag
02cb0010: bl      #0x5c45aa0                                 UnityEngine.UI.Image::set_sprite
02cb0014: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb0018: ldr     x21, [x19, #0x28]                          ._txtRegion
02cb001c: ldr     x20, [x20, #0x18]                          
02cb0020: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02cb0024: cbnz    w8, #0x2cb002c                             
02cb0028: bl      #0x2b70f30                                 fn_2b70f30
02cb002c: mov     x0, x20                                    
02cb0030: mov     x1, xzr                                    
02cb0034: bl      #0x2d76794                                 Assets.SimpleLocalization.Scripts.LocalizationManager::Localize
02cb0038: cbz     x21, #0x2cb0098                            
02cb003c: ldr     x8, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb0040: mov     x1, x0                                     
02cb0044: mov     x0, x21                                    
02cb0048: ldr     x9, [x8, #0x558]                           
02cb004c: ldr     x2, [x8, #0x560]                           
02cb0050: blr     x9                                         
02cb0054: ldr     x0, [x19, #0x28]                           ._txtRegion
02cb0058: cbz     x0, #0x2cb0098                             
02cb005c: ldr     x8, [x0]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb0060: ldp     s2, s3, [x19, #0x50]                       
02cb0064: ldp     s0, s1, [x19, #0x48]                       ._colorNormal
02cb0068: ldr     x9, [x8, #0x2a8]                           
02cb006c: ldr     x1, [x8, #0x2b0]                           
02cb0070: blr     x9                                         
02cb0074: ldr     x0, [x19, #0x30]                           ._goSelected
02cb0078: strb    wzr, [x19, #0x60]                          .Selected
02cb007c: cbz     x0, #0x2cb0098                             
02cb0080: ldp     x20, x19, [sp, #0x10]                      
02cb0084: mov     w1, wzr                                    
02cb0088: mov     x2, xzr                                    
02cb008c: ldp     x30, x21, [sp], #0x20                      
02cb0090: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cb0094: cbnz    x0, #0x2cb0080                             
02cb0098: bl      #0x2b7105c                                 fn_2b7105c
## ReloadText() -> void
---- LanguageUIItem::ReloadText 0x2cb009c
02cb009c: str     x30, [sp, #-0x20]!                         
02cb00a0: stp     x20, x19, [sp, #0x10]                      
02cb00a4: adrp    x20, #0x662f000                            
02cb00a8: mov     x19, x0                                    
02cb00ac: ldrb    w8, [x20, #0xb62]                          
02cb00b0: tbnz    w8, #0, #0x2cb00c8                         
02cb00b4: adrp    x0, #0x6266000                             
02cb00b8: ldr     x0, [x0, #0x9f0]                           T:Assets.SimpleLocalization.Scripts.LocalizationManager
02cb00bc: bl      #0x2b70db0                                 fn_2b70db0
02cb00c0: mov     w8, #1                                     
02cb00c4: strb    w8, [x20, #0xb62]                          
02cb00c8: ldr     x8, [x19, #0x58]                           ._cachedData
02cb00cc: cbz     x8, #0x2cb0120                             
02cb00d0: adrp    x9, #0x6266000                             
02cb00d4: ldr     x9, [x9, #0x9f0]                           T:Assets.SimpleLocalization.Scripts.LocalizationManager
02cb00d8: ldr     x19, [x19, #0x28]                          ._txtRegion
02cb00dc: ldr     x20, [x8, #0x18]                           
02cb00e0: ldr     x0, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb00e4: ldr     w9, [x0, #0xe4]                            [62660e4]=0 f=0,0
02cb00e8: cbnz    w9, #0x2cb00f0                             
02cb00ec: bl      #0x2b70f30                                 fn_2b70f30
02cb00f0: mov     x0, x20                                    
02cb00f4: mov     x1, xzr                                    
02cb00f8: bl      #0x2d76794                                 Assets.SimpleLocalization.Scripts.LocalizationManager::Localize
02cb00fc: cbz     x19, #0x2cb0120                            
02cb0100: ldr     x8, [x19]                                  
02cb0104: mov     x1, x0                                     
02cb0108: mov     x0, x19                                    
02cb010c: ldp     x20, x19, [sp, #0x10]                      
02cb0110: ldr     x2, [x8, #0x560]                           
02cb0114: ldr     x3, [x8, #0x558]                           
02cb0118: ldr     x30, [sp], #0x20                           
02cb011c: br      x3                                         
02cb0120: bl      #0x2b7105c                                 fn_2b7105c
## Select(bool select) -> void
---- LanguageUIItem::Select 0x2cb0124
02cb0124: stp     x30, x19, [sp, #-0x10]!                    
02cb0128: mov     x19, x0                                    
02cb012c: ldr     x0, [x0, #0x30]                            ._goSelected
02cb0130: strb    w1, [x19, #0x60]                           .Selected
02cb0134: cbz     x0, #0x2cb0168                             
02cb0138: and     w1, w1, #1                                 
02cb013c: mov     x2, xzr                                    
02cb0140: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cb0144: ldr     x0, [x19, #0x28]                           ._txtRegion
02cb0148: cbz     x0, #0x2cb0168                             
02cb014c: ldr     x8, [x0]                                   
02cb0150: ldp     s0, s1, [x19, #0x48]                       ._colorNormal
02cb0154: ldp     s2, s3, [x19, #0x50]                       
02cb0158: ldr     x2, [x8, #0x2a8]                           
02cb015c: ldr     x1, [x8, #0x2b0]                           
02cb0160: ldp     x30, x19, [sp], #0x10                      
02cb0164: br      x2                                         
02cb0168: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- LanguageUIItem::.ctor 0x2cb016c
02cb016c: mov     x1, xzr                                    
02cb0170: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
