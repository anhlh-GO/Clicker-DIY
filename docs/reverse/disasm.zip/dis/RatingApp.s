#### CLASS RatingApp/<StartRequestReview>d__0 parent= System.ValueType
#   field <>1__state                     int                                                off=0x10 attr=6 
#   field <>t__builder                   System.Runtime.CompilerServices.AsyncVoidMethodBuilder off=0x18 attr=6 
## MoveNext() -> void
---- RatingApp/<StartRequestReview>d__0::MoveNext 0x2ca80f4
02ca80f4: mov     w8, #-2                                    
02ca80f8: mov     x1, xzr                                    
02ca80fc: str     w8, [x0], #8                               
02ca8100: b       #0x4d43b50                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::SetResult
## SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine stateMachine) -> void
---- RatingApp/<StartRequestReview>d__0::SetStateMachine 0x2ca8104
02ca8104: add     x0, x0, #8                                 
02ca8108: mov     x2, xzr                                    
02ca810c: b       #0x4d43a8c                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::SetStateMachine
#### CLASS RatingApp parent= object
## StartRequestReview() -> void
---- RatingApp::StartRequestReview 0x2ca8064
02ca8064: sub     sp, sp, #0x70                              
02ca8068: str     x30, [sp, #0x50]                           
02ca806c: stp     x20, x19, [sp, #0x60]                      
02ca8070: adrp    x20, #0x662f000                            
02ca8074: adrp    x19, #0x6266000                            
02ca8078: ldrb    w8, [x20, #0xaeb]                          
02ca807c: ldr     x19, [x19, #0x540]                         MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::Start
02ca8080: tbnz    w8, #0, #0x2ca8098                         
02ca8084: adrp    x0, #0x6266000                             
02ca8088: ldr     x0, [x0, #0x540]                           MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::Start
02ca808c: bl      #0x2b70db0                                 fn_2b70db0
02ca8090: mov     w8, #1                                     
02ca8094: strb    w8, [x20, #0xaeb]                          
02ca8098: movi    v0.2d, #0000000000000000                   
02ca809c: mov     x8, sp                                     
02ca80a0: mov     x0, xzr                                    
02ca80a4: str     xzr, [sp, #0x40]                           
02ca80a8: stp     q0, q0, [sp, #0x20]                        
02ca80ac: bl      #0x4d43a24                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::Create
02ca80b0: ldp     q0, q1, [sp]                               
02ca80b4: add     x20, sp, #0x20                             
02ca80b8: orr     x0, x20, #8                                
02ca80bc: mov     x1, xzr                                    
02ca80c0: stur    q0, [sp, #0x28]                            
02ca80c4: stur    q1, [sp, #0x38]                            
02ca80c8: bl      #0x2b70d54                                 fn_2b70d54
02ca80cc: ldr     x2, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca80d0: mov     w8, #-1                                    
02ca80d4: orr     x0, x20, #8                                
02ca80d8: add     x1, sp, #0x20                              
02ca80dc: str     w8, [sp, #0x20]                            
02ca80e0: bl      #0x30c8dc0                                 fn_30c8dc0
02ca80e4: ldp     x20, x19, [sp, #0x60]                      
02ca80e8: ldr     x30, [sp, #0x50]                           
02ca80ec: add     sp, sp, #0x70                              
02ca80f0: ret                                                
