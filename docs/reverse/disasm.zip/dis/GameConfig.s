#### CLASS GameConfig parent= object
#   field PanelHidePosX                  int                                                off=0x0 attr=16 
#   field DefaultDuration                float                                              off=0x4 attr=16 
#   field HomeScene                      string                                             off=0x8 attr=16 
#   field DreamHouseScene                string                                             off=0x10 attr=16 
#   field BlindbagScene                  string                                             off=0x18 attr=16 
#   field BlindbagCollection             string                                             off=0x20 attr=16 
#   field ClickerScene                   string                                             off=0x28 attr=16 
#   field ScoopGameScene                 string                                             off=0x30 attr=16 
#   field SpawnCommentTimer              float                                              off=0x38 attr=16 
#   field DistanceComment                float                                              off=0x3c attr=16 
#   field TimeToFreeLuckyWheel           float                                              off=0x40 attr=16 
#   field BonusTime                      float                                              off=0x44 attr=16 
#   field MoveSpeed                      float                                              off=0x48 attr=16 
#   field InGameMissionReward            int                                                off=0x4c attr=16 
#   field BonusMoneyReward               int                                                off=0x50 attr=16 
#   field DefaultMoneyReward             int                                                off=0x54 attr=16 
#   field MinViewers                     int                                                off=0x58 attr=16 
#   field MaxViewers                     int                                                off=0x5c attr=16 
#   field PlayCountUnlockDecor           int                                                off=0x60 attr=16 
#   field PlayCountUnlockDreamHouse      int                                                off=0x64 attr=16 
#   field PlayCountUnlockDumplingBlindBox int                                                off=0x68 attr=16 
#   field PlayCountUnlockLuckyScoop      int                                                off=0x6c attr=16 
#   field PlayCountUnlockIdleChest       int                                                off=0x70 attr=16 
#   field PlayCountUnlockBlindBag        int                                                off=0x74 attr=16 
#   field PlayCountUnlockDailyTask       int                                                off=0x78 attr=16 
#   field PlayCountUnlockPartTime        int                                                off=0x7c attr=16 
#   field BlinkInterval                  float                                              off=0x80 attr=16 
#   field MinStartIconAnim               float                                              off=0x84 attr=16 
#   field MaxStartIconAnim               float                                              off=0x88 attr=16 
#   field XpToNextLevel                  int                                                off=0x8c attr=16 
#   field MoneyRightCharm                int                                                off=0x90 attr=16 
#   field MoneyWrongCharm                int                                                off=0x94 attr=16 
#   field MoneySuppriseOrder             int                                                off=0x98 attr=16 
#   field MinimumTip                     int                                                off=0x9c attr=16 
#   field QuestId_BuyNewSkin             int                                                off=0xa0 attr=16 
#   field QuestId_Collect200Coin         int                                                off=0xa4 attr=16 
#   field QuestId_Collect500Coin         int                                                off=0xa8 attr=16 
#   field QuestId_Play10Minutes          int                                                off=0xac attr=16 
#   field QuestId_BuyDecor               int                                                off=0xb0 attr=16 
#   field QuestId_Collect1000Coin        int                                                off=0xb4 attr=16 
#   field QuestId_Play12Minutes          int                                                off=0xb8 attr=16 
#   field MaxKeycapAmount                int                                                off=0xbc attr=16 
## .ctor() -> void
---- GameConfig::.ctor 0x2ca868c
02ca868c: mov     x1, xzr                                    
02ca8690: b       #0x4e53e9c                                 System.Object::.ctor
## .cctor() -> void
---- GameConfig::.cctor 0x2cac500
02cac500: str     x30, [sp, #-0x50]!                         
02cac504: stp     x26, x25, [sp, #0x10]                      
02cac508: stp     x24, x23, [sp, #0x20]                      
02cac50c: stp     x22, x21, [sp, #0x30]                      
02cac510: stp     x20, x19, [sp, #0x40]                      
02cac514: adrp    x19, #0x6266000                            
02cac518: adrp    x25, #0x6266000                            
02cac51c: adrp    x24, #0x6266000                            
02cac520: adrp    x23, #0x6266000                            
02cac524: adrp    x26, #0x662f000                            
02cac528: adrp    x22, #0x6266000                            
02cac52c: adrp    x21, #0x6266000                            
02cac530: adrp    x20, #0x6266000                            
02cac534: ldr     x19, [x19, #0x5e0]                         T:GameConfig
02cac538: ldr     x25, [x25, #0x828]                         S:'Assets/_Game/Scenes/Home.unity'
02cac53c: ldr     x24, [x24, #0x830]                         S:'Assets/_Game/Scenes/DreamHouse.unity'
02cac540: ldr     x23, [x23, #0x838]                         S:'Assets/_Game/Scenes/BlindbagMinigame.unity'
02cac544: ldr     x22, [x22, #0x840]                         S:'Assets/_Game/Scenes/BlindBagCollection.unity'
02cac548: ldrb    w8, [x26, #0xb32]                          
02cac54c: ldr     x21, [x21, #0x848]                         S:'Assets/_Game/Scenes/ModeClicker.unity'
02cac550: ldr     x20, [x20, #0x850]                         S:'Assets/_Game/Scenes/ScoopGame.unity'
02cac554: tbnz    w8, #0, #0x2cac5b4                         
02cac558: adrp    x0, #0x6266000                             
02cac55c: ldr     x0, [x0, #0x5e0]                           T:GameConfig
02cac560: bl      #0x2b70db0                                 fn_2b70db0
02cac564: adrp    x0, #0x6266000                             
02cac568: ldr     x0, [x0, #0x828]                           S:'Assets/_Game/Scenes/Home.unity'
02cac56c: bl      #0x2b70db0                                 fn_2b70db0
02cac570: adrp    x0, #0x6266000                             
02cac574: ldr     x0, [x0, #0x838]                           S:'Assets/_Game/Scenes/BlindbagMinigame.unity'
02cac578: bl      #0x2b70db0                                 fn_2b70db0
02cac57c: adrp    x0, #0x6266000                             
02cac580: ldr     x0, [x0, #0x848]                           S:'Assets/_Game/Scenes/ModeClicker.unity'
02cac584: bl      #0x2b70db0                                 fn_2b70db0
02cac588: adrp    x0, #0x6266000                             
02cac58c: ldr     x0, [x0, #0x840]                           S:'Assets/_Game/Scenes/BlindBagCollection.unity'
02cac590: bl      #0x2b70db0                                 fn_2b70db0
02cac594: adrp    x0, #0x6266000                             
02cac598: ldr     x0, [x0, #0x830]                           S:'Assets/_Game/Scenes/DreamHouse.unity'
02cac59c: bl      #0x2b70db0                                 fn_2b70db0
02cac5a0: adrp    x0, #0x6266000                             
02cac5a4: ldr     x0, [x0, #0x850]                           S:'Assets/_Game/Scenes/ScoopGame.unity'
02cac5a8: bl      #0x2b70db0                                 fn_2b70db0
02cac5ac: mov     w8, #1                                     
02cac5b0: strb    w8, [x26, #0xb32]                          
02cac5b4: ldr     x8, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cac5b8: ldr     x0, [x8, #0xb8]                            
02cac5bc: mov     x8, #0x514                                 
02cac5c0: movk    x8, #0x51ec, lsl #32                       
02cac5c4: movk    x8, #0x3eb8, lsl #48                       
02cac5c8: str     x8, [x0]                                   
02cac5cc: ldr     x1, [x25]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cac5d0: str     x1, [x0, #8]!                              
02cac5d4: bl      #0x2b70d54                                 fn_2b70d54
02cac5d8: ldr     x8, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cac5dc: ldr     x1, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cac5e0: ldr     x0, [x8, #0xb8]                            
02cac5e4: str     x1, [x0, #0x10]!                           .DreamHouseScene
02cac5e8: bl      #0x2b70d54                                 fn_2b70d54
02cac5ec: ldr     x8, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cac5f0: ldr     x1, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cac5f4: ldr     x0, [x8, #0xb8]                            
02cac5f8: str     x1, [x0, #0x18]!                           .BlindbagScene
02cac5fc: bl      #0x2b70d54                                 fn_2b70d54
02cac600: ldr     x8, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cac604: ldr     x1, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cac608: ldr     x0, [x8, #0xb8]                            
02cac60c: str     x1, [x0, #0x20]!                           .BlindbagCollection
02cac610: bl      #0x2b70d54                                 fn_2b70d54
02cac614: ldr     x8, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cac618: ldr     x1, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cac61c: ldr     x0, [x8, #0xb8]                            
02cac620: str     x1, [x0, #0x28]!                           .ClickerScene
02cac624: bl      #0x2b70d54                                 fn_2b70d54
02cac628: ldr     x8, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cac62c: ldr     x1, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cac630: ldr     x0, [x8, #0xb8]                            
02cac634: str     x1, [x0, #0x30]!                           .ScoopGameScene
02cac638: bl      #0x2b70d54                                 fn_2b70d54
02cac63c: ldr     x8, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cac640: adrp    x9, #0x1085000                             
02cac644: ldr     q0, [x9, #0xeb0]                           [1085eb0]=434800003f4ccccd f=0.8,200
02cac648: adrp    x9, #0x1087000                             
02cac64c: ldr     x8, [x8, #0xb8]                            
02cac650: ldr     q1, [x9, #0x8b0]                           [10878b0]=bb80000076c f=2.66247e-42,4.2039e-42
02cac654: adrp    x9, #0x1086000                             
02cac658: ldp     x20, x19, [sp, #0x40]                      
02cac65c: stur    q0, [x8, #0x38]                            
02cac660: ldr     q0, [x9, #0xb40]                           [1086b40]=55f0 f=3.08286e-41,0
02cac664: adrp    x9, #0x1088000                             
02cac668: stur    q1, [x8, #0x4c]                            
02cac66c: ldr     q1, [x9, #0xc0]                            [10880c0]=400000003 f=4.2039e-45,5.60519e-45
02cac670: adrp    x9, #0x1041000                             
02cac674: stur    q0, [x8, #0x5c]                            
02cac678: ldr     d0, [x9, #0x130]                           [1041130]=400000003e99999a f=0.3,2
02cac67c: adrp    x9, #0x1085000                             
02cac680: ldp     x22, x21, [sp, #0x30]                      
02cac684: stur    q1, [x8, #0x6c]                            
02cac688: str     d0, [x8, #0x80]                            
02cac68c: ldr     q0, [x9, #0xec0]                           [1085ec0]=1f400000019 f=3.50325e-44,7.00649e-43
02cac690: mov     w9, #0x41200000                            
02cac694: str     w9, [x8, #0x48]                            
02cac698: adrp    x9, #0x1087000                             
02cac69c: stur    q0, [x8, #0x8c]                            
02cac6a0: ldr     q0, [x9, #0x8c0]                           [10878c0]=64 f=1.4013e-43,0
02cac6a4: mov     w9, #8                                     
02cac6a8: str     w9, [x8, #0x7c]                            
02cac6ac: adrp    x9, #0x1086000                             
02cac6b0: stur    q0, [x8, #0x9c]                            
02cac6b4: ldr     q0, [x9, #0x7c0]                           [10867c0]=400000003 f=4.2039e-45,5.60519e-45
02cac6b8: mov     w9, #0x40c00000                            
02cac6bc: ldp     x24, x23, [sp, #0x20]                      
02cac6c0: str     w9, [x8, #0x88]                            
02cac6c4: ldp     x26, x25, [sp, #0x10]                      
02cac6c8: mov     w9, #0xc                                   
02cac6cc: stur    q0, [x8, #0xac]                            
02cac6d0: str     w9, [x8, #0xbc]                            
02cac6d4: ldr     x30, [sp], #0x50                           
02cac6d8: ret                                                
