#### CLASS Assets.SimpleLocalization.Scripts.Constants parent= object
#   field LocalizationEditorUrl          string                                             off=0x0 attr=8056 
#   field SheetResolverUrl               string                                             off=0x0 attr=8056 
#   field AssetUrlFree                   string                                             off=0x0 attr=8056 
#   field AssetUrlPro                    string                                             off=0x0 attr=8056 
#   field TableUrlPattern                string                                             off=0x0 attr=8056 
#   field ExampleTableId                 string                                             off=0x0 attr=8056 
#   field ExampleSheets                  System.Collections.Generic.Dictionary`2<string,int> off=0x0 attr=36 
## .cctor() -> void
---- Assets.SimpleLocalization.Scripts.Constants::.cctor 0x2d7b010
02d7b010: stp     x30, x23, [sp, #-0x30]!                    
02d7b014: stp     x22, x21, [sp, #0x10]                      
02d7b018: stp     x20, x19, [sp, #0x20]                      
02d7b01c: adrp    x20, #0x6630000                            
02d7b020: adrp    x21, #0x626c000                            
02d7b024: adrp    x19, #0x626c000                            
02d7b028: ldrb    w8, [x20, #0x401]                          
02d7b02c: ldr     x21, [x21, #0xb08]                         T:type8911(k15)
02d7b030: ldr     x19, [x19, #0xb10]                         MS:System.Collections.Generic.Dictionary`2::.ctor
02d7b034: tbnz    w8, #0, #0x2d7b094                         
02d7b038: adrp    x0, #0x626c000                             
02d7b03c: ldr     x0, [x0, #0xb18]                           T:Assets.SimpleLocalization.Scripts.Constants
02d7b040: bl      #0x2b70db0                                 fn_2b70db0
02d7b044: adrp    x0, #0x626c000                             
02d7b048: ldr     x0, [x0, #0xb20]                           MS:System.Collections.Generic.Dictionary`2::Add
02d7b04c: bl      #0x2b70db0                                 fn_2b70db0
02d7b050: adrp    x0, #0x626c000                             
02d7b054: ldr     x0, [x0, #0xb10]                           MS:System.Collections.Generic.Dictionary`2::.ctor
02d7b058: bl      #0x2b70db0                                 fn_2b70db0
02d7b05c: adrp    x0, #0x626c000                             
02d7b060: ldr     x0, [x0, #0xb08]                           T:type8911(k15)
02d7b064: bl      #0x2b70db0                                 fn_2b70db0
02d7b068: adrp    x0, #0x626c000                             
02d7b06c: ldr     x0, [x0, #0xb28]                           S:'Menu'
02d7b070: bl      #0x2b70db0                                 fn_2b70db0
02d7b074: adrp    x0, #0x626c000                             
02d7b078: ldr     x0, [x0, #0xb30]                           S:'Settings'
02d7b07c: bl      #0x2b70db0                                 fn_2b70db0
02d7b080: adrp    x0, #0x626c000                             
02d7b084: ldr     x0, [x0, #0xb38]                           S:'Tests'
02d7b088: bl      #0x2b70db0                                 fn_2b70db0
02d7b08c: mov     w8, #1                                     
02d7b090: strb    w8, [x20, #0x401]                          
02d7b094: ldr     x0, [x21]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7b098: bl      #0x2b7104c                                 fn_2b7104c
02d7b09c: ldr     x1, [x19]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7b0a0: mov     x19, x0                                    
02d7b0a4: bl      #0x4521238                                 fn_4521238
02d7b0a8: cbz     x19, #0x2d7b140                            
02d7b0ac: adrp    x8, #0x626c000                             
02d7b0b0: adrp    x20, #0x626c000                            
02d7b0b4: adrp    x21, #0x626c000                            
02d7b0b8: ldr     x8, [x8, #0xb28]                           S:'Menu'
02d7b0bc: ldr     x20, [x20, #0xb20]                         MS:System.Collections.Generic.Dictionary`2::Add
02d7b0c0: adrp    x22, #0x626c000                            
02d7b0c4: adrp    x23, #0x626c000                            
02d7b0c8: ldr     x21, [x21, #0xb30]                         S:'Settings'
02d7b0cc: ldr     x22, [x22, #0xb38]                         S:'Tests'
02d7b0d0: ldr     x23, [x23, #0xb18]                         T:Assets.SimpleLocalization.Scripts.Constants
02d7b0d4: ldr     x1, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7b0d8: ldr     x3, [x20]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7b0dc: mov     x0, x19                                    
02d7b0e0: mov     w2, wzr                                    
02d7b0e4: bl      #0x4521fb8                                 fn_4521fb8
02d7b0e8: ldr     x1, [x21]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7b0ec: ldr     x3, [x20]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7b0f0: mov     w2, #0x9eed                                
02d7b0f4: mov     x0, x19                                    
02d7b0f8: movk    w2, #0x13c9, lsl #16                       
02d7b0fc: bl      #0x4521fb8                                 fn_4521fb8
02d7b100: ldr     x1, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7b104: ldr     x3, [x20]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7b108: mov     w2, #0x98b1                                
02d7b10c: mov     x0, x19                                    
02d7b110: movk    w2, #0x63cc, lsl #16                       
02d7b114: bl      #0x4521fb8                                 fn_4521fb8
02d7b118: ldr     x8, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7b11c: mov     x1, x19                                    
02d7b120: ldp     x22, x21, [sp, #0x10]                      
02d7b124: ldr     x8, [x8, #0xb8]                            MS:System.Collections.Generic.List`1::Add
02d7b128: str     x19, [x8]                                  
02d7b12c: ldp     x20, x19, [sp, #0x20]                      
02d7b130: ldr     x8, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7b134: ldr     x0, [x8, #0xb8]                            MS:System.Collections.Generic.List`1::Add
02d7b138: ldp     x30, x23, [sp], #0x30                      
02d7b13c: b       #0x2b70d54                                 
02d7b140: bl      #0x2b7105c                                 fn_2b7105c
