#### CLASS Clicker.Light2DManager/<>c parent= object
#   field <>9                            Clicker.Light2DManager/<>c                         off=0x0 attr=36 
#   field <>9__5_0                       System.Predicate`1<Clicker.GlowSprite2DItem>       off=0x8 attr=16 
#   field <>9__6_0                       System.Predicate`1<Clicker.GlowSprite2DItem>       off=0x10 attr=16 
## .cctor() -> void
---- Clicker.Light2DManager/<>c::.cctor 0x2d6427c
02d6427c: str     x30, [sp, #-0x20]!                         
02d64280: stp     x20, x19, [sp, #0x10]                      
02d64284: adrp    x19, #0x6630000                            
02d64288: adrp    x20, #0x626c000                            
02d6428c: ldrb    w8, [x19, #0x318]                          
02d64290: ldr     x20, [x20, #0x80]                          T:Clicker.Light2DManager/<>c
02d64294: tbnz    w8, #0, #0x2d642ac                         
02d64298: adrp    x0, #0x626c000                             
02d6429c: ldr     x0, [x0, #0x80]                            T:Clicker.Light2DManager/<>c
02d642a0: bl      #0x2b70db0                                 fn_2b70db0
02d642a4: mov     w8, #1                                     
02d642a8: strb    w8, [x19, #0x318]                          
02d642ac: ldr     x0, [x20]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d642b0: bl      #0x2b7104c                                 fn_2b7104c
02d642b4: mov     x1, xzr                                    
02d642b8: mov     x19, x0                                    
02d642bc: bl      #0x4e53e9c                                 System.Object::.ctor
02d642c0: ldr     x8, [x20]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d642c4: mov     x1, x19                                    
02d642c8: ldr     x8, [x8, #0xb8]                            
02d642cc: str     x19, [x8]                                  
02d642d0: ldr     x8, [x20]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d642d4: ldp     x20, x19, [sp, #0x10]                      
02d642d8: ldr     x0, [x8, #0xb8]                            
02d642dc: ldr     x30, [sp], #0x20                           
02d642e0: b       #0x2b70d54                                 
## .ctor() -> void
---- Clicker.Light2DManager/<>c::.ctor 0x2d642e4
02d642e4: mov     x1, xzr                                    
02d642e8: b       #0x4e53e9c                                 System.Object::.ctor
## <GetAvailableItem>b__5_0(Clicker.GlowSprite2DItem item) -> bool
---- Clicker.Light2DManager/<>c::<GetAvailableItem>b__5_0 0x2d642ec
02d642ec: stp     x30, x21, [sp, #-0x20]!                    
02d642f0: stp     x20, x19, [sp, #0x10]                      
02d642f4: adrp    x20, #0x6630000                            
02d642f8: adrp    x21, #0x6263000                            
02d642fc: mov     x19, x1                                    
02d64300: ldrb    w8, [x20, #0x319]                          
02d64304: ldr     x21, [x21, #0x918]                         T:UnityEngine.Object
02d64308: tbnz    w8, #0, #0x2d64320                         
02d6430c: adrp    x0, #0x6263000                             
02d64310: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d64314: bl      #0x2b70db0                                 fn_2b70db0
02d64318: mov     w8, #1                                     
02d6431c: strb    w8, [x20, #0x319]                          
02d64320: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d64324: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d64328: cbnz    w8, #0x2d64330                             
02d6432c: bl      #0x2b70f30                                 fn_2b70f30
02d64330: mov     x0, x19                                    
02d64334: mov     x1, xzr                                    
02d64338: mov     x2, xzr                                    
02d6433c: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d64340: tbz     w0, #0, #0x2d64368                         
02d64344: cbz     x19, #0x2d6437c                            
02d64348: mov     x0, x19                                    
02d6434c: mov     x1, xzr                                    
02d64350: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d64354: cbz     x0, #0x2d6437c                             
02d64358: mov     x1, xzr                                    
02d6435c: bl      #0x5b36bfc                                 UnityEngine.GameObject::get_activeSelf
02d64360: eor     w8, w0, #1                                 
02d64364: b       #0x2d6436c                                 
02d64368: mov     w8, wzr                                    
02d6436c: ldp     x20, x19, [sp, #0x10]                      
02d64370: and     w0, w8, #1                                 
02d64374: ldp     x30, x21, [sp], #0x20                      
02d64378: ret                                                
02d6437c: bl      #0x2b7105c                                 fn_2b7105c
## <RemoveMissingItems>b__6_0(Clicker.GlowSprite2DItem item) -> bool
---- Clicker.Light2DManager/<>c::<RemoveMissingItems>b__6_0 0x2d64380
02d64380: stp     x30, x21, [sp, #-0x20]!                    
02d64384: stp     x20, x19, [sp, #0x10]                      
02d64388: adrp    x20, #0x6630000                            
02d6438c: adrp    x21, #0x6263000                            
02d64390: mov     x19, x1                                    
02d64394: ldrb    w8, [x20, #0x31a]                          
02d64398: ldr     x21, [x21, #0x918]                         T:UnityEngine.Object
02d6439c: tbnz    w8, #0, #0x2d643b4                         
02d643a0: adrp    x0, #0x6263000                             
02d643a4: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d643a8: bl      #0x2b70db0                                 fn_2b70db0
02d643ac: mov     w8, #1                                     
02d643b0: strb    w8, [x20, #0x31a]                          
02d643b4: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d643b8: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d643bc: cbnz    w8, #0x2d643c4                             
02d643c0: bl      #0x2b70f30                                 fn_2b70f30
02d643c4: mov     x0, x19                                    
02d643c8: ldp     x20, x19, [sp, #0x10]                      
02d643cc: mov     x1, xzr                                    
02d643d0: mov     x2, xzr                                    
02d643d4: ldp     x30, x21, [sp], #0x20                      
02d643d8: b       #0x5b37d84                                 UnityEngine.Object::op_Equality
#### CLASS Clicker.Light2DManager parent= MonoSingleton`1<Clicker.Light2DManager>
#   field _tfLightPoolHolder             UnityEngine.Transform                              off=0x20 attr=1 SerializeField
#   field _glowItems                     System.Collections.Generic.List`1<Clicker.GlowSprite2DItem> off=0x28 attr=1 SerializeField
## BorrowGlowItem(UnityEngine.Transform parent) -> Clicker.GlowSprite2DItem
---- Clicker.Light2DManager::BorrowGlowItem 0x2d63b98
02d63b98: str     x30, [sp, #-0x30]!                         
02d63b9c: stp     x22, x21, [sp, #0x10]                      
02d63ba0: stp     x20, x19, [sp, #0x20]                      
02d63ba4: adrp    x19, #0x6630000                            
02d63ba8: adrp    x22, #0x6263000                            
02d63bac: mov     x20, x1                                    
02d63bb0: ldrb    w8, [x19, #0x312]                          
02d63bb4: ldr     x22, [x22, #0x918]                         T:UnityEngine.Object
02d63bb8: mov     x21, x0                                    
02d63bbc: tbnz    w8, #0, #0x2d63bd4                         
02d63bc0: adrp    x0, #0x6263000                             
02d63bc4: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d63bc8: bl      #0x2b70db0                                 fn_2b70db0
02d63bcc: mov     w8, #1                                     
02d63bd0: strb    w8, [x19, #0x312]                          
02d63bd4: ldr     x0, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d63bd8: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d63bdc: cbnz    w8, #0x2d63be4                             
02d63be0: bl      #0x2b70f30                                 fn_2b70f30
02d63be4: mov     x0, x20                                    
02d63be8: mov     x1, xzr                                    
02d63bec: mov     x2, xzr                                    
02d63bf0: bl      #0x5b37d84                                 UnityEngine.Object::op_Equality
02d63bf4: mov     x19, xzr                                   
02d63bf8: tbnz    w0, #0, #0x2d63c7c                         
02d63bfc: mov     x0, x21                                    
02d63c00: bl      #0x2d63e70                                 Clicker.Light2DManager::GetAvailableItem
02d63c04: cbz     x0, #0x2d63c90                             
02d63c08: mov     x1, xzr                                    
02d63c0c: mov     x19, x0                                    
02d63c10: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d63c14: cbz     x0, #0x2d63c90                             
02d63c18: mov     x1, x20                                    
02d63c1c: mov     x2, xzr                                    
02d63c20: bl      #0x5b472ec                                 UnityEngine.Transform::SetParent
02d63c24: mov     x0, x19                                    
02d63c28: mov     x1, xzr                                    
02d63c2c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d63c30: adrp    x21, #0x662f000                            
02d63c34: mov     x20, x0                                    
02d63c38: ldrb    w8, [x21, #0x91a]                          
02d63c3c: cbnz    w8, #0x2d63c54                             
02d63c40: adrp    x0, #0x6264000                             
02d63c44: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d63c48: bl      #0x2b70db0                                 fn_2b70db0
02d63c4c: mov     w8, #1                                     
02d63c50: strb    w8, [x21, #0x91a]                          
02d63c54: cbz     x20, #0x2d63c90                            
02d63c58: adrp    x8, #0x6264000                             
02d63c5c: mov     x0, x20                                    
02d63c60: mov     x1, xzr                                    
02d63c64: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02d63c68: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d63c6c: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d63c70: ldp     s1, s2, [x8, #4]                           
02d63c74: ldr     s0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d63c78: bl      #0x5b45cec                                 UnityEngine.Transform::set_localPosition
02d63c7c: mov     x0, x19                                    
02d63c80: ldp     x20, x19, [sp, #0x20]                      
02d63c84: ldp     x22, x21, [sp, #0x10]                      
02d63c88: ldr     x30, [sp], #0x30                           
02d63c8c: ret                                                
02d63c90: bl      #0x2b7105c                                 fn_2b7105c
## ReleaseAllItem() -> void
---- Clicker.Light2DManager::ReleaseAllItem 0x2d5d5ec
02d5d5ec: sub     sp, sp, #0x70                              
02d5d5f0: stp     x30, x23, [sp, #0x40]                      
02d5d5f4: stp     x22, x21, [sp, #0x50]                      
02d5d5f8: stp     x20, x19, [sp, #0x60]                      
02d5d5fc: adrp    x20, #0x6630000                            
02d5d600: mov     x19, x0                                    
02d5d604: ldrb    w8, [x20, #0x313]                          
02d5d608: tbnz    w8, #0, #0x2d5d650                         
02d5d60c: adrp    x0, #0x626b000                             
02d5d610: ldr     x0, [x0, #0xdb0]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d5d614: bl      #0x2b70db0                                 fn_2b70db0
02d5d618: adrp    x0, #0x626b000                             
02d5d61c: ldr     x0, [x0, #0xdb8]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d5d620: bl      #0x2b70db0                                 fn_2b70db0
02d5d624: adrp    x0, #0x626b000                             
02d5d628: ldr     x0, [x0, #0xdc0]                           MS:System.Collections.Generic.List`1/Enumerator::get_Current
02d5d62c: bl      #0x2b70db0                                 fn_2b70db0
02d5d630: adrp    x0, #0x626b000                             
02d5d634: ldr     x0, [x0, #0xdc8]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d5d638: bl      #0x2b70db0                                 fn_2b70db0
02d5d63c: adrp    x0, #0x6263000                             
02d5d640: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d5d644: bl      #0x2b70db0                                 fn_2b70db0
02d5d648: mov     w8, #1                                     
02d5d64c: strb    w8, [x20, #0x313]                          
02d5d650: mov     x0, x19                                    
02d5d654: stp     xzr, xzr, [sp, #0x20]                      
02d5d658: str     xzr, [sp, #0x30]                           
02d5d65c: bl      #0x2d64054                                 Clicker.Light2DManager::RemoveMissingItems
02d5d660: ldr     x0, [x19, #0x28]                           ._glowItems
02d5d664: cbz     x0, #0x2d5d750                             
02d5d668: adrp    x8, #0x626b000                             
02d5d66c: adrp    x22, #0x626b000                            
02d5d670: adrp    x23, #0x6263000                            
02d5d674: ldr     x8, [x8, #0xdc8]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d5d678: adrp    x21, #0x626b000                            
02d5d67c: ldr     x22, [x22, #0xdb8]                         MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d5d680: ldr     x23, [x23, #0x918]                         T:UnityEngine.Object
02d5d684: ldr     x21, [x21, #0xdb0]                         MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d5d688: ldr     x1, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5d68c: add     x8, sp, #8                                 
02d5d690: bl      #0x35a9d9c                                 fn_35a9d9c
02d5d694: ldr     x8, [sp, #0x18]                            
02d5d698: ldur    q0, [sp, #8]                               
02d5d69c: str     x8, [sp, #0x30]                            
02d5d6a0: add     x8, sp, #0x20                              
02d5d6a4: str     q0, [sp, #0x20]                            
02d5d6a8: stp     xzr, x8, [sp, #8]                          
02d5d6ac: ldr     x1, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5d6b0: add     x0, sp, #0x20                              
02d5d6b4: bl      #0x4690474                                 fn_4690474
02d5d6b8: tbz     w0, #0, #0x2d5d724                         
02d5d6bc: ldr     x0, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d5d6c0: ldr     x20, [sp, #0x30]                           
02d5d6c4: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d5d6c8: cbnz    w8, #0x2d5d6d0                             
02d5d6cc: bl      #0x2b70f30                                 fn_2b70f30
02d5d6d0: mov     x0, x20                                    
02d5d6d4: mov     x1, xzr                                    
02d5d6d8: mov     x2, xzr                                    
02d5d6dc: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d5d6e0: tbz     w0, #0, #0x2d5d6ac                         
02d5d6e4: cbz     x20, #0x2d5d748                            
02d5d6e8: mov     x0, x20                                    
02d5d6ec: mov     x1, xzr                                    
02d5d6f0: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d5d6f4: cbz     x0, #0x2d5d74c                             
02d5d6f8: ldr     x1, [x19, #0x20]                           ._tfLightPoolHolder
02d5d6fc: mov     x2, xzr                                    
02d5d700: bl      #0x5b472ec                                 UnityEngine.Transform::SetParent
02d5d704: mov     x0, x20                                    
02d5d708: mov     x1, xzr                                    
02d5d70c: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d5d710: cbz     x0, #0x2d5d744                             
02d5d714: mov     w1, wzr                                    
02d5d718: mov     x2, xzr                                    
02d5d71c: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d5d720: b       #0x2d5d6ac                                 
02d5d724: ldr     x1, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5d728: add     x0, sp, #0x20                              
02d5d72c: bl      #0x4690470                                 fn_4690470
02d5d730: ldp     x20, x19, [sp, #0x60]                      
02d5d734: ldp     x22, x21, [sp, #0x50]                      
02d5d738: ldp     x30, x23, [sp, #0x40]                      
02d5d73c: add     sp, sp, #0x70                              
02d5d740: ret                                                
02d5d744: bl      #0x2b7105c                                 fn_2b7105c
02d5d748: bl      #0x2b7105c                                 fn_2b7105c
02d5d74c: bl      #0x2b7105c                                 fn_2b7105c
02d5d750: bl      #0x2b7105c                                 fn_2b7105c
02d5d754: b       #0x2d5d774                                 
02d5d758: b       #0x2d5d774                                 
02d5d75c: b       #0x2d5d774                                 
02d5d760: b       #0x2d5d774                                 
02d5d764: b       #0x2d5d774                                 
02d5d768: b       #0x2d5d774                                 
02d5d76c: b       #0x2d5d774                                 
02d5d770: b       #0x2d5d774                                 
02d5d774: mov     x19, x0                                    
02d5d778: cmp     w1, #1                                     
02d5d77c: b.ne    #0x2d5d7b0                                 
02d5d780: mov     x0, x19                                    
02d5d784: bl      #0x5e90260                                 fn_5e90260
02d5d788: ldr     x19, [x0]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d5d78c: str     x19, [sp, #8]                              
02d5d790: bl      #0x5e90270                                 fn_5e90270
02d5d794: ldr     x0, [sp, #0x10]                            
02d5d798: ldr     x1, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d5d79c: bl      #0x4690470                                 fn_4690470
02d5d7a0: cbz     x19, #0x2d5d730                            
02d5d7a4: mov     x0, x19                                    
02d5d7a8: bl      #0x2b71054                                 fn_2b71054
02d5d7ac: mov     x19, x0                                    
02d5d7b0: add     x0, sp, #8                                 
02d5d7b4: bl      #0x2738848                                 fn_2738848
02d5d7b8: mov     x0, x19                                    
02d5d7bc: bl      #0x2c6051c                                 fn_2c6051c
02d5d7c0: bl      #0x27369b8                                 fn_27369b8
## AddItem(Clicker.GlowSprite2DItem item) -> void
---- Clicker.Light2DManager::AddItem 0x2d64158
02d64158: stp     x30, x21, [sp, #-0x20]!                    
02d6415c: stp     x20, x19, [sp, #0x10]                      
02d64160: adrp    x21, #0x6630000                            
02d64164: mov     x20, x1                                    
02d64168: mov     x19, x0                                    
02d6416c: ldrb    w8, [x21, #0x314]                          
02d64170: tbnz    w8, #0, #0x2d64194                         
02d64174: adrp    x0, #0x626c000                             
02d64178: ldr     x0, [x0, #0xb8]                            MS:System.Collections.Generic.List`1::Add
02d6417c: bl      #0x2b70db0                                 fn_2b70db0
02d64180: adrp    x0, #0x626c000                             
02d64184: ldr     x0, [x0, #0xc0]                            MS:System.Collections.Generic.List`1::Contains
02d64188: bl      #0x2b70db0                                 fn_2b70db0
02d6418c: mov     w8, #1                                     
02d64190: strb    w8, [x21, #0x314]                          
02d64194: ldr     x0, [x19, #0x28]                           ._glowItems
02d64198: cbz     x0, #0x2d64230                             
02d6419c: adrp    x8, #0x626c000                             
02d641a0: mov     x1, x20                                    
02d641a4: ldr     x8, [x8, #0xc0]                            MS:System.Collections.Generic.List`1::Contains
02d641a8: ldr     x2, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d641ac: bl      #0x35a95a8                                 fn_35a95a8
02d641b0: tbnz    w0, #0, #0x2d64220                         
02d641b4: ldr     x0, [x19, #0x28]                           ._glowItems
02d641b8: cbz     x0, #0x2d64230                             
02d641bc: adrp    x9, #0x626c000                             
02d641c0: ldr     x9, [x9, #0xb8]                            MS:System.Collections.Generic.List`1::Add
02d641c4: ldr     w10, [x0, #0x1c]                           [626c01c]=0 f=0,0
02d641c8: ldr     x8, [x0, #0x10]                            M:Clicker.GlowSprite2DItem::<DoGlow>b__10_4
02d641cc: ldr     x9, [x9]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d641d0: add     w10, w10, #1                               
02d641d4: str     w10, [x0, #0x1c]                           
02d641d8: cbz     x8, #0x2d64230                             
02d641dc: ldrsw   x10, [x0, #0x18]                           
02d641e0: ldr     w11, [x8, #0x18]                           M:Clicker.GlowSprite2DItem::<DoGlow>b__10_5
02d641e4: cmp     w10, w11                                   
02d641e8: b.hs    #0x2d6420c                                 
02d641ec: add     x8, x8, x10, lsl #3                        &626c000
02d641f0: add     w9, w10, #1                                
02d641f4: mov     x1, x20                                    
02d641f8: str     w9, [x0, #0x18]                            
02d641fc: str     x20, [x8, #0x20]!                          
02d64200: mov     x0, x8                                     
02d64204: bl      #0x2b70d54                                 fn_2b70d54
02d64208: b       #0x2d64220                                 
02d6420c: ldr     x8, [x9, #0x20]                            M:Clicker.GlowSprite2DItem::<DoGlow>b__10_6
02d64210: mov     x1, x20                                    
02d64214: ldr     x8, [x8, #0xc0]                            MS:System.Collections.Generic.List`1::Contains
02d64218: ldr     x2, [x8, #0x70]                            M:Clicker.HandFollowClick::<ClickAt>b__2_0
02d6421c: bl      #0x35a920c                                 fn_35a920c
02d64220: mov     x0, x19                                    
02d64224: ldp     x20, x19, [sp, #0x10]                      
02d64228: ldp     x30, x21, [sp], #0x20                      
02d6422c: b       #0x2d64054                                 Clicker.Light2DManager::RemoveMissingItems
02d64230: bl      #0x2b7105c                                 fn_2b7105c
## GetAvailableItem() -> Clicker.GlowSprite2DItem
---- Clicker.Light2DManager::GetAvailableItem 0x2d63e70
02d63e70: stp     x30, x23, [sp, #-0x30]!                    
02d63e74: stp     x22, x21, [sp, #0x10]                      
02d63e78: stp     x20, x19, [sp, #0x20]                      
02d63e7c: adrp    x20, #0x6630000                            
02d63e80: adrp    x23, #0x626c000                            
02d63e84: mov     x19, x0                                    
02d63e88: ldrb    w8, [x20, #0x315]                          
02d63e8c: ldr     x23, [x23, #0x80]                          T:Clicker.Light2DManager/<>c
02d63e90: tbnz    w8, #0, #0x2d63ef0                         
02d63e94: adrp    x0, #0x626c000                             
02d63e98: ldr     x0, [x0, #0x88]                            MS:UnityEngine.Component::GetComponent
02d63e9c: bl      #0x2b70db0                                 fn_2b70db0
02d63ea0: adrp    x0, #0x626c000                             
02d63ea4: ldr     x0, [x0, #0x90]                            MS:System.Collections.Generic.List`1::Find
02d63ea8: bl      #0x2b70db0                                 fn_2b70db0
02d63eac: adrp    x0, #0x6266000                             
02d63eb0: ldr     x0, [x0, #0xd20]                           MS:MonoSingleton`1::get_Instance
02d63eb4: bl      #0x2b70db0                                 fn_2b70db0
02d63eb8: adrp    x0, #0x6263000                             
02d63ebc: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d63ec0: bl      #0x2b70db0                                 fn_2b70db0
02d63ec4: adrp    x0, #0x626c000                             
02d63ec8: ldr     x0, [x0, #0x98]                            T:type57246(k15)
02d63ecc: bl      #0x2b70db0                                 fn_2b70db0
02d63ed0: adrp    x0, #0x626c000                             
02d63ed4: ldr     x0, [x0, #0xa0]                            M:Clicker.Light2DManager/<>c::<GetAvailableItem>b__5_0
02d63ed8: bl      #0x2b70db0                                 fn_2b70db0
02d63edc: adrp    x0, #0x626c000                             
02d63ee0: ldr     x0, [x0, #0x80]                            T:Clicker.Light2DManager/<>c
02d63ee4: bl      #0x2b70db0                                 fn_2b70db0
02d63ee8: mov     w8, #1                                     
02d63eec: strb    w8, [x20, #0x315]                          
02d63ef0: mov     x0, x19                                    
02d63ef4: bl      #0x2d64054                                 Clicker.Light2DManager::RemoveMissingItems
02d63ef8: ldr     x0, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d63efc: ldr     x20, [x19, #0x28]                          ._glowItems
02d63f00: ldr     w8, [x0, #0xe4]                            [626c0e4]=0 f=0,0
02d63f04: cbnz    w8, #0x2d63f10                             
02d63f08: bl      #0x2b70f30                                 fn_2b70f30
02d63f0c: ldr     x0, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d63f10: ldr     x8, [x0, #0xb8]                            MS:System.Collections.Generic.List`1::Add
02d63f14: ldr     x21, [x8, #8]                              
02d63f18: cbnz    x21, #0x2d63f74                            
02d63f1c: ldr     w9, [x0, #0xe4]                            [626c0e4]=0 f=0,0
02d63f20: cbnz    w9, #0x2d63f30                             
02d63f24: bl      #0x2b70f30                                 fn_2b70f30
02d63f28: ldr     x8, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d63f2c: ldr     x8, [x8, #0xb8]                            
02d63f30: adrp    x9, #0x626c000                             
02d63f34: ldr     x9, [x9, #0x98]                            T:type57246(k15)
02d63f38: ldr     x22, [x8]                                  
02d63f3c: ldr     x0, [x9]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d63f40: bl      #0x2b7104c                                 fn_2b7104c
02d63f44: adrp    x8, #0x626c000                             
02d63f48: mov     x1, x22                                    
02d63f4c: mov     x3, xzr                                    
02d63f50: ldr     x8, [x8, #0xa0]                            M:Clicker.Light2DManager/<>c::<GetAvailableItem>b__5_0
02d63f54: mov     x21, x0                                    
02d63f58: ldr     x2, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d63f5c: bl      #0x399ba10                                 fn_399ba10
02d63f60: ldr     x8, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d63f64: mov     x1, x21                                    
02d63f68: ldr     x0, [x8, #0xb8]                            MS:System.Collections.Generic.List`1::Add
02d63f6c: str     x21, [x0, #8]!                             
02d63f70: bl      #0x2b70d54                                 fn_2b70d54
02d63f74: cbz     x20, #0x2d64050                            
02d63f78: adrp    x8, #0x626c000                             
02d63f7c: adrp    x22, #0x6263000                            
02d63f80: mov     x0, x20                                    
02d63f84: ldr     x8, [x8, #0x90]                            MS:System.Collections.Generic.List`1::Find
02d63f88: ldr     x22, [x22, #0x918]                         T:UnityEngine.Object
02d63f8c: mov     x1, x21                                    
02d63f90: ldr     x2, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d63f94: bl      #0x35a9868                                 fn_35a9868
02d63f98: ldr     x8, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d63f9c: mov     x20, x0                                    
02d63fa0: ldr     w9, [x8, #0xe4]                            [626c0e4]=0 f=0,0
02d63fa4: cbnz    w9, #0x2d63fb0                             
02d63fa8: mov     x0, x8                                     
02d63fac: bl      #0x2b70f30                                 fn_2b70f30
02d63fb0: mov     x0, x20                                    
02d63fb4: mov     x1, xzr                                    
02d63fb8: mov     x2, xzr                                    
02d63fbc: bl      #0x5b37d84                                 UnityEngine.Object::op_Equality
02d63fc0: tbz     w0, #0, #0x2d6401c                         
02d63fc4: adrp    x8, #0x6266000                             
02d63fc8: ldr     x8, [x8, #0xd20]                           MS:MonoSingleton`1::get_Instance
02d63fcc: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d63fd0: bl      #0x3769600                                 fn_3769600
02d63fd4: cbz     x0, #0x2d64050                             
02d63fd8: mov     w1, #0x3e8                                 
02d63fdc: mov     x2, xzr                                    
02d63fe0: bl      #0x2cdcdd4                                 PoolManager::SpawnObject
02d63fe4: cbz     x0, #0x2d64050                             
02d63fe8: ldr     x1, [x19, #0x20]                           ._tfLightPoolHolder
02d63fec: mov     x2, xzr                                    
02d63ff0: mov     x20, x0                                    
02d63ff4: bl      #0x5b472ec                                 UnityEngine.Transform::SetParent
02d63ff8: adrp    x8, #0x626c000                             
02d63ffc: mov     x0, x20                                    
02d64000: ldr     x8, [x8, #0x88]                            MS:UnityEngine.Component::GetComponent
02d64004: ldr     x1, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d64008: bl      #0x3140c84                                 fn_3140c84
02d6400c: mov     x20, x0                                    
02d64010: mov     x0, x19                                    
02d64014: mov     x1, x20                                    
02d64018: bl      #0x2d64158                                 Clicker.Light2DManager::AddItem
02d6401c: cbz     x20, #0x2d64050                            
02d64020: mov     x0, x20                                    
02d64024: mov     x1, xzr                                    
02d64028: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d6402c: cbz     x0, #0x2d64050                             
02d64030: mov     w1, #1                                     
02d64034: mov     x2, xzr                                    
02d64038: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d6403c: mov     x0, x20                                    
02d64040: ldp     x20, x19, [sp, #0x20]                      
02d64044: ldp     x22, x21, [sp, #0x10]                      
02d64048: ldp     x30, x23, [sp], #0x30                      
02d6404c: ret                                                
02d64050: bl      #0x2b7105c                                 fn_2b7105c
## RemoveMissingItems() -> void
---- Clicker.Light2DManager::RemoveMissingItems 0x2d64054
02d64054: str     x30, [sp, #-0x30]!                         
02d64058: stp     x22, x21, [sp, #0x10]                      
02d6405c: stp     x20, x19, [sp, #0x20]                      
02d64060: adrp    x20, #0x6630000                            
02d64064: adrp    x22, #0x626c000                            
02d64068: mov     x19, x0                                    
02d6406c: ldrb    w8, [x20, #0x316]                          
02d64070: ldr     x22, [x22, #0x80]                          T:Clicker.Light2DManager/<>c
02d64074: tbnz    w8, #0, #0x2d640b0                         
02d64078: adrp    x0, #0x626c000                             
02d6407c: ldr     x0, [x0, #0xa8]                            MS:System.Collections.Generic.List`1::RemoveAll
02d64080: bl      #0x2b70db0                                 fn_2b70db0
02d64084: adrp    x0, #0x626c000                             
02d64088: ldr     x0, [x0, #0x98]                            T:type57246(k15)
02d6408c: bl      #0x2b70db0                                 fn_2b70db0
02d64090: adrp    x0, #0x626c000                             
02d64094: ldr     x0, [x0, #0xb0]                            M:Clicker.Light2DManager/<>c::<RemoveMissingItems>b__6_0
02d64098: bl      #0x2b70db0                                 fn_2b70db0
02d6409c: adrp    x0, #0x626c000                             
02d640a0: ldr     x0, [x0, #0x80]                            T:Clicker.Light2DManager/<>c
02d640a4: bl      #0x2b70db0                                 fn_2b70db0
02d640a8: mov     w8, #1                                     
02d640ac: strb    w8, [x20, #0x316]                          
02d640b0: ldr     x0, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d640b4: ldr     x19, [x19, #0x28]                          ._glowItems
02d640b8: ldr     w8, [x0, #0xe4]                            [626c0e4]=0 f=0,0
02d640bc: cbnz    w8, #0x2d640c8                             
02d640c0: bl      #0x2b70f30                                 fn_2b70f30
02d640c4: ldr     x0, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d640c8: ldr     x8, [x0, #0xb8]                            MS:System.Collections.Generic.List`1::Add
02d640cc: ldr     x20, [x8, #0x10]                           
02d640d0: cbnz    x20, #0x2d6412c                            
02d640d4: ldr     w9, [x0, #0xe4]                            [626c0e4]=0 f=0,0
02d640d8: cbnz    w9, #0x2d640e8                             
02d640dc: bl      #0x2b70f30                                 fn_2b70f30
02d640e0: ldr     x8, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d640e4: ldr     x8, [x8, #0xb8]                            
02d640e8: adrp    x9, #0x626c000                             
02d640ec: ldr     x9, [x9, #0x98]                            T:type57246(k15)
02d640f0: ldr     x21, [x8]                                  
02d640f4: ldr     x0, [x9]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d640f8: bl      #0x2b7104c                                 fn_2b7104c
02d640fc: adrp    x8, #0x626c000                             
02d64100: mov     x1, x21                                    
02d64104: mov     x3, xzr                                    
02d64108: ldr     x8, [x8, #0xb0]                            M:Clicker.Light2DManager/<>c::<RemoveMissingItems>b__6_0
02d6410c: mov     x20, x0                                    
02d64110: ldr     x2, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d64114: bl      #0x399ba10                                 fn_399ba10
02d64118: ldr     x8, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6411c: mov     x1, x20                                    
02d64120: ldr     x0, [x8, #0xb8]                            MS:System.Collections.Generic.List`1::Add
02d64124: str     x20, [x0, #0x10]!                          
02d64128: bl      #0x2b70d54                                 fn_2b70d54
02d6412c: cbz     x19, #0x2d64154                            
02d64130: adrp    x8, #0x626c000                             
02d64134: mov     x0, x19                                    
02d64138: mov     x1, x20                                    
02d6413c: ldr     x8, [x8, #0xa8]                            MS:System.Collections.Generic.List`1::RemoveAll
02d64140: ldp     x20, x19, [sp, #0x20]                      
02d64144: ldp     x22, x21, [sp, #0x10]                      
02d64148: ldr     x2, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6414c: ldr     x30, [sp], #0x30                           
02d64150: b       #0x35aa8f0                                 
02d64154: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Clicker.Light2DManager::.ctor 0x2d64234
02d64234: stp     x30, x21, [sp, #-0x20]!                    
02d64238: stp     x20, x19, [sp, #0x10]                      
02d6423c: adrp    x20, #0x6630000                            
02d64240: adrp    x21, #0x626c000                            
02d64244: mov     x19, x0                                    
02d64248: ldrb    w8, [x20, #0x317]                          
02d6424c: ldr     x21, [x21, #0xc8]                          MS:MonoSingleton`1::.ctor
02d64250: tbnz    w8, #0, #0x2d64268                         
02d64254: adrp    x0, #0x626c000                             
02d64258: ldr     x0, [x0, #0xc8]                            MS:MonoSingleton`1::.ctor
02d6425c: bl      #0x2b70db0                                 fn_2b70db0
02d64260: mov     w8, #1                                     
02d64264: strb    w8, [x20, #0x317]                          
02d64268: mov     x0, x19                                    
02d6426c: ldp     x20, x19, [sp, #0x10]                      
02d64270: ldr     x1, [x21]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d64274: ldp     x30, x21, [sp], #0x20                      
02d64278: b       #0x3769e18                                 
