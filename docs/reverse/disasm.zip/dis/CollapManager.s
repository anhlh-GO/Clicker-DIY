#### CLASS CollapManager/<ISetCount>d__8 parent= object
#   field <>1__state                     int                                                off=0x10 attr=1 
#   field <>2__current                   object                                             off=0x18 attr=1 
#   field <>4__this                      CollapManager                                      off=0x20 attr=6 
#   field seconds                        int                                                off=0x28 attr=6 
#   field <time>5__2                     int                                                off=0x2c attr=1 
## .ctor(int <>1__state) -> void
---- CollapManager/<ISetCount>d__8::.ctor 0x2c8f1f8
02c8f1f8: str     x30, [sp, #-0x20]!                         
02c8f1fc: stp     x20, x19, [sp, #0x10]                      
02c8f200: mov     w19, w1                                    
02c8f204: mov     x1, xzr                                    
02c8f208: mov     x20, x0                                    
02c8f20c: bl      #0x4e53e9c                                 System.Object::.ctor
02c8f210: str     w19, [x20, #0x10]                          .<>1__state
02c8f214: ldp     x20, x19, [sp, #0x10]                      
02c8f218: ldr     x30, [sp], #0x20                           
02c8f21c: ret                                                
## System.IDisposable.Dispose() -> void
---- CollapManager/<ISetCount>d__8::System.IDisposable.Dispose 0x2c8f268
02c8f268: ret                                                
## MoveNext() -> bool
---- CollapManager/<ISetCount>d__8::MoveNext 0x2c8f26c
02c8f26c: str     x30, [sp, #-0x20]!                         
02c8f270: stp     x20, x19, [sp, #0x10]                      
02c8f274: adrp    x20, #0x662f000                            
02c8f278: mov     x19, x0                                    
02c8f27c: ldrb    w8, [x20, #0x9b6]                          
02c8f280: tbnz    w8, #0, #0x2c8f2a4                         
02c8f284: adrp    x0, #0x6264000                             
02c8f288: ldr     x0, [x0, #0xf58]                           T:UnityEngine.WaitForSeconds
02c8f28c: bl      #0x2b70db0                                 fn_2b70db0
02c8f290: adrp    x0, #0x6265000                             
02c8f294: ldr     x0, [x0, #0x458]                           S:'{0}s'
02c8f298: bl      #0x2b70db0                                 fn_2b70db0
02c8f29c: mov     w8, #1                                     
02c8f2a0: strb    w8, [x20, #0x9b6]                          
02c8f2a4: ldr     w8, [x19, #0x10]                           .<>1__state
02c8f2a8: ldr     x20, [x19, #0x20]                          .<>4__this
02c8f2ac: cmp     w8, #1                                     
02c8f2b0: b.eq    #0x2c8f30c                                 
02c8f2b4: cbnz    w8, #0x2c8f40c                             
02c8f2b8: mov     w8, #-1                                    
02c8f2bc: str     w8, [x19, #0x10]                           .<>1__state
02c8f2c0: cbz     x20, #0x2c8f41c                            
02c8f2c4: ldr     x0, [x20, #0x28]                           [662f028]=6000015 f=2.40742e-35,0 .seconds
02c8f2c8: cbz     x0, #0x2c8f41c                             
02c8f2cc: mov     x1, xzr                                    
02c8f2d0: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02c8f2d4: cbz     x0, #0x2c8f41c                             
02c8f2d8: mov     w1, wzr                                    
02c8f2dc: mov     x2, xzr                                    
02c8f2e0: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02c8f2e4: ldr     x0, [x20, #0x30]                           &2b706f8(=d65f03c0b9401800)
02c8f2e8: cbz     x0, #0x2c8f41c                             
02c8f2ec: mov     x1, xzr                                    
02c8f2f0: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02c8f2f4: cbz     x0, #0x2c8f41c                             
02c8f2f8: mov     w1, #1                                     
02c8f2fc: mov     x2, xzr                                    
02c8f300: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02c8f304: ldr     w8, [x19, #0x28]                           .seconds
02c8f308: b       #0x2c8f31c                                 
02c8f30c: ldr     w8, [x19, #0x2c]                           .<time>5__2
02c8f310: mov     w9, #-1                                    
02c8f314: str     w9, [x19, #0x10]                           .<>1__state
02c8f318: sub     w8, w8, #1                                 
02c8f31c: str     w8, [x19, #0x2c]                           .<time>5__2
02c8f320: tbnz    w8, #0x1f, #0x2c8f3b8                      
02c8f324: cbz     x20, #0x2c8f41c                            
02c8f328: adrp    x9, #0x6263000                             
02c8f32c: add     x1, sp, #0xc                               
02c8f330: ldr     x9, [x9, #0x970]                           &6645c70(=0)
02c8f334: ldr     x20, [x20, #0x30]                          &2b706f8(=d65f03c0b9401800)
02c8f338: str     w8, [sp, #0xc]                             
02c8f33c: ldr     x0, [x9, #0x48]                            &6263098(=0)
02c8f340: bl      #0x2b70f38                                 fn_2b70f38
02c8f344: adrp    x8, #0x6265000                             
02c8f348: mov     x1, x0                                     
02c8f34c: mov     x2, xzr                                    
02c8f350: ldr     x8, [x8, #0x458]                           S:'{0}s'
02c8f354: ldr     x8, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c8f358: mov     x0, x8                                     
02c8f35c: bl      #0x4c9d0ec                                 System.String::Format
02c8f360: cbz     x20, #0x2c8f41c                            
02c8f364: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02c8f368: mov     x1, x0                                     
02c8f36c: mov     x0, x20                                    
02c8f370: ldr     x9, [x8, #0x558]                           T:GoogleMobileAdsManager
02c8f374: ldr     x2, [x8, #0x560]                           T:GoogleMobileAds.Mediation.UnityAds.Api.UnityAds
02c8f378: blr     x9                                         
02c8f37c: adrp    x8, #0x6264000                             
02c8f380: ldr     x8, [x8, #0xf58]                           T:UnityEngine.WaitForSeconds
02c8f384: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c8f388: bl      #0x2b7104c                                 fn_2b7104c
02c8f38c: fmov    s0, #1.00000000                            
02c8f390: mov     x1, xzr                                    
02c8f394: mov     x20, x0                                    
02c8f398: bl      #0x5b3e5e8                                 UnityEngine.WaitForSeconds::.ctor
02c8f39c: str     x20, [x19, #0x18]!                         .<>2__current
02c8f3a0: mov     x0, x19                                    
02c8f3a4: mov     x1, x20                                    
02c8f3a8: bl      #0x2b70d54                                 fn_2b70d54
02c8f3ac: mov     w0, #1                                     
02c8f3b0: stur    w0, [x19, #-8]                             
02c8f3b4: b       #0x2c8f410                                 
02c8f3b8: cbz     x20, #0x2c8f41c                            
02c8f3bc: ldr     x0, [x20, #0x30]                           &2b706f8(=d65f03c0b9401800)
02c8f3c0: cbz     x0, #0x2c8f41c                             
02c8f3c4: mov     x1, xzr                                    
02c8f3c8: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02c8f3cc: cbz     x0, #0x2c8f41c                             
02c8f3d0: mov     w1, wzr                                    
02c8f3d4: mov     x2, xzr                                    
02c8f3d8: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02c8f3dc: ldr     x0, [x20, #0x28]                           [662f028]=6000015 f=2.40742e-35,0 .seconds
02c8f3e0: cbz     x0, #0x2c8f41c                             
02c8f3e4: mov     x1, xzr                                    
02c8f3e8: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02c8f3ec: cbz     x0, #0x2c8f41c                             
02c8f3f0: mov     w1, #1                                     
02c8f3f4: mov     x2, xzr                                    
02c8f3f8: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02c8f3fc: str     xzr, [x20, #0x38]!                         
02c8f400: mov     x0, x20                                    
02c8f404: mov     x1, xzr                                    
02c8f408: bl      #0x2b70d54                                 fn_2b70d54
02c8f40c: mov     w0, wzr                                    
02c8f410: ldp     x20, x19, [sp, #0x10]                      
02c8f414: ldr     x30, [sp], #0x20                           
02c8f418: ret                                                
02c8f41c: bl      #0x2b7105c                                 fn_2b7105c
## System.Collections.Generic.IEnumerator<System.Object>.get_Current() -> object
---- CollapManager/<ISetCount>d__8::System.Collections.Generic.IEnumerator<System.Object>.get_Current 0x2c8f420
02c8f420: ldr     x0, [x0, #0x18]                            .<>2__current
02c8f424: ret                                                
## System.Collections.IEnumerator.Reset() -> void
---- CollapManager/<ISetCount>d__8::System.Collections.IEnumerator.Reset 0x2c8f428
02c8f428: stp     x30, x19, [sp, #-0x10]!                    
02c8f42c: adrp    x0, #0x6264000                             
02c8f430: ldr     x0, [x0, #0xf60]                           T:System.NotSupportedException
02c8f434: bl      #0x2b70dc4                                 fn_2b70dc4
02c8f438: bl      #0x2b7104c                                 fn_2b7104c
02c8f43c: mov     x1, xzr                                    
02c8f440: mov     x19, x0                                    
02c8f444: bl      #0x4e14238                                 System.NotSupportedException::.ctor
02c8f448: adrp    x0, #0x6265000                             
02c8f44c: ldr     x0, [x0, #0x460]                           M:CollapManager/<ISetCount>d__8::System.Collections.IEnumerator.Reset
02c8f450: bl      #0x2b70dc4                                 fn_2b70dc4
02c8f454: mov     x1, x0                                     
02c8f458: mov     x0, x19                                    
02c8f45c: bl      #0x2b70f20                                 fn_2b70f20
## System.Collections.IEnumerator.get_Current() -> object
---- CollapManager/<ISetCount>d__8::System.Collections.IEnumerator.get_Current 0x2c8f460
02c8f460: ldr     x0, [x0, #0x18]                            .<>2__current
02c8f464: ret                                                
#### CLASS CollapManager parent= WejoyService.Singleton`1<CollapManager>
#   field _viewGO                        UnityEngine.GameObject                             off=0x20 attr=1 SerializeField
#   field _btnClose                      UnityEngine.UI.Button                              off=0x28 attr=1 SerializeField
#   field _txtTime                       TMPro.TMP_Text                                     off=0x30 attr=1 SerializeField
#   field _countCoroutine                UnityEngine.Coroutine                              off=0x38 attr=1 
## Start() -> void
---- CollapManager::Start 0x2c8f0d8
02c8f0d8: ret                                                
## Show() -> void
---- CollapManager::Show 0x2c8f0dc
02c8f0dc: ret                                                
## StartCountDown() -> void
---- CollapManager::StartCountDown 0x2c8f0e0
02c8f0e0: str     x30, [sp, #-0x20]!                         
02c8f0e4: stp     x20, x19, [sp, #0x10]                      
02c8f0e8: mov     x20, x0                                    
02c8f0ec: mov     x19, x0                                    
02c8f0f0: ldr     x1, [x20, #0x38]!                          ._countCoroutine
02c8f0f4: cbz     x1, #0x2c8f104                             
02c8f0f8: mov     x0, x19                                    
02c8f0fc: mov     x2, xzr                                    
02c8f100: bl      #0x5b38c4c                                 UnityEngine.MonoBehaviour::StopCoroutine
02c8f104: mov     x0, x19                                    
02c8f108: mov     w1, #0x64                                  
02c8f10c: bl      #0x2c8f138                                 CollapManager::ISetCount
02c8f110: mov     x1, x0                                     
02c8f114: mov     x0, x19                                    
02c8f118: mov     x2, xzr                                    
02c8f11c: bl      #0x5b389f0                                 UnityEngine.MonoBehaviour::StartCoroutine
02c8f120: mov     x1, x0                                     
02c8f124: mov     x0, x20                                    
02c8f128: str     x1, [x19, #0x38]                           ._countCoroutine
02c8f12c: ldp     x20, x19, [sp, #0x10]                      
02c8f130: ldr     x30, [sp], #0x20                           
02c8f134: b       #0x2b70d54                                 
## Hide() -> void
---- CollapManager::Hide 0x2c8f1b4
02c8f1b4: stp     x30, x19, [sp, #-0x10]!                    
02c8f1b8: mov     x19, x0                                    
02c8f1bc: ldr     x0, [x0, #0x20]                            ._viewGO
02c8f1c0: cbz     x0, #0x2c8f1f4                             
02c8f1c4: mov     w1, wzr                                    
02c8f1c8: mov     x2, xzr                                    
02c8f1cc: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02c8f1d0: ldr     x0, [x19, #0x28]                           ._btnClose
02c8f1d4: cbz     x0, #0x2c8f1f4                             
02c8f1d8: mov     x1, xzr                                    
02c8f1dc: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02c8f1e0: cbz     x0, #0x2c8f1f4                             
02c8f1e4: mov     w1, wzr                                    
02c8f1e8: mov     x2, xzr                                    
02c8f1ec: ldp     x30, x19, [sp], #0x10                      
02c8f1f0: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02c8f1f4: bl      #0x2b7105c                                 fn_2b7105c
## ISetCount(int seconds) -> System.Collections.IEnumerator
---- CollapManager::ISetCount 0x2c8f138
02c8f138: str     x30, [sp, #-0x30]!                         
02c8f13c: stp     x22, x21, [sp, #0x10]                      
02c8f140: stp     x20, x19, [sp, #0x20]                      
02c8f144: adrp    x21, #0x662f000                            
02c8f148: adrp    x22, #0x6265000                            
02c8f14c: mov     w19, w1                                    
02c8f150: ldrb    w8, [x21, #0x9b4]                          
02c8f154: ldr     x22, [x22, #0x448]                         T:CollapManager/<ISetCount>d__8
02c8f158: mov     x20, x0                                    
02c8f15c: tbnz    w8, #0, #0x2c8f174                         
02c8f160: adrp    x0, #0x6265000                             
02c8f164: ldr     x0, [x0, #0x448]                           T:CollapManager/<ISetCount>d__8
02c8f168: bl      #0x2b70db0                                 fn_2b70db0
02c8f16c: mov     w8, #1                                     
02c8f170: strb    w8, [x21, #0x9b4]                          
02c8f174: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8f178: bl      #0x2b7104c                                 fn_2b7104c
02c8f17c: mov     x1, xzr                                    
02c8f180: mov     x21, x0                                    
02c8f184: bl      #0x4e53e9c                                 System.Object::.ctor
02c8f188: mov     x0, x21                                    
02c8f18c: mov     x1, x20                                    
02c8f190: str     wzr, [x21, #0x10]                          
02c8f194: str     x20, [x0, #0x20]!                          ._viewGO
02c8f198: bl      #0x2b70d54                                 fn_2b70d54
02c8f19c: mov     x0, x21                                    
02c8f1a0: str     w19, [x21, #0x28]                          ._btnClose
02c8f1a4: ldp     x20, x19, [sp, #0x20]                      
02c8f1a8: ldp     x22, x21, [sp, #0x10]                      
02c8f1ac: ldr     x30, [sp], #0x30                           
02c8f1b0: ret                                                
## .ctor() -> void
---- CollapManager::.ctor 0x2c8f220
02c8f220: stp     x30, x21, [sp, #-0x20]!                    
02c8f224: stp     x20, x19, [sp, #0x10]                      
02c8f228: adrp    x20, #0x662f000                            
02c8f22c: adrp    x21, #0x6265000                            
02c8f230: mov     x19, x0                                    
02c8f234: ldrb    w8, [x20, #0x9b5]                          
02c8f238: ldr     x21, [x21, #0x450]                         MS:WejoyService.Singleton`1::.ctor
02c8f23c: tbnz    w8, #0, #0x2c8f254                         
02c8f240: adrp    x0, #0x6265000                             
02c8f244: ldr     x0, [x0, #0x450]                           MS:WejoyService.Singleton`1::.ctor
02c8f248: bl      #0x2b70db0                                 fn_2b70db0
02c8f24c: mov     w8, #1                                     
02c8f250: strb    w8, [x20, #0x9b5]                          
02c8f254: mov     x0, x19                                    
02c8f258: ldp     x20, x19, [sp, #0x10]                      
02c8f25c: ldr     x1, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8f260: ldp     x30, x21, [sp], #0x20                      
02c8f264: b       #0x3be76dc                                 
