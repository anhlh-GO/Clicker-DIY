#### CLASS DreamHouse.PopupNewRoom parent= PopupBase
#   field _backButton                    UnityEngine.UI.Button                              off=0x38 attr=1 SerializeField
#   field _decorateButton                UnityEngine.UI.Button                              off=0x40 attr=1 SerializeField
#   field _iconImage                     UnityEngine.UI.Image                               off=0x48 attr=1 SerializeField
#   field _panel                         UnityEngine.RectTransform                          off=0x50 attr=1 SerializeField
## OnDestroy() -> void
---- DreamHouse.PopupNewRoom::OnDestroy 0x2d1beb4
02d1beb4: str     x30, [sp, #-0x30]!                         
02d1beb8: stp     x22, x21, [sp, #0x10]                      
02d1bebc: stp     x20, x19, [sp, #0x20]                      
02d1bec0: adrp    x20, #0x6630000                            
02d1bec4: mov     x19, x0                                    
02d1bec8: ldrb    w8, [x20, #0x11]                           
02d1becc: tbnz    w8, #0, #0x2d1befc                         
02d1bed0: adrp    x0, #0x6269000                             
02d1bed4: ldr     x0, [x0, #0xc08]                           M:DreamHouse.PopupNewRoom::OnBackButtonClicked
02d1bed8: bl      #0x2b70db0                                 fn_2b70db0
02d1bedc: adrp    x0, #0x6269000                             
02d1bee0: ldr     x0, [x0, #0xc10]                           M:DreamHouse.PopupNewRoom::OnDecorateButtonClicked
02d1bee4: bl      #0x2b70db0                                 fn_2b70db0
02d1bee8: adrp    x0, #0x6265000                             
02d1beec: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d1bef0: bl      #0x2b70db0                                 fn_2b70db0
02d1bef4: mov     w8, #1                                     
02d1bef8: strb    w8, [x20, #0x11]                           
02d1befc: ldr     x8, [x19, #0x38]                           ._backButton
02d1bf00: cbz     x8, #0x2d1bf98                             
02d1bf04: adrp    x22, #0x6265000                            
02d1bf08: adrp    x21, #0x6269000                            
02d1bf0c: ldr     x22, [x22, #0x3f0]                         T:UnityEngine.Events.UnityAction
02d1bf10: ldr     x21, [x21, #0xc08]                         M:DreamHouse.PopupNewRoom::OnBackButtonClicked
02d1bf14: ldr     x20, [x8, #0x100]                          
02d1bf18: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d1bf1c: bl      #0x2b7104c                                 fn_2b7104c
02d1bf20: ldr     x2, [x21]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1bf24: mov     x1, x19                                    
02d1bf28: mov     x3, xzr                                    
02d1bf2c: mov     x21, x0                                    
02d1bf30: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d1bf34: cbz     x20, #0x2d1bf98                            
02d1bf38: mov     x0, x20                                    
02d1bf3c: mov     x1, x21                                    
02d1bf40: mov     x2, xzr                                    
02d1bf44: bl      #0x5b4d13c                                 UnityEngine.Events.UnityEvent::RemoveListener
02d1bf48: ldr     x8, [x19, #0x40]                           ._decorateButton
02d1bf4c: cbz     x8, #0x2d1bf98                             
02d1bf50: adrp    x21, #0x6269000                            
02d1bf54: ldr     x21, [x21, #0xc10]                         M:DreamHouse.PopupNewRoom::OnDecorateButtonClicked
02d1bf58: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d1bf5c: ldr     x20, [x8, #0x100]                          
02d1bf60: bl      #0x2b7104c                                 fn_2b7104c
02d1bf64: ldr     x2, [x21]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1bf68: mov     x1, x19                                    
02d1bf6c: mov     x3, xzr                                    
02d1bf70: mov     x21, x0                                    
02d1bf74: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d1bf78: cbz     x20, #0x2d1bf98                            
02d1bf7c: mov     x0, x20                                    
02d1bf80: mov     x1, x21                                    
02d1bf84: mov     x2, xzr                                    
02d1bf88: ldp     x20, x19, [sp, #0x20]                      
02d1bf8c: ldp     x22, x21, [sp, #0x10]                      
02d1bf90: ldr     x30, [sp], #0x30                           
02d1bf94: b       #0x5b4d13c                                 UnityEngine.Events.UnityEvent::RemoveListener
02d1bf98: bl      #0x2b7105c                                 fn_2b7105c
## OnInit(UIManager uiManager) -> void
---- DreamHouse.PopupNewRoom::OnInit 0x2d1bf9c
02d1bf9c: str     x30, [sp, #-0x30]!                         
02d1bfa0: stp     x22, x21, [sp, #0x10]                      
02d1bfa4: stp     x20, x19, [sp, #0x20]                      
02d1bfa8: adrp    x21, #0x6630000                            
02d1bfac: mov     x20, x1                                    
02d1bfb0: mov     x19, x0                                    
02d1bfb4: ldrb    w8, [x21, #0x12]                           
02d1bfb8: tbnz    w8, #0, #0x2d1bfe8                         
02d1bfbc: adrp    x0, #0x6269000                             
02d1bfc0: ldr     x0, [x0, #0xc08]                           M:DreamHouse.PopupNewRoom::OnBackButtonClicked
02d1bfc4: bl      #0x2b70db0                                 fn_2b70db0
02d1bfc8: adrp    x0, #0x6269000                             
02d1bfcc: ldr     x0, [x0, #0xc10]                           M:DreamHouse.PopupNewRoom::OnDecorateButtonClicked
02d1bfd0: bl      #0x2b70db0                                 fn_2b70db0
02d1bfd4: adrp    x0, #0x6265000                             
02d1bfd8: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d1bfdc: bl      #0x2b70db0                                 fn_2b70db0
02d1bfe0: mov     w8, #1                                     
02d1bfe4: strb    w8, [x21, #0x12]                           
02d1bfe8: mov     x0, x19                                    
02d1bfec: mov     x1, x20                                    
02d1bff0: mov     x2, xzr                                    
02d1bff4: bl      #0x2cdd3c4                                 UIBase::OnInit
02d1bff8: ldr     x8, [x19, #0x38]                           ._backButton
02d1bffc: cbz     x8, #0x2d1c094                             
02d1c000: adrp    x22, #0x6265000                            
02d1c004: adrp    x21, #0x6269000                            
02d1c008: ldr     x22, [x22, #0x3f0]                         T:UnityEngine.Events.UnityAction
02d1c00c: ldr     x21, [x21, #0xc08]                         M:DreamHouse.PopupNewRoom::OnBackButtonClicked
02d1c010: ldr     x20, [x8, #0x100]                          
02d1c014: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d1c018: bl      #0x2b7104c                                 fn_2b7104c
02d1c01c: ldr     x2, [x21]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1c020: mov     x1, x19                                    
02d1c024: mov     x3, xzr                                    
02d1c028: mov     x21, x0                                    
02d1c02c: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d1c030: cbz     x20, #0x2d1c094                            
02d1c034: mov     x0, x20                                    
02d1c038: mov     x1, x21                                    
02d1c03c: mov     x2, xzr                                    
02d1c040: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d1c044: ldr     x8, [x19, #0x40]                           ._decorateButton
02d1c048: cbz     x8, #0x2d1c094                             
02d1c04c: adrp    x21, #0x6269000                            
02d1c050: ldr     x21, [x21, #0xc10]                         M:DreamHouse.PopupNewRoom::OnDecorateButtonClicked
02d1c054: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d1c058: ldr     x20, [x8, #0x100]                          
02d1c05c: bl      #0x2b7104c                                 fn_2b7104c
02d1c060: ldr     x2, [x21]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1c064: mov     x1, x19                                    
02d1c068: mov     x3, xzr                                    
02d1c06c: mov     x21, x0                                    
02d1c070: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d1c074: cbz     x20, #0x2d1c094                            
02d1c078: mov     x0, x20                                    
02d1c07c: mov     x1, x21                                    
02d1c080: mov     x2, xzr                                    
02d1c084: ldp     x20, x19, [sp, #0x20]                      
02d1c088: ldp     x22, x21, [sp, #0x10]                      
02d1c08c: ldr     x30, [sp], #0x30                           
02d1c090: b       #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d1c094: bl      #0x2b7105c                                 fn_2b7105c
## OnShow() -> void
---- DreamHouse.PopupNewRoom::OnShow 0x2d1c098
02d1c098: stp     x30, x23, [sp, #-0x30]!                    
02d1c09c: stp     x22, x21, [sp, #0x10]                      
02d1c0a0: stp     x20, x19, [sp, #0x20]                      
02d1c0a4: adrp    x20, #0x6630000                            
02d1c0a8: mov     x19, x0                                    
02d1c0ac: ldrb    w8, [x20, #0x13]                           
02d1c0b0: tbnz    w8, #0, #0x2d1c0d4                         
02d1c0b4: adrp    x0, #0x6266000                             
02d1c0b8: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d1c0bc: bl      #0x2b70db0                                 fn_2b70db0
02d1c0c0: adrp    x0, #0x6269000                             
02d1c0c4: ldr     x0, [x0, #0xc18]                           MS:UIManager::GetScreen
02d1c0c8: bl      #0x2b70db0                                 fn_2b70db0
02d1c0cc: mov     w8, #1                                     
02d1c0d0: strb    w8, [x20, #0x13]                           
02d1c0d4: mov     x0, x19                                    
02d1c0d8: mov     x1, xzr                                    
02d1c0dc: bl      #0x2cdd6b8                                 UIBase::OnShow
02d1c0e0: ldr     x0, [x19, #0x50]                           ._panel
02d1c0e4: mov     w1, wzr                                    
02d1c0e8: mov     x2, xzr                                    
02d1c0ec: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d1c0f0: adrp    x21, #0x662f000                            
02d1c0f4: ldr     x20, [x19, #0x50]                          ._panel
02d1c0f8: ldrb    w8, [x21, #0x91a]                          
02d1c0fc: cbnz    w8, #0x2d1c114                             
02d1c100: adrp    x0, #0x6264000                             
02d1c104: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d1c108: bl      #0x2b70db0                                 fn_2b70db0
02d1c10c: mov     w8, #1                                     
02d1c110: strb    w8, [x21, #0x91a]                          
02d1c114: cbz     x20, #0x2d1c1c4                            
02d1c118: adrp    x22, #0x6264000                            
02d1c11c: adrp    x21, #0x6266000                            
02d1c120: mov     x0, x20                                    
02d1c124: ldr     x22, [x22, #0xd8]                          T:UnityEngine.Vector3
02d1c128: mov     x1, xzr                                    
02d1c12c: ldr     x8, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d1c130: ldr     x8, [x8, #0xb8]                            
02d1c134: ldr     x21, [x21, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d1c138: ldp     s1, s2, [x8, #4]                           
02d1c13c: ldr     s0, [x8]                                   
02d1c140: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d1c144: adrp    x23, #0x662f000                            
02d1c148: ldr     x20, [x19, #0x50]                          ._panel
02d1c14c: ldrb    w8, [x23, #0xa74]                          
02d1c150: cbnz    w8, #0x2d1c168                             
02d1c154: adrp    x0, #0x6264000                             
02d1c158: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d1c15c: bl      #0x2b70db0                                 fn_2b70db0
02d1c160: mov     w8, #1                                     
02d1c164: strb    w8, [x23, #0xa74]                          
02d1c168: ldr     x8, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d1c16c: mov     x0, x20                                    
02d1c170: mov     x1, xzr                                    
02d1c174: ldr     x8, [x8, #0xb8]                            
02d1c178: ldp     s0, s1, [x8, #0xc]                         
02d1c17c: ldr     s2, [x8, #0x14]                            
02d1c180: adrp    x8, #0x1084000                             
02d1c184: ldr     s3, [x8, #0xda8]                           [1084da8]=da242603eb851ec f=0.36,1e-30
02d1c188: bl      #0x2d98af8                                 DG.Tweening.ShortcutExtensions::DOScale
02d1c18c: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1c190: mov     w1, #0x1b                                  
02d1c194: bl      #0x336fa0c                                 fn_336fa0c
02d1c198: ldr     x0, [x19, #0x30]                           
02d1c19c: cbz     x0, #0x2d1c1c4                             
02d1c1a0: adrp    x8, #0x6269000                             
02d1c1a4: ldr     x8, [x8, #0xc18]                           MS:UIManager::GetScreen
02d1c1a8: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d1c1ac: bl      #0x33fbbd0                                 fn_33fbbd0
02d1c1b0: cbz     x0, #0x2d1c1c4                             
02d1c1b4: ldp     x20, x19, [sp, #0x20]                      
02d1c1b8: ldp     x22, x21, [sp, #0x10]                      
02d1c1bc: ldp     x30, x23, [sp], #0x30                      
02d1c1c0: b       #0x2d1c1c8                                 DreamHouse.ScreenInGame::CheckShowBtnBack
02d1c1c4: bl      #0x2b7105c                                 fn_2b7105c
## OnBackButtonClicked() -> void
---- DreamHouse.PopupNewRoom::OnBackButtonClicked 0x2d1c22c
02d1c22c: str     x30, [sp, #-0x30]!                         
02d1c230: stp     x22, x21, [sp, #0x10]                      
02d1c234: stp     x20, x19, [sp, #0x20]                      
02d1c238: adrp    x20, #0x6630000                            
02d1c23c: mov     x19, x0                                    
02d1c240: ldrb    w8, [x20, #0x14]                           
02d1c244: tbnz    w8, #0, #0x2d1c280                         
02d1c248: adrp    x0, #0x6264000                             
02d1c24c: ldr     x0, [x0, #0xf90]                           T:System.Action
02d1c250: bl      #0x2b70db0                                 fn_2b70db0
02d1c254: adrp    x0, #0x6269000                             
02d1c258: ldr     x0, [x0, #0xc20]                           M:DreamHouse.PopupNewRoom::<OnBackButtonClicked>b__7_0
02d1c25c: bl      #0x2b70db0                                 fn_2b70db0
02d1c260: adrp    x0, #0x6265000                             
02d1c264: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02d1c268: bl      #0x2b70db0                                 fn_2b70db0
02d1c26c: adrp    x0, #0x6269000                             
02d1c270: ldr     x0, [x0, #0xc28]                           S:'dreamhouse_back_room'
02d1c274: bl      #0x2b70db0                                 fn_2b70db0
02d1c278: mov     w8, #1                                     
02d1c27c: strb    w8, [x20, #0x14]                           
02d1c280: mov     x0, xzr                                    
02d1c284: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d1c288: cbz     x0, #0x2d1c320                             
02d1c28c: movi    d1, #0000000000000000                      
02d1c290: movi    d2, #0000000000000000                      
02d1c294: adrp    x20, #0x6265000                            
02d1c298: fmov    s0, #1.00000000                            
02d1c29c: adrp    x21, #0x6264000                            
02d1c2a0: adrp    x22, #0x6269000                            
02d1c2a4: ldr     x20, [x20, #0x310]                         MS:WejoyService.Singleton`1::get_Instance
02d1c2a8: ldr     x21, [x21, #0xf90]                         T:System.Action
02d1c2ac: ldr     x22, [x22, #0xc20]                         M:DreamHouse.PopupNewRoom::<OnBackButtonClicked>b__7_0
02d1c2b0: mov     w1, #1                                     
02d1c2b4: mov     w2, wzr                                    
02d1c2b8: mov     w3, wzr                                    
02d1c2bc: mov     x4, xzr                                    
02d1c2c0: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d1c2c4: ldr     x0, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d1c2c8: bl      #0x3be7218                                 fn_3be7218
02d1c2cc: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d1c2d0: mov     x20, x0                                    
02d1c2d4: mov     x0, x8                                     
02d1c2d8: bl      #0x2b7104c                                 fn_2b7104c
02d1c2dc: ldr     x2, [x22]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1c2e0: mov     x1, x19                                    
02d1c2e4: mov     x3, xzr                                    
02d1c2e8: mov     x21, x0                                    
02d1c2ec: bl      #0x4d8ddbc                                 System.Action::.ctor
02d1c2f0: cbz     x20, #0x2d1c320                            
02d1c2f4: adrp    x8, #0x6269000                             
02d1c2f8: mov     x0, x20                                    
02d1c2fc: mov     x2, x21                                    
02d1c300: ldr     x8, [x8, #0xc28]                           S:'dreamhouse_back_room'
02d1c304: ldp     x20, x19, [sp, #0x20]                      
02d1c308: ldp     x22, x21, [sp, #0x10]                      
02d1c30c: mov     w3, #1                                     
02d1c310: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d1c314: mov     x4, xzr                                    
02d1c318: ldr     x30, [sp], #0x30                           
02d1c31c: b       #0x2c89698                                 AdsManager::ShowInter
02d1c320: bl      #0x2b7105c                                 fn_2b7105c
## OnDecorateButtonClicked() -> void
---- DreamHouse.PopupNewRoom::OnDecorateButtonClicked 0x2d1c324
02d1c324: str     x30, [sp, #-0x30]!                         
02d1c328: stp     x22, x21, [sp, #0x10]                      
02d1c32c: stp     x20, x19, [sp, #0x20]                      
02d1c330: adrp    x20, #0x6630000                            
02d1c334: mov     x19, x0                                    
02d1c338: ldrb    w8, [x20, #0x15]                           
02d1c33c: tbnz    w8, #0, #0x2d1c378                         
02d1c340: adrp    x0, #0x6264000                             
02d1c344: ldr     x0, [x0, #0xf90]                           T:System.Action
02d1c348: bl      #0x2b70db0                                 fn_2b70db0
02d1c34c: adrp    x0, #0x6269000                             
02d1c350: ldr     x0, [x0, #0xc30]                           M:DreamHouse.PopupNewRoom::<OnDecorateButtonClicked>b__8_0
02d1c354: bl      #0x2b70db0                                 fn_2b70db0
02d1c358: adrp    x0, #0x6265000                             
02d1c35c: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02d1c360: bl      #0x2b70db0                                 fn_2b70db0
02d1c364: adrp    x0, #0x6269000                             
02d1c368: ldr     x0, [x0, #0xc38]                           S:'dreamhouse_decorate_room'
02d1c36c: bl      #0x2b70db0                                 fn_2b70db0
02d1c370: mov     w8, #1                                     
02d1c374: strb    w8, [x20, #0x15]                           
02d1c378: mov     x0, xzr                                    
02d1c37c: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d1c380: cbz     x0, #0x2d1c418                             
02d1c384: movi    d1, #0000000000000000                      
02d1c388: movi    d2, #0000000000000000                      
02d1c38c: adrp    x20, #0x6265000                            
02d1c390: fmov    s0, #1.00000000                            
02d1c394: adrp    x21, #0x6264000                            
02d1c398: adrp    x22, #0x6269000                            
02d1c39c: ldr     x20, [x20, #0x310]                         MS:WejoyService.Singleton`1::get_Instance
02d1c3a0: ldr     x21, [x21, #0xf90]                         T:System.Action
02d1c3a4: ldr     x22, [x22, #0xc30]                         M:DreamHouse.PopupNewRoom::<OnDecorateButtonClicked>b__8_0
02d1c3a8: mov     w1, #1                                     
02d1c3ac: mov     w2, wzr                                    
02d1c3b0: mov     w3, wzr                                    
02d1c3b4: mov     x4, xzr                                    
02d1c3b8: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d1c3bc: ldr     x0, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d1c3c0: bl      #0x3be7218                                 fn_3be7218
02d1c3c4: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d1c3c8: mov     x20, x0                                    
02d1c3cc: mov     x0, x8                                     
02d1c3d0: bl      #0x2b7104c                                 fn_2b7104c
02d1c3d4: ldr     x2, [x22]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1c3d8: mov     x1, x19                                    
02d1c3dc: mov     x3, xzr                                    
02d1c3e0: mov     x21, x0                                    
02d1c3e4: bl      #0x4d8ddbc                                 System.Action::.ctor
02d1c3e8: cbz     x20, #0x2d1c418                            
02d1c3ec: adrp    x8, #0x6269000                             
02d1c3f0: mov     x0, x20                                    
02d1c3f4: mov     x2, x21                                    
02d1c3f8: ldr     x8, [x8, #0xc38]                           S:'dreamhouse_decorate_room'
02d1c3fc: ldp     x20, x19, [sp, #0x20]                      
02d1c400: ldp     x22, x21, [sp, #0x10]                      
02d1c404: mov     w3, wzr                                    
02d1c408: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d1c40c: mov     x4, xzr                                    
02d1c410: ldr     x30, [sp], #0x30                           
02d1c414: b       #0x2c89698                                 AdsManager::ShowInter
02d1c418: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- DreamHouse.PopupNewRoom::.ctor 0x2d1c41c
02d1c41c: mov     x1, xzr                                    
02d1c420: b       #0x2cddba8                                 PopupBase::.ctor
## <OnBackButtonClicked>b__7_0() -> void
---- DreamHouse.PopupNewRoom::<OnBackButtonClicked>b__7_0 0x2d1c424
02d1c424: ldr     x8, [x0]                                   
02d1c428: ldp     x2, x1, [x8, #0x198]                       
02d1c42c: br      x2                                         
## <OnDecorateButtonClicked>b__8_0() -> void
---- DreamHouse.PopupNewRoom::<OnDecorateButtonClicked>b__8_0 0x2d1c430
02d1c430: stp     x30, x21, [sp, #-0x20]!                    
02d1c434: stp     x20, x19, [sp, #0x10]                      
02d1c438: adrp    x21, #0x6630000                            
02d1c43c: adrp    x20, #0x6269000                            
02d1c440: mov     x19, x0                                    
02d1c444: ldrb    w8, [x21, #0x16]                           
02d1c448: ldr     x20, [x20, #0xac0]                         MS:MonoSingleton`1::get_Instance
02d1c44c: tbnz    w8, #0, #0x2d1c464                         
02d1c450: adrp    x0, #0x6269000                             
02d1c454: ldr     x0, [x0, #0xac0]                           MS:MonoSingleton`1::get_Instance
02d1c458: bl      #0x2b70db0                                 fn_2b70db0
02d1c45c: mov     w8, #1                                     
02d1c460: strb    w8, [x21, #0x16]                           
02d1c464: ldr     x8, [x19]                                  
02d1c468: mov     x0, x19                                    
02d1c46c: ldp     x9, x1, [x8, #0x198]                       
02d1c470: blr     x9                                         
02d1c474: ldr     x0, [x20]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1c478: bl      #0x3769600                                 fn_3769600
02d1c47c: cbz     x0, #0x2d1c490                             
02d1c480: ldp     x20, x19, [sp, #0x10]                      
02d1c484: mov     x1, xzr                                    
02d1c488: ldp     x30, x21, [sp], #0x20                      
02d1c48c: b       #0x2d18298                                 DreamHouse.DreamHouseController::CompletedRoom
02d1c490: bl      #0x2b7105c                                 fn_2b7105c
