#### CLASS DecorSyncData parent= object
#   field ShowIndex                      string                                             off=0x10 attr=6 
#   field SpriteName                     string                                             off=0x18 attr=6 
#   field LockType                       string                                             off=0x20 attr=6 
#   field Rarity                         string                                             off=0x28 attr=6 
#   field value                          int                                                off=0x30 attr=6 
## .ctor() -> void
---- DecorSyncData::.ctor 0x2ca82c8
02ca82c8: mov     x1, xzr                                    
02ca82cc: b       #0x4e53e9c                                 System.Object::.ctor
