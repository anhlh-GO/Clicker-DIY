#### CLASS AndroidOnFsnCompletedListener/<>c__DisplayClass3_0 parent= object
#   field <>4__this                      AndroidOnFsnCompletedListener                      off=0x10 attr=6 
#   field errorMessage                   string                                             off=0x18 attr=6 
## .ctor() -> void
---- AndroidOnFsnCompletedListener/<>c__DisplayClass3_0::.ctor 0x2c96af0
02c96af0: mov     x1, xzr                                    
02c96af4: b       #0x4e53e9c                                 System.Object::.ctor
## <OnAdCompleted>b__0(object _) -> void
---- AndroidOnFsnCompletedListener/<>c__DisplayClass3_0::<OnAdCompleted>b__0 0x2c96af8
02c96af8: ldr     x8, [x0, #0x10]                            .<>4__this
02c96afc: cbz     x8, #0x2c96b20                             
02c96b00: ldr     x8, [x8, #0x20]                            
02c96b04: cbz     x8, #0x2c96b1c                             
02c96b08: ldr     x1, [x0, #0x18]                            .errorMessage
02c96b0c: ldr     x0, [x8, #0x40]                            
02c96b10: ldr     x2, [x8, #0x28]                            
02c96b14: ldr     x3, [x8, #0x18]                            
02c96b18: br      x3                                         
02c96b1c: ret                                                
02c96b20: str     x30, [sp, #-0x10]!                         
02c96b24: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS AndroidOnFsnCompletedListener parent= UnityEngine.AndroidJavaProxy
#   field onAdCompleted                  System.Action`1<string>                            off=0x20 attr=21 
#   field mainThreadContext              System.Threading.SynchronizationContext            off=0x28 attr=21 
## .ctor(System.Action`1<string> onAdCompleted) -> void
---- AndroidOnFsnCompletedListener::.ctor 0x2c93874
02c93874: str     x30, [sp, #-0x30]!                         
02c93878: stp     x22, x21, [sp, #0x10]                      
02c9387c: stp     x20, x19, [sp, #0x20]                      
02c93880: adrp    x22, #0x662f000                            
02c93884: adrp    x21, #0x6263000                            
02c93888: mov     x20, x1                                    
02c9388c: ldrb    w8, [x22, #0xa04]                          
02c93890: ldr     x21, [x21, #0xec8]                         T:UnityEngine.AndroidJavaProxy
02c93894: mov     x19, x0                                    
02c93898: tbnz    w8, #0, #0x2c938bc                         
02c9389c: adrp    x0, #0x6263000                             
02c938a0: ldr     x0, [x0, #0xec8]                           T:UnityEngine.AndroidJavaProxy
02c938a4: bl      #0x2b70db0                                 fn_2b70db0
02c938a8: adrp    x0, #0x6265000                             
02c938ac: ldr     x0, [x0, #0x750]                           S:'com.ads.fsnforunity.fsnlib.OnFsnCompletedListener'
02c938b0: bl      #0x2b70db0                                 fn_2b70db0
02c938b4: mov     w8, #1                                     
02c938b8: strb    w8, [x22, #0xa04]                          
02c938bc: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c938c0: adrp    x21, #0x6265000                            
02c938c4: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c938c8: ldr     x21, [x21, #0x750]                         S:'com.ads.fsnforunity.fsnlib.OnFsnCompletedListener'
02c938cc: cbnz    w8, #0x2c938d4                             
02c938d0: bl      #0x2b70f30                                 fn_2b70f30
02c938d4: ldr     x1, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c938d8: mov     x0, x19                                    
02c938dc: mov     x2, xzr                                    
02c938e0: bl      #0x5ad2a78                                 UnityEngine.AndroidJavaProxy::.ctor
02c938e4: mov     x0, x19                                    
02c938e8: mov     x1, x20                                    
02c938ec: str     x20, [x0, #0x20]!                          .onAdCompleted
02c938f0: bl      #0x2b70d54                                 fn_2b70d54
02c938f4: mov     x0, xzr                                    
02c938f8: bl      #0x4e739d4                                 System.Threading.SynchronizationContext::get_Current
02c938fc: str     x0, [x19, #0x28]!                          .mainThreadContext
02c93900: mov     x1, x0                                     
02c93904: mov     x0, x19                                    
02c93908: ldp     x20, x19, [sp, #0x20]                      
02c9390c: ldp     x22, x21, [sp, #0x10]                      
02c93910: ldr     x30, [sp], #0x30                           
02c93914: b       #0x2b70d54                                 
## OnAdCompleted(string errorMessage) -> void
---- AndroidOnFsnCompletedListener::OnAdCompleted 0x2c969cc
02c969cc: str     x30, [sp, #-0x30]!                         
02c969d0: stp     x22, x21, [sp, #0x10]                      
02c969d4: stp     x20, x19, [sp, #0x20]                      
02c969d8: adrp    x21, #0x662f000                            
02c969dc: adrp    x22, #0x6265000                            
02c969e0: mov     x20, x1                                    
02c969e4: ldrb    w8, [x21, #0xa05]                          
02c969e8: ldr     x22, [x22, #0x810]                         T:AndroidOnFsnCompletedListener/<>c__DisplayClass3_0
02c969ec: mov     x19, x0                                    
02c969f0: tbnz    w8, #0, #0x2c96a20                         
02c969f4: adrp    x0, #0x6265000                             
02c969f8: ldr     x0, [x0, #0x7e8]                           T:System.Threading.SendOrPostCallback
02c969fc: bl      #0x2b70db0                                 fn_2b70db0
02c96a00: adrp    x0, #0x6265000                             
02c96a04: ldr     x0, [x0, #0x818]                           M:AndroidOnFsnCompletedListener/<>c__DisplayClass3_0::<OnAdCompleted>b__0
02c96a08: bl      #0x2b70db0                                 fn_2b70db0
02c96a0c: adrp    x0, #0x6265000                             
02c96a10: ldr     x0, [x0, #0x810]                           T:AndroidOnFsnCompletedListener/<>c__DisplayClass3_0
02c96a14: bl      #0x2b70db0                                 fn_2b70db0
02c96a18: mov     w8, #1                                     
02c96a1c: strb    w8, [x21, #0xa05]                          
02c96a20: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c96a24: bl      #0x2b7104c                                 fn_2b7104c
02c96a28: mov     x1, xzr                                    
02c96a2c: mov     x21, x0                                    
02c96a30: bl      #0x4e53e9c                                 System.Object::.ctor
02c96a34: cbz     x21, #0x2c96aec                            
02c96a38: mov     x0, x21                                    
02c96a3c: mov     x1, x19                                    
02c96a40: str     x19, [x0, #0x10]!                          
02c96a44: bl      #0x2b70d54                                 fn_2b70d54
02c96a48: mov     x22, x21                                   
02c96a4c: mov     x1, x20                                    
02c96a50: str     x20, [x22, #0x18]!                         
02c96a54: mov     x0, x22                                    
02c96a58: bl      #0x2b70d54                                 fn_2b70d54
02c96a5c: ldr     x20, [x19, #0x28]                          .mainThreadContext
02c96a60: cbz     x20, #0x2c96ab4                            
02c96a64: adrp    x8, #0x6265000                             
02c96a68: adrp    x19, #0x6265000                            
02c96a6c: ldr     x8, [x8, #0x7e8]                           T:System.Threading.SendOrPostCallback
02c96a70: ldr     x19, [x19, #0x818]                         M:AndroidOnFsnCompletedListener/<>c__DisplayClass3_0::<OnAdCompleted>b__0
02c96a74: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c96a78: bl      #0x2b7104c                                 fn_2b7104c
02c96a7c: ldr     x2, [x19]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c96a80: mov     x1, x21                                    
02c96a84: mov     x3, xzr                                    
02c96a88: mov     x19, x0                                    
02c96a8c: bl      #0x4e73098                                 System.Threading.SendOrPostCallback::.ctor
02c96a90: ldr     x8, [x20]                                  
02c96a94: mov     x0, x20                                    
02c96a98: mov     x1, x19                                    
02c96a9c: ldp     x20, x19, [sp, #0x20]                      
02c96aa0: mov     x2, xzr                                    
02c96aa4: ldp     x4, x3, [x8, #0x188]                       
02c96aa8: ldp     x22, x21, [sp, #0x10]                      
02c96aac: ldr     x30, [sp], #0x30                           
02c96ab0: br      x4                                         
02c96ab4: ldr     x8, [x19, #0x20]                           S:'dev log AdsManager show app open ad' .onAdCompleted
02c96ab8: cbz     x8, #0x2c96adc                             
02c96abc: ldr     x1, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c96ac0: ldp     x20, x19, [sp, #0x20]                      
02c96ac4: ldp     x22, x21, [sp, #0x10]                      
02c96ac8: ldr     x0, [x8, #0x40]                            S:'done_ad'
02c96acc: ldr     x2, [x8, #0x28]                            T:AdsManager/<ISetAOAInterval>d__33
02c96ad0: ldr     x3, [x8, #0x18]                            T:AdsManager/<IEHideAdResume>d__30
02c96ad4: ldr     x30, [sp], #0x30                           
02c96ad8: br      x3                                         
02c96adc: ldp     x20, x19, [sp, #0x20]                      
02c96ae0: ldp     x22, x21, [sp, #0x10]                      
02c96ae4: ldr     x30, [sp], #0x30                           
02c96ae8: ret                                                
02c96aec: bl      #0x2b7105c                                 fn_2b7105c
