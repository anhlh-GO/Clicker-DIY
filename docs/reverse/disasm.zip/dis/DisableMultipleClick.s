#### CLASS DisableMultipleClick parent= UnityEngine.MonoBehaviour
## Awake() -> void
---- DisableMultipleClick::Awake 0x2cde464
02cde464: ret                                                
## .ctor() -> void
---- DisableMultipleClick::.ctor 0x2cde468
02cde468: mov     x1, xzr                                    
02cde46c: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
