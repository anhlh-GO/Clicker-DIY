#### CLASS Blindbag.Basket/<>c parent= object
#   field <>9                            Blindbag.Basket/<>c                                off=0x0 attr=36 
#   field <>9__3_0                       System.Func`2<Blindbag.PointData,bool>             off=0x8 attr=16 
#   field <>9__3_1                       System.Func`2<Blindbag.PointData,Blindbag.BlindBagAnimation> off=0x10 attr=16 
#   field <>9__5_0                       System.Func`2<Blindbag.PointData,bool>             off=0x18 attr=16 
#   field <>9__6_0                       System.Func`2<Blindbag.PointData,bool>             off=0x20 attr=16 
#   field <>9__11_0                      System.Func`2<Blindbag.PointData,bool>             off=0x28 attr=16 
#   field <>9__12_0                      System.Func`2<Blindbag.PointData,bool>             off=0x30 attr=16 
#   field <>9__12_1                      System.Func`2<Blindbag.PointData,int>              off=0x38 attr=16 
#   field <>9__13_0                      System.Func`2<Blindbag.PointData,bool>             off=0x40 attr=16 
#   field <>9__13_1                      System.Func`2<Blindbag.PointData,int>              off=0x48 attr=16 
## .cctor() -> void
---- Blindbag.Basket/<>c::.cctor 0x2d4fbbc
02d4fbbc: str     x30, [sp, #-0x20]!                         
02d4fbc0: stp     x20, x19, [sp, #0x10]                      
02d4fbc4: adrp    x19, #0x6630000                            
02d4fbc8: adrp    x20, #0x626b000                            
02d4fbcc: ldrb    w8, [x19, #0x24a]                          
02d4fbd0: ldr     x20, [x20, #0x6c0]                         T:Blindbag.Basket/<>c
02d4fbd4: tbnz    w8, #0, #0x2d4fbec                         
02d4fbd8: adrp    x0, #0x626b000                             
02d4fbdc: ldr     x0, [x0, #0x6c0]                           T:Blindbag.Basket/<>c
02d4fbe0: bl      #0x2b70db0                                 fn_2b70db0
02d4fbe4: mov     w8, #1                                     
02d4fbe8: strb    w8, [x19, #0x24a]                          
02d4fbec: ldr     x0, [x20]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4fbf0: bl      #0x2b7104c                                 fn_2b7104c
02d4fbf4: mov     x1, xzr                                    
02d4fbf8: mov     x19, x0                                    
02d4fbfc: bl      #0x4e53e9c                                 System.Object::.ctor
02d4fc00: ldr     x8, [x20]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4fc04: mov     x1, x19                                    
02d4fc08: ldr     x8, [x8, #0xb8]                            
02d4fc0c: str     x19, [x8]                                  
02d4fc10: ldr     x8, [x20]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4fc14: ldp     x20, x19, [sp, #0x10]                      
02d4fc18: ldr     x0, [x8, #0xb8]                            
02d4fc1c: ldr     x30, [sp], #0x20                           
02d4fc20: b       #0x2b70d54                                 
## .ctor() -> void
---- Blindbag.Basket/<>c::.ctor 0x2d4fc24
02d4fc24: mov     x1, xzr                                    
02d4fc28: b       #0x4e53e9c                                 System.Object::.ctor
## <GetOrderingBags>b__3_0(Blindbag.PointData pointData) -> bool
---- Blindbag.Basket/<>c::<GetOrderingBags>b__3_0 0x2d4fc2c
02d4fc2c: str     x30, [sp, #-0x20]!                         
02d4fc30: stp     x20, x19, [sp, #0x10]                      
02d4fc34: adrp    x20, #0x6630000                            
02d4fc38: mov     x19, x1                                    
02d4fc3c: ldrb    w8, [x20, #0x24b]                          
02d4fc40: tbnz    w8, #0, #0x2d4fc58                         
02d4fc44: adrp    x0, #0x6263000                             
02d4fc48: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d4fc4c: bl      #0x2b70db0                                 fn_2b70db0
02d4fc50: mov     w8, #1                                     
02d4fc54: strb    w8, [x20, #0x24b]                          
02d4fc58: cbz     x19, #0x2d4fc90                            
02d4fc5c: adrp    x8, #0x6263000                             
02d4fc60: ldr     x8, [x8, #0x918]                           T:UnityEngine.Object
02d4fc64: ldr     x19, [x19, #0x20]                          .<>9__6_0
02d4fc68: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02d4fc6c: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d4fc70: cbnz    w8, #0x2d4fc78                             
02d4fc74: bl      #0x2b70f30                                 fn_2b70f30
02d4fc78: mov     x0, x19                                    
02d4fc7c: ldp     x20, x19, [sp, #0x10]                      
02d4fc80: mov     x1, xzr                                    
02d4fc84: mov     x2, xzr                                    
02d4fc88: ldr     x30, [sp], #0x20                           
02d4fc8c: b       #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d4fc90: bl      #0x2b7105c                                 fn_2b7105c
## <GetOrderingBags>b__3_1(Blindbag.PointData pointData) -> Blindbag.BlindBagAnimation
---- Blindbag.Basket/<>c::<GetOrderingBags>b__3_1 0x2d4fc94
02d4fc94: cbz     x1, #0x2d4fca0                             
02d4fc98: ldr     x0, [x1, #0x20]                            
02d4fc9c: ret                                                
02d4fca0: str     x30, [sp, #-0x10]!                         
02d4fca4: bl      #0x2b7105c                                 fn_2b7105c
## <IsFull>b__5_0(Blindbag.PointData pointData) -> bool
---- Blindbag.Basket/<>c::<IsFull>b__5_0 0x2d4fca8
02d4fca8: cbz     x1, #0x2d4fcbc                             
02d4fcac: ldr     w8, [x1, #0x18]                            
02d4fcb0: cmp     w8, #0                                     
02d4fcb4: cset    w0, ne                                     
02d4fcb8: ret                                                
02d4fcbc: str     x30, [sp, #-0x10]!                         
02d4fcc0: bl      #0x2b7105c                                 fn_2b7105c
## <GetPointData>b__6_0(Blindbag.PointData pointData) -> bool
---- Blindbag.Basket/<>c::<GetPointData>b__6_0 0x2d4fcc4
02d4fcc4: cbz     x1, #0x2d4fcd8                             
02d4fcc8: ldr     w8, [x1, #0x18]                            
02d4fccc: cmp     w8, #0                                     
02d4fcd0: cset    w0, eq                                     
02d4fcd4: ret                                                
02d4fcd8: str     x30, [sp, #-0x10]!                         
02d4fcdc: bl      #0x2b7105c                                 fn_2b7105c
## <GetTotalItem>b__11_0(Blindbag.PointData pointData) -> bool
---- Blindbag.Basket/<>c::<GetTotalItem>b__11_0 0x2d4fce0
02d4fce0: cbz     x1, #0x2d4fcf4                             
02d4fce4: ldr     w8, [x1, #0x18]                            
02d4fce8: cmp     w8, #2                                     
02d4fcec: cset    w0, eq                                     
02d4fcf0: ret                                                
02d4fcf4: str     x30, [sp, #-0x10]!                         
02d4fcf8: bl      #0x2b7105c                                 fn_2b7105c
## <GetTotalPrice>b__12_0(Blindbag.PointData pointData) -> bool
---- Blindbag.Basket/<>c::<GetTotalPrice>b__12_0 0x2d4fcfc
02d4fcfc: cbz     x1, #0x2d4fd10                             
02d4fd00: ldr     w8, [x1, #0x18]                            
02d4fd04: cmp     w8, #2                                     
02d4fd08: cset    w0, eq                                     
02d4fd0c: ret                                                
02d4fd10: str     x30, [sp, #-0x10]!                         
02d4fd14: bl      #0x2b7105c                                 fn_2b7105c
## <GetTotalPrice>b__12_1(Blindbag.PointData pointData) -> int
---- Blindbag.Basket/<>c::<GetTotalPrice>b__12_1 0x2d4fd18
02d4fd18: str     x30, [sp, #-0x10]!                         
02d4fd1c: cbz     x1, #0x2d4fd34                             
02d4fd20: ldr     x8, [x1, #0x20]                            
02d4fd24: cbz     x8, #0x2d4fd34                             
02d4fd28: ldr     w0, [x8, #0x50]                            
02d4fd2c: ldr     x30, [sp], #0x10                           
02d4fd30: ret                                                
02d4fd34: bl      #0x2b7105c                                 fn_2b7105c
## <GetReviewPrice>b__13_0(Blindbag.PointData pointData) -> bool
---- Blindbag.Basket/<>c::<GetReviewPrice>b__13_0 0x2d4fd38
02d4fd38: cbz     x1, #0x2d4fd50                             
02d4fd3c: ldr     w8, [x1, #0x18]                            
02d4fd40: sub     w8, w8, #1                                 
02d4fd44: cmp     w8, #2                                     
02d4fd48: cset    w0, lo                                     
02d4fd4c: ret                                                
02d4fd50: str     x30, [sp, #-0x10]!                         
02d4fd54: bl      #0x2b7105c                                 fn_2b7105c
## <GetReviewPrice>b__13_1(Blindbag.PointData pointData) -> int
---- Blindbag.Basket/<>c::<GetReviewPrice>b__13_1 0x2d4fd58
02d4fd58: str     x30, [sp, #-0x10]!                         
02d4fd5c: cbz     x1, #0x2d4fd74                             
02d4fd60: ldr     x8, [x1, #0x20]                            
02d4fd64: cbz     x8, #0x2d4fd74                             
02d4fd68: ldr     w0, [x8, #0x50]                            
02d4fd6c: ldr     x30, [sp], #0x10                           
02d4fd70: ret                                                
02d4fd74: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Blindbag.Basket/<>c__DisplayClass7_0 parent= object
#   field pointData                      Blindbag.PointData                                 off=0x10 attr=6 
#   field <>4__this                      Blindbag.Basket                                    off=0x18 attr=6 
## .ctor() -> void
---- Blindbag.Basket/<>c__DisplayClass7_0::.ctor 0x2d4f624
02d4f624: mov     x1, xzr                                    
02d4f628: b       #0x4e53e9c                                 System.Object::.ctor
## <RemoveLastPoint>b__0() -> void
---- Blindbag.Basket/<>c__DisplayClass7_0::<RemoveLastPoint>b__0 0x2d4fd78
02d4fd78: stp     x30, x19, [sp, #-0x10]!                    
02d4fd7c: mov     x19, x0                                    
02d4fd80: ldr     x0, [x0, #0x10]                            .pointData
02d4fd84: cbz     x0, #0x2d4fdb0                             
02d4fd88: mov     x1, xzr                                    
02d4fd8c: str     xzr, [x0, #0x20]!                          
02d4fd90: stur    wzr, [x0, #-8]                             
02d4fd94: bl      #0x2b70d54                                 fn_2b70d54
02d4fd98: ldr     x8, [x19, #0x18]                           .<>4__this
02d4fd9c: cbz     x8, #0x2d4fdb0                             
02d4fda0: ldr     x0, [x8, #0x30]                            
02d4fda4: cbz     x0, #0x2d4fdb0                             
02d4fda8: ldp     x30, x19, [sp], #0x10                      
02d4fdac: b       #0x2d4fdb4                                 Blindbag.BlindbagGameController::UpdateBasket
02d4fdb0: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Blindbag.Basket parent= UnityEngine.MonoBehaviour
#   field _animator                      Jelly.ItemAnimator                                 off=0x20 attr=1 SerializeField
#   field _point                         System.Collections.Generic.List`1<Blindbag.PointData> off=0x28 attr=1 SerializeField
#   field _controller                    Blindbag.BlindbagGameController                    off=0x30 attr=1 
## GetOrderingBags() -> System.Collections.Generic.List`1<Blindbag.BlindBagAnimation>
---- Blindbag.Basket::GetOrderingBags 0x2d4f034
02d4f034: str     x30, [sp, #-0x40]!                         
02d4f038: stp     x24, x23, [sp, #0x10]                      
02d4f03c: stp     x22, x21, [sp, #0x20]                      
02d4f040: stp     x20, x19, [sp, #0x30]                      
02d4f044: adrp    x20, #0x6630000                            
02d4f048: adrp    x22, #0x626b000                            
02d4f04c: mov     x19, x0                                    
02d4f050: ldrb    w8, [x20, #0x243]                          
02d4f054: ldr     x22, [x22, #0x6c0]                         T:Blindbag.Basket/<>c
02d4f058: tbnz    w8, #0, #0x2d4f0c4                         
02d4f05c: adrp    x0, #0x626b000                             
02d4f060: ldr     x0, [x0, #0x6c8]                           MS:System.Linq.Enumerable::Select
02d4f064: bl      #0x2b70db0                                 fn_2b70db0
02d4f068: adrp    x0, #0x626b000                             
02d4f06c: ldr     x0, [x0, #0x6d0]                           MS:System.Linq.Enumerable::ToList
02d4f070: bl      #0x2b70db0                                 fn_2b70db0
02d4f074: adrp    x0, #0x626b000                             
02d4f078: ldr     x0, [x0, #0x6d8]                           MS:System.Linq.Enumerable::Where
02d4f07c: bl      #0x2b70db0                                 fn_2b70db0
02d4f080: adrp    x0, #0x626b000                             
02d4f084: ldr     x0, [x0, #0x6e0]                           T:type55618(k15)
02d4f088: bl      #0x2b70db0                                 fn_2b70db0
02d4f08c: adrp    x0, #0x626b000                             
02d4f090: ldr     x0, [x0, #0x6e8]                           T:type55619(k15)
02d4f094: bl      #0x2b70db0                                 fn_2b70db0
02d4f098: adrp    x0, #0x626b000                             
02d4f09c: ldr     x0, [x0, #0x6f0]                           M:Blindbag.Basket/<>c::<GetOrderingBags>b__3_0
02d4f0a0: bl      #0x2b70db0                                 fn_2b70db0
02d4f0a4: adrp    x0, #0x626b000                             
02d4f0a8: ldr     x0, [x0, #0x6f8]                           M:Blindbag.Basket/<>c::<GetOrderingBags>b__3_1
02d4f0ac: bl      #0x2b70db0                                 fn_2b70db0
02d4f0b0: adrp    x0, #0x626b000                             
02d4f0b4: ldr     x0, [x0, #0x6c0]                           T:Blindbag.Basket/<>c
02d4f0b8: bl      #0x2b70db0                                 fn_2b70db0
02d4f0bc: mov     w8, #1                                     
02d4f0c0: strb    w8, [x20, #0x243]                          
02d4f0c4: ldr     x0, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4f0c8: ldr     x19, [x19, #0x28]                          ._point
02d4f0cc: ldr     w8, [x0, #0xe4]                            [626b0e4]=0 f=0,0
02d4f0d0: cbnz    w8, #0x2d4f0dc                             
02d4f0d4: bl      #0x2b70f30                                 fn_2b70f30
02d4f0d8: ldr     x0, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4f0dc: ldr     x8, [x0, #0xb8]                            S:'scoop_no_thank'
02d4f0e0: adrp    x23, #0x626b000                            
02d4f0e4: ldr     x20, [x8, #8]                              
02d4f0e8: ldr     x23, [x23, #0x6d8]                         MS:System.Linq.Enumerable::Where
02d4f0ec: cbnz    x20, #0x2d4f148                            
02d4f0f0: ldr     w9, [x0, #0xe4]                            [626b0e4]=0 f=0,0
02d4f0f4: cbnz    w9, #0x2d4f104                             
02d4f0f8: bl      #0x2b70f30                                 fn_2b70f30
02d4f0fc: ldr     x8, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4f100: ldr     x8, [x8, #0xb8]                            
02d4f104: adrp    x9, #0x626b000                             
02d4f108: ldr     x9, [x9, #0x6e8]                           T:type55619(k15)
02d4f10c: ldr     x21, [x8]                                  
02d4f110: ldr     x0, [x9]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4f114: bl      #0x2b7104c                                 fn_2b7104c
02d4f118: adrp    x8, #0x626b000                             
02d4f11c: mov     x1, x21                                    
02d4f120: mov     x3, xzr                                    
02d4f124: ldr     x8, [x8, #0x6f0]                           M:Blindbag.Basket/<>c::<GetOrderingBags>b__3_0
02d4f128: mov     x20, x0                                    
02d4f12c: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4f130: bl      #0x4940cf8                                 fn_4940cf8
02d4f134: ldr     x8, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4f138: mov     x1, x20                                    
02d4f13c: ldr     x0, [x8, #0xb8]                            S:'scoop_no_thank'
02d4f140: str     x20, [x0, #8]!                             
02d4f144: bl      #0x2b70d54                                 fn_2b70d54
02d4f148: ldr     x2, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4f14c: mov     x0, x19                                    
02d4f150: mov     x1, x20                                    
02d4f154: bl      #0x319fec4                                 fn_319fec4
02d4f158: ldr     x8, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4f15c: mov     x19, x0                                    
02d4f160: ldr     w9, [x8, #0xe4]                            [626b0e4]=0 f=0,0
02d4f164: cbnz    w9, #0x2d4f174                             
02d4f168: mov     x0, x8                                     
02d4f16c: bl      #0x2b70f30                                 fn_2b70f30
02d4f170: ldr     x8, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4f174: ldr     x9, [x8, #0xb8]                            S:'scoop_no_thank'
02d4f178: adrp    x24, #0x626b000                            
02d4f17c: adrp    x23, #0x626b000                            
02d4f180: ldr     x24, [x24, #0x6c8]                         MS:System.Linq.Enumerable::Select
02d4f184: ldr     x20, [x9, #0x10]                           MS:System.Collections.Generic.List`1::Find
02d4f188: ldr     x23, [x23, #0x6d0]                         MS:System.Linq.Enumerable::ToList
02d4f18c: cbnz    x20, #0x2d4f1ec                            
02d4f190: ldr     w10, [x8, #0xe4]                           [626b0e4]=0 f=0,0
02d4f194: cbnz    w10, #0x2d4f1a8                            
02d4f198: mov     x0, x8                                     
02d4f19c: bl      #0x2b70f30                                 fn_2b70f30
02d4f1a0: ldr     x8, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4f1a4: ldr     x9, [x8, #0xb8]                            S:'scoop_no_thank'
02d4f1a8: adrp    x8, #0x626b000                             
02d4f1ac: ldr     x8, [x8, #0x6e0]                           T:type55618(k15)
02d4f1b0: ldr     x21, [x9]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4f1b4: ldr     x0, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4f1b8: bl      #0x2b7104c                                 fn_2b7104c
02d4f1bc: adrp    x8, #0x626b000                             
02d4f1c0: mov     x1, x21                                    
02d4f1c4: mov     x3, xzr                                    
02d4f1c8: ldr     x8, [x8, #0x6f8]                           M:Blindbag.Basket/<>c::<GetOrderingBags>b__3_1
02d4f1cc: mov     x20, x0                                    
02d4f1d0: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4f1d4: bl      #0x49416f4                                 fn_49416f4
02d4f1d8: ldr     x8, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4f1dc: mov     x1, x20                                    
02d4f1e0: ldr     x0, [x8, #0xb8]                            S:'scoop_no_thank'
02d4f1e4: str     x20, [x0, #0x10]!                          
02d4f1e8: bl      #0x2b70d54                                 fn_2b70d54
02d4f1ec: ldr     x2, [x24]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4f1f0: mov     x0, x19                                    
02d4f1f4: mov     x1, x20                                    
02d4f1f8: bl      #0x3193858                                 fn_3193858
02d4f1fc: ldr     x1, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4f200: ldp     x20, x19, [sp, #0x30]                      
02d4f204: ldp     x22, x21, [sp, #0x20]                      
02d4f208: ldp     x24, x23, [sp, #0x10]                      
02d4f20c: ldr     x30, [sp], #0x40                           
02d4f210: b       #0x319eb2c                                 
## OnInitialized(Blindbag.BlindbagGameController controller) -> void
---- Blindbag.Basket::OnInitialized 0x2d4f214
02d4f214: str     x1, [x0, #0x30]!                           ._controller
02d4f218: b       #0x2b70d54                                 
## IsFull() -> bool
---- Blindbag.Basket::IsFull 0x2d4f21c
02d4f21c: stp     x30, x23, [sp, #-0x30]!                    
02d4f220: stp     x22, x21, [sp, #0x10]                      
02d4f224: stp     x20, x19, [sp, #0x20]                      
02d4f228: adrp    x20, #0x6630000                            
02d4f22c: adrp    x22, #0x626b000                            
02d4f230: mov     x19, x0                                    
02d4f234: ldrb    w8, [x20, #0x244]                          
02d4f238: ldr     x22, [x22, #0x6c0]                         T:Blindbag.Basket/<>c
02d4f23c: tbnz    w8, #0, #0x2d4f278                         
02d4f240: adrp    x0, #0x626b000                             
02d4f244: ldr     x0, [x0, #0x700]                           MS:System.Linq.Enumerable::All
02d4f248: bl      #0x2b70db0                                 fn_2b70db0
02d4f24c: adrp    x0, #0x626b000                             
02d4f250: ldr     x0, [x0, #0x6e8]                           T:type55619(k15)
02d4f254: bl      #0x2b70db0                                 fn_2b70db0
02d4f258: adrp    x0, #0x626b000                             
02d4f25c: ldr     x0, [x0, #0x708]                           M:Blindbag.Basket/<>c::<IsFull>b__5_0
02d4f260: bl      #0x2b70db0                                 fn_2b70db0
02d4f264: adrp    x0, #0x626b000                             
02d4f268: ldr     x0, [x0, #0x6c0]                           T:Blindbag.Basket/<>c
02d4f26c: bl      #0x2b70db0                                 fn_2b70db0
02d4f270: mov     w8, #1                                     
02d4f274: strb    w8, [x20, #0x244]                          
02d4f278: ldr     x0, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4f27c: ldr     x19, [x19, #0x28]                          ._point
02d4f280: ldr     w8, [x0, #0xe4]                            [626b0e4]=0 f=0,0
02d4f284: cbnz    w8, #0x2d4f290                             
02d4f288: bl      #0x2b70f30                                 fn_2b70f30
02d4f28c: ldr     x0, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4f290: ldr     x8, [x0, #0xb8]                            S:'scoop_no_thank'
02d4f294: adrp    x23, #0x626b000                            
02d4f298: ldr     x20, [x8, #0x18]                           
02d4f29c: ldr     x23, [x23, #0x700]                         MS:System.Linq.Enumerable::All
02d4f2a0: cbnz    x20, #0x2d4f2fc                            
02d4f2a4: ldr     w9, [x0, #0xe4]                            [626b0e4]=0 f=0,0
02d4f2a8: cbnz    w9, #0x2d4f2b8                             
02d4f2ac: bl      #0x2b70f30                                 fn_2b70f30
02d4f2b0: ldr     x8, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4f2b4: ldr     x8, [x8, #0xb8]                            
02d4f2b8: adrp    x9, #0x626b000                             
02d4f2bc: ldr     x9, [x9, #0x6e8]                           T:type55619(k15)
02d4f2c0: ldr     x21, [x8]                                  
02d4f2c4: ldr     x0, [x9]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4f2c8: bl      #0x2b7104c                                 fn_2b7104c
02d4f2cc: adrp    x8, #0x626b000                             
02d4f2d0: mov     x1, x21                                    
02d4f2d4: mov     x3, xzr                                    
02d4f2d8: ldr     x8, [x8, #0x708]                           M:Blindbag.Basket/<>c::<IsFull>b__5_0
02d4f2dc: mov     x20, x0                                    
02d4f2e0: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4f2e4: bl      #0x4940cf8                                 fn_4940cf8
02d4f2e8: ldr     x8, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4f2ec: mov     x1, x20                                    
02d4f2f0: ldr     x0, [x8, #0xb8]                            S:'scoop_no_thank'
02d4f2f4: str     x20, [x0, #0x18]!                          
02d4f2f8: bl      #0x2b70d54                                 fn_2b70d54
02d4f2fc: mov     x0, x19                                    
02d4f300: mov     x1, x20                                    
02d4f304: ldr     x2, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4f308: ldp     x20, x19, [sp, #0x20]                      
02d4f30c: ldp     x22, x21, [sp, #0x10]                      
02d4f310: ldp     x30, x23, [sp], #0x30                      
02d4f314: b       #0x317aad4                                 
## GetPointData() -> Blindbag.PointData
---- Blindbag.Basket::GetPointData 0x2d4f318
02d4f318: stp     x30, x23, [sp, #-0x30]!                    
02d4f31c: stp     x22, x21, [sp, #0x10]                      
02d4f320: stp     x20, x19, [sp, #0x20]                      
02d4f324: adrp    x20, #0x6630000                            
02d4f328: adrp    x22, #0x626b000                            
02d4f32c: mov     x19, x0                                    
02d4f330: ldrb    w8, [x20, #0x245]                          
02d4f334: ldr     x22, [x22, #0x6c0]                         T:Blindbag.Basket/<>c
02d4f338: tbnz    w8, #0, #0x2d4f374                         
02d4f33c: adrp    x0, #0x626b000                             
02d4f340: ldr     x0, [x0, #0x710]                           MS:System.Linq.Enumerable::FirstOrDefault
02d4f344: bl      #0x2b70db0                                 fn_2b70db0
02d4f348: adrp    x0, #0x626b000                             
02d4f34c: ldr     x0, [x0, #0x6e8]                           T:type55619(k15)
02d4f350: bl      #0x2b70db0                                 fn_2b70db0
02d4f354: adrp    x0, #0x626b000                             
02d4f358: ldr     x0, [x0, #0x718]                           M:Blindbag.Basket/<>c::<GetPointData>b__6_0
02d4f35c: bl      #0x2b70db0                                 fn_2b70db0
02d4f360: adrp    x0, #0x626b000                             
02d4f364: ldr     x0, [x0, #0x6c0]                           T:Blindbag.Basket/<>c
02d4f368: bl      #0x2b70db0                                 fn_2b70db0
02d4f36c: mov     w8, #1                                     
02d4f370: strb    w8, [x20, #0x245]                          
02d4f374: ldr     x0, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4f378: ldr     x19, [x19, #0x28]                          ._point
02d4f37c: ldr     w8, [x0, #0xe4]                            [626b0e4]=0 f=0,0
02d4f380: cbnz    w8, #0x2d4f38c                             
02d4f384: bl      #0x2b70f30                                 fn_2b70f30
02d4f388: ldr     x0, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4f38c: ldr     x8, [x0, #0xb8]                            S:'scoop_no_thank'
02d4f390: adrp    x23, #0x626b000                            
02d4f394: ldr     x20, [x8, #0x20]                           
02d4f398: ldr     x23, [x23, #0x710]                         MS:System.Linq.Enumerable::FirstOrDefault
02d4f39c: cbnz    x20, #0x2d4f3f8                            
02d4f3a0: ldr     w9, [x0, #0xe4]                            [626b0e4]=0 f=0,0
02d4f3a4: cbnz    w9, #0x2d4f3b4                             
02d4f3a8: bl      #0x2b70f30                                 fn_2b70f30
02d4f3ac: ldr     x8, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4f3b0: ldr     x8, [x8, #0xb8]                            
02d4f3b4: adrp    x9, #0x626b000                             
02d4f3b8: ldr     x9, [x9, #0x6e8]                           T:type55619(k15)
02d4f3bc: ldr     x21, [x8]                                  
02d4f3c0: ldr     x0, [x9]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4f3c4: bl      #0x2b7104c                                 fn_2b7104c
02d4f3c8: adrp    x8, #0x626b000                             
02d4f3cc: mov     x1, x21                                    
02d4f3d0: mov     x3, xzr                                    
02d4f3d4: ldr     x8, [x8, #0x718]                           M:Blindbag.Basket/<>c::<GetPointData>b__6_0
02d4f3d8: mov     x20, x0                                    
02d4f3dc: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4f3e0: bl      #0x4940cf8                                 fn_4940cf8
02d4f3e4: ldr     x8, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4f3e8: mov     x1, x20                                    
02d4f3ec: ldr     x0, [x8, #0xb8]                            S:'scoop_no_thank'
02d4f3f0: str     x20, [x0, #0x20]!                          ._animator
02d4f3f4: bl      #0x2b70d54                                 fn_2b70d54
02d4f3f8: mov     x0, x19                                    
02d4f3fc: mov     x1, x20                                    
02d4f400: ldr     x2, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4f404: ldp     x20, x19, [sp, #0x20]                      
02d4f408: ldp     x22, x21, [sp, #0x10]                      
02d4f40c: ldp     x30, x23, [sp], #0x30                      
02d4f410: b       #0x318c658                                 
## RemoveLastPoint() -> void
---- Blindbag.Basket::RemoveLastPoint 0x2d4f414
02d4f414: str     x30, [sp, #-0x40]!                         
02d4f418: stp     x24, x23, [sp, #0x10]                      
02d4f41c: stp     x22, x21, [sp, #0x20]                      
02d4f420: stp     x20, x19, [sp, #0x30]                      
02d4f424: adrp    x20, #0x6630000                            
02d4f428: mov     x19, x0                                    
02d4f42c: ldrb    w8, [x20, #0x246]                          
02d4f430: tbnz    w8, #0, #0x2d4f478                         
02d4f434: adrp    x0, #0x6264000                             
02d4f438: ldr     x0, [x0, #0xf90]                           T:System.Action
02d4f43c: bl      #0x2b70db0                                 fn_2b70db0
02d4f440: adrp    x0, #0x626b000                             
02d4f444: ldr     x0, [x0, #0x720]                           MS:System.Collections.Generic.List`1::get_Count
02d4f448: bl      #0x2b70db0                                 fn_2b70db0
02d4f44c: adrp    x0, #0x626b000                             
02d4f450: ldr     x0, [x0, #0x728]                           MS:System.Collections.Generic.List`1::get_Item
02d4f454: bl      #0x2b70db0                                 fn_2b70db0
02d4f458: adrp    x0, #0x626b000                             
02d4f45c: ldr     x0, [x0, #0x730]                           M:Blindbag.Basket/<>c__DisplayClass7_0::<RemoveLastPoint>b__0
02d4f460: bl      #0x2b70db0                                 fn_2b70db0
02d4f464: adrp    x0, #0x626b000                             
02d4f468: ldr     x0, [x0, #0x738]                           T:Blindbag.Basket/<>c__DisplayClass7_0
02d4f46c: bl      #0x2b70db0                                 fn_2b70db0
02d4f470: mov     w8, #1                                     
02d4f474: strb    w8, [x20, #0x246]                          
02d4f478: ldr     x0, [x19, #0x30]                           ._controller
02d4f47c: cbz     x0, #0x2d4f5b8                             
02d4f480: mov     w1, wzr                                    
02d4f484: bl      #0x2d4f5bc                                 Blindbag.BlindbagGameController::EnableConfirmOrderButton
02d4f488: ldr     x8, [x19, #0x28]                           ._point
02d4f48c: cbz     x8, #0x2d4f5b8                             
02d4f490: adrp    x23, #0x626b000                            
02d4f494: adrp    x24, #0x626b000                            
02d4f498: ldr     x23, [x23, #0x738]                         T:Blindbag.Basket/<>c__DisplayClass7_0
02d4f49c: ldr     w8, [x8, #0x18]                            
02d4f4a0: ldr     x24, [x24, #0x728]                         MS:System.Collections.Generic.List`1::get_Item
02d4f4a4: sub     w21, w8, #1                                
02d4f4a8: tbnz    w21, #0x1f, #0x2d4f5a4                     
02d4f4ac: ldr     x0, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4f4b0: bl      #0x2b7104c                                 fn_2b7104c
02d4f4b4: mov     x1, xzr                                    
02d4f4b8: mov     x20, x0                                    
02d4f4bc: bl      #0x4e53e9c                                 System.Object::.ctor
02d4f4c0: cbz     x20, #0x2d4f5b8                            
02d4f4c4: mov     x0, x20                                    
02d4f4c8: mov     x1, x19                                    
02d4f4cc: str     x19, [x0, #0x18]!                          
02d4f4d0: bl      #0x2b70d54                                 fn_2b70d54
02d4f4d4: ldr     x0, [x19, #0x28]                           ._point
02d4f4d8: cbz     x0, #0x2d4f5b8                             
02d4f4dc: ldr     x2, [x24]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4f4e0: mov     w1, w21                                    
02d4f4e4: bl      #0x35a8f3c                                 fn_35a8f3c
02d4f4e8: mov     x22, x20                                   
02d4f4ec: mov     x1, x0                                     
02d4f4f0: str     x0, [x22, #0x10]!                          
02d4f4f4: mov     x0, x22                                    
02d4f4f8: bl      #0x2b70d54                                 fn_2b70d54
02d4f4fc: ldr     x8, [x22]                                  
02d4f500: cbz     x8, #0x2d4f5b8                             
02d4f504: ldr     w9, [x8, #0x18]                            
02d4f508: sub     w21, w21, #1                               
02d4f50c: cmp     w9, #2                                     
02d4f510: b.ne    #0x2d4f4a8                                 
02d4f514: mov     w9, #1                                     
02d4f518: mov     x0, xzr                                    
02d4f51c: str     w9, [x8, #0x18]                            
02d4f520: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d4f524: cbz     x0, #0x2d4f5b8                             
02d4f528: movi    d1, #0000000000000000                      
02d4f52c: movi    d2, #0000000000000000                      
02d4f530: mov     w1, #0x10                                  
02d4f534: fmov    s0, #1.00000000                            
02d4f538: mov     w2, wzr                                    
02d4f53c: mov     w3, wzr                                    
02d4f540: mov     x4, xzr                                    
02d4f544: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d4f548: ldr     x8, [x22]                                  
02d4f54c: cbz     x8, #0x2d4f5b8                             
02d4f550: adrp    x9, #0x6264000                             
02d4f554: ldr     x9, [x9, #0xf90]                           T:System.Action
02d4f558: ldr     x19, [x8, #0x20]                           
02d4f55c: ldr     x0, [x9]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d4f560: bl      #0x2b7104c                                 fn_2b7104c
02d4f564: adrp    x8, #0x626b000                             
02d4f568: mov     x1, x20                                    
02d4f56c: mov     x3, xzr                                    
02d4f570: ldr     x8, [x8, #0x730]                           M:Blindbag.Basket/<>c__DisplayClass7_0::<RemoveLastPoint>b__0
02d4f574: mov     x21, x0                                    
02d4f578: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4f57c: bl      #0x4d8ddbc                                 System.Action::.ctor
02d4f580: cbz     x19, #0x2d4f5b8                            
02d4f584: mov     x0, x19                                    
02d4f588: mov     x1, x21                                    
02d4f58c: fmov    s0, #1.00000000                            
02d4f590: ldp     x20, x19, [sp, #0x30]                      
02d4f594: ldp     x22, x21, [sp, #0x20]                      
02d4f598: ldp     x24, x23, [sp, #0x10]                      
02d4f59c: ldr     x30, [sp], #0x40                           
02d4f5a0: b       #0x2d4f62c                                 Blindbag.BlindBagAnimation::FadeOut
02d4f5a4: ldp     x20, x19, [sp, #0x30]                      
02d4f5a8: ldp     x22, x21, [sp, #0x20]                      
02d4f5ac: ldp     x24, x23, [sp, #0x10]                      
02d4f5b0: ldr     x30, [sp], #0x40                           
02d4f5b4: ret                                                
02d4f5b8: bl      #0x2b7105c                                 fn_2b7105c
## OnMouseButtonDown() -> void
---- Blindbag.Basket::OnMouseButtonDown 0x2d4f710
02d4f710: stp     x30, x19, [sp, #-0x10]!                    
02d4f714: mov     x19, x0                                    
02d4f718: ldr     x0, [x0, #0x20]                            ._animator
02d4f71c: cbz     x0, #0x2d4f734                             
02d4f720: mov     x1, xzr                                    
02d4f724: bl      #0x2d14ea4                                 Jelly.ItemAnimator::ShowUp
02d4f728: mov     x0, x19                                    
02d4f72c: ldp     x30, x19, [sp], #0x10                      
02d4f730: b       #0x2d4f414                                 Blindbag.Basket::RemoveLastPoint
02d4f734: bl      #0x2b7105c                                 fn_2b7105c
## OnMouseButtonDrag() -> void
---- Blindbag.Basket::OnMouseButtonDrag 0x2d4f738
02d4f738: ret                                                
## OnMouseButtonUp() -> void
---- Blindbag.Basket::OnMouseButtonUp 0x2d4f73c
02d4f73c: ret                                                
## GetTotalItem() -> int
---- Blindbag.Basket::GetTotalItem 0x2d4f740
02d4f740: stp     x30, x23, [sp, #-0x30]!                    
02d4f744: stp     x22, x21, [sp, #0x10]                      
02d4f748: stp     x20, x19, [sp, #0x20]                      
02d4f74c: adrp    x20, #0x6630000                            
02d4f750: adrp    x22, #0x626b000                            
02d4f754: mov     x19, x0                                    
02d4f758: ldrb    w8, [x20, #0x247]                          
02d4f75c: ldr     x22, [x22, #0x6c0]                         T:Blindbag.Basket/<>c
02d4f760: tbnz    w8, #0, #0x2d4f79c                         
02d4f764: adrp    x0, #0x626b000                             
02d4f768: ldr     x0, [x0, #0x758]                           MS:System.Linq.Enumerable::Count
02d4f76c: bl      #0x2b70db0                                 fn_2b70db0
02d4f770: adrp    x0, #0x626b000                             
02d4f774: ldr     x0, [x0, #0x6e8]                           T:type55619(k15)
02d4f778: bl      #0x2b70db0                                 fn_2b70db0
02d4f77c: adrp    x0, #0x626b000                             
02d4f780: ldr     x0, [x0, #0x760]                           M:Blindbag.Basket/<>c::<GetTotalItem>b__11_0
02d4f784: bl      #0x2b70db0                                 fn_2b70db0
02d4f788: adrp    x0, #0x626b000                             
02d4f78c: ldr     x0, [x0, #0x6c0]                           T:Blindbag.Basket/<>c
02d4f790: bl      #0x2b70db0                                 fn_2b70db0
02d4f794: mov     w8, #1                                     
02d4f798: strb    w8, [x20, #0x247]                          
02d4f79c: ldr     x0, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4f7a0: ldr     x19, [x19, #0x28]                          ._point
02d4f7a4: ldr     w8, [x0, #0xe4]                            [626b0e4]=0 f=0,0
02d4f7a8: cbnz    w8, #0x2d4f7b4                             
02d4f7ac: bl      #0x2b70f30                                 fn_2b70f30
02d4f7b0: ldr     x0, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4f7b4: ldr     x8, [x0, #0xb8]                            S:'scoop_no_thank'
02d4f7b8: adrp    x23, #0x626b000                            
02d4f7bc: ldr     x20, [x8, #0x28]                           
02d4f7c0: ldr     x23, [x23, #0x758]                         MS:System.Linq.Enumerable::Count
02d4f7c4: cbnz    x20, #0x2d4f820                            
02d4f7c8: ldr     w9, [x0, #0xe4]                            [626b0e4]=0 f=0,0
02d4f7cc: cbnz    w9, #0x2d4f7dc                             
02d4f7d0: bl      #0x2b70f30                                 fn_2b70f30
02d4f7d4: ldr     x8, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4f7d8: ldr     x8, [x8, #0xb8]                            
02d4f7dc: adrp    x9, #0x626b000                             
02d4f7e0: ldr     x9, [x9, #0x6e8]                           T:type55619(k15)
02d4f7e4: ldr     x21, [x8]                                  
02d4f7e8: ldr     x0, [x9]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4f7ec: bl      #0x2b7104c                                 fn_2b7104c
02d4f7f0: adrp    x8, #0x626b000                             
02d4f7f4: mov     x1, x21                                    
02d4f7f8: mov     x3, xzr                                    
02d4f7fc: ldr     x8, [x8, #0x760]                           M:Blindbag.Basket/<>c::<GetTotalItem>b__11_0
02d4f800: mov     x20, x0                                    
02d4f804: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4f808: bl      #0x4940cf8                                 fn_4940cf8
02d4f80c: ldr     x8, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4f810: mov     x1, x20                                    
02d4f814: ldr     x0, [x8, #0xb8]                            S:'scoop_no_thank'
02d4f818: str     x20, [x0, #0x28]!                          ._point
02d4f81c: bl      #0x2b70d54                                 fn_2b70d54
02d4f820: mov     x0, x19                                    
02d4f824: mov     x1, x20                                    
02d4f828: ldr     x2, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4f82c: ldp     x20, x19, [sp, #0x20]                      
02d4f830: ldp     x22, x21, [sp, #0x10]                      
02d4f834: ldp     x30, x23, [sp], #0x30                      
02d4f838: b       #0x31878c4                                 
## GetTotalPrice() -> int
---- Blindbag.Basket::GetTotalPrice 0x2d4f83c
02d4f83c: stp     x30, x23, [sp, #-0x30]!                    
02d4f840: stp     x22, x21, [sp, #0x10]                      
02d4f844: stp     x20, x19, [sp, #0x20]                      
02d4f848: adrp    x20, #0x6630000                            
02d4f84c: adrp    x22, #0x626b000                            
02d4f850: mov     x19, x0                                    
02d4f854: ldrb    w8, [x20, #0x248]                          
02d4f858: ldr     x22, [x22, #0x6c0]                         T:Blindbag.Basket/<>c
02d4f85c: tbnz    w8, #0, #0x2d4f8bc                         
02d4f860: adrp    x0, #0x626b000                             
02d4f864: ldr     x0, [x0, #0x768]                           MS:System.Linq.Enumerable::Sum
02d4f868: bl      #0x2b70db0                                 fn_2b70db0
02d4f86c: adrp    x0, #0x626b000                             
02d4f870: ldr     x0, [x0, #0x6d8]                           MS:System.Linq.Enumerable::Where
02d4f874: bl      #0x2b70db0                                 fn_2b70db0
02d4f878: adrp    x0, #0x626b000                             
02d4f87c: ldr     x0, [x0, #0x770]                           T:type55620(k15)
02d4f880: bl      #0x2b70db0                                 fn_2b70db0
02d4f884: adrp    x0, #0x626b000                             
02d4f888: ldr     x0, [x0, #0x6e8]                           T:type55619(k15)
02d4f88c: bl      #0x2b70db0                                 fn_2b70db0
02d4f890: adrp    x0, #0x626b000                             
02d4f894: ldr     x0, [x0, #0x778]                           M:Blindbag.Basket/<>c::<GetTotalPrice>b__12_0
02d4f898: bl      #0x2b70db0                                 fn_2b70db0
02d4f89c: adrp    x0, #0x626b000                             
02d4f8a0: ldr     x0, [x0, #0x780]                           M:Blindbag.Basket/<>c::<GetTotalPrice>b__12_1
02d4f8a4: bl      #0x2b70db0                                 fn_2b70db0
02d4f8a8: adrp    x0, #0x626b000                             
02d4f8ac: ldr     x0, [x0, #0x6c0]                           T:Blindbag.Basket/<>c
02d4f8b0: bl      #0x2b70db0                                 fn_2b70db0
02d4f8b4: mov     w8, #1                                     
02d4f8b8: strb    w8, [x20, #0x248]                          
02d4f8bc: ldr     x0, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4f8c0: ldr     x19, [x19, #0x28]                          ._point
02d4f8c4: ldr     w8, [x0, #0xe4]                            [626b0e4]=0 f=0,0
02d4f8c8: cbnz    w8, #0x2d4f8d4                             
02d4f8cc: bl      #0x2b70f30                                 fn_2b70f30
02d4f8d0: ldr     x0, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4f8d4: ldr     x8, [x0, #0xb8]                            S:'scoop_no_thank'
02d4f8d8: adrp    x23, #0x626b000                            
02d4f8dc: ldr     x20, [x8, #0x30]                           
02d4f8e0: ldr     x23, [x23, #0x6d8]                         MS:System.Linq.Enumerable::Where
02d4f8e4: cbnz    x20, #0x2d4f940                            
02d4f8e8: ldr     w9, [x0, #0xe4]                            [626b0e4]=0 f=0,0
02d4f8ec: cbnz    w9, #0x2d4f8fc                             
02d4f8f0: bl      #0x2b70f30                                 fn_2b70f30
02d4f8f4: ldr     x8, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4f8f8: ldr     x8, [x8, #0xb8]                            
02d4f8fc: adrp    x9, #0x626b000                             
02d4f900: ldr     x9, [x9, #0x6e8]                           T:type55619(k15)
02d4f904: ldr     x21, [x8]                                  
02d4f908: ldr     x0, [x9]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4f90c: bl      #0x2b7104c                                 fn_2b7104c
02d4f910: adrp    x8, #0x626b000                             
02d4f914: mov     x1, x21                                    
02d4f918: mov     x3, xzr                                    
02d4f91c: ldr     x8, [x8, #0x778]                           M:Blindbag.Basket/<>c::<GetTotalPrice>b__12_0
02d4f920: mov     x20, x0                                    
02d4f924: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4f928: bl      #0x4940cf8                                 fn_4940cf8
02d4f92c: ldr     x8, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4f930: mov     x1, x20                                    
02d4f934: ldr     x0, [x8, #0xb8]                            S:'scoop_no_thank'
02d4f938: str     x20, [x0, #0x30]!                          ._controller
02d4f93c: bl      #0x2b70d54                                 fn_2b70d54
02d4f940: ldr     x2, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4f944: mov     x0, x19                                    
02d4f948: mov     x1, x20                                    
02d4f94c: bl      #0x319fec4                                 fn_319fec4
02d4f950: ldr     x8, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4f954: mov     x19, x0                                    
02d4f958: ldr     w9, [x8, #0xe4]                            [626b0e4]=0 f=0,0
02d4f95c: cbnz    w9, #0x2d4f96c                             
02d4f960: mov     x0, x8                                     
02d4f964: bl      #0x2b70f30                                 fn_2b70f30
02d4f968: ldr     x8, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4f96c: ldr     x9, [x8, #0xb8]                            S:'scoop_no_thank'
02d4f970: adrp    x23, #0x626b000                            
02d4f974: ldr     x20, [x9, #0x38]                           MS:UnityEngine.Component::GetComponent
02d4f978: ldr     x23, [x23, #0x768]                         MS:System.Linq.Enumerable::Sum
02d4f97c: cbnz    x20, #0x2d4f9dc                            
02d4f980: ldr     w10, [x8, #0xe4]                           [626b0e4]=0 f=0,0
02d4f984: cbnz    w10, #0x2d4f998                            
02d4f988: mov     x0, x8                                     
02d4f98c: bl      #0x2b70f30                                 fn_2b70f30
02d4f990: ldr     x8, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4f994: ldr     x9, [x8, #0xb8]                            S:'scoop_no_thank'
02d4f998: adrp    x8, #0x626b000                             
02d4f99c: ldr     x8, [x8, #0x770]                           T:type55620(k15)
02d4f9a0: ldr     x21, [x9]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4f9a4: ldr     x0, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4f9a8: bl      #0x2b7104c                                 fn_2b7104c
02d4f9ac: adrp    x8, #0x626b000                             
02d4f9b0: mov     x1, x21                                    
02d4f9b4: mov     x3, xzr                                    
02d4f9b8: ldr     x8, [x8, #0x780]                           M:Blindbag.Basket/<>c::<GetTotalPrice>b__12_1
02d4f9bc: mov     x20, x0                                    
02d4f9c0: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4f9c4: bl      #0x4941168                                 fn_4941168
02d4f9c8: ldr     x8, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4f9cc: mov     x1, x20                                    
02d4f9d0: ldr     x0, [x8, #0xb8]                            S:'scoop_no_thank'
02d4f9d4: str     x20, [x0, #0x38]!                          
02d4f9d8: bl      #0x2b70d54                                 fn_2b70d54
02d4f9dc: mov     x0, x19                                    
02d4f9e0: mov     x1, x20                                    
02d4f9e4: ldr     x2, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4f9e8: ldp     x20, x19, [sp, #0x20]                      
02d4f9ec: ldp     x22, x21, [sp, #0x10]                      
02d4f9f0: ldp     x30, x23, [sp], #0x30                      
02d4f9f4: b       #0x319babc                                 
## GetReviewPrice() -> int
---- Blindbag.Basket::GetReviewPrice 0x2d4f9f8
02d4f9f8: stp     x30, x23, [sp, #-0x30]!                    
02d4f9fc: stp     x22, x21, [sp, #0x10]                      
02d4fa00: stp     x20, x19, [sp, #0x20]                      
02d4fa04: adrp    x20, #0x6630000                            
02d4fa08: adrp    x22, #0x626b000                            
02d4fa0c: mov     x19, x0                                    
02d4fa10: ldrb    w8, [x20, #0x249]                          
02d4fa14: ldr     x22, [x22, #0x6c0]                         T:Blindbag.Basket/<>c
02d4fa18: tbnz    w8, #0, #0x2d4fa78                         
02d4fa1c: adrp    x0, #0x626b000                             
02d4fa20: ldr     x0, [x0, #0x768]                           MS:System.Linq.Enumerable::Sum
02d4fa24: bl      #0x2b70db0                                 fn_2b70db0
02d4fa28: adrp    x0, #0x626b000                             
02d4fa2c: ldr     x0, [x0, #0x6d8]                           MS:System.Linq.Enumerable::Where
02d4fa30: bl      #0x2b70db0                                 fn_2b70db0
02d4fa34: adrp    x0, #0x626b000                             
02d4fa38: ldr     x0, [x0, #0x770]                           T:type55620(k15)
02d4fa3c: bl      #0x2b70db0                                 fn_2b70db0
02d4fa40: adrp    x0, #0x626b000                             
02d4fa44: ldr     x0, [x0, #0x6e8]                           T:type55619(k15)
02d4fa48: bl      #0x2b70db0                                 fn_2b70db0
02d4fa4c: adrp    x0, #0x626b000                             
02d4fa50: ldr     x0, [x0, #0x788]                           M:Blindbag.Basket/<>c::<GetReviewPrice>b__13_0
02d4fa54: bl      #0x2b70db0                                 fn_2b70db0
02d4fa58: adrp    x0, #0x626b000                             
02d4fa5c: ldr     x0, [x0, #0x790]                           M:Blindbag.Basket/<>c::<GetReviewPrice>b__13_1
02d4fa60: bl      #0x2b70db0                                 fn_2b70db0
02d4fa64: adrp    x0, #0x626b000                             
02d4fa68: ldr     x0, [x0, #0x6c0]                           T:Blindbag.Basket/<>c
02d4fa6c: bl      #0x2b70db0                                 fn_2b70db0
02d4fa70: mov     w8, #1                                     
02d4fa74: strb    w8, [x20, #0x249]                          
02d4fa78: ldr     x0, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4fa7c: ldr     x19, [x19, #0x28]                          ._point
02d4fa80: ldr     w8, [x0, #0xe4]                            [626b0e4]=0 f=0,0
02d4fa84: cbnz    w8, #0x2d4fa90                             
02d4fa88: bl      #0x2b70f30                                 fn_2b70f30
02d4fa8c: ldr     x0, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4fa90: ldr     x8, [x0, #0xb8]                            S:'scoop_no_thank'
02d4fa94: adrp    x23, #0x626b000                            
02d4fa98: ldr     x20, [x8, #0x40]                           
02d4fa9c: ldr     x23, [x23, #0x6d8]                         MS:System.Linq.Enumerable::Where
02d4faa0: cbnz    x20, #0x2d4fafc                            
02d4faa4: ldr     w9, [x0, #0xe4]                            [626b0e4]=0 f=0,0
02d4faa8: cbnz    w9, #0x2d4fab8                             
02d4faac: bl      #0x2b70f30                                 fn_2b70f30
02d4fab0: ldr     x8, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4fab4: ldr     x8, [x8, #0xb8]                            
02d4fab8: adrp    x9, #0x626b000                             
02d4fabc: ldr     x9, [x9, #0x6e8]                           T:type55619(k15)
02d4fac0: ldr     x21, [x8]                                  
02d4fac4: ldr     x0, [x9]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4fac8: bl      #0x2b7104c                                 fn_2b7104c
02d4facc: adrp    x8, #0x626b000                             
02d4fad0: mov     x1, x21                                    
02d4fad4: mov     x3, xzr                                    
02d4fad8: ldr     x8, [x8, #0x788]                           M:Blindbag.Basket/<>c::<GetReviewPrice>b__13_0
02d4fadc: mov     x20, x0                                    
02d4fae0: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4fae4: bl      #0x4940cf8                                 fn_4940cf8
02d4fae8: ldr     x8, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4faec: mov     x1, x20                                    
02d4faf0: ldr     x0, [x8, #0xb8]                            S:'scoop_no_thank'
02d4faf4: str     x20, [x0, #0x40]!                          
02d4faf8: bl      #0x2b70d54                                 fn_2b70d54
02d4fafc: ldr     x2, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4fb00: mov     x0, x19                                    
02d4fb04: mov     x1, x20                                    
02d4fb08: bl      #0x319fec4                                 fn_319fec4
02d4fb0c: ldr     x8, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4fb10: mov     x19, x0                                    
02d4fb14: ldr     w9, [x8, #0xe4]                            [626b0e4]=0 f=0,0
02d4fb18: cbnz    w9, #0x2d4fb28                             
02d4fb1c: mov     x0, x8                                     
02d4fb20: bl      #0x2b70f30                                 fn_2b70f30
02d4fb24: ldr     x8, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4fb28: ldr     x9, [x8, #0xb8]                            S:'scoop_no_thank'
02d4fb2c: adrp    x23, #0x626b000                            
02d4fb30: ldr     x20, [x9, #0x48]                           T:type56654(k15)
02d4fb34: ldr     x23, [x23, #0x768]                         MS:System.Linq.Enumerable::Sum
02d4fb38: cbnz    x20, #0x2d4fb98                            
02d4fb3c: ldr     w10, [x8, #0xe4]                           [626b0e4]=0 f=0,0
02d4fb40: cbnz    w10, #0x2d4fb54                            
02d4fb44: mov     x0, x8                                     
02d4fb48: bl      #0x2b70f30                                 fn_2b70f30
02d4fb4c: ldr     x8, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4fb50: ldr     x9, [x8, #0xb8]                            S:'scoop_no_thank'
02d4fb54: adrp    x8, #0x626b000                             
02d4fb58: ldr     x8, [x8, #0x770]                           T:type55620(k15)
02d4fb5c: ldr     x21, [x9]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4fb60: ldr     x0, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4fb64: bl      #0x2b7104c                                 fn_2b7104c
02d4fb68: adrp    x8, #0x626b000                             
02d4fb6c: mov     x1, x21                                    
02d4fb70: mov     x3, xzr                                    
02d4fb74: ldr     x8, [x8, #0x790]                           M:Blindbag.Basket/<>c::<GetReviewPrice>b__13_1
02d4fb78: mov     x20, x0                                    
02d4fb7c: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4fb80: bl      #0x4941168                                 fn_4941168
02d4fb84: ldr     x8, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4fb88: mov     x1, x20                                    
02d4fb8c: ldr     x0, [x8, #0xb8]                            S:'scoop_no_thank'
02d4fb90: str     x20, [x0, #0x48]!                          
02d4fb94: bl      #0x2b70d54                                 fn_2b70d54
02d4fb98: mov     x0, x19                                    
02d4fb9c: mov     x1, x20                                    
02d4fba0: ldr     x2, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4fba4: ldp     x20, x19, [sp, #0x20]                      
02d4fba8: ldp     x22, x21, [sp, #0x10]                      
02d4fbac: ldp     x30, x23, [sp], #0x30                      
02d4fbb0: b       #0x319babc                                 
## .ctor() -> void
---- Blindbag.Basket::.ctor 0x2d4fbb4
02d4fbb4: mov     x1, xzr                                    
02d4fbb8: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
