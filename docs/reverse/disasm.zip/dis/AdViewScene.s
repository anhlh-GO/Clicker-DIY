#### CLASS AdViewScene parent= BaseScene
#   field adView                         AudienceNetwork.AdView                             off=0x20 attr=1 
#   field currentAdViewPosition          AudienceNetwork.AdPosition                         off=0x28 attr=1 
#   field currentScreenOrientation       UnityEngine.ScreenOrientation                      off=0x2c attr=1 
#   field statusLabel                    UnityEngine.UI.Text                                off=0x30 attr=6 
#   field adSizeArray                    AudienceNetwork.AdSize[]                           off=0x38 attr=1 
#   field currentAdSize                  int                                                off=0x40 attr=1 
#   field loadAdButton                   UnityEngine.UI.Button                              off=0x48 attr=6 
## OnDestroy() -> void
---- AdViewScene::OnDestroy 0x2c8413c
02c8413c: str     x30, [sp, #-0x20]!                         
02c84140: stp     x20, x19, [sp, #0x10]                      
02c84144: adrp    x20, #0x662f000                            
02c84148: mov     x19, x0                                    
02c8414c: ldrb    w8, [x20, #0x91e]                          
02c84150: tbnz    w8, #0, #0x2c84174                         
02c84154: adrp    x0, #0x6263000                             
02c84158: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c8415c: bl      #0x2b70db0                                 fn_2b70db0
02c84160: adrp    x0, #0x6264000                             
02c84164: ldr     x0, [x0, #0xae0]                           S:'AdViewTest was destroyed!'
02c84168: bl      #0x2b70db0                                 fn_2b70db0
02c8416c: mov     w8, #1                                     
02c84170: strb    w8, [x20, #0x91e]                          
02c84174: ldr     x0, [x19, #0x20]                           .adView
02c84178: mov     x1, xzr                                    
02c8417c: bl      #0x2cca4b0                                 AudienceNetwork.AdView::op_Implicit
02c84180: tbz     w0, #0, #0x2c84194                         
02c84184: ldr     x0, [x19, #0x20]                           .adView
02c84188: cbz     x0, #0x2c841c8                             
02c8418c: mov     x1, xzr                                    
02c84190: bl      #0x2cc9a2c                                 AudienceNetwork.AdView::Dispose
02c84194: adrp    x8, #0x6263000                             
02c84198: adrp    x19, #0x6264000                            
02c8419c: ldr     x8, [x8, #0x928]                           T:UnityEngine.Debug
02c841a0: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c841a4: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c841a8: ldr     x19, [x19, #0xae0]                         S:'AdViewTest was destroyed!'
02c841ac: cbnz    w8, #0x2c841b4                             
02c841b0: bl      #0x2b70f30                                 fn_2b70f30
02c841b4: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c841b8: ldp     x20, x19, [sp, #0x10]                      
02c841bc: mov     x1, xzr                                    
02c841c0: ldr     x30, [sp], #0x20                           
02c841c4: b       #0x5af21f4                                 UnityEngine.Debug::Log
02c841c8: bl      #0x2b7105c                                 fn_2b7105c
## Awake() -> void
---- AdViewScene::Awake 0x2c841cc
02c841cc: stp     x30, x21, [sp, #-0x20]!                    
02c841d0: stp     x20, x19, [sp, #0x10]                      
02c841d4: adrp    x21, #0x662f000                            
02c841d8: adrp    x20, #0x6264000                            
02c841dc: mov     x19, x0                                    
02c841e0: ldrb    w8, [x21, #0x91f]                          
02c841e4: ldr     x20, [x20, #0xae8]                         T:SettingsScene
02c841e8: tbnz    w8, #0, #0x2c84200                         
02c841ec: adrp    x0, #0x6264000                             
02c841f0: ldr     x0, [x0, #0xae8]                           T:SettingsScene
02c841f4: bl      #0x2b70db0                                 fn_2b70db0
02c841f8: mov     w8, #1                                     
02c841fc: strb    w8, [x21, #0x91f]                          
02c84200: mov     x0, xzr                                    
02c84204: bl      #0x2ccc9d4                                 AudienceNetwork.AudienceNetworkAds::Initialize
02c84208: mov     x0, x19                                    
02c8420c: bl      #0x2c8422c                                 AdViewScene::SetLoadAddButtonText
02c84210: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c84214: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c84218: cbnz    w8, #0x2c84220                             
02c8421c: bl      #0x2b70f30                                 fn_2b70f30
02c84220: ldp     x20, x19, [sp, #0x10]                      
02c84224: ldp     x30, x21, [sp], #0x20                      
02c84228: b       #0x2c84340                                 SettingsScene::InitializeSettings
## SetLoadAddButtonText() -> void
---- AdViewScene::SetLoadAddButtonText 0x2c8422c
02c8422c: sub     sp, sp, #0x40                              
02c84230: stp     x30, x21, [sp, #0x20]                      
02c84234: stp     x20, x19, [sp, #0x30]                      
02c84238: adrp    x19, #0x662f000                            
02c8423c: mov     x20, x0                                    
02c84240: ldrb    w8, [x19, #0x920]                          
02c84244: tbnz    w8, #0, #0x2c84280                         
02c84248: adrp    x0, #0x6264000                             
02c8424c: ldr     x0, [x0, #0xaf0]                           T:AudienceNetwork.AdSize
02c84250: bl      #0x2b70db0                                 fn_2b70db0
02c84254: adrp    x0, #0x6264000                             
02c84258: ldr     x0, [x0, #0xaf8]                           MS:UnityEngine.Component::GetComponentInChildren
02c8425c: bl      #0x2b70db0                                 fn_2b70db0
02c84260: adrp    x0, #0x6264000                             
02c84264: ldr     x0, [x0, #0xb00]                           S:'Load Banner ('
02c84268: bl      #0x2b70db0                                 fn_2b70db0
02c8426c: adrp    x0, #0x6264000                             
02c84270: ldr     x0, [x0, #0xb08]                           S:')'
02c84274: bl      #0x2b70db0                                 fn_2b70db0
02c84278: mov     w8, #1                                     
02c8427c: strb    w8, [x19, #0x920]                          
02c84280: ldr     x0, [x20, #0x48]                           .loadAdButton
02c84284: cbz     x0, #0x2c84338                             
02c84288: adrp    x8, #0x6264000                             
02c8428c: ldr     x8, [x8, #0xaf8]                           MS:UnityEngine.Component::GetComponentInChildren
02c84290: ldr     x1, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c84294: bl      #0x3140e60                                 fn_3140e60
02c84298: ldr     x8, [x20, #0x38]                           .adSizeArray
02c8429c: cbz     x8, #0x2c84338                             
02c842a0: ldrsw   x9, [x20, #0x40]                           .currentAdSize
02c842a4: ldr     w10, [x8, #0x18]                           M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0::<DOSetFloat>b__1
02c842a8: cmp     w9, w10                                    
02c842ac: b.hs    #0x2c8433c                                 
02c842b0: adrp    x10, #0x6264000                            
02c842b4: add     x8, x8, x9, lsl #2                         &6264000
02c842b8: adrp    x20, #0x6264000                            
02c842bc: ldr     x10, [x10, #0xaf0]                         T:AudienceNetwork.AdSize
02c842c0: adrp    x21, #0x6264000                            
02c842c4: mov     x19, x0                                    
02c842c8: mov     x9, #-1                                    
02c842cc: add     x0, sp, #8                                 
02c842d0: mov     x1, xzr                                    
02c842d4: ldr     x10, [x10]                                 M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c842d8: str     x10, [sp, #8]                              
02c842dc: ldr     x20, [x20, #0xb00]                         S:'Load Banner ('
02c842e0: ldr     w8, [x8, #0x20]                            T:DG.Tweening.DOTweenModulePhysics/<>c__DisplayClass0_0
02c842e4: ldr     x21, [x21, #0xb08]                         S:')'
02c842e8: str     x9, [sp, #0x10]                            
02c842ec: str     w8, [sp, #0x18]                            
02c842f0: bl      #0x4e47e48                                 System.Enum::ToString
02c842f4: ldr     x8, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c842f8: ldr     x2, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c842fc: mov     x1, x0                                     
02c84300: mov     x3, xzr                                    
02c84304: mov     x0, x8                                     
02c84308: bl      #0x4ca6dbc                                 System.String::Concat
02c8430c: cbz     x19, #0x2c84338                            
02c84310: ldr     x8, [x19]                                  &2b706c4(=eb01011ff9400808)
02c84314: mov     x1, x0                                     
02c84318: mov     x0, x19                                    
02c8431c: ldr     x9, [x8, #0x5e8]                           T:DG.Tweening.DOTweenModuleUI/<>c__DisplayClass29_0
02c84320: ldr     x2, [x8, #0x5f0]                           MS:DG.Tweening.TweenSettingsExtensions::OnUpdate
02c84324: blr     x9                                         
02c84328: ldp     x20, x19, [sp, #0x30]                      
02c8432c: ldp     x30, x21, [sp, #0x20]                      
02c84330: add     sp, sp, #0x40                              
02c84334: ret                                                
02c84338: bl      #0x2b7105c                                 fn_2b7105c
02c8433c: bl      #0x2b71064                                 fn_2b71064
## LoadBanner() -> void
---- AdViewScene::LoadBanner 0x2c843bc
02c843bc: stp     x30, x25, [sp, #-0x40]!                    
02c843c0: stp     x24, x23, [sp, #0x10]                      
02c843c4: stp     x22, x21, [sp, #0x20]                      
02c843c8: stp     x20, x19, [sp, #0x30]                      
02c843cc: adrp    x20, #0x662f000                            
02c843d0: mov     x19, x0                                    
02c843d4: ldrb    w8, [x20, #0x921]                          
02c843d8: tbnz    w8, #0, #0x2c84450                         
02c843dc: adrp    x0, #0x6264000                             
02c843e0: ldr     x0, [x0, #0xb10]                           M:AdViewScene::<LoadBanner>b__10_0
02c843e4: bl      #0x2b70db0                                 fn_2b70db0
02c843e8: adrp    x0, #0x6264000                             
02c843ec: ldr     x0, [x0, #0xb18]                           M:AdViewScene::<LoadBanner>b__10_1
02c843f0: bl      #0x2b70db0                                 fn_2b70db0
02c843f4: adrp    x0, #0x6264000                             
02c843f8: ldr     x0, [x0, #0xb20]                           M:AdViewScene::<LoadBanner>b__10_2
02c843fc: bl      #0x2b70db0                                 fn_2b70db0
02c84400: adrp    x0, #0x6264000                             
02c84404: ldr     x0, [x0, #0xb28]                           M:AdViewScene::<LoadBanner>b__10_3
02c84408: bl      #0x2b70db0                                 fn_2b70db0
02c8440c: adrp    x0, #0x6264000                             
02c84410: ldr     x0, [x0, #0xb30]                           T:AudienceNetwork.AdView
02c84414: bl      #0x2b70db0                                 fn_2b70db0
02c84418: adrp    x0, #0x6264000                             
02c8441c: ldr     x0, [x0, #0xb38]                           T:AudienceNetwork.FBAdViewBridgeCallback
02c84420: bl      #0x2b70db0                                 fn_2b70db0
02c84424: adrp    x0, #0x6264000                             
02c84428: ldr     x0, [x0, #0xb40]                           T:AudienceNetwork.FBAdViewBridgeErrorCallback
02c8442c: bl      #0x2b70db0                                 fn_2b70db0
02c84430: adrp    x0, #0x6264000                             
02c84434: ldr     x0, [x0, #0xb48]                           S:'Loading Banner...'
02c84438: bl      #0x2b70db0                                 fn_2b70db0
02c8443c: adrp    x0, #0x6264000                             
02c84440: ldr     x0, [x0, #0xb50]                           S:'YOUR_PLACEMENT_ID'
02c84444: bl      #0x2b70db0                                 fn_2b70db0
02c84448: mov     w8, #1                                     
02c8444c: strb    w8, [x20, #0x921]                          
02c84450: mov     x20, x19                                   
02c84454: mov     x1, xzr                                    
02c84458: ldr     x0, [x20, #0x20]!                          &2b706f0(=d65f03c0f9400800) .adView
02c8445c: bl      #0x2cca4b0                                 AudienceNetwork.AdView::op_Implicit
02c84460: tbz     w0, #0, #0x2c84474                         
02c84464: ldr     x0, [x20]                                  &2b706c4(=eb01011ff9400808)
02c84468: cbz     x0, #0x2c8463c                             
02c8446c: mov     x1, xzr                                    
02c84470: bl      #0x2cc9a2c                                 AudienceNetwork.AdView::Dispose
02c84474: ldr     x0, [x19, #0x30]                           .statusLabel
02c84478: cbz     x0, #0x2c8463c                             
02c8447c: adrp    x8, #0x6264000                             
02c84480: ldr     x8, [x8, #0xb48]                           S:'Loading Banner...'
02c84484: ldr     x9, [x0]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c84488: ldr     x1, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c8448c: ldr     x8, [x9, #0x5e8]                           
02c84490: ldr     x2, [x9, #0x5f0]                           
02c84494: blr     x8                                         
02c84498: ldr     x8, [x19, #0x38]                           .adSizeArray
02c8449c: cbz     x8, #0x2c8463c                             
02c844a0: ldrsw   x9, [x19, #0x40]                           .currentAdSize
02c844a4: ldr     w10, [x8, #0x18]                           M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0::<DOSetFloat>b__1
02c844a8: cmp     w9, w10                                    
02c844ac: b.hs    #0x2c84640                                 
02c844b0: adrp    x10, #0x6264000                            
02c844b4: add     x8, x8, x9, lsl #2                         &6264000
02c844b8: adrp    x22, #0x6264000                            
02c844bc: ldr     x10, [x10, #0xb30]                         T:AudienceNetwork.AdView
02c844c0: ldr     x22, [x22, #0xb50]                         S:'YOUR_PLACEMENT_ID'
02c844c4: ldr     w21, [x8, #0x20]                           T:DG.Tweening.DOTweenModulePhysics/<>c__DisplayClass0_0
02c844c8: ldr     x0, [x10]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c844cc: bl      #0x2b7104c                                 fn_2b7104c
02c844d0: ldr     x1, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c844d4: mov     w2, w21                                    
02c844d8: mov     x3, xzr                                    
02c844dc: mov     x22, x0                                    
02c844e0: bl      #0x2cc94b8                                 AudienceNetwork.AdView::.ctor
02c844e4: mov     x0, x20                                    
02c844e8: mov     x1, x22                                    
02c844ec: str     x22, [x19, #0x20]                          .adView
02c844f0: bl      #0x2b70d54                                 fn_2b70d54
02c844f4: ldr     x21, [x19, #0x20]                          .adView
02c844f8: mov     x0, x19                                    
02c844fc: mov     x1, xzr                                    
02c84500: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02c84504: cbz     x21, #0x2c8463c                            
02c84508: adrp    x23, #0x6264000                            
02c8450c: adrp    x22, #0x6264000                            
02c84510: mov     x1, x0                                     
02c84514: ldr     x23, [x23, #0xb38]                         T:AudienceNetwork.FBAdViewBridgeCallback
02c84518: ldr     x22, [x22, #0xb10]                         M:AdViewScene::<LoadBanner>b__10_0
02c8451c: mov     x0, x21                                    
02c84520: mov     x2, xzr                                    
02c84524: bl      #0x2cc9c64                                 AudienceNetwork.AdView::Register
02c84528: ldr     x0, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c8452c: ldr     x21, [x19, #0x20]                          .adView
02c84530: str     wzr, [x19, #0x28]                          .currentAdViewPosition
02c84534: bl      #0x2b7104c                                 fn_2b7104c
02c84538: ldr     x2, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c8453c: mov     x1, x19                                    
02c84540: mov     x3, xzr                                    
02c84544: mov     x22, x0                                    
02c84548: bl      #0x2cc8b80                                 AudienceNetwork.FBAdViewBridgeCallback::.ctor
02c8454c: cbz     x21, #0x2c8463c                            
02c84550: adrp    x24, #0x6264000                            
02c84554: adrp    x25, #0x6264000                            
02c84558: mov     x0, x21                                    
02c8455c: ldr     x24, [x24, #0xb40]                         T:AudienceNetwork.FBAdViewBridgeErrorCallback
02c84560: ldr     x25, [x25, #0xb18]                         M:AdViewScene::<LoadBanner>b__10_1
02c84564: mov     x1, x22                                    
02c84568: mov     x2, xzr                                    
02c8456c: bl      #0x2cc8fac                                 AudienceNetwork.AdView::set_AdViewDidLoad
02c84570: ldr     x0, [x24]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c84574: ldr     x21, [x19, #0x20]                          .adView
02c84578: bl      #0x2b7104c                                 fn_2b7104c
02c8457c: ldr     x2, [x25]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c84580: mov     x1, x19                                    
02c84584: mov     x3, xzr                                    
02c84588: mov     x22, x0                                    
02c8458c: bl      #0x2cc8c58                                 AudienceNetwork.FBAdViewBridgeErrorCallback::.ctor
02c84590: cbz     x21, #0x2c8463c                            
02c84594: adrp    x24, #0x6264000                            
02c84598: mov     x0, x21                                    
02c8459c: mov     x1, x22                                    
02c845a0: ldr     x24, [x24, #0xb20]                         M:AdViewScene::<LoadBanner>b__10_2
02c845a4: mov     x2, xzr                                    
02c845a8: bl      #0x2cc91b4                                 AudienceNetwork.AdView::set_AdViewDidFailWithError
02c845ac: ldr     x0, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c845b0: ldr     x21, [x19, #0x20]                          .adView
02c845b4: bl      #0x2b7104c                                 fn_2b7104c
02c845b8: ldr     x2, [x24]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c845bc: mov     x1, x19                                    
02c845c0: mov     x3, xzr                                    
02c845c4: mov     x22, x0                                    
02c845c8: bl      #0x2cc8b80                                 AudienceNetwork.FBAdViewBridgeCallback::.ctor
02c845cc: cbz     x21, #0x2c8463c                            
02c845d0: adrp    x24, #0x6264000                            
02c845d4: mov     x0, x21                                    
02c845d8: mov     x1, x22                                    
02c845dc: ldr     x24, [x24, #0xb28]                         M:AdViewScene::<LoadBanner>b__10_3
02c845e0: mov     x2, xzr                                    
02c845e4: bl      #0x2cc90b0                                 AudienceNetwork.AdView::set_AdViewWillLogImpression
02c845e8: ldr     x0, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c845ec: ldr     x21, [x19, #0x20]                          .adView
02c845f0: bl      #0x2b7104c                                 fn_2b7104c
02c845f4: ldr     x2, [x24]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c845f8: mov     x1, x19                                    
02c845fc: mov     x3, xzr                                    
02c84600: mov     x22, x0                                    
02c84604: bl      #0x2cc8b80                                 AudienceNetwork.FBAdViewBridgeCallback::.ctor
02c84608: cbz     x21, #0x2c8463c                            
02c8460c: mov     x0, x21                                    
02c84610: mov     x1, x22                                    
02c84614: mov     x2, xzr                                    
02c84618: bl      #0x2cc92b8                                 AudienceNetwork.AdView::set_AdViewDidClick
02c8461c: ldr     x0, [x20]                                  &2b706c4(=eb01011ff9400808)
02c84620: cbz     x0, #0x2c8463c                             
02c84624: ldp     x20, x19, [sp, #0x30]                      
02c84628: mov     x1, xzr                                    
02c8462c: ldp     x22, x21, [sp, #0x20]                      
02c84630: ldp     x24, x23, [sp, #0x10]                      
02c84634: ldp     x30, x25, [sp], #0x40                      
02c84638: b       #0x2cc9cc8                                 AudienceNetwork.AdView::LoadAd
02c8463c: bl      #0x2b7105c                                 fn_2b7105c
02c84640: bl      #0x2b71064                                 fn_2b71064
## ChangeBannerSize() -> void
---- AdViewScene::ChangeBannerSize 0x2c84644
02c84644: ldr     w8, [x0, #0x40]                            .currentAdSize
02c84648: ldr     x9, [x0, #0x38]                            .adSizeArray
02c8464c: add     w8, w8, #1                                 
02c84650: str     w8, [x0, #0x40]                            .currentAdSize
02c84654: cbz     x9, #0x2c8466c                             
02c84658: ldr     w9, [x9, #0x18]                            
02c8465c: sdiv    w10, w8, w9                                
02c84660: msub    w8, w10, w9, w8                            
02c84664: str     w8, [x0, #0x40]                            .currentAdSize
02c84668: b       #0x2c8422c                                 AdViewScene::SetLoadAddButtonText
02c8466c: str     x30, [sp, #-0x10]!                         
02c84670: bl      #0x2b7105c                                 fn_2b7105c
## NextScene() -> void
---- AdViewScene::NextScene 0x2c84674
02c84674: str     x30, [sp, #-0x20]!                         
02c84678: stp     x20, x19, [sp, #0x10]                      
02c8467c: adrp    x20, #0x662f000                            
02c84680: adrp    x19, #0x6264000                            
02c84684: ldrb    w8, [x20, #0x922]                          
02c84688: ldr     x19, [x19, #0xb58]                         T:UnityEngine.SceneManagement.SceneManager
02c8468c: tbnz    w8, #0, #0x2c846b0                         
02c84690: adrp    x0, #0x6264000                             
02c84694: ldr     x0, [x0, #0xb58]                           T:UnityEngine.SceneManagement.SceneManager
02c84698: bl      #0x2b70db0                                 fn_2b70db0
02c8469c: adrp    x0, #0x6264000                             
02c846a0: ldr     x0, [x0, #0xb60]                           S:'RewardedVideoAdScene'
02c846a4: bl      #0x2b70db0                                 fn_2b70db0
02c846a8: mov     w8, #1                                     
02c846ac: strb    w8, [x20, #0x922]                          
02c846b0: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c846b4: adrp    x19, #0x6264000                            
02c846b8: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c846bc: ldr     x19, [x19, #0xb60]                         S:'RewardedVideoAdScene'
02c846c0: cbnz    w8, #0x2c846c8                             
02c846c4: bl      #0x2b70f30                                 fn_2b70f30
02c846c8: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c846cc: ldp     x20, x19, [sp, #0x10]                      
02c846d0: mov     x1, xzr                                    
02c846d4: ldr     x30, [sp], #0x20                           
02c846d8: b       #0x5b4f55c                                 UnityEngine.SceneManagement.SceneManager::LoadScene
## ChangePosition() -> void
---- AdViewScene::ChangePosition 0x2c846dc
02c846dc: ldr     w8, [x0, #0x28]                            .currentAdViewPosition
02c846e0: cmp     w8, #2                                     
02c846e4: b.hi    #0x2c846f8                                 
02c846e8: adrp    x9, #0x1088000                             
02c846ec: add     x9, x9, #0xe40                             &1088e40
02c846f0: ldr     w1, [x9, x8, lsl #2]                       [1088000]=cd0445a5d19764c7 f=-8.12789e+10,-1.38697e+08
02c846f4: b       #0x2c846fc                                 AdViewScene::SetAdViewPosition
02c846f8: ret                                                
## OnRectTransformDimensionsChange() -> void
---- AdViewScene::OnRectTransformDimensionsChange 0x2c84774
02c84774: stp     x30, x19, [sp, #-0x10]!                    
02c84778: mov     x19, x0                                    
02c8477c: ldr     x0, [x0, #0x20]                            .adView
02c84780: mov     x1, xzr                                    
02c84784: bl      #0x2cca4b0                                 AudienceNetwork.AdView::op_Implicit
02c84788: tbz     w0, #0, #0x2c847b8                         
02c8478c: mov     x0, xzr                                    
02c84790: bl      #0x5afb7d8                                 UnityEngine.Screen::get_orientation
02c84794: ldr     w8, [x19, #0x2c]                           .currentScreenOrientation
02c84798: cmp     w0, w8                                     
02c8479c: b.eq    #0x2c847b8                                 
02c847a0: ldr     w1, [x19, #0x28]                           .currentAdViewPosition
02c847a4: mov     x0, x19                                    
02c847a8: bl      #0x2c846fc                                 AdViewScene::SetAdViewPosition
02c847ac: mov     x0, xzr                                    
02c847b0: bl      #0x5afb7d8                                 UnityEngine.Screen::get_orientation
02c847b4: str     w0, [x19, #0x2c]                           .currentScreenOrientation
02c847b8: ldp     x30, x19, [sp], #0x10                      
02c847bc: ret                                                
## SetAdViewPosition(AudienceNetwork.AdPosition adPosition) -> void
---- AdViewScene::SetAdViewPosition 0x2c846fc
02c846fc: str     x30, [sp, #-0x20]!                         
02c84700: stp     x20, x19, [sp, #0x10]                      
02c84704: mov     w19, w1                                    
02c84708: mov     x20, x0                                    
02c8470c: cbz     w1, #0x2c84748                             
02c84710: cmp     w19, #2                                    
02c84714: b.eq    #0x2c84730                                 
02c84718: cmp     w19, #1                                    
02c8471c: b.ne    #0x2c84764                                 
02c84720: ldr     x0, [x20, #0x20]                           .adView
02c84724: cbz     x0, #0x2c84770                             
02c84728: mov     w1, #1                                     
02c8472c: b       #0x2c8473c                                 
02c84730: ldr     x0, [x20, #0x20]                           .adView
02c84734: cbz     x0, #0x2c84770                             
02c84738: mov     w1, #2                                     
02c8473c: mov     x2, xzr                                    
02c84740: bl      #0x2cca10c                                 AudienceNetwork.AdView::Show
02c84744: b       #0x2c84760                                 
02c84748: ldr     x0, [x20, #0x20]                           .adView
02c8474c: cbz     x0, #0x2c84770                             
02c84750: mov     x8, #0x4059000000000000                    
02c84754: mov     x1, xzr                                    
02c84758: fmov    d0, x8                                     
02c8475c: bl      #0x2cca1d0                                 AudienceNetwork.AdView::Show
02c84760: str     w19, [x20, #0x28]                          .currentAdViewPosition
02c84764: ldp     x20, x19, [sp, #0x10]                      
02c84768: ldr     x30, [sp], #0x20                           
02c8476c: ret                                                
02c84770: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- AdViewScene::.ctor 0x2c847c0
02c847c0: str     x30, [sp, #-0x30]!                         
02c847c4: stp     x22, x21, [sp, #0x10]                      
02c847c8: stp     x20, x19, [sp, #0x20]                      
02c847cc: adrp    x21, #0x662f000                            
02c847d0: adrp    x20, #0x6264000                            
02c847d4: mov     x19, x0                                    
02c847d8: ldrb    w8, [x21, #0x923]                          
02c847dc: ldr     x20, [x20, #0xb68]                         T:AudienceNetwork.AdSize
02c847e0: tbnz    w8, #0, #0x2c84804                         
02c847e4: adrp    x0, #0x6264000                             
02c847e8: ldr     x0, [x0, #0xb70]                           T:type60860(k1d)
02c847ec: bl      #0x2b70db0                                 fn_2b70db0
02c847f0: adrp    x0, #0x6264000                             
02c847f4: ldr     x0, [x0, #0xb68]                           T:AudienceNetwork.AdSize
02c847f8: bl      #0x2b70db0                                 fn_2b70db0
02c847fc: mov     w8, #1                                     
02c84800: strb    w8, [x21, #0x923]                          
02c84804: adrp    x21, #0x6263000                            
02c84808: ldr     x21, [x21, #0x970]                         &6645c70(=0)
02c8480c: ldr     x20, [x20]                                 M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c84810: ldr     x0, [x21, #0xe0]                           &2c5bf4c(=a9be7bfdd503233f)
02c84814: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c84818: cbnz    w8, #0x2c84820                             
02c8481c: bl      #0x2b70f30                                 fn_2b70f30
02c84820: mov     x0, x20                                    
02c84824: mov     x1, xzr                                    
02c84828: bl      #0x4e20e5c                                 System.Type::GetTypeFromHandle
02c8482c: ldr     x8, [x21, #0x98]                           [6263098]=0 f=0,0
02c84830: mov     x20, x0                                    
02c84834: ldr     w9, [x8, #0xe4]                            
02c84838: cbnz    w9, #0x2c84844                             
02c8483c: mov     x0, x8                                     
02c84840: bl      #0x2b70f30                                 fn_2b70f30
02c84844: mov     x0, x20                                    
02c84848: mov     x1, xzr                                    
02c8484c: bl      #0x4e4676c                                 System.Enum::GetValues
02c84850: cbz     x0, #0x2c84894                             
02c84854: adrp    x22, #0x6264000                            
02c84858: mov     x20, x0                                    
02c8485c: ldr     x22, [x22, #0xb70]                         T:type60860(k1d)
02c84860: ldr     x21, [x22]                                 M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c84864: mov     x1, x21                                    
02c84868: bl      #0x2b70f34                                 fn_2b70f34
02c8486c: cbz     x0, #0x2c848c0                             
02c84870: ldr     x22, [x22]                                 M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c84874: mov     x21, x19                                   
02c84878: str     x0, [x21, #0x38]!                          .adSizeArray
02c8487c: mov     x0, x20                                    
02c84880: mov     x1, x22                                    
02c84884: bl      #0x2b70f34                                 fn_2b70f34
02c84888: cbz     x0, #0x2c848cc                             
02c8488c: mov     x1, x0                                     
02c84890: b       #0x2c848a0                                 
02c84894: mov     x21, x19                                   
02c84898: mov     x1, xzr                                    
02c8489c: str     xzr, [x21, #0x38]!                         .adSizeArray
02c848a0: mov     x0, x21                                    
02c848a4: bl      #0x2b70d54                                 fn_2b70d54
02c848a8: mov     x0, x19                                    
02c848ac: ldp     x20, x19, [sp, #0x20]                      
02c848b0: ldp     x22, x21, [sp, #0x10]                      
02c848b4: mov     x1, xzr                                    
02c848b8: ldr     x30, [sp], #0x30                           
02c848bc: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
02c848c0: mov     x0, x20                                    
02c848c4: mov     x1, x21                                    
02c848c8: bl      #0x2b713dc                                 fn_2b713dc
02c848cc: mov     x0, x20                                    
02c848d0: mov     x1, x22                                    
02c848d4: bl      #0x2b713dc                                 fn_2b713dc
## <LoadBanner>b__10_0() -> void
---- AdViewScene::<LoadBanner>b__10_0 0x2c848e0
02c848e0: stp     x30, x23, [sp, #-0x30]!                    
02c848e4: stp     x22, x21, [sp, #0x10]                      
02c848e8: stp     x20, x19, [sp, #0x20]                      
02c848ec: adrp    x20, #0x662f000                            
02c848f0: mov     x19, x0                                    
02c848f4: ldrb    w8, [x20, #0x924]                          
02c848f8: tbnz    w8, #0, #0x2c8494c                         
02c848fc: adrp    x0, #0x6263000                             
02c84900: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c84904: bl      #0x2b70db0                                 fn_2b70db0
02c84908: adrp    x0, #0x6264000                             
02c8490c: ldr     x0, [x0, #0xb78]                           S:'Banner loaded'
02c84910: bl      #0x2b70db0                                 fn_2b70db0
02c84914: adrp    x0, #0x6264000                             
02c84918: ldr     x0, [x0, #0xb80]                           S:'Banner loaded and is '
02c8491c: bl      #0x2b70db0                                 fn_2b70db0
02c84920: adrp    x0, #0x6264000                             
02c84924: ldr     x0, [x0, #0xb88]                           S:'invalid'
02c84928: bl      #0x2b70db0                                 fn_2b70db0
02c8492c: adrp    x0, #0x6264000                             
02c84930: ldr     x0, [x0, #0xb90]                           S:'valid'
02c84934: bl      #0x2b70db0                                 fn_2b70db0
02c84938: adrp    x0, #0x6264000                             
02c8493c: ldr     x0, [x0, #0xa38]                           S:'.'
02c84940: bl      #0x2b70db0                                 fn_2b70db0
02c84944: mov     w8, #1                                     
02c84948: strb    w8, [x20, #0x924]                          
02c8494c: mov     x0, xzr                                    
02c84950: bl      #0x5afb7d8                                 UnityEngine.Screen::get_orientation
02c84954: ldr     x8, [x19, #0x20]                           .adView
02c84958: str     w0, [x19, #0x2c]                           .currentScreenOrientation
02c8495c: cbz     x8, #0x2c84a18                             
02c84960: mov     x9, #0x4059000000000000                    
02c84964: mov     x0, x8                                     
02c84968: mov     x1, xzr                                    
02c8496c: fmov    d0, x9                                     
02c84970: bl      #0x2cca1d0                                 AudienceNetwork.AdView::Show
02c84974: ldr     x0, [x19, #0x20]                           .adView
02c84978: cbz     x0, #0x2c84a18                             
02c8497c: adrp    x20, #0x6264000                            
02c84980: adrp    x21, #0x6264000                            
02c84984: adrp    x22, #0x6264000                            
02c84988: adrp    x23, #0x6264000                            
02c8498c: ldr     x20, [x20, #0xb90]                         S:'valid'
02c84990: ldr     x21, [x21, #0xb88]                         S:'invalid'
02c84994: ldr     x22, [x22, #0xb80]                         S:'Banner loaded and is '
02c84998: ldr     x23, [x23, #0xa38]                         S:'.'
02c8499c: mov     x1, xzr                                    
02c849a0: bl      #0x2cc9f2c                                 AudienceNetwork.AdView::IsValid
02c849a4: tst     w0, #1                                     
02c849a8: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c849ac: ldr     x2, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c849b0: csel    x8, x20, x21, ne                           
02c849b4: ldr     x19, [x19, #0x30]                          .statusLabel
02c849b8: mov     x3, xzr                                    
02c849bc: ldr     x1, [x8]                                   
02c849c0: bl      #0x4ca6dbc                                 System.String::Concat
02c849c4: cbz     x19, #0x2c84a18                            
02c849c8: adrp    x21, #0x6263000                            
02c849cc: adrp    x20, #0x6264000                            
02c849d0: mov     x1, x0                                     
02c849d4: ldr     x21, [x21, #0x928]                         T:UnityEngine.Debug
02c849d8: ldr     x8, [x19]                                  
02c849dc: ldr     x20, [x20, #0xb78]                         S:'Banner loaded'
02c849e0: mov     x0, x19                                    
02c849e4: ldr     x9, [x8, #0x5e8]                           
02c849e8: ldr     x2, [x8, #0x5f0]                           
02c849ec: blr     x9                                         
02c849f0: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c849f4: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c849f8: cbnz    w8, #0x2c84a00                             
02c849fc: bl      #0x2b70f30                                 fn_2b70f30
02c84a00: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c84a04: ldp     x20, x19, [sp, #0x20]                      
02c84a08: ldp     x22, x21, [sp, #0x10]                      
02c84a0c: mov     x1, xzr                                    
02c84a10: ldp     x30, x23, [sp], #0x30                      
02c84a14: b       #0x5af21f4                                 UnityEngine.Debug::Log
02c84a18: bl      #0x2b7105c                                 fn_2b7105c
## <LoadBanner>b__10_1(string error) -> void
---- AdViewScene::<LoadBanner>b__10_1 0x2c84a1c
02c84a1c: str     x30, [sp, #-0x30]!                         
02c84a20: stp     x22, x21, [sp, #0x10]                      
02c84a24: stp     x20, x19, [sp, #0x20]                      
02c84a28: adrp    x22, #0x662f000                            
02c84a2c: adrp    x21, #0x6264000                            
02c84a30: mov     x19, x1                                    
02c84a34: ldrb    w8, [x22, #0x925]                          
02c84a38: ldr     x21, [x21, #0xb98]                         S:'Banner failed to load with error: '
02c84a3c: mov     x20, x0                                    
02c84a40: tbnz    w8, #0, #0x2c84a64                         
02c84a44: adrp    x0, #0x6263000                             
02c84a48: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c84a4c: bl      #0x2b70db0                                 fn_2b70db0
02c84a50: adrp    x0, #0x6264000                             
02c84a54: ldr     x0, [x0, #0xb98]                           S:'Banner failed to load with error: '
02c84a58: bl      #0x2b70db0                                 fn_2b70db0
02c84a5c: mov     w8, #1                                     
02c84a60: strb    w8, [x22, #0x925]                          
02c84a64: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c84a68: ldr     x20, [x20, #0x30]                          .statusLabel
02c84a6c: mov     x1, x19                                    
02c84a70: mov     x2, xzr                                    
02c84a74: bl      #0x4c9c514                                 System.String::Concat
02c84a78: cbz     x20, #0x2c84adc                            
02c84a7c: ldr     x8, [x20]                                  
02c84a80: adrp    x22, #0x6263000                            
02c84a84: mov     x1, x0                                     
02c84a88: ldr     x22, [x22, #0x928]                         T:UnityEngine.Debug
02c84a8c: mov     x0, x20                                    
02c84a90: ldr     x9, [x8, #0x5e8]                           
02c84a94: ldr     x2, [x8, #0x5f0]                           
02c84a98: blr     x9                                         
02c84a9c: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c84aa0: mov     x1, x19                                    
02c84aa4: mov     x2, xzr                                    
02c84aa8: bl      #0x4c9c514                                 System.String::Concat
02c84aac: ldr     x8, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c84ab0: mov     x19, x0                                    
02c84ab4: ldr     w9, [x8, #0xe4]                            
02c84ab8: cbnz    w9, #0x2c84ac4                             
02c84abc: mov     x0, x8                                     
02c84ac0: bl      #0x2b70f30                                 fn_2b70f30
02c84ac4: mov     x0, x19                                    
02c84ac8: ldp     x20, x19, [sp, #0x20]                      
02c84acc: ldp     x22, x21, [sp, #0x10]                      
02c84ad0: mov     x1, xzr                                    
02c84ad4: ldr     x30, [sp], #0x30                           
02c84ad8: b       #0x5af21f4                                 UnityEngine.Debug::Log
02c84adc: bl      #0x2b7105c                                 fn_2b7105c
## <LoadBanner>b__10_2() -> void
---- AdViewScene::<LoadBanner>b__10_2 0x2c84ae0
02c84ae0: str     x30, [sp, #-0x20]!                         
02c84ae4: stp     x20, x19, [sp, #0x10]                      
02c84ae8: adrp    x20, #0x662f000                            
02c84aec: mov     x19, x0                                    
02c84af0: ldrb    w8, [x20, #0x926]                          
02c84af4: tbnz    w8, #0, #0x2c84b18                         
02c84af8: adrp    x0, #0x6263000                             
02c84afc: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c84b00: bl      #0x2b70db0                                 fn_2b70db0
02c84b04: adrp    x0, #0x6264000                             
02c84b08: ldr     x0, [x0, #0xba0]                           S:'Banner logged impression.'
02c84b0c: bl      #0x2b70db0                                 fn_2b70db0
02c84b10: mov     w8, #1                                     
02c84b14: strb    w8, [x20, #0x926]                          
02c84b18: ldr     x0, [x19, #0x30]                           .statusLabel
02c84b1c: cbz     x0, #0x2c84b68                             
02c84b20: adrp    x19, #0x6264000                            
02c84b24: adrp    x20, #0x6263000                            
02c84b28: ldr     x19, [x19, #0xba0]                         S:'Banner logged impression.'
02c84b2c: ldr     x8, [x0]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c84b30: ldr     x20, [x20, #0x928]                         T:UnityEngine.Debug
02c84b34: ldr     x1, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c84b38: ldr     x9, [x8, #0x5e8]                           
02c84b3c: ldr     x2, [x8, #0x5f0]                           
02c84b40: blr     x9                                         
02c84b44: ldr     x0, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c84b48: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c84b4c: cbnz    w8, #0x2c84b54                             
02c84b50: bl      #0x2b70f30                                 fn_2b70f30
02c84b54: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c84b58: ldp     x20, x19, [sp, #0x10]                      
02c84b5c: mov     x1, xzr                                    
02c84b60: ldr     x30, [sp], #0x20                           
02c84b64: b       #0x5af21f4                                 UnityEngine.Debug::Log
02c84b68: bl      #0x2b7105c                                 fn_2b7105c
## <LoadBanner>b__10_3() -> void
---- AdViewScene::<LoadBanner>b__10_3 0x2c84b6c
02c84b6c: str     x30, [sp, #-0x20]!                         
02c84b70: stp     x20, x19, [sp, #0x10]                      
02c84b74: adrp    x20, #0x662f000                            
02c84b78: mov     x19, x0                                    
02c84b7c: ldrb    w8, [x20, #0x927]                          
02c84b80: tbnz    w8, #0, #0x2c84ba4                         
02c84b84: adrp    x0, #0x6263000                             
02c84b88: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c84b8c: bl      #0x2b70db0                                 fn_2b70db0
02c84b90: adrp    x0, #0x6264000                             
02c84b94: ldr     x0, [x0, #0xba8]                           S:'Banner clicked.'
02c84b98: bl      #0x2b70db0                                 fn_2b70db0
02c84b9c: mov     w8, #1                                     
02c84ba0: strb    w8, [x20, #0x927]                          
02c84ba4: ldr     x0, [x19, #0x30]                           .statusLabel
02c84ba8: cbz     x0, #0x2c84bf4                             
02c84bac: adrp    x19, #0x6264000                            
02c84bb0: adrp    x20, #0x6263000                            
02c84bb4: ldr     x19, [x19, #0xba8]                         S:'Banner clicked.'
02c84bb8: ldr     x8, [x0]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c84bbc: ldr     x20, [x20, #0x928]                         T:UnityEngine.Debug
02c84bc0: ldr     x1, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c84bc4: ldr     x9, [x8, #0x5e8]                           
02c84bc8: ldr     x2, [x8, #0x5f0]                           
02c84bcc: blr     x9                                         
02c84bd0: ldr     x0, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c84bd4: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c84bd8: cbnz    w8, #0x2c84be0                             
02c84bdc: bl      #0x2b70f30                                 fn_2b70f30
02c84be0: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c84be4: ldp     x20, x19, [sp, #0x10]                      
02c84be8: mov     x1, xzr                                    
02c84bec: ldr     x30, [sp], #0x20                           
02c84bf0: b       #0x5af21f4                                 UnityEngine.Debug::Log
02c84bf4: bl      #0x2b7105c                                 fn_2b7105c
