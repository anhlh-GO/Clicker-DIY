#### CLASS PagesScrollVisual parent= UnityEngine.MonoBehaviour
#   field _pageBG                        System.Collections.Generic.List`1<UnityEngine.GameObject> off=0x20 attr=1 SerializeField
#   field _pageHighlight                 System.Collections.Generic.List`1<UnityEngine.GameObject> off=0x28 attr=1 SerializeField
## Awake() -> void
---- PagesScrollVisual::Awake 0x2cae2dc
02cae2dc: ret                                                
## SetPages(int pageCount) -> void
---- PagesScrollVisual::SetPages 0x2cae2e0
02cae2e0: ldr     x8, [x0, #0x20]                            ._pageBG
02cae2e4: mov     w2, w1                                     
02cae2e8: mov     x1, x8                                     
02cae2ec: b       #0x2cae2f0                                 PagesScrollVisual::SetActive
## HighlightPage(int pageIndex) -> void
---- PagesScrollVisual::HighlightPage 0x2cae3ec
02cae3ec: str     x30, [sp, #-0x40]!                         
02cae3f0: stp     x24, x23, [sp, #0x10]                      
02cae3f4: stp     x22, x21, [sp, #0x20]                      
02cae3f8: stp     x20, x19, [sp, #0x30]                      
02cae3fc: adrp    x21, #0x662f000                            
02cae400: mov     w19, w1                                    
02cae404: mov     x20, x0                                    
02cae408: ldrb    w8, [x21, #0xb49]                          
02cae40c: tbnz    w8, #0, #0x2cae43c                         
02cae410: adrp    x0, #0x6266000                             
02cae414: ldr     x0, [x0, #0x900]                           MS:System.Collections.Generic.List`1::get_Count
02cae418: bl      #0x2b70db0                                 fn_2b70db0
02cae41c: adrp    x0, #0x6266000                             
02cae420: ldr     x0, [x0, #0x908]                           MS:System.Collections.Generic.List`1::get_Item
02cae424: bl      #0x2b70db0                                 fn_2b70db0
02cae428: adrp    x0, #0x6263000                             
02cae42c: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02cae430: bl      #0x2b70db0                                 fn_2b70db0
02cae434: mov     w8, #1                                     
02cae438: strb    w8, [x21, #0xb49]                          
02cae43c: ldr     x0, [x20, #0x28]                           ._pageHighlight
02cae440: cbz     x0, #0x2cae4d0                             
02cae444: adrp    x23, #0x6266000                            
02cae448: adrp    x24, #0x6263000                            
02cae44c: mov     w21, wzr                                   
02cae450: ldr     x23, [x23, #0x908]                         MS:System.Collections.Generic.List`1::get_Item
02cae454: ldr     x24, [x24, #0x918]                         T:UnityEngine.Object
02cae458: ldr     w8, [x0, #0x18]                            &2c5d934(=d65f03c0d503245f)
02cae45c: cmp     w21, w8                                    
02cae460: b.ge    #0x2cae4d4                                 
02cae464: ldr     x2, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cae468: mov     w1, w21                                    
02cae46c: bl      #0x35a8f3c                                 fn_35a8f3c
02cae470: ldr     x8, [x24]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cae474: mov     x22, x0                                    
02cae478: ldr     w9, [x8, #0xe4]                            
02cae47c: cbnz    w9, #0x2cae488                             
02cae480: mov     x0, x8                                     
02cae484: bl      #0x2b70f30                                 fn_2b70f30
02cae488: mov     x0, x22                                    
02cae48c: mov     x1, xzr                                    
02cae490: mov     x2, xzr                                    
02cae494: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02cae498: tbz     w0, #0, #0x2cae4c4                         
02cae49c: ldr     x0, [x20, #0x28]                           ._pageHighlight
02cae4a0: cbz     x0, #0x2cae4d0                             
02cae4a4: ldr     x2, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cae4a8: mov     w1, w21                                    
02cae4ac: bl      #0x35a8f3c                                 fn_35a8f3c
02cae4b0: cbz     x0, #0x2cae4d0                             
02cae4b4: cmp     w19, w21                                   
02cae4b8: mov     x2, xzr                                    
02cae4bc: cset    w1, eq                                     
02cae4c0: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cae4c4: ldr     x0, [x20, #0x28]                           ._pageHighlight
02cae4c8: add     w21, w21, #1                               
02cae4cc: cbnz    x0, #0x2cae458                             
02cae4d0: bl      #0x2b7105c                                 fn_2b7105c
02cae4d4: ldp     x20, x19, [sp, #0x30]                      
02cae4d8: ldp     x22, x21, [sp, #0x20]                      
02cae4dc: ldp     x24, x23, [sp, #0x10]                      
02cae4e0: ldr     x30, [sp], #0x40                           
02cae4e4: ret                                                
## SetActive(System.Collections.Generic.List`1<UnityEngine.GameObject> objects, int activeCount) -> void
---- PagesScrollVisual::SetActive 0x2cae2f0
02cae2f0: str     x30, [sp, #-0x40]!                         
02cae2f4: stp     x24, x23, [sp, #0x10]                      
02cae2f8: stp     x22, x21, [sp, #0x20]                      
02cae2fc: stp     x20, x19, [sp, #0x30]                      
02cae300: adrp    x21, #0x662f000                            
02cae304: mov     w19, w2                                    
02cae308: mov     x20, x1                                    
02cae30c: ldrb    w8, [x21, #0xb4a]                          
02cae310: tbnz    w8, #0, #0x2cae340                         
02cae314: adrp    x0, #0x6266000                             
02cae318: ldr     x0, [x0, #0x900]                           MS:System.Collections.Generic.List`1::get_Count
02cae31c: bl      #0x2b70db0                                 fn_2b70db0
02cae320: adrp    x0, #0x6266000                             
02cae324: ldr     x0, [x0, #0x908]                           MS:System.Collections.Generic.List`1::get_Item
02cae328: bl      #0x2b70db0                                 fn_2b70db0
02cae32c: adrp    x0, #0x6263000                             
02cae330: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02cae334: bl      #0x2b70db0                                 fn_2b70db0
02cae338: mov     w8, #1                                     
02cae33c: strb    w8, [x21, #0xb4a]                          
02cae340: cbz     x20, #0x2cae3e8                            
02cae344: ldr     w8, [x20, #0x18]                           
02cae348: cmp     w8, #1                                     
02cae34c: b.lt    #0x2cae3d4                                 
02cae350: adrp    x23, #0x6266000                            
02cae354: adrp    x24, #0x6263000                            
02cae358: mov     w21, wzr                                   
02cae35c: ldr     x23, [x23, #0x908]                         MS:System.Collections.Generic.List`1::get_Item
02cae360: ldr     x24, [x24, #0x918]                         T:UnityEngine.Object
02cae364: ldr     x2, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cae368: mov     x0, x20                                    
02cae36c: mov     w1, w21                                    
02cae370: bl      #0x35a8f3c                                 fn_35a8f3c
02cae374: ldr     x8, [x24]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cae378: mov     x22, x0                                    
02cae37c: ldr     w9, [x8, #0xe4]                            
02cae380: cbnz    w9, #0x2cae38c                             
02cae384: mov     x0, x8                                     
02cae388: bl      #0x2b70f30                                 fn_2b70f30
02cae38c: mov     x0, x22                                    
02cae390: mov     x1, xzr                                    
02cae394: mov     x2, xzr                                    
02cae398: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02cae39c: tbz     w0, #0, #0x2cae3c4                         
02cae3a0: ldr     x2, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cae3a4: mov     x0, x20                                    
02cae3a8: mov     w1, w21                                    
02cae3ac: bl      #0x35a8f3c                                 fn_35a8f3c
02cae3b0: cbz     x0, #0x2cae3e8                             
02cae3b4: cmp     w21, w19                                   
02cae3b8: mov     x2, xzr                                    
02cae3bc: cset    w1, lt                                     
02cae3c0: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cae3c4: ldr     w8, [x20, #0x18]                           
02cae3c8: add     w21, w21, #1                               
02cae3cc: cmp     w21, w8                                    
02cae3d0: b.lt    #0x2cae364                                 
02cae3d4: ldp     x20, x19, [sp, #0x30]                      
02cae3d8: ldp     x22, x21, [sp, #0x20]                      
02cae3dc: ldp     x24, x23, [sp, #0x10]                      
02cae3e0: ldr     x30, [sp], #0x40                           
02cae3e4: ret                                                
02cae3e8: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- PagesScrollVisual::.ctor 0x2cae4e8
02cae4e8: mov     x1, xzr                                    
02cae4ec: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
