#### CLASS Framework.RangedExtensions parent= object
## LerpFromRange(Framework.RangedFloat ranged, float t) -> float
---- Framework.RangedExtensions::LerpFromRange 0x2cb8414
02cb8414: fmov    s3, #1.00000000                            
02cb8418: movi    d4, #0000000000000000                      
02cb841c: fsub    s1, s1, s0                                 
02cb8420: fcmp    s2, s3                                     
02cb8424: fcsel   s3, s3, s2, gt                             
02cb8428: fcmp    s2, #0.0                                   
02cb842c: fcsel   s2, s4, s3, mi                             
02cb8430: fmul    s1, s1, s2                                 
02cb8434: fadd    s0, s0, s1                                 
02cb8438: ret                                                
## LerpFromRangeUnclamped(Framework.RangedFloat ranged, float t) -> float
---- Framework.RangedExtensions::LerpFromRangeUnclamped 0x2cb843c
02cb843c: fsub    s1, s1, s0                                 
02cb8440: fmul    s1, s1, s2                                 
02cb8444: fadd    s0, s0, s1                                 
02cb8448: ret                                                
## LerpFromRange(Framework.RangedInt ranged, float t) -> float
---- Framework.RangedExtensions::LerpFromRange 0x2cb844c
02cb844c: fmov    s1, #1.00000000                            
02cb8450: lsr     x8, x0, #0x20                              
02cb8454: scvtf   s2, w0                                     
02cb8458: movi    d4, #0000000000000000                      
02cb845c: scvtf   s3, w8                                     
02cb8460: fcmp    s0, s1                                     
02cb8464: fcsel   s1, s1, s0, gt                             
02cb8468: fcmp    s0, #0.0                                   
02cb846c: fcsel   s0, s4, s1, mi                             
02cb8470: fsub    s1, s3, s2                                 
02cb8474: fmul    s0, s1, s0                                 
02cb8478: fadd    s0, s0, s2                                 
02cb847c: ret                                                
## LerpFromRangeUnclamped(Framework.RangedInt ranged, float t) -> float
---- Framework.RangedExtensions::LerpFromRangeUnclamped 0x2cb8480
02cb8480: lsr     x8, x0, #0x20                              
02cb8484: scvtf   s1, w0                                     
02cb8488: scvtf   s2, w8                                     
02cb848c: fsub    s2, s2, s1                                 
02cb8490: fmul    s0, s2, s0                                 
02cb8494: fadd    s0, s0, s1                                 
02cb8498: ret                                                
