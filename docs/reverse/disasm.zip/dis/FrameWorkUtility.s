#### CLASS FrameWorkUtility/<>c__39`1 parent= object
#   field <>9                            FrameWorkUtility/<>c__39`1<T>                      off=0x0 attr=36 
#   field <>9__39_0                      System.Func`2<T,System.Guid>                       off=0x0 attr=16 
##  .cctor (no body)
##  .ctor (no body)
##  <Shuffle>b__39_0 (no body)
#### CLASS FrameWorkUtility/<>c__DisplayClass32_0 parent= object
#   field OnCompleted                    System.Action                                      off=0x10 attr=6 
## .ctor() -> void
---- FrameWorkUtility/<>c__DisplayClass32_0::.ctor 0x2cefd94
02cefd94: mov     x1, xzr                                    
02cefd98: b       #0x4e53e9c                                 System.Object::.ctor
## <DoTransform>b__0() -> void
---- FrameWorkUtility/<>c__DisplayClass32_0::<DoTransform>b__0 0x2cf19fc
02cf19fc: ldr     x8, [x0, #0x10]                            .OnCompleted
02cf1a00: cbz     x8, #0x2cf1a14                             
02cf1a04: ldr     x0, [x8, #0x40]                            
02cf1a08: ldr     x1, [x8, #0x28]                            
02cf1a0c: ldr     x2, [x8, #0x18]                            
02cf1a10: br      x2                                         
02cf1a14: ret                                                
#### CLASS FrameWorkUtility/<>c__DisplayClass33_0 parent= object
#   field OnCompleted                    System.Action                                      off=0x10 attr=6 
## .ctor() -> void
---- FrameWorkUtility/<>c__DisplayClass33_0::.ctor 0x2ceff24
02ceff24: mov     x1, xzr                                    
02ceff28: b       #0x4e53e9c                                 System.Object::.ctor
## <DoLocalTransform>b__0() -> void
---- FrameWorkUtility/<>c__DisplayClass33_0::<DoLocalTransform>b__0 0x2cf1a18
02cf1a18: ldr     x8, [x0, #0x10]                            .OnCompleted
02cf1a1c: cbz     x8, #0x2cf1a30                             
02cf1a20: ldr     x0, [x8, #0x40]                            
02cf1a24: ldr     x1, [x8, #0x28]                            
02cf1a28: ldr     x2, [x8, #0x18]                            
02cf1a2c: br      x2                                         
02cf1a30: ret                                                
#### CLASS FrameWorkUtility/<>c__DisplayClass38_0`1 parent= object
#   field sourceList                     System.Collections.Generic.List`1<T>               off=0x0 attr=6 
#   field random                         System.Random                                      off=0x0 attr=6 
##  .ctor (no body)
##  <PickRandom>b__0 (no body)
#### CLASS FrameWorkUtility/<>c__DisplayClass50_0 parent= object
#   field hit                            UnityEngine.RaycastHit2D                           off=0x10 attr=6 
## .ctor() -> void
---- FrameWorkUtility/<>c__DisplayClass50_0::.ctor 0x2cf10ec
02cf10ec: mov     x1, xzr                                    
02cf10f0: b       #0x4e53e9c                                 System.Object::.ctor
## <MutipleRayCastAll>b__0(UnityEngine.RaycastHit2D x) -> bool
---- FrameWorkUtility/<>c__DisplayClass50_0::<MutipleRayCastAll>b__0 0x2cf1a34
02cf1a34: str     x30, [sp, #-0x30]!                         
02cf1a38: stp     x22, x21, [sp, #0x10]                      
02cf1a3c: stp     x20, x19, [sp, #0x20]                      
02cf1a40: adrp    x22, #0x662f000                            
02cf1a44: adrp    x21, #0x6263000                            
02cf1a48: mov     x19, x1                                    
02cf1a4c: ldrb    w8, [x22, #0xe61]                          
02cf1a50: ldr     x21, [x21, #0x918]                         T:UnityEngine.Object
02cf1a54: mov     x20, x0                                    
02cf1a58: tbnz    w8, #0, #0x2cf1a70                         
02cf1a5c: adrp    x0, #0x6263000                             
02cf1a60: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02cf1a64: bl      #0x2b70db0                                 fn_2b70db0
02cf1a68: mov     w8, #1                                     
02cf1a6c: strb    w8, [x22, #0xe61]                          
02cf1a70: mov     x0, x19                                    
02cf1a74: mov     x1, xzr                                    
02cf1a78: bl      #0x5bbe11c                                 UnityEngine.RaycastHit2D::get_collider
02cf1a7c: mov     x19, x0                                    
02cf1a80: add     x0, x20, #0x10                             
02cf1a84: mov     x1, xzr                                    
02cf1a88: bl      #0x5bbe11c                                 UnityEngine.RaycastHit2D::get_collider
02cf1a8c: ldr     x8, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cf1a90: mov     x20, x0                                    
02cf1a94: ldr     w9, [x8, #0xe4]                            
02cf1a98: cbnz    w9, #0x2cf1aa4                             
02cf1a9c: mov     x0, x8                                     
02cf1aa0: bl      #0x2b70f30                                 fn_2b70f30
02cf1aa4: mov     x0, x19                                    
02cf1aa8: mov     x1, x20                                    
02cf1aac: mov     x2, xzr                                    
02cf1ab0: ldp     x20, x19, [sp, #0x20]                      
02cf1ab4: ldp     x22, x21, [sp, #0x10]                      
02cf1ab8: ldr     x30, [sp], #0x30                           
02cf1abc: b       #0x5b37d84                                 UnityEngine.Object::op_Equality
#### CLASS FrameWorkUtility/<>c__DisplayClass50_1 parent= object
#   field hit                            UnityEngine.RaycastHit2D                           off=0x10 attr=6 
## .ctor() -> void
---- FrameWorkUtility/<>c__DisplayClass50_1::.ctor 0x2cf10f4
02cf10f4: mov     x1, xzr                                    
02cf10f8: b       #0x4e53e9c                                 System.Object::.ctor
## <MutipleRayCastAll>b__1(UnityEngine.RaycastHit2D x) -> bool
---- FrameWorkUtility/<>c__DisplayClass50_1::<MutipleRayCastAll>b__1 0x2cf1ac0
02cf1ac0: str     x30, [sp, #-0x30]!                         
02cf1ac4: stp     x22, x21, [sp, #0x10]                      
02cf1ac8: stp     x20, x19, [sp, #0x20]                      
02cf1acc: adrp    x22, #0x662f000                            
02cf1ad0: adrp    x21, #0x6263000                            
02cf1ad4: mov     x19, x1                                    
02cf1ad8: ldrb    w8, [x22, #0xe62]                          
02cf1adc: ldr     x21, [x21, #0x918]                         T:UnityEngine.Object
02cf1ae0: mov     x20, x0                                    
02cf1ae4: tbnz    w8, #0, #0x2cf1afc                         
02cf1ae8: adrp    x0, #0x6263000                             
02cf1aec: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02cf1af0: bl      #0x2b70db0                                 fn_2b70db0
02cf1af4: mov     w8, #1                                     
02cf1af8: strb    w8, [x22, #0xe62]                          
02cf1afc: mov     x0, x19                                    
02cf1b00: mov     x1, xzr                                    
02cf1b04: bl      #0x5bbe11c                                 UnityEngine.RaycastHit2D::get_collider
02cf1b08: mov     x19, x0                                    
02cf1b0c: add     x0, x20, #0x10                             
02cf1b10: mov     x1, xzr                                    
02cf1b14: bl      #0x5bbe11c                                 UnityEngine.RaycastHit2D::get_collider
02cf1b18: ldr     x8, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cf1b1c: mov     x20, x0                                    
02cf1b20: ldr     w9, [x8, #0xe4]                            
02cf1b24: cbnz    w9, #0x2cf1b30                             
02cf1b28: mov     x0, x8                                     
02cf1b2c: bl      #0x2b70f30                                 fn_2b70f30
02cf1b30: mov     x0, x19                                    
02cf1b34: mov     x1, x20                                    
02cf1b38: mov     x2, xzr                                    
02cf1b3c: ldp     x20, x19, [sp, #0x20]                      
02cf1b40: ldp     x22, x21, [sp, #0x10]                      
02cf1b44: ldr     x30, [sp], #0x30                           
02cf1b48: b       #0x5b37d84                                 UnityEngine.Object::op_Equality
#### CLASS FrameWorkUtility/<EndOfFrameCoroutine>d__21 parent= object
#   field <>1__state                     int                                                off=0x10 attr=1 
#   field <>2__current                   object                                             off=0x18 attr=1 
#   field Callback                       UnityEngine.Events.UnityAction                     off=0x20 attr=6 
## .ctor(int <>1__state) -> void
---- FrameWorkUtility/<EndOfFrameCoroutine>d__21::.ctor 0x2cef868
02cef868: str     x30, [sp, #-0x20]!                         
02cef86c: stp     x20, x19, [sp, #0x10]                      
02cef870: mov     w19, w1                                    
02cef874: mov     x1, xzr                                    
02cef878: mov     x20, x0                                    
02cef87c: bl      #0x4e53e9c                                 System.Object::.ctor
02cef880: str     w19, [x20, #0x10]                          .<>1__state
02cef884: ldp     x20, x19, [sp, #0x10]                      
02cef888: ldr     x30, [sp], #0x20                           
02cef88c: ret                                                
## System.IDisposable.Dispose() -> void
---- FrameWorkUtility/<EndOfFrameCoroutine>d__21::System.IDisposable.Dispose 0x2cf1b4c
02cf1b4c: ret                                                
## MoveNext() -> bool
---- FrameWorkUtility/<EndOfFrameCoroutine>d__21::MoveNext 0x2cf1b50
02cf1b50: stp     x30, x21, [sp, #-0x20]!                    
02cf1b54: stp     x20, x19, [sp, #0x10]                      
02cf1b58: adrp    x20, #0x662f000                            
02cf1b5c: mov     x19, x0                                    
02cf1b60: ldrb    w8, [x20, #0xe63]                          
02cf1b64: tbnz    w8, #0, #0x2cf1b7c                         
02cf1b68: adrp    x0, #0x6268000                             
02cf1b6c: ldr     x0, [x0, #0x618]                           T:UnityEngine.WaitForEndOfFrame
02cf1b70: bl      #0x2b70db0                                 fn_2b70db0
02cf1b74: mov     w8, #1                                     
02cf1b78: strb    w8, [x20, #0xe63]                          
02cf1b7c: ldr     w21, [x19, #0x10]                          .<>1__state
02cf1b80: cbz     w21, #0x2cf1bb0                            
02cf1b84: cmp     w21, #1                                    
02cf1b88: b.ne    #0x2cf1bec                                 
02cf1b8c: ldr     x8, [x19, #0x20]                           .Callback
02cf1b90: mov     w9, #-1                                    
02cf1b94: str     w9, [x19, #0x10]                           .<>1__state
02cf1b98: cbz     x8, #0x2cf1bec                             
02cf1b9c: ldr     x9, [x8, #0x18]                            
02cf1ba0: ldr     x0, [x8, #0x40]                            
02cf1ba4: ldr     x1, [x8, #0x28]                            
02cf1ba8: blr     x9                                         
02cf1bac: b       #0x2cf1bec                                 
02cf1bb0: adrp    x8, #0x6268000                             
02cf1bb4: mov     w9, #-1                                    
02cf1bb8: ldr     x8, [x8, #0x618]                           T:UnityEngine.WaitForEndOfFrame
02cf1bbc: str     w9, [x19, #0x10]                           .<>1__state
02cf1bc0: ldr     x0, [x8]                                   S:'{0}/2'
02cf1bc4: bl      #0x2b7104c                                 fn_2b7104c
02cf1bc8: mov     x1, xzr                                    
02cf1bcc: mov     x20, x0                                    
02cf1bd0: bl      #0x5b3e5d8                                 UnityEngine.WaitForEndOfFrame::.ctor
02cf1bd4: mov     x0, x19                                    
02cf1bd8: mov     x1, x20                                    
02cf1bdc: str     x20, [x0, #0x18]!                          .<>2__current
02cf1be0: bl      #0x2b70d54                                 fn_2b70d54
02cf1be4: mov     w8, #1                                     
02cf1be8: str     w8, [x19, #0x10]                           .<>1__state
02cf1bec: ldp     x20, x19, [sp, #0x10]                      
02cf1bf0: cmp     w21, #0                                    
02cf1bf4: cset    w0, eq                                     
02cf1bf8: ldp     x30, x21, [sp], #0x20                      
02cf1bfc: ret                                                
## System.Collections.Generic.IEnumerator<System.Object>.get_Current() -> object
---- FrameWorkUtility/<EndOfFrameCoroutine>d__21::System.Collections.Generic.IEnumerator<System.Object>.get_Current 0x2cf1c00
02cf1c00: ldr     x0, [x0, #0x18]                            .<>2__current
02cf1c04: ret                                                
## System.Collections.IEnumerator.Reset() -> void
---- FrameWorkUtility/<EndOfFrameCoroutine>d__21::System.Collections.IEnumerator.Reset 0x2cf1c08
02cf1c08: stp     x30, x19, [sp, #-0x10]!                    
02cf1c0c: adrp    x0, #0x6264000                             
02cf1c10: ldr     x0, [x0, #0xf60]                           T:System.NotSupportedException
02cf1c14: bl      #0x2b70dc4                                 fn_2b70dc4
02cf1c18: bl      #0x2b7104c                                 fn_2b7104c
02cf1c1c: mov     x1, xzr                                    
02cf1c20: mov     x19, x0                                    
02cf1c24: bl      #0x4e14238                                 System.NotSupportedException::.ctor
02cf1c28: adrp    x0, #0x6268000                             
02cf1c2c: ldr     x0, [x0, #0x620]                           M:FrameWorkUtility/<EndOfFrameCoroutine>d__21::System.Collections.IEnumerator.Reset
02cf1c30: bl      #0x2b70dc4                                 fn_2b70dc4
02cf1c34: mov     x1, x0                                     
02cf1c38: mov     x0, x19                                    
02cf1c3c: bl      #0x2b70f20                                 fn_2b70f20
## System.Collections.IEnumerator.get_Current() -> object
---- FrameWorkUtility/<EndOfFrameCoroutine>d__21::System.Collections.IEnumerator.get_Current 0x2cf1c40
02cf1c40: ldr     x0, [x0, #0x18]                            .<>2__current
02cf1c44: ret                                                
#### CLASS FrameWorkUtility/<I_Progress>d__36 parent= object
#   field <>1__state                     int                                                off=0x10 attr=1 
#   field <>2__current                   float                                              off=0x14 attr=1 
#   field duration                       float                                              off=0x18 attr=6 
#   field rtf                            UnityEngine.RectTransform                          off=0x20 attr=6 
#   field start                          UnityEngine.Vector2                                off=0x28 attr=6 
#   field end                            UnityEngine.Vector2                                off=0x30 attr=6 
#   field <t>5__2                        float                                              off=0x38 attr=1 
## .ctor(int <>1__state) -> void
---- FrameWorkUtility/<I_Progress>d__36::.ctor 0x2cf014c
02cf014c: str     x30, [sp, #-0x20]!                         
02cf0150: stp     x20, x19, [sp, #0x10]                      
02cf0154: mov     w19, w1                                    
02cf0158: mov     x1, xzr                                    
02cf015c: mov     x20, x0                                    
02cf0160: bl      #0x4e53e9c                                 System.Object::.ctor
02cf0164: str     w19, [x20, #0x10]                          .<>1__state
02cf0168: ldp     x20, x19, [sp, #0x10]                      
02cf016c: ldr     x30, [sp], #0x20                           
02cf0170: ret                                                
## System.IDisposable.Dispose() -> void
---- FrameWorkUtility/<I_Progress>d__36::System.IDisposable.Dispose 0x2cf1c48
02cf1c48: ret                                                
## MoveNext() -> bool
---- FrameWorkUtility/<I_Progress>d__36::MoveNext 0x2cf1c4c
02cf1c4c: str     d8, [sp, #-0x20]!                          
02cf1c50: stp     x30, x19, [sp, #0x10]                      
02cf1c54: ldr     w8, [x0, #0x10]                            .<>1__state
02cf1c58: mov     x19, x0                                    
02cf1c5c: cmp     w8, #1                                     
02cf1c60: b.eq    #0x2cf1c7c                                 
02cf1c64: cbnz    w8, #0x2cf1cf4                             
02cf1c68: movi    d8, #0000000000000000                      
02cf1c6c: mov     w8, #-1                                    
02cf1c70: str     wzr, [x19, #0x38]                          .<t>5__2
02cf1c74: str     w8, [x19, #0x10]                           .<>1__state
02cf1c78: b       #0x2cf1c94                                 
02cf1c7c: fmov    s0, #1.00000000                            
02cf1c80: ldr     s8, [x19, #0x38]                           .<t>5__2
02cf1c84: mov     w8, #-1                                    
02cf1c88: str     w8, [x19, #0x10]                           .<>1__state
02cf1c8c: fcmp    s8, s0                                     
02cf1c90: b.pl    #0x2cf1cf4                                 
02cf1c94: mov     x0, xzr                                    
02cf1c98: bl      #0x5b433a4                                 UnityEngine.Time::get_deltaTime
02cf1c9c: ldr     s1, [x19, #0x18]                           .duration
02cf1ca0: ldr     x0, [x19, #0x20]                           .rtf
02cf1ca4: fdiv    s0, s0, s1                                 
02cf1ca8: fadd    s0, s8, s0                                 
02cf1cac: str     s0, [x19, #0x38]                           .<t>5__2
02cf1cb0: cbz     x0, #0x2cf1d04                             
02cf1cb4: fmov    s1, #1.00000000                            
02cf1cb8: movi    d2, #0000000000000000                      
02cf1cbc: mov     x1, xzr                                    
02cf1cc0: fcmp    s0, s1                                     
02cf1cc4: fcsel   s1, s1, s0, gt                             
02cf1cc8: fcmp    s0, #0.0                                   
02cf1ccc: ldp     d0, d3, [x19, #0x28]                       .start
02cf1cd0: fcsel   s1, s2, s1, mi                             
02cf1cd4: fsub    v2.2s, v3.2s, v0.2s                        
02cf1cd8: fmul    v1.2s, v2.2s, v1.s[0]                      
02cf1cdc: fadd    v0.2s, v0.2s, v1.2s                        
02cf1ce0: mov     s1, v0.s[1]                                
02cf1ce4: bl      #0x5b45994                                 UnityEngine.RectTransform::set_sizeDelta
02cf1ce8: mov     w0, #1                                     
02cf1cec: str     x0, [x19, #0x10]                           .<>1__state
02cf1cf0: b       #0x2cf1cf8                                 
02cf1cf4: mov     w0, wzr                                    
02cf1cf8: ldp     x30, x19, [sp, #0x10]                      
02cf1cfc: ldr     d8, [sp], #0x20                            
02cf1d00: ret                                                
02cf1d04: bl      #0x2b7105c                                 fn_2b7105c
## System.Collections.Generic.IEnumerator<System.Single>.get_Current() -> float
---- FrameWorkUtility/<I_Progress>d__36::System.Collections.Generic.IEnumerator<System.Single>.get_Current 0x2cf1d08
02cf1d08: ldr     s0, [x0, #0x14]                            .<>2__current
02cf1d0c: ret                                                
## System.Collections.IEnumerator.Reset() -> void
---- FrameWorkUtility/<I_Progress>d__36::System.Collections.IEnumerator.Reset 0x2cf1d10
02cf1d10: stp     x30, x19, [sp, #-0x10]!                    
02cf1d14: adrp    x0, #0x6264000                             
02cf1d18: ldr     x0, [x0, #0xf60]                           T:System.NotSupportedException
02cf1d1c: bl      #0x2b70dc4                                 fn_2b70dc4
02cf1d20: bl      #0x2b7104c                                 fn_2b7104c
02cf1d24: mov     x1, xzr                                    
02cf1d28: mov     x19, x0                                    
02cf1d2c: bl      #0x4e14238                                 System.NotSupportedException::.ctor
02cf1d30: adrp    x0, #0x6268000                             
02cf1d34: ldr     x0, [x0, #0x628]                           M:FrameWorkUtility/<I_Progress>d__36::System.Collections.IEnumerator.Reset
02cf1d38: bl      #0x2b70dc4                                 fn_2b70dc4
02cf1d3c: mov     x1, x0                                     
02cf1d40: mov     x0, x19                                    
02cf1d44: bl      #0x2b70f20                                 fn_2b70f20
## System.Collections.IEnumerator.get_Current() -> object
---- FrameWorkUtility/<I_Progress>d__36::System.Collections.IEnumerator.get_Current 0x2cf1d48
02cf1d48: str     x30, [sp, #-0x10]!                         
02cf1d4c: adrp    x8, #0x6263000                             
02cf1d50: add     x1, sp, #0xc                               
02cf1d54: ldr     x8, [x8, #0x970]                           &6645c70(=0)
02cf1d58: ldr     s0, [x0, #0x14]                            .<>2__current
02cf1d5c: ldr     x0, [x8, #0x78]                            &2c498b4(=d65f03c0d503245f)
02cf1d60: str     s0, [sp, #0xc]                             
02cf1d64: bl      #0x2b70f38                                 fn_2b70f38
02cf1d68: ldr     x30, [sp], #0x10                           
02cf1d6c: ret                                                
#### CLASS FrameWorkUtility/<I_SetColor>d__11 parent= object
#   field <>1__state                     int                                                off=0x10 attr=1 
#   field <>2__current                   object                                             off=0x18 attr=1 
#   field renderer                       UnityEngine.Renderer                               off=0x20 attr=6 
#   field duration                       float                                              off=0x28 attr=6 
#   field color1                         UnityEngine.Color                                  off=0x2c attr=6 
#   field color2                         UnityEngine.Color                                  off=0x3c attr=6 
#   field OnCompleted                    System.Action                                      off=0x50 attr=6 
#   field <propBlock>5__2                UnityEngine.MaterialPropertyBlock                  off=0x58 attr=1 
#   field <t>5__3                        float                                              off=0x60 attr=1 
## .ctor(int <>1__state) -> void
---- FrameWorkUtility/<I_SetColor>d__11::.ctor 0x2cef224
02cef224: str     x30, [sp, #-0x20]!                         
02cef228: stp     x20, x19, [sp, #0x10]                      
02cef22c: mov     w19, w1                                    
02cef230: mov     x1, xzr                                    
02cef234: mov     x20, x0                                    
02cef238: bl      #0x4e53e9c                                 System.Object::.ctor
02cef23c: str     w19, [x20, #0x10]                          .<>1__state
02cef240: ldp     x20, x19, [sp, #0x10]                      
02cef244: ldr     x30, [sp], #0x20                           
02cef248: ret                                                
## System.IDisposable.Dispose() -> void
---- FrameWorkUtility/<I_SetColor>d__11::System.IDisposable.Dispose 0x2cf1d70
02cf1d70: ret                                                
## MoveNext() -> bool
---- FrameWorkUtility/<I_SetColor>d__11::MoveNext 0x2cf1d74
02cf1d74: str     d8, [sp, #-0x30]!                          
02cf1d78: stp     x30, x21, [sp, #0x10]                      
02cf1d7c: stp     x20, x19, [sp, #0x20]                      
02cf1d80: adrp    x20, #0x662f000                            
02cf1d84: mov     x19, x0                                    
02cf1d88: ldrb    w8, [x20, #0xe64]                          
02cf1d8c: tbnz    w8, #0, #0x2cf1db0                         
02cf1d90: adrp    x0, #0x6268000                             
02cf1d94: ldr     x0, [x0, #0x520]                           T:UnityEngine.MaterialPropertyBlock
02cf1d98: bl      #0x2b70db0                                 fn_2b70db0
02cf1d9c: adrp    x0, #0x6268000                             
02cf1da0: ldr     x0, [x0, #0x530]                           S:'_Color'
02cf1da4: bl      #0x2b70db0                                 fn_2b70db0
02cf1da8: mov     w8, #1                                     
02cf1dac: strb    w8, [x20, #0xe64]                          
02cf1db0: ldr     w8, [x19, #0x10]                           .<>1__state
02cf1db4: cmp     w8, #1                                     
02cf1db8: b.eq    #0x2cf1e18                                 
02cf1dbc: cbnz    w8, #0x2cf1f1c                             
02cf1dc0: adrp    x8, #0x6268000                             
02cf1dc4: mov     w9, #-1                                    
02cf1dc8: ldr     x8, [x8, #0x520]                           T:UnityEngine.MaterialPropertyBlock
02cf1dcc: str     w9, [x19, #0x10]                           .<>1__state
02cf1dd0: ldr     x0, [x8]                                   S:'{0}/2'
02cf1dd4: bl      #0x2b7104c                                 fn_2b7104c
02cf1dd8: mov     x1, xzr                                    
02cf1ddc: mov     x20, x0                                    
02cf1de0: bl      #0x5b01a80                                 UnityEngine.MaterialPropertyBlock::.ctor
02cf1de4: mov     x21, x19                                   
02cf1de8: mov     x1, x20                                    
02cf1dec: str     x20, [x21, #0x58]!                         .<propBlock>5__2
02cf1df0: mov     x0, x21                                    
02cf1df4: bl      #0x2b70d54                                 fn_2b70d54
02cf1df8: ldur    x0, [x21, #-0x38]                          
02cf1dfc: cbz     x0, #0x2cf1f30                             
02cf1e00: ldr     x1, [x19, #0x58]                           .<propBlock>5__2
02cf1e04: mov     x2, xzr                                    
02cf1e08: bl      #0x5b02d90                                 UnityEngine.Renderer::GetPropertyBlock
02cf1e0c: movi    d8, #0000000000000000                      
02cf1e10: str     wzr, [x19, #0x60]                          .<t>5__3
02cf1e14: b       #0x2cf1e30                                 
02cf1e18: fmov    s0, #1.00000000                            
02cf1e1c: ldr     s8, [x19, #0x60]                           .<t>5__3
02cf1e20: mov     w8, #-1                                    
02cf1e24: str     w8, [x19, #0x10]                           .<>1__state
02cf1e28: fcmp    s8, s0                                     
02cf1e2c: b.pl    #0x2cf1f04                                 
02cf1e30: mov     x0, xzr                                    
02cf1e34: bl      #0x5b433a4                                 UnityEngine.Time::get_deltaTime
02cf1e38: ldr     s1, [x19, #0x28]                           .duration
02cf1e3c: ldr     x0, [x19, #0x58]                           .<propBlock>5__2
02cf1e40: fdiv    s0, s0, s1                                 
02cf1e44: fadd    s0, s8, s0                                 
02cf1e48: str     s0, [x19, #0x60]                           .<t>5__3
02cf1e4c: cbz     x0, #0x2cf1f30                             
02cf1e50: fmov    s1, #1.00000000                            
02cf1e54: movi    d3, #0000000000000000                      
02cf1e58: adrp    x8, #0x6268000                             
02cf1e5c: fmov    s4, #3.00000000                            
02cf1e60: mov     x2, xzr                                    
02cf1e64: fcmp    s0, s1                                     
02cf1e68: fcsel   s2, s1, s0, gt                             
02cf1e6c: fcmp    s0, #0.0                                   
02cf1e70: fcsel   s0, s3, s2, mi                             
02cf1e74: fadd    s2, s0, s0                                 
02cf1e78: fmul    s4, s0, s4                                 
02cf1e7c: fmul    s2, s0, s2                                 
02cf1e80: fmul    s4, s0, s4                                 
02cf1e84: fmul    s0, s0, s2                                 
02cf1e88: fsub    s0, s4, s0                                 
02cf1e8c: fsub    s2, s1, s0                                 
02cf1e90: fmul    s2, s2, s3                                 
02cf1e94: fadd    s0, s0, s2                                 
02cf1e98: ldur    q2, [x19, #0x3c]                           .color2
02cf1e9c: fcmp    s0, s1                                     
02cf1ea0: fcsel   s1, s1, s0, gt                             
02cf1ea4: fcmp    s0, #0.0                                   
02cf1ea8: ldur    q0, [x19, #0x2c]                           .color1
02cf1eac: ldr     x8, [x8, #0x530]                           S:'_Color'
02cf1eb0: fsub    v2.4s, v2.4s, v0.4s                        
02cf1eb4: ldr     x1, [x8]                                   S:'{0}/2'
02cf1eb8: fcsel   s1, s3, s1, mi                             
02cf1ebc: fmul    v1.4s, v2.4s, v1.s[0]                      
02cf1ec0: fadd    v0.4s, v0.4s, v1.4s                        
02cf1ec4: mov     s1, v0.s[1]                                
02cf1ec8: mov     s2, v0.s[2]                                
02cf1ecc: mov     s3, v0.s[3]                                
02cf1ed0: bl      #0x5b01e10                                 UnityEngine.MaterialPropertyBlock::SetColor
02cf1ed4: ldr     x0, [x19, #0x20]                           .renderer
02cf1ed8: cbz     x0, #0x2cf1f30                             
02cf1edc: ldr     x1, [x19, #0x58]                           .<propBlock>5__2
02cf1ee0: mov     x2, xzr                                    
02cf1ee4: bl      #0x5b02d88                                 UnityEngine.Renderer::SetPropertyBlock
02cf1ee8: str     xzr, [x19, #0x18]!                         .<>2__current
02cf1eec: mov     x0, x19                                    
02cf1ef0: mov     x1, xzr                                    
02cf1ef4: bl      #0x2b70d54                                 fn_2b70d54
02cf1ef8: mov     w0, #1                                     
02cf1efc: stur    w0, [x19, #-8]                             
02cf1f00: b       #0x2cf1f20                                 
02cf1f04: ldr     x8, [x19, #0x50]                           .OnCompleted
02cf1f08: cbz     x8, #0x2cf1f1c                             
02cf1f0c: ldr     x9, [x8, #0x18]                            M:LuckyWheelPopup/<>c__DisplayClass50_0::<RunAnimation>b__0
02cf1f10: ldr     x0, [x8, #0x40]                            MS:System.Collections.Generic.List`1/Enumerator::Dispose
02cf1f14: ldr     x1, [x8, #0x28]                            T:LuckyWheelPopup/<>c__DisplayClass52_0
02cf1f18: blr     x9                                         
02cf1f1c: mov     w0, wzr                                    
02cf1f20: ldp     x20, x19, [sp, #0x20]                      
02cf1f24: ldp     x30, x21, [sp, #0x10]                      
02cf1f28: ldr     d8, [sp], #0x30                            
02cf1f2c: ret                                                
02cf1f30: bl      #0x2b7105c                                 fn_2b7105c
## System.Collections.Generic.IEnumerator<System.Object>.get_Current() -> object
---- FrameWorkUtility/<I_SetColor>d__11::System.Collections.Generic.IEnumerator<System.Object>.get_Current 0x2cf1f34
02cf1f34: ldr     x0, [x0, #0x18]                            .<>2__current
02cf1f38: ret                                                
## System.Collections.IEnumerator.Reset() -> void
---- FrameWorkUtility/<I_SetColor>d__11::System.Collections.IEnumerator.Reset 0x2cf1f3c
02cf1f3c: stp     x30, x19, [sp, #-0x10]!                    
02cf1f40: adrp    x0, #0x6264000                             
02cf1f44: ldr     x0, [x0, #0xf60]                           T:System.NotSupportedException
02cf1f48: bl      #0x2b70dc4                                 fn_2b70dc4
02cf1f4c: bl      #0x2b7104c                                 fn_2b7104c
02cf1f50: mov     x1, xzr                                    
02cf1f54: mov     x19, x0                                    
02cf1f58: bl      #0x4e14238                                 System.NotSupportedException::.ctor
02cf1f5c: adrp    x0, #0x6268000                             
02cf1f60: ldr     x0, [x0, #0x630]                           M:FrameWorkUtility/<I_SetColor>d__11::System.Collections.IEnumerator.Reset
02cf1f64: bl      #0x2b70dc4                                 fn_2b70dc4
02cf1f68: mov     x1, x0                                     
02cf1f6c: mov     x0, x19                                    
02cf1f70: bl      #0x2b70f20                                 fn_2b70f20
## System.Collections.IEnumerator.get_Current() -> object
---- FrameWorkUtility/<I_SetColor>d__11::System.Collections.IEnumerator.get_Current 0x2cf1f74
02cf1f74: ldr     x0, [x0, #0x18]                            .<>2__current
02cf1f78: ret                                                
#### CLASS FrameWorkUtility/<I_SmoothLookAtInSeconds>d__46 parent= object
#   field <>1__state                     int                                                off=0x10 attr=1 
#   field <>2__current                   object                                             off=0x18 attr=1 
#   field duration                       float                                              off=0x20 attr=6 
#   field target                         UnityEngine.Transform                              off=0x28 attr=6 
#   field tf                             UnityEngine.Transform                              off=0x30 attr=6 
#   field OnCompleted                    System.Action                                      off=0x38 attr=6 
#   field <t>5__2                        float                                              off=0x40 attr=1 
## .ctor(int <>1__state) -> void
---- FrameWorkUtility/<I_SmoothLookAtInSeconds>d__46::.ctor 0x2cf07c4
02cf07c4: str     x30, [sp, #-0x20]!                         
02cf07c8: stp     x20, x19, [sp, #0x10]                      
02cf07cc: mov     w19, w1                                    
02cf07d0: mov     x1, xzr                                    
02cf07d4: mov     x20, x0                                    
02cf07d8: bl      #0x4e53e9c                                 System.Object::.ctor
02cf07dc: str     w19, [x20, #0x10]                          .<>1__state
02cf07e0: ldp     x20, x19, [sp, #0x10]                      
02cf07e4: ldr     x30, [sp], #0x20                           
02cf07e8: ret                                                
## System.IDisposable.Dispose() -> void
---- FrameWorkUtility/<I_SmoothLookAtInSeconds>d__46::System.IDisposable.Dispose 0x2cf1f7c
02cf1f7c: ret                                                
## MoveNext() -> bool
---- FrameWorkUtility/<I_SmoothLookAtInSeconds>d__46::MoveNext 0x2cf1f80
02cf1f80: sub     sp, sp, #0x60                              
02cf1f84: stp     d11, d10, [sp, #0x20]                      
02cf1f88: stp     d9, d8, [sp, #0x30]                        
02cf1f8c: str     x30, [sp, #0x40]                           
02cf1f90: stp     x20, x19, [sp, #0x50]                      
02cf1f94: ldr     w8, [x0, #0x10]                            .<>1__state
02cf1f98: mov     x19, x0                                    
02cf1f9c: cmp     w8, #1                                     
02cf1fa0: b.eq    #0x2cf1fbc                                 
02cf1fa4: cbnz    w8, #0x2cf210c                             
02cf1fa8: movi    d8, #0000000000000000                      
02cf1fac: mov     w8, #-1                                    
02cf1fb0: str     wzr, [x19, #0x40]                          .<t>5__2
02cf1fb4: str     w8, [x19, #0x10]                           .<>1__state
02cf1fb8: b       #0x2cf1fd4                                 
02cf1fbc: fmov    s0, #1.00000000                            
02cf1fc0: ldr     s8, [x19, #0x40]                           .<t>5__2
02cf1fc4: mov     w8, #-1                                    
02cf1fc8: str     w8, [x19, #0x10]                           .<>1__state
02cf1fcc: fcmp    s8, s0                                     
02cf1fd0: b.pl    #0x2cf20f4                                 
02cf1fd4: mov     x0, xzr                                    
02cf1fd8: bl      #0x5b433a4                                 UnityEngine.Time::get_deltaTime
02cf1fdc: ldr     s1, [x19, #0x20]                           .duration
02cf1fe0: ldr     x0, [x19, #0x28]                           .target
02cf1fe4: fdiv    s0, s0, s1                                 
02cf1fe8: fadd    s0, s8, s0                                 
02cf1fec: str     s0, [x19, #0x40]                           .<t>5__2
02cf1ff0: cbz     x0, #0x2cf2128                             
02cf1ff4: mov     x1, xzr                                    
02cf1ff8: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02cf1ffc: ldr     x0, [x19, #0x30]                           .tf
02cf2000: cbz     x0, #0x2cf2128                             
02cf2004: mov     x1, xzr                                    
02cf2008: fmov    s8, s0                                     
02cf200c: fmov    s9, s1                                     
02cf2010: fmov    s10, s2                                    
02cf2014: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02cf2018: fsub    s0, s8, s0                                 
02cf201c: fsub    s1, s9, s1                                 
02cf2020: adrp    x20, #0x662f000                            
02cf2024: fsub    s2, s10, s2                                
02cf2028: ldrb    w8, [x20, #0x918]                          
02cf202c: str     wzr, [sp, #8]                              
02cf2030: str     xzr, [sp]                                  
02cf2034: stp     s0, s1, [sp, #0x10]                        
02cf2038: str     s2, [sp, #0x18]                            
02cf203c: cbnz    w8, #0x2cf2054                             
02cf2040: adrp    x0, #0x6264000                             
02cf2044: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02cf2048: bl      #0x2b70db0                                 fn_2b70db0
02cf204c: mov     w8, #1                                     
02cf2050: strb    w8, [x20, #0x918]                          
02cf2054: adrp    x8, #0x6264000                             
02cf2058: add     x0, sp, #0x10                              
02cf205c: mov     x1, sp                                     
02cf2060: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02cf2064: mov     x2, xzr                                    
02cf2068: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cf206c: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02cf2070: ldr     d0, [x8, #0x18]                            M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0::<DOSetFloat>b__1
02cf2074: ldr     s1, [x8, #0x20]                            T:DG.Tweening.DOTweenModulePhysics/<>c__DisplayClass0_0
02cf2078: str     d0, [sp]                                   
02cf207c: str     s1, [sp, #8]                               
02cf2080: bl      #0x5b262ec                                 UnityEngine.Quaternion::Internal_LookRotation
02cf2084: ldr     x20, [x19, #0x30]                          .tf
02cf2088: cbz     x20, #0x2cf2128                            
02cf208c: mov     x0, x20                                    
02cf2090: mov     x1, xzr                                    
02cf2094: fmov    s9, s0                                     
02cf2098: fmov    s10, s1                                    
02cf209c: fmov    s8, s2                                     
02cf20a0: fmov    s11, s3                                    
02cf20a4: bl      #0x5b46a30                                 UnityEngine.Transform::get_rotation
02cf20a8: stp     s0, s1, [sp, #0x10]                        
02cf20ac: ldr     s0, [x19, #0x40]                           .<t>5__2
02cf20b0: add     x0, sp, #0x10                              
02cf20b4: mov     x1, sp                                     
02cf20b8: mov     x2, xzr                                    
02cf20bc: stp     s2, s3, [sp, #0x18]                        
02cf20c0: stp     s9, s10, [sp]                              
02cf20c4: stp     s8, s11, [sp, #8]                          
02cf20c8: bl      #0x5b25f70                                 UnityEngine.Quaternion::Internal_Slerp
02cf20cc: mov     x0, x20                                    
02cf20d0: mov     x1, xzr                                    
02cf20d4: bl      #0x5b46b18                                 UnityEngine.Transform::set_rotation
02cf20d8: str     xzr, [x19, #0x18]!                         .<>2__current
02cf20dc: mov     x0, x19                                    
02cf20e0: mov     x1, xzr                                    
02cf20e4: bl      #0x2b70d54                                 fn_2b70d54
02cf20e8: mov     w0, #1                                     
02cf20ec: stur    w0, [x19, #-8]                             
02cf20f0: b       #0x2cf2110                                 
02cf20f4: ldr     x8, [x19, #0x38]                           .OnCompleted
02cf20f8: cbz     x8, #0x2cf210c                             
02cf20fc: ldr     x9, [x8, #0x18]                            M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0::<DOSetFloat>b__1
02cf2100: ldr     x0, [x8, #0x40]                            MS:DG.Tweening.TweenSettingsExtensions::SetTarget
02cf2104: ldr     x1, [x8, #0x28]                            T:type8534(k15)
02cf2108: blr     x9                                         
02cf210c: mov     w0, wzr                                    
02cf2110: ldp     x20, x19, [sp, #0x50]                      
02cf2114: ldr     x30, [sp, #0x40]                           
02cf2118: ldp     d9, d8, [sp, #0x30]                        
02cf211c: ldp     d11, d10, [sp, #0x20]                      
02cf2120: add     sp, sp, #0x60                              
02cf2124: ret                                                
02cf2128: bl      #0x2b7105c                                 fn_2b7105c
## System.Collections.Generic.IEnumerator<System.Object>.get_Current() -> object
---- FrameWorkUtility/<I_SmoothLookAtInSeconds>d__46::System.Collections.Generic.IEnumerator<System.Object>.get_Current 0x2cf212c
02cf212c: ldr     x0, [x0, #0x18]                            .<>2__current
02cf2130: ret                                                
## System.Collections.IEnumerator.Reset() -> void
---- FrameWorkUtility/<I_SmoothLookAtInSeconds>d__46::System.Collections.IEnumerator.Reset 0x2cf2134
02cf2134: stp     x30, x19, [sp, #-0x10]!                    
02cf2138: adrp    x0, #0x6264000                             
02cf213c: ldr     x0, [x0, #0xf60]                           T:System.NotSupportedException
02cf2140: bl      #0x2b70dc4                                 fn_2b70dc4
02cf2144: bl      #0x2b7104c                                 fn_2b7104c
02cf2148: mov     x1, xzr                                    
02cf214c: mov     x19, x0                                    
02cf2150: bl      #0x4e14238                                 System.NotSupportedException::.ctor
02cf2154: adrp    x0, #0x6268000                             
02cf2158: ldr     x0, [x0, #0x638]                           M:FrameWorkUtility/<I_SmoothLookAtInSeconds>d__46::System.Collections.IEnumerator.Reset
02cf215c: bl      #0x2b70dc4                                 fn_2b70dc4
02cf2160: mov     x1, x0                                     
02cf2164: mov     x0, x19                                    
02cf2168: bl      #0x2b70f20                                 fn_2b70f20
## System.Collections.IEnumerator.get_Current() -> object
---- FrameWorkUtility/<I_SmoothLookAtInSeconds>d__46::System.Collections.IEnumerator.get_Current 0x2cf216c
02cf216c: ldr     x0, [x0, #0x18]                            .<>2__current
02cf2170: ret                                                
#### CLASS FrameWorkUtility/<InFixedUpdatesCoroutine>d__27 parent= object
#   field <>1__state                     int                                                off=0x10 attr=1 
#   field <>2__current                   object                                             off=0x18 attr=1 
#   field ticks                          int                                                off=0x20 attr=6 
#   field Callback                       UnityEngine.Events.UnityAction                     off=0x28 attr=6 
#   field <i>5__2                        int                                                off=0x30 attr=1 
## .ctor(int <>1__state) -> void
---- FrameWorkUtility/<InFixedUpdatesCoroutine>d__27::.ctor 0x2cefa28
02cefa28: str     x30, [sp, #-0x20]!                         
02cefa2c: stp     x20, x19, [sp, #0x10]                      
02cefa30: mov     w19, w1                                    
02cefa34: mov     x1, xzr                                    
02cefa38: mov     x20, x0                                    
02cefa3c: bl      #0x4e53e9c                                 System.Object::.ctor
02cefa40: str     w19, [x20, #0x10]                          .<>1__state
02cefa44: ldp     x20, x19, [sp, #0x10]                      
02cefa48: ldr     x30, [sp], #0x20                           
02cefa4c: ret                                                
## System.IDisposable.Dispose() -> void
---- FrameWorkUtility/<InFixedUpdatesCoroutine>d__27::System.IDisposable.Dispose 0x2cf2174
02cf2174: ret                                                
## MoveNext() -> bool
---- FrameWorkUtility/<InFixedUpdatesCoroutine>d__27::MoveNext 0x2cf2178
02cf2178: str     x30, [sp, #-0x20]!                         
02cf217c: stp     x20, x19, [sp, #0x10]                      
02cf2180: adrp    x20, #0x662f000                            
02cf2184: mov     x19, x0                                    
02cf2188: ldrb    w8, [x20, #0xe65]                          
02cf218c: tbnz    w8, #0, #0x2cf21a4                         
02cf2190: adrp    x0, #0x6268000                             
02cf2194: ldr     x0, [x0, #0x640]                           T:UnityEngine.WaitForFixedUpdate
02cf2198: bl      #0x2b70db0                                 fn_2b70db0
02cf219c: mov     w8, #1                                     
02cf21a0: strb    w8, [x20, #0xe65]                          
02cf21a4: ldr     w8, [x19, #0x10]                           .<>1__state
02cf21a8: cmp     w8, #1                                     
02cf21ac: b.eq    #0x2cf21c4                                 
02cf21b0: cbnz    w8, #0x2cf2234                             
02cf21b4: mov     w9, #-1                                    
02cf21b8: str     wzr, [x19, #0x30]                          .<i>5__2
02cf21bc: str     w9, [x19, #0x10]                           .<>1__state
02cf21c0: b       #0x2cf21d8                                 
02cf21c4: ldr     w8, [x19, #0x30]                           .<i>5__2
02cf21c8: mov     w9, #-1                                    
02cf21cc: str     w9, [x19, #0x10]                           .<>1__state
02cf21d0: add     w8, w8, #1                                 
02cf21d4: str     w8, [x19, #0x30]                           .<i>5__2
02cf21d8: ldr     w9, [x19, #0x20]                           .ticks
02cf21dc: cmp     w8, w9                                     
02cf21e0: b.ge    #0x2cf221c                                 
02cf21e4: adrp    x8, #0x6268000                             
02cf21e8: ldr     x8, [x8, #0x640]                           T:UnityEngine.WaitForFixedUpdate
02cf21ec: ldr     x0, [x8]                                   S:'{0}/2'
02cf21f0: bl      #0x2b7104c                                 fn_2b7104c
02cf21f4: mov     x1, xzr                                    
02cf21f8: mov     x20, x0                                    
02cf21fc: bl      #0x5b3e5e0                                 UnityEngine.WaitForFixedUpdate::.ctor
02cf2200: str     x20, [x19, #0x18]!                         .<>2__current
02cf2204: mov     x0, x19                                    
02cf2208: mov     x1, x20                                    
02cf220c: bl      #0x2b70d54                                 fn_2b70d54
02cf2210: mov     w0, #1                                     
02cf2214: stur    w0, [x19, #-8]                             
02cf2218: b       #0x2cf2238                                 
02cf221c: ldr     x8, [x19, #0x28]                           .Callback
02cf2220: cbz     x8, #0x2cf2234                             
02cf2224: ldr     x9, [x8, #0x18]                            M:LuckyWheelPopup/<>c__DisplayClass50_0::<RunAnimation>b__0
02cf2228: ldr     x0, [x8, #0x40]                            MS:System.Collections.Generic.List`1/Enumerator::Dispose
02cf222c: ldr     x1, [x8, #0x28]                            T:LuckyWheelPopup/<>c__DisplayClass52_0
02cf2230: blr     x9                                         
02cf2234: mov     w0, wzr                                    
02cf2238: ldp     x20, x19, [sp, #0x10]                      
02cf223c: ldr     x30, [sp], #0x20                           
02cf2240: ret                                                
## System.Collections.Generic.IEnumerator<System.Object>.get_Current() -> object
---- FrameWorkUtility/<InFixedUpdatesCoroutine>d__27::System.Collections.Generic.IEnumerator<System.Object>.get_Current 0x2cf2244
02cf2244: ldr     x0, [x0, #0x18]                            .<>2__current
02cf2248: ret                                                
## System.Collections.IEnumerator.Reset() -> void
---- FrameWorkUtility/<InFixedUpdatesCoroutine>d__27::System.Collections.IEnumerator.Reset 0x2cf224c
02cf224c: stp     x30, x19, [sp, #-0x10]!                    
02cf2250: adrp    x0, #0x6264000                             
02cf2254: ldr     x0, [x0, #0xf60]                           T:System.NotSupportedException
02cf2258: bl      #0x2b70dc4                                 fn_2b70dc4
02cf225c: bl      #0x2b7104c                                 fn_2b7104c
02cf2260: mov     x1, xzr                                    
02cf2264: mov     x19, x0                                    
02cf2268: bl      #0x4e14238                                 System.NotSupportedException::.ctor
02cf226c: adrp    x0, #0x6268000                             
02cf2270: ldr     x0, [x0, #0x648]                           M:FrameWorkUtility/<InFixedUpdatesCoroutine>d__27::System.Collections.IEnumerator.Reset
02cf2274: bl      #0x2b70dc4                                 fn_2b70dc4
02cf2278: mov     x1, x0                                     
02cf227c: mov     x0, x19                                    
02cf2280: bl      #0x2b70f20                                 fn_2b70f20
## System.Collections.IEnumerator.get_Current() -> object
---- FrameWorkUtility/<InFixedUpdatesCoroutine>d__27::System.Collections.IEnumerator.get_Current 0x2cf2284
02cf2284: ldr     x0, [x0, #0x18]                            .<>2__current
02cf2288: ret                                                
#### CLASS FrameWorkUtility/<InSecondsCoroutine>d__29 parent= object
#   field <>1__state                     int                                                off=0x10 attr=1 
#   field <>2__current                   object                                             off=0x18 attr=1 
#   field seconds                        float                                              off=0x20 attr=6 
#   field Callback                       UnityEngine.Events.UnityAction                     off=0x28 attr=6 
## .ctor(int <>1__state) -> void
---- FrameWorkUtility/<InSecondsCoroutine>d__29::.ctor 0x2cefaf8
02cefaf8: str     x30, [sp, #-0x20]!                         
02cefafc: stp     x20, x19, [sp, #0x10]                      
02cefb00: mov     w19, w1                                    
02cefb04: mov     x1, xzr                                    
02cefb08: mov     x20, x0                                    
02cefb0c: bl      #0x4e53e9c                                 System.Object::.ctor
02cefb10: str     w19, [x20, #0x10]                          .<>1__state
02cefb14: ldp     x20, x19, [sp, #0x10]                      
02cefb18: ldr     x30, [sp], #0x20                           
02cefb1c: ret                                                
## System.IDisposable.Dispose() -> void
---- FrameWorkUtility/<InSecondsCoroutine>d__29::System.IDisposable.Dispose 0x2cf228c
02cf228c: ret                                                
## MoveNext() -> bool
---- FrameWorkUtility/<InSecondsCoroutine>d__29::MoveNext 0x2cf2290
02cf2290: str     d8, [sp, #-0x30]!                          
02cf2294: stp     x30, x21, [sp, #0x10]                      
02cf2298: stp     x20, x19, [sp, #0x20]                      
02cf229c: adrp    x20, #0x662f000                            
02cf22a0: mov     x19, x0                                    
02cf22a4: ldrb    w8, [x20, #0xe66]                          
02cf22a8: tbnz    w8, #0, #0x2cf22c0                         
02cf22ac: adrp    x0, #0x6264000                             
02cf22b0: ldr     x0, [x0, #0xf58]                           T:UnityEngine.WaitForSeconds
02cf22b4: bl      #0x2b70db0                                 fn_2b70db0
02cf22b8: mov     w8, #1                                     
02cf22bc: strb    w8, [x20, #0xe66]                          
02cf22c0: ldr     w21, [x19, #0x10]                          .<>1__state
02cf22c4: cbz     w21, #0x2cf22f4                            
02cf22c8: cmp     w21, #1                                    
02cf22cc: b.ne    #0x2cf2338                                 
02cf22d0: ldr     x8, [x19, #0x28]                           .Callback
02cf22d4: mov     w9, #-1                                    
02cf22d8: str     w9, [x19, #0x10]                           .<>1__state
02cf22dc: cbz     x8, #0x2cf2338                             
02cf22e0: ldr     x9, [x8, #0x18]                            
02cf22e4: ldr     x0, [x8, #0x40]                            
02cf22e8: ldr     x1, [x8, #0x28]                            
02cf22ec: blr     x9                                         
02cf22f0: b       #0x2cf2338                                 
02cf22f4: adrp    x8, #0x6264000                             
02cf22f8: mov     w9, #-1                                    
02cf22fc: ldr     x8, [x8, #0xf58]                           T:UnityEngine.WaitForSeconds
02cf2300: ldr     s8, [x19, #0x20]                           .seconds
02cf2304: str     w9, [x19, #0x10]                           .<>1__state
02cf2308: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cf230c: bl      #0x2b7104c                                 fn_2b7104c
02cf2310: fmov    s0, s8                                     
02cf2314: mov     x1, xzr                                    
02cf2318: mov     x20, x0                                    
02cf231c: bl      #0x5b3e5e8                                 UnityEngine.WaitForSeconds::.ctor
02cf2320: mov     x0, x19                                    
02cf2324: mov     x1, x20                                    
02cf2328: str     x20, [x0, #0x18]!                          .<>2__current
02cf232c: bl      #0x2b70d54                                 fn_2b70d54
02cf2330: mov     w8, #1                                     
02cf2334: str     w8, [x19, #0x10]                           .<>1__state
02cf2338: cmp     w21, #0                                    
02cf233c: ldp     x20, x19, [sp, #0x20]                      
02cf2340: ldp     x30, x21, [sp, #0x10]                      
02cf2344: cset    w0, eq                                     
02cf2348: ldr     d8, [sp], #0x30                            
02cf234c: ret                                                
## System.Collections.Generic.IEnumerator<System.Object>.get_Current() -> object
---- FrameWorkUtility/<InSecondsCoroutine>d__29::System.Collections.Generic.IEnumerator<System.Object>.get_Current 0x2cf2350
02cf2350: ldr     x0, [x0, #0x18]                            .<>2__current
02cf2354: ret                                                
## System.Collections.IEnumerator.Reset() -> void
---- FrameWorkUtility/<InSecondsCoroutine>d__29::System.Collections.IEnumerator.Reset 0x2cf2358
02cf2358: stp     x30, x19, [sp, #-0x10]!                    
02cf235c: adrp    x0, #0x6264000                             
02cf2360: ldr     x0, [x0, #0xf60]                           T:System.NotSupportedException
02cf2364: bl      #0x2b70dc4                                 fn_2b70dc4
02cf2368: bl      #0x2b7104c                                 fn_2b7104c
02cf236c: mov     x1, xzr                                    
02cf2370: mov     x19, x0                                    
02cf2374: bl      #0x4e14238                                 System.NotSupportedException::.ctor
02cf2378: adrp    x0, #0x6268000                             
02cf237c: ldr     x0, [x0, #0x650]                           M:FrameWorkUtility/<InSecondsCoroutine>d__29::System.Collections.IEnumerator.Reset
02cf2380: bl      #0x2b70dc4                                 fn_2b70dc4
02cf2384: mov     x1, x0                                     
02cf2388: mov     x0, x19                                    
02cf238c: bl      #0x2b70f20                                 fn_2b70f20
## System.Collections.IEnumerator.get_Current() -> object
---- FrameWorkUtility/<InSecondsCoroutine>d__29::System.Collections.IEnumerator.get_Current 0x2cf2390
02cf2390: ldr     x0, [x0, #0x18]                            .<>2__current
02cf2394: ret                                                
#### CLASS FrameWorkUtility/<InSecondsIntervalCoroutine>d__31 parent= object
#   field <>1__state                     int                                                off=0x10 attr=1 
#   field <>2__current                   object                                             off=0x18 attr=1 
#   field seconds                        float                                              off=0x20 attr=6 
#   field interval                       float                                              off=0x24 attr=6 
#   field Callback                       UnityEngine.Events.UnityAction                     off=0x28 attr=6 
#   field self                           UnityEngine.MonoBehaviour                          off=0x30 attr=6 
## .ctor(int <>1__state) -> void
---- FrameWorkUtility/<InSecondsIntervalCoroutine>d__31::.ctor 0x2cefbe4
02cefbe4: str     x30, [sp, #-0x20]!                         
02cefbe8: stp     x20, x19, [sp, #0x10]                      
02cefbec: mov     w19, w1                                    
02cefbf0: mov     x1, xzr                                    
02cefbf4: mov     x20, x0                                    
02cefbf8: bl      #0x4e53e9c                                 System.Object::.ctor
02cefbfc: str     w19, [x20, #0x10]                          .<>1__state
02cefc00: ldp     x20, x19, [sp, #0x10]                      
02cefc04: ldr     x30, [sp], #0x20                           
02cefc08: ret                                                
## System.IDisposable.Dispose() -> void
---- FrameWorkUtility/<InSecondsIntervalCoroutine>d__31::System.IDisposable.Dispose 0x2cf2398
02cf2398: ret                                                
## MoveNext() -> bool
---- FrameWorkUtility/<InSecondsIntervalCoroutine>d__31::MoveNext 0x2cf239c
02cf239c: str     d8, [sp, #-0x20]!                          
02cf23a0: str     x30, [sp, #8]                              
02cf23a4: stp     x20, x19, [sp, #0x10]                      
02cf23a8: adrp    x20, #0x662f000                            
02cf23ac: mov     x19, x0                                    
02cf23b0: ldrb    w8, [x20, #0xe67]                          
02cf23b4: tbnz    w8, #0, #0x2cf23cc                         
02cf23b8: adrp    x0, #0x6264000                             
02cf23bc: ldr     x0, [x0, #0xf58]                           T:UnityEngine.WaitForSeconds
02cf23c0: bl      #0x2b70db0                                 fn_2b70db0
02cf23c4: mov     w8, #1                                     
02cf23c8: strb    w8, [x20, #0xe67]                          
02cf23cc: ldr     w8, [x19, #0x10]                           .<>1__state
02cf23d0: cmp     w8, #2                                     
02cf23d4: b.eq    #0x2cf2434                                 
02cf23d8: cmp     w8, #1                                     
02cf23dc: b.eq    #0x2cf2428                                 
02cf23e0: cbnz    w8, #0x2cf24b8                             
02cf23e4: adrp    x8, #0x6264000                             
02cf23e8: mov     w9, #-1                                    
02cf23ec: ldr     x8, [x8, #0xf58]                           T:UnityEngine.WaitForSeconds
02cf23f0: ldr     s8, [x19, #0x20]                           .seconds
02cf23f4: str     w9, [x19, #0x10]                           .<>1__state
02cf23f8: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cf23fc: bl      #0x2b7104c                                 fn_2b7104c
02cf2400: fmov    s0, s8                                     
02cf2404: mov     x1, xzr                                    
02cf2408: mov     x20, x0                                    
02cf240c: bl      #0x5b3e5e8                                 UnityEngine.WaitForSeconds::.ctor
02cf2410: mov     x0, x19                                    
02cf2414: mov     x1, x20                                    
02cf2418: str     x20, [x0, #0x18]!                          .<>2__current
02cf241c: bl      #0x2b70d54                                 fn_2b70d54
02cf2420: mov     w8, #1                                     
02cf2424: b       #0x2cf24ac                                 
02cf2428: mov     w8, #-1                                    
02cf242c: str     w8, [x19, #0x10]                           .<>1__state
02cf2430: b       #0x2cf2454                                 
02cf2434: ldr     x8, [x19, #0x28]                           .Callback
02cf2438: mov     w9, #-1                                    
02cf243c: str     w9, [x19, #0x10]                           .<>1__state
02cf2440: cbz     x8, #0x2cf2454                             
02cf2444: ldr     x9, [x8, #0x18]                            M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0::<DOSetFloat>b__1
02cf2448: ldr     x0, [x8, #0x40]                            MS:DG.Tweening.TweenSettingsExtensions::SetTarget
02cf244c: ldr     x1, [x8, #0x28]                            T:type8534(k15)
02cf2450: blr     x9                                         
02cf2454: ldr     x0, [x19, #0x30]                           .self
02cf2458: cbz     x0, #0x2cf24cc                             
02cf245c: mov     x1, xzr                                    
02cf2460: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02cf2464: cbz     x0, #0x2cf24cc                             
02cf2468: mov     x1, xzr                                    
02cf246c: bl      #0x5b36cb0                                 UnityEngine.GameObject::get_activeInHierarchy
02cf2470: tbz     w0, #0, #0x2cf24b8                         
02cf2474: adrp    x8, #0x6264000                             
02cf2478: ldr     x8, [x8, #0xf58]                           T:UnityEngine.WaitForSeconds
02cf247c: ldr     s8, [x19, #0x24]                           .interval
02cf2480: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cf2484: bl      #0x2b7104c                                 fn_2b7104c
02cf2488: fmov    s0, s8                                     
02cf248c: mov     x1, xzr                                    
02cf2490: mov     x20, x0                                    
02cf2494: bl      #0x5b3e5e8                                 UnityEngine.WaitForSeconds::.ctor
02cf2498: mov     x0, x19                                    
02cf249c: mov     x1, x20                                    
02cf24a0: str     x20, [x0, #0x18]!                          .<>2__current
02cf24a4: bl      #0x2b70d54                                 fn_2b70d54
02cf24a8: mov     w8, #2                                     
02cf24ac: mov     w0, #1                                     
02cf24b0: str     w8, [x19, #0x10]                           .<>1__state
02cf24b4: b       #0x2cf24bc                                 
02cf24b8: mov     w0, wzr                                    
02cf24bc: ldp     x20, x19, [sp, #0x10]                      
02cf24c0: ldr     x30, [sp, #8]                              
02cf24c4: ldr     d8, [sp], #0x20                            
02cf24c8: ret                                                
02cf24cc: bl      #0x2b7105c                                 fn_2b7105c
## System.Collections.Generic.IEnumerator<System.Object>.get_Current() -> object
---- FrameWorkUtility/<InSecondsIntervalCoroutine>d__31::System.Collections.Generic.IEnumerator<System.Object>.get_Current 0x2cf24d0
02cf24d0: ldr     x0, [x0, #0x18]                            .<>2__current
02cf24d4: ret                                                
## System.Collections.IEnumerator.Reset() -> void
---- FrameWorkUtility/<InSecondsIntervalCoroutine>d__31::System.Collections.IEnumerator.Reset 0x2cf24d8
02cf24d8: stp     x30, x19, [sp, #-0x10]!                    
02cf24dc: adrp    x0, #0x6264000                             
02cf24e0: ldr     x0, [x0, #0xf60]                           T:System.NotSupportedException
02cf24e4: bl      #0x2b70dc4                                 fn_2b70dc4
02cf24e8: bl      #0x2b7104c                                 fn_2b7104c
02cf24ec: mov     x1, xzr                                    
02cf24f0: mov     x19, x0                                    
02cf24f4: bl      #0x4e14238                                 System.NotSupportedException::.ctor
02cf24f8: adrp    x0, #0x6268000                             
02cf24fc: ldr     x0, [x0, #0x658]                           M:FrameWorkUtility/<InSecondsIntervalCoroutine>d__31::System.Collections.IEnumerator.Reset
02cf2500: bl      #0x2b70dc4                                 fn_2b70dc4
02cf2504: mov     x1, x0                                     
02cf2508: mov     x0, x19                                    
02cf250c: bl      #0x2b70f20                                 fn_2b70f20
## System.Collections.IEnumerator.get_Current() -> object
---- FrameWorkUtility/<InSecondsIntervalCoroutine>d__31::System.Collections.IEnumerator.get_Current 0x2cf2510
02cf2510: ldr     x0, [x0, #0x18]                            .<>2__current
02cf2514: ret                                                
#### CLASS FrameWorkUtility/<InUpdatesCoroutine>d__24 parent= object
#   field <>1__state                     int                                                off=0x10 attr=1 
#   field <>2__current                   object                                             off=0x18 attr=1 
#   field updates                        int                                                off=0x20 attr=6 
#   field Callback                       UnityEngine.Events.UnityAction                     off=0x28 attr=6 
#   field <i>5__2                        int                                                off=0x30 attr=1 
## .ctor(int <>1__state) -> void
---- FrameWorkUtility/<InUpdatesCoroutine>d__24::.ctor 0x2cef948
02cef948: str     x30, [sp, #-0x20]!                         
02cef94c: stp     x20, x19, [sp, #0x10]                      
02cef950: mov     w19, w1                                    
02cef954: mov     x1, xzr                                    
02cef958: mov     x20, x0                                    
02cef95c: bl      #0x4e53e9c                                 System.Object::.ctor
02cef960: str     w19, [x20, #0x10]                          .<>1__state
02cef964: ldp     x20, x19, [sp, #0x10]                      
02cef968: ldr     x30, [sp], #0x20                           
02cef96c: ret                                                
## System.IDisposable.Dispose() -> void
---- FrameWorkUtility/<InUpdatesCoroutine>d__24::System.IDisposable.Dispose 0x2cf2518
02cf2518: ret                                                
## MoveNext() -> bool
---- FrameWorkUtility/<InUpdatesCoroutine>d__24::MoveNext 0x2cf251c
02cf251c: stp     x30, x19, [sp, #-0x10]!                    
02cf2520: ldr     w8, [x0, #0x10]                            .<>1__state
02cf2524: mov     x19, x0                                    
02cf2528: cmp     w8, #1                                     
02cf252c: b.eq    #0x2cf2544                                 
02cf2530: cbnz    w8, #0x2cf2598                             
02cf2534: mov     w9, #-1                                    
02cf2538: str     wzr, [x19, #0x30]                          .<i>5__2
02cf253c: str     w9, [x19, #0x10]                           .<>1__state
02cf2540: b       #0x2cf2558                                 
02cf2544: ldr     w8, [x19, #0x30]                           .<i>5__2
02cf2548: mov     w9, #-1                                    
02cf254c: str     w9, [x19, #0x10]                           .<>1__state
02cf2550: add     w8, w8, #1                                 
02cf2554: str     w8, [x19, #0x30]                           .<i>5__2
02cf2558: ldr     w9, [x19, #0x20]                           .updates
02cf255c: cmp     w8, w9                                     
02cf2560: b.ge    #0x2cf2580                                 
02cf2564: str     xzr, [x19, #0x18]!                         .<>2__current
02cf2568: mov     x0, x19                                    
02cf256c: mov     x1, xzr                                    
02cf2570: bl      #0x2b70d54                                 fn_2b70d54
02cf2574: mov     w0, #1                                     
02cf2578: stur    w0, [x19, #-8]                             
02cf257c: b       #0x2cf259c                                 
02cf2580: ldr     x8, [x19, #0x28]                           .Callback
02cf2584: cbz     x8, #0x2cf2598                             
02cf2588: ldr     x9, [x8, #0x18]                            
02cf258c: ldr     x0, [x8, #0x40]                            
02cf2590: ldr     x1, [x8, #0x28]                            
02cf2594: blr     x9                                         
02cf2598: mov     w0, wzr                                    
02cf259c: ldp     x30, x19, [sp], #0x10                      
02cf25a0: ret                                                
## System.Collections.Generic.IEnumerator<System.Object>.get_Current() -> object
---- FrameWorkUtility/<InUpdatesCoroutine>d__24::System.Collections.Generic.IEnumerator<System.Object>.get_Current 0x2cf25a4
02cf25a4: ldr     x0, [x0, #0x18]                            .<>2__current
02cf25a8: ret                                                
## System.Collections.IEnumerator.Reset() -> void
---- FrameWorkUtility/<InUpdatesCoroutine>d__24::System.Collections.IEnumerator.Reset 0x2cf25ac
02cf25ac: stp     x30, x19, [sp, #-0x10]!                    
02cf25b0: adrp    x0, #0x6264000                             
02cf25b4: ldr     x0, [x0, #0xf60]                           T:System.NotSupportedException
02cf25b8: bl      #0x2b70dc4                                 fn_2b70dc4
02cf25bc: bl      #0x2b7104c                                 fn_2b7104c
02cf25c0: mov     x1, xzr                                    
02cf25c4: mov     x19, x0                                    
02cf25c8: bl      #0x4e14238                                 System.NotSupportedException::.ctor
02cf25cc: adrp    x0, #0x6268000                             
02cf25d0: ldr     x0, [x0, #0x660]                           M:FrameWorkUtility/<InUpdatesCoroutine>d__24::System.Collections.IEnumerator.Reset
02cf25d4: bl      #0x2b70dc4                                 fn_2b70dc4
02cf25d8: mov     x1, x0                                     
02cf25dc: mov     x0, x19                                    
02cf25e0: bl      #0x2b70f20                                 fn_2b70f20
## System.Collections.IEnumerator.get_Current() -> object
---- FrameWorkUtility/<InUpdatesCoroutine>d__24::System.Collections.IEnumerator.get_Current 0x2cf25e4
02cf25e4: ldr     x0, [x0, #0x18]                            .<>2__current
02cf25e8: ret                                                
#### CLASS FrameWorkUtility parent= object
## sign(UnityEngine.Vector2 p1, UnityEngine.Vector2 p2, UnityEngine.Vector2 p3) -> float
---- FrameWorkUtility::sign 0x2ceebf4
02ceebf4: fsub    s0, s0, s4                                 
02ceebf8: fsub    s3, s3, s5                                 
02ceebfc: fsub    s2, s2, s4                                 
02ceec00: fsub    s1, s1, s5                                 
02ceec04: fmul    s0, s0, s3                                 
02ceec08: fmul    s1, s2, s1                                 
02ceec0c: fsub    s0, s0, s1                                 
02ceec10: ret                                                
## PointInTriangle(UnityEngine.Vector2 pt, UnityEngine.Vector2 v1, UnityEngine.Vector2 v2, UnityEngine.Vector2 v3) -> bool
---- FrameWorkUtility::PointInTriangle 0x2ceec14
02ceec14: fsub    s16, s3, s5                                
02ceec18: fsub    s17, s0, s4                                
02ceec1c: fsub    s18, s2, s4                                
02ceec20: fsub    s19, s1, s5                                
02ceec24: fsub    s20, s0, s6                                
02ceec28: fsub    s5, s5, s7                                 
02ceec2c: fsub    s4, s4, s6                                 
02ceec30: fsub    s21, s1, s7                                
02ceec34: fsub    s0, s0, s2                                 
02ceec38: fsub    s7, s7, s3                                 
02ceec3c: fsub    s2, s6, s2                                 
02ceec40: fsub    s1, s1, s3                                 
02ceec44: fmul    s16, s17, s16                              
02ceec48: fmul    s17, s18, s19                              
02ceec4c: fmul    s5, s20, s5                                
02ceec50: fmul    s4, s4, s21                                
02ceec54: fmul    s0, s0, s7                                 
02ceec58: fmul    s1, s1, s2                                 
02ceec5c: fsub    s3, s16, s17                               
02ceec60: fsub    s4, s5, s4                                 
02ceec64: fsub    s0, s0, s1                                 
02ceec68: fmaxnm  s1, s3, s4                                 
02ceec6c: fminnm  s2, s3, s4                                 
02ceec70: fmaxnm  s1, s1, s0                                 
02ceec74: fminnm  s0, s2, s0                                 
02ceec78: fcmp    s1, #0.0                                   
02ceec7c: cset    w8, le                                     
02ceec80: fcmp    s0, #0.0                                   
02ceec84: csinc   w0, w8, wzr, mi                            
02ceec88: ret                                                
## WrapRotation(UnityEngine.Quaternion rot) -> UnityEngine.Vector3
---- FrameWorkUtility::WrapRotation 0x2ceec8c
02ceec8c: sub     sp, sp, #0x50                              
02ceec90: stp     d13, d12, [sp, #0x10]                      
02ceec94: stp     d11, d10, [sp, #0x20]                      
02ceec98: stp     d9, d8, [sp, #0x30]                        
02ceec9c: str     x30, [sp, #0x40]                           
02ceeca0: mov     x0, sp                                     
02ceeca4: mov     x1, xzr                                    
02ceeca8: stp     s0, s1, [sp]                               
02ceecac: stp     s2, s3, [sp, #8]                           
02ceecb0: bl      #0x5b26118                                 UnityEngine.Quaternion::Internal_ToEulerRad
02ceecb4: adrp    x8, #0x1084000                             
02ceecb8: mov     x0, xzr                                    
02ceecbc: ldr     s11, [x8, #0xdec]                          [1084dec]=3fe6666642652ee1 f=57.2958,1.8
02ceecc0: fmul    s0, s0, s11                                
02ceecc4: fmul    s1, s1, s11                                
02ceecc8: fmul    s2, s2, s11                                
02ceeccc: bl      #0x5b266d8                                 UnityEngine.Quaternion::Internal_MakePositive
02ceecd0: mov     w8, #0x43b40000                            
02ceecd4: fmov    s8, w8                                     
02ceecd8: fmov    s1, s8                                     
02ceecdc: bl      #0x5e90330                                 fn_5e90330
02ceece0: mov     w8, #-0x3c4c0000                           
02ceece4: mov     x0, sp                                     
02ceece8: mov     x1, xzr                                    
02ceecec: fmov    s12, w8                                    
02ceecf0: mov     w8, #0x43340000                            
02ceecf4: fmov    s13, w8                                    
02ceecf8: fadd    s1, s0, s12                                
02ceecfc: fcmp    s0, s13                                    
02ceed00: fcsel   s9, s1, s0, gt                             
02ceed04: bl      #0x5b26118                                 UnityEngine.Quaternion::Internal_ToEulerRad
02ceed08: fmul    s0, s0, s11                                
02ceed0c: fmul    s1, s1, s11                                
02ceed10: mov     x0, xzr                                    
02ceed14: fmul    s2, s2, s11                                
02ceed18: bl      #0x5b266d8                                 UnityEngine.Quaternion::Internal_MakePositive
02ceed1c: fmov    s0, s1                                     
02ceed20: fmov    s1, s8                                     
02ceed24: bl      #0x5e90330                                 fn_5e90330
02ceed28: fadd    s1, s0, s12                                
02ceed2c: fcmp    s0, s13                                    
02ceed30: mov     x0, sp                                     
02ceed34: mov     x1, xzr                                    
02ceed38: fcsel   s10, s1, s0, gt                            
02ceed3c: bl      #0x5b26118                                 UnityEngine.Quaternion::Internal_ToEulerRad
02ceed40: fmul    s0, s0, s11                                
02ceed44: fmul    s1, s1, s11                                
02ceed48: mov     x0, xzr                                    
02ceed4c: fmul    s2, s2, s11                                
02ceed50: bl      #0x5b266d8                                 UnityEngine.Quaternion::Internal_MakePositive
02ceed54: fmov    s0, s2                                     
02ceed58: fmov    s1, s8                                     
02ceed5c: bl      #0x5e90330                                 fn_5e90330
02ceed60: fadd    s1, s0, s12                                
02ceed64: fcmp    s0, s13                                    
02ceed68: ldr     x30, [sp, #0x40]                           
02ceed6c: ldp     d13, d12, [sp, #0x10]                      
02ceed70: fcsel   s2, s1, s0, gt                             
02ceed74: fmov    s0, s9                                     
02ceed78: fmov    s1, s10                                    
02ceed7c: ldp     d9, d8, [sp, #0x30]                        
02ceed80: ldp     d11, d10, [sp, #0x20]                      
02ceed84: add     sp, sp, #0x50                              
02ceed88: ret                                                
## WrapAngle(float angle) -> float
---- FrameWorkUtility::WrapAngle 0x2ceed8c
02ceed8c: str     x30, [sp, #-0x10]!                         
02ceed90: mov     w8, #0x43b40000                            
02ceed94: fmov    s1, w8                                     
02ceed98: bl      #0x5e90330                                 fn_5e90330
02ceed9c: mov     w8, #-0x3c4c0000                           
02ceeda0: fmov    s1, w8                                     
02ceeda4: mov     w8, #0x43340000                            
02ceeda8: fmov    s2, w8                                     
02ceedac: fadd    s1, s0, s1                                 
02ceedb0: fcmp    s0, s2                                     
02ceedb4: fcsel   s0, s1, s0, gt                             
02ceedb8: ldr     x30, [sp], #0x10                           
02ceedbc: ret                                                
## UnwrapAngle(float angle) -> float
---- FrameWorkUtility::UnwrapAngle 0x2ceedc0
02ceedc0: fcmp    s0, #0.0                                   
02ceedc4: b.ge    #0x2ceedf0                                 
02ceedc8: str     d8, [sp, #-0x10]!                          
02ceedcc: str     x30, [sp, #8]                              
02ceedd0: mov     w8, #0x43b40000                            
02ceedd4: fneg    s0, s0                                     
02ceedd8: fmov    s8, w8                                     
02ceeddc: fmov    s1, s8                                     
02ceede0: bl      #0x5e90330                                 fn_5e90330
02ceede4: fsub    s0, s8, s0                                 
02ceede8: ldr     x30, [sp, #8]                              
02ceedec: ldr     d8, [sp], #0x10                            
02ceedf0: ret                                                
## ChangeMaterial(UnityEngine.Renderer rend, UnityEngine.Material mat, int index) -> void
---- FrameWorkUtility::ChangeMaterial 0x2ceedf4
02ceedf4: str     x30, [sp, #-0x30]!                         
02ceedf8: stp     x22, x21, [sp, #0x10]                      
02ceedfc: stp     x20, x19, [sp, #0x20]                      
02ceee00: cbz     x0, #0x2ceee70                             
02ceee04: mov     x20, x1                                    
02ceee08: mov     x1, xzr                                    
02ceee0c: mov     w21, w2                                    
02ceee10: mov     x19, x0                                    
02ceee14: bl      #0x5b04730                                 UnityEngine.Renderer::get_materials
02ceee18: cbz     x0, #0x2ceee70                             
02ceee1c: mov     x22, x0                                    
02ceee20: cbz     x20, #0x2ceee38                            
02ceee24: ldr     x8, [x22]                                  
02ceee28: mov     x0, x20                                    
02ceee2c: ldr     x1, [x8, #0x40]                            
02ceee30: bl      #0x2b70f34                                 fn_2b70f34
02ceee34: cbz     x0, #0x2ceee78                             
02ceee38: ldr     w8, [x22, #0x18]                           
02ceee3c: cmp     w8, w21                                    
02ceee40: b.ls    #0x2ceee74                                 
02ceee44: add     x0, x22, w21, sxtw #3                      
02ceee48: mov     x1, x20                                    
02ceee4c: str     x20, [x0, #0x20]!                          
02ceee50: bl      #0x2b70d54                                 fn_2b70d54
02ceee54: mov     x0, x19                                    
02ceee58: mov     x1, x22                                    
02ceee5c: mov     x2, xzr                                    
02ceee60: ldp     x20, x19, [sp, #0x20]                      
02ceee64: ldp     x22, x21, [sp, #0x10]                      
02ceee68: ldr     x30, [sp], #0x30                           
02ceee6c: b       #0x5b04734                                 UnityEngine.Renderer::set_materials
02ceee70: bl      #0x2b7105c                                 fn_2b7105c
02ceee74: bl      #0x2b71064                                 fn_2b71064
02ceee78: bl      #0x2b71080                                 fn_2b71080
02ceee7c: mov     x1, xzr                                    
02ceee80: bl      #0x2b70f20                                 fn_2b70f20
## ChangeMesh(UnityEngine.SkinnedMeshRenderer rend, UnityEngine.Mesh mesh) -> void
---- FrameWorkUtility::ChangeMesh 0x2ceee84
02ceee84: cbz     x0, #0x2ceee90                             
02ceee88: mov     x2, xzr                                    
02ceee8c: b       #0x5b0c274                                 UnityEngine.SkinnedMeshRenderer::set_sharedMesh
02ceee90: str     x30, [sp, #-0x10]!                         
02ceee94: bl      #0x2b7105c                                 fn_2b7105c
## ChangeTextureProp(UnityEngine.Renderer renderer, UnityEngine.Texture tex) -> void
---- FrameWorkUtility::ChangeTextureProp 0x2ceee98
02ceee98: str     x30, [sp, #-0x30]!                         
02ceee9c: stp     x22, x21, [sp, #0x10]                      
02ceeea0: stp     x20, x19, [sp, #0x20]                      
02ceeea4: adrp    x21, #0x662f000                            
02ceeea8: adrp    x22, #0x6268000                            
02ceeeac: mov     x19, x1                                    
02ceeeb0: ldrb    w8, [x21, #0xe45]                          
02ceeeb4: ldr     x22, [x22, #0x520]                         T:UnityEngine.MaterialPropertyBlock
02ceeeb8: mov     x20, x0                                    
02ceeebc: tbnz    w8, #0, #0x2ceeee0                         
02ceeec0: adrp    x0, #0x6268000                             
02ceeec4: ldr     x0, [x0, #0x520]                           T:UnityEngine.MaterialPropertyBlock
02ceeec8: bl      #0x2b70db0                                 fn_2b70db0
02ceeecc: adrp    x0, #0x6268000                             
02ceeed0: ldr     x0, [x0, #0x528]                           S:'_MainTex'
02ceeed4: bl      #0x2b70db0                                 fn_2b70db0
02ceeed8: mov     w8, #1                                     
02ceeedc: strb    w8, [x21, #0xe45]                          
02ceeee0: ldr     x0, [x22]                                  S:'{0}/2'
02ceeee4: bl      #0x2b7104c                                 fn_2b7104c
02ceeee8: mov     x1, xzr                                    
02ceeeec: mov     x21, x0                                    
02ceeef0: bl      #0x5b01a80                                 UnityEngine.MaterialPropertyBlock::.ctor
02ceeef4: cbz     x20, #0x2ceef50                            
02ceeef8: adrp    x22, #0x6268000                            
02ceeefc: mov     x0, x20                                    
02ceef00: mov     x1, x21                                    
02ceef04: ldr     x22, [x22, #0x528]                         S:'_MainTex'
02ceef08: mov     x2, xzr                                    
02ceef0c: bl      #0x5b02d90                                 UnityEngine.Renderer::GetPropertyBlock
02ceef10: ldr     x0, [x22]                                  S:'{0}/2'
02ceef14: mov     x1, xzr                                    
02ceef18: bl      #0x5b01c0c                                 UnityEngine.Shader::PropertyToID
02ceef1c: cbz     x21, #0x2ceef50                            
02ceef20: mov     w1, w0                                     
02ceef24: mov     x0, x21                                    
02ceef28: mov     x2, x19                                    
02ceef2c: mov     x3, xzr                                    
02ceef30: bl      #0x5b01f40                                 UnityEngine.MaterialPropertyBlock::SetTexture
02ceef34: mov     x0, x20                                    
02ceef38: mov     x1, x21                                    
02ceef3c: mov     x2, xzr                                    
02ceef40: ldp     x20, x19, [sp, #0x20]                      
02ceef44: ldp     x22, x21, [sp, #0x10]                      
02ceef48: ldr     x30, [sp], #0x30                           
02ceef4c: b       #0x5b02d88                                 UnityEngine.Renderer::SetPropertyBlock
02ceef50: bl      #0x2b7105c                                 fn_2b7105c
## ChangeColorProp(UnityEngine.Renderer renderer, UnityEngine.Color color) -> void
---- FrameWorkUtility::ChangeColorProp 0x2ceef54
02ceef54: stp     d11, d10, [sp, #-0x40]!                    
02ceef58: stp     d9, d8, [sp, #0x10]                        
02ceef5c: stp     x30, x21, [sp, #0x20]                      
02ceef60: stp     x20, x19, [sp, #0x30]                      
02ceef64: fmov    s8, s3                                     
02ceef68: fmov    s9, s2                                     
02ceef6c: adrp    x20, #0x662f000                            
02ceef70: fmov    s10, s1                                    
02ceef74: fmov    s11, s0                                    
02ceef78: adrp    x21, #0x6268000                            
02ceef7c: ldrb    w8, [x20, #0xe46]                          
02ceef80: ldr     x21, [x21, #0x520]                         T:UnityEngine.MaterialPropertyBlock
02ceef84: mov     x19, x0                                    
02ceef88: tbnz    w8, #0, #0x2ceefac                         
02ceef8c: adrp    x0, #0x6268000                             
02ceef90: ldr     x0, [x0, #0x520]                           T:UnityEngine.MaterialPropertyBlock
02ceef94: bl      #0x2b70db0                                 fn_2b70db0
02ceef98: adrp    x0, #0x6268000                             
02ceef9c: ldr     x0, [x0, #0x530]                           S:'_Color'
02ceefa0: bl      #0x2b70db0                                 fn_2b70db0
02ceefa4: mov     w8, #1                                     
02ceefa8: strb    w8, [x20, #0xe46]                          
02ceefac: ldr     x0, [x21]                                  S:'{0}/2'
02ceefb0: bl      #0x2b7104c                                 fn_2b7104c
02ceefb4: mov     x1, xzr                                    
02ceefb8: mov     x20, x0                                    
02ceefbc: bl      #0x5b01a80                                 UnityEngine.MaterialPropertyBlock::.ctor
02ceefc0: cbz     x19, #0x2cef02c                            
02ceefc4: adrp    x21, #0x6268000                            
02ceefc8: mov     x0, x19                                    
02ceefcc: mov     x1, x20                                    
02ceefd0: ldr     x21, [x21, #0x530]                         S:'_Color'
02ceefd4: mov     x2, xzr                                    
02ceefd8: bl      #0x5b02d90                                 UnityEngine.Renderer::GetPropertyBlock
02ceefdc: ldr     x0, [x21]                                  S:'{0}/2'
02ceefe0: mov     x1, xzr                                    
02ceefe4: bl      #0x5b01c0c                                 UnityEngine.Shader::PropertyToID
02ceefe8: cbz     x20, #0x2cef02c                            
02ceefec: fmov    s0, s11                                    
02ceeff0: fmov    s1, s10                                    
02ceeff4: mov     w1, w0                                     
02ceeff8: fmov    s2, s9                                     
02ceeffc: fmov    s3, s8                                     
02cef000: mov     x0, x20                                    
02cef004: mov     x2, xzr                                    
02cef008: bl      #0x5b01e60                                 UnityEngine.MaterialPropertyBlock::SetColor
02cef00c: mov     x0, x19                                    
02cef010: mov     x1, x20                                    
02cef014: mov     x2, xzr                                    
02cef018: ldp     x20, x19, [sp, #0x30]                      
02cef01c: ldp     x30, x21, [sp, #0x20]                      
02cef020: ldp     d9, d8, [sp, #0x10]                        
02cef024: ldp     d11, d10, [sp], #0x40                      
02cef028: b       #0x5b02d88                                 UnityEngine.Renderer::SetPropertyBlock
02cef02c: bl      #0x2b7105c                                 fn_2b7105c
## SetColor(UnityEngine.Renderer renderer, UnityEngine.Color color) -> void
---- FrameWorkUtility::SetColor 0x2cef030
02cef030: stp     d11, d10, [sp, #-0x40]!                    
02cef034: stp     d9, d8, [sp, #0x10]                        
02cef038: stp     x30, x21, [sp, #0x20]                      
02cef03c: stp     x20, x19, [sp, #0x30]                      
02cef040: fmov    s8, s3                                     
02cef044: fmov    s9, s2                                     
02cef048: adrp    x20, #0x662f000                            
02cef04c: fmov    s10, s1                                    
02cef050: fmov    s11, s0                                    
02cef054: adrp    x21, #0x6268000                            
02cef058: ldrb    w8, [x20, #0xe47]                          
02cef05c: ldr     x21, [x21, #0x520]                         T:UnityEngine.MaterialPropertyBlock
02cef060: mov     x19, x0                                    
02cef064: tbnz    w8, #0, #0x2cef088                         
02cef068: adrp    x0, #0x6268000                             
02cef06c: ldr     x0, [x0, #0x520]                           T:UnityEngine.MaterialPropertyBlock
02cef070: bl      #0x2b70db0                                 fn_2b70db0
02cef074: adrp    x0, #0x6268000                             
02cef078: ldr     x0, [x0, #0x530]                           S:'_Color'
02cef07c: bl      #0x2b70db0                                 fn_2b70db0
02cef080: mov     w8, #1                                     
02cef084: strb    w8, [x20, #0xe47]                          
02cef088: ldr     x0, [x21]                                  S:'{0}/2'
02cef08c: bl      #0x2b7104c                                 fn_2b7104c
02cef090: mov     x1, xzr                                    
02cef094: mov     x20, x0                                    
02cef098: bl      #0x5b01a80                                 UnityEngine.MaterialPropertyBlock::.ctor
02cef09c: cbz     x19, #0x2cef0fc                            
02cef0a0: mov     x0, x19                                    
02cef0a4: mov     x1, x20                                    
02cef0a8: mov     x2, xzr                                    
02cef0ac: bl      #0x5b02d90                                 UnityEngine.Renderer::GetPropertyBlock
02cef0b0: cbz     x20, #0x2cef0fc                            
02cef0b4: adrp    x8, #0x6268000                             
02cef0b8: fmov    s0, s11                                    
02cef0bc: fmov    s1, s10                                    
02cef0c0: ldr     x8, [x8, #0x530]                           S:'_Color'
02cef0c4: fmov    s2, s9                                     
02cef0c8: fmov    s3, s8                                     
02cef0cc: mov     x0, x20                                    
02cef0d0: mov     x2, xzr                                    
02cef0d4: ldr     x1, [x8]                                   S:'{0}/2'
02cef0d8: bl      #0x5b01e10                                 UnityEngine.MaterialPropertyBlock::SetColor
02cef0dc: mov     x0, x19                                    
02cef0e0: mov     x1, x20                                    
02cef0e4: mov     x2, xzr                                    
02cef0e8: ldp     x20, x19, [sp, #0x30]                      
02cef0ec: ldp     x30, x21, [sp, #0x20]                      
02cef0f0: ldp     d9, d8, [sp, #0x10]                        
02cef0f4: ldp     d11, d10, [sp], #0x40                      
02cef0f8: b       #0x5b02d88                                 UnityEngine.Renderer::SetPropertyBlock
02cef0fc: bl      #0x2b7105c                                 fn_2b7105c
## LerpColor(UnityEngine.MonoBehaviour self, UnityEngine.Renderer renderer, UnityEngine.Color color1, UnityEngine.Color color2, float duration, System.Action OnCompleted) -> void
---- FrameWorkUtility::LerpColor 0x2cef100
02cef100: sub     sp, sp, #0x20                              
02cef104: stp     x30, x19, [sp, #0x10]                      
02cef108: ldr     s16, [sp, #0x20]                           
02cef10c: mov     x19, x0                                    
02cef110: mov     x0, x1                                     
02cef114: mov     x1, x2                                     
02cef118: str     s16, [sp]                                  
02cef11c: bl      #0x2cef140                                 FrameWorkUtility::I_SetColor
02cef120: cbz     x19, #0x2cef13c                            
02cef124: mov     x1, x0                                     
02cef128: mov     x0, x19                                    
02cef12c: mov     x2, xzr                                    
02cef130: ldp     x30, x19, [sp, #0x10]                      
02cef134: add     sp, sp, #0x20                              
02cef138: b       #0x5b389f0                                 UnityEngine.MonoBehaviour::StartCoroutine
02cef13c: bl      #0x2b7105c                                 fn_2b7105c
## I_SetColor(UnityEngine.Renderer renderer, UnityEngine.Color color1, UnityEngine.Color color2, float duration, System.Action OnCompleted) -> System.Collections.IEnumerator
---- FrameWorkUtility::I_SetColor 0x2cef140
02cef140: stp     d15, d14, [sp, #-0x70]!                    
02cef144: stp     d13, d12, [sp, #0x10]                      
02cef148: stp     d11, d10, [sp, #0x20]                      
02cef14c: stp     d9, d8, [sp, #0x30]                        
02cef150: str     x30, [sp, #0x40]                           
02cef154: stp     x22, x21, [sp, #0x50]                      
02cef158: stp     x20, x19, [sp, #0x60]                      
02cef15c: fmov    s9, s6                                     
02cef160: fmov    s10, s5                                    
02cef164: str     s7, [sp, #0x4c]                            
02cef168: fmov    s12, s4                                    
02cef16c: fmov    s13, s3                                    
02cef170: adrp    x21, #0x662f000                            
02cef174: fmov    s14, s2                                    
02cef178: fmov    s15, s1                                    
02cef17c: adrp    x22, #0x6268000                            
02cef180: fmov    s11, s0                                    
02cef184: ldrb    w8, [x21, #0xe48]                          
02cef188: ldr     s8, [sp, #0x70]                            
02cef18c: ldr     x22, [x22, #0x538]                         T:FrameWorkUtility/<I_SetColor>d__11
02cef190: mov     x19, x1                                    
02cef194: mov     x20, x0                                    
02cef198: tbnz    w8, #0, #0x2cef1b0                         
02cef19c: adrp    x0, #0x6268000                             
02cef1a0: ldr     x0, [x0, #0x538]                           T:FrameWorkUtility/<I_SetColor>d__11
02cef1a4: bl      #0x2b70db0                                 fn_2b70db0
02cef1a8: mov     w8, #1                                     
02cef1ac: strb    w8, [x21, #0xe48]                          
02cef1b0: ldr     x0, [x22]                                  S:'{0}/2'
02cef1b4: bl      #0x2b7104c                                 fn_2b7104c
02cef1b8: mov     x1, xzr                                    
02cef1bc: mov     x21, x0                                    
02cef1c0: bl      #0x4e53e9c                                 System.Object::.ctor
02cef1c4: mov     x0, x21                                    
02cef1c8: mov     x1, x20                                    
02cef1cc: str     wzr, [x21, #0x10]                          
02cef1d0: str     x20, [x0, #0x20]!                          
02cef1d4: bl      #0x2b70d54                                 fn_2b70d54
02cef1d8: ldr     s0, [sp, #0x4c]                            
02cef1dc: mov     x0, x21                                    
02cef1e0: mov     x1, x19                                    
02cef1e4: stp     s15, s14, [x21, #0x30]                     
02cef1e8: stp     s13, s12, [x21, #0x38]                     
02cef1ec: stp     s10, s9, [x21, #0x40]                      
02cef1f0: str     s0, [x21, #0x48]                           
02cef1f4: stp     s8, s11, [x21, #0x28]                      
02cef1f8: str     x19, [x0, #0x50]!                          
02cef1fc: bl      #0x2b70d54                                 fn_2b70d54
02cef200: mov     x0, x21                                    
02cef204: ldp     x20, x19, [sp, #0x60]                      
02cef208: ldp     x22, x21, [sp, #0x50]                      
02cef20c: ldr     x30, [sp, #0x40]                           
02cef210: ldp     d9, d8, [sp, #0x30]                        
02cef214: ldp     d11, d10, [sp, #0x20]                      
02cef218: ldp     d13, d12, [sp, #0x10]                      
02cef21c: ldp     d15, d14, [sp], #0x70                      
02cef220: ret                                                
## DateTimeToUnix(System.DateTime MyDateTime) -> long
---- FrameWorkUtility::DateTimeToUnix 0x2cef24c
02cef24c: sub     sp, sp, #0x30                              
02cef250: stp     x30, x21, [sp, #0x10]                      
02cef254: stp     x20, x19, [sp, #0x20]                      
02cef258: adrp    x20, #0x662f000                            
02cef25c: adrp    x21, #0x6266000                            
02cef260: mov     x19, x0                                    
02cef264: ldrb    w8, [x20, #0xe49]                          
02cef268: ldr     x21, [x21, #0x128]                         T:System.DateTime
02cef26c: tbnz    w8, #0, #0x2cef290                         
02cef270: adrp    x0, #0x6266000                             
02cef274: ldr     x0, [x0, #0x128]                           T:System.DateTime
02cef278: bl      #0x2b70db0                                 fn_2b70db0
02cef27c: adrp    x0, #0x6265000                             
02cef280: ldr     x0, [x0, #0xf98]                           T:System.TimeSpan
02cef284: bl      #0x2b70db0                                 fn_2b70db0
02cef288: mov     w8, #1                                     
02cef28c: strb    w8, [x20, #0xe49]                          
02cef290: adrp    x20, #0x6265000                            
02cef294: mov     x0, sp                                     
02cef298: mov     w1, #0x7b2                                 
02cef29c: ldr     x20, [x20, #0xf98]                         T:System.TimeSpan
02cef2a0: mov     w2, #1                                     
02cef2a4: mov     w3, #1                                     
02cef2a8: mov     w4, wzr                                    
02cef2ac: mov     w5, wzr                                    
02cef2b0: mov     w6, wzr                                    
02cef2b4: mov     x7, xzr                                    
02cef2b8: stp     xzr, xzr, [sp]                             
02cef2bc: bl      #0x4df011c                                 System.DateTime::.ctor
02cef2c0: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cef2c4: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02cef2c8: cbnz    w8, #0x2cef2d0                             
02cef2cc: bl      #0x2b70f30                                 fn_2b70f30
02cef2d0: ldr     x1, [sp]                                   
02cef2d4: mov     x0, x19                                    
02cef2d8: mov     x2, xzr                                    
02cef2dc: bl      #0x4df3fb4                                 System.DateTime::op_Subtraction
02cef2e0: ldr     x8, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02cef2e4: str     x0, [sp, #8]                               
02cef2e8: ldr     w9, [x8, #0xe4]                            
02cef2ec: cbnz    w9, #0x2cef2f8                             
02cef2f0: mov     x0, x8                                     
02cef2f4: bl      #0x2b70f30                                 fn_2b70f30
02cef2f8: add     x0, sp, #8                                 
02cef2fc: mov     x1, xzr                                    
02cef300: bl      #0x4e2943c                                 System.TimeSpan::get_TotalSeconds
02cef304: mov     x8, #0x7ff0000000000000                    
02cef308: fcvtzs  x9, d0                                     
02cef30c: fmov    d1, x8                                     
02cef310: ldp     x20, x19, [sp, #0x20]                      
02cef314: ldp     x30, x21, [sp, #0x10]                      
02cef318: mov     x8, #-0x8000000000000000                   
02cef31c: fcmp    d0, d1                                     
02cef320: csel    x0, x8, x9, eq                             
02cef324: add     sp, sp, #0x30                              
02cef328: ret                                                
## UnixTimeToDateTime(long unixtime) -> System.DateTime
---- FrameWorkUtility::UnixTimeToDateTime 0x2cef32c
02cef32c: sub     sp, sp, #0x40                              
02cef330: stp     x30, x21, [sp, #0x20]                      
02cef334: stp     x20, x19, [sp, #0x30]                      
02cef338: adrp    x21, #0x662f000                            
02cef33c: adrp    x20, #0x6266000                            
02cef340: mov     x19, x0                                    
02cef344: ldrb    w8, [x21, #0xe4a]                          
02cef348: ldr     x20, [x20, #0x128]                         T:System.DateTime
02cef34c: tbnz    w8, #0, #0x2cef364                         
02cef350: adrp    x0, #0x6266000                             
02cef354: ldr     x0, [x0, #0x128]                           T:System.DateTime
02cef358: bl      #0x2b70db0                                 fn_2b70db0
02cef35c: mov     w8, #1                                     
02cef360: strb    w8, [x21, #0xe4a]                          
02cef364: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cef368: stp     xzr, xzr, [sp, #0x10]                      
02cef36c: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02cef370: cbnz    w8, #0x2cef378                             
02cef374: bl      #0x2b70f30                                 fn_2b70f30
02cef378: mov     w4, wzr                                    
02cef37c: mov     w5, wzr                                    
02cef380: mov     w6, wzr                                    
02cef384: mov     w7, wzr                                    
02cef388: mov     w8, #1                                     
02cef38c: add     x0, sp, #0x18                              
02cef390: mov     w1, #0x7b2                                 
02cef394: mov     w2, #1                                     
02cef398: mov     w3, #1                                     
02cef39c: str     xzr, [sp, #8]                              
02cef3a0: str     w8, [sp]                                   
02cef3a4: bl      #0x4df0580                                 System.DateTime::.ctor
02cef3a8: scvtf   d0, x19                                    
02cef3ac: add     x0, sp, #0x18                              
02cef3b0: mov     x1, xzr                                    
02cef3b4: bl      #0x4df15f0                                 System.DateTime::AddSeconds
02cef3b8: str     x0, [sp, #0x10]                            
02cef3bc: add     x0, sp, #0x10                              
02cef3c0: mov     x1, xzr                                    
02cef3c4: bl      #0x4df3250                                 System.DateTime::ToLocalTime
02cef3c8: ldp     x20, x19, [sp, #0x30]                      
02cef3cc: ldp     x30, x21, [sp, #0x20]                      
02cef3d0: add     sp, sp, #0x40                              
02cef3d4: ret                                                
## GetTimeSpan(System.DateTime to, System.DateTime from) -> System.TimeSpan
---- FrameWorkUtility::GetTimeSpan 0x2cef3d8
02cef3d8: sub     sp, sp, #0x40                              
02cef3dc: stp     x30, x0, [sp, #0x20]                       
02cef3e0: stp     x20, x19, [sp, #0x30]                      
02cef3e4: adrp    x19, #0x662f000                            
02cef3e8: adrp    x20, #0x6266000                            
02cef3ec: ldrb    w8, [x19, #0xe4b]                          
02cef3f0: ldr     x20, [x20, #0x128]                         T:System.DateTime
02cef3f4: str     x1, [sp, #0x18]                            
02cef3f8: tbnz    w8, #0, #0x2cef410                         
02cef3fc: adrp    x0, #0x6266000                             
02cef400: ldr     x0, [x0, #0x128]                           T:System.DateTime
02cef404: bl      #0x2b70db0                                 fn_2b70db0
02cef408: mov     w8, #1                                     
02cef40c: strb    w8, [x19, #0xe4b]                          
02cef410: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cef414: str     xzr, [sp, #0x10]                           
02cef418: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02cef41c: cbnz    w8, #0x2cef424                             
02cef420: bl      #0x2b70f30                                 fn_2b70f30
02cef424: add     x0, sp, #0x28                              
02cef428: mov     x1, xzr                                    
02cef42c: bl      #0x4df28bc                                 System.DateTime::get_Year
02cef430: mov     w19, w0                                    
02cef434: add     x0, sp, #0x28                              
02cef438: mov     x1, xzr                                    
02cef43c: bl      #0x4df2570                                 System.DateTime::get_Month
02cef440: mov     w20, w0                                    
02cef444: add     x0, sp, #0x28                              
02cef448: mov     x1, xzr                                    
02cef44c: bl      #0x4df21c4                                 System.DateTime::get_Day
02cef450: mov     w3, w0                                     
02cef454: add     x0, sp, #8                                 
02cef458: mov     w1, w19                                    
02cef45c: mov     w2, w20                                    
02cef460: mov     x4, xzr                                    
02cef464: str     xzr, [sp, #8]                              
02cef468: bl      #0x4defef8                                 System.DateTime::.ctor
02cef46c: add     x0, sp, #0x18                              
02cef470: mov     x1, xzr                                    
02cef474: bl      #0x4df28bc                                 System.DateTime::get_Year
02cef478: mov     w19, w0                                    
02cef47c: add     x0, sp, #0x18                              
02cef480: mov     x1, xzr                                    
02cef484: bl      #0x4df2570                                 System.DateTime::get_Month
02cef488: mov     w20, w0                                    
02cef48c: add     x0, sp, #0x18                              
02cef490: mov     x1, xzr                                    
02cef494: bl      #0x4df21c4                                 System.DateTime::get_Day
02cef498: mov     w3, w0                                     
02cef49c: add     x0, sp, #0x10                              
02cef4a0: mov     w1, w19                                    
02cef4a4: mov     w2, w20                                    
02cef4a8: mov     x4, xzr                                    
02cef4ac: bl      #0x4defef8                                 System.DateTime::.ctor
02cef4b0: ldp     x0, x1, [sp, #8]                           
02cef4b4: mov     x2, xzr                                    
02cef4b8: bl      #0x4df3fb4                                 System.DateTime::op_Subtraction
02cef4bc: ldp     x20, x19, [sp, #0x30]                      
02cef4c0: ldr     x30, [sp, #0x20]                           
02cef4c4: add     sp, sp, #0x40                              
02cef4c8: ret                                                
## ToString(long num) -> string
---- FrameWorkUtility::ToString 0x2cef4cc
02cef4cc: str     x30, [sp, #-0x20]!                         
02cef4d0: stp     x20, x19, [sp, #0x10]                      
02cef4d4: adrp    x20, #0x662f000                            
02cef4d8: mov     x19, x0                                    
02cef4dc: str     x0, [sp, #8]                               
02cef4e0: ldrb    w8, [x20, #0xe4c]                          
02cef4e4: tbnz    w8, #0, #0x2cef520                         
02cef4e8: adrp    x0, #0x6264000                             
02cef4ec: ldr     x0, [x0, #0x6a8]                           T:System.Globalization.CultureInfo
02cef4f0: bl      #0x2b70db0                                 fn_2b70db0
02cef4f4: adrp    x0, #0x6268000                             
02cef4f8: ldr     x0, [x0, #0x540]                           S:'0,,#00'
02cef4fc: bl      #0x2b70db0                                 fn_2b70db0
02cef500: adrp    x0, #0x6268000                             
02cef504: ldr     x0, [x0, #0x548]                           S:'0,,,.#B'
02cef508: bl      #0x2b70db0                                 fn_2b70db0
02cef50c: adrp    x0, #0x6268000                             
02cef510: ldr     x0, [x0, #0x550]                           S:'0,,.#M'
02cef514: bl      #0x2b70db0                                 fn_2b70db0
02cef518: mov     w8, #1                                     
02cef51c: strb    w8, [x20, #0xe4c]                          
02cef520: mov     w8, #0xc9ff                                
02cef524: mov     w10, #0x93ff                               
02cef528: movk    w8, #0x3b9a, lsl #16                       
02cef52c: movk    w10, #0x7735, lsl #16                      
02cef530: add     x9, x19, x8                                
02cef534: adrp    x8, #0x6264000                             
02cef538: ldr     x8, [x8, #0x6a8]                           T:System.Globalization.CultureInfo
02cef53c: cmp     x9, x10                                    
02cef540: b.hs    #0x2cef5a0                                 
02cef544: mov     w9, #0x423f                                
02cef548: mov     w11, #0x847f                               
02cef54c: movk    w9, #0xf, lsl #16                          
02cef550: movk    w11, #0x1e, lsl #16                        
02cef554: add     x10, x19, x9                               
02cef558: cmp     x10, x11                                   
02cef55c: b.hs    #0x2cef5f4                                 
02cef560: mov     w9, #0x2710                                
02cef564: mov     w10, #0x4e21                               
02cef568: add     x9, x19, x9                                
02cef56c: cmp     x9, x10                                    
02cef570: b.hs    #0x2cef63c                                 
02cef574: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cef578: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cef57c: cbnz    w8, #0x2cef584                             
02cef580: bl      #0x2b70f30                                 fn_2b70f30
02cef584: mov     x0, xzr                                    
02cef588: bl      #0x4d9ea74                                 System.Globalization.CultureInfo::get_InvariantCulture
02cef58c: mov     x1, x0                                     
02cef590: add     x0, sp, #8                                 
02cef594: mov     x2, xzr                                    
02cef598: bl      #0x4e0fe90                                 System.Int64::ToString
02cef59c: b       #0x2cef694                                 
02cef5a0: mov     x9, #0x94b3                                
02cef5a4: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cef5a8: movk    x9, #0x26d6, lsl #16                       
02cef5ac: movk    x9, #0xbe8, lsl #32                        
02cef5b0: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cef5b4: movk    x9, #0x112e, lsl #48                       
02cef5b8: smulh   x9, x19, x9                                
02cef5bc: adrp    x19, #0x6268000                            
02cef5c0: ldr     x19, [x19, #0x548]                         S:'0,,,.#B'
02cef5c4: asr     x10, x9, #0x1a                             
02cef5c8: add     x9, x10, x9, lsr #63                       
02cef5cc: mov     w10, #0xca00                               
02cef5d0: movk    w10, #0x3b9a, lsl #16                      
02cef5d4: mul     x9, x9, x10                                
02cef5d8: str     x9, [sp, #8]                               
02cef5dc: cbnz    w8, #0x2cef5e4                             
02cef5e0: bl      #0x2b70f30                                 fn_2b70f30
02cef5e4: mov     x0, xzr                                    
02cef5e8: bl      #0x4d9ea74                                 System.Globalization.CultureInfo::get_InvariantCulture
02cef5ec: ldr     x1, [x19]                                  S:'{0}/2'
02cef5f0: b       #0x2cef684                                 
02cef5f4: mov     w10, #0xde83                               
02cef5f8: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cef5fc: movk    w10, #0x431b, lsl #16                      
02cef600: smull   x10, w19, w10                              
02cef604: lsr     x11, x10, #0x3f                            
02cef608: asr     x10, x10, #0x32                            
02cef60c: add     w10, w10, w11                              
02cef610: sxtw    x8, w10                                    
02cef614: smaddl  x8, w9, w10, x8                            
02cef618: ldr     w9, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cef61c: str     x8, [sp, #8]                               
02cef620: cbnz    w9, #0x2cef628                             
02cef624: bl      #0x2b70f30                                 fn_2b70f30
02cef628: mov     x0, xzr                                    
02cef62c: bl      #0x4d9ea74                                 System.Globalization.CultureInfo::get_InvariantCulture
02cef630: adrp    x8, #0x6268000                             
02cef634: ldr     x8, [x8, #0x550]                           S:'0,,.#M'
02cef638: b       #0x2cef680                                 
02cef63c: mov     w9, #0x4dd3                                
02cef640: ldr     x0, [x8]                                   S:'{0}/2'
02cef644: movk    w9, #0x1062, lsl #16                       
02cef648: smull   x9, w19, w9                                
02cef64c: lsr     x10, x9, #0x3f                             
02cef650: asr     x9, x9, #0x26                              
02cef654: add     w9, w9, w10                                
02cef658: mov     w10, #0x3e8                                
02cef65c: smull   x8, w9, w10                                
02cef660: ldr     w9, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cef664: str     x8, [sp, #8]                               
02cef668: cbnz    w9, #0x2cef670                             
02cef66c: bl      #0x2b70f30                                 fn_2b70f30
02cef670: mov     x0, xzr                                    
02cef674: bl      #0x4d9ea74                                 System.Globalization.CultureInfo::get_InvariantCulture
02cef678: adrp    x8, #0x6268000                             
02cef67c: ldr     x8, [x8, #0x540]                           S:'0,,#00'
02cef680: ldr     x1, [x8]                                   S:'{0}/2'
02cef684: mov     x2, x0                                     
02cef688: add     x0, sp, #8                                 
02cef68c: mov     x3, xzr                                    
02cef690: bl      #0x4e0ffd8                                 System.Int64::ToString
02cef694: ldp     x20, x19, [sp, #0x10]                      
02cef698: ldr     x30, [sp], #0x20                           
02cef69c: ret                                                
## ToPercent(float num, int digit) -> string
---- FrameWorkUtility::ToPercent 0x2cef6a0
02cef6a0: str     x30, [sp, #-0x20]!                         
02cef6a4: stp     x20, x19, [sp, #0x10]                      
02cef6a8: adrp    x20, #0x662f000                            
02cef6ac: str     s0, [sp, #0xc]                             
02cef6b0: adrp    x19, #0x6268000                            
02cef6b4: ldrb    w8, [x20, #0xe4d]                          
02cef6b8: ldr     x19, [x19, #0x558]                         S:'P'
02cef6bc: str     w0, [sp, #8]                               
02cef6c0: tbnz    w8, #0, #0x2cef6e4                         
02cef6c4: adrp    x0, #0x6265000                             
02cef6c8: ldr     x0, [x0, #0x260]                           S:' '
02cef6cc: bl      #0x2b70db0                                 fn_2b70db0
02cef6d0: adrp    x0, #0x6268000                             
02cef6d4: ldr     x0, [x0, #0x558]                           S:'P'
02cef6d8: bl      #0x2b70db0                                 fn_2b70db0
02cef6dc: mov     w8, #1                                     
02cef6e0: strb    w8, [x20, #0xe4d]                          
02cef6e4: add     x0, sp, #8                                 
02cef6e8: mov     x1, xzr                                    
02cef6ec: bl      #0x4e0ea3c                                 System.Int32::ToString
02cef6f0: ldr     x8, [x19]                                  S:'{0}/2'
02cef6f4: mov     x1, x0                                     
02cef6f8: mov     x2, xzr                                    
02cef6fc: mov     x0, x8                                     
02cef700: bl      #0x4c9c514                                 System.String::Concat
02cef704: mov     x1, x0                                     
02cef708: add     x0, sp, #0xc                               
02cef70c: mov     x2, xzr                                    
02cef710: bl      #0x4e247e0                                 System.Single::ToString
02cef714: cbz     x0, #0x2cef74c                             
02cef718: adrp    x8, #0x6263000                             
02cef71c: adrp    x9, #0x6265000                             
02cef720: mov     x3, xzr                                    
02cef724: ldr     x8, [x8, #0x970]                           &6645c70(=0)
02cef728: ldr     x8, [x8, #0x90]                            &2c5beb4(=14c8d222d503245f)
02cef72c: ldr     x9, [x9, #0x260]                           S:' '
02cef730: ldr     x8, [x8, #0xb8]                            &6263108(=0)
02cef734: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02cef738: ldr     x2, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02cef73c: bl      #0x4ca8ca8                                 System.String::Replace
02cef740: ldp     x20, x19, [sp, #0x10]                      
02cef744: ldr     x30, [sp], #0x20                           
02cef748: ret                                                
02cef74c: bl      #0x2b7105c                                 fn_2b7105c
##  ParseEnum (no body)
##  ToEnum (no body)
## IntToBinaryString(int input, int stringLength) -> string
---- FrameWorkUtility::IntToBinaryString 0x2cef750
02cef750: str     x30, [sp, #-0x30]!                         
02cef754: stp     x22, x21, [sp, #0x10]                      
02cef758: stp     x20, x19, [sp, #0x20]                      
02cef75c: adrp    x21, #0x662f000                            
02cef760: adrp    x22, #0x6263000                            
02cef764: mov     w19, w1                                    
02cef768: ldrb    w8, [x21, #0xe4e]                          
02cef76c: ldr     x22, [x22, #0x9d8]                         T:System.Convert
02cef770: mov     w20, w0                                    
02cef774: tbnz    w8, #0, #0x2cef78c                         
02cef778: adrp    x0, #0x6263000                             
02cef77c: ldr     x0, [x0, #0x9d8]                           T:System.Convert
02cef780: bl      #0x2b70db0                                 fn_2b70db0
02cef784: mov     w8, #1                                     
02cef788: strb    w8, [x21, #0xe4e]                          
02cef78c: ldr     x0, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cef790: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02cef794: cbnz    w8, #0x2cef79c                             
02cef798: bl      #0x2b70f30                                 fn_2b70f30
02cef79c: mov     w0, w20                                    
02cef7a0: mov     w1, #2                                     
02cef7a4: mov     x2, xzr                                    
02cef7a8: bl      #0x4d9bfbc                                 System.Convert::ToString
02cef7ac: cbz     x0, #0x2cef7cc                             
02cef7b0: mov     w1, w19                                    
02cef7b4: ldp     x20, x19, [sp, #0x20]                      
02cef7b8: ldp     x22, x21, [sp, #0x10]                      
02cef7bc: mov     w2, #0x30                                  
02cef7c0: mov     x3, xzr                                    
02cef7c4: ldr     x30, [sp], #0x30                           
02cef7c8: b       #0x4ca8428                                 System.String::PadLeft
02cef7cc: bl      #0x2b7105c                                 fn_2b7105c
## OnEndOfFrame(UnityEngine.MonoBehaviour self, UnityEngine.Events.UnityAction Callback) -> UnityEngine.Coroutine
---- FrameWorkUtility::OnEndOfFrame 0x2cef7d0
02cef7d0: stp     x30, x19, [sp, #-0x10]!                    
02cef7d4: mov     x19, x0                                    
02cef7d8: mov     x0, x1                                     
02cef7dc: bl      #0x2cef7fc                                 FrameWorkUtility::EndOfFrameCoroutine
02cef7e0: cbz     x19, #0x2cef7f8                            
02cef7e4: mov     x1, x0                                     
02cef7e8: mov     x0, x19                                    
02cef7ec: mov     x2, xzr                                    
02cef7f0: ldp     x30, x19, [sp], #0x10                      
02cef7f4: b       #0x5b389f0                                 UnityEngine.MonoBehaviour::StartCoroutine
02cef7f8: bl      #0x2b7105c                                 fn_2b7105c
## EndOfFrameCoroutine(UnityEngine.Events.UnityAction Callback) -> System.Collections.IEnumerator
---- FrameWorkUtility::EndOfFrameCoroutine 0x2cef7fc
02cef7fc: stp     x30, x21, [sp, #-0x20]!                    
02cef800: stp     x20, x19, [sp, #0x10]                      
02cef804: adrp    x20, #0x662f000                            
02cef808: adrp    x21, #0x6268000                            
02cef80c: mov     x19, x0                                    
02cef810: ldrb    w8, [x20, #0xe4f]                          
02cef814: ldr     x21, [x21, #0x560]                         T:FrameWorkUtility/<EndOfFrameCoroutine>d__21
02cef818: tbnz    w8, #0, #0x2cef830                         
02cef81c: adrp    x0, #0x6268000                             
02cef820: ldr     x0, [x0, #0x560]                           T:FrameWorkUtility/<EndOfFrameCoroutine>d__21
02cef824: bl      #0x2b70db0                                 fn_2b70db0
02cef828: mov     w8, #1                                     
02cef82c: strb    w8, [x20, #0xe4f]                          
02cef830: ldr     x0, [x21]                                  S:'{0}/2'
02cef834: bl      #0x2b7104c                                 fn_2b7104c
02cef838: mov     x1, xzr                                    
02cef83c: mov     x20, x0                                    
02cef840: bl      #0x4e53e9c                                 System.Object::.ctor
02cef844: mov     x0, x20                                    
02cef848: mov     x1, x19                                    
02cef84c: str     wzr, [x20, #0x10]                          
02cef850: str     x19, [x0, #0x20]!                          
02cef854: bl      #0x2b70d54                                 fn_2b70d54
02cef858: mov     x0, x20                                    
02cef85c: ldp     x20, x19, [sp, #0x10]                      
02cef860: ldp     x30, x21, [sp], #0x20                      
02cef864: ret                                                
## OnUpdate(UnityEngine.MonoBehaviour self, UnityEngine.Events.UnityAction Callback) -> UnityEngine.Coroutine
---- FrameWorkUtility::OnUpdate 0x2cef890
02cef890: mov     x2, x1                                     
02cef894: mov     w1, #1                                     
02cef898: b       #0x2cef89c                                 FrameWorkUtility::InUpdates
## InUpdates(UnityEngine.MonoBehaviour self, int updates, UnityEngine.Events.UnityAction Callback) -> UnityEngine.Coroutine
---- FrameWorkUtility::InUpdates 0x2cef89c
02cef89c: stp     x30, x19, [sp, #-0x10]!                    
02cef8a0: mov     x19, x0                                    
02cef8a4: mov     w0, w1                                     
02cef8a8: mov     x1, x2                                     
02cef8ac: bl      #0x2cef8cc                                 FrameWorkUtility::InUpdatesCoroutine
02cef8b0: cbz     x19, #0x2cef8c8                            
02cef8b4: mov     x1, x0                                     
02cef8b8: mov     x0, x19                                    
02cef8bc: mov     x2, xzr                                    
02cef8c0: ldp     x30, x19, [sp], #0x10                      
02cef8c4: b       #0x5b389f0                                 UnityEngine.MonoBehaviour::StartCoroutine
02cef8c8: bl      #0x2b7105c                                 fn_2b7105c
## InUpdatesCoroutine(int updates, UnityEngine.Events.UnityAction Callback) -> System.Collections.IEnumerator
---- FrameWorkUtility::InUpdatesCoroutine 0x2cef8cc
02cef8cc: str     x30, [sp, #-0x30]!                         
02cef8d0: stp     x22, x21, [sp, #0x10]                      
02cef8d4: stp     x20, x19, [sp, #0x20]                      
02cef8d8: adrp    x21, #0x662f000                            
02cef8dc: adrp    x22, #0x6268000                            
02cef8e0: mov     x19, x1                                    
02cef8e4: ldrb    w8, [x21, #0xe50]                          
02cef8e8: ldr     x22, [x22, #0x568]                         T:FrameWorkUtility/<InUpdatesCoroutine>d__24
02cef8ec: mov     w20, w0                                    
02cef8f0: tbnz    w8, #0, #0x2cef908                         
02cef8f4: adrp    x0, #0x6268000                             
02cef8f8: ldr     x0, [x0, #0x568]                           T:FrameWorkUtility/<InUpdatesCoroutine>d__24
02cef8fc: bl      #0x2b70db0                                 fn_2b70db0
02cef900: mov     w8, #1                                     
02cef904: strb    w8, [x21, #0xe50]                          
02cef908: ldr     x0, [x22]                                  S:'{0}/2'
02cef90c: bl      #0x2b7104c                                 fn_2b7104c
02cef910: mov     x1, xzr                                    
02cef914: mov     x21, x0                                    
02cef918: bl      #0x4e53e9c                                 System.Object::.ctor
02cef91c: mov     x0, x21                                    
02cef920: mov     x1, x19                                    
02cef924: str     wzr, [x21, #0x10]                          
02cef928: str     w20, [x21, #0x20]                          
02cef92c: str     x19, [x0, #0x28]!                          
02cef930: bl      #0x2b70d54                                 fn_2b70d54
02cef934: mov     x0, x21                                    
02cef938: ldp     x20, x19, [sp, #0x20]                      
02cef93c: ldp     x22, x21, [sp, #0x10]                      
02cef940: ldr     x30, [sp], #0x30                           
02cef944: ret                                                
## OnFixedUpdate(UnityEngine.MonoBehaviour self, UnityEngine.Events.UnityAction Callback) -> UnityEngine.Coroutine
---- FrameWorkUtility::OnFixedUpdate 0x2cef970
02cef970: mov     x2, x1                                     
02cef974: mov     w1, #1                                     
02cef978: b       #0x2cef97c                                 FrameWorkUtility::InFixedUpdates
## InFixedUpdates(UnityEngine.MonoBehaviour self, int ticks, UnityEngine.Events.UnityAction Callback) -> UnityEngine.Coroutine
---- FrameWorkUtility::InFixedUpdates 0x2cef97c
02cef97c: stp     x30, x19, [sp, #-0x10]!                    
02cef980: mov     x19, x0                                    
02cef984: mov     w0, w1                                     
02cef988: mov     x1, x2                                     
02cef98c: bl      #0x2cef9ac                                 FrameWorkUtility::InFixedUpdatesCoroutine
02cef990: cbz     x19, #0x2cef9a8                            
02cef994: mov     x1, x0                                     
02cef998: mov     x0, x19                                    
02cef99c: mov     x2, xzr                                    
02cef9a0: ldp     x30, x19, [sp], #0x10                      
02cef9a4: b       #0x5b389f0                                 UnityEngine.MonoBehaviour::StartCoroutine
02cef9a8: bl      #0x2b7105c                                 fn_2b7105c
## InFixedUpdatesCoroutine(int ticks, UnityEngine.Events.UnityAction Callback) -> System.Collections.IEnumerator
---- FrameWorkUtility::InFixedUpdatesCoroutine 0x2cef9ac
02cef9ac: str     x30, [sp, #-0x30]!                         
02cef9b0: stp     x22, x21, [sp, #0x10]                      
02cef9b4: stp     x20, x19, [sp, #0x20]                      
02cef9b8: adrp    x21, #0x662f000                            
02cef9bc: adrp    x22, #0x6268000                            
02cef9c0: mov     x19, x1                                    
02cef9c4: ldrb    w8, [x21, #0xe51]                          
02cef9c8: ldr     x22, [x22, #0x570]                         T:FrameWorkUtility/<InFixedUpdatesCoroutine>d__27
02cef9cc: mov     w20, w0                                    
02cef9d0: tbnz    w8, #0, #0x2cef9e8                         
02cef9d4: adrp    x0, #0x6268000                             
02cef9d8: ldr     x0, [x0, #0x570]                           T:FrameWorkUtility/<InFixedUpdatesCoroutine>d__27
02cef9dc: bl      #0x2b70db0                                 fn_2b70db0
02cef9e0: mov     w8, #1                                     
02cef9e4: strb    w8, [x21, #0xe51]                          
02cef9e8: ldr     x0, [x22]                                  S:'{0}/2'
02cef9ec: bl      #0x2b7104c                                 fn_2b7104c
02cef9f0: mov     x1, xzr                                    
02cef9f4: mov     x21, x0                                    
02cef9f8: bl      #0x4e53e9c                                 System.Object::.ctor
02cef9fc: mov     x0, x21                                    
02cefa00: mov     x1, x19                                    
02cefa04: str     wzr, [x21, #0x10]                          
02cefa08: str     w20, [x21, #0x20]                          
02cefa0c: str     x19, [x0, #0x28]!                          
02cefa10: bl      #0x2b70d54                                 fn_2b70d54
02cefa14: mov     x0, x21                                    
02cefa18: ldp     x20, x19, [sp, #0x20]                      
02cefa1c: ldp     x22, x21, [sp, #0x10]                      
02cefa20: ldr     x30, [sp], #0x30                           
02cefa24: ret                                                
## InSeconds(UnityEngine.MonoBehaviour self, float seconds, UnityEngine.Events.UnityAction Callback) -> UnityEngine.Coroutine
---- FrameWorkUtility::InSeconds 0x2cefa50
02cefa50: stp     x30, x19, [sp, #-0x10]!                    
02cefa54: mov     x19, x0                                    
02cefa58: mov     x0, x1                                     
02cefa5c: bl      #0x2cefa7c                                 FrameWorkUtility::InSecondsCoroutine
02cefa60: cbz     x19, #0x2cefa78                            
02cefa64: mov     x1, x0                                     
02cefa68: mov     x0, x19                                    
02cefa6c: mov     x2, xzr                                    
02cefa70: ldp     x30, x19, [sp], #0x10                      
02cefa74: b       #0x5b389f0                                 UnityEngine.MonoBehaviour::StartCoroutine
02cefa78: bl      #0x2b7105c                                 fn_2b7105c
## InSecondsCoroutine(float seconds, UnityEngine.Events.UnityAction Callback) -> System.Collections.IEnumerator
---- FrameWorkUtility::InSecondsCoroutine 0x2cefa7c
02cefa7c: str     d8, [sp, #-0x30]!                          
02cefa80: stp     x30, x21, [sp, #0x10]                      
02cefa84: stp     x20, x19, [sp, #0x20]                      
02cefa88: fmov    s8, s0                                     
02cefa8c: adrp    x20, #0x662f000                            
02cefa90: adrp    x21, #0x6268000                            
02cefa94: ldrb    w8, [x20, #0xe52]                          
02cefa98: ldr     x21, [x21, #0x578]                         T:FrameWorkUtility/<InSecondsCoroutine>d__29
02cefa9c: mov     x19, x0                                    
02cefaa0: tbnz    w8, #0, #0x2cefab8                         
02cefaa4: adrp    x0, #0x6268000                             
02cefaa8: ldr     x0, [x0, #0x578]                           T:FrameWorkUtility/<InSecondsCoroutine>d__29
02cefaac: bl      #0x2b70db0                                 fn_2b70db0
02cefab0: mov     w8, #1                                     
02cefab4: strb    w8, [x20, #0xe52]                          
02cefab8: ldr     x0, [x21]                                  S:'{0}/2'
02cefabc: bl      #0x2b7104c                                 fn_2b7104c
02cefac0: mov     x1, xzr                                    
02cefac4: mov     x20, x0                                    
02cefac8: bl      #0x4e53e9c                                 System.Object::.ctor
02cefacc: mov     x0, x20                                    
02cefad0: mov     x1, x19                                    
02cefad4: str     wzr, [x20, #0x10]                          
02cefad8: str     s8, [x20, #0x20]                           
02cefadc: str     x19, [x0, #0x28]!                          
02cefae0: bl      #0x2b70d54                                 fn_2b70d54
02cefae4: mov     x0, x20                                    
02cefae8: ldp     x20, x19, [sp, #0x20]                      
02cefaec: ldp     x30, x21, [sp, #0x10]                      
02cefaf0: ldr     d8, [sp], #0x30                            
02cefaf4: ret                                                
## InSecondsInterval(UnityEngine.MonoBehaviour self, float seconds, float interval, UnityEngine.Events.UnityAction Callback) -> UnityEngine.Coroutine
---- FrameWorkUtility::InSecondsInterval 0x2cefb20
02cefb20: stp     x30, x19, [sp, #-0x10]!                    
02cefb24: mov     x19, x0                                    
02cefb28: bl      #0x2cefb48                                 FrameWorkUtility::InSecondsIntervalCoroutine
02cefb2c: cbz     x19, #0x2cefb44                            
02cefb30: mov     x1, x0                                     
02cefb34: mov     x0, x19                                    
02cefb38: mov     x2, xzr                                    
02cefb3c: ldp     x30, x19, [sp], #0x10                      
02cefb40: b       #0x5b389f0                                 UnityEngine.MonoBehaviour::StartCoroutine
02cefb44: bl      #0x2b7105c                                 fn_2b7105c
## InSecondsIntervalCoroutine(UnityEngine.MonoBehaviour self, float seconds, float interval, UnityEngine.Events.UnityAction Callback) -> System.Collections.IEnumerator
---- FrameWorkUtility::InSecondsIntervalCoroutine 0x2cefb48
02cefb48: stp     d9, d8, [sp, #-0x40]!                      
02cefb4c: str     x30, [sp, #0x10]                           
02cefb50: stp     x22, x21, [sp, #0x20]                      
02cefb54: stp     x20, x19, [sp, #0x30]                      
02cefb58: fmov    s8, s1                                     
02cefb5c: fmov    s9, s0                                     
02cefb60: adrp    x21, #0x662f000                            
02cefb64: adrp    x22, #0x6268000                            
02cefb68: ldrb    w8, [x21, #0xe53]                          
02cefb6c: mov     x19, x1                                    
02cefb70: ldr     x22, [x22, #0x580]                         T:FrameWorkUtility/<InSecondsIntervalCoroutine>d__31
02cefb74: mov     x20, x0                                    
02cefb78: tbnz    w8, #0, #0x2cefb90                         
02cefb7c: adrp    x0, #0x6268000                             
02cefb80: ldr     x0, [x0, #0x580]                           T:FrameWorkUtility/<InSecondsIntervalCoroutine>d__31
02cefb84: bl      #0x2b70db0                                 fn_2b70db0
02cefb88: mov     w8, #1                                     
02cefb8c: strb    w8, [x21, #0xe53]                          
02cefb90: ldr     x0, [x22]                                  S:'{0}/2'
02cefb94: bl      #0x2b7104c                                 fn_2b7104c
02cefb98: mov     x1, xzr                                    
02cefb9c: mov     x21, x0                                    
02cefba0: bl      #0x4e53e9c                                 System.Object::.ctor
02cefba4: mov     x0, x21                                    
02cefba8: mov     x1, x20                                    
02cefbac: str     wzr, [x21, #0x10]                          
02cefbb0: str     x20, [x0, #0x30]!                          
02cefbb4: bl      #0x2b70d54                                 fn_2b70d54
02cefbb8: mov     x0, x21                                    
02cefbbc: mov     x1, x19                                    
02cefbc0: stp     s9, s8, [x21, #0x20]                       
02cefbc4: str     x19, [x0, #0x28]!                          
02cefbc8: bl      #0x2b70d54                                 fn_2b70d54
02cefbcc: mov     x0, x21                                    
02cefbd0: ldp     x20, x19, [sp, #0x30]                      
02cefbd4: ldp     x22, x21, [sp, #0x20]                      
02cefbd8: ldr     x30, [sp, #0x10]                           
02cefbdc: ldp     d9, d8, [sp], #0x40                        
02cefbe0: ret                                                
## DoTransform(UnityEngine.Transform tf, UnityEngine.Transform target, float duration, float delay, System.Action OnCompleted) -> void
---- FrameWorkUtility::DoTransform 0x2cefc0c
02cefc0c: stp     d9, d8, [sp, #-0x60]!                      
02cefc10: str     x30, [sp, #0x10]                           
02cefc14: stp     x26, x25, [sp, #0x20]                      
02cefc18: stp     x24, x23, [sp, #0x30]                      
02cefc1c: stp     x22, x21, [sp, #0x40]                      
02cefc20: stp     x20, x19, [sp, #0x50]                      
02cefc24: fmov    s8, s1                                     
02cefc28: fmov    s9, s0                                     
02cefc2c: adrp    x21, #0x662f000                            
02cefc30: adrp    x23, #0x6268000                            
02cefc34: ldrb    w8, [x21, #0xe54]                          
02cefc38: mov     x22, x2                                    
02cefc3c: ldr     x23, [x23, #0x588]                         T:FrameWorkUtility/<>c__DisplayClass32_0
02cefc40: mov     x20, x1                                    
02cefc44: mov     x19, x0                                    
02cefc48: tbnz    w8, #0, #0x2cefc9c                         
02cefc4c: adrp    x0, #0x6264000                             
02cefc50: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02cefc54: bl      #0x2b70db0                                 fn_2b70db0
02cefc58: adrp    x0, #0x6268000                             
02cefc5c: ldr     x0, [x0, #0x590]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02cefc60: bl      #0x2b70db0                                 fn_2b70db0
02cefc64: adrp    x0, #0x6268000                             
02cefc68: ldr     x0, [x0, #0x598]                           MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02cefc6c: bl      #0x2b70db0                                 fn_2b70db0
02cefc70: adrp    x0, #0x6266000                             
02cefc74: ldr     x0, [x0, #0xe08]                           MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02cefc78: bl      #0x2b70db0                                 fn_2b70db0
02cefc7c: adrp    x0, #0x6268000                             
02cefc80: ldr     x0, [x0, #0x5a0]                           M:FrameWorkUtility/<>c__DisplayClass32_0::<DoTransform>b__0
02cefc84: bl      #0x2b70db0                                 fn_2b70db0
02cefc88: adrp    x0, #0x6268000                             
02cefc8c: ldr     x0, [x0, #0x588]                           T:FrameWorkUtility/<>c__DisplayClass32_0
02cefc90: bl      #0x2b70db0                                 fn_2b70db0
02cefc94: mov     w8, #1                                     
02cefc98: strb    w8, [x21, #0xe54]                          
02cefc9c: ldr     x0, [x23]                                  S:'{0}/2'
02cefca0: bl      #0x2b7104c                                 fn_2b7104c
02cefca4: mov     x1, xzr                                    
02cefca8: mov     x21, x0                                    
02cefcac: bl      #0x4e53e9c                                 System.Object::.ctor
02cefcb0: cbz     x21, #0x2cefd90                            
02cefcb4: mov     x0, x21                                    
02cefcb8: mov     x1, x22                                    
02cefcbc: str     x22, [x0, #0x10]!                          
02cefcc0: bl      #0x2b70d54                                 fn_2b70d54
02cefcc4: cbz     x20, #0x2cefd90                            
02cefcc8: adrp    x25, #0x6266000                            
02cefccc: adrp    x26, #0x6268000                            
02cefcd0: adrp    x24, #0x6264000                            
02cefcd4: adrp    x23, #0x6268000                            
02cefcd8: adrp    x22, #0x6268000                            
02cefcdc: ldr     x25, [x25, #0xe08]                         MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02cefce0: ldr     x26, [x26, #0x598]                         MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02cefce4: ldr     x24, [x24, #0xe8]                          T:DG.Tweening.TweenCallback
02cefce8: ldr     x23, [x23, #0x5a0]                         M:FrameWorkUtility/<>c__DisplayClass32_0::<DoTransform>b__0
02cefcec: ldr     x22, [x22, #0x590]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02cefcf0: mov     x0, x20                                    
02cefcf4: mov     x1, xzr                                    
02cefcf8: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02cefcfc: fmov    s3, s9                                     
02cefd00: mov     x0, x19                                    
02cefd04: mov     w1, wzr                                    
02cefd08: mov     x2, xzr                                    
02cefd0c: bl      #0x2d975e4                                 DG.Tweening.ShortcutExtensions::DOMove
02cefd10: fmov    s0, s8                                     
02cefd14: ldr     x1, [x25]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cefd18: bl      #0x336f7fc                                 fn_336f7fc
02cefd1c: mov     x0, x20                                    
02cefd20: mov     x1, xzr                                    
02cefd24: bl      #0x5b46a30                                 UnityEngine.Transform::get_rotation
02cefd28: fmov    s4, s9                                     
02cefd2c: mov     x0, x19                                    
02cefd30: mov     x1, xzr                                    
02cefd34: bl      #0x2d9857c                                 DG.Tweening.ShortcutExtensions::DORotateQuaternion
02cefd38: fmov    s0, s8                                     
02cefd3c: ldr     x1, [x26]                                  S:'{0}/2'
02cefd40: bl      #0x336f7fc                                 fn_336f7fc
02cefd44: ldr     x8, [x24]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cefd48: mov     x19, x0                                    
02cefd4c: mov     x0, x8                                     
02cefd50: bl      #0x2b7104c                                 fn_2b7104c
02cefd54: ldr     x2, [x23]                                  S:'{0}/2'
02cefd58: mov     x1, x21                                    
02cefd5c: mov     x3, xzr                                    
02cefd60: mov     x20, x0                                    
02cefd64: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02cefd68: ldr     x2, [x22]                                  S:'{0}/2'
02cefd6c: mov     x0, x19                                    
02cefd70: mov     x1, x20                                    
02cefd74: ldp     x20, x19, [sp, #0x50]                      
02cefd78: ldr     x30, [sp, #0x10]                           
02cefd7c: ldp     x22, x21, [sp, #0x40]                      
02cefd80: ldp     x24, x23, [sp, #0x30]                      
02cefd84: ldp     x26, x25, [sp, #0x20]                      
02cefd88: ldp     d9, d8, [sp], #0x60                        
02cefd8c: b       #0x336f26c                                 
02cefd90: bl      #0x2b7105c                                 fn_2b7105c
## DoLocalTransform(UnityEngine.Transform tf, UnityEngine.Transform target, float duration, float delay, System.Action OnCompleted) -> void
---- FrameWorkUtility::DoLocalTransform 0x2cefd9c
02cefd9c: stp     d9, d8, [sp, #-0x60]!                      
02cefda0: str     x30, [sp, #0x10]                           
02cefda4: stp     x26, x25, [sp, #0x20]                      
02cefda8: stp     x24, x23, [sp, #0x30]                      
02cefdac: stp     x22, x21, [sp, #0x40]                      
02cefdb0: stp     x20, x19, [sp, #0x50]                      
02cefdb4: fmov    s8, s1                                     
02cefdb8: fmov    s9, s0                                     
02cefdbc: adrp    x21, #0x662f000                            
02cefdc0: adrp    x23, #0x6268000                            
02cefdc4: ldrb    w8, [x21, #0xe55]                          
02cefdc8: mov     x22, x2                                    
02cefdcc: ldr     x23, [x23, #0x5a8]                         T:FrameWorkUtility/<>c__DisplayClass33_0
02cefdd0: mov     x20, x1                                    
02cefdd4: mov     x19, x0                                    
02cefdd8: tbnz    w8, #0, #0x2cefe2c                         
02cefddc: adrp    x0, #0x6264000                             
02cefde0: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02cefde4: bl      #0x2b70db0                                 fn_2b70db0
02cefde8: adrp    x0, #0x6268000                             
02cefdec: ldr     x0, [x0, #0x590]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02cefdf0: bl      #0x2b70db0                                 fn_2b70db0
02cefdf4: adrp    x0, #0x6268000                             
02cefdf8: ldr     x0, [x0, #0x598]                           MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02cefdfc: bl      #0x2b70db0                                 fn_2b70db0
02cefe00: adrp    x0, #0x6266000                             
02cefe04: ldr     x0, [x0, #0xe08]                           MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02cefe08: bl      #0x2b70db0                                 fn_2b70db0
02cefe0c: adrp    x0, #0x6268000                             
02cefe10: ldr     x0, [x0, #0x5b0]                           M:FrameWorkUtility/<>c__DisplayClass33_0::<DoLocalTransform>b__0
02cefe14: bl      #0x2b70db0                                 fn_2b70db0
02cefe18: adrp    x0, #0x6268000                             
02cefe1c: ldr     x0, [x0, #0x5a8]                           T:FrameWorkUtility/<>c__DisplayClass33_0
02cefe20: bl      #0x2b70db0                                 fn_2b70db0
02cefe24: mov     w8, #1                                     
02cefe28: strb    w8, [x21, #0xe55]                          
02cefe2c: ldr     x0, [x23]                                  S:'{0}/2'
02cefe30: bl      #0x2b7104c                                 fn_2b7104c
02cefe34: mov     x1, xzr                                    
02cefe38: mov     x21, x0                                    
02cefe3c: bl      #0x4e53e9c                                 System.Object::.ctor
02cefe40: cbz     x21, #0x2ceff20                            
02cefe44: mov     x0, x21                                    
02cefe48: mov     x1, x22                                    
02cefe4c: str     x22, [x0, #0x10]!                          
02cefe50: bl      #0x2b70d54                                 fn_2b70d54
02cefe54: cbz     x20, #0x2ceff20                            
02cefe58: adrp    x25, #0x6266000                            
02cefe5c: adrp    x26, #0x6268000                            
02cefe60: adrp    x24, #0x6264000                            
02cefe64: adrp    x23, #0x6268000                            
02cefe68: adrp    x22, #0x6268000                            
02cefe6c: ldr     x25, [x25, #0xe08]                         MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02cefe70: ldr     x26, [x26, #0x598]                         MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02cefe74: ldr     x24, [x24, #0xe8]                          T:DG.Tweening.TweenCallback
02cefe78: ldr     x23, [x23, #0x5b0]                         M:FrameWorkUtility/<>c__DisplayClass33_0::<DoLocalTransform>b__0
02cefe7c: ldr     x22, [x22, #0x590]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02cefe80: mov     x0, x20                                    
02cefe84: mov     x1, xzr                                    
02cefe88: bl      #0x5b45c24                                 UnityEngine.Transform::get_localPosition
02cefe8c: fmov    s3, s9                                     
02cefe90: mov     x0, x19                                    
02cefe94: mov     w1, wzr                                    
02cefe98: mov     x2, xzr                                    
02cefe9c: bl      #0x2d97cf0                                 DG.Tweening.ShortcutExtensions::DOLocalMove
02cefea0: fmov    s0, s8                                     
02cefea4: ldr     x1, [x25]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cefea8: bl      #0x336f7fc                                 fn_336f7fc
02cefeac: mov     x0, x20                                    
02cefeb0: mov     x1, xzr                                    
02cefeb4: bl      #0x5b46bf4                                 UnityEngine.Transform::get_localRotation
02cefeb8: fmov    s4, s9                                     
02cefebc: mov     x0, x19                                    
02cefec0: mov     x1, xzr                                    
02cefec4: bl      #0x2d98914                                 DG.Tweening.ShortcutExtensions::DOLocalRotateQuaternion
02cefec8: fmov    s0, s8                                     
02cefecc: ldr     x1, [x26]                                  S:'{0}/2'
02cefed0: bl      #0x336f7fc                                 fn_336f7fc
02cefed4: ldr     x8, [x24]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cefed8: mov     x19, x0                                    
02cefedc: mov     x0, x8                                     
02cefee0: bl      #0x2b7104c                                 fn_2b7104c
02cefee4: ldr     x2, [x23]                                  S:'{0}/2'
02cefee8: mov     x1, x21                                    
02cefeec: mov     x3, xzr                                    
02cefef0: mov     x20, x0                                    
02cefef4: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02cefef8: ldr     x2, [x22]                                  S:'{0}/2'
02cefefc: mov     x0, x19                                    
02ceff00: mov     x1, x20                                    
02ceff04: ldp     x20, x19, [sp, #0x50]                      
02ceff08: ldr     x30, [sp, #0x10]                           
02ceff0c: ldp     x22, x21, [sp, #0x40]                      
02ceff10: ldp     x24, x23, [sp, #0x30]                      
02ceff14: ldp     x26, x25, [sp, #0x20]                      
02ceff18: ldp     d9, d8, [sp], #0x60                        
02ceff1c: b       #0x336f26c                                 
02ceff20: bl      #0x2b7105c                                 fn_2b7105c
## DOPunchScaleEff(UnityEngine.Transform target, float punch, DG.Tweening.Ease ease) -> void
---- FrameWorkUtility::DOPunchScaleEff 0x2ceff2c
02ceff2c: str     d8, [sp, #-0x30]!                          
02ceff30: str     x30, [sp, #8]                              
02ceff34: stp     x22, x21, [sp, #0x10]                      
02ceff38: stp     x20, x19, [sp, #0x20]                      
02ceff3c: fmov    s8, s0                                     
02ceff40: adrp    x21, #0x662f000                            
02ceff44: adrp    x22, #0x6263000                            
02ceff48: ldrb    w8, [x21, #0xe56]                          
02ceff4c: ldr     x22, [x22, #0x918]                         T:UnityEngine.Object
02ceff50: mov     w19, w1                                    
02ceff54: mov     x20, x0                                    
02ceff58: tbnz    w8, #0, #0x2ceff7c                         
02ceff5c: adrp    x0, #0x6263000                             
02ceff60: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02ceff64: bl      #0x2b70db0                                 fn_2b70db0
02ceff68: adrp    x0, #0x6264000                             
02ceff6c: ldr     x0, [x0, #0x108]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02ceff70: bl      #0x2b70db0                                 fn_2b70db0
02ceff74: mov     w8, #1                                     
02ceff78: strb    w8, [x21, #0xe56]                          
02ceff7c: ldr     x0, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02ceff80: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ceff84: cbnz    w8, #0x2ceff8c                             
02ceff88: bl      #0x2b70f30                                 fn_2b70f30
02ceff8c: mov     x0, x20                                    
02ceff90: mov     x1, xzr                                    
02ceff94: mov     x2, xzr                                    
02ceff98: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02ceff9c: tbz     w0, #0, #0x2cefffc                         
02ceffa0: adrp    x21, #0x6264000                            
02ceffa4: mov     x0, x20                                    
02ceffa8: mov     w1, wzr                                    
02ceffac: ldr     x21, [x21, #0x108]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02ceffb0: mov     x2, xzr                                    
02ceffb4: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02ceffb8: fmov    s0, s8                                     
02ceffbc: fmov    s1, s8                                     
02ceffc0: adrp    x8, #0x1084000                             
02ceffc4: fmov    s2, s8                                     
02ceffc8: fmov    s4, #1.00000000                            
02ceffcc: ldr     s3, [x8, #0xda4]                           [1084da4]=3eb851ec3e19999a f=0.15,0.36
02ceffd0: mov     x0, x20                                    
02ceffd4: mov     w1, #2                                     
02ceffd8: mov     x2, xzr                                    
02ceffdc: bl      #0x2d9982c                                 DG.Tweening.ShortcutExtensions::DOPunchScale
02ceffe0: ldr     x2, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ceffe4: mov     w1, w19                                    
02ceffe8: ldr     x30, [sp, #8]                              
02ceffec: ldp     x20, x19, [sp, #0x20]                      
02cefff0: ldp     x22, x21, [sp, #0x10]                      
02cefff4: ldr     d8, [sp], #0x30                            
02cefff8: b       #0x336fa0c                                 
02cefffc: ldp     x20, x19, [sp, #0x20]                      
02cf0000: ldr     x30, [sp, #8]                              
02cf0004: ldp     x22, x21, [sp, #0x10]                      
02cf0008: ldr     d8, [sp], #0x30                            
02cf000c: ret                                                
## DOProgress(UnityEngine.RectTransform rtf, float max, float percent, UnityEngine.MonoBehaviour monoBehaviour, float duration) -> void
---- FrameWorkUtility::DOProgress 0x2cf0010
02cf0010: stp     d9, d8, [sp, #-0x30]!                      
02cf0014: str     x30, [sp, #0x10]                           
02cf0018: stp     x20, x19, [sp, #0x20]                      
02cf001c: fmul    s8, s0, s1                                 
02cf0020: fcmp    s2, #0.0                                   
02cf0024: mov     x20, x0                                    
02cf0028: b.le    #0x2cf0078                                 
02cf002c: cbz     x20, #0x2cf00a4                            
02cf0030: mov     x19, x1                                    
02cf0034: mov     x0, x20                                    
02cf0038: mov     x1, xzr                                    
02cf003c: fmov    s9, s2                                     
02cf0040: bl      #0x5b458c8                                 UnityEngine.RectTransform::get_sizeDelta
02cf0044: fmov    s2, s8                                     
02cf0048: fmov    s3, s1                                     
02cf004c: mov     x0, x20                                    
02cf0050: fmov    s4, s9                                     
02cf0054: bl      #0x2cf00a8                                 FrameWorkUtility::I_Progress
02cf0058: cbz     x19, #0x2cf00a4                            
02cf005c: mov     x1, x0                                     
02cf0060: mov     x0, x19                                    
02cf0064: ldr     x30, [sp, #0x10]                           
02cf0068: ldp     x20, x19, [sp, #0x20]                      
02cf006c: mov     x2, xzr                                    
02cf0070: ldp     d9, d8, [sp], #0x30                        
02cf0074: b       #0x5b389f0                                 UnityEngine.MonoBehaviour::StartCoroutine
02cf0078: cbz     x20, #0x2cf00a4                            
02cf007c: mov     x0, x20                                    
02cf0080: mov     x1, xzr                                    
02cf0084: bl      #0x5b458c8                                 UnityEngine.RectTransform::get_sizeDelta
02cf0088: mov     x0, x20                                    
02cf008c: ldp     x20, x19, [sp, #0x20]                      
02cf0090: ldr     x30, [sp, #0x10]                           
02cf0094: fmov    s0, s8                                     
02cf0098: mov     x1, xzr                                    
02cf009c: ldp     d9, d8, [sp], #0x30                        
02cf00a0: b       #0x5b45994                                 UnityEngine.RectTransform::set_sizeDelta
02cf00a4: bl      #0x2b7105c                                 fn_2b7105c
## I_Progress(UnityEngine.RectTransform rtf, UnityEngine.Vector2 start, UnityEngine.Vector2 end, float duration) -> System.Collections.Generic.IEnumerator`1<float>
---- FrameWorkUtility::I_Progress 0x2cf00a8
02cf00a8: str     d12, [sp, #-0x50]!                         
02cf00ac: stp     d11, d10, [sp, #0x10]                      
02cf00b0: stp     d9, d8, [sp, #0x20]                        
02cf00b4: stp     x30, x21, [sp, #0x30]                      
02cf00b8: stp     x20, x19, [sp, #0x40]                      
02cf00bc: fmov    s8, s4                                     
02cf00c0: fmov    s9, s3                                     
02cf00c4: adrp    x20, #0x662f000                            
02cf00c8: fmov    s10, s2                                    
02cf00cc: fmov    s11, s1                                    
02cf00d0: adrp    x21, #0x6268000                            
02cf00d4: fmov    s12, s0                                    
02cf00d8: ldrb    w8, [x20, #0xe57]                          
02cf00dc: ldr     x21, [x21, #0x5b8]                         T:FrameWorkUtility/<I_Progress>d__36
02cf00e0: mov     x19, x0                                    
02cf00e4: tbnz    w8, #0, #0x2cf00fc                         
02cf00e8: adrp    x0, #0x6268000                             
02cf00ec: ldr     x0, [x0, #0x5b8]                           T:FrameWorkUtility/<I_Progress>d__36
02cf00f0: bl      #0x2b70db0                                 fn_2b70db0
02cf00f4: mov     w8, #1                                     
02cf00f8: strb    w8, [x20, #0xe57]                          
02cf00fc: ldr     x0, [x21]                                  S:'{0}/2'
02cf0100: bl      #0x2b7104c                                 fn_2b7104c
02cf0104: mov     x1, xzr                                    
02cf0108: mov     x20, x0                                    
02cf010c: bl      #0x4e53e9c                                 System.Object::.ctor
02cf0110: mov     x0, x20                                    
02cf0114: mov     x1, x19                                    
02cf0118: str     wzr, [x20, #0x10]                          
02cf011c: str     x19, [x0, #0x20]!                          
02cf0120: bl      #0x2b70d54                                 fn_2b70d54
02cf0124: stp     s12, s11, [x20, #0x28]                     
02cf0128: mov     x0, x20                                    
02cf012c: stp     s10, s9, [x20, #0x30]                      
02cf0130: ldp     x30, x21, [sp, #0x30]                      
02cf0134: str     s8, [x20, #0x18]                           
02cf0138: ldp     x20, x19, [sp, #0x40]                      
02cf013c: ldp     d9, d8, [sp, #0x20]                        
02cf0140: ldp     d11, d10, [sp, #0x10]                      
02cf0144: ldr     d12, [sp], #0x50                           
02cf0148: ret                                                
##  PickRandom (no body)
##  PickRandom (no body)
##  Shuffle (no body)
##  Shuffle (no body)
## SetLayerRecursively(UnityEngine.GameObject obj, int layer) -> void
---- FrameWorkUtility::SetLayerRecursively 0x2cf0174
02cf0174: sub     sp, sp, #0x60                              
02cf0178: stp     x30, x23, [sp, #0x30]                      
02cf017c: stp     x22, x21, [sp, #0x40]                      
02cf0180: stp     x20, x19, [sp, #0x50]                      
02cf0184: adrp    x21, #0x662f000                            
02cf0188: mov     w19, w1                                    
02cf018c: mov     x20, x0                                    
02cf0190: ldrb    w8, [x21, #0xe58]                          
02cf0194: tbnz    w8, #0, #0x2cf01c4                         
02cf0198: adrp    x0, #0x6263000                             
02cf019c: ldr     x0, [x0, #0x980]                           T:System.IDisposable
02cf01a0: bl      #0x2b70db0                                 fn_2b70db0
02cf01a4: adrp    x0, #0x6263000                             
02cf01a8: ldr     x0, [x0, #0xa58]                           T:System.Collections.IEnumerator
02cf01ac: bl      #0x2b70db0                                 fn_2b70db0
02cf01b0: adrp    x0, #0x6264000                             
02cf01b4: ldr     x0, [x0, #0x920]                           T:UnityEngine.Transform
02cf01b8: bl      #0x2b70db0                                 fn_2b70db0
02cf01bc: mov     w8, #1                                     
02cf01c0: strb    w8, [x21, #0xe58]                          
02cf01c4: stp     xzr, xzr, [sp, #0x20]                      
02cf01c8: cbz     x20, #0x2cf03d0                            
02cf01cc: mov     x0, x20                                    
02cf01d0: mov     w1, w19                                    
02cf01d4: mov     x2, xzr                                    
02cf01d8: bl      #0x5b36a74                                 UnityEngine.GameObject::set_layer
02cf01dc: mov     x0, x20                                    
02cf01e0: mov     x1, xzr                                    
02cf01e4: bl      #0x5b368f0                                 UnityEngine.GameObject::get_transform
02cf01e8: cbz     x0, #0x2cf03d0                             
02cf01ec: adrp    x22, #0x6263000                            
02cf01f0: adrp    x23, #0x6264000                            
02cf01f4: adrp    x21, #0x6263000                            
02cf01f8: ldr     x22, [x22, #0xa58]                         T:System.Collections.IEnumerator
02cf01fc: ldr     x23, [x23, #0x920]                         T:UnityEngine.Transform
02cf0200: ldr     x21, [x21, #0x980]                         T:System.IDisposable
02cf0204: mov     x1, xzr                                    
02cf0208: bl      #0x5b48c9c                                 UnityEngine.Transform::GetEnumerator
02cf020c: add     x8, sp, #0x28                              
02cf0210: str     x0, [sp, #0x28]                            
02cf0214: stp     xzr, x8, [sp, #8]                          
02cf0218: add     x8, sp, #0x20                              
02cf021c: str     x8, [sp, #0x18]                            
02cf0220: ldr     x20, [sp, #0x28]                           
02cf0224: cbz     x20, #0x2cf03c4                            
02cf0228: ldr     x8, [x20]                                  
02cf022c: ldr     x1, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cf0230: ldrh    w9, [x8, #0x12e]                           
02cf0234: cbz     x9, #0x2cf0258                             
02cf0238: ldr     x10, [x8, #0xb0]                           
02cf023c: add     x10, x10, #8                               
02cf0240: ldur    x11, [x10, #-8]                            
02cf0244: cmp     x11, x1                                    
02cf0248: b.eq    #0x2cf0268                                 
02cf024c: subs    x9, x9, #1                                 
02cf0250: add     x10, x10, #0x10                            
02cf0254: b.ne    #0x2cf0240                                 
02cf0258: mov     x0, x20                                    
02cf025c: mov     w2, wzr                                    
02cf0260: bl      #0x2baa05c                                 fn_2baa05c
02cf0264: b       #0x2cf0274                                 
02cf0268: ldrsw   x9, [x10]                                  
02cf026c: add     x8, x8, x9, lsl #4                         
02cf0270: add     x0, x8, #0x138                             
02cf0274: ldp     x8, x1, [x0]                               
02cf0278: mov     x0, x20                                    
02cf027c: blr     x8                                         
02cf0280: tbz     w0, #0, #0x2cf032c                         
02cf0284: ldr     x20, [sp, #0x28]                           
02cf0288: cbz     x20, #0x2cf03c8                            
02cf028c: ldr     x8, [x20]                                  
02cf0290: ldr     x1, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cf0294: ldrh    w9, [x8, #0x12e]                           
02cf0298: cbz     x9, #0x2cf02bc                             
02cf029c: ldr     x10, [x8, #0xb0]                           
02cf02a0: add     x10, x10, #8                               
02cf02a4: ldur    x11, [x10, #-8]                            
02cf02a8: cmp     x11, x1                                    
02cf02ac: b.eq    #0x2cf02cc                                 
02cf02b0: subs    x9, x9, #1                                 
02cf02b4: add     x10, x10, #0x10                            
02cf02b8: b.ne    #0x2cf02a4                                 
02cf02bc: mov     x0, x20                                    
02cf02c0: mov     w2, #1                                     
02cf02c4: bl      #0x2baa05c                                 fn_2baa05c
02cf02c8: b       #0x2cf02dc                                 
02cf02cc: ldr     w9, [x10]                                  
02cf02d0: add     w9, w9, #1                                 
02cf02d4: add     x8, x8, w9, sxtw #4                        
02cf02d8: add     x0, x8, #0x138                             
02cf02dc: ldp     x8, x1, [x0]                               
02cf02e0: mov     x0, x20                                    
02cf02e4: blr     x8                                         
02cf02e8: cbz     x0, #0x2cf03cc                             
02cf02ec: ldr     x1, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cf02f0: ldr     x8, [x0]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cf02f4: ldrb    w10, [x8, #0x130]                          
02cf02f8: ldrb    w9, [x1, #0x130]                           
02cf02fc: cmp     w10, w9                                    
02cf0300: b.lo    #0x2cf03c0                                 
02cf0304: ldr     x8, [x8, #0xc8]                            
02cf0308: add     x8, x8, x9, lsl #3                         
02cf030c: ldur    x8, [x8, #-8]                              
02cf0310: cmp     x8, x1                                     
02cf0314: b.ne    #0x2cf03c0                                 
02cf0318: mov     x1, xzr                                    
02cf031c: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02cf0320: mov     w1, w19                                    
02cf0324: bl      #0x2cf0174                                 FrameWorkUtility::SetLayerRecursively
02cf0328: b       #0x2cf0220                                 
02cf032c: mov     x19, xzr                                   
02cf0330: add     x8, sp, #0x28                              
02cf0334: add     x22, sp, #0x20                             
02cf0338: ldr     x0, [x8]                                   
02cf033c: ldr     x1, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cf0340: bl      #0x2b70f34                                 fn_2b70f34
02cf0344: str     x0, [x22]                                  
02cf0348: cbz     x0, #0x2cf03a8                             
02cf034c: ldr     x8, [x0]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cf0350: ldr     x1, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cf0354: mov     x20, x0                                    
02cf0358: ldrh    w9, [x8, #0x12e]                           
02cf035c: cbz     x9, #0x2cf0380                             
02cf0360: ldr     x10, [x8, #0xb0]                           
02cf0364: add     x10, x10, #8                               
02cf0368: ldur    x11, [x10, #-8]                            
02cf036c: cmp     x11, x1                                    
02cf0370: b.eq    #0x2cf0390                                 
02cf0374: subs    x9, x9, #1                                 
02cf0378: add     x10, x10, #0x10                            
02cf037c: b.ne    #0x2cf0368                                 
02cf0380: mov     x0, x20                                    
02cf0384: mov     w2, wzr                                    
02cf0388: bl      #0x2baa05c                                 fn_2baa05c
02cf038c: b       #0x2cf039c                                 
02cf0390: ldrsw   x9, [x10]                                  
02cf0394: add     x8, x8, x9, lsl #4                         
02cf0398: add     x0, x8, #0x138                             
02cf039c: ldp     x8, x1, [x0]                               
02cf03a0: mov     x0, x20                                    
02cf03a4: blr     x8                                         
02cf03a8: cbnz    x19, #0x2cf03d4                            
02cf03ac: ldp     x20, x19, [sp, #0x50]                      
02cf03b0: ldp     x22, x21, [sp, #0x40]                      
02cf03b4: ldp     x30, x23, [sp, #0x30]                      
02cf03b8: add     sp, sp, #0x60                              
02cf03bc: ret                                                
02cf03c0: bl      #0x2b713dc                                 fn_2b713dc
02cf03c4: bl      #0x2b7105c                                 fn_2b7105c
02cf03c8: bl      #0x2b7105c                                 fn_2b7105c
02cf03cc: bl      #0x2b7105c                                 fn_2b7105c
02cf03d0: bl      #0x2b7105c                                 fn_2b7105c
02cf03d4: mov     x0, x19                                    
02cf03d8: bl      #0x2b71054                                 fn_2b71054
02cf03dc: b       #0x2cf03f4                                 
02cf03e0: b       #0x2cf03f4                                 
02cf03e4: b       #0x2cf03f4                                 
02cf03e8: b       #0x2cf03f4                                 
02cf03ec: b       #0x2cf03f4                                 
02cf03f0: b       #0x2cf03f4                                 
02cf03f4: mov     x19, x0                                    
02cf03f8: cmp     w1, #1                                     
02cf03fc: b.ne    #0x2cf0420                                 
02cf0400: mov     x0, x19                                    
02cf0404: bl      #0x5e90260                                 fn_5e90260
02cf0408: ldr     x19, [x0]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cf040c: str     x19, [sp, #8]                              
02cf0410: bl      #0x5e90270                                 fn_5e90270
02cf0414: ldp     x8, x22, [sp, #0x10]                       
02cf0418: b       #0x2cf0338                                 
02cf041c: mov     x19, x0                                    
02cf0420: add     x0, sp, #8                                 
02cf0424: bl      #0x2736a80                                 fn_2736a80
02cf0428: mov     x0, x19                                    
02cf042c: bl      #0x2c6051c                                 fn_2c6051c
02cf0430: bl      #0x27369b8                                 fn_27369b8
## Log(System.Exception excep) -> void
---- FrameWorkUtility::Log 0x2cf0434
02cf0434: str     x30, [sp, #-0x30]!                         
02cf0438: stp     x22, x21, [sp, #0x10]                      
02cf043c: stp     x20, x19, [sp, #0x20]                      
02cf0440: adrp    x19, #0x662f000                            
02cf0444: adrp    x21, #0x6263000                            
02cf0448: mov     x20, x0                                    
02cf044c: ldrb    w8, [x19, #0xe59]                          
02cf0450: ldr     x21, [x21, #0xa80]                         T:type24502(k1d)
02cf0454: tbnz    w8, #0, #0x2cf0484                         
02cf0458: adrp    x0, #0x6263000                             
02cf045c: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02cf0460: bl      #0x2b70db0                                 fn_2b70db0
02cf0464: adrp    x0, #0x6263000                             
02cf0468: ldr     x0, [x0, #0xa80]                           T:type24502(k1d)
02cf046c: bl      #0x2b70db0                                 fn_2b70db0
02cf0470: adrp    x0, #0x6268000                             
02cf0474: ldr     x0, [x0, #0x5c0]                           S:'[Exception]{0}'
02cf0478: bl      #0x2b70db0                                 fn_2b70db0
02cf047c: mov     w8, #1                                     
02cf0480: strb    w8, [x19, #0xe59]                          
02cf0484: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cf0488: mov     w1, #1                                     
02cf048c: bl      #0x2b70ea0                                 fn_2b70ea0
02cf0490: cbz     x20, #0x2cf051c                            
02cf0494: ldr     x8, [x20]                                  
02cf0498: mov     x19, x0                                    
02cf049c: mov     x0, x20                                    
02cf04a0: ldp     x9, x1, [x8, #0x188]                       
02cf04a4: blr     x9                                         
02cf04a8: cbz     x19, #0x2cf051c                            
02cf04ac: mov     x20, x0                                    
02cf04b0: cbz     x0, #0x2cf04c8                             
02cf04b4: ldr     x8, [x19]                                  &2b706c4(=eb01011ff9400808)
02cf04b8: mov     x0, x20                                    
02cf04bc: ldr     x1, [x8, #0x40]                            
02cf04c0: bl      #0x2b70f34                                 fn_2b70f34
02cf04c4: cbz     x0, #0x2cf0524                             
02cf04c8: ldr     w8, [x19, #0x18]                           [662f018]=6000014 f=2.40742e-35,0
02cf04cc: cbz     w8, #0x2cf0520                             
02cf04d0: adrp    x22, #0x6263000                            
02cf04d4: adrp    x21, #0x6268000                            
02cf04d8: mov     x0, x19                                    
02cf04dc: ldr     x22, [x22, #0x928]                         T:UnityEngine.Debug
02cf04e0: ldr     x21, [x21, #0x5c0]                         S:'[Exception]{0}'
02cf04e4: mov     x1, x20                                    
02cf04e8: str     x20, [x0, #0x20]!                          
02cf04ec: bl      #0x2b70d54                                 fn_2b70d54
02cf04f0: ldr     x0, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cf04f4: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cf04f8: cbnz    w8, #0x2cf0500                             
02cf04fc: bl      #0x2b70f30                                 fn_2b70f30
02cf0500: ldr     x0, [x21]                                  S:'{0}/2'
02cf0504: mov     x1, x19                                    
02cf0508: mov     x2, xzr                                    
02cf050c: ldp     x20, x19, [sp, #0x20]                      
02cf0510: ldp     x22, x21, [sp, #0x10]                      
02cf0514: ldr     x30, [sp], #0x30                           
02cf0518: b       #0x5af2a60                                 UnityEngine.Debug::LogErrorFormat
02cf051c: bl      #0x2b7105c                                 fn_2b7105c
02cf0520: bl      #0x2b71064                                 fn_2b71064
02cf0524: bl      #0x2b71080                                 fn_2b71080
02cf0528: mov     x1, xzr                                    
02cf052c: bl      #0x2b70f20                                 fn_2b70f20
## LogVector2(UnityEngine.Vector2 vector2) -> string
---- FrameWorkUtility::LogVector2 0x2cf0530
02cf0530: str     x30, [sp, #-0x30]!                         
02cf0534: stp     x22, x21, [sp, #0x10]                      
02cf0538: stp     x20, x19, [sp, #0x20]                      
02cf053c: adrp    x19, #0x662f000                            
02cf0540: adrp    x21, #0x6268000                            
02cf0544: adrp    x20, #0x6263000                            
02cf0548: ldrb    w8, [x19, #0xe5a]                          
02cf054c: ldr     x21, [x21, #0x5c8]                         S:'  '
02cf0550: ldr     x20, [x20, #0xb70]                         MS:System.Array::Empty
02cf0554: add     x22, sp, #8                                
02cf0558: stp     s0, s1, [sp, #8]                           
02cf055c: tbnz    w8, #0, #0x2cf0580                         
02cf0560: adrp    x0, #0x6263000                             
02cf0564: ldr     x0, [x0, #0xb70]                           MS:System.Array::Empty
02cf0568: bl      #0x2b70db0                                 fn_2b70db0
02cf056c: adrp    x0, #0x6268000                             
02cf0570: ldr     x0, [x0, #0x5c8]                           S:'  '
02cf0574: bl      #0x2b70db0                                 fn_2b70db0
02cf0578: mov     w8, #1                                     
02cf057c: strb    w8, [x19, #0xe5a]                          
02cf0580: add     x0, sp, #8                                 
02cf0584: mov     x1, xzr                                    
02cf0588: bl      #0x4e246d8                                 System.Single::ToString
02cf058c: mov     x19, x0                                    
02cf0590: add     x0, x22, #4                                
02cf0594: mov     x1, xzr                                    
02cf0598: bl      #0x4e246d8                                 System.Single::ToString
02cf059c: ldr     x1, [x21]                                  S:'{0}/2'
02cf05a0: mov     x2, x0                                     
02cf05a4: mov     x0, x19                                    
02cf05a8: mov     x3, xzr                                    
02cf05ac: bl      #0x4ca6dbc                                 System.String::Concat
02cf05b0: ldr     x20, [x20]                                 &2c5bbd4(=a9bd7bfdd503233f)
02cf05b4: mov     x19, x0                                    
02cf05b8: ldr     x8, [x20, #0x38]                           &6260bd8(=0)
02cf05bc: cbnz    x8, #0x2cf05cc                             
02cf05c0: mov     x0, x20                                    
02cf05c4: bl      #0x2ba9d7c                                 fn_2ba9d7c
02cf05c8: ldr     x8, [x20, #0x38]                           &6260bd8(=0)
02cf05cc: ldr     x0, [x8, #0x10]                            
02cf05d0: add     x8, x0, #0x135                             &6268135
02cf05d4: ldrh    w8, [x8]                                   
02cf05d8: tbnz    w8, #0, #0x2cf05e0                         
02cf05dc: bl      #0x2ba9d20                                 fn_2ba9d20
02cf05e0: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02cf05e4: cbnz    w8, #0x2cf05ec                             
02cf05e8: bl      #0x2b70f30                                 fn_2b70f30
02cf05ec: ldr     x8, [x20, #0x38]                           &6260bd8(=0)
02cf05f0: ldr     x0, [x8, #0x10]                            
02cf05f4: add     x8, x0, #0x135                             &6268135
02cf05f8: ldrh    w8, [x8]                                   
02cf05fc: tbnz    w8, #0, #0x2cf0604                         
02cf0600: bl      #0x2ba9d20                                 fn_2ba9d20
02cf0604: ldr     x8, [x0, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02cf0608: mov     x0, x19                                    
02cf060c: mov     x2, xzr                                    
02cf0610: ldr     x1, [x8]                                   
02cf0614: bl      #0x4ca77a8                                 System.String::Format
02cf0618: ldp     x20, x19, [sp, #0x20]                      
02cf061c: ldp     x22, x21, [sp, #0x10]                      
02cf0620: ldr     x30, [sp], #0x30                           
02cf0624: ret                                                
## IsVisible(UnityEngine.CanvasGroup canvasGroup, bool isVisible, float minAlpha) -> void
---- FrameWorkUtility::IsVisible 0x2cf0628
02cf0628: str     d8, [sp, #-0x30]!                          
02cf062c: str     x30, [sp, #8]                              
02cf0630: stp     x22, x21, [sp, #0x10]                      
02cf0634: stp     x20, x19, [sp, #0x20]                      
02cf0638: fmov    s8, s0                                     
02cf063c: adrp    x21, #0x662f000                            
02cf0640: adrp    x22, #0x6263000                            
02cf0644: ldrb    w8, [x21, #0xe5b]                          
02cf0648: ldr     x22, [x22, #0x918]                         T:UnityEngine.Object
02cf064c: mov     w20, w1                                    
02cf0650: mov     x19, x0                                    
02cf0654: tbnz    w8, #0, #0x2cf066c                         
02cf0658: adrp    x0, #0x6263000                             
02cf065c: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02cf0660: bl      #0x2b70db0                                 fn_2b70db0
02cf0664: mov     w8, #1                                     
02cf0668: strb    w8, [x21, #0xe5b]                          
02cf066c: ldr     x0, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cf0670: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02cf0674: cbnz    w8, #0x2cf067c                             
02cf0678: bl      #0x2b70f30                                 fn_2b70f30
02cf067c: mov     x0, x19                                    
02cf0680: mov     x1, xzr                                    
02cf0684: mov     x2, xzr                                    
02cf0688: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02cf068c: tbz     w0, #0, #0x2cf06cc                         
02cf0690: cbz     x19, #0x2cf06e0                            
02cf0694: fmov    s0, #1.00000000                            
02cf0698: ands    w20, w20, #1                               
02cf069c: mov     x0, x19                                    
02cf06a0: mov     x1, xzr                                    
02cf06a4: fcsel   s0, s0, s8, ne                             
02cf06a8: bl      #0x5e45108                                 UnityEngine.CanvasGroup::set_alpha
02cf06ac: mov     x0, x19                                    
02cf06b0: mov     w1, w20                                    
02cf06b4: ldr     x30, [sp, #8]                              
02cf06b8: ldp     x20, x19, [sp, #0x20]                      
02cf06bc: mov     x2, xzr                                    
02cf06c0: ldp     x22, x21, [sp, #0x10]                      
02cf06c4: ldr     d8, [sp], #0x30                            
02cf06c8: b       #0x5e45408                                 UnityEngine.CanvasGroup::set_blocksRaycasts
02cf06cc: ldp     x20, x19, [sp, #0x20]                      
02cf06d0: ldr     x30, [sp, #8]                              
02cf06d4: ldp     x22, x21, [sp, #0x10]                      
02cf06d8: ldr     d8, [sp], #0x30                            
02cf06dc: ret                                                
02cf06e0: bl      #0x2b7105c                                 fn_2b7105c
## SmoothLookAtInSeconds(UnityEngine.MonoBehaviour self, UnityEngine.Transform tf, UnityEngine.Transform target, float damping, float duration, System.Action OnCompleted) -> void
---- FrameWorkUtility::SmoothLookAtInSeconds 0x2cf06e4
02cf06e4: stp     x30, x19, [sp, #-0x10]!                    
02cf06e8: mov     x19, x0                                    
02cf06ec: mov     x0, x1                                     
02cf06f0: mov     x1, x2                                     
02cf06f4: mov     x2, x3                                     
02cf06f8: bl      #0x2cf0718                                 FrameWorkUtility::I_SmoothLookAtInSeconds
02cf06fc: cbz     x19, #0x2cf0714                            
02cf0700: mov     x1, x0                                     
02cf0704: mov     x0, x19                                    
02cf0708: mov     x2, xzr                                    
02cf070c: ldp     x30, x19, [sp], #0x10                      
02cf0710: b       #0x5b389f0                                 UnityEngine.MonoBehaviour::StartCoroutine
02cf0714: bl      #0x2b7105c                                 fn_2b7105c
## I_SmoothLookAtInSeconds(UnityEngine.Transform tf, UnityEngine.Transform target, float damping, float duration, System.Action OnCompleted) -> System.Collections.IEnumerator
---- FrameWorkUtility::I_SmoothLookAtInSeconds 0x2cf0718
02cf0718: str     d8, [sp, #-0x40]!                          
02cf071c: stp     x30, x23, [sp, #0x10]                      
02cf0720: stp     x22, x21, [sp, #0x20]                      
02cf0724: stp     x20, x19, [sp, #0x30]                      
02cf0728: fmov    s8, s1                                     
02cf072c: adrp    x22, #0x662f000                            
02cf0730: adrp    x23, #0x6268000                            
02cf0734: ldrb    w8, [x22, #0xe5c]                          
02cf0738: ldr     x23, [x23, #0x5d0]                         T:FrameWorkUtility/<I_SmoothLookAtInSeconds>d__46
02cf073c: mov     x19, x2                                    
02cf0740: mov     x20, x1                                    
02cf0744: mov     x21, x0                                    
02cf0748: tbnz    w8, #0, #0x2cf0760                         
02cf074c: adrp    x0, #0x6268000                             
02cf0750: ldr     x0, [x0, #0x5d0]                           T:FrameWorkUtility/<I_SmoothLookAtInSeconds>d__46
02cf0754: bl      #0x2b70db0                                 fn_2b70db0
02cf0758: mov     w8, #1                                     
02cf075c: strb    w8, [x22, #0xe5c]                          
02cf0760: ldr     x0, [x23]                                  S:'{0}/2'
02cf0764: bl      #0x2b7104c                                 fn_2b7104c
02cf0768: mov     x1, xzr                                    
02cf076c: mov     x22, x0                                    
02cf0770: bl      #0x4e53e9c                                 System.Object::.ctor
02cf0774: mov     x0, x22                                    
02cf0778: mov     x1, x21                                    
02cf077c: str     wzr, [x22, #0x10]                          
02cf0780: str     x21, [x0, #0x30]!                          
02cf0784: bl      #0x2b70d54                                 fn_2b70d54
02cf0788: mov     x0, x22                                    
02cf078c: mov     x1, x20                                    
02cf0790: str     x20, [x0, #0x28]!                          
02cf0794: bl      #0x2b70d54                                 fn_2b70d54
02cf0798: mov     x0, x22                                    
02cf079c: mov     x1, x19                                    
02cf07a0: str     s8, [x22, #0x20]                           
02cf07a4: str     x19, [x0, #0x38]!                          
02cf07a8: bl      #0x2b70d54                                 fn_2b70d54
02cf07ac: mov     x0, x22                                    
02cf07b0: ldp     x20, x19, [sp, #0x30]                      
02cf07b4: ldp     x22, x21, [sp, #0x20]                      
02cf07b8: ldp     x30, x23, [sp, #0x10]                      
02cf07bc: ldr     d8, [sp], #0x40                            
02cf07c0: ret                                                
## SmoothLookAt(UnityEngine.Transform tf, UnityEngine.Transform target, float damping) -> void
---- FrameWorkUtility::SmoothLookAt 0x2cf07ec
02cf07ec: sub     sp, sp, #0x80                              
02cf07f0: stp     d15, d14, [sp, #0x20]                      
02cf07f4: stp     d13, d12, [sp, #0x30]                      
02cf07f8: stp     d11, d10, [sp, #0x40]                      
02cf07fc: stp     d9, d8, [sp, #0x50]                        
02cf0800: str     x30, [sp, #0x60]                           
02cf0804: stp     x20, x19, [sp, #0x70]                      
02cf0808: cbz     x1, #0x2cf0934                             
02cf080c: mov     x19, x0                                    
02cf0810: mov     x0, x1                                     
02cf0814: mov     x1, xzr                                    
02cf0818: fmov    s8, s0                                     
02cf081c: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02cf0820: cbz     x19, #0x2cf0934                            
02cf0824: mov     x0, x19                                    
02cf0828: mov     x1, xzr                                    
02cf082c: fmov    s9, s0                                     
02cf0830: fmov    s10, s1                                    
02cf0834: fmov    s11, s2                                    
02cf0838: str     s8, [sp, #0x6c]                            
02cf083c: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02cf0840: fsub    s0, s9, s0                                 
02cf0844: fsub    s1, s10, s1                                
02cf0848: adrp    x20, #0x662f000                            
02cf084c: fsub    s2, s11, s2                                
02cf0850: ldrb    w8, [x20, #0x918]                          
02cf0854: str     wzr, [sp, #8]                              
02cf0858: str     xzr, [sp]                                  
02cf085c: stp     s0, s1, [sp, #0x10]                        
02cf0860: str     s2, [sp, #0x18]                            
02cf0864: cbnz    w8, #0x2cf087c                             
02cf0868: adrp    x0, #0x6264000                             
02cf086c: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02cf0870: bl      #0x2b70db0                                 fn_2b70db0
02cf0874: mov     w8, #1                                     
02cf0878: strb    w8, [x20, #0x918]                          
02cf087c: adrp    x8, #0x6264000                             
02cf0880: add     x0, sp, #0x10                              
02cf0884: mov     x1, sp                                     
02cf0888: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02cf088c: mov     x2, xzr                                    
02cf0890: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cf0894: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02cf0898: ldr     d0, [x8, #0x18]                            M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0::<DOSetFloat>b__1
02cf089c: ldr     s1, [x8, #0x20]                            T:DG.Tweening.DOTweenModulePhysics/<>c__DisplayClass0_0
02cf08a0: str     d0, [sp]                                   
02cf08a4: str     s1, [sp, #8]                               
02cf08a8: bl      #0x5b262ec                                 UnityEngine.Quaternion::Internal_LookRotation
02cf08ac: mov     x0, x19                                    
02cf08b0: mov     x1, xzr                                    
02cf08b4: fmov    s9, s0                                     
02cf08b8: fmov    s10, s1                                    
02cf08bc: fmov    s11, s2                                    
02cf08c0: fmov    s12, s3                                    
02cf08c4: bl      #0x5b46a30                                 UnityEngine.Transform::get_rotation
02cf08c8: mov     x0, xzr                                    
02cf08cc: fmov    s13, s0                                    
02cf08d0: fmov    s14, s1                                    
02cf08d4: fmov    s15, s2                                    
02cf08d8: fmov    s8, s3                                     
02cf08dc: bl      #0x5b433a4                                 UnityEngine.Time::get_deltaTime
02cf08e0: ldr     s1, [sp, #0x6c]                            
02cf08e4: add     x0, sp, #0x10                              
02cf08e8: mov     x1, sp                                     
02cf08ec: mov     x2, xzr                                    
02cf08f0: stp     s13, s14, [sp, #0x10]                      
02cf08f4: fmul    s0, s0, s1                                 
02cf08f8: stp     s15, s8, [sp, #0x18]                       
02cf08fc: stp     s9, s10, [sp]                              
02cf0900: stp     s11, s12, [sp, #8]                         
02cf0904: bl      #0x5b25f70                                 UnityEngine.Quaternion::Internal_Slerp
02cf0908: mov     x0, x19                                    
02cf090c: mov     x1, xzr                                    
02cf0910: bl      #0x5b46b18                                 UnityEngine.Transform::set_rotation
02cf0914: ldp     x20, x19, [sp, #0x70]                      
02cf0918: ldr     x30, [sp, #0x60]                           
02cf091c: ldp     d9, d8, [sp, #0x50]                        
02cf0920: ldp     d11, d10, [sp, #0x40]                      
02cf0924: ldp     d13, d12, [sp, #0x30]                      
02cf0928: ldp     d15, d14, [sp, #0x20]                      
02cf092c: add     sp, sp, #0x80                              
02cf0930: ret                                                
02cf0934: bl      #0x2b7105c                                 fn_2b7105c
## IsVisible(UnityEngine.Camera camera, UnityEngine.Vector3 position) -> bool
---- FrameWorkUtility::IsVisible 0x2cf0938
02cf0938: str     x30, [sp, #-0x10]!                         
02cf093c: cbz     x0, #0x2cf0980                             
02cf0940: mov     x1, xzr                                    
02cf0944: bl      #0x5aefba8                                 UnityEngine.Camera::WorldToViewportPoint
02cf0948: fmov    s3, #1.00000000                            
02cf094c: movi    d4, #0000000000000000                      
02cf0950: fcmp    s0, s3                                     
02cf0954: cset    w8, ls                                     
02cf0958: fcmp    s1, #0.0                                   
02cf095c: fccmp   s0, s4, #8, ge                             
02cf0960: cset    w9, ge                                     
02cf0964: fcmp    s1, s3                                     
02cf0968: and     w8, w9, w8                                 
02cf096c: csel    w8, wzr, w8, hi                            
02cf0970: fcmp    s2, #0.0                                   
02cf0974: csel    w0, wzr, w8, le                            
02cf0978: ldr     x30, [sp], #0x10                           
02cf097c: ret                                                
02cf0980: bl      #0x2b7105c                                 fn_2b7105c
## IsObjectVisible(UnityEngine.Camera this, UnityEngine.Renderer renderer) -> bool
---- FrameWorkUtility::IsObjectVisible 0x2cf0984
02cf0984: sub     sp, sp, #0x50                              
02cf0988: str     x30, [sp, #0x30]                           
02cf098c: stp     x20, x19, [sp, #0x40]                      
02cf0990: mov     x20, x1                                    
02cf0994: mov     x1, xzr                                    
02cf0998: bl      #0x5af69f0                                 UnityEngine.GeometryUtility::CalculateFrustumPlanes
02cf099c: cbz     x20, #0x2cf0a54                            
02cf09a0: mov     x19, x0                                    
02cf09a4: add     x8, sp, #0x18                              
02cf09a8: mov     x0, x20                                    
02cf09ac: mov     x1, xzr                                    
02cf09b0: bl      #0x5b02028                                 UnityEngine.Renderer::get_bounds
02cf09b4: adrp    x20, #0x662f000                            
02cf09b8: ldur    q0, [sp, #0x18]                            
02cf09bc: ldr     x8, [sp, #0x28]                            
02cf09c0: ldrb    w9, [x20, #0xca3]                          
02cf09c4: str     q0, [sp]                                   
02cf09c8: str     x8, [sp, #0x10]                            
02cf09cc: cbnz    w9, #0x2cf09f0                             
02cf09d0: adrp    x0, #0x6266000                             
02cf09d4: ldr     x0, [x0, #0xe90]                           MS:System.MemoryExtensions::AsSpan
02cf09d8: bl      #0x2b70db0                                 fn_2b70db0
02cf09dc: adrp    x0, #0x6266000                             
02cf09e0: ldr     x0, [x0, #0xe98]                           MS:System.Span`1::op_Implicit
02cf09e4: bl      #0x2b70db0                                 fn_2b70db0
02cf09e8: mov     w8, #1                                     
02cf09ec: strb    w8, [x20, #0xca3]                          
02cf09f0: adrp    x8, #0x6266000                             
02cf09f4: ldr     x8, [x8, #0xe90]                           MS:System.MemoryExtensions::AsSpan
02cf09f8: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cf09fc: ldr     x8, [x0, #0x38]                            S:'native_collap_id'
02cf0a00: cbz     x8, #0x2cf0a14                             
02cf0a04: cbz     x19, #0x2cf0a1c                            
02cf0a08: ldr     w1, [x19, #0x18]                           
02cf0a0c: add     x0, x19, #0x20                             
02cf0a10: b       #0x2cf0a24                                 
02cf0a14: bl      #0x2ba9d7c                                 fn_2ba9d7c
02cf0a18: cbnz    x19, #0x2cf0a08                            
02cf0a1c: mov     x0, xzr                                    
02cf0a20: mov     x1, xzr                                    
02cf0a24: adrp    x8, #0x6266000                             
02cf0a28: ldr     x8, [x8, #0xe98]                           MS:System.Span`1::op_Implicit
02cf0a2c: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cf0a30: bl      #0x3c3ba14                                 fn_3c3ba14
02cf0a34: mov     x2, sp                                     
02cf0a38: mov     x3, xzr                                    
02cf0a3c: bl      #0x5af6e98                                 UnityEngine.GeometryUtility::Internal_TestPlanesAABB
02cf0a40: ldp     x20, x19, [sp, #0x40]                      
02cf0a44: and     w0, w0, #1                                 
02cf0a48: ldr     x30, [sp, #0x30]                           
02cf0a4c: add     sp, sp, #0x50                              
02cf0a50: ret                                                
02cf0a54: bl      #0x2b7105c                                 fn_2b7105c
## MutipleRayCastAll(System.Collections.Generic.List`1<UnityEngine.RaycastHit2D> result, UnityEngine.Vector2 original, UnityEngine.Vector2 point1, UnityEngine.Vector2 point2, float distance, int layer) -> void
---- FrameWorkUtility::MutipleRayCastAll 0x2cf0a58
02cf0a58: sub     sp, sp, #0x1a0                             
02cf0a5c: stp     d15, d14, [sp, #0x100]                     
02cf0a60: stp     d13, d12, [sp, #0x110]                     
02cf0a64: stp     d11, d10, [sp, #0x120]                     
02cf0a68: stp     d9, d8, [sp, #0x130]                       
02cf0a6c: stp     x29, x30, [sp, #0x140]                     
02cf0a70: stp     x28, x27, [sp, #0x150]                     
02cf0a74: stp     x26, x25, [sp, #0x160]                     
02cf0a78: stp     x24, x23, [sp, #0x170]                     
02cf0a7c: stp     x22, x21, [sp, #0x180]                     
02cf0a80: stp     x20, x19, [sp, #0x190]                     
02cf0a84: fmov    s12, s6                                    
02cf0a88: fmov    s10, s5                                    
02cf0a8c: adrp    x20, #0x662f000                            
02cf0a90: fmov    s11, s4                                    
02cf0a94: fmov    s8, s1                                     
02cf0a98: ldrb    w8, [x20, #0xe5d]                          
02cf0a9c: fmov    s9, s0                                     
02cf0aa0: mov     x19, x0                                    
02cf0aa4: str     w1, [sp, #0x24]                            
02cf0aa8: stp     s2, s3, [sp, #0x28]                        
02cf0aac: tbnz    w8, #0, #0x2cf0b30                         
02cf0ab0: adrp    x0, #0x6268000                             
02cf0ab4: ldr     x0, [x0, #0x5d8]                           MS:System.Collections.Generic.List`1::Add
02cf0ab8: bl      #0x2b70db0                                 fn_2b70db0
02cf0abc: adrp    x0, #0x6268000                             
02cf0ac0: ldr     x0, [x0, #0x5e0]                           MS:System.Collections.Generic.List`1::Clear
02cf0ac4: bl      #0x2b70db0                                 fn_2b70db0
02cf0ac8: adrp    x0, #0x6268000                             
02cf0acc: ldr     x0, [x0, #0x5e8]                           MS:System.Collections.Generic.List`1::Find
02cf0ad0: bl      #0x2b70db0                                 fn_2b70db0
02cf0ad4: adrp    x0, #0x6263000                             
02cf0ad8: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02cf0adc: bl      #0x2b70db0                                 fn_2b70db0
02cf0ae0: adrp    x0, #0x6266000                             
02cf0ae4: ldr     x0, [x0, #0x940]                           T:UnityEngine.Physics2D
02cf0ae8: bl      #0x2b70db0                                 fn_2b70db0
02cf0aec: adrp    x0, #0x6268000                             
02cf0af0: ldr     x0, [x0, #0x5f0]                           T:type57275(k15)
02cf0af4: bl      #0x2b70db0                                 fn_2b70db0
02cf0af8: adrp    x0, #0x6268000                             
02cf0afc: ldr     x0, [x0, #0x5f8]                           M:FrameWorkUtility/<>c__DisplayClass50_0::<MutipleRayCastAll>b__0
02cf0b00: bl      #0x2b70db0                                 fn_2b70db0
02cf0b04: adrp    x0, #0x6268000                             
02cf0b08: ldr     x0, [x0, #0x600]                           T:FrameWorkUtility/<>c__DisplayClass50_0
02cf0b0c: bl      #0x2b70db0                                 fn_2b70db0
02cf0b10: adrp    x0, #0x6268000                             
02cf0b14: ldr     x0, [x0, #0x608]                           M:FrameWorkUtility/<>c__DisplayClass50_1::<MutipleRayCastAll>b__1
02cf0b18: bl      #0x2b70db0                                 fn_2b70db0
02cf0b1c: adrp    x0, #0x6268000                             
02cf0b20: ldr     x0, [x0, #0x610]                           T:FrameWorkUtility/<>c__DisplayClass50_1
02cf0b24: bl      #0x2b70db0                                 fn_2b70db0
02cf0b28: mov     w8, #1                                     
02cf0b2c: strb    w8, [x20, #0xe5d]                          
02cf0b30: ldr     x8, [x19]                                  
02cf0b34: stp     xzr, xzr, [sp, #0x90]                      
02cf0b38: cbz     x8, #0x2cf10b4                             
02cf0b3c: ldp     s0, s1, [sp, #0x28]                        
02cf0b40: add     x0, sp, #0x98                              
02cf0b44: ldr     w9, [x8, #0x1c]                            
02cf0b48: mov     x1, xzr                                    
02cf0b4c: stp     s11, s10, [sp, #0x14]                      
02cf0b50: fsub    s0, s11, s0                                
02cf0b54: fsub    s1, s10, s1                                
02cf0b58: add     w9, w9, #1                                 
02cf0b5c: stp     wzr, w9, [x8, #0x18]                       
02cf0b60: stp     s0, s1, [sp, #0x98]                        
02cf0b64: bl      #0x5b28290                                 UnityEngine.Vector2::Normalize
02cf0b68: fmov    s10, s1                                    
02cf0b6c: adrp    x28, #0x662f000                            
02cf0b70: str     s0, [sp, #0x20]                            
02cf0b74: ldrb    w8, [x28, #0xca9]                          
02cf0b78: cbnz    w8, #0x2cf0b90                             
02cf0b7c: adrp    x0, #0x6265000                             
02cf0b80: ldr     x0, [x0, #0xb48]                           T:System.Math
02cf0b84: bl      #0x2b70db0                                 fn_2b70db0
02cf0b88: mov     w8, #1                                     
02cf0b8c: strb    w8, [x28, #0xca9]                          
02cf0b90: adrp    x8, #0x6265000                             
02cf0b94: ldr     x8, [x8, #0xb48]                           T:System.Math
02cf0b98: ldr     d11, [sp, #0x98]                           
02cf0b9c: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02cf0ba0: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02cf0ba4: cbnz    w8, #0x2cf0bac                             
02cf0ba8: bl      #0x2b70f30                                 fn_2b70f30
02cf0bac: fmul    v0.2s, v11.2s, v11.2s                      
02cf0bb0: mov     w8, #0x7f800000                            
02cf0bb4: fmov    s1, w8                                     
02cf0bb8: mov     w8, #-0xffffffff80000000                   
02cf0bbc: faddp   s0, v0.2s                                  
02cf0bc0: fsqrt   s0, s0                                     
02cf0bc4: fdiv    s0, s0, s12                                
02cf0bc8: fcvtzs  w9, s0                                     
02cf0bcc: fcmp    s0, s1                                     
02cf0bd0: csel    w8, w8, w9, eq                             
02cf0bd4: str     w8, [sp, #0x1c]                            
02cf0bd8: tbnz    w8, #0x1f, #0x2cf0e60                      
02cf0bdc: adrp    x27, #0x6268000                            
02cf0be0: adrp    x26, #0x6263000                            
02cf0be4: mov     w29, wzr                                   
02cf0be8: ldr     x27, [x27, #0x600]                         T:FrameWorkUtility/<>c__DisplayClass50_0
02cf0bec: ldr     x26, [x26, #0x918]                         T:UnityEngine.Object
02cf0bf0: scvtf   s0, w29                                    
02cf0bf4: ldr     s1, [sp, #0x20]                            
02cf0bf8: add     x0, sp, #0x90                              
02cf0bfc: ldp     s3, s2, [sp, #0x28]                        
02cf0c00: mov     x1, xzr                                    
02cf0c04: fmul    s1, s1, s0                                 
02cf0c08: fmul    s0, s10, s0                                
02cf0c0c: fmul    s1, s1, s12                                
02cf0c10: fmul    s0, s0, s12                                
02cf0c14: fadd    s1, s3, s1                                 
02cf0c18: fadd    s0, s2, s0                                 
02cf0c1c: fsub    s1, s1, s9                                 
02cf0c20: fsub    s0, s0, s8                                 
02cf0c24: stp     s1, s0, [sp, #0x90]                        
02cf0c28: bl      #0x5b28290                                 UnityEngine.Vector2::Normalize
02cf0c2c: fmov    s11, s0                                    
02cf0c30: fmov    s13, s1                                    
02cf0c34: ldrb    w8, [x28, #0xca9]                          
02cf0c38: cbnz    w8, #0x2cf0c50                             
02cf0c3c: adrp    x0, #0x6265000                             
02cf0c40: ldr     x0, [x0, #0xb48]                           T:System.Math
02cf0c44: bl      #0x2b70db0                                 fn_2b70db0
02cf0c48: mov     w8, #1                                     
02cf0c4c: strb    w8, [x28, #0xca9]                          
02cf0c50: adrp    x8, #0x6265000                             
02cf0c54: ldr     x8, [x8, #0xb48]                           T:System.Math
02cf0c58: ldp     s14, s15, [sp, #0x90]                      
02cf0c5c: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02cf0c60: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02cf0c64: cbnz    w8, #0x2cf0c6c                             
02cf0c68: bl      #0x2b70f30                                 fn_2b70f30
02cf0c6c: adrp    x8, #0x6266000                             
02cf0c70: ldr     x8, [x8, #0x940]                           T:UnityEngine.Physics2D
02cf0c74: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cf0c78: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02cf0c7c: cbnz    w8, #0x2cf0c84                             
02cf0c80: bl      #0x2b70f30                                 fn_2b70f30
02cf0c84: fmul    s0, s14, s14                               
02cf0c88: fmul    s1, s15, s15                               
02cf0c8c: fmov    s2, s11                                    
02cf0c90: fmov    s3, s13                                    
02cf0c94: ldr     w0, [sp, #0x24]                            
02cf0c98: mov     x1, xzr                                    
02cf0c9c: fadd    s0, s0, s1                                 
02cf0ca0: fmov    s1, s8                                     
02cf0ca4: fsqrt   s4, s0                                     
02cf0ca8: fmov    s0, s9                                     
02cf0cac: bl      #0x5bbd164                                 UnityEngine.Physics2D::RaycastAll
02cf0cb0: cbz     x0, #0x2cf10e4                             
02cf0cb4: ldr     w8, [x0, #0x18]                            T:AdsManager/<IEHideAdResume>d__30
02cf0cb8: mov     x22, x0                                    
02cf0cbc: cmp     w8, #1                                     
02cf0cc0: b.lt    #0x2cf0e50                                 
02cf0cc4: mov     x21, xzr                                   
02cf0cc8: add     x20, x22, #0x20                            
02cf0ccc: ldr     x0, [x27]                                  S:'{0}/2'
02cf0cd0: bl      #0x2b7104c                                 fn_2b7104c
02cf0cd4: mov     x1, xzr                                    
02cf0cd8: mov     x23, x0                                    
02cf0cdc: bl      #0x4e53e9c                                 System.Object::.ctor
02cf0ce0: ldr     w8, [x22, #0x18]                           
02cf0ce4: cmp     x21, x8                                    
02cf0ce8: b.hs    #0x2cf10e8                                 
02cf0cec: cbz     x23, #0x2cf10e4                            
02cf0cf0: ldp     q1, q0, [x20]                              
02cf0cf4: add     x0, x23, #0x10                             
02cf0cf8: ldr     w8, [x20, #0x20]                           &2b706f0(=d65f03c0f9400800)
02cf0cfc: mov     x1, xzr                                    
02cf0d00: str     w8, [x23, #0x30]                           
02cf0d04: stp     q1, q0, [x23, #0x10]                       
02cf0d08: bl      #0x5bbe11c                                 UnityEngine.RaycastHit2D::get_collider
02cf0d0c: ldr     x8, [x26]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cf0d10: mov     x24, x0                                    
02cf0d14: ldr     w9, [x8, #0xe4]                            [62660e4]=0 f=0,0
02cf0d18: cbnz    w9, #0x2cf0d24                             
02cf0d1c: mov     x0, x8                                     
02cf0d20: bl      #0x2b70f30                                 fn_2b70f30
02cf0d24: mov     x0, x24                                    
02cf0d28: mov     x1, xzr                                    
02cf0d2c: mov     x2, xzr                                    
02cf0d30: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02cf0d34: tbz     w0, #0, #0x2cf0e3c                         
02cf0d38: adrp    x8, #0x6268000                             
02cf0d3c: ldr     x24, [x19]                                 
02cf0d40: ldr     x8, [x8, #0x5f0]                           T:type57275(k15)
02cf0d44: ldr     x0, [x8]                                   S:'{0}/2'
02cf0d48: bl      #0x2b7104c                                 fn_2b7104c
02cf0d4c: adrp    x8, #0x6268000                             
02cf0d50: mov     x1, x23                                    
02cf0d54: mov     x3, xzr                                    
02cf0d58: ldr     x8, [x8, #0x5f8]                           M:FrameWorkUtility/<>c__DisplayClass50_0::<MutipleRayCastAll>b__0
02cf0d5c: mov     x25, x0                                    
02cf0d60: ldr     x2, [x8]                                   S:'{0}/2'
02cf0d64: bl      #0x399c5b0                                 fn_399c5b0
02cf0d68: cbz     x24, #0x2cf10e4                            
02cf0d6c: adrp    x8, #0x6268000                             
02cf0d70: mov     x0, x24                                    
02cf0d74: mov     x1, x25                                    
02cf0d78: ldr     x8, [x8, #0x5e8]                           MS:System.Collections.Generic.List`1::Find
02cf0d7c: ldr     x2, [x8]                                   S:'{0}/2'
02cf0d80: add     x8, sp, #0xd0                              
02cf0d84: bl      #0x35cc228                                 fn_35cc228
02cf0d88: ldp     q0, q1, [sp, #0xd0]                        
02cf0d8c: add     x0, sp, #0x60                              
02cf0d90: ldr     w8, [sp, #0xf0]                            
02cf0d94: mov     x1, xzr                                    
02cf0d98: stp     q0, q1, [sp, #0x60]                        
02cf0d9c: str     w8, [sp, #0x80]                            
02cf0da0: bl      #0x5bbe3c8                                 UnityEngine.RaycastHit2D::op_Implicit
02cf0da4: tbnz    w0, #0, #0x2cf0e3c                         
02cf0da8: ldr     x0, [x19]                                  
02cf0dac: cbz     x0, #0x2cf10e4                             
02cf0db0: ldp     q0, q1, [x23, #0x10]                       
02cf0db4: ldur    w9, [x23, #0x30]                           
02cf0db8: ldr     w10, [x0, #0x1c]                           [626501c]=0 f=0,0
02cf0dbc: ldr     x8, [x0, #0x10]                            MS:MonoSingleton`1::get_Instance
02cf0dc0: str     w9, [sp, #0xc0]                            
02cf0dc4: adrp    x9, #0x6268000                             
02cf0dc8: stp     q0, q1, [sp, #0xa0]                        
02cf0dcc: add     w10, w10, #1                               
02cf0dd0: ldr     x9, [x9, #0x5d8]                           MS:System.Collections.Generic.List`1::Add
02cf0dd4: str     w10, [x0, #0x1c]                           
02cf0dd8: ldr     x9, [x9]                                   S:'{0}/2'
02cf0ddc: cbz     x8, #0x2cf10e4                             
02cf0de0: ldrsw   x10, [x0, #0x18]                           
02cf0de4: ldr     w11, [x8, #0x18]                           M:LuckyWheelPopup/<>c__DisplayClass50_0::<RunAnimation>b__0
02cf0de8: cmp     w10, w11                                   
02cf0dec: b.hs    #0x2cf0e18                                 
02cf0df0: mov     w9, #0x24                                  
02cf0df4: ldp     q0, q1, [sp, #0xa0]                        
02cf0df8: nop                                                
02cf0dfc: smaddl  x8, w10, w9, x8                            
02cf0e00: add     w9, w10, #1                                
02cf0e04: str     w9, [x0, #0x18]                            
02cf0e08: ldr     w9, [sp, #0xc0]                            
02cf0e0c: stp     q0, q1, [x8, #0x20]                        
02cf0e10: str     w9, [x8, #0x40]                            
02cf0e14: b       #0x2cf0e3c                                 
02cf0e18: ldr     x8, [x9, #0x20]                            T:LuckyWheelPopup/<SpinAnimation>d__51
02cf0e1c: ldp     q0, q1, [sp, #0xa0]                        
02cf0e20: ldr     w9, [sp, #0xc0]                            
02cf0e24: add     x1, sp, #0xd0                              
02cf0e28: ldr     x8, [x8, #0xc0]                            M:LuckyWheelPopup/<>c__DisplayClass54_0::<GetMoney>b__0
02cf0e2c: ldr     x2, [x8, #0x70]                            T:type57276(k15)
02cf0e30: stp     q0, q1, [sp, #0xd0]                        
02cf0e34: str     w9, [sp, #0xf0]                            
02cf0e38: bl      #0x35cbb0c                                 fn_35cbb0c
02cf0e3c: ldrsw   x8, [x22, #0x18]                           
02cf0e40: add     x21, x21, #1                               
02cf0e44: add     x20, x20, #0x24                            &662f024
02cf0e48: cmp     x21, x8                                    
02cf0e4c: b.lt    #0x2cf0ccc                                 
02cf0e50: ldr     w8, [sp, #0x1c]                            
02cf0e54: add     w29, w29, #1                               
02cf0e58: cmp     w29, w8                                    
02cf0e5c: b.le    #0x2cf0bf0                                 
02cf0e60: ldp     s0, s1, [sp, #0x14]                        
02cf0e64: add     x0, sp, #0x90                              
02cf0e68: mov     x1, xzr                                    
02cf0e6c: fsub    s0, s0, s9                                 
02cf0e70: fsub    s1, s1, s8                                 
02cf0e74: stp     s0, s1, [sp, #0x90]                        
02cf0e78: bl      #0x5b28290                                 UnityEngine.Vector2::Normalize
02cf0e7c: fmov    s10, s0                                    
02cf0e80: fmov    s11, s1                                    
02cf0e84: ldrb    w8, [x28, #0xca9]                          
02cf0e88: cbnz    w8, #0x2cf0ea0                             
02cf0e8c: adrp    x0, #0x6265000                             
02cf0e90: ldr     x0, [x0, #0xb48]                           T:System.Math
02cf0e94: bl      #0x2b70db0                                 fn_2b70db0
02cf0e98: mov     w8, #1                                     
02cf0e9c: strb    w8, [x28, #0xca9]                          
02cf0ea0: adrp    x8, #0x6265000                             
02cf0ea4: ldr     x8, [x8, #0xb48]                           T:System.Math
02cf0ea8: ldp     s12, s13, [sp, #0x90]                      
02cf0eac: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02cf0eb0: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02cf0eb4: cbnz    w8, #0x2cf0ebc                             
02cf0eb8: bl      #0x2b70f30                                 fn_2b70f30
02cf0ebc: fmul    s0, s12, s12                               
02cf0ec0: fmul    s1, s13, s13                               
02cf0ec4: adrp    x8, #0x6266000                             
02cf0ec8: ldr     x8, [x8, #0x940]                           T:UnityEngine.Physics2D
02cf0ecc: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cf0ed0: fadd    s0, s0, s1                                 
02cf0ed4: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02cf0ed8: fsqrt   s12, s0                                    
02cf0edc: cbnz    w8, #0x2cf0ee4                             
02cf0ee0: bl      #0x2b70f30                                 fn_2b70f30
02cf0ee4: fmov    s0, s9                                     
02cf0ee8: fmov    s1, s8                                     
02cf0eec: ldr     w0, [sp, #0x24]                            
02cf0ef0: fmov    s2, s10                                    
02cf0ef4: fmov    s3, s11                                    
02cf0ef8: mov     x1, xzr                                    
02cf0efc: fmov    s4, s12                                    
02cf0f00: bl      #0x5bbd164                                 UnityEngine.Physics2D::RaycastAll
02cf0f04: cbz     x0, #0x2cf10e4                             
02cf0f08: ldr     w8, [x0, #0x18]                            T:AdsManager/<IEHideAdResume>d__30
02cf0f0c: mov     x20, x0                                    
02cf0f10: cmp     w8, #1                                     
02cf0f14: b.lt    #0x2cf10b4                                 
02cf0f18: adrp    x25, #0x6268000                            
02cf0f1c: adrp    x26, #0x6263000                            
02cf0f20: adrp    x28, #0x6268000                            
02cf0f24: adrp    x29, #0x6268000                            
02cf0f28: ldr     x25, [x25, #0x610]                         T:FrameWorkUtility/<>c__DisplayClass50_1
02cf0f2c: ldr     x26, [x26, #0x918]                         T:UnityEngine.Object
02cf0f30: ldr     x28, [x28, #0x608]                         M:FrameWorkUtility/<>c__DisplayClass50_1::<MutipleRayCastAll>b__1
02cf0f34: ldr     x29, [x29, #0x5e8]                         MS:System.Collections.Generic.List`1::Find
02cf0f38: mov     x24, xzr                                   
02cf0f3c: add     x27, x20, #0x20                            &662f020
02cf0f40: ldr     x0, [x25]                                  S:'{0}/2'
02cf0f44: bl      #0x2b7104c                                 fn_2b7104c
02cf0f48: mov     x1, xzr                                    
02cf0f4c: mov     x21, x0                                    
02cf0f50: bl      #0x4e53e9c                                 System.Object::.ctor
02cf0f54: ldr     w8, [x20, #0x18]                           [662f018]=6000014 f=2.40742e-35,0
02cf0f58: cmp     x24, x8                                    
02cf0f5c: b.hs    #0x2cf10e8                                 
02cf0f60: cbz     x21, #0x2cf10e4                            
02cf0f64: ldp     q1, q0, [x27]                              
02cf0f68: add     x0, x21, #0x10                             
02cf0f6c: ldr     w8, [x27, #0x20]                           T:LuckyWheelPopup/<SpinAnimation>d__51
02cf0f70: mov     x1, xzr                                    
02cf0f74: str     w8, [x21, #0x30]                           
02cf0f78: stp     q1, q0, [x21, #0x10]                       
02cf0f7c: bl      #0x5bbe11c                                 UnityEngine.RaycastHit2D::get_collider
02cf0f80: ldr     x8, [x26]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cf0f84: mov     x22, x0                                    
02cf0f88: ldr     w9, [x8, #0xe4]                            [62660e4]=0 f=0,0
02cf0f8c: cbnz    w9, #0x2cf0f98                             
02cf0f90: mov     x0, x8                                     
02cf0f94: bl      #0x2b70f30                                 fn_2b70f30
02cf0f98: mov     x0, x22                                    
02cf0f9c: mov     x1, xzr                                    
02cf0fa0: mov     x2, xzr                                    
02cf0fa4: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02cf0fa8: tbz     w0, #0, #0x2cf10a0                         
02cf0fac: adrp    x8, #0x6268000                             
02cf0fb0: ldr     x22, [x19]                                 
02cf0fb4: ldr     x8, [x8, #0x5f0]                           T:type57275(k15)
02cf0fb8: ldr     x0, [x8]                                   S:'{0}/2'
02cf0fbc: bl      #0x2b7104c                                 fn_2b7104c
02cf0fc0: ldr     x2, [x28]                                  S:'{0}/2'
02cf0fc4: mov     x1, x21                                    
02cf0fc8: mov     x3, xzr                                    
02cf0fcc: mov     x23, x0                                    
02cf0fd0: bl      #0x399c5b0                                 fn_399c5b0
02cf0fd4: cbz     x22, #0x2cf10e4                            
02cf0fd8: ldr     x2, [x29]                                  S:'{0}/2'
02cf0fdc: add     x8, sp, #0xd0                              
02cf0fe0: mov     x0, x22                                    
02cf0fe4: mov     x1, x23                                    
02cf0fe8: bl      #0x35cc228                                 fn_35cc228
02cf0fec: ldp     q0, q1, [sp, #0xd0]                        
02cf0ff0: add     x0, sp, #0x30                              
02cf0ff4: ldr     w8, [sp, #0xf0]                            
02cf0ff8: mov     x1, xzr                                    
02cf0ffc: stp     q0, q1, [sp, #0x30]                        
02cf1000: str     w8, [sp, #0x50]                            
02cf1004: bl      #0x5bbe3c8                                 UnityEngine.RaycastHit2D::op_Implicit
02cf1008: tbnz    w0, #0, #0x2cf10a0                         
02cf100c: ldr     x0, [x19]                                  
02cf1010: cbz     x0, #0x2cf10e4                             
02cf1014: ldp     q0, q1, [x21, #0x10]                       
02cf1018: ldur    w9, [x21, #0x30]                           
02cf101c: ldr     w10, [x0, #0x1c]                           [626501c]=0 f=0,0
02cf1020: ldr     x8, [x0, #0x10]                            MS:MonoSingleton`1::get_Instance
02cf1024: str     w9, [sp, #0xc0]                            
02cf1028: adrp    x9, #0x6268000                             
02cf102c: stp     q0, q1, [sp, #0xa0]                        
02cf1030: add     w10, w10, #1                               
02cf1034: ldr     x9, [x9, #0x5d8]                           MS:System.Collections.Generic.List`1::Add
02cf1038: str     w10, [x0, #0x1c]                           
02cf103c: ldr     x9, [x9]                                   S:'{0}/2'
02cf1040: cbz     x8, #0x2cf10e4                             
02cf1044: ldrsw   x10, [x0, #0x18]                           
02cf1048: ldr     w11, [x8, #0x18]                           M:LuckyWheelPopup/<>c__DisplayClass50_0::<RunAnimation>b__0
02cf104c: cmp     w10, w11                                   
02cf1050: b.hs    #0x2cf107c                                 
02cf1054: mov     w9, #0x24                                  
02cf1058: ldp     q0, q1, [sp, #0xa0]                        
02cf105c: nop                                                
02cf1060: smaddl  x8, w10, w9, x8                            
02cf1064: add     w9, w10, #1                                
02cf1068: str     w9, [x0, #0x18]                            
02cf106c: ldr     w9, [sp, #0xc0]                            
02cf1070: stp     q0, q1, [x8, #0x20]                        
02cf1074: str     w9, [x8, #0x40]                            
02cf1078: b       #0x2cf10a0                                 
02cf107c: ldr     x8, [x9, #0x20]                            T:LuckyWheelPopup/<SpinAnimation>d__51
02cf1080: ldp     q0, q1, [sp, #0xa0]                        
02cf1084: ldr     w9, [sp, #0xc0]                            
02cf1088: add     x1, sp, #0xd0                              
02cf108c: ldr     x8, [x8, #0xc0]                            M:LuckyWheelPopup/<>c__DisplayClass54_0::<GetMoney>b__0
02cf1090: ldr     x2, [x8, #0x70]                            T:type57276(k15)
02cf1094: stp     q0, q1, [sp, #0xd0]                        
02cf1098: str     w9, [sp, #0xf0]                            
02cf109c: bl      #0x35cbb0c                                 fn_35cbb0c
02cf10a0: ldrsw   x8, [x20, #0x18]                           
02cf10a4: add     x24, x24, #1                               
02cf10a8: add     x27, x27, #0x24                            &6268024
02cf10ac: cmp     x24, x8                                    
02cf10b0: b.lt    #0x2cf0f40                                 
02cf10b4: ldp     x20, x19, [sp, #0x190]                     
02cf10b8: ldp     x22, x21, [sp, #0x180]                     
02cf10bc: ldp     x24, x23, [sp, #0x170]                     
02cf10c0: ldp     x26, x25, [sp, #0x160]                     
02cf10c4: ldp     x28, x27, [sp, #0x150]                     
02cf10c8: ldp     x29, x30, [sp, #0x140]                     
02cf10cc: ldp     d9, d8, [sp, #0x130]                       
02cf10d0: ldp     d11, d10, [sp, #0x120]                     
02cf10d4: ldp     d13, d12, [sp, #0x110]                     
02cf10d8: ldp     d15, d14, [sp, #0x100]                     
02cf10dc: add     sp, sp, #0x1a0                             
02cf10e0: ret                                                
02cf10e4: bl      #0x2b7105c                                 fn_2b7105c
02cf10e8: bl      #0x2b71064                                 fn_2b71064
## MutipleRayCast(UnityEngine.Vector2 original, UnityEngine.Vector2 point1, UnityEngine.Vector2 point2, float distance, int layer) -> UnityEngine.RaycastHit2D
---- FrameWorkUtility::MutipleRayCast 0x2cf10fc
02cf10fc: sub     sp, sp, #0x120                             
02cf1100: stp     d15, d14, [sp, #0x80]                      
02cf1104: stp     d13, d12, [sp, #0x90]                      
02cf1108: stp     d11, d10, [sp, #0xa0]                      
02cf110c: stp     d9, d8, [sp, #0xb0]                        
02cf1110: stp     x29, x30, [sp, #0xc0]                      
02cf1114: stp     x28, x27, [sp, #0xd0]                      
02cf1118: stp     x26, x25, [sp, #0xe0]                      
02cf111c: stp     x24, x23, [sp, #0xf0]                      
02cf1120: stp     x22, x21, [sp, #0x100]                     
02cf1124: stp     x20, x19, [sp, #0x110]                     
02cf1128: fmov    s12, s6                                    
02cf112c: fmov    s10, s5                                    
02cf1130: adrp    x21, #0x662f000                            
02cf1134: fmov    s11, s4                                    
02cf1138: fmov    s8, s1                                     
02cf113c: ldrb    w9, [x21, #0xe5e]                          
02cf1140: fmov    s9, s0                                     
02cf1144: mov     w20, w0                                    
02cf1148: mov     x19, x8                                    
02cf114c: stp     s2, s3, [sp, #0x14]                        
02cf1150: tbnz    w9, #0, #0x2cf1174                         
02cf1154: adrp    x0, #0x6263000                             
02cf1158: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02cf115c: bl      #0x2b70db0                                 fn_2b70db0
02cf1160: adrp    x0, #0x6266000                             
02cf1164: ldr     x0, [x0, #0x940]                           T:UnityEngine.Physics2D
02cf1168: bl      #0x2b70db0                                 fn_2b70db0
02cf116c: mov     w8, #1                                     
02cf1170: strb    w8, [x21, #0xe5e]                          
02cf1174: ldp     s1, s2, [sp, #0x14]                        
02cf1178: movi    v0.2d, #0000000000000000                   
02cf117c: add     x0, sp, #0x78                              
02cf1180: mov     x1, xzr                                    
02cf1184: stp     xzr, xzr, [sp, #0x70]                      
02cf1188: stp     s11, s10, [sp, #8]                         
02cf118c: fsub    s1, s11, s1                                
02cf1190: fsub    s2, s10, s2                                
02cf1194: str     wzr, [sp, #0x60]                           
02cf1198: stp     q0, q0, [sp, #0x40]                        
02cf119c: stp     s1, s2, [sp, #0x78]                        
02cf11a0: bl      #0x5b28290                                 UnityEngine.Vector2::Normalize
02cf11a4: fmov    s10, s1                                    
02cf11a8: adrp    x23, #0x662f000                            
02cf11ac: str     s0, [sp, #0x10]                            
02cf11b0: ldrb    w8, [x23, #0xca9]                          
02cf11b4: cbnz    w8, #0x2cf11cc                             
02cf11b8: adrp    x0, #0x6265000                             
02cf11bc: ldr     x0, [x0, #0xb48]                           T:System.Math
02cf11c0: bl      #0x2b70db0                                 fn_2b70db0
02cf11c4: mov     w8, #1                                     
02cf11c8: strb    w8, [x23, #0xca9]                          
02cf11cc: adrp    x21, #0x6265000                            
02cf11d0: ldr     x21, [x21, #0xb48]                         T:System.Math
02cf11d4: ldr     d11, [sp, #0x78]                           
02cf11d8: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02cf11dc: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02cf11e0: cbnz    w8, #0x2cf11e8                             
02cf11e4: bl      #0x2b70f30                                 fn_2b70f30
02cf11e8: fmul    v0.2s, v11.2s, v11.2s                      
02cf11ec: mov     w8, #0x7f800000                            
02cf11f0: adrp    x24, #0x6266000                            
02cf11f4: fmov    s1, w8                                     
02cf11f8: mov     w8, #-0xffffffff80000000                   
02cf11fc: ldr     x24, [x24, #0x940]                         T:UnityEngine.Physics2D
02cf1200: faddp   s0, v0.2s                                  
02cf1204: fsqrt   s0, s0                                     
02cf1208: fdiv    s0, s0, s12                                
02cf120c: fcvtzs  w9, s0                                     
02cf1210: fcmp    s0, s1                                     
02cf1214: csel    w25, w8, w9, eq                            
02cf1218: tbnz    w25, #0x1f, #0x2cf1330                     
02cf121c: adrp    x27, #0x6263000                            
02cf1220: mov     w26, wzr                                   
02cf1224: mov     w28, #1                                    
02cf1228: ldr     x27, [x27, #0x918]                         T:UnityEngine.Object
02cf122c: scvtf   s0, w26                                    
02cf1230: ldp     s1, s2, [sp, #0x10]                        
02cf1234: add     x0, sp, #0x70                              
02cf1238: mov     x1, xzr                                    
02cf123c: fmul    s1, s1, s0                                 
02cf1240: fmul    s0, s10, s0                                
02cf1244: fmul    s1, s1, s12                                
02cf1248: fmul    s0, s0, s12                                
02cf124c: fadd    s1, s2, s1                                 
02cf1250: ldr     s2, [sp, #0x18]                            
02cf1254: fadd    s0, s2, s0                                 
02cf1258: fsub    s1, s1, s9                                 
02cf125c: fsub    s0, s0, s8                                 
02cf1260: stp     s1, s0, [sp, #0x70]                        
02cf1264: bl      #0x5b28290                                 UnityEngine.Vector2::Normalize
02cf1268: fmov    s11, s0                                    
02cf126c: fmov    s13, s1                                    
02cf1270: ldrb    w8, [x23, #0xca9]                          
02cf1274: cbnz    w8, #0x2cf1284                             
02cf1278: mov     x0, x21                                    
02cf127c: bl      #0x2b70db0                                 fn_2b70db0
02cf1280: strb    w28, [x23, #0xca9]                         
02cf1284: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02cf1288: ldp     s14, s15, [sp, #0x70]                      
02cf128c: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02cf1290: cbnz    w8, #0x2cf1298                             
02cf1294: bl      #0x2b70f30                                 fn_2b70f30
02cf1298: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cf129c: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02cf12a0: cbnz    w8, #0x2cf12a8                             
02cf12a4: bl      #0x2b70f30                                 fn_2b70f30
02cf12a8: fmul    s0, s14, s14                               
02cf12ac: fmul    s1, s15, s15                               
02cf12b0: fmov    s2, s11                                    
02cf12b4: fmov    s3, s13                                    
02cf12b8: add     x8, sp, #0x1c                              
02cf12bc: mov     w0, w20                                    
02cf12c0: mov     x1, xzr                                    
02cf12c4: fadd    s0, s0, s1                                 
02cf12c8: fmov    s1, s8                                     
02cf12cc: fsqrt   s4, s0                                     
02cf12d0: fmov    s0, s9                                     
02cf12d4: bl      #0x5bbcb94                                 UnityEngine.Physics2D::Raycast
02cf12d8: ldur    q0, [sp, #0x1c]                            
02cf12dc: ldur    q1, [sp, #0x2c]                            
02cf12e0: add     x0, sp, #0x40                              
02cf12e4: ldr     w8, [sp, #0x3c]                            
02cf12e8: mov     x1, xzr                                    
02cf12ec: stp     q0, q1, [sp, #0x40]                        
02cf12f0: str     w8, [sp, #0x60]                            
02cf12f4: bl      #0x5bbe11c                                 UnityEngine.RaycastHit2D::get_collider
02cf12f8: ldr     x8, [x27]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cf12fc: mov     x22, x0                                    
02cf1300: ldr     w9, [x8, #0xe4]                            
02cf1304: cbnz    w9, #0x2cf1310                             
02cf1308: mov     x0, x8                                     
02cf130c: bl      #0x2b70f30                                 fn_2b70f30
02cf1310: mov     x0, x22                                    
02cf1314: mov     x1, xzr                                    
02cf1318: mov     x2, xzr                                    
02cf131c: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02cf1320: tbnz    w0, #0, #0x2cf13e0                         
02cf1324: add     w26, w26, #1                               
02cf1328: cmp     w26, w25                                   
02cf132c: b.le    #0x2cf122c                                 
02cf1330: ldp     s0, s1, [sp, #8]                           
02cf1334: add     x0, sp, #0x70                              
02cf1338: mov     x1, xzr                                    
02cf133c: fsub    s0, s0, s9                                 
02cf1340: fsub    s1, s1, s8                                 
02cf1344: stp     s0, s1, [sp, #0x70]                        
02cf1348: bl      #0x5b28290                                 UnityEngine.Vector2::Normalize
02cf134c: fmov    s10, s0                                    
02cf1350: fmov    s11, s1                                    
02cf1354: ldrb    w8, [x23, #0xca9]                          
02cf1358: cbnz    w8, #0x2cf1370                             
02cf135c: adrp    x0, #0x6265000                             
02cf1360: ldr     x0, [x0, #0xb48]                           T:System.Math
02cf1364: bl      #0x2b70db0                                 fn_2b70db0
02cf1368: mov     w8, #1                                     
02cf136c: strb    w8, [x23, #0xca9]                          
02cf1370: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02cf1374: ldp     s12, s13, [sp, #0x70]                      
02cf1378: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02cf137c: cbnz    w8, #0x2cf1384                             
02cf1380: bl      #0x2b70f30                                 fn_2b70f30
02cf1384: fmul    s0, s12, s12                               
02cf1388: fmul    s1, s13, s13                               
02cf138c: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cf1390: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02cf1394: fadd    s0, s0, s1                                 
02cf1398: fsqrt   s12, s0                                    
02cf139c: cbnz    w8, #0x2cf13a4                             
02cf13a0: bl      #0x2b70f30                                 fn_2b70f30
02cf13a4: fmov    s0, s9                                     
02cf13a8: fmov    s1, s8                                     
02cf13ac: add     x8, sp, #0x1c                              
02cf13b0: fmov    s2, s10                                    
02cf13b4: fmov    s3, s11                                    
02cf13b8: mov     w0, w20                                    
02cf13bc: fmov    s4, s12                                    
02cf13c0: mov     x1, xzr                                    
02cf13c4: bl      #0x5bbcb94                                 UnityEngine.Physics2D::Raycast
02cf13c8: ldur    q0, [sp, #0x1c]                            
02cf13cc: ldur    q1, [sp, #0x2c]                            
02cf13d0: ldr     w8, [sp, #0x3c]                            
02cf13d4: stp     q0, q1, [sp, #0x40]                        
02cf13d8: str     w8, [sp, #0x60]                            
02cf13dc: b       #0x2cf13e8                                 
02cf13e0: ldp     q0, q1, [sp, #0x40]                        
02cf13e4: ldr     w8, [sp, #0x60]                            
02cf13e8: stp     q0, q1, [x19]                              
02cf13ec: ldp     x22, x21, [sp, #0x100]                     
02cf13f0: str     w8, [x19, #0x20]                           
02cf13f4: ldp     x20, x19, [sp, #0x110]                     
02cf13f8: ldp     x24, x23, [sp, #0xf0]                      
02cf13fc: ldp     x26, x25, [sp, #0xe0]                      
02cf1400: ldp     x28, x27, [sp, #0xd0]                      
02cf1404: ldp     x29, x30, [sp, #0xc0]                      
02cf1408: ldp     d9, d8, [sp, #0xb0]                        
02cf140c: ldp     d11, d10, [sp, #0xa0]                      
02cf1410: ldp     d13, d12, [sp, #0x90]                      
02cf1414: ldp     d15, d14, [sp, #0x80]                      
02cf1418: add     sp, sp, #0x120                             
02cf141c: ret                                                
## DrawPlane(UnityEngine.Vector3 normal, UnityEngine.Vector3 position) -> void
---- FrameWorkUtility::DrawPlane 0x2cf1420
02cf1420: sub     sp, sp, #0xd0                              
02cf1424: stp     d15, d14, [sp, #0x50]                      
02cf1428: stp     d13, d12, [sp, #0x60]                      
02cf142c: stp     d11, d10, [sp, #0x70]                      
02cf1430: stp     d9, d8, [sp, #0x80]                        
02cf1434: str     x30, [sp, #0x90]                           
02cf1438: stp     x24, x23, [sp, #0xa0]                      
02cf143c: stp     x22, x21, [sp, #0xb0]                      
02cf1440: stp     x20, x19, [sp, #0xc0]                      
02cf1444: fmov    s15, s2                                    
02cf1448: fmov    s8, s1                                     
02cf144c: adrp    x19, #0x662f000                            
02cf1450: fmov    s10, s0                                    
02cf1454: ldrb    w8, [x19, #0xe5f]                          
02cf1458: stp     s4, s5, [sp, #0x3c]                        
02cf145c: str     s3, [sp, #0x30]                            
02cf1460: tbnz    w8, #0, #0x2cf1478                         
02cf1464: adrp    x0, #0x6263000                             
02cf1468: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02cf146c: bl      #0x2b70db0                                 fn_2b70db0
02cf1470: mov     w8, #1                                     
02cf1474: strb    w8, [x19, #0xe5f]                          
02cf1478: adrp    x23, #0x662f000                            
02cf147c: ldrb    w8, [x23, #0xca8]                          
02cf1480: cbnz    w8, #0x2cf1498                             
02cf1484: adrp    x0, #0x6264000                             
02cf1488: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02cf148c: bl      #0x2b70db0                                 fn_2b70db0
02cf1490: mov     w8, #1                                     
02cf1494: strb    w8, [x23, #0xca8]                          
02cf1498: adrp    x20, #0x662f000                            
02cf149c: ldrb    w8, [x20, #0xca7]                          
02cf14a0: cbnz    w8, #0x2cf14b8                             
02cf14a4: adrp    x0, #0x6265000                             
02cf14a8: ldr     x0, [x0, #0xb48]                           T:System.Math
02cf14ac: bl      #0x2b70db0                                 fn_2b70db0
02cf14b0: mov     w8, #1                                     
02cf14b4: strb    w8, [x20, #0xca7]                          
02cf14b8: adrp    x22, #0x6265000                            
02cf14bc: ldr     x22, [x22, #0xb48]                         T:System.Math
02cf14c0: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02cf14c4: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02cf14c8: cbnz    w8, #0x2cf14d0                             
02cf14cc: bl      #0x2b70f30                                 fn_2b70f30
02cf14d0: fmul    s0, s10, s10                               
02cf14d4: fmul    s1, s8, s8                                 
02cf14d8: adrp    x8, #0x1084000                             
02cf14dc: adrp    x19, #0x6264000                            
02cf14e0: fadd    s0, s0, s1                                 
02cf14e4: fmul    s1, s15, s15                               
02cf14e8: fadd    s0, s1, s0                                 
02cf14ec: fsqrt   s9, s0                                     
02cf14f0: ldr     s0, [x8, #0xfe0]                           [1084fe0]=3d5df3603727c5ac f=1e-05,0.0541872
02cf14f4: str     s0, [sp, #0x38]                            
02cf14f8: ldr     x19, [x19, #0xd8]                          T:UnityEngine.Vector3
02cf14fc: str     s10, [sp, #0x98]                           
02cf1500: fcmp    s9, s0                                     
02cf1504: b.le    #0x2cf1518                                 
02cf1508: fdiv    s12, s10, s9                               
02cf150c: fdiv    s11, s8, s9                                
02cf1510: fdiv    s10, s15, s9                               
02cf1514: b       #0x2cf1528                                 
02cf1518: ldr     x8, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cf151c: ldr     x8, [x8, #0xb8]                            [10840b8]=2632726f74636556 f=7.20646e+31,6.19112e-16
02cf1520: ldp     s11, s10, [x8, #4]                         
02cf1524: ldr     s12, [x8]                                  [1084000]=287475706e49646c f=1.5582e+28,1.35702e-14
02cf1528: adrp    x21, #0x662f000                            
02cf152c: str     s8, [sp, #0x9c]                            
02cf1530: ldrb    w8, [x21, #0x91c]                          
02cf1534: cbnz    w8, #0x2cf154c                             
02cf1538: adrp    x0, #0x6264000                             
02cf153c: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02cf1540: bl      #0x2b70db0                                 fn_2b70db0
02cf1544: mov     w8, #1                                     
02cf1548: strb    w8, [x21, #0x91c]                          
02cf154c: ldr     x8, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cf1550: adrp    x9, #0x1084000                             
02cf1554: fmov    s8, s15                                    
02cf1558: adrp    x21, #0x6263000                            
02cf155c: ldr     x8, [x8, #0xb8]                            [10840b8]=2632726f74636556 f=7.20646e+31,6.19112e-16
02cf1560: ldp     s13, s14, [x8, #0x48]                      
02cf1564: fsub    s0, s12, s13                               
02cf1568: fsub    s1, s11, s14                               
02cf156c: ldr     s11, [x8, #0x50]                           [1084050]=69737968502e656e f=1.17035e+10,1.83964e+25
02cf1570: ldr     x21, [x21, #0x928]                         T:UnityEngine.Debug
02cf1574: fsub    s2, s10, s11                               
02cf1578: fmul    s0, s0, s0                                 
02cf157c: fmul    s1, s1, s1                                 
02cf1580: fadd    s0, s0, s1                                 
02cf1584: fmul    s1, s2, s2                                 
02cf1588: fadd    s0, s1, s0                                 
02cf158c: ldr     s1, [x9, #0xbd0]                           [1084bd0]=3f6666662edbe6fe f=1e-10,0.9
02cf1590: fcmp    s0, s1                                     
02cf1594: b.mi    #0x2cf1600                                 
02cf1598: ldrb    w8, [x23, #0xca8]                          
02cf159c: cbnz    w8, #0x2cf15b4                             
02cf15a0: adrp    x0, #0x6264000                             
02cf15a4: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02cf15a8: bl      #0x2b70db0                                 fn_2b70db0
02cf15ac: mov     w8, #1                                     
02cf15b0: strb    w8, [x23, #0xca8]                          
02cf15b4: ldp     s1, s0, [sp, #0x98]                        
02cf15b8: fmul    s12, s15, s14                              
02cf15bc: fmul    s15, s15, s13                              
02cf15c0: ldrb    w8, [x20, #0xca7]                          
02cf15c4: fmul    s10, s0, s11                               
02cf15c8: fmul    s11, s1, s11                               
02cf15cc: fmul    s14, s1, s14                               
02cf15d0: fmul    s13, s0, s13                               
02cf15d4: cbnz    w8, #0x2cf15ec                             
02cf15d8: adrp    x0, #0x6265000                             
02cf15dc: ldr     x0, [x0, #0xb48]                           T:System.Math
02cf15e0: bl      #0x2b70db0                                 fn_2b70db0
02cf15e4: mov     w8, #1                                     
02cf15e8: strb    w8, [x20, #0xca7]                          
02cf15ec: fsub    s10, s10, s12                              
02cf15f0: fsub    s11, s15, s11                              
02cf15f4: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02cf15f8: fsub    s12, s14, s13                              
02cf15fc: b       #0x2cf1698                                 
02cf1600: adrp    x24, #0x662f000                            
02cf1604: ldrb    w9, [x24, #0x918]                          
02cf1608: cbnz    w9, #0x2cf1624                             
02cf160c: mov     x0, x19                                    
02cf1610: bl      #0x2b70db0                                 fn_2b70db0
02cf1614: ldr     x8, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cf1618: mov     w9, #1                                     
02cf161c: strb    w9, [x24, #0x918]                          
02cf1620: ldr     x8, [x8, #0xb8]                            [10840b8]=2632726f74636556 f=7.20646e+31,6.19112e-16
02cf1624: ldp     s15, s14, [x8, #0x18]                      
02cf1628: ldrb    w9, [x23, #0xca8]                          
02cf162c: ldr     s13, [x8, #0x20]                           [1084020]=79654b7465533a3a f=6.23433e+22,7.44104e+34
02cf1630: cbnz    w9, #0x2cf1648                             
02cf1634: adrp    x0, #0x6264000                             
02cf1638: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02cf163c: bl      #0x2b70db0                                 fn_2b70db0
02cf1640: mov     w8, #1                                     
02cf1644: strb    w8, [x23, #0xca8]                          
02cf1648: fmov    s0, s8                                     
02cf164c: ldr     s1, [sp, #0x9c]                            
02cf1650: fmul    s11, s8, s14                               
02cf1654: ldr     s0, [sp, #0x98]                            
02cf1658: fmul    s12, s8, s15                               
02cf165c: ldrb    w8, [x20, #0xca7]                          
02cf1660: fmul    s10, s1, s13                               
02cf1664: fmul    s15, s1, s15                               
02cf1668: fmul    s13, s0, s13                               
02cf166c: fmul    s14, s0, s14                               
02cf1670: cbnz    w8, #0x2cf1688                             
02cf1674: adrp    x0, #0x6265000                             
02cf1678: ldr     x0, [x0, #0xb48]                           T:System.Math
02cf167c: bl      #0x2b70db0                                 fn_2b70db0
02cf1680: mov     w8, #1                                     
02cf1684: strb    w8, [x20, #0xca7]                          
02cf1688: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02cf168c: fsub    s10, s10, s11                              
02cf1690: fsub    s11, s12, s13                              
02cf1694: fsub    s12, s14, s15                              
02cf1698: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02cf169c: cbnz    w8, #0x2cf16a4                             
02cf16a0: bl      #0x2b70f30                                 fn_2b70f30
02cf16a4: fmul    s0, s10, s10                               
02cf16a8: fmul    s1, s11, s11                               
02cf16ac: fmov    s13, s8                                    
02cf16b0: fadd    s0, s0, s1                                 
02cf16b4: fmul    s1, s12, s12                               
02cf16b8: fadd    s0, s1, s0                                 
02cf16bc: ldr     s1, [sp, #0x38]                            
02cf16c0: fsqrt   s0, s0                                     
02cf16c4: fcmp    s0, s1                                     
02cf16c8: b.le    #0x2cf16dc                                 
02cf16cc: fdiv    s10, s10, s0                               
02cf16d0: fdiv    s11, s11, s0                               
02cf16d4: fdiv    s8, s12, s0                                
02cf16d8: b       #0x2cf16ec                                 
02cf16dc: ldr     x8, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cf16e0: ldr     x8, [x8, #0xb8]                            [10840b8]=2632726f74636556 f=7.20646e+31,6.19112e-16
02cf16e4: ldp     s11, s8, [x8, #4]                          
02cf16e8: ldr     s10, [x8]                                  [1084000]=287475706e49646c f=1.5582e+28,1.35702e-14
02cf16ec: ldrb    w8, [x20, #0xca7]                          
02cf16f0: cbnz    w8, #0x2cf1708                             
02cf16f4: adrp    x0, #0x6265000                             
02cf16f8: ldr     x0, [x0, #0xb48]                           T:System.Math
02cf16fc: bl      #0x2b70db0                                 fn_2b70db0
02cf1700: mov     w8, #1                                     
02cf1704: strb    w8, [x20, #0xca7]                          
02cf1708: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02cf170c: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02cf1710: cbnz    w8, #0x2cf1718                             
02cf1714: bl      #0x2b70f30                                 fn_2b70f30
02cf1718: ldp     s1, s0, [sp, #0x98]                        
02cf171c: mov     w8, #0x42b40000                            
02cf1720: add     x0, sp, #0x44                              
02cf1724: mov     x1, xzr                                    
02cf1728: str     s13, [sp, #0x2c]                           
02cf172c: fmul    s8, s9, s8                                 
02cf1730: fmul    s12, s9, s11                               
02cf1734: str     s13, [sp, #0x4c]                           
02cf1738: stp     s1, s0, [sp, #0x44]                        
02cf173c: fmov    s0, w8                                     
02cf1740: fmul    s10, s9, s10                               
02cf1744: bl      #0x5b2620c                                 UnityEngine.Quaternion::Internal_AngleAxis
02cf1748: fmov    s4, s10                                    
02cf174c: fmov    s5, s12                                    
02cf1750: mov     x0, xzr                                    
02cf1754: fmov    s6, s8                                     
02cf1758: bl      #0x5b26598                                 UnityEngine.Quaternion::op_Multiply
02cf175c: fmov    s11, s0                                    
02cf1760: fmov    s9, s1                                     
02cf1764: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cf1768: fmov    s13, s2                                    
02cf176c: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02cf1770: cbnz    w8, #0x2cf1778                             
02cf1774: bl      #0x2b70f30                                 fn_2b70f30
02cf1778: ldr     s0, [sp, #0x40]                            
02cf177c: ldr     s1, [sp, #0x3c]                            
02cf1780: mov     x0, xzr                                    
02cf1784: ldr     s14, [sp, #0x30]                           
02cf1788: mov     w20, #0x42c80000                           
02cf178c: mov     x19, #0x3f80000000000000                   
02cf1790: fsub    s6, s0, s13                                
02cf1794: fsub    s3, s1, s9                                 
02cf1798: fadd    s15, s0, s13                               
02cf179c: fsub    s2, s14, s11                               
02cf17a0: fsub    s5, s0, s8                                 
02cf17a4: fsub    s4, s1, s12                                
02cf17a8: fadd    s13, s0, s8                                
02cf17ac: fadd    s8, s1, s12                                
02cf17b0: fadd    s12, s14, s10                              
02cf17b4: fadd    s9, s1, s9                                 
02cf17b8: fadd    s11, s14, s11                              
02cf17bc: str     w20, [sp, #0x10]                           
02cf17c0: stp     x19, x19, [sp]                             
02cf17c4: stp     s3, s2, [sp, #0x34]                        
02cf17c8: fsub    s3, s14, s10                               
02cf17cc: fmov    s0, s12                                    
02cf17d0: fmov    s1, s8                                     
02cf17d4: fmov    s2, s13                                    
02cf17d8: stp     s4, s5, [sp, #0x24]                        
02cf17dc: stp     s6, s3, [sp, #0x1c]                        
02cf17e0: bl      #0x5af1b20                                 UnityEngine.Debug::DrawLine
02cf17e4: ldr     s10, [sp, #0x1c]                           
02cf17e8: fmov    s0, s11                                    
02cf17ec: fmov    s1, s9                                     
02cf17f0: fmov    s2, s15                                    
02cf17f4: ldp     s4, s3, [sp, #0x34]                        
02cf17f8: fmov    s5, s10                                    
02cf17fc: mov     x0, xzr                                    
02cf1800: str     w20, [sp, #0x10]                           
02cf1804: stp     x19, x19, [sp]                             
02cf1808: bl      #0x5af1b20                                 UnityEngine.Debug::DrawLine
02cf180c: fmov    s0, s12                                    
02cf1810: fmov    s1, s8                                     
02cf1814: mov     x0, xzr                                    
02cf1818: fmov    s2, s13                                    
02cf181c: fmov    s3, s11                                    
02cf1820: str     w20, [sp, #0x10]                           
02cf1824: fmov    s4, s9                                     
02cf1828: fmov    s5, s15                                    
02cf182c: stp     x19, x19, [sp]                             
02cf1830: bl      #0x5af1b20                                 UnityEngine.Debug::DrawLine
02cf1834: fmov    s0, s11                                    
02cf1838: fmov    s2, s15                                    
02cf183c: mov     x0, xzr                                    
02cf1840: ldp     s15, s11, [sp, #0x20]                      
02cf1844: fmov    s1, s9                                     
02cf1848: ldr     s9, [sp, #0x28]                            
02cf184c: str     w20, [sp, #0x10]                           
02cf1850: stp     x19, x19, [sp]                             
02cf1854: fmov    s3, s15                                    
02cf1858: fmov    s4, s11                                    
02cf185c: fmov    s5, s9                                     
02cf1860: bl      #0x5af1b20                                 UnityEngine.Debug::DrawLine
02cf1864: fmov    s1, s11                                    
02cf1868: fmov    s2, s9                                     
02cf186c: mov     x0, xzr                                    
02cf1870: ldp     s9, s11, [sp, #0x34]                       
02cf1874: fmov    s0, s15                                    
02cf1878: fmov    s5, s10                                    
02cf187c: str     w20, [sp, #0x10]                           
02cf1880: stp     x19, x19, [sp]                             
02cf1884: fmov    s3, s11                                    
02cf1888: fmov    s4, s9                                     
02cf188c: bl      #0x5af1b20                                 UnityEngine.Debug::DrawLine
02cf1890: fmov    s0, s11                                    
02cf1894: fmov    s1, s9                                     
02cf1898: mov     x0, xzr                                    
02cf189c: fmov    s2, s10                                    
02cf18a0: fmov    s3, s12                                    
02cf18a4: str     w20, [sp, #0x10]                           
02cf18a8: fmov    s4, s8                                     
02cf18ac: fmov    s5, s13                                    
02cf18b0: stp     x19, x19, [sp]                             
02cf18b4: bl      #0x5af1b20                                 UnityEngine.Debug::DrawLine
02cf18b8: fmov    s0, s14                                    
02cf18bc: ldp     s1, s2, [sp, #0x3c]                        
02cf18c0: ldp     s3, s4, [sp, #0x98]                        
02cf18c4: mov     x0, xzr                                    
02cf18c8: ldr     s5, [sp, #0x2c]                            
02cf18cc: mov     w8, #0x3f800000                            
02cf18d0: stp     x8, x19, [sp]                              
02cf18d4: bl      #0x5af1e20                                 UnityEngine.Debug::DrawRay
02cf18d8: ldp     x20, x19, [sp, #0xc0]                      
02cf18dc: ldr     x30, [sp, #0x90]                           
02cf18e0: ldp     x22, x21, [sp, #0xb0]                      
02cf18e4: ldp     x24, x23, [sp, #0xa0]                      
02cf18e8: ldp     d9, d8, [sp, #0x80]                        
02cf18ec: ldp     d11, d10, [sp, #0x70]                      
02cf18f0: ldp     d13, d12, [sp, #0x60]                      
02cf18f4: ldp     d15, d14, [sp, #0x50]                      
02cf18f8: add     sp, sp, #0xd0                              
02cf18fc: ret                                                
## GetRating(float target) -> bool
---- FrameWorkUtility::GetRating 0x2cf1900
02cf1900: str     d8, [sp, #-0x10]!                          
02cf1904: str     x30, [sp, #8]                              
02cf1908: mov     x0, xzr                                    
02cf190c: fmov    s8, s0                                     
02cf1910: bl      #0x5b2e088                                 UnityEngine.Random::get_value
02cf1914: fcmp    s0, s8                                     
02cf1918: ldr     x30, [sp, #8]                              
02cf191c: cset    w0, ls                                     
02cf1920: ldr     d8, [sp], #0x10                            
02cf1924: ret                                                
## SetActive(UnityEngine.CanvasGroup canvasGroup, bool isActive, float fadeTime) -> void
---- FrameWorkUtility::SetActive 0x2cf1928
02cf1928: str     d8, [sp, #-0x30]!                          
02cf192c: str     x30, [sp, #8]                              
02cf1930: stp     x22, x21, [sp, #0x10]                      
02cf1934: stp     x20, x19, [sp, #0x20]                      
02cf1938: fmov    s8, s0                                     
02cf193c: adrp    x21, #0x662f000                            
02cf1940: adrp    x22, #0x6263000                            
02cf1944: ldrb    w8, [x21, #0xe60]                          
02cf1948: ldr     x22, [x22, #0x918]                         T:UnityEngine.Object
02cf194c: mov     w19, w1                                    
02cf1950: mov     x20, x0                                    
02cf1954: tbnz    w8, #0, #0x2cf196c                         
02cf1958: adrp    x0, #0x6263000                             
02cf195c: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02cf1960: bl      #0x2b70db0                                 fn_2b70db0
02cf1964: mov     w8, #1                                     
02cf1968: strb    w8, [x21, #0xe60]                          
02cf196c: ldr     x0, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cf1970: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02cf1974: cbnz    w8, #0x2cf197c                             
02cf1978: bl      #0x2b70f30                                 fn_2b70f30
02cf197c: mov     x0, x20                                    
02cf1980: mov     x1, xzr                                    
02cf1984: mov     x2, xzr                                    
02cf1988: bl      #0x5b37d84                                 UnityEngine.Object::op_Equality
02cf198c: tbz     w0, #0, #0x2cf19a4                         
02cf1990: ldp     x20, x19, [sp, #0x20]                      
02cf1994: ldr     x30, [sp, #8]                              
02cf1998: ldp     x22, x21, [sp, #0x10]                      
02cf199c: ldr     d8, [sp], #0x30                            
02cf19a0: ret                                                
02cf19a4: mov     x0, x20                                    
02cf19a8: mov     w1, wzr                                    
02cf19ac: mov     x2, xzr                                    
02cf19b0: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02cf19b4: movi    d0, #0000000000000000                      
02cf19b8: fmov    s1, #1.00000000                            
02cf19bc: tst     w19, #1                                    
02cf19c0: mov     x0, x20                                    
02cf19c4: mov     x1, xzr                                    
02cf19c8: fcsel   s0, s1, s0, ne                             
02cf19cc: fmov    s1, s8                                     
02cf19d0: bl      #0x2c78338                                 DG.Tweening.DOTweenModuleUI::DOFade
02cf19d4: cbz     x20, #0x2cf19f8                            
02cf19d8: and     w1, w19, #1                                
02cf19dc: mov     x0, x20                                    
02cf19e0: ldr     x30, [sp, #8]                              
02cf19e4: ldp     x20, x19, [sp, #0x20]                      
02cf19e8: mov     x2, xzr                                    
02cf19ec: ldp     x22, x21, [sp, #0x10]                      
02cf19f0: ldr     d8, [sp], #0x30                            
02cf19f4: b       #0x5e45408                                 UnityEngine.CanvasGroup::set_blocksRaycasts
02cf19f8: bl      #0x2b7105c                                 fn_2b7105c
