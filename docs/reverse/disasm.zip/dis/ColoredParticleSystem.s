#### CLASS ColoredParticleSystem parent= PoolElement
#   field splash_PSList                  System.Collections.Generic.List`1<UnityEngine.ParticleSystem> off=0x28 attr=6 
## SetColor(UnityEngine.Color inputColor) -> void
---- ColoredParticleSystem::SetColor 0x2cdc39c
02cdc39c: sub     sp, sp, #0xf0                              
02cdc3a0: stp     d11, d10, [sp, #0xb0]                      
02cdc3a4: stp     d9, d8, [sp, #0xc0]                        
02cdc3a8: stp     x30, x21, [sp, #0xd0]                      
02cdc3ac: stp     x20, x19, [sp, #0xe0]                      
02cdc3b0: fmov    s8, s3                                     
02cdc3b4: fmov    s9, s2                                     
02cdc3b8: adrp    x20, #0x662f000                            
02cdc3bc: fmov    s10, s1                                    
02cdc3c0: fmov    s11, s0                                    
02cdc3c4: ldrb    w8, [x20, #0xd70]                          
02cdc3c8: mov     x19, x0                                    
02cdc3cc: tbnz    w8, #0, #0x2cdc408                         
02cdc3d0: adrp    x0, #0x6267000                             
02cdc3d4: ldr     x0, [x0, #0xc90]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02cdc3d8: bl      #0x2b70db0                                 fn_2b70db0
02cdc3dc: adrp    x0, #0x6267000                             
02cdc3e0: ldr     x0, [x0, #0xc98]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02cdc3e4: bl      #0x2b70db0                                 fn_2b70db0
02cdc3e8: adrp    x0, #0x6267000                             
02cdc3ec: ldr     x0, [x0, #0xca0]                           MS:System.Collections.Generic.List`1/Enumerator::get_Current
02cdc3f0: bl      #0x2b70db0                                 fn_2b70db0
02cdc3f4: adrp    x0, #0x6267000                             
02cdc3f8: ldr     x0, [x0, #0xca8]                           MS:System.Collections.Generic.List`1::GetEnumerator
02cdc3fc: bl      #0x2b70db0                                 fn_2b70db0
02cdc400: mov     w8, #1                                     
02cdc404: strb    w8, [x20, #0xd70]                          
02cdc408: ldr     x0, [x19, #0x28]                           .splash_PSList
02cdc40c: stp     xzr, xzr, [sp, #0x98]                      
02cdc410: str     xzr, [sp, #0xa8]                           
02cdc414: str     xzr, [sp, #0x90]                           
02cdc418: cbz     x0, #0x2cdc4f0                             
02cdc41c: adrp    x8, #0x6267000                             
02cdc420: adrp    x20, #0x6267000                            
02cdc424: adrp    x19, #0x6267000                            
02cdc428: ldr     x8, [x8, #0xca8]                           MS:System.Collections.Generic.List`1::GetEnumerator
02cdc42c: ldr     x20, [x20, #0xc98]                         MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02cdc430: ldr     x19, [x19, #0xc90]                         MS:System.Collections.Generic.List`1/Enumerator::Dispose
02cdc434: add     x21, sp, #0x98                             
02cdc438: ldr     x1, [x8]                                   S:'didu'
02cdc43c: add     x8, sp, #0x98                              
02cdc440: bl      #0x35a9d9c                                 fn_35a9d9c
02cdc444: stp     xzr, x21, [sp, #0x80]                      
02cdc448: ldr     x1, [x20]                                  S:'didu'
02cdc44c: add     x0, sp, #0x98                              
02cdc450: bl      #0x4690474                                 fn_4690474
02cdc454: tbz     w0, #0, #0x2cdc4c4                         
02cdc458: ldr     x0, [sp, #0xa8]                            
02cdc45c: cbz     x0, #0x2cdc4e8                             
02cdc460: mov     x1, xzr                                    
02cdc464: bl      #0x5bbad4c                                 UnityEngine.ParticleSystem::get_main
02cdc468: movi    v0.2d, #0000000000000000                   
02cdc46c: str     x0, [sp, #0x90]                            
02cdc470: str     xzr, [sp, #0x70]                           
02cdc474: stp     q0, q0, [sp, #0x50]                        
02cdc478: str     q0, [sp, #0x40]                            
02cdc47c: fmov    s0, s11                                    
02cdc480: fmov    s1, s10                                    
02cdc484: add     x0, sp, #0x40                              
02cdc488: fmov    s2, s9                                     
02cdc48c: fmov    s3, s8                                     
02cdc490: mov     x1, xzr                                    
02cdc494: bl      #0x5bbb2d0                                 UnityEngine.ParticleSystem/MinMaxGradient::.ctor
02cdc498: ldp     q0, q1, [sp, #0x40]                        
02cdc49c: ldr     q2, [sp, #0x60]                            
02cdc4a0: ldr     x8, [sp, #0x70]                            
02cdc4a4: str     q2, [sp, #0x20]                            
02cdc4a8: stp     q0, q1, [sp]                               
02cdc4ac: str     x8, [sp, #0x30]                            
02cdc4b0: add     x0, sp, #0x90                              
02cdc4b4: mov     x1, sp                                     
02cdc4b8: mov     x2, xzr                                    
02cdc4bc: bl      #0x5bbaefc                                 UnityEngine.ParticleSystem/MainModule::set_startColor
02cdc4c0: b       #0x2cdc448                                 
02cdc4c4: ldr     x1, [x19]                                  S:'didu'
02cdc4c8: add     x0, sp, #0x98                              
02cdc4cc: bl      #0x4690470                                 fn_4690470
02cdc4d0: ldp     x20, x19, [sp, #0xe0]                      
02cdc4d4: ldp     x30, x21, [sp, #0xd0]                      
02cdc4d8: ldp     d9, d8, [sp, #0xc0]                        
02cdc4dc: ldp     d11, d10, [sp, #0xb0]                      
02cdc4e0: add     sp, sp, #0xf0                              
02cdc4e4: ret                                                
02cdc4e8: mov     x20, x19                                   
02cdc4ec: bl      #0x2b7105c                                 fn_2b7105c
02cdc4f0: bl      #0x2b7105c                                 fn_2b7105c
02cdc4f4: b       #0x2cdc504                                 
02cdc4f8: b       #0x2cdc500                                 
02cdc4fc: b       #0x2cdc500                                 
02cdc500: mov     x20, x19                                   
02cdc504: cmp     w1, #1                                     
02cdc508: b.ne    #0x2cdc534                                 
02cdc50c: bl      #0x5e90260                                 fn_5e90260
02cdc510: ldr     x19, [x0]                                  S:'didu'
02cdc514: str     x19, [sp, #0x80]                           
02cdc518: bl      #0x5e90270                                 fn_5e90270
02cdc51c: ldr     x0, [sp, #0x88]                            
02cdc520: ldr     x1, [x20]                                  S:'didu'
02cdc524: bl      #0x4690470                                 fn_4690470
02cdc528: cbz     x19, #0x2cdc4d0                            
02cdc52c: mov     x0, x19                                    
02cdc530: bl      #0x2b71054                                 fn_2b71054
02cdc534: mov     x19, x0                                    
02cdc538: add     x0, sp, #0x80                              
02cdc53c: bl      #0x2737860                                 fn_2737860
02cdc540: mov     x0, x19                                    
02cdc544: bl      #0x2c6051c                                 fn_2c6051c
02cdc548: bl      #0x27369b8                                 fn_27369b8
## .ctor() -> void
---- ColoredParticleSystem::.ctor 0x2cdc54c
02cdc54c: str     x30, [sp, #-0x30]!                         
02cdc550: stp     x22, x21, [sp, #0x10]                      
02cdc554: stp     x20, x19, [sp, #0x20]                      
02cdc558: adrp    x21, #0x662f000                            
02cdc55c: adrp    x22, #0x6267000                            
02cdc560: adrp    x20, #0x6267000                            
02cdc564: ldrb    w8, [x21, #0xd71]                          
02cdc568: ldr     x22, [x22, #0xcb0]                         T:type56775(k15)
02cdc56c: ldr     x20, [x20, #0xcb8]                         MS:System.Collections.Generic.List`1::.ctor
02cdc570: mov     x19, x0                                    
02cdc574: tbnz    w8, #0, #0x2cdc598                         
02cdc578: adrp    x0, #0x6267000                             
02cdc57c: ldr     x0, [x0, #0xcb8]                           MS:System.Collections.Generic.List`1::.ctor
02cdc580: bl      #0x2b70db0                                 fn_2b70db0
02cdc584: adrp    x0, #0x6267000                             
02cdc588: ldr     x0, [x0, #0xcb0]                           T:type56775(k15)
02cdc58c: bl      #0x2b70db0                                 fn_2b70db0
02cdc590: mov     w8, #1                                     
02cdc594: strb    w8, [x21, #0xd71]                          
02cdc598: ldr     x0, [x22]                                  S:'didu'
02cdc59c: bl      #0x2b7104c                                 fn_2b7104c
02cdc5a0: ldr     x1, [x20]                                  S:'didu'
02cdc5a4: mov     x20, x0                                    
02cdc5a8: bl      #0x35a89a4                                 fn_35a89a4
02cdc5ac: mov     x0, x19                                    
02cdc5b0: mov     x1, x20                                    
02cdc5b4: str     x20, [x0, #0x28]!                          .splash_PSList
02cdc5b8: bl      #0x2b70d54                                 fn_2b70d54
02cdc5bc: mov     x0, x19                                    
02cdc5c0: ldp     x20, x19, [sp, #0x20]                      
02cdc5c4: ldp     x22, x21, [sp, #0x10]                      
02cdc5c8: mov     x1, xzr                                    
02cdc5cc: ldr     x30, [sp], #0x30                           
02cdc5d0: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
