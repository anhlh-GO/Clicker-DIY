#### CLASS DreamHouse.ProgressBar parent= UnityEngine.MonoBehaviour
#   field _progressValue                 UnityEngine.UI.Image                               off=0x20 attr=1 SerializeField
#   field _progressText                  TMPro.TextMeshProUGUI                              off=0x28 attr=1 SerializeField
#   field _maxValue                      int                                                off=0x30 attr=1 
## OnInit(bool isActive, int minValue, int maxValue) -> void
---- DreamHouse.ProgressBar::OnInit 0x2d1c494
02d1c494: str     x30, [sp, #-0x20]!                         
02d1c498: stp     x20, x19, [sp, #0x10]                      
02d1c49c: mov     w19, w2                                    
02d1c4a0: mov     x20, x0                                    
02d1c4a4: str     w3, [x0, #0x30]                            ._maxValue
02d1c4a8: bl      #0x2d1c4c0                                 DreamHouse.ProgressBar::SetActive
02d1c4ac: mov     x0, x20                                    
02d1c4b0: mov     w1, w19                                    
02d1c4b4: ldp     x20, x19, [sp, #0x10]                      
02d1c4b8: ldr     x30, [sp], #0x20                           
02d1c4bc: b       #0x2d1c528                                 DreamHouse.ProgressBar::SetProgressValue
## SetActive(bool isActive) -> void
---- DreamHouse.ProgressBar::SetActive 0x2d1c4c0
02d1c4c0: str     x30, [sp, #-0x20]!                         
02d1c4c4: stp     x20, x19, [sp, #0x10]                      
02d1c4c8: mov     w20, w1                                    
02d1c4cc: mov     x1, xzr                                    
02d1c4d0: mov     x19, x0                                    
02d1c4d4: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d1c4d8: cbz     x0, #0x2d1c524                             
02d1c4dc: and     w1, w20, #1                                
02d1c4e0: mov     x2, xzr                                    
02d1c4e4: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d1c4e8: tbz     w20, #0, #0x2d1c518                        
02d1c4ec: ldr     x0, [x19, #0x20]                           ._progressValue
02d1c4f0: mov     w1, wzr                                    
02d1c4f4: mov     x2, xzr                                    
02d1c4f8: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d1c4fc: ldr     x0, [x19, #0x20]                           ._progressValue
02d1c500: cbz     x0, #0x2d1c524                             
02d1c504: ldp     x20, x19, [sp, #0x10]                      
02d1c508: movi    d0, #0000000000000000                      
02d1c50c: mov     x1, xzr                                    
02d1c510: ldr     x30, [sp], #0x20                           
02d1c514: b       #0x5c53138                                 UnityEngine.UI.Image::set_fillAmount
02d1c518: ldp     x20, x19, [sp, #0x10]                      
02d1c51c: ldr     x30, [sp], #0x20                           
02d1c520: ret                                                
02d1c524: bl      #0x2b7105c                                 fn_2b7105c
## SetProgressValue(int value) -> void
---- DreamHouse.ProgressBar::SetProgressValue 0x2d1c528
02d1c528: sub     sp, sp, #0x40                              
02d1c52c: stp     x30, x23, [sp, #0x10]                      
02d1c530: stp     x22, x21, [sp, #0x20]                      
02d1c534: stp     x20, x19, [sp, #0x30]                      
02d1c538: adrp    x20, #0x6630000                            
02d1c53c: mov     w21, w1                                    
02d1c540: mov     x19, x0                                    
02d1c544: ldrb    w8, [x20, #0x17]                           
02d1c548: tbnz    w8, #0, #0x2d1c560                         
02d1c54c: adrp    x0, #0x6267000                             
02d1c550: ldr     x0, [x0, #0xd70]                           S:'{0}/{1}'
02d1c554: bl      #0x2b70db0                                 fn_2b70db0
02d1c558: mov     w8, #1                                     
02d1c55c: strb    w8, [x20, #0x17]                           
02d1c560: ldr     x0, [x19, #0x20]                           ._progressValue
02d1c564: cbz     x0, #0x2d1c604                             
02d1c568: ldr     s0, [x19, #0x30]                           ._maxValue
02d1c56c: scvtf   s1, w21                                    
02d1c570: adrp    x22, #0x6267000                            
02d1c574: ldr     x22, [x22, #0xd70]                         S:'{0}/{1}'
02d1c578: mov     x1, xzr                                    
02d1c57c: scvtf   s0, s0                                     
02d1c580: fdiv    s0, s1, s0                                 
02d1c584: bl      #0x5c53138                                 UnityEngine.UI.Image::set_fillAmount
02d1c588: adrp    x23, #0x6263000                            
02d1c58c: add     x1, sp, #0xc                               
02d1c590: ldr     x23, [x23, #0x970]                         &6645c70(=0)
02d1c594: ldr     x20, [x19, #0x28]                          ._progressText
02d1c598: str     w21, [sp, #0xc]                            
02d1c59c: ldr     x0, [x23, #0x48]                           &6263098(=0)
02d1c5a0: bl      #0x2b70f38                                 fn_2b70f38
02d1c5a4: mov     x21, x0                                    
02d1c5a8: ldr     w8, [x19, #0x30]                           ._maxValue
02d1c5ac: ldr     x0, [x23, #0x48]                           &6263098(=0)
02d1c5b0: add     x1, sp, #8                                 
02d1c5b4: str     w8, [sp, #8]                               
02d1c5b8: bl      #0x2b70f38                                 fn_2b70f38
02d1c5bc: ldr     x8, [x22]                                  S:'didu'
02d1c5c0: mov     x2, x0                                     
02d1c5c4: mov     x1, x21                                    
02d1c5c8: mov     x3, xzr                                    
02d1c5cc: mov     x0, x8                                     
02d1c5d0: bl      #0x4ca7720                                 System.String::Format
02d1c5d4: cbz     x20, #0x2d1c604                            
02d1c5d8: ldr     x8, [x20]                                  
02d1c5dc: mov     x1, x0                                     
02d1c5e0: mov     x0, x20                                    
02d1c5e4: ldr     x9, [x8, #0x558]                           
02d1c5e8: ldr     x2, [x8, #0x560]                           
02d1c5ec: blr     x9                                         
02d1c5f0: ldp     x20, x19, [sp, #0x30]                      
02d1c5f4: ldp     x22, x21, [sp, #0x20]                      
02d1c5f8: ldp     x30, x23, [sp, #0x10]                      
02d1c5fc: add     sp, sp, #0x40                              
02d1c600: ret                                                
02d1c604: bl      #0x2b7105c                                 fn_2b7105c
## DoProgressValue(int value, float duration) -> void
---- DreamHouse.ProgressBar::DoProgressValue 0x2d1c608
02d1c608: sub     sp, sp, #0x50                              
02d1c60c: stp     d9, d8, [sp, #0x10]                        
02d1c610: stp     x30, x23, [sp, #0x20]                      
02d1c614: stp     x22, x21, [sp, #0x30]                      
02d1c618: stp     x20, x19, [sp, #0x40]                      
02d1c61c: fmov    s8, s0                                     
02d1c620: adrp    x21, #0x6630000                            
02d1c624: adrp    x22, #0x6267000                            
02d1c628: ldrb    w8, [x21, #0x18]                           
02d1c62c: ldr     x22, [x22, #0xd70]                         S:'{0}/{1}'
02d1c630: mov     w20, w1                                    
02d1c634: mov     x19, x0                                    
02d1c638: tbnz    w8, #0, #0x2d1c650                         
02d1c63c: adrp    x0, #0x6267000                             
02d1c640: ldr     x0, [x0, #0xd70]                           S:'{0}/{1}'
02d1c644: bl      #0x2b70db0                                 fn_2b70db0
02d1c648: mov     w8, #1                                     
02d1c64c: strb    w8, [x21, #0x18]                           
02d1c650: ldr     s0, [x19, #0x30]                           ._maxValue
02d1c654: scvtf   s1, w20                                    
02d1c658: ldr     x0, [x19, #0x20]                           ._progressValue
02d1c65c: mov     w1, wzr                                    
02d1c660: mov     x2, xzr                                    
02d1c664: scvtf   s0, s0                                     
02d1c668: fdiv    s9, s1, s0                                 
02d1c66c: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d1c670: fmov    s0, s9                                     
02d1c674: fmov    s1, s8                                     
02d1c678: ldr     x0, [x19, #0x20]                           ._progressValue
02d1c67c: mov     x1, xzr                                    
02d1c680: bl      #0x2c78b44                                 DG.Tweening.DOTweenModuleUI::DOFillAmount
02d1c684: adrp    x23, #0x6263000                            
02d1c688: add     x1, sp, #0xc                               
02d1c68c: ldr     x23, [x23, #0x970]                         &6645c70(=0)
02d1c690: ldr     x21, [x19, #0x28]                          ._progressText
02d1c694: str     w20, [sp, #0xc]                            
02d1c698: ldr     x0, [x23, #0x48]                           &6263098(=0)
02d1c69c: bl      #0x2b70f38                                 fn_2b70f38
02d1c6a0: mov     x20, x0                                    
02d1c6a4: ldr     w8, [x19, #0x30]                           ._maxValue
02d1c6a8: ldr     x0, [x23, #0x48]                           &6263098(=0)
02d1c6ac: add     x1, sp, #8                                 
02d1c6b0: str     w8, [sp, #8]                               
02d1c6b4: bl      #0x2b70f38                                 fn_2b70f38
02d1c6b8: ldr     x8, [x22]                                  S:'didu'
02d1c6bc: mov     x2, x0                                     
02d1c6c0: mov     x1, x20                                    
02d1c6c4: mov     x3, xzr                                    
02d1c6c8: mov     x0, x8                                     
02d1c6cc: bl      #0x4ca7720                                 System.String::Format
02d1c6d0: cbz     x21, #0x2d1c704                            
02d1c6d4: ldr     x8, [x21]                                  
02d1c6d8: mov     x1, x0                                     
02d1c6dc: mov     x0, x21                                    
02d1c6e0: ldr     x9, [x8, #0x558]                           
02d1c6e4: ldr     x2, [x8, #0x560]                           
02d1c6e8: blr     x9                                         
02d1c6ec: ldp     x20, x19, [sp, #0x40]                      
02d1c6f0: ldp     x22, x21, [sp, #0x30]                      
02d1c6f4: ldp     x30, x23, [sp, #0x20]                      
02d1c6f8: ldp     d9, d8, [sp, #0x10]                        
02d1c6fc: add     sp, sp, #0x50                              
02d1c700: ret                                                
02d1c704: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- DreamHouse.ProgressBar::.ctor 0x2d1c708
02d1c708: mov     x1, xzr                                    
02d1c70c: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
