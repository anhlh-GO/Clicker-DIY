#### CLASS PopupRename parent= PopupBase
#   field _inputField                    TMPro.TMP_InputField                               off=0x38 attr=1 SerializeField
#   field _confirmButton                 UnityEngine.UI.Button                              off=0x40 attr=1 SerializeField
#   field _closeButton                   UnityEngine.UI.Button                              off=0x48 attr=1 SerializeField
#   field _overlayCloseButton            UnityEngine.UI.Button                              off=0x50 attr=1 SerializeField
#   field _panel                         UnityEngine.RectTransform                          off=0x58 attr=1 SerializeField
#   field _unInteractiveSprite           UnityEngine.Sprite                                 off=0x60 attr=1 SerializeField
#   field _interactiveSprite             UnityEngine.Sprite                                 off=0x68 attr=1 SerializeField
#   field _profileManager                Profile.ProfileManager                             off=0x70 attr=1 
#   field _onChangeNameAction            System.Action`1<string>                            off=0x78 attr=1 
#   field _onCloseAction                 System.Action                                      off=0x80 attr=1 
## OnInit(UIManager uiManager) -> void
---- PopupRename::OnInit 0x2cdd280
02cdd280: stp     x30, x23, [sp, #-0x30]!                    
02cdd284: stp     x22, x21, [sp, #0x10]                      
02cdd288: stp     x20, x19, [sp, #0x20]                      
02cdd28c: adrp    x21, #0x662f000                            
02cdd290: mov     x20, x1                                    
02cdd294: mov     x19, x0                                    
02cdd298: ldrb    w8, [x21, #0xd80]                          
02cdd29c: tbnz    w8, #0, #0x2cdd2cc                         
02cdd2a0: adrp    x0, #0x6267000                             
02cdd2a4: ldr     x0, [x0, #0xd10]                           M:PopupRename::OnButtonCloseClicked
02cdd2a8: bl      #0x2b70db0                                 fn_2b70db0
02cdd2ac: adrp    x0, #0x6267000                             
02cdd2b0: ldr     x0, [x0, #0xd18]                           M:PopupRename::OnConfirmClick
02cdd2b4: bl      #0x2b70db0                                 fn_2b70db0
02cdd2b8: adrp    x0, #0x6265000                             
02cdd2bc: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02cdd2c0: bl      #0x2b70db0                                 fn_2b70db0
02cdd2c4: mov     w8, #1                                     
02cdd2c8: strb    w8, [x21, #0xd80]                          
02cdd2cc: mov     x0, x19                                    
02cdd2d0: mov     x1, x20                                    
02cdd2d4: bl      #0x2cdd3c4                                 UIBase::OnInit
02cdd2d8: ldr     x8, [x19, #0x48]                           ._closeButton
02cdd2dc: cbz     x8, #0x2cdd3c0                             
02cdd2e0: adrp    x22, #0x6265000                            
02cdd2e4: adrp    x23, #0x6267000                            
02cdd2e8: ldr     x22, [x22, #0x3f0]                         T:UnityEngine.Events.UnityAction
02cdd2ec: ldr     x23, [x23, #0xd10]                         M:PopupRename::OnButtonCloseClicked
02cdd2f0: ldr     x20, [x8, #0x100]                          
02cdd2f4: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02cdd2f8: bl      #0x2b7104c                                 fn_2b7104c
02cdd2fc: ldr     x2, [x23]                                  S:'didu'
02cdd300: mov     x1, x19                                    
02cdd304: mov     x3, xzr                                    
02cdd308: mov     x21, x0                                    
02cdd30c: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02cdd310: cbz     x20, #0x2cdd3c0                            
02cdd314: mov     x0, x20                                    
02cdd318: mov     x1, x21                                    
02cdd31c: mov     x2, xzr                                    
02cdd320: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02cdd324: ldr     x8, [x19, #0x50]                           ._overlayCloseButton
02cdd328: cbz     x8, #0x2cdd3c0                             
02cdd32c: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02cdd330: ldr     x20, [x8, #0x100]                          
02cdd334: bl      #0x2b7104c                                 fn_2b7104c
02cdd338: ldr     x2, [x23]                                  S:'didu'
02cdd33c: mov     x1, x19                                    
02cdd340: mov     x3, xzr                                    
02cdd344: mov     x21, x0                                    
02cdd348: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02cdd34c: cbz     x20, #0x2cdd3c0                            
02cdd350: mov     x0, x20                                    
02cdd354: mov     x1, x21                                    
02cdd358: mov     x2, xzr                                    
02cdd35c: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02cdd360: ldr     x8, [x19, #0x40]                           ._confirmButton
02cdd364: cbz     x8, #0x2cdd3c0                             
02cdd368: adrp    x21, #0x6267000                            
02cdd36c: ldr     x21, [x21, #0xd18]                         M:PopupRename::OnConfirmClick
02cdd370: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02cdd374: ldr     x20, [x8, #0x100]                          
02cdd378: bl      #0x2b7104c                                 fn_2b7104c
02cdd37c: ldr     x2, [x21]                                  S:'didu'
02cdd380: mov     x1, x19                                    
02cdd384: mov     x3, xzr                                    
02cdd388: mov     x21, x0                                    
02cdd38c: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02cdd390: cbz     x20, #0x2cdd3c0                            
02cdd394: mov     x0, x20                                    
02cdd398: mov     x1, x21                                    
02cdd39c: mov     x2, xzr                                    
02cdd3a0: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02cdd3a4: ldr     x8, [x19]                                  
02cdd3a8: mov     x0, x19                                    
02cdd3ac: ldp     x20, x19, [sp, #0x20]                      
02cdd3b0: ldp     x2, x1, [x8, #0x198]                       
02cdd3b4: ldp     x22, x21, [sp, #0x10]                      
02cdd3b8: ldp     x30, x23, [sp], #0x30                      
02cdd3bc: br      x2                                         
02cdd3c0: bl      #0x2b7105c                                 fn_2b7105c
## Start() -> void
---- PopupRename::Start 0x2cdd458
02cdd458: stp     x30, x21, [sp, #-0x20]!                    
02cdd45c: stp     x20, x19, [sp, #0x10]                      
02cdd460: adrp    x20, #0x662f000                            
02cdd464: adrp    x21, #0x6267000                            
02cdd468: mov     x19, x0                                    
02cdd46c: ldrb    w8, [x20, #0xd81]                          
02cdd470: ldr     x21, [x21, #0xd20]                         MS:MonoSingleton`1::get_Instance
02cdd474: tbnz    w8, #0, #0x2cdd48c                         
02cdd478: adrp    x0, #0x6267000                             
02cdd47c: ldr     x0, [x0, #0xd20]                           MS:MonoSingleton`1::get_Instance
02cdd480: bl      #0x2b70db0                                 fn_2b70db0
02cdd484: mov     w8, #1                                     
02cdd488: strb    w8, [x20, #0xd81]                          
02cdd48c: ldr     x0, [x21]                                  S:'didu'
02cdd490: bl      #0x3769600                                 fn_3769600
02cdd494: str     x0, [x19, #0x70]!                          ._profileManager
02cdd498: mov     x1, x0                                     
02cdd49c: mov     x0, x19                                    
02cdd4a0: ldp     x20, x19, [sp, #0x10]                      
02cdd4a4: ldp     x30, x21, [sp], #0x20                      
02cdd4a8: b       #0x2b70d54                                 
## RegisterCloseAction(System.Action action) -> void
---- PopupRename::RegisterCloseAction 0x2cdd4ac
02cdd4ac: str     x1, [x0, #0x80]!                           ._onCloseAction
02cdd4b0: b       #0x2b70d54                                 
## OnShow() -> void
---- PopupRename::OnShow 0x2cdd4b4
02cdd4b4: str     x30, [sp, #-0x50]!                         
02cdd4b8: stp     x26, x25, [sp, #0x10]                      
02cdd4bc: stp     x24, x23, [sp, #0x20]                      
02cdd4c0: stp     x22, x21, [sp, #0x30]                      
02cdd4c4: stp     x20, x19, [sp, #0x40]                      
02cdd4c8: adrp    x20, #0x662f000                            
02cdd4cc: adrp    x21, #0x6265000                            
02cdd4d0: mov     x19, x0                                    
02cdd4d4: ldrb    w8, [x20, #0xd82]                          
02cdd4d8: ldr     x21, [x21, #0x310]                         MS:WejoyService.Singleton`1::get_Instance
02cdd4dc: tbnz    w8, #0, #0x2cdd53c                         
02cdd4e0: adrp    x0, #0x6266000                             
02cdd4e4: ldr     x0, [x0, #0x5e0]                           T:GameConfig
02cdd4e8: bl      #0x2b70db0                                 fn_2b70db0
02cdd4ec: adrp    x0, #0x6267000                             
02cdd4f0: ldr     x0, [x0, #0xd28]                           M:PopupRename::<OnShow>b__13_0
02cdd4f4: bl      #0x2b70db0                                 fn_2b70db0
02cdd4f8: adrp    x0, #0x6265000                             
02cdd4fc: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02cdd500: bl      #0x2b70db0                                 fn_2b70db0
02cdd504: adrp    x0, #0x6264000                             
02cdd508: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02cdd50c: bl      #0x2b70db0                                 fn_2b70db0
02cdd510: adrp    x0, #0x6267000                             
02cdd514: ldr     x0, [x0, #0xd30]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02cdd518: bl      #0x2b70db0                                 fn_2b70db0
02cdd51c: adrp    x0, #0x6267000                             
02cdd520: ldr     x0, [x0, #0xd38]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02cdd524: bl      #0x2b70db0                                 fn_2b70db0
02cdd528: adrp    x0, #0x6263000                             
02cdd52c: ldr     x0, [x0, #0xa90]                           S:''
02cdd530: bl      #0x2b70db0                                 fn_2b70db0
02cdd534: mov     w8, #1                                     
02cdd538: strb    w8, [x20, #0xd82]                          
02cdd53c: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02cdd540: bl      #0x3be7218                                 fn_3be7218
02cdd544: cbz     x0, #0x2cdd6b4                             
02cdd548: mov     w1, #4                                     
02cdd54c: mov     x2, xzr                                    
02cdd550: bl      #0x2c8a650                                 AdsManager::ShowMREC
02cdd554: ldr     x0, [x19, #0x38]                           ._inputField
02cdd558: cbz     x0, #0x2cdd6b4                             
02cdd55c: adrp    x8, #0x6263000                             
02cdd560: adrp    x21, #0x6266000                            
02cdd564: mov     x2, xzr                                    
02cdd568: ldr     x8, [x8, #0xa90]                           S:''
02cdd56c: ldr     x21, [x21, #0x5e0]                         T:GameConfig
02cdd570: ldr     x1, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02cdd574: bl      #0x5a6a094                                 TMPro.TMP_InputField::set_text
02cdd578: movi    d0, #0000000000000000                      
02cdd57c: ldr     x0, [x19, #0x28]                           
02cdd580: mov     w1, #1                                     
02cdd584: mov     x2, xzr                                    
02cdd588: mov     w20, #1                                    
02cdd58c: bl      #0x2cf1928                                 FrameWorkUtility::SetActive
02cdd590: ldr     x0, [x19, #0x58]                           ._panel
02cdd594: mov     w1, wzr                                    
02cdd598: mov     x2, xzr                                    
02cdd59c: strb    w20, [x19, #0x20]                          
02cdd5a0: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02cdd5a4: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cdd5a8: ldr     x20, [x19, #0x58]                          ._panel
02cdd5ac: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02cdd5b0: cbnz    w8, #0x2cdd5bc                             
02cdd5b4: bl      #0x2b70f30                                 fn_2b70f30
02cdd5b8: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cdd5bc: adrp    x25, #0x6267000                            
02cdd5c0: adrp    x24, #0x6264000                            
02cdd5c4: adrp    x23, #0x6267000                            
02cdd5c8: ldr     x25, [x25, #0xd38]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02cdd5cc: ldr     x24, [x24, #0xe8]                          T:DG.Tweening.TweenCallback
02cdd5d0: ldr     x8, [x0, #0xb8]                            &6263108(=0)
02cdd5d4: adrp    x22, #0x6267000                            
02cdd5d8: ldr     x23, [x23, #0xd28]                         M:PopupRename::<OnShow>b__13_0
02cdd5dc: fmov    s4, #1.00000000                            
02cdd5e0: ldr     x22, [x22, #0xd30]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02cdd5e4: ldr     s3, [x8, #4]                               [6263004]=0 f=0,0
02cdd5e8: adrp    x8, #0x1084000                             
02cdd5ec: ldr     s0, [x8, #0xeec]                           [1084eec]=457ff0003dcccccd f=0.1,4095
02cdd5f0: mov     x0, x20                                    
02cdd5f4: mov     w1, #0xa                                   
02cdd5f8: mov     x2, xzr                                    
02cdd5fc: fmov    s1, s0                                     
02cdd600: fmov    s2, s0                                     
02cdd604: bl      #0x2d9982c                                 DG.Tweening.ShortcutExtensions::DOPunchScale
02cdd608: adrp    x26, #0x662f000                            
02cdd60c: ldr     x20, [x19, #0x58]                          ._panel
02cdd610: ldrb    w8, [x26, #0x91a]                          
02cdd614: cbnz    w8, #0x2cdd62c                             
02cdd618: adrp    x0, #0x6264000                             
02cdd61c: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02cdd620: bl      #0x2b70db0                                 fn_2b70db0
02cdd624: mov     w8, #1                                     
02cdd628: strb    w8, [x26, #0x91a]                          
02cdd62c: adrp    x8, #0x6264000                             
02cdd630: mov     x0, x20                                    
02cdd634: mov     w1, wzr                                    
02cdd638: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02cdd63c: ldr     x9, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cdd640: mov     x2, xzr                                    
02cdd644: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cdd648: ldr     x9, [x9, #0xb8]                            
02cdd64c: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02cdd650: ldr     s3, [x9, #4]                               
02cdd654: ldp     s0, s1, [x8]                               
02cdd658: ldr     s2, [x8, #8]                               T:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0
02cdd65c: bl      #0x2d98760                                 DG.Tweening.ShortcutExtensions::DOLocalRotate
02cdd660: ldr     x2, [x25]                                  S:'didu'
02cdd664: mov     w1, #0x1b                                  
02cdd668: bl      #0x336fa0c                                 fn_336fa0c
02cdd66c: ldr     x8, [x24]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cdd670: mov     x20, x0                                    
02cdd674: mov     x0, x8                                     
02cdd678: bl      #0x2b7104c                                 fn_2b7104c
02cdd67c: ldr     x2, [x23]                                  S:'didu'
02cdd680: mov     x1, x19                                    
02cdd684: mov     x3, xzr                                    
02cdd688: mov     x21, x0                                    
02cdd68c: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02cdd690: ldr     x2, [x22]                                  S:'didu'
02cdd694: mov     x0, x20                                    
02cdd698: mov     x1, x21                                    
02cdd69c: ldp     x20, x19, [sp, #0x40]                      
02cdd6a0: ldp     x22, x21, [sp, #0x30]                      
02cdd6a4: ldp     x24, x23, [sp, #0x20]                      
02cdd6a8: ldp     x26, x25, [sp, #0x10]                      
02cdd6ac: ldr     x30, [sp], #0x50                           
02cdd6b0: b       #0x336f26c                                 
02cdd6b4: bl      #0x2b7105c                                 fn_2b7105c
## OnHide() -> void
---- PopupRename::OnHide 0x2cdd6ec
02cdd6ec: stp     x30, x25, [sp, #-0x40]!                    
02cdd6f0: stp     x24, x23, [sp, #0x10]                      
02cdd6f4: stp     x22, x21, [sp, #0x20]                      
02cdd6f8: stp     x20, x19, [sp, #0x30]                      
02cdd6fc: adrp    x20, #0x662f000                            
02cdd700: adrp    x21, #0x6265000                            
02cdd704: mov     x19, x0                                    
02cdd708: ldrb    w8, [x20, #0xd83]                          
02cdd70c: ldr     x21, [x21, #0x310]                         MS:WejoyService.Singleton`1::get_Instance
02cdd710: tbnz    w8, #0, #0x2cdd77c                         
02cdd714: adrp    x0, #0x6266000                             
02cdd718: ldr     x0, [x0, #0x5e0]                           T:GameConfig
02cdd71c: bl      #0x2b70db0                                 fn_2b70db0
02cdd720: adrp    x0, #0x6266000                             
02cdd724: ldr     x0, [x0, #0xaa0]                           MS:MonoSingleton`1::get_Instance
02cdd728: bl      #0x2b70db0                                 fn_2b70db0
02cdd72c: adrp    x0, #0x6267000                             
02cdd730: ldr     x0, [x0, #0xd40]                           M:PopupRename::<OnHide>b__14_0
02cdd734: bl      #0x2b70db0                                 fn_2b70db0
02cdd738: adrp    x0, #0x6265000                             
02cdd73c: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02cdd740: bl      #0x2b70db0                                 fn_2b70db0
02cdd744: adrp    x0, #0x6264000                             
02cdd748: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02cdd74c: bl      #0x2b70db0                                 fn_2b70db0
02cdd750: adrp    x0, #0x6267000                             
02cdd754: ldr     x0, [x0, #0xd30]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02cdd758: bl      #0x2b70db0                                 fn_2b70db0
02cdd75c: adrp    x0, #0x6267000                             
02cdd760: ldr     x0, [x0, #0xd38]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02cdd764: bl      #0x2b70db0                                 fn_2b70db0
02cdd768: adrp    x0, #0x6267000                             
02cdd76c: ldr     x0, [x0, #0xd48]                           S:'Tdtc500k'
02cdd770: bl      #0x2b70db0                                 fn_2b70db0
02cdd774: mov     w8, #1                                     
02cdd778: strb    w8, [x20, #0xd83]                          
02cdd77c: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02cdd780: bl      #0x3be7218                                 fn_3be7218
02cdd784: cbz     x0, #0x2cdd91c                             
02cdd788: mov     x1, xzr                                    
02cdd78c: bl      #0x2c88cec                                 AdsManager::HideMREC
02cdd790: ldr     x8, [x19, #0x80]                           ._onCloseAction
02cdd794: cbz     x8, #0x2cdd7a8                             
02cdd798: ldr     x9, [x8, #0x18]                            
02cdd79c: ldr     x0, [x8, #0x40]                            
02cdd7a0: ldr     x1, [x8, #0x28]                            
02cdd7a4: blr     x9                                         
02cdd7a8: ldr     x0, [x19, #0x48]                           ._closeButton
02cdd7ac: cbz     x0, #0x2cdd91c                             
02cdd7b0: mov     w1, wzr                                    
02cdd7b4: mov     x2, xzr                                    
02cdd7b8: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02cdd7bc: ldr     x0, [x19, #0x50]                           ._overlayCloseButton
02cdd7c0: cbz     x0, #0x2cdd91c                             
02cdd7c4: adrp    x25, #0x6266000                            
02cdd7c8: adrp    x24, #0x6267000                            
02cdd7cc: adrp    x23, #0x6264000                            
02cdd7d0: adrp    x21, #0x6267000                            
02cdd7d4: adrp    x22, #0x6267000                            
02cdd7d8: ldr     x25, [x25, #0x5e0]                         T:GameConfig
02cdd7dc: ldr     x24, [x24, #0xd38]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02cdd7e0: ldr     x23, [x23, #0xe8]                          T:DG.Tweening.TweenCallback
02cdd7e4: ldr     x21, [x21, #0xd40]                         M:PopupRename::<OnHide>b__14_0
02cdd7e8: ldr     x22, [x22, #0xd30]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02cdd7ec: mov     w1, wzr                                    
02cdd7f0: mov     x2, xzr                                    
02cdd7f4: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02cdd7f8: ldr     x0, [x19, #0x58]                           ._panel
02cdd7fc: mov     w1, wzr                                    
02cdd800: mov     x2, xzr                                    
02cdd804: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02cdd808: ldr     x0, [x25]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cdd80c: ldr     x20, [x19, #0x58]                          ._panel
02cdd810: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02cdd814: cbnz    w8, #0x2cdd820                             
02cdd818: bl      #0x2b70f30                                 fn_2b70f30
02cdd81c: ldr     x0, [x25]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cdd820: ldr     x8, [x0, #0xb8]                            M:Framework.SceneUtils/<CRUnloadSceneAsync>d__2::System.Collections.IEnumerator.Reset
02cdd824: fmov    s4, #1.00000000                            
02cdd828: mov     x0, x20                                    
02cdd82c: mov     w1, #0xa                                   
02cdd830: mov     x2, xzr                                    
02cdd834: ldr     s3, [x8, #4]                               
02cdd838: adrp    x8, #0x1084000                             
02cdd83c: ldr     s0, [x8, #0xeec]                           [1084eec]=457ff0003dcccccd f=0.1,4095
02cdd840: fmov    s1, s0                                     
02cdd844: fmov    s2, s0                                     
02cdd848: bl      #0x2d9982c                                 DG.Tweening.ShortcutExtensions::DOPunchScale
02cdd84c: ldr     x8, [x25]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cdd850: movi    d0, #0000000000000000                      
02cdd854: movi    d1, #0000000000000000                      
02cdd858: fmov    s2, #10.00000000                           
02cdd85c: ldr     x0, [x19, #0x58]                           ._panel
02cdd860: mov     w1, wzr                                    
02cdd864: ldr     x8, [x8, #0xb8]                            [10840b8]=2632726f74636556 f=7.20646e+31,6.19112e-16
02cdd868: mov     x2, xzr                                    
02cdd86c: ldr     s3, [x8, #4]                               [1084004]=6e55002928747570 f=1.35702e-14,1.64801e+28
02cdd870: bl      #0x2d98760                                 DG.Tweening.ShortcutExtensions::DOLocalRotate
02cdd874: ldr     x2, [x24]                                  S:'didu'
02cdd878: mov     w1, #0x1a                                  
02cdd87c: bl      #0x336fa0c                                 fn_336fa0c
02cdd880: ldr     x8, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cdd884: mov     x20, x0                                    
02cdd888: mov     x0, x8                                     
02cdd88c: bl      #0x2b7104c                                 fn_2b7104c
02cdd890: ldr     x2, [x21]                                  S:'didu'
02cdd894: mov     x1, x19                                    
02cdd898: mov     x3, xzr                                    
02cdd89c: mov     x21, x0                                    
02cdd8a0: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02cdd8a4: ldr     x2, [x22]                                  S:'didu'
02cdd8a8: mov     x0, x20                                    
02cdd8ac: mov     x1, x21                                    
02cdd8b0: bl      #0x336f26c                                 fn_336f26c
02cdd8b4: ldr     x8, [x19, #0x38]                           ._inputField
02cdd8b8: cbz     x8, #0x2cdd91c                             
02cdd8bc: adrp    x9, #0x6267000                             
02cdd8c0: mov     x2, xzr                                    
02cdd8c4: ldr     x9, [x9, #0xd48]                           S:'Tdtc500k'
02cdd8c8: ldr     x0, [x8, #0x210]                           [1084210]=292633726f746365 f=7.56345e+28,3.6904e-14
02cdd8cc: ldr     x1, [x9]                                   S:'didu'
02cdd8d0: bl      #0x4ca52b8                                 System.String::op_Equality
02cdd8d4: tbz     w0, #0, #0x2cdd908                         
02cdd8d8: adrp    x8, #0x6266000                             
02cdd8dc: ldr     x8, [x8, #0xaa0]                           MS:MonoSingleton`1::get_Instance
02cdd8e0: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cdd8e4: bl      #0x3769600                                 fn_3769600
02cdd8e8: cbz     x0, #0x2cdd91c                             
02cdd8ec: ldp     x20, x19, [sp, #0x30]                      
02cdd8f0: mov     w1, #0xa120                                
02cdd8f4: ldp     x22, x21, [sp, #0x20]                      
02cdd8f8: movk    w1, #7, lsl #16                            
02cdd8fc: ldp     x24, x23, [sp, #0x10]                      
02cdd900: ldp     x30, x25, [sp], #0x40                      
02cdd904: b       #0x2cdac78                                 MoneyManager::UpdateMoney
02cdd908: ldp     x20, x19, [sp, #0x30]                      
02cdd90c: ldp     x22, x21, [sp, #0x20]                      
02cdd910: ldp     x24, x23, [sp, #0x10]                      
02cdd914: ldp     x30, x25, [sp], #0x40                      
02cdd918: ret                                                
02cdd91c: bl      #0x2b7105c                                 fn_2b7105c
## RegisterCallback(System.Action`1<string> changeNameAction) -> void
---- PopupRename::RegisterCallback 0x2cdd920
02cdd920: str     x1, [x0, #0x78]!                           ._onChangeNameAction
02cdd924: b       #0x2b70d54                                 
## OnConfirmClick() -> void
---- PopupRename::OnConfirmClick 0x2cdd928
02cdd928: str     x30, [sp, #-0x20]!                         
02cdd92c: stp     x20, x19, [sp, #0x10]                      
02cdd930: adrp    x20, #0x662f000                            
02cdd934: mov     x19, x0                                    
02cdd938: ldrb    w8, [x20, #0xd84]                          
02cdd93c: tbnz    w8, #0, #0x2cdd978                         
02cdd940: adrp    x0, #0x6266000                             
02cdd944: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02cdd948: bl      #0x2b70db0                                 fn_2b70db0
02cdd94c: adrp    x0, #0x6267000                             
02cdd950: ldr     x0, [x0, #0xd50]                           MS:MonoSingleton`1::get_Instance
02cdd954: bl      #0x2b70db0                                 fn_2b70db0
02cdd958: adrp    x0, #0x6266000                             
02cdd95c: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02cdd960: bl      #0x2b70db0                                 fn_2b70db0
02cdd964: adrp    x0, #0x6267000                             
02cdd968: ldr     x0, [x0, #0xd58]                           MS:UIManager::GetScreen
02cdd96c: bl      #0x2b70db0                                 fn_2b70db0
02cdd970: mov     w8, #1                                     
02cdd974: strb    w8, [x20, #0xd84]                          
02cdd978: mov     x0, xzr                                    
02cdd97c: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02cdd980: cbz     x0, #0x2cdda7c                             
02cdd984: movi    d1, #0000000000000000                      
02cdd988: movi    d2, #0000000000000000                      
02cdd98c: adrp    x20, #0x6267000                            
02cdd990: fmov    s0, #1.00000000                            
02cdd994: ldr     x20, [x20, #0xd50]                         MS:MonoSingleton`1::get_Instance
02cdd998: mov     w1, #1                                     
02cdd99c: mov     w2, wzr                                    
02cdd9a0: mov     w3, wzr                                    
02cdd9a4: mov     x4, xzr                                    
02cdd9a8: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02cdd9ac: ldr     x0, [x20]                                  S:'didu'
02cdd9b0: bl      #0x3769600                                 fn_3769600
02cdd9b4: cbz     x0, #0x2cdda7c                             
02cdd9b8: adrp    x20, #0x6266000                            
02cdd9bc: mov     w1, #4                                     
02cdd9c0: mov     x2, xzr                                    
02cdd9c4: ldr     x20, [x20, #0x658]                         MS:MonoSingleton`1::get_Instance
02cdd9c8: bl      #0x2cc6ee0                                 Framework.VibrationManager::Haptic
02cdd9cc: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cdd9d0: bl      #0x3769600                                 fn_3769600
02cdd9d4: cbz     x0, #0x2cdda7c                             
02cdd9d8: adrp    x8, #0x6266000                             
02cdd9dc: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02cdd9e0: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cdd9e4: bl      #0x3168dd0                                 fn_3168dd0
02cdd9e8: ldr     x8, [x19, #0x38]                           ._inputField
02cdd9ec: cbz     x8, #0x2cdda7c                             
02cdd9f0: ldr     x0, [x19, #0x70]                           ._profileManager
02cdd9f4: cbz     x0, #0x2cdda7c                             
02cdd9f8: ldr     x1, [x8, #0x210]                           MS:System.Collections.Generic.List`1::GetEnumerator
02cdd9fc: mov     x2, xzr                                    
02cdda00: bl      #0x2cf3f44                                 Profile.ProfileManager::SetName
02cdda04: ldr     x0, [x19, #0x30]                           
02cdda08: cbz     x0, #0x2cdda7c                             
02cdda0c: adrp    x8, #0x6267000                             
02cdda10: ldr     x8, [x8, #0xd58]                           MS:UIManager::GetScreen
02cdda14: ldr     x1, [x8]                                   S:'didu'
02cdda18: bl      #0x33fbbd0                                 fn_33fbbd0
02cdda1c: cbz     x0, #0x2cdda7c                             
02cdda20: ldr     x0, [x0, #0xc0]                            M:Framework.SceneUtils/<CRUnloadSceneAsync>d__3::System.Collections.IEnumerator.Reset
02cdda24: cbz     x0, #0x2cdda7c                             
02cdda28: bl      #0x2cdda80                                 ProfilePanel::UpdateName
02cdda2c: mov     x20, x19                                   
02cdda30: ldr     x8, [x20, #0x78]!                          S:'Latest Fetch call still pending.' ._onChangeNameAction
02cdda34: cbz     x8, #0x2cdda54                             
02cdda38: ldr     x9, [x19, #0x38]                           ._inputField
02cdda3c: cbz     x9, #0x2cdda7c                             
02cdda40: ldr     x1, [x9, #0x210]                           
02cdda44: ldr     x9, [x8, #0x18]                            S:'android.content.Intent'
02cdda48: ldr     x0, [x8, #0x40]                            S:'<color=#'
02cdda4c: ldr     x2, [x8, #0x28]                            S:'[^A-Za-z0-9_. ]+'
02cdda50: blr     x9                                         
02cdda54: mov     x0, x20                                    
02cdda58: mov     x1, xzr                                    
02cdda5c: str     xzr, [x19, #0x78]                          ._onChangeNameAction
02cdda60: bl      #0x2b70d54                                 fn_2b70d54
02cdda64: ldr     x8, [x19]                                  
02cdda68: mov     x0, x19                                    
02cdda6c: ldp     x20, x19, [sp, #0x10]                      
02cdda70: ldp     x2, x1, [x8, #0x198]                       
02cdda74: ldr     x30, [sp], #0x20                           
02cdda78: br      x2                                         
02cdda7c: bl      #0x2b7105c                                 fn_2b7105c
## OnButtonCloseClicked() -> void
---- PopupRename::OnButtonCloseClicked 0x2cddafc
02cddafc: str     x30, [sp, #-0x20]!                         
02cddb00: stp     x20, x19, [sp, #0x10]                      
02cddb04: adrp    x20, #0x662f000                            
02cddb08: mov     x19, x0                                    
02cddb0c: ldrb    w8, [x20, #0xd85]                          
02cddb10: tbnz    w8, #0, #0x2cddb34                         
02cddb14: adrp    x0, #0x6266000                             
02cddb18: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02cddb1c: bl      #0x2b70db0                                 fn_2b70db0
02cddb20: adrp    x0, #0x6266000                             
02cddb24: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02cddb28: bl      #0x2b70db0                                 fn_2b70db0
02cddb2c: mov     w8, #1                                     
02cddb30: strb    w8, [x20, #0xd85]                          
02cddb34: mov     x0, xzr                                    
02cddb38: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02cddb3c: cbz     x0, #0x2cddb9c                             
02cddb40: movi    d1, #0000000000000000                      
02cddb44: movi    d2, #0000000000000000                      
02cddb48: adrp    x20, #0x6266000                            
02cddb4c: fmov    s0, #1.00000000                            
02cddb50: ldr     x20, [x20, #0x658]                         MS:MonoSingleton`1::get_Instance
02cddb54: mov     w1, #1                                     
02cddb58: mov     w2, wzr                                    
02cddb5c: mov     w3, wzr                                    
02cddb60: mov     x4, xzr                                    
02cddb64: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02cddb68: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cddb6c: bl      #0x3769600                                 fn_3769600
02cddb70: cbz     x0, #0x2cddb9c                             
02cddb74: adrp    x8, #0x6266000                             
02cddb78: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02cddb7c: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cddb80: bl      #0x3168dd0                                 fn_3168dd0
02cddb84: ldr     x8, [x19]                                  
02cddb88: mov     x0, x19                                    
02cddb8c: ldp     x20, x19, [sp, #0x10]                      
02cddb90: ldp     x2, x1, [x8, #0x198]                       
02cddb94: ldr     x30, [sp], #0x20                           
02cddb98: br      x2                                         
02cddb9c: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- PopupRename::.ctor 0x2cddba0
02cddba0: mov     x1, xzr                                    
02cddba4: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
## <OnShow>b__13_0() -> void
---- PopupRename::<OnShow>b__13_0 0x2cddbb0
02cddbb0: stp     x30, x19, [sp, #-0x10]!                    
02cddbb4: mov     x19, x0                                    
02cddbb8: ldr     x0, [x0, #0x48]                            ._closeButton
02cddbbc: cbz     x0, #0x2cddbe4                             
02cddbc0: mov     w1, #1                                     
02cddbc4: mov     x2, xzr                                    
02cddbc8: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02cddbcc: ldr     x0, [x19, #0x50]                           ._overlayCloseButton
02cddbd0: cbz     x0, #0x2cddbe4                             
02cddbd4: mov     w1, #1                                     
02cddbd8: mov     x2, xzr                                    
02cddbdc: ldp     x30, x19, [sp], #0x10                      
02cddbe0: b       #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02cddbe4: bl      #0x2b7105c                                 fn_2b7105c
## <OnHide>b__14_0() -> void
---- PopupRename::<OnHide>b__14_0 0x2cddbe8
02cddbe8: stp     x30, x19, [sp, #-0x10]!                    
02cddbec: movi    d0, #0000000000000000                      
02cddbf0: mov     x19, x0                                    
02cddbf4: ldr     x0, [x0, #0x28]                            
02cddbf8: mov     w1, wzr                                    
02cddbfc: mov     x2, xzr                                    
02cddc00: bl      #0x2cf1928                                 FrameWorkUtility::SetActive
02cddc04: strb    wzr, [x19, #0x20]                          
02cddc08: ldp     x30, x19, [sp], #0x10                      
02cddc0c: ret                                                
