#### CLASS Clicker.DragManager/<>c parent= object
#   field <>9                            Clicker.DragManager/<>c                            off=0x0 attr=36 
#   field <>9__14_0                      System.Action`1<Clicker.DraggableSwitch>           off=0x8 attr=16 
#   field <>9__14_1                      System.Action`1<Clicker.DraggableKeychain>         off=0x10 attr=16 
#   field <>9__14_2                      System.Action`1<Clicker.DraggableKeycap>           off=0x18 attr=16 
## .cctor() -> void
---- Clicker.DragManager/<>c::.cctor 0x2d63090
02d63090: str     x30, [sp, #-0x20]!                         
02d63094: stp     x20, x19, [sp, #0x10]                      
02d63098: adrp    x19, #0x6630000                            
02d6309c: adrp    x20, #0x626b000                            
02d630a0: ldrb    w8, [x19, #0x307]                          
02d630a4: ldr     x20, [x20, #0xfa8]                         T:Clicker.DragManager/<>c
02d630a8: tbnz    w8, #0, #0x2d630c0                         
02d630ac: adrp    x0, #0x626b000                             
02d630b0: ldr     x0, [x0, #0xfa8]                           T:Clicker.DragManager/<>c
02d630b4: bl      #0x2b70db0                                 fn_2b70db0
02d630b8: mov     w8, #1                                     
02d630bc: strb    w8, [x19, #0x307]                          
02d630c0: ldr     x0, [x20]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d630c4: bl      #0x2b7104c                                 fn_2b7104c
02d630c8: mov     x1, xzr                                    
02d630cc: mov     x19, x0                                    
02d630d0: bl      #0x4e53e9c                                 System.Object::.ctor
02d630d4: ldr     x8, [x20]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d630d8: mov     x1, x19                                    
02d630dc: ldr     x8, [x8, #0xb8]                            
02d630e0: str     x19, [x8]                                  
02d630e4: ldr     x8, [x20]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d630e8: ldp     x20, x19, [sp, #0x10]                      
02d630ec: ldr     x0, [x8, #0xb8]                            
02d630f0: ldr     x30, [sp], #0x20                           
02d630f4: b       #0x2b70d54                                 
## .ctor() -> void
---- Clicker.DragManager/<>c::.ctor 0x2d630f8
02d630f8: mov     x1, xzr                                    
02d630fc: b       #0x4e53e9c                                 System.Object::.ctor
## <UpdateFallbackPosition>b__14_0(Clicker.DraggableSwitch item) -> void
---- Clicker.DragManager/<>c::<UpdateFallbackPosition>b__14_0 0x2d63100
02d63100: cbz     x1, #0x2d6310c                             
02d63104: mov     x0, x1                                     
02d63108: b       #0x2d61788                                 Clicker.DraggableClickerItem::SetFallBackPosition
02d6310c: str     x30, [sp, #-0x10]!                         
02d63110: bl      #0x2b7105c                                 fn_2b7105c
## <UpdateFallbackPosition>b__14_1(Clicker.DraggableKeychain item) -> void
---- Clicker.DragManager/<>c::<UpdateFallbackPosition>b__14_1 0x2d63114
02d63114: cbz     x1, #0x2d63120                             
02d63118: mov     x0, x1                                     
02d6311c: b       #0x2d61788                                 Clicker.DraggableClickerItem::SetFallBackPosition
02d63120: str     x30, [sp, #-0x10]!                         
02d63124: bl      #0x2b7105c                                 fn_2b7105c
## <UpdateFallbackPosition>b__14_2(Clicker.DraggableKeycap item) -> void
---- Clicker.DragManager/<>c::<UpdateFallbackPosition>b__14_2 0x2d63128
02d63128: cbz     x1, #0x2d63134                             
02d6312c: mov     x0, x1                                     
02d63130: b       #0x2d61788                                 Clicker.DraggableClickerItem::SetFallBackPosition
02d63134: str     x30, [sp, #-0x10]!                         
02d63138: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Clicker.DragManager/<>c__DisplayClass13_0 parent= object
#   field allowDrag                      bool                                               off=0x10 attr=6 
## .ctor() -> void
---- Clicker.DragManager/<>c__DisplayClass13_0::.ctor 0x2d61f44
02d61f44: mov     x1, xzr                                    
02d61f48: b       #0x4e53e9c                                 System.Object::.ctor
## <SetDraggable>b__0(Clicker.DraggableSwitch item) -> void
---- Clicker.DragManager/<>c__DisplayClass13_0::<SetDraggable>b__0 0x2d6313c
02d6313c: cbz     x1, #0x2d6314c                             
02d63140: ldrb    w8, [x0, #0x10]                            .allowDrag
02d63144: strb    w8, [x1, #0x34]                            
02d63148: ret                                                
02d6314c: str     x30, [sp, #-0x10]!                         
02d63150: bl      #0x2b7105c                                 fn_2b7105c
## <SetDraggable>b__1(Clicker.DraggableKeychain item) -> void
---- Clicker.DragManager/<>c__DisplayClass13_0::<SetDraggable>b__1 0x2d63154
02d63154: cbz     x1, #0x2d63164                             
02d63158: ldrb    w8, [x0, #0x10]                            .allowDrag
02d6315c: strb    w8, [x1, #0x34]                            
02d63160: ret                                                
02d63164: str     x30, [sp, #-0x10]!                         
02d63168: bl      #0x2b7105c                                 fn_2b7105c
## <SetDraggable>b__2(Clicker.DraggableKeycap item) -> void
---- Clicker.DragManager/<>c__DisplayClass13_0::<SetDraggable>b__2 0x2d6316c
02d6316c: cbz     x1, #0x2d6317c                             
02d63170: ldrb    w8, [x0, #0x10]                            .allowDrag
02d63174: strb    w8, [x1, #0x34]                            
02d63178: ret                                                
02d6317c: str     x30, [sp, #-0x10]!                         
02d63180: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Clicker.DragManager parent= UnityEngine.MonoBehaviour
#   field _switchList                    System.Collections.Generic.List`1<Clicker.DraggableSwitch> off=0x20 attr=1 SerializeField
#   field _keychainList                  System.Collections.Generic.List`1<Clicker.DraggableKeychain> off=0x28 attr=1 SerializeField
#   field _keycapList                    System.Collections.Generic.List`1<Clicker.DraggableKeycap> off=0x30 attr=1 SerializeField
#   field _tfCurrentHolding              UnityEngine.Transform                              off=0x38 attr=1 SerializeField
#   field _cam                           UnityEngine.Camera                                 off=0x40 attr=1 
#   field _current                       Clicker.IClickerDraggableItem                      off=0x48 attr=1 
#   field _tfOldParent                   UnityEngine.Transform                              off=0x50 attr=1 
#   field _offset                        UnityEngine.Vector3                                off=0x58 attr=1 
#   field _handOffset                    UnityEngine.Vector3                                off=0x64 attr=1 
#   field _allowDrag                     bool                                               off=0x70 attr=1 
#   field _baseKeycapObjectChecking      Clicker.BaseKeycapObject                           off=0x78 attr=1 
## Awake() -> void
---- Clicker.DragManager::Awake 0x2d61d48
02d61d48: stp     x30, x19, [sp, #-0x10]!                    
02d61d4c: mov     x19, x0                                    
02d61d50: mov     x0, xzr                                    
02d61d54: bl      #0x5aefe28                                 UnityEngine.Camera::get_main
02d61d58: mov     x1, x0                                     
02d61d5c: str     x0, [x19, #0x40]!                          ._cam
02d61d60: mov     x0, x19                                    
02d61d64: ldp     x30, x19, [sp], #0x10                      
02d61d68: b       #0x2b70d54                                 
## SetBaseKeycapChecking(Clicker.BaseKeycapObject baseKeycapObject) -> void
---- Clicker.DragManager::SetBaseKeycapChecking 0x2d61d6c
02d61d6c: str     x1, [x0, #0x78]!                           ._baseKeycapObjectChecking
02d61d70: b       #0x2b70d54                                 
## SetDraggable(bool allowDrag) -> void
---- Clicker.DragManager::SetDraggable 0x2d61d74
02d61d74: str     x30, [sp, #-0x40]!                         
02d61d78: stp     x24, x23, [sp, #0x10]                      
02d61d7c: stp     x22, x21, [sp, #0x20]                      
02d61d80: stp     x20, x19, [sp, #0x30]                      
02d61d84: adrp    x20, #0x6630000                            
02d61d88: adrp    x22, #0x626b000                            
02d61d8c: mov     w21, w1                                    
02d61d90: ldrb    w8, [x20, #0x301]                          
02d61d94: ldr     x22, [x22, #0xf58]                         T:Clicker.DragManager/<>c__DisplayClass13_0
02d61d98: mov     x19, x0                                    
02d61d9c: tbnz    w8, #0, #0x2d61e20                         
02d61da0: adrp    x0, #0x626b000                             
02d61da4: ldr     x0, [x0, #0xf60]                           T:type53130(k15)
02d61da8: bl      #0x2b70db0                                 fn_2b70db0
02d61dac: adrp    x0, #0x626b000                             
02d61db0: ldr     x0, [x0, #0xf68]                           T:type53131(k15)
02d61db4: bl      #0x2b70db0                                 fn_2b70db0
02d61db8: adrp    x0, #0x626b000                             
02d61dbc: ldr     x0, [x0, #0xf70]                           T:type53129(k15)
02d61dc0: bl      #0x2b70db0                                 fn_2b70db0
02d61dc4: adrp    x0, #0x626b000                             
02d61dc8: ldr     x0, [x0, #0xf78]                           MS:System.Collections.Generic.List`1::ForEach
02d61dcc: bl      #0x2b70db0                                 fn_2b70db0
02d61dd0: adrp    x0, #0x626b000                             
02d61dd4: ldr     x0, [x0, #0xf80]                           MS:System.Collections.Generic.List`1::ForEach
02d61dd8: bl      #0x2b70db0                                 fn_2b70db0
02d61ddc: adrp    x0, #0x626b000                             
02d61de0: ldr     x0, [x0, #0xf88]                           MS:System.Collections.Generic.List`1::ForEach
02d61de4: bl      #0x2b70db0                                 fn_2b70db0
02d61de8: adrp    x0, #0x626b000                             
02d61dec: ldr     x0, [x0, #0xf90]                           M:Clicker.DragManager/<>c__DisplayClass13_0::<SetDraggable>b__0
02d61df0: bl      #0x2b70db0                                 fn_2b70db0
02d61df4: adrp    x0, #0x626b000                             
02d61df8: ldr     x0, [x0, #0xf98]                           M:Clicker.DragManager/<>c__DisplayClass13_0::<SetDraggable>b__1
02d61dfc: bl      #0x2b70db0                                 fn_2b70db0
02d61e00: adrp    x0, #0x626b000                             
02d61e04: ldr     x0, [x0, #0xfa0]                           M:Clicker.DragManager/<>c__DisplayClass13_0::<SetDraggable>b__2
02d61e08: bl      #0x2b70db0                                 fn_2b70db0
02d61e0c: adrp    x0, #0x626b000                             
02d61e10: ldr     x0, [x0, #0xf58]                           T:Clicker.DragManager/<>c__DisplayClass13_0
02d61e14: bl      #0x2b70db0                                 fn_2b70db0
02d61e18: mov     w8, #1                                     
02d61e1c: strb    w8, [x20, #0x301]                          
02d61e20: ldr     x0, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d61e24: bl      #0x2b7104c                                 fn_2b7104c
02d61e28: mov     x1, xzr                                    
02d61e2c: mov     x20, x0                                    
02d61e30: bl      #0x4e53e9c                                 System.Object::.ctor
02d61e34: cbz     x20, #0x2d61f40                            
02d61e38: adrp    x8, #0x626b000                             
02d61e3c: adrp    x22, #0x626b000                            
02d61e40: and     w9, w21, #1                                
02d61e44: ldr     x8, [x8, #0xf68]                           T:type53131(k15)
02d61e48: ldr     x22, [x22, #0xf90]                         M:Clicker.DragManager/<>c__DisplayClass13_0::<SetDraggable>b__0
02d61e4c: ldr     x21, [x19, #0x20]                          ._switchList
02d61e50: strb    w9, [x20, #0x10]                           
02d61e54: ldr     x0, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d61e58: bl      #0x2b7104c                                 fn_2b7104c
02d61e5c: ldr     x2, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d61e60: mov     x1, x20                                    
02d61e64: mov     x3, xzr                                    
02d61e68: mov     x22, x0                                    
02d61e6c: bl      #0x453418c                                 fn_453418c
02d61e70: cbz     x21, #0x2d61f40                            
02d61e74: adrp    x8, #0x626b000                             
02d61e78: adrp    x23, #0x626b000                            
02d61e7c: adrp    x24, #0x626b000                            
02d61e80: ldr     x8, [x8, #0xf80]                           MS:System.Collections.Generic.List`1::ForEach
02d61e84: ldr     x23, [x23, #0xf60]                         T:type53130(k15)
02d61e88: ldr     x24, [x24, #0xf98]                         M:Clicker.DragManager/<>c__DisplayClass13_0::<SetDraggable>b__1
02d61e8c: mov     x0, x21                                    
02d61e90: mov     x1, x22                                    
02d61e94: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d61e98: bl      #0x35a9ce4                                 fn_35a9ce4
02d61e9c: ldr     x0, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d61ea0: ldr     x21, [x19, #0x28]                          ._keychainList
02d61ea4: bl      #0x2b7104c                                 fn_2b7104c
02d61ea8: ldr     x2, [x24]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d61eac: mov     x1, x20                                    
02d61eb0: mov     x3, xzr                                    
02d61eb4: mov     x22, x0                                    
02d61eb8: bl      #0x453418c                                 fn_453418c
02d61ebc: cbz     x21, #0x2d61f40                            
02d61ec0: adrp    x8, #0x626b000                             
02d61ec4: adrp    x23, #0x626b000                            
02d61ec8: adrp    x24, #0x626b000                            
02d61ecc: ldr     x8, [x8, #0xf88]                           MS:System.Collections.Generic.List`1::ForEach
02d61ed0: ldr     x23, [x23, #0xf70]                         T:type53129(k15)
02d61ed4: ldr     x24, [x24, #0xfa0]                         M:Clicker.DragManager/<>c__DisplayClass13_0::<SetDraggable>b__2
02d61ed8: mov     x0, x21                                    
02d61edc: mov     x1, x22                                    
02d61ee0: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d61ee4: bl      #0x35a9ce4                                 fn_35a9ce4
02d61ee8: ldr     x0, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d61eec: ldr     x21, [x19, #0x30]                          ._keycapList
02d61ef0: bl      #0x2b7104c                                 fn_2b7104c
02d61ef4: ldr     x2, [x24]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d61ef8: mov     x1, x20                                    
02d61efc: mov     x3, xzr                                    
02d61f00: mov     x22, x0                                    
02d61f04: bl      #0x453418c                                 fn_453418c
02d61f08: cbz     x21, #0x2d61f40                            
02d61f0c: adrp    x8, #0x626b000                             
02d61f10: mov     x0, x21                                    
02d61f14: mov     x1, x22                                    
02d61f18: ldr     x8, [x8, #0xf78]                           MS:System.Collections.Generic.List`1::ForEach
02d61f1c: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d61f20: bl      #0x35a9ce4                                 fn_35a9ce4
02d61f24: ldrb    w8, [x20, #0x10]                           
02d61f28: ldp     x22, x21, [sp, #0x20]                      
02d61f2c: ldp     x24, x23, [sp, #0x10]                      
02d61f30: strb    w8, [x19, #0x70]                           ._allowDrag
02d61f34: ldp     x20, x19, [sp, #0x30]                      
02d61f38: ldr     x30, [sp], #0x40                           
02d61f3c: ret                                                
02d61f40: bl      #0x2b7105c                                 fn_2b7105c
## UpdateFallbackPosition() -> void
---- Clicker.DragManager::UpdateFallbackPosition 0x2d61f4c
02d61f4c: stp     x30, x23, [sp, #-0x30]!                    
02d61f50: stp     x22, x21, [sp, #0x10]                      
02d61f54: stp     x20, x19, [sp, #0x20]                      
02d61f58: adrp    x20, #0x6630000                            
02d61f5c: adrp    x23, #0x626b000                            
02d61f60: mov     x19, x0                                    
02d61f64: ldrb    w8, [x20, #0x302]                          
02d61f68: ldr     x23, [x23, #0xfa8]                         T:Clicker.DragManager/<>c
02d61f6c: tbnz    w8, #0, #0x2d61ff0                         
02d61f70: adrp    x0, #0x626b000                             
02d61f74: ldr     x0, [x0, #0xf60]                           T:type53130(k15)
02d61f78: bl      #0x2b70db0                                 fn_2b70db0
02d61f7c: adrp    x0, #0x626b000                             
02d61f80: ldr     x0, [x0, #0xf68]                           T:type53131(k15)
02d61f84: bl      #0x2b70db0                                 fn_2b70db0
02d61f88: adrp    x0, #0x626b000                             
02d61f8c: ldr     x0, [x0, #0xf70]                           T:type53129(k15)
02d61f90: bl      #0x2b70db0                                 fn_2b70db0
02d61f94: adrp    x0, #0x626b000                             
02d61f98: ldr     x0, [x0, #0xf78]                           MS:System.Collections.Generic.List`1::ForEach
02d61f9c: bl      #0x2b70db0                                 fn_2b70db0
02d61fa0: adrp    x0, #0x626b000                             
02d61fa4: ldr     x0, [x0, #0xf80]                           MS:System.Collections.Generic.List`1::ForEach
02d61fa8: bl      #0x2b70db0                                 fn_2b70db0
02d61fac: adrp    x0, #0x626b000                             
02d61fb0: ldr     x0, [x0, #0xf88]                           MS:System.Collections.Generic.List`1::ForEach
02d61fb4: bl      #0x2b70db0                                 fn_2b70db0
02d61fb8: adrp    x0, #0x626b000                             
02d61fbc: ldr     x0, [x0, #0xfb0]                           M:Clicker.DragManager/<>c::<UpdateFallbackPosition>b__14_0
02d61fc0: bl      #0x2b70db0                                 fn_2b70db0
02d61fc4: adrp    x0, #0x626b000                             
02d61fc8: ldr     x0, [x0, #0xfb8]                           M:Clicker.DragManager/<>c::<UpdateFallbackPosition>b__14_1
02d61fcc: bl      #0x2b70db0                                 fn_2b70db0
02d61fd0: adrp    x0, #0x626b000                             
02d61fd4: ldr     x0, [x0, #0xfc0]                           M:Clicker.DragManager/<>c::<UpdateFallbackPosition>b__14_2
02d61fd8: bl      #0x2b70db0                                 fn_2b70db0
02d61fdc: adrp    x0, #0x626b000                             
02d61fe0: ldr     x0, [x0, #0xfa8]                           T:Clicker.DragManager/<>c
02d61fe4: bl      #0x2b70db0                                 fn_2b70db0
02d61fe8: mov     w8, #1                                     
02d61fec: strb    w8, [x20, #0x302]                          
02d61ff0: ldr     x0, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d61ff4: ldr     x20, [x19, #0x20]                          ._switchList
02d61ff8: ldr     w8, [x0, #0xe4]                            [626b0e4]=0 f=0,0
02d61ffc: cbnz    w8, #0x2d62008                             
02d62000: bl      #0x2b70f30                                 fn_2b70f30
02d62004: ldr     x0, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d62008: ldr     x8, [x0, #0xb8]                            S:'scoop_no_thank'
02d6200c: ldr     x21, [x8, #8]                              
02d62010: cbnz    x21, #0x2d6206c                            
02d62014: ldr     w9, [x0, #0xe4]                            [626b0e4]=0 f=0,0
02d62018: cbnz    w9, #0x2d62028                             
02d6201c: bl      #0x2b70f30                                 fn_2b70f30
02d62020: ldr     x8, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d62024: ldr     x8, [x8, #0xb8]                            
02d62028: adrp    x9, #0x626b000                             
02d6202c: ldr     x9, [x9, #0xf68]                           T:type53131(k15)
02d62030: ldr     x22, [x8]                                  
02d62034: ldr     x0, [x9]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d62038: bl      #0x2b7104c                                 fn_2b7104c
02d6203c: adrp    x8, #0x626b000                             
02d62040: mov     x1, x22                                    
02d62044: mov     x3, xzr                                    
02d62048: ldr     x8, [x8, #0xfb0]                           M:Clicker.DragManager/<>c::<UpdateFallbackPosition>b__14_0
02d6204c: mov     x21, x0                                    
02d62050: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d62054: bl      #0x453418c                                 fn_453418c
02d62058: ldr     x8, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d6205c: mov     x1, x21                                    
02d62060: ldr     x0, [x8, #0xb8]                            S:'scoop_no_thank'
02d62064: str     x21, [x0, #8]!                             
02d62068: bl      #0x2b70d54                                 fn_2b70d54
02d6206c: cbz     x20, #0x2d621c4                            
02d62070: adrp    x8, #0x626b000                             
02d62074: mov     x0, x20                                    
02d62078: mov     x1, x21                                    
02d6207c: ldr     x8, [x8, #0xf80]                           MS:System.Collections.Generic.List`1::ForEach
02d62080: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d62084: bl      #0x35a9ce4                                 fn_35a9ce4
02d62088: ldr     x0, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d6208c: ldr     x20, [x19, #0x28]                          ._keychainList
02d62090: ldr     w8, [x0, #0xe4]                            [626b0e4]=0 f=0,0
02d62094: cbnz    w8, #0x2d620a0                             
02d62098: bl      #0x2b70f30                                 fn_2b70f30
02d6209c: ldr     x0, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d620a0: ldr     x8, [x0, #0xb8]                            S:'scoop_no_thank'
02d620a4: ldr     x21, [x8, #0x10]                           MS:System.Collections.Generic.List`1::Find
02d620a8: cbnz    x21, #0x2d62104                            
02d620ac: ldr     w9, [x0, #0xe4]                            [626b0e4]=0 f=0,0
02d620b0: cbnz    w9, #0x2d620c0                             
02d620b4: bl      #0x2b70f30                                 fn_2b70f30
02d620b8: ldr     x8, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d620bc: ldr     x8, [x8, #0xb8]                            S:'scoop_no_thank'
02d620c0: adrp    x9, #0x626b000                             
02d620c4: ldr     x9, [x9, #0xf60]                           T:type53130(k15)
02d620c8: ldr     x22, [x8]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d620cc: ldr     x0, [x9]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d620d0: bl      #0x2b7104c                                 fn_2b7104c
02d620d4: adrp    x8, #0x626b000                             
02d620d8: mov     x1, x22                                    
02d620dc: mov     x3, xzr                                    
02d620e0: ldr     x8, [x8, #0xfb8]                           M:Clicker.DragManager/<>c::<UpdateFallbackPosition>b__14_1
02d620e4: mov     x21, x0                                    
02d620e8: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d620ec: bl      #0x453418c                                 fn_453418c
02d620f0: ldr     x8, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d620f4: mov     x1, x21                                    
02d620f8: ldr     x0, [x8, #0xb8]                            S:'scoop_no_thank'
02d620fc: str     x21, [x0, #0x10]!                          
02d62100: bl      #0x2b70d54                                 fn_2b70d54
02d62104: cbz     x20, #0x2d621c4                            
02d62108: adrp    x8, #0x626b000                             
02d6210c: mov     x0, x20                                    
02d62110: mov     x1, x21                                    
02d62114: ldr     x8, [x8, #0xf88]                           MS:System.Collections.Generic.List`1::ForEach
02d62118: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d6211c: bl      #0x35a9ce4                                 fn_35a9ce4
02d62120: ldr     x0, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d62124: ldr     x19, [x19, #0x30]                          ._keycapList
02d62128: ldr     w8, [x0, #0xe4]                            [626b0e4]=0 f=0,0
02d6212c: cbnz    w8, #0x2d62138                             
02d62130: bl      #0x2b70f30                                 fn_2b70f30
02d62134: ldr     x0, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d62138: ldr     x8, [x0, #0xb8]                            S:'scoop_no_thank'
02d6213c: ldr     x20, [x8, #0x18]                           T:type57265(k15)
02d62140: cbnz    x20, #0x2d6219c                            
02d62144: ldr     w9, [x0, #0xe4]                            [626b0e4]=0 f=0,0
02d62148: cbnz    w9, #0x2d62158                             
02d6214c: bl      #0x2b70f30                                 fn_2b70f30
02d62150: ldr     x8, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d62154: ldr     x8, [x8, #0xb8]                            S:'scoop_no_thank'
02d62158: adrp    x9, #0x626b000                             
02d6215c: ldr     x9, [x9, #0xf70]                           T:type53129(k15)
02d62160: ldr     x21, [x8]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d62164: ldr     x0, [x9]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d62168: bl      #0x2b7104c                                 fn_2b7104c
02d6216c: adrp    x8, #0x626b000                             
02d62170: mov     x1, x21                                    
02d62174: mov     x3, xzr                                    
02d62178: ldr     x8, [x8, #0xfc0]                           M:Clicker.DragManager/<>c::<UpdateFallbackPosition>b__14_2
02d6217c: mov     x20, x0                                    
02d62180: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d62184: bl      #0x453418c                                 fn_453418c
02d62188: ldr     x8, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d6218c: mov     x1, x20                                    
02d62190: ldr     x0, [x8, #0xb8]                            S:'scoop_no_thank'
02d62194: str     x20, [x0, #0x18]!                          
02d62198: bl      #0x2b70d54                                 fn_2b70d54
02d6219c: cbz     x19, #0x2d621c4                            
02d621a0: adrp    x8, #0x626b000                             
02d621a4: mov     x0, x19                                    
02d621a8: mov     x1, x20                                    
02d621ac: ldr     x8, [x8, #0xf78]                           MS:System.Collections.Generic.List`1::ForEach
02d621b0: ldp     x20, x19, [sp, #0x20]                      
02d621b4: ldp     x22, x21, [sp, #0x10]                      
02d621b8: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d621bc: ldp     x30, x23, [sp], #0x30                      
02d621c0: b       #0x35a9ce4                                 
02d621c4: bl      #0x2b7105c                                 fn_2b7105c
## Update() -> void
---- Clicker.DragManager::Update 0x2d621c8
02d621c8: str     d10, [sp, #-0x40]!                         
02d621cc: stp     d9, d8, [sp, #0x10]                        
02d621d0: stp     x30, x21, [sp, #0x20]                      
02d621d4: stp     x20, x19, [sp, #0x30]                      
02d621d8: adrp    x20, #0x6630000                            
02d621dc: mov     x19, x0                                    
02d621e0: ldrb    w8, [x20, #0x303]                          
02d621e4: tbnz    w8, #0, #0x2d62214                         
02d621e8: adrp    x0, #0x626b000                             
02d621ec: ldr     x0, [x0, #0xfc8]                           T:Clicker.IClickerDraggableItem
02d621f0: bl      #0x2b70db0                                 fn_2b70db0
02d621f4: adrp    x0, #0x626b000                             
02d621f8: ldr     x0, [x0, #0xee0]                           MS:MonoSingleton`1::get_Instance
02d621fc: bl      #0x2b70db0                                 fn_2b70db0
02d62200: adrp    x0, #0x6267000                             
02d62204: ldr     x0, [x0, #0xea8]                           T:Framework.Vibration
02d62208: bl      #0x2b70db0                                 fn_2b70db0
02d6220c: mov     w8, #1                                     
02d62210: strb    w8, [x20, #0x303]                          
02d62214: ldrb    w8, [x19, #0x70]                           ._allowDrag
02d62218: cbz     w8, #0x2d62400                             
02d6221c: adrp    x20, #0x662f000                            
02d62220: ldrb    w8, [x20, #0xbd9]                          
02d62224: cbnz    w8, #0x2d6223c                             
02d62228: adrp    x0, #0x6266000                             
02d6222c: ldr     x0, [x0, #0x950]                           T:UnityEngine.InputSystem.Pointer
02d62230: bl      #0x2b70db0                                 fn_2b70db0
02d62234: mov     w8, #1                                     
02d62238: strb    w8, [x20, #0xbd9]                          
02d6223c: adrp    x8, #0x6266000                             
02d62240: ldr     x8, [x8, #0x950]                           T:UnityEngine.InputSystem.Pointer
02d62244: ldr     x8, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d62248: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02d6224c: ldr     x20, [x8]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d62250: cbz     x20, #0x2d62400                            
02d62254: ldr     x0, [x20, #0x1a8]                          [662f1a8]=600006c f=2.40744e-35,0
02d62258: cbz     x0, #0x2d626d4                             
02d6225c: mov     x1, xzr                                    
02d62260: bl      #0x55532f0                                 UnityEngine.InputSystem.Controls.ButtonControl::get_wasPressedThisFrame
02d62264: tbz     w0, #0, #0x2d622e8                         
02d62268: mov     x0, x19                                    
02d6226c: mov     x1, x20                                    
02d62270: bl      #0x2d626d8                                 Clicker.DragManager::GetWorldPoint
02d62274: mov     x0, x19                                    
02d62278: fmov    s8, s0                                     
02d6227c: fmov    s9, s1                                     
02d62280: bl      #0x2d6274c                                 Clicker.DragManager::Pick
02d62284: mov     x20, x19                                   
02d62288: mov     x1, x0                                     
02d6228c: str     x0, [x20, #0x48]!                          ._current
02d62290: mov     x0, x20                                    
02d62294: bl      #0x2b70d54                                 fn_2b70d54
02d62298: ldr     x20, [x20]                                 &2b706c4(=eb01011ff9400808)
02d6229c: cbz     x20, #0x2d62400                            
02d622a0: adrp    x21, #0x626b000                            
02d622a4: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02d622a8: ldr     x21, [x21, #0xfc8]                         T:Clicker.IClickerDraggableItem
02d622ac: ldrh    w9, [x8, #0x12e]                           
02d622b0: ldr     x1, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d622b4: cbz     x9, #0x2d622d8                             
02d622b8: ldr     x10, [x8, #0xb0]                           S:'native_banner_ad_on_off'
02d622bc: add     x10, x10, #8                               
02d622c0: ldur    x11, [x10, #-8]                            
02d622c4: cmp     x11, x1                                    
02d622c8: b.eq    #0x2d62414                                 
02d622cc: subs    x9, x9, #1                                 
02d622d0: add     x10, x10, #0x10                            
02d622d4: b.ne    #0x2d622c0                                 
02d622d8: mov     x0, x20                                    
02d622dc: mov     w2, #1                                     
02d622e0: bl      #0x2baa05c                                 fn_2baa05c
02d622e4: b       #0x2d62424                                 
02d622e8: ldr     x0, [x20, #0x1a8]                          [662f1a8]=600006c f=2.40744e-35,0
02d622ec: cbz     x0, #0x2d626d4                             
02d622f0: mov     x1, xzr                                    
02d622f4: bl      #0x5553134                                 UnityEngine.InputSystem.Controls.ButtonControl::get_isPressed
02d622f8: tbz     w0, #0, #0x2d62368                         
02d622fc: ldr     x8, [x19, #0x48]                           ._current
02d62300: cbz     x8, #0x2d62368                             
02d62304: mov     x0, x19                                    
02d62308: mov     x1, x20                                    
02d6230c: bl      #0x2d626d8                                 Clicker.DragManager::GetWorldPoint
02d62310: ldr     x20, [x19, #0x48]                          ._current
02d62314: cbz     x20, #0x2d626d4                            
02d62318: adrp    x21, #0x626b000                            
02d6231c: fmov    s8, s0                                     
02d62320: fmov    s9, s1                                     
02d62324: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02d62328: ldr     x21, [x21, #0xfc8]                         T:Clicker.IClickerDraggableItem
02d6232c: ldrh    w9, [x8, #0x12e]                           
02d62330: ldr     x1, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d62334: cbz     x9, #0x2d62358                             
02d62338: ldr     x10, [x8, #0xb0]                           S:'native_banner_ad_on_off'
02d6233c: add     x10, x10, #8                               
02d62340: ldur    x11, [x10, #-8]                            
02d62344: cmp     x11, x1                                    
02d62348: b.eq    #0x2d62614                                 
02d6234c: subs    x9, x9, #1                                 
02d62350: add     x10, x10, #0x10                            
02d62354: b.ne    #0x2d62340                                 
02d62358: mov     x0, x20                                    
02d6235c: mov     w2, #1                                     
02d62360: bl      #0x2baa05c                                 fn_2baa05c
02d62364: b       #0x2d62624                                 
02d62368: ldr     x0, [x20, #0x1a8]                          [662f1a8]=600006c f=2.40744e-35,0
02d6236c: cbz     x0, #0x2d626d4                             
02d62370: mov     x1, xzr                                    
02d62374: bl      #0x5553460                                 UnityEngine.InputSystem.Controls.ButtonControl::get_wasReleasedThisFrame
02d62378: tbz     w0, #0, #0x2d62400                         
02d6237c: mov     x20, x19                                   
02d62380: ldr     x2, [x20, #0x48]!                          [662f048]=6000017 f=2.40742e-35,0 ._current
02d62384: cbz     x2, #0x2d62400                             
02d62388: adrp    x8, #0x626b000                             
02d6238c: mov     w0, #1                                     
02d62390: ldr     x8, [x8, #0xfc8]                           T:Clicker.IClickerDraggableItem
02d62394: ldr     x1, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d62398: bl      #0x27387e4                                 fn_27387e4
02d6239c: cbz     x0, #0x2d626d4                             
02d623a0: ldr     x1, [x19, #0x50]                           ._tfOldParent
02d623a4: mov     x2, xzr                                    
02d623a8: bl      #0x5b472ec                                 UnityEngine.Transform::SetParent
02d623ac: adrp    x8, #0x6267000                             
02d623b0: ldr     x8, [x8, #0xea8]                           T:Framework.Vibration
02d623b4: ldr     x0, [x8]                                   S:'didu'
02d623b8: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d623bc: cbnz    w8, #0x2d623c4                             
02d623c0: bl      #0x2b70f30                                 fn_2b70f30
02d623c4: mov     w0, #0x32                                  
02d623c8: mov     w1, #-1                                    
02d623cc: mov     w2, wzr                                    
02d623d0: mov     x3, xzr                                    
02d623d4: bl      #0x2d6e144                                 Framework.Vibration::Vibrate
02d623d8: mov     x0, x19                                    
02d623dc: bl      #0x2d628f4                                 Clicker.DragManager::CheckLogic
02d623e0: mov     x0, x20                                    
02d623e4: str     xzr, [x19, #0x48]                          ._current
02d623e8: mov     x1, xzr                                    
02d623ec: ldp     x20, x19, [sp, #0x30]                      
02d623f0: ldp     x30, x21, [sp, #0x20]                      
02d623f4: ldp     d9, d8, [sp, #0x10]                        
02d623f8: ldr     d10, [sp], #0x40                           
02d623fc: b       #0x2b70d54                                 
02d62400: ldp     x20, x19, [sp, #0x30]                      
02d62404: ldp     x30, x21, [sp, #0x20]                      
02d62408: ldp     d9, d8, [sp, #0x10]                        
02d6240c: ldr     d10, [sp], #0x40                           
02d62410: ret                                                
02d62414: ldr     w9, [x10]                                  
02d62418: add     w9, w9, #1                                 
02d6241c: add     x8, x8, w9, sxtw #4                        &6267000
02d62420: add     x0, x8, #0x138                             &6267138
02d62424: ldp     x8, x1, [x0]                               
02d62428: mov     x0, x20                                    
02d6242c: blr     x8                                         
02d62430: cbz     x0, #0x2d626d4                             
02d62434: mov     x1, xzr                                    
02d62438: bl      #0x5b466dc                                 UnityEngine.Transform::get_parent
02d6243c: mov     x20, x19                                   
02d62440: mov     x1, x0                                     
02d62444: str     x0, [x20, #0x50]!                          ._tfOldParent
02d62448: mov     x0, x20                                    
02d6244c: bl      #0x2b70d54                                 fn_2b70d54
02d62450: ldur    x20, [x20, #-8]                            
02d62454: cbz     x20, #0x2d626d4                            
02d62458: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02d6245c: ldr     x1, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d62460: ldrh    w9, [x8, #0x12e]                           
02d62464: cbz     x9, #0x2d62488                             
02d62468: ldr     x10, [x8, #0xb0]                           M:Framework.SceneUtils/<CRLoadSceneAsync>d__1::System.Collections.IEnumerator.Reset
02d6246c: add     x10, x10, #8                               
02d62470: ldur    x11, [x10, #-8]                            
02d62474: cmp     x11, x1                                    
02d62478: b.eq    #0x2d62498                                 
02d6247c: subs    x9, x9, #1                                 
02d62480: add     x10, x10, #0x10                            
02d62484: b.ne    #0x2d62470                                 
02d62488: mov     x0, x20                                    
02d6248c: mov     w2, #1                                     
02d62490: bl      #0x2baa05c                                 fn_2baa05c
02d62494: b       #0x2d624a8                                 
02d62498: ldr     w9, [x10]                                  
02d6249c: add     w9, w9, #1                                 
02d624a0: add     x8, x8, w9, sxtw #4                        &6267000
02d624a4: add     x0, x8, #0x138                             &6267138
02d624a8: ldp     x8, x1, [x0]                               
02d624ac: mov     x0, x20                                    
02d624b0: blr     x8                                         
02d624b4: cbz     x0, #0x2d626d4                             
02d624b8: ldr     x1, [x19, #0x38]                           ._tfCurrentHolding
02d624bc: mov     x2, xzr                                    
02d624c0: bl      #0x5b472ec                                 UnityEngine.Transform::SetParent
02d624c4: ldr     x20, [x19, #0x48]                          ._current
02d624c8: cbz     x20, #0x2d626d4                            
02d624cc: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02d624d0: ldr     x1, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d624d4: ldrh    w9, [x8, #0x12e]                           
02d624d8: cbz     x9, #0x2d624fc                             
02d624dc: ldr     x10, [x8, #0xb0]                           M:Framework.SceneUtils/<CRLoadSceneAsync>d__1::System.Collections.IEnumerator.Reset
02d624e0: add     x10, x10, #8                               
02d624e4: ldur    x11, [x10, #-8]                            
02d624e8: cmp     x11, x1                                    
02d624ec: b.eq    #0x2d6250c                                 
02d624f0: subs    x9, x9, #1                                 
02d624f4: add     x10, x10, #0x10                            
02d624f8: b.ne    #0x2d624e4                                 
02d624fc: mov     x0, x20                                    
02d62500: mov     w2, #1                                     
02d62504: bl      #0x2baa05c                                 fn_2baa05c
02d62508: b       #0x2d6251c                                 
02d6250c: ldr     w9, [x10]                                  
02d62510: add     w9, w9, #1                                 
02d62514: add     x8, x8, w9, sxtw #4                        &6267000
02d62518: add     x0, x8, #0x138                             &6267138
02d6251c: ldp     x8, x1, [x0]                               
02d62520: mov     x0, x20                                    
02d62524: blr     x8                                         
02d62528: cbz     x0, #0x2d626d4                             
02d6252c: mov     x1, xzr                                    
02d62530: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d62534: fsub    s1, s1, s9                                 
02d62538: fsub    s0, s0, s8                                 
02d6253c: ldr     d3, [x19, #0x68]                           
02d62540: ldr     x20, [x19, #0x48]                          ._current
02d62544: mov     v1.s[1], v2.s[0]                           
02d62548: ldr     s2, [x19, #0x64]                           ._handOffset
02d6254c: fadd    s0, s2, s0                                 
02d62550: fadd    v1.2s, v1.2s, v3.2s                        
02d62554: str     s0, [x19, #0x58]                           ._offset
02d62558: stur    d1, [x19, #0x5c]                           
02d6255c: cbz     x20, #0x2d626d4                            
02d62560: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02d62564: ldr     x1, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d62568: ldrh    w9, [x8, #0x12e]                           
02d6256c: cbz     x9, #0x2d62590                             
02d62570: ldr     x10, [x8, #0xb0]                           M:Framework.SceneUtils/<CRLoadSceneAsync>d__1::System.Collections.IEnumerator.Reset
02d62574: add     x10, x10, #8                               
02d62578: ldur    x11, [x10, #-8]                            
02d6257c: cmp     x11, x1                                    
02d62580: b.eq    #0x2d625a0                                 
02d62584: subs    x9, x9, #1                                 
02d62588: add     x10, x10, #0x10                            
02d6258c: b.ne    #0x2d62578                                 
02d62590: mov     x0, x20                                    
02d62594: mov     w2, #5                                     
02d62598: bl      #0x2baa05c                                 fn_2baa05c
02d6259c: b       #0x2d625b0                                 
02d625a0: ldr     w9, [x10]                                  
02d625a4: add     w9, w9, #5                                 
02d625a8: add     x8, x8, w9, sxtw #4                        &6267000
02d625ac: add     x0, x8, #0x138                             &6267138
02d625b0: ldp     x8, x1, [x0]                               
02d625b4: mov     x0, x20                                    
02d625b8: blr     x8                                         
02d625bc: adrp    x8, #0x6267000                             
02d625c0: ldr     x8, [x8, #0xea8]                           T:Framework.Vibration
02d625c4: ldr     x0, [x8]                                   S:'didu'
02d625c8: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d625cc: cbnz    w8, #0x2d625d4                             
02d625d0: bl      #0x2b70f30                                 fn_2b70f30
02d625d4: mov     w0, #0x32                                  
02d625d8: mov     w1, #-1                                    
02d625dc: mov     w2, wzr                                    
02d625e0: mov     x3, xzr                                    
02d625e4: bl      #0x2d6e144                                 Framework.Vibration::Vibrate
02d625e8: adrp    x8, #0x626b000                             
02d625ec: ldr     x8, [x8, #0xee0]                           MS:MonoSingleton`1::get_Instance
02d625f0: ldr     x0, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d625f4: bl      #0x3769600                                 fn_3769600
02d625f8: cbz     x0, #0x2d626d4                             
02d625fc: ldp     x20, x19, [sp, #0x30]                      
02d62600: mov     w1, wzr                                    
02d62604: ldp     x30, x21, [sp, #0x20]                      
02d62608: ldp     d9, d8, [sp, #0x10]                        
02d6260c: ldr     d10, [sp], #0x40                           
02d62610: b       #0x2d62830                                 Clicker.KeycapMakerController::ShowDragHandTutorial
02d62614: ldr     w9, [x10]                                  
02d62618: add     w9, w9, #1                                 
02d6261c: add     x8, x8, w9, sxtw #4                        &626b000
02d62620: add     x0, x8, #0x138                             &626b138
02d62624: ldp     x8, x1, [x0]                               
02d62628: mov     x0, x20                                    
02d6262c: blr     x8                                         
02d62630: cbz     x0, #0x2d626d4                             
02d62634: mov     x1, xzr                                    
02d62638: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d6263c: ldr     x20, [x19, #0x48]                          ._current
02d62640: cbz     x20, #0x2d626d4                            
02d62644: fmov    s10, s2                                    
02d62648: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02d6264c: ldr     x1, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d62650: ldrh    w9, [x8, #0x12e]                           
02d62654: cbz     x9, #0x2d62678                             
02d62658: ldr     x10, [x8, #0xb0]                           T:ScoopGame.CompletedPopup/<>c
02d6265c: add     x10, x10, #8                               
02d62660: ldur    x11, [x10, #-8]                            
02d62664: cmp     x11, x1                                    
02d62668: b.eq    #0x2d62688                                 
02d6266c: subs    x9, x9, #1                                 
02d62670: add     x10, x10, #0x10                            
02d62674: b.ne    #0x2d62660                                 
02d62678: mov     x0, x20                                    
02d6267c: mov     w2, #1                                     
02d62680: bl      #0x2baa05c                                 fn_2baa05c
02d62684: b       #0x2d62698                                 
02d62688: ldr     w9, [x10]                                  
02d6268c: add     w9, w9, #1                                 
02d62690: add     x8, x8, w9, sxtw #4                        &626b000
02d62694: add     x0, x8, #0x138                             &626b138
02d62698: ldp     x8, x1, [x0]                               
02d6269c: mov     x0, x20                                    
02d626a0: blr     x8                                         
02d626a4: cbz     x0, #0x2d626d4                             
02d626a8: ldp     s0, s1, [x19, #0x58]                       ._offset
02d626ac: mov     x1, xzr                                    
02d626b0: ldr     s2, [x19, #0x60]                           
02d626b4: ldp     x20, x19, [sp, #0x30]                      
02d626b8: ldp     x30, x21, [sp, #0x20]                      
02d626bc: fadd    s0, s8, s0                                 
02d626c0: fadd    s1, s9, s1                                 
02d626c4: fadd    s2, s10, s2                                
02d626c8: ldp     d9, d8, [sp, #0x10]                        
02d626cc: ldr     d10, [sp], #0x40                           
02d626d0: b       #0x5b46888                                 UnityEngine.Transform::set_position
02d626d4: bl      #0x2b7105c                                 fn_2b7105c
## CheckLogic() -> void
---- Clicker.DragManager::CheckLogic 0x2d628f4
02d628f4: str     x30, [sp, #-0x40]!                         
02d628f8: stp     x24, x23, [sp, #0x10]                      
02d628fc: stp     x22, x21, [sp, #0x20]                      
02d62900: stp     x20, x19, [sp, #0x30]                      
02d62904: adrp    x20, #0x6630000                            
02d62908: mov     x19, x0                                    
02d6290c: ldrb    w8, [x20, #0x304]                          
02d62910: tbnz    w8, #0, #0x2d62940                         
02d62914: adrp    x0, #0x626b000                             
02d62918: ldr     x0, [x0, #0xfe8]                           MS:UnityEngine.Component::GetComponent
02d6291c: bl      #0x2b70db0                                 fn_2b70db0
02d62920: adrp    x0, #0x626b000                             
02d62924: ldr     x0, [x0, #0xfc8]                           T:Clicker.IClickerDraggableItem
02d62928: bl      #0x2b70db0                                 fn_2b70db0
02d6292c: adrp    x0, #0x6263000                             
02d62930: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d62934: bl      #0x2b70db0                                 fn_2b70db0
02d62938: mov     w8, #1                                     
02d6293c: strb    w8, [x20, #0x304]                          
02d62940: ldr     x20, [x19, #0x48]                          ._current
02d62944: cbz     x20, #0x2d63074                            
02d62948: adrp    x23, #0x626b000                            
02d6294c: ldr     x8, [x20]                                  
02d62950: ldr     x23, [x23, #0xfc8]                         T:Clicker.IClickerDraggableItem
02d62954: ldrh    w9, [x8, #0x12e]                           
02d62958: ldr     x1, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d6295c: cbz     x9, #0x2d62980                             
02d62960: ldr     x10, [x8, #0xb0]                           
02d62964: add     x10, x10, #8                               
02d62968: ldur    x11, [x10, #-8]                            
02d6296c: cmp     x11, x1                                    
02d62970: b.eq    #0x2d62990                                 
02d62974: subs    x9, x9, #1                                 
02d62978: add     x10, x10, #0x10                            
02d6297c: b.ne    #0x2d62968                                 
02d62980: mov     x0, x20                                    
02d62984: mov     w2, #4                                     
02d62988: bl      #0x2baa05c                                 fn_2baa05c
02d6298c: b       #0x2d629a0                                 
02d62990: ldr     w9, [x10]                                  
02d62994: add     w9, w9, #4                                 
02d62998: add     x8, x8, w9, sxtw #4                        
02d6299c: add     x0, x8, #0x138                             
02d629a0: ldp     x8, x1, [x0]                               
02d629a4: mov     x0, x20                                    
02d629a8: blr     x8                                         
02d629ac: cmp     w0, #2                                     
02d629b0: b.eq    #0x2d62a58                                 
02d629b4: cmp     w0, #1                                     
02d629b8: b.eq    #0x2d62a0c                                 
02d629bc: cbnz    w0, #0x2d62d28                             
02d629c0: ldr     x21, [x19, #0x48]                          ._current
02d629c4: cbz     x21, #0x2d63074                            
02d629c8: ldr     x8, [x21]                                  
02d629cc: ldr     x20, [x19, #0x78]                          ._baseKeycapObjectChecking
02d629d0: ldr     x1, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d629d4: ldrh    w9, [x8, #0x12e]                           
02d629d8: cbz     x9, #0x2d629fc                             
02d629dc: ldr     x10, [x8, #0xb0]                           
02d629e0: add     x10, x10, #8                               
02d629e4: ldur    x11, [x10, #-8]                            
02d629e8: cmp     x11, x1                                    
02d629ec: b.eq    #0x2d62be4                                 
02d629f0: subs    x9, x9, #1                                 
02d629f4: add     x10, x10, #0x10                            
02d629f8: b.ne    #0x2d629e4                                 
02d629fc: mov     x0, x21                                    
02d62a00: mov     w2, #1                                     
02d62a04: bl      #0x2baa05c                                 fn_2baa05c
02d62a08: b       #0x2d62bf4                                 
02d62a0c: ldr     x21, [x19, #0x48]                          ._current
02d62a10: cbz     x21, #0x2d63074                            
02d62a14: ldr     x8, [x21]                                  
02d62a18: ldr     x20, [x19, #0x78]                          ._baseKeycapObjectChecking
02d62a1c: ldr     x1, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d62a20: ldrh    w9, [x8, #0x12e]                           
02d62a24: cbz     x9, #0x2d62a48                             
02d62a28: ldr     x10, [x8, #0xb0]                           
02d62a2c: add     x10, x10, #8                               
02d62a30: ldur    x11, [x10, #-8]                            
02d62a34: cmp     x11, x1                                    
02d62a38: b.eq    #0x2d62aa4                                 
02d62a3c: subs    x9, x9, #1                                 
02d62a40: add     x10, x10, #0x10                            
02d62a44: b.ne    #0x2d62a30                                 
02d62a48: mov     x0, x21                                    
02d62a4c: mov     w2, #1                                     
02d62a50: bl      #0x2baa05c                                 fn_2baa05c
02d62a54: b       #0x2d62ab4                                 
02d62a58: ldr     x21, [x19, #0x48]                          ._current
02d62a5c: cbz     x21, #0x2d63074                            
02d62a60: ldr     x8, [x21]                                  
02d62a64: ldr     x20, [x19, #0x78]                          ._baseKeycapObjectChecking
02d62a68: ldr     x1, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d62a6c: ldrh    w9, [x8, #0x12e]                           
02d62a70: cbz     x9, #0x2d62a94                             
02d62a74: ldr     x10, [x8, #0xb0]                           
02d62a78: add     x10, x10, #8                               
02d62a7c: ldur    x11, [x10, #-8]                            
02d62a80: cmp     x11, x1                                    
02d62a84: b.eq    #0x2d62b5c                                 
02d62a88: subs    x9, x9, #1                                 
02d62a8c: add     x10, x10, #0x10                            
02d62a90: b.ne    #0x2d62a7c                                 
02d62a94: mov     x0, x21                                    
02d62a98: mov     w2, #1                                     
02d62a9c: bl      #0x2baa05c                                 fn_2baa05c
02d62aa0: b       #0x2d62b6c                                 
02d62aa4: ldr     w9, [x10]                                  
02d62aa8: add     w9, w9, #1                                 
02d62aac: add     x8, x8, w9, sxtw #4                        
02d62ab0: add     x0, x8, #0x138                             
02d62ab4: ldp     x8, x1, [x0]                               
02d62ab8: mov     x0, x21                                    
02d62abc: blr     x8                                         
02d62ac0: cbz     x20, #0x2d63074                            
02d62ac4: fmov    s0, #2.50000000                            
02d62ac8: mov     x1, x0                                     
02d62acc: mov     x0, x20                                    
02d62ad0: bl      #0x2d5faf0                                 Clicker.BaseKeycapObject::CheckDropKeycap
02d62ad4: ldr     x21, [x19, #0x48]                          ._current
02d62ad8: tbnz    w0, #0x1f, #0x2d62b24                      
02d62adc: cbz     x21, #0x2d63074                            
02d62ae0: ldr     x8, [x21]                                  
02d62ae4: ldr     x1, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d62ae8: mov     w20, w0                                    
02d62aec: ldrh    w9, [x8, #0x12e]                           
02d62af0: cbz     x9, #0x2d62b14                             
02d62af4: ldr     x10, [x8, #0xb0]                           
02d62af8: add     x10, x10, #8                               
02d62afc: ldur    x11, [x10, #-8]                            
02d62b00: cmp     x11, x1                                    
02d62b04: b.eq    #0x2d62cc4                                 
02d62b08: subs    x9, x9, #1                                 
02d62b0c: add     x10, x10, #0x10                            
02d62b10: b.ne    #0x2d62afc                                 
02d62b14: mov     x0, x21                                    
02d62b18: mov     w2, #1                                     
02d62b1c: bl      #0x2baa05c                                 fn_2baa05c
02d62b20: b       #0x2d62cd4                                 
02d62b24: cbz     x21, #0x2d63074                            
02d62b28: ldr     x8, [x21]                                  
02d62b2c: ldr     x1, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d62b30: ldrh    w9, [x8, #0x12e]                           
02d62b34: cbz     x9, #0x2d62c98                             
02d62b38: ldr     x10, [x8, #0xb0]                           
02d62b3c: add     x10, x10, #8                               
02d62b40: ldur    x11, [x10, #-8]                            
02d62b44: cmp     x11, x1                                    
02d62b48: b.eq    #0x2d62ca8                                 
02d62b4c: subs    x9, x9, #1                                 
02d62b50: add     x10, x10, #0x10                            
02d62b54: b.ne    #0x2d62b40                                 
02d62b58: b       #0x2d62c98                                 
02d62b5c: ldr     w9, [x10]                                  
02d62b60: add     w9, w9, #1                                 
02d62b64: add     x8, x8, w9, sxtw #4                        
02d62b68: add     x0, x8, #0x138                             
02d62b6c: ldp     x8, x1, [x0]                               
02d62b70: mov     x0, x21                                    
02d62b74: blr     x8                                         
02d62b78: cbz     x20, #0x2d63074                            
02d62b7c: fmov    s0, #2.00000000                            
02d62b80: mov     x1, x0                                     
02d62b84: mov     x0, x20                                    
02d62b88: bl      #0x2d5f4ac                                 Clicker.BaseKeycapObject::CheckDropKeychain
02d62b8c: tbz     w0, #0, #0x2d62e9c                         
02d62b90: ldr     x0, [x19, #0x78]                           ._baseKeycapObjectChecking
02d62b94: cbz     x0, #0x2d63074                             
02d62b98: bl      #0x2d5f5a0                                 Clicker.BaseKeycapObject::ActiveKeychain
02d62b9c: ldr     x20, [x19, #0x48]                          ._current
02d62ba0: cbz     x20, #0x2d63074                            
02d62ba4: ldr     x8, [x20]                                  
02d62ba8: ldr     x1, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d62bac: ldrh    w9, [x8, #0x12e]                           
02d62bb0: cbz     x9, #0x2d62bd4                             
02d62bb4: ldr     x10, [x8, #0xb0]                           
02d62bb8: add     x10, x10, #8                               
02d62bbc: ldur    x11, [x10, #-8]                            
02d62bc0: cmp     x11, x1                                    
02d62bc4: b.eq    #0x2d62e54                                 
02d62bc8: subs    x9, x9, #1                                 
02d62bcc: add     x10, x10, #0x10                            
02d62bd0: b.ne    #0x2d62bbc                                 
02d62bd4: mov     x0, x20                                    
02d62bd8: mov     w2, #7                                     
02d62bdc: bl      #0x2baa05c                                 fn_2baa05c
02d62be0: b       #0x2d62e64                                 
02d62be4: ldr     w9, [x10]                                  
02d62be8: add     w9, w9, #1                                 
02d62bec: add     x8, x8, w9, sxtw #4                        
02d62bf0: add     x0, x8, #0x138                             
02d62bf4: ldp     x8, x1, [x0]                               
02d62bf8: mov     x0, x21                                    
02d62bfc: blr     x8                                         
02d62c00: cbz     x20, #0x2d63074                            
02d62c04: fmov    s0, #3.00000000                            
02d62c08: mov     x1, x0                                     
02d62c0c: mov     x0, x20                                    
02d62c10: bl      #0x2d5f79c                                 Clicker.BaseKeycapObject::CheckDropSwitch
02d62c14: ldr     x21, [x19, #0x48]                          ._current
02d62c18: tbnz    w0, #0x1f, #0x2d62c64                      
02d62c1c: cbz     x21, #0x2d63074                            
02d62c20: ldr     x8, [x21]                                  
02d62c24: ldr     x1, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d62c28: mov     w20, w0                                    
02d62c2c: ldrh    w9, [x8, #0x12e]                           
02d62c30: cbz     x9, #0x2d62c54                             
02d62c34: ldr     x10, [x8, #0xb0]                           
02d62c38: add     x10, x10, #8                               
02d62c3c: ldur    x11, [x10, #-8]                            
02d62c40: cmp     x11, x1                                    
02d62c44: b.eq    #0x2d62d84                                 
02d62c48: subs    x9, x9, #1                                 
02d62c4c: add     x10, x10, #0x10                            
02d62c50: b.ne    #0x2d62c3c                                 
02d62c54: mov     x0, x21                                    
02d62c58: mov     w2, #7                                     
02d62c5c: bl      #0x2baa05c                                 fn_2baa05c
02d62c60: b       #0x2d62d94                                 
02d62c64: cbz     x21, #0x2d63074                            
02d62c68: ldr     x8, [x21]                                  
02d62c6c: ldr     x1, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d62c70: ldrh    w9, [x8, #0x12e]                           
02d62c74: cbz     x9, #0x2d62c98                             
02d62c78: ldr     x10, [x8, #0xb0]                           
02d62c7c: add     x10, x10, #8                               
02d62c80: ldur    x11, [x10, #-8]                            
02d62c84: cmp     x11, x1                                    
02d62c88: b.eq    #0x2d62ca8                                 
02d62c8c: subs    x9, x9, #1                                 
02d62c90: add     x10, x10, #0x10                            
02d62c94: b.ne    #0x2d62c80                                 
02d62c98: mov     x0, x21                                    
02d62c9c: mov     w2, #6                                     
02d62ca0: bl      #0x2baa05c                                 fn_2baa05c
02d62ca4: b       #0x2d62cb8                                 
02d62ca8: ldr     w9, [x10]                                  
02d62cac: add     w9, w9, #6                                 
02d62cb0: add     x8, x8, w9, sxtw #4                        
02d62cb4: add     x0, x8, #0x138                             
02d62cb8: ldp     x3, x2, [x0]                               
02d62cbc: mov     x0, x21                                    
02d62cc0: b       #0x2d62efc                                 
02d62cc4: ldr     w9, [x10]                                  
02d62cc8: add     w9, w9, #1                                 
02d62ccc: add     x8, x8, w9, sxtw #4                        
02d62cd0: add     x0, x8, #0x138                             
02d62cd4: ldp     x8, x1, [x0]                               
02d62cd8: mov     x0, x21                                    
02d62cdc: blr     x8                                         
02d62ce0: cbz     x0, #0x2d63074                             
02d62ce4: adrp    x8, #0x626b000                             
02d62ce8: ldr     x8, [x8, #0xfe8]                           MS:UnityEngine.Component::GetComponent
02d62cec: ldr     x1, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d62cf0: bl      #0x3140c84                                 fn_3140c84
02d62cf4: adrp    x24, #0x6263000                            
02d62cf8: mov     x21, x0                                    
02d62cfc: ldr     x24, [x24, #0x918]                         T:UnityEngine.Object
02d62d00: ldr     x8, [x24]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d62d04: ldr     w9, [x8, #0xe4]                            [626b0e4]=0 f=0,0
02d62d08: cbnz    w9, #0x2d62d14                             
02d62d0c: mov     x0, x8                                     
02d62d10: bl      #0x2b70f30                                 fn_2b70f30
02d62d14: mov     x0, x21                                    
02d62d18: mov     x1, xzr                                    
02d62d1c: mov     x2, xzr                                    
02d62d20: bl      #0x5b37d84                                 UnityEngine.Object::op_Equality
02d62d24: tbz     w0, #0, #0x2d62d3c                         
02d62d28: ldp     x20, x19, [sp, #0x30]                      
02d62d2c: ldp     x22, x21, [sp, #0x20]                      
02d62d30: ldp     x24, x23, [sp, #0x10]                      
02d62d34: ldr     x30, [sp], #0x40                           
02d62d38: ret                                                
02d62d3c: ldr     x22, [x19, #0x48]                          ._current
02d62d40: cbz     x22, #0x2d63074                            
02d62d44: ldr     x8, [x22]                                  
02d62d48: ldr     x1, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d62d4c: ldrh    w9, [x8, #0x12e]                           
02d62d50: cbz     x9, #0x2d62d74                             
02d62d54: ldr     x10, [x8, #0xb0]                           T:ScoopGame.CompletedPopup/<>c
02d62d58: add     x10, x10, #8                               
02d62d5c: ldur    x11, [x10, #-8]                            
02d62d60: cmp     x11, x1                                    
02d62d64: b.eq    #0x2d62f14                                 
02d62d68: subs    x9, x9, #1                                 
02d62d6c: add     x10, x10, #0x10                            
02d62d70: b.ne    #0x2d62d5c                                 
02d62d74: mov     x0, x22                                    
02d62d78: mov     w2, #7                                     
02d62d7c: bl      #0x2baa05c                                 fn_2baa05c
02d62d80: b       #0x2d62f24                                 
02d62d84: ldr     w9, [x10]                                  
02d62d88: add     w9, w9, #7                                 
02d62d8c: add     x8, x8, w9, sxtw #4                        &626b000
02d62d90: add     x0, x8, #0x138                             &626b138
02d62d94: ldp     x8, x1, [x0]                               
02d62d98: mov     x0, x21                                    
02d62d9c: blr     x8                                         
02d62da0: ldr     x0, [x19, #0x78]                           ._baseKeycapObjectChecking
02d62da4: cbz     x0, #0x2d63074                             
02d62da8: mov     w1, w20                                    
02d62dac: bl      #0x2d5f948                                 Clicker.BaseKeycapObject::DropSwitchReal
02d62db0: ldr     x19, [x19, #0x48]                          ._current
02d62db4: cbz     x19, #0x2d63074                            
02d62db8: ldr     x8, [x19]                                  
02d62dbc: ldr     x1, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d62dc0: ldrh    w9, [x8, #0x12e]                           
02d62dc4: cbz     x9, #0x2d62de8                             
02d62dc8: ldr     x10, [x8, #0xb0]                           T:ScoopGame.CompletedPopup/<>c
02d62dcc: add     x10, x10, #8                               
02d62dd0: ldur    x11, [x10, #-8]                            
02d62dd4: cmp     x11, x1                                    
02d62dd8: b.eq    #0x2d62df8                                 
02d62ddc: subs    x9, x9, #1                                 
02d62de0: add     x10, x10, #0x10                            
02d62de4: b.ne    #0x2d62dd0                                 
02d62de8: mov     x0, x19                                    
02d62dec: mov     w2, #6                                     
02d62df0: bl      #0x2baa05c                                 fn_2baa05c
02d62df4: b       #0x2d62e08                                 
02d62df8: ldr     w9, [x10]                                  
02d62dfc: add     w9, w9, #6                                 
02d62e00: add     x8, x8, w9, sxtw #4                        &626b000
02d62e04: add     x0, x8, #0x138                             &626b138
02d62e08: ldp     x8, x2, [x0]                               
02d62e0c: mov     x0, x19                                    
02d62e10: mov     w1, w20                                    
02d62e14: blr     x8                                         
02d62e18: mov     x0, xzr                                    
02d62e1c: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d62e20: cbz     x0, #0x2d63074                             
02d62e24: ldp     x20, x19, [sp, #0x30]                      
02d62e28: movi    d1, #0000000000000000                      
02d62e2c: ldp     x22, x21, [sp, #0x20]                      
02d62e30: movi    d2, #0000000000000000                      
02d62e34: ldp     x24, x23, [sp, #0x10]                      
02d62e38: fmov    s0, #1.00000000                            
02d62e3c: mov     w1, #0x34                                  
02d62e40: mov     w2, wzr                                    
02d62e44: mov     w3, wzr                                    
02d62e48: mov     x4, xzr                                    
02d62e4c: ldr     x30, [sp], #0x40                           
02d62e50: b       #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d62e54: ldr     w9, [x10]                                  
02d62e58: add     w9, w9, #7                                 
02d62e5c: add     x8, x8, w9, sxtw #4                        &626b000
02d62e60: add     x0, x8, #0x138                             &626b138
02d62e64: ldp     x8, x1, [x0]                               
02d62e68: mov     x0, x20                                    
02d62e6c: blr     x8                                         
02d62e70: mov     x0, xzr                                    
02d62e74: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d62e78: cbz     x0, #0x2d63074                             
02d62e7c: movi    d1, #0000000000000000                      
02d62e80: movi    d2, #0000000000000000                      
02d62e84: mov     w1, #0x34                                  
02d62e88: fmov    s0, #1.00000000                            
02d62e8c: mov     w2, wzr                                    
02d62e90: mov     w3, wzr                                    
02d62e94: mov     x4, xzr                                    
02d62e98: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d62e9c: ldr     x19, [x19, #0x48]                          ._current
02d62ea0: cbz     x19, #0x2d63074                            
02d62ea4: ldr     x8, [x19]                                  
02d62ea8: ldr     x1, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d62eac: ldrh    w9, [x8, #0x12e]                           
02d62eb0: cbz     x9, #0x2d62ed4                             
02d62eb4: ldr     x10, [x8, #0xb0]                           T:ScoopGame.CompletedPopup/<>c
02d62eb8: add     x10, x10, #8                               
02d62ebc: ldur    x11, [x10, #-8]                            
02d62ec0: cmp     x11, x1                                    
02d62ec4: b.eq    #0x2d62ee4                                 
02d62ec8: subs    x9, x9, #1                                 
02d62ecc: add     x10, x10, #0x10                            
02d62ed0: b.ne    #0x2d62ebc                                 
02d62ed4: mov     x0, x19                                    
02d62ed8: mov     w2, #6                                     
02d62edc: bl      #0x2baa05c                                 fn_2baa05c
02d62ee0: b       #0x2d62ef4                                 
02d62ee4: ldr     w9, [x10]                                  
02d62ee8: add     w9, w9, #6                                 
02d62eec: add     x8, x8, w9, sxtw #4                        &626b000
02d62ef0: add     x0, x8, #0x138                             &626b138
02d62ef4: ldp     x3, x2, [x0]                               
02d62ef8: mov     x0, x19                                    
02d62efc: ldp     x20, x19, [sp, #0x30]                      
02d62f00: mov     w1, #-1                                    
02d62f04: ldp     x22, x21, [sp, #0x20]                      
02d62f08: ldp     x24, x23, [sp, #0x10]                      
02d62f0c: ldr     x30, [sp], #0x40                           
02d62f10: br      x3                                         
02d62f14: ldr     w9, [x10]                                  
02d62f18: add     w9, w9, #7                                 
02d62f1c: add     x8, x8, w9, sxtw #4                        &626b000
02d62f20: add     x0, x8, #0x138                             &626b138
02d62f24: ldp     x8, x1, [x0]                               
02d62f28: mov     x0, x22                                    
02d62f2c: blr     x8                                         
02d62f30: ldr     x0, [x19, #0x78]                           ._baseKeycapObjectChecking
02d62f34: cbz     x0, #0x2d63074                             
02d62f38: mov     w1, w20                                    
02d62f3c: mov     x2, x21                                    
02d62f40: bl      #0x2d5fd2c                                 Clicker.BaseKeycapObject::DropKeycapReal
02d62f44: ldr     x21, [x19, #0x48]                          ._current
02d62f48: cbz     x21, #0x2d63074                            
02d62f4c: ldr     x8, [x21]                                  
02d62f50: ldr     x1, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d62f54: ldrh    w9, [x8, #0x12e]                           
02d62f58: cbz     x9, #0x2d62f7c                             
02d62f5c: ldr     x10, [x8, #0xb0]                           T:ScoopGame.CompletedPopup/<>c
02d62f60: add     x10, x10, #8                               
02d62f64: ldur    x11, [x10, #-8]                            
02d62f68: cmp     x11, x1                                    
02d62f6c: b.eq    #0x2d62f8c                                 
02d62f70: subs    x9, x9, #1                                 
02d62f74: add     x10, x10, #0x10                            
02d62f78: b.ne    #0x2d62f64                                 
02d62f7c: mov     x0, x21                                    
02d62f80: mov     w2, #6                                     
02d62f84: bl      #0x2baa05c                                 fn_2baa05c
02d62f88: b       #0x2d62f9c                                 
02d62f8c: ldr     w9, [x10]                                  
02d62f90: add     w9, w9, #6                                 
02d62f94: add     x8, x8, w9, sxtw #4                        &626b000
02d62f98: add     x0, x8, #0x138                             &626b138
02d62f9c: ldp     x8, x2, [x0]                               
02d62fa0: mov     x0, x21                                    
02d62fa4: mov     w1, w20                                    
02d62fa8: blr     x8                                         
02d62fac: ldr     x0, [x19, #0x78]                           ._baseKeycapObjectChecking
02d62fb0: cbz     x0, #0x2d63074                             
02d62fb4: mov     w1, w20                                    
02d62fb8: bl      #0x2d5fcb4                                 Clicker.BaseKeycapObject::GetPosKeycap
02d62fbc: ldr     x8, [x24]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d62fc0: mov     x20, x0                                    
02d62fc4: ldr     w9, [x8, #0xe4]                            [626b0e4]=0 f=0,0
02d62fc8: cbnz    w9, #0x2d62fd4                             
02d62fcc: mov     x0, x8                                     
02d62fd0: bl      #0x2b70f30                                 fn_2b70f30
02d62fd4: mov     x0, x20                                    
02d62fd8: mov     x1, xzr                                    
02d62fdc: mov     x2, xzr                                    
02d62fe0: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d62fe4: tbz     w0, #0, #0x2d62e18                         
02d62fe8: ldr     x19, [x19, #0x48]                          ._current
02d62fec: cbz     x19, #0x2d63074                            
02d62ff0: ldr     x8, [x19]                                  
02d62ff4: ldr     x1, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d62ff8: ldrh    w9, [x8, #0x12e]                           
02d62ffc: cbz     x9, #0x2d63020                             
02d63000: ldr     x10, [x8, #0xb0]                           T:ScoopGame.CompletedPopup/<>c
02d63004: add     x10, x10, #8                               
02d63008: ldur    x11, [x10, #-8]                            
02d6300c: cmp     x11, x1                                    
02d63010: b.eq    #0x2d63030                                 
02d63014: subs    x9, x9, #1                                 
02d63018: add     x10, x10, #0x10                            
02d6301c: b.ne    #0x2d63008                                 
02d63020: mov     x0, x19                                    
02d63024: mov     w2, #1                                     
02d63028: bl      #0x2baa05c                                 fn_2baa05c
02d6302c: b       #0x2d63040                                 
02d63030: ldr     w9, [x10]                                  
02d63034: add     w9, w9, #1                                 
02d63038: add     x8, x8, w9, sxtw #4                        &626b000
02d6303c: add     x0, x8, #0x138                             &626b138
02d63040: ldp     x8, x1, [x0]                               
02d63044: mov     x0, x19                                    
02d63048: blr     x8                                         
02d6304c: cbz     x20, #0x2d63074                            
02d63050: mov     x19, x0                                    
02d63054: mov     x0, x20                                    
02d63058: mov     x1, xzr                                    
02d6305c: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d63060: cbz     x19, #0x2d63074                            
02d63064: mov     x0, x19                                    
02d63068: mov     x1, xzr                                    
02d6306c: bl      #0x5b46888                                 UnityEngine.Transform::set_position
02d63070: b       #0x2d62e18                                 
02d63074: bl      #0x2b7105c                                 fn_2b7105c
## GetWorldPoint(UnityEngine.InputSystem.Pointer pointer) -> UnityEngine.Vector3
---- Clicker.DragManager::GetWorldPoint 0x2d626d8
02d626d8: stp     x30, x21, [sp, #-0x20]!                    
02d626dc: stp     x20, x19, [sp, #0x10]                      
02d626e0: adrp    x21, #0x6630000                            
02d626e4: mov     x20, x1                                    
02d626e8: mov     x19, x0                                    
02d626ec: ldrb    w8, [x21, #0x305]                          
02d626f0: tbnz    w8, #0, #0x2d62708                         
02d626f4: adrp    x0, #0x6266000                             
02d626f8: ldr     x0, [x0, #0x938]                           MS:UnityEngine.InputSystem.InputControl`1::ReadValue
02d626fc: bl      #0x2b70db0                                 fn_2b70db0
02d62700: mov     w8, #1                                     
02d62704: strb    w8, [x21, #0x305]                          
02d62708: cbz     x20, #0x2d62748                            
02d6270c: ldr     x0, [x20, #0x188]                          
02d62710: cbz     x0, #0x2d62748                             
02d62714: adrp    x8, #0x6266000                             
02d62718: ldr     x8, [x8, #0x938]                           MS:UnityEngine.InputSystem.InputControl`1::ReadValue
02d6271c: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d62720: bl      #0x4a187c4                                 fn_4a187c4
02d62724: ldr     x0, [x19, #0x40]                           ._cam
02d62728: cbz     x0, #0x2d62748                             
02d6272c: movi    d2, #0000000000000000                      
02d62730: mov     x1, xzr                                    
02d62734: bl      #0x5aefbb0                                 UnityEngine.Camera::ScreenToWorldPoint
02d62738: ldp     x20, x19, [sp, #0x10]                      
02d6273c: movi    d2, #0000000000000000                      
02d62740: ldp     x30, x21, [sp], #0x20                      
02d62744: ret                                                
02d62748: bl      #0x2b7105c                                 fn_2b7105c
## Pick(UnityEngine.Vector2 point) -> Clicker.IClickerDraggableItem
---- Clicker.DragManager::Pick 0x2d6274c
02d6274c: sub     sp, sp, #0x50                              
02d62750: stp     d9, d8, [sp, #0x10]                        
02d62754: stp     x30, x23, [sp, #0x20]                      
02d62758: stp     x22, x21, [sp, #0x30]                      
02d6275c: stp     x20, x19, [sp, #0x40]                      
02d62760: fmov    s8, s1                                     
02d62764: fmov    s9, s0                                     
02d62768: adrp    x23, #0x6630000                            
02d6276c: adrp    x22, #0x626b000                            
02d62770: adrp    x21, #0x626b000                            
02d62774: adrp    x20, #0x626b000                            
02d62778: ldr     x22, [x22, #0xfd0]                         MS:Clicker.DragManager::Check
02d6277c: ldrb    w8, [x23, #0x306]                          
02d62780: ldr     x21, [x21, #0xfd8]                         MS:Clicker.DragManager::Check
02d62784: ldr     x20, [x20, #0xfe0]                         MS:Clicker.DragManager::Check
02d62788: mov     x19, x0                                    
02d6278c: tbnz    w8, #0, #0x2d627bc                         
02d62790: adrp    x0, #0x626b000                             
02d62794: ldr     x0, [x0, #0xfe0]                           MS:Clicker.DragManager::Check
02d62798: bl      #0x2b70db0                                 fn_2b70db0
02d6279c: adrp    x0, #0x626b000                             
02d627a0: ldr     x0, [x0, #0xfd8]                           MS:Clicker.DragManager::Check
02d627a4: bl      #0x2b70db0                                 fn_2b70db0
02d627a8: adrp    x0, #0x626b000                             
02d627ac: ldr     x0, [x0, #0xfd0]                           MS:Clicker.DragManager::Check
02d627b0: bl      #0x2b70db0                                 fn_2b70db0
02d627b4: mov     w8, #1                                     
02d627b8: strb    w8, [x23, #0x306]                          
02d627bc: fmov    s0, s9                                     
02d627c0: fmov    s1, s8                                     
02d627c4: ldr     x1, [x19, #0x20]                           ._switchList
02d627c8: ldr     x3, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d627cc: add     x2, sp, #8                                 
02d627d0: mov     x0, x19                                    
02d627d4: str     xzr, [sp, #8]                              
02d627d8: bl      #0x31772f4                                 fn_31772f4
02d627dc: fmov    s0, s9                                     
02d627e0: fmov    s1, s8                                     
02d627e4: ldr     x1, [x19, #0x28]                           ._keychainList
02d627e8: ldr     x3, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d627ec: add     x2, sp, #8                                 
02d627f0: mov     x0, x19                                    
02d627f4: bl      #0x31772f4                                 fn_31772f4
02d627f8: fmov    s0, s9                                     
02d627fc: fmov    s1, s8                                     
02d62800: ldr     x1, [x19, #0x30]                           ._keycapList
02d62804: ldr     x3, [x20]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d62808: add     x2, sp, #8                                 
02d6280c: mov     x0, x19                                    
02d62810: bl      #0x31772f4                                 fn_31772f4
02d62814: ldp     x20, x19, [sp, #0x40]                      
02d62818: ldr     x0, [sp, #8]                               
02d6281c: ldp     x22, x21, [sp, #0x30]                      
02d62820: ldp     x30, x23, [sp, #0x20]                      
02d62824: ldp     d9, d8, [sp, #0x10]                        
02d62828: add     sp, sp, #0x50                              
02d6282c: ret                                                
##  Check (no body)
## .ctor() -> void
---- Clicker.DragManager::.ctor 0x2d63078
02d63078: adrp    x8, #0x1040000                             
02d6307c: mov     x1, xzr                                    
02d63080: str     wzr, [x0, #0x6c]                           
02d63084: ldr     d0, [x8, #0x728]                           [1040728]=3fc00000becccccd f=-0.4,1.5
02d63088: stur    d0, [x0, #0x64]                            ._handOffset
02d6308c: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
