#### CLASS DreamHouse.DataDreamHouse/DreamHouseOldRoomData parent= object
#   field RoomIndex                      int                                                off=0x10 attr=6 
#   field CurrentRoomSteps               UnityEngine.Rendering.SerializedDictionary`2<int,int> off=0x18 attr=6 
## .ctor() -> void
---- DreamHouse.DataDreamHouse/DreamHouseOldRoomData::.ctor 0x2d168d0
02d168d0: str     x30, [sp, #-0x30]!                         
02d168d4: stp     x22, x21, [sp, #0x10]                      
02d168d8: stp     x20, x19, [sp, #0x20]                      
02d168dc: adrp    x22, #0x662f000                            
02d168e0: adrp    x21, #0x6269000                            
02d168e4: adrp    x20, #0x6269000                            
02d168e8: ldrb    w8, [x22, #0xfe0]                          
02d168ec: ldr     x21, [x21, #0x928]                         T:type57541(k15)
02d168f0: ldr     x20, [x20, #0x920]                         MS:UnityEngine.Rendering.SerializedDictionary`2::.ctor
02d168f4: mov     x19, x0                                    
02d168f8: tbnz    w8, #0, #0x2d1691c                         
02d168fc: adrp    x0, #0x6269000                             
02d16900: ldr     x0, [x0, #0x920]                           MS:UnityEngine.Rendering.SerializedDictionary`2::.ctor
02d16904: bl      #0x2b70db0                                 fn_2b70db0
02d16908: adrp    x0, #0x6269000                             
02d1690c: ldr     x0, [x0, #0x928]                           T:type57541(k15)
02d16910: bl      #0x2b70db0                                 fn_2b70db0
02d16914: mov     w8, #1                                     
02d16918: strb    w8, [x22, #0xfe0]                          
02d1691c: ldr     x0, [x21]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d16920: mov     w8, #-1                                    
02d16924: str     w8, [x19, #0x10]                           .RoomIndex
02d16928: bl      #0x2b7104c                                 fn_2b7104c
02d1692c: ldr     x1, [x20]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d16930: mov     x20, x0                                    
02d16934: bl      #0x3bdaf20                                 fn_3bdaf20
02d16938: mov     x0, x19                                    
02d1693c: mov     x1, x20                                    
02d16940: str     x20, [x0, #0x18]!                          .CurrentRoomSteps
02d16944: bl      #0x2b70d54                                 fn_2b70d54
02d16948: mov     x0, x19                                    
02d1694c: ldp     x20, x19, [sp, #0x20]                      
02d16950: ldp     x22, x21, [sp, #0x10]                      
02d16954: mov     x1, xzr                                    
02d16958: ldr     x30, [sp], #0x30                           
02d1695c: b       #0x4e53e9c                                 System.Object::.ctor
#### CLASS DreamHouse.DataDreamHouse/DataSaveDreamHouse parent= object
#   field IsFirstTime                    bool                                               off=0x10 attr=6 
#   field IsDoneTutorial                 bool                                               off=0x11 attr=6 
#   field CurrentRoomIndex               int                                                off=0x14 attr=6 
#   field UnlockedRooms                  System.Collections.Generic.List`1<int>             off=0x18 attr=6 
#   field CurrentRoomSteps               UnityEngine.Rendering.SerializedDictionary`2<int,int> off=0x20 attr=6 
#   field RoomSaved                      System.Collections.Generic.List`1<DreamHouse.DataDreamHouse/DreamHouseOldRoomData> off=0x28 attr=6 
## .ctor() -> void
---- DreamHouse.DataDreamHouse/DataSaveDreamHouse::.ctor 0x2d1654c
02d1654c: str     x30, [sp, #-0x30]!                         
02d16550: stp     x22, x21, [sp, #0x10]                      
02d16554: stp     x20, x19, [sp, #0x20]                      
02d16558: adrp    x21, #0x662f000                            
02d1655c: adrp    x22, #0x6266000                            
02d16560: adrp    x20, #0x6266000                            
02d16564: ldrb    w8, [x21, #0xfe1]                          
02d16568: ldr     x22, [x22, #0x648]                         T:type15061(k15)
02d1656c: ldr     x20, [x20, #0x650]                         MS:System.Collections.Generic.List`1::.ctor
02d16570: mov     x19, x0                                    
02d16574: tbnz    w8, #0, #0x2d165bc                         
02d16578: adrp    x0, #0x6266000                             
02d1657c: ldr     x0, [x0, #0x818]                           MS:System.Collections.Generic.List`1::Add
02d16580: bl      #0x2b70db0                                 fn_2b70db0
02d16584: adrp    x0, #0x6266000                             
02d16588: ldr     x0, [x0, #0x650]                           MS:System.Collections.Generic.List`1::.ctor
02d1658c: bl      #0x2b70db0                                 fn_2b70db0
02d16590: adrp    x0, #0x6269000                             
02d16594: ldr     x0, [x0, #0x908]                           MS:System.Collections.Generic.List`1::.ctor
02d16598: bl      #0x2b70db0                                 fn_2b70db0
02d1659c: adrp    x0, #0x6266000                             
02d165a0: ldr     x0, [x0, #0x648]                           T:type15061(k15)
02d165a4: bl      #0x2b70db0                                 fn_2b70db0
02d165a8: adrp    x0, #0x6269000                             
02d165ac: ldr     x0, [x0, #0x910]                           T:type56880(k15)
02d165b0: bl      #0x2b70db0                                 fn_2b70db0
02d165b4: mov     w8, #1                                     
02d165b8: strb    w8, [x21, #0xfe1]                          
02d165bc: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d165c0: bl      #0x2b7104c                                 fn_2b7104c
02d165c4: ldr     x1, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d165c8: mov     x20, x0                                    
02d165cc: bl      #0x3569388                                 fn_3569388
02d165d0: cbz     x20, #0x2d1668c                            
02d165d4: adrp    x9, #0x6266000                             
02d165d8: ldr     x9, [x9, #0x818]                           MS:System.Collections.Generic.List`1::Add
02d165dc: ldr     w10, [x20, #0x1c]                          [626601c]=0 f=0,0
02d165e0: ldr     x8, [x20, #0x10]                           S:'mrec_ad_on_off' .IsFirstTime
02d165e4: ldr     x9, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d165e8: add     w10, w10, #1                               
02d165ec: str     w10, [x20, #0x1c]                          
02d165f0: cbz     x8, #0x2d1668c                             
02d165f4: ldrsw   x10, [x20, #0x18]                          .UnlockedRooms
02d165f8: ldr     w11, [x8, #0x18]                           
02d165fc: adrp    x22, #0x6269000                            
02d16600: adrp    x21, #0x6269000                            
02d16604: ldr     x22, [x22, #0x910]                         T:type56880(k15)
02d16608: ldr     x21, [x21, #0x908]                         MS:System.Collections.Generic.List`1::.ctor
02d1660c: cmp     w10, w11                                   
02d16610: b.hs    #0x2d16628                                 
02d16614: add     x8, x8, x10, lsl #2                        
02d16618: add     w9, w10, #1                                
02d1661c: str     w9, [x20, #0x18]                           .UnlockedRooms
02d16620: str     wzr, [x8, #0x20]                           
02d16624: b       #0x2d16640                                 
02d16628: ldr     x8, [x9, #0x20]                            S:'inter_ad_capping_time'
02d1662c: mov     x0, x20                                    
02d16630: mov     w1, wzr                                    
02d16634: ldr     x8, [x8, #0xc0]                            
02d16638: ldr     x2, [x8, #0x70]                            
02d1663c: bl      #0x3569c18                                 fn_3569c18
02d16640: mov     x0, x19                                    
02d16644: mov     x1, x20                                    
02d16648: str     x20, [x0, #0x18]!                          .UnlockedRooms
02d1664c: bl      #0x2b70d54                                 fn_2b70d54
02d16650: ldr     x0, [x22]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d16654: bl      #0x2b7104c                                 fn_2b7104c
02d16658: ldr     x1, [x21]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1665c: mov     x20, x0                                    
02d16660: bl      #0x35a89a4                                 fn_35a89a4
02d16664: mov     x0, x19                                    
02d16668: mov     x1, x20                                    
02d1666c: str     x20, [x0, #0x28]!                          .RoomSaved
02d16670: bl      #0x2b70d54                                 fn_2b70d54
02d16674: mov     x0, x19                                    
02d16678: ldp     x20, x19, [sp, #0x20]                      
02d1667c: ldp     x22, x21, [sp, #0x10]                      
02d16680: mov     x1, xzr                                    
02d16684: ldr     x30, [sp], #0x30                           
02d16688: b       #0x4e53e9c                                 System.Object::.ctor
02d1668c: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS DreamHouse.DataDreamHouse/<>c__DisplayClass11_0 parent= object
#   field roomIndex                      int                                                off=0x10 attr=6 
## .ctor() -> void
---- DreamHouse.DataDreamHouse/<>c__DisplayClass11_0::.ctor 0x2d168c8
02d168c8: mov     x1, xzr                                    
02d168cc: b       #0x4e53e9c                                 System.Object::.ctor
## <SetCurrentRoomIndex>b__0(DreamHouse.DataDreamHouse/DreamHouseOldRoomData x) -> bool
---- DreamHouse.DataDreamHouse/<>c__DisplayClass11_0::<SetCurrentRoomIndex>b__0 0x2d17444
02d17444: cbz     x1, #0x2d1745c                             
02d17448: ldr     w8, [x1, #0x10]                            
02d1744c: ldr     w9, [x0, #0x10]                            .roomIndex
02d17450: cmp     w8, w9                                     
02d17454: cset    w0, eq                                     
02d17458: ret                                                
02d1745c: str     x30, [sp, #-0x10]!                         
02d17460: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS DreamHouse.DataDreamHouse/<>c__DisplayClass13_0 parent= object
#   field roomIndex                      int                                                off=0x10 attr=6 
## .ctor() -> void
---- DreamHouse.DataDreamHouse/<>c__DisplayClass13_0::.ctor 0x2d16c24
02d16c24: mov     x1, xzr                                    
02d16c28: b       #0x4e53e9c                                 System.Object::.ctor
## <UnlockRoom>b__0(DreamHouse.DataDreamHouse/DreamHouseOldRoomData x) -> bool
---- DreamHouse.DataDreamHouse/<>c__DisplayClass13_0::<UnlockRoom>b__0 0x2d17464
02d17464: cbz     x1, #0x2d1747c                             
02d17468: ldr     w8, [x1, #0x10]                            
02d1746c: ldr     w9, [x0, #0x10]                            .roomIndex
02d17470: cmp     w8, w9                                     
02d17474: cset    w0, eq                                     
02d17478: ret                                                
02d1747c: str     x30, [sp, #-0x10]!                         
02d17480: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS DreamHouse.DataDreamHouse parent= GameData
#   field _dataSave                      DreamHouse.DataDreamHouse/DataSaveDreamHouse       off=0x20 attr=1 SerializeField
## get_DataSave() -> DreamHouse.DataDreamHouse/DataSaveDreamHouse
---- DreamHouse.DataDreamHouse::get_DataSave 0x2d15f4c
02d15f4c: ldr     x0, [x0, #0x20]                            ._dataSave
02d15f50: ret                                                
## set_DataSave(DreamHouse.DataDreamHouse/DataSaveDreamHouse value) -> void
---- DreamHouse.DataDreamHouse::set_DataSave 0x2d15f54
02d15f54: str     x1, [x0, #0x20]!                           ._dataSave
02d15f58: b       #0x2b70d54                                 
## SaveData() -> void
---- DreamHouse.DataDreamHouse::SaveData 0x2d15f5c
02d15f5c: stp     x30, x21, [sp, #-0x20]!                    
02d15f60: stp     x20, x19, [sp, #0x10]                      
02d15f64: adrp    x20, #0x662f000                            
02d15f68: adrp    x21, #0x6266000                            
02d15f6c: mov     x19, x0                                    
02d15f70: ldrb    w8, [x20, #0xfd6]                          
02d15f74: ldr     x21, [x21, #0x658]                         MS:MonoSingleton`1::get_Instance
02d15f78: tbnz    w8, #0, #0x2d15f9c                         
02d15f7c: adrp    x0, #0x6269000                             
02d15f80: ldr     x0, [x0, #0x8f8]                           MS:DataManager::SaveData
02d15f84: bl      #0x2b70db0                                 fn_2b70db0
02d15f88: adrp    x0, #0x6266000                             
02d15f8c: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d15f90: bl      #0x2b70db0                                 fn_2b70db0
02d15f94: mov     w8, #1                                     
02d15f98: strb    w8, [x20, #0xfd6]                          
02d15f9c: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d15fa0: bl      #0x3769600                                 fn_3769600
02d15fa4: ldr     x8, [x19]                                  
02d15fa8: mov     x20, x0                                    
02d15fac: mov     x0, x19                                    
02d15fb0: ldr     x9, [x8, #0x2a8]                           
02d15fb4: ldr     x1, [x8, #0x2b0]                           
02d15fb8: blr     x9                                         
02d15fbc: cbz     x20, #0x2d15fe4                            
02d15fc0: adrp    x8, #0x6269000                             
02d15fc4: mov     x1, x0                                     
02d15fc8: mov     x0, x20                                    
02d15fcc: ldr     x8, [x8, #0x8f8]                           MS:DataManager::SaveData
02d15fd0: ldr     x2, [x19, #0x20]                           ._dataSave
02d15fd4: ldp     x20, x19, [sp, #0x10]                      
02d15fd8: ldr     x3, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d15fdc: ldp     x30, x21, [sp], #0x20                      
02d15fe0: b       #0x3169790                                 
02d15fe4: bl      #0x2b7105c                                 fn_2b7105c
## LoadData() -> void
---- DreamHouse.DataDreamHouse::LoadData 0x2d15fe8
02d15fe8: stp     x30, x21, [sp, #-0x20]!                    
02d15fec: stp     x20, x19, [sp, #0x10]                      
02d15ff0: adrp    x20, #0x662f000                            
02d15ff4: adrp    x21, #0x6266000                            
02d15ff8: mov     x19, x0                                    
02d15ffc: ldrb    w8, [x20, #0xfd7]                          
02d16000: ldr     x21, [x21, #0x658]                         MS:MonoSingleton`1::get_Instance
02d16004: tbnz    w8, #0, #0x2d16058                         
02d16008: adrp    x0, #0x6269000                             
02d1600c: ldr     x0, [x0, #0x900]                           MS:DataManager::LoadData
02d16010: bl      #0x2b70db0                                 fn_2b70db0
02d16014: adrp    x0, #0x6266000                             
02d16018: ldr     x0, [x0, #0x818]                           MS:System.Collections.Generic.List`1::Add
02d1601c: bl      #0x2b70db0                                 fn_2b70db0
02d16020: adrp    x0, #0x6266000                             
02d16024: ldr     x0, [x0, #0x820]                           MS:System.Collections.Generic.List`1::Contains
02d16028: bl      #0x2b70db0                                 fn_2b70db0
02d1602c: adrp    x0, #0x6269000                             
02d16030: ldr     x0, [x0, #0x908]                           MS:System.Collections.Generic.List`1::.ctor
02d16034: bl      #0x2b70db0                                 fn_2b70db0
02d16038: adrp    x0, #0x6269000                             
02d1603c: ldr     x0, [x0, #0x910]                           T:type56880(k15)
02d16040: bl      #0x2b70db0                                 fn_2b70db0
02d16044: adrp    x0, #0x6266000                             
02d16048: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d1604c: bl      #0x2b70db0                                 fn_2b70db0
02d16050: mov     w8, #1                                     
02d16054: strb    w8, [x20, #0xfd7]                          
02d16058: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1605c: bl      #0x3769600                                 fn_3769600
02d16060: ldr     x8, [x19]                                  
02d16064: mov     x20, x0                                    
02d16068: mov     x0, x19                                    
02d1606c: ldr     x9, [x8, #0x2a8]                           
02d16070: ldr     x1, [x8, #0x2b0]                           
02d16074: blr     x9                                         
02d16078: cbz     x20, #0x2d162f8                            
02d1607c: adrp    x8, #0x6269000                             
02d16080: mov     x1, x0                                     
02d16084: mov     x0, x20                                    
02d16088: ldr     x8, [x8, #0x900]                           MS:DataManager::LoadData
02d1608c: ldr     x2, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d16090: bl      #0x31690b0                                 fn_31690b0
02d16094: mov     x20, x19                                   
02d16098: mov     x1, x0                                     
02d1609c: str     x0, [x20, #0x20]!                          ._dataSave
02d160a0: mov     x0, x20                                    
02d160a4: bl      #0x2b70d54                                 fn_2b70d54
02d160a8: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02d160ac: cbz     x8, #0x2d162f8                             
02d160b0: ldr     x0, [x8, #0x18]                            M:Trading.TradingSession::<ValidateTrade>b__57_0
02d160b4: cbz     x0, #0x2d162f8                             
02d160b8: adrp    x21, #0x6266000                            
02d160bc: mov     w1, wzr                                    
02d160c0: ldr     x21, [x21, #0x820]                         MS:System.Collections.Generic.List`1::Contains
02d160c4: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d160c8: bl      #0x3569f98                                 fn_3569f98
02d160cc: tbnz    w0, #0, #0x2d1614c                         
02d160d0: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02d160d4: cbz     x8, #0x2d162f8                             
02d160d8: ldr     x0, [x8, #0x18]                            M:Trading.TradingSession::<ValidateTrade>b__57_0
02d160dc: cbz     x0, #0x2d162f8                             
02d160e0: adrp    x9, #0x6266000                             
02d160e4: ldr     x9, [x9, #0x818]                           MS:System.Collections.Generic.List`1::Add
02d160e8: ldr     w10, [x0, #0x1c]                           [626601c]=0 f=0,0
02d160ec: ldr     x8, [x0, #0x10]                            S:'mrec_ad_on_off'
02d160f0: ldr     x9, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d160f4: add     w10, w10, #1                               
02d160f8: str     w10, [x0, #0x1c]                           
02d160fc: cbz     x8, #0x2d162f8                             
02d16100: ldrsw   x10, [x0, #0x18]                           
02d16104: ldr     w11, [x8, #0x18]                           M:Trading.TradingSession::<ValidateTrade>b__57_0
02d16108: cmp     w10, w11                                   
02d1610c: b.hs    #0x2d16124                                 
02d16110: add     x8, x8, x10, lsl #2                        &6269000
02d16114: add     w9, w10, #1                                
02d16118: str     w9, [x0, #0x18]                            
02d1611c: str     wzr, [x8, #0x20]                           
02d16120: b       #0x2d16138                                 
02d16124: ldr     x8, [x9, #0x20]                            S:'inter_ad_capping_time'
02d16128: mov     w1, wzr                                    
02d1612c: ldr     x8, [x8, #0xc0]                            MS:System.Linq.Enumerable::Select
02d16130: ldr     x2, [x8, #0x70]                            T:Trading.TradingSession/<>c__DisplayClass63_0
02d16134: bl      #0x3569c18                                 fn_3569c18
02d16138: ldr     x8, [x19]                                  
02d1613c: mov     x0, x19                                    
02d16140: ldr     x9, [x8, #0x258]                           M:Trading.PopupTradingEmptyCollection::OnBtnGoDiyClick
02d16144: ldr     x1, [x8, #0x260]                           M:Trading.PopupTradingEmptyCollection::OnBtnLaterClick
02d16148: blr     x9                                         
02d1614c: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02d16150: cbz     x8, #0x2d162f8                             
02d16154: ldr     x0, [x8, #0x18]                            M:Trading.TradingSession::<ValidateTrade>b__57_0
02d16158: cbz     x0, #0x2d162f8                             
02d1615c: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d16160: mov     w1, #1                                     
02d16164: bl      #0x3569f98                                 fn_3569f98
02d16168: tbnz    w0, #0, #0x2d161ec                         
02d1616c: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02d16170: cbz     x8, #0x2d162f8                             
02d16174: ldr     x0, [x8, #0x18]                            M:Trading.TradingSession::<ValidateTrade>b__57_0
02d16178: cbz     x0, #0x2d162f8                             
02d1617c: adrp    x9, #0x6266000                             
02d16180: ldr     x9, [x9, #0x818]                           MS:System.Collections.Generic.List`1::Add
02d16184: ldr     w10, [x0, #0x1c]                           [626601c]=0 f=0,0
02d16188: ldr     x8, [x0, #0x10]                            S:'mrec_ad_on_off'
02d1618c: ldr     x9, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d16190: add     w10, w10, #1                               
02d16194: str     w10, [x0, #0x1c]                           
02d16198: cbz     x8, #0x2d162f8                             
02d1619c: ldrsw   x10, [x0, #0x18]                           
02d161a0: ldr     w11, [x8, #0x18]                           M:Trading.TradingSession::<ValidateTrade>b__57_0
02d161a4: cmp     w10, w11                                   
02d161a8: b.hs    #0x2d161c4                                 
02d161ac: add     w9, w10, #1                                
02d161b0: add     x8, x8, x10, lsl #2                        &6269000
02d161b4: str     w9, [x0, #0x18]                            
02d161b8: mov     w9, #1                                     
02d161bc: str     w9, [x8, #0x20]                            
02d161c0: b       #0x2d161d8                                 
02d161c4: ldr     x8, [x9, #0x20]                            S:'inter_ad_capping_time'
02d161c8: mov     w1, #1                                     
02d161cc: ldr     x8, [x8, #0xc0]                            MS:System.Linq.Enumerable::Select
02d161d0: ldr     x2, [x8, #0x70]                            T:Trading.TradingSession/<>c__DisplayClass63_0
02d161d4: bl      #0x3569c18                                 fn_3569c18
02d161d8: ldr     x8, [x19]                                  
02d161dc: mov     x0, x19                                    
02d161e0: ldr     x9, [x8, #0x258]                           M:Trading.PopupTradingEmptyCollection::OnBtnGoDiyClick
02d161e4: ldr     x1, [x8, #0x260]                           M:Trading.PopupTradingEmptyCollection::OnBtnLaterClick
02d161e8: blr     x9                                         
02d161ec: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02d161f0: cbz     x8, #0x2d162f8                             
02d161f4: ldr     x0, [x8, #0x18]                            M:Trading.TradingSession::<ValidateTrade>b__57_0
02d161f8: cbz     x0, #0x2d162f8                             
02d161fc: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d16200: mov     w1, #2                                     
02d16204: bl      #0x3569f98                                 fn_3569f98
02d16208: tbnz    w0, #0, #0x2d1628c                         
02d1620c: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02d16210: cbz     x8, #0x2d162f8                             
02d16214: ldr     x0, [x8, #0x18]                            M:Trading.TradingSession::<ValidateTrade>b__57_0
02d16218: cbz     x0, #0x2d162f8                             
02d1621c: adrp    x9, #0x6266000                             
02d16220: ldr     x9, [x9, #0x818]                           MS:System.Collections.Generic.List`1::Add
02d16224: ldr     w10, [x0, #0x1c]                           [626601c]=0 f=0,0
02d16228: ldr     x8, [x0, #0x10]                            S:'mrec_ad_on_off'
02d1622c: ldr     x9, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d16230: add     w10, w10, #1                               
02d16234: str     w10, [x0, #0x1c]                           
02d16238: cbz     x8, #0x2d162f8                             
02d1623c: ldrsw   x10, [x0, #0x18]                           
02d16240: ldr     w11, [x8, #0x18]                           M:Trading.TradingSession::<ValidateTrade>b__57_0
02d16244: cmp     w10, w11                                   
02d16248: b.hs    #0x2d16264                                 
02d1624c: add     w9, w10, #1                                
02d16250: add     x8, x8, x10, lsl #2                        &6269000
02d16254: str     w9, [x0, #0x18]                            
02d16258: mov     w9, #2                                     
02d1625c: str     w9, [x8, #0x20]                            
02d16260: b       #0x2d16278                                 
02d16264: ldr     x8, [x9, #0x20]                            S:'inter_ad_capping_time'
02d16268: mov     w1, #2                                     
02d1626c: ldr     x8, [x8, #0xc0]                            MS:System.Linq.Enumerable::Select
02d16270: ldr     x2, [x8, #0x70]                            T:Trading.TradingSession/<>c__DisplayClass63_0
02d16274: bl      #0x3569c18                                 fn_3569c18
02d16278: ldr     x8, [x19]                                  
02d1627c: mov     x0, x19                                    
02d16280: ldr     x9, [x8, #0x258]                           M:Trading.PopupTradingEmptyCollection::OnBtnGoDiyClick
02d16284: ldr     x1, [x8, #0x260]                           M:Trading.PopupTradingEmptyCollection::OnBtnLaterClick
02d16288: blr     x9                                         
02d1628c: ldr     x20, [x20]                                 &2b706c4(=eb01011ff9400808)
02d16290: cbz     x20, #0x2d162f8                            
02d16294: ldr     x8, [x20, #0x28]!                          [662f028]=6000015 f=2.40742e-35,0
02d16298: cbz     x8, #0x2d162a8                             
02d1629c: ldp     x20, x19, [sp, #0x10]                      
02d162a0: ldp     x30, x21, [sp], #0x20                      
02d162a4: ret                                                
02d162a8: adrp    x8, #0x6269000                             
02d162ac: ldr     x8, [x8, #0x910]                           T:type56880(k15)
02d162b0: ldr     x0, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d162b4: bl      #0x2b7104c                                 fn_2b7104c
02d162b8: adrp    x8, #0x6269000                             
02d162bc: mov     x21, x0                                    
02d162c0: ldr     x8, [x8, #0x908]                           MS:System.Collections.Generic.List`1::.ctor
02d162c4: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d162c8: bl      #0x35a89a4                                 fn_35a89a4
02d162cc: mov     x0, x20                                    
02d162d0: mov     x1, x21                                    
02d162d4: str     x21, [x20]                                 
02d162d8: bl      #0x2b70d54                                 fn_2b70d54
02d162dc: ldr     x8, [x19]                                  
02d162e0: mov     x0, x19                                    
02d162e4: ldp     x20, x19, [sp, #0x10]                      
02d162e8: ldr     x1, [x8, #0x260]                           M:Trading.PopupTradingEmptyCollection::OnBtnLaterClick
02d162ec: ldr     x2, [x8, #0x258]                           M:Trading.PopupTradingEmptyCollection::OnBtnGoDiyClick
02d162f0: ldp     x30, x21, [sp], #0x20                      
02d162f4: br      x2                                         
02d162f8: bl      #0x2b7105c                                 fn_2b7105c
## NewData() -> void
---- DreamHouse.DataDreamHouse::NewData 0x2d162fc
02d162fc: stp     x30, x23, [sp, #-0x30]!                    
02d16300: stp     x22, x21, [sp, #0x10]                      
02d16304: stp     x20, x19, [sp, #0x20]                      
02d16308: adrp    x21, #0x662f000                            
02d1630c: adrp    x20, #0x6269000                            
02d16310: mov     x19, x0                                    
02d16314: ldrb    w8, [x21, #0xfd8]                          
02d16318: ldr     x20, [x20, #0x918]                         T:DreamHouse.DataDreamHouse/DataSaveDreamHouse
02d1631c: tbnz    w8, #0, #0x2d16370                         
02d16320: adrp    x0, #0x6269000                             
02d16324: ldr     x0, [x0, #0x918]                           T:DreamHouse.DataDreamHouse/DataSaveDreamHouse
02d16328: bl      #0x2b70db0                                 fn_2b70db0
02d1632c: adrp    x0, #0x6266000                             
02d16330: ldr     x0, [x0, #0x818]                           MS:System.Collections.Generic.List`1::Add
02d16334: bl      #0x2b70db0                                 fn_2b70db0
02d16338: adrp    x0, #0x6266000                             
02d1633c: ldr     x0, [x0, #0x650]                           MS:System.Collections.Generic.List`1::.ctor
02d16340: bl      #0x2b70db0                                 fn_2b70db0
02d16344: adrp    x0, #0x6266000                             
02d16348: ldr     x0, [x0, #0x648]                           T:type15061(k15)
02d1634c: bl      #0x2b70db0                                 fn_2b70db0
02d16350: adrp    x0, #0x6269000                             
02d16354: ldr     x0, [x0, #0x920]                           MS:UnityEngine.Rendering.SerializedDictionary`2::.ctor
02d16358: bl      #0x2b70db0                                 fn_2b70db0
02d1635c: adrp    x0, #0x6269000                             
02d16360: ldr     x0, [x0, #0x928]                           T:type57541(k15)
02d16364: bl      #0x2b70db0                                 fn_2b70db0
02d16368: mov     w8, #1                                     
02d1636c: strb    w8, [x21, #0xfd8]                          
02d16370: mov     x0, x19                                    
02d16374: mov     x1, xzr                                    
02d16378: bl      #0x2cac6e0                                 GameData::NewData
02d1637c: ldr     x0, [x20]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d16380: bl      #0x2b7104c                                 fn_2b7104c
02d16384: mov     x20, x0                                    
02d16388: bl      #0x2d1654c                                 DreamHouse.DataDreamHouse/DataSaveDreamHouse::.ctor
02d1638c: cbz     x20, #0x2d16548                            
02d16390: adrp    x8, #0x6266000                             
02d16394: adrp    x21, #0x6266000                            
02d16398: mov     w9, #1                                     
02d1639c: ldr     x8, [x8, #0x648]                           T:type15061(k15)
02d163a0: ldr     x21, [x21, #0x650]                         MS:System.Collections.Generic.List`1::.ctor
02d163a4: strh    w9, [x20, #0x10]                           
02d163a8: str     wzr, [x20, #0x14]                          
02d163ac: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d163b0: bl      #0x2b7104c                                 fn_2b7104c
02d163b4: ldr     x1, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d163b8: mov     x21, x0                                    
02d163bc: bl      #0x3569388                                 fn_3569388
02d163c0: cbz     x21, #0x2d16548                            
02d163c4: adrp    x22, #0x6266000                            
02d163c8: ldr     x22, [x22, #0x818]                         MS:System.Collections.Generic.List`1::Add
02d163cc: ldr     w10, [x21, #0x1c]                          [626601c]=0 f=0,0
02d163d0: ldr     x8, [x21, #0x10]                           S:'mrec_ad_on_off'
02d163d4: ldr     x9, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d163d8: add     w10, w10, #1                               
02d163dc: str     w10, [x21, #0x1c]                          
02d163e0: cbz     x8, #0x2d16548                             
02d163e4: ldrsw   x10, [x21, #0x18]                          
02d163e8: ldr     w11, [x8, #0x18]                           S:'level_show_popuprate'
02d163ec: cmp     w10, w11                                   
02d163f0: b.hs    #0x2d16414                                 
02d163f4: add     w11, w10, #1                               
02d163f8: add     x10, x8, x10, lsl #2                       &6266000
02d163fc: str     w11, [x21, #0x18]                          
02d16400: str     wzr, [x10, #0x20]                          
02d16404: ldr     w10, [x21, #0x1c]                          [626601c]=0 f=0,0
02d16408: add     w10, w10, #1                               
02d1640c: str     w10, [x21, #0x1c]                          
02d16410: b       #0x2d16444                                 
02d16414: ldr     x8, [x9, #0x20]                            
02d16418: mov     x0, x21                                    
02d1641c: mov     w1, wzr                                    
02d16420: ldr     x8, [x8, #0xc0]                            T:Firebase.RemoteConfig.ConfigValue
02d16424: ldr     x2, [x8, #0x70]                            S:'open_ad_id'
02d16428: bl      #0x3569c18                                 fn_3569c18
02d1642c: ldr     w10, [x21, #0x1c]                          [626601c]=0 f=0,0
02d16430: ldr     x8, [x21, #0x10]                           S:'mrec_ad_on_off'
02d16434: ldr     x9, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d16438: add     w10, w10, #1                               
02d1643c: str     w10, [x21, #0x1c]                          
02d16440: cbz     x8, #0x2d16548                             
02d16444: ldrsw   x10, [x21, #0x18]                          
02d16448: ldr     w11, [x8, #0x18]                           S:'level_show_popuprate'
02d1644c: cmp     w10, w11                                   
02d16450: b.hs    #0x2d16478                                 
02d16454: add     w11, w10, #1                               
02d16458: add     x10, x8, x10, lsl #2                       &6266000
02d1645c: str     w11, [x21, #0x18]                          
02d16460: mov     w11, #1                                    
02d16464: str     w11, [x10, #0x20]                          
02d16468: ldr     w10, [x21, #0x1c]                          [626601c]=0 f=0,0
02d1646c: add     w10, w10, #1                               
02d16470: str     w10, [x21, #0x1c]                          
02d16474: b       #0x2d164a8                                 
02d16478: ldr     x8, [x9, #0x20]                            
02d1647c: mov     x0, x21                                    
02d16480: mov     w1, #1                                     
02d16484: ldr     x8, [x8, #0xc0]                            T:Firebase.RemoteConfig.ConfigValue
02d16488: ldr     x2, [x8, #0x70]                            S:'open_ad_id'
02d1648c: bl      #0x3569c18                                 fn_3569c18
02d16490: ldr     w10, [x21, #0x1c]                          [626601c]=0 f=0,0
02d16494: ldr     x8, [x21, #0x10]                           S:'mrec_ad_on_off'
02d16498: ldr     x9, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d1649c: add     w10, w10, #1                               
02d164a0: str     w10, [x21, #0x1c]                          
02d164a4: cbz     x8, #0x2d16548                             
02d164a8: ldrsw   x10, [x21, #0x18]                          
02d164ac: ldr     w11, [x8, #0x18]                           S:'level_show_popuprate'
02d164b0: adrp    x23, #0x6269000                            
02d164b4: adrp    x22, #0x6269000                            
02d164b8: ldr     x23, [x23, #0x928]                         T:type57541(k15)
02d164bc: ldr     x22, [x22, #0x920]                         MS:UnityEngine.Rendering.SerializedDictionary`2::.ctor
02d164c0: cmp     w10, w11                                   
02d164c4: b.hs    #0x2d164e0                                 
02d164c8: add     w9, w10, #1                                
02d164cc: add     x8, x8, x10, lsl #2                        &6266000
02d164d0: str     w9, [x21, #0x18]                           
02d164d4: mov     w9, #2                                     
02d164d8: str     w9, [x8, #0x20]                            
02d164dc: b       #0x2d164f8                                 
02d164e0: ldr     x8, [x9, #0x20]                            
02d164e4: mov     x0, x21                                    
02d164e8: mov     w1, #2                                     
02d164ec: ldr     x8, [x8, #0xc0]                            T:Firebase.RemoteConfig.ConfigValue
02d164f0: ldr     x2, [x8, #0x70]                            S:'open_ad_id'
02d164f4: bl      #0x3569c18                                 fn_3569c18
02d164f8: mov     x0, x20                                    
02d164fc: mov     x1, x21                                    
02d16500: str     x21, [x0, #0x18]!                          
02d16504: bl      #0x2b70d54                                 fn_2b70d54
02d16508: ldr     x0, [x23]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1650c: bl      #0x2b7104c                                 fn_2b7104c
02d16510: ldr     x1, [x22]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d16514: mov     x21, x0                                    
02d16518: bl      #0x3bdaf20                                 fn_3bdaf20
02d1651c: mov     x0, x20                                    
02d16520: mov     x1, x21                                    
02d16524: str     x21, [x0, #0x20]!                          ._dataSave
02d16528: bl      #0x2b70d54                                 fn_2b70d54
02d1652c: str     x20, [x19, #0x20]!                         ._dataSave
02d16530: mov     x0, x19                                    
02d16534: mov     x1, x20                                    
02d16538: ldp     x20, x19, [sp, #0x20]                      
02d1653c: ldp     x22, x21, [sp, #0x10]                      
02d16540: ldp     x30, x23, [sp], #0x30                      
02d16544: b       #0x2b70d54                                 
02d16548: bl      #0x2b7105c                                 fn_2b7105c
## SetFirstTime(bool isFirstTime) -> void
---- DreamHouse.DataDreamHouse::SetFirstTime 0x2d16690
02d16690: ldr     x8, [x0, #0x20]                            ._dataSave
02d16694: cbz     x8, #0x2d166b0                             
02d16698: and     w9, w1, #1                                 
02d1669c: strb    w9, [x8, #0x10]                            
02d166a0: ldr     x8, [x0]                                   
02d166a4: ldr     x1, [x8, #0x260]                           
02d166a8: ldr     x2, [x8, #0x258]                           
02d166ac: br      x2                                         
02d166b0: str     x30, [sp, #-0x10]!                         
02d166b4: bl      #0x2b7105c                                 fn_2b7105c
## IsFirstTime() -> bool
---- DreamHouse.DataDreamHouse::IsFirstTime 0x2d166b8
02d166b8: ldr     x8, [x0, #0x20]                            ._dataSave
02d166bc: cbz     x8, #0x2d166c8                             
02d166c0: ldrb    w0, [x8, #0x10]                            
02d166c4: ret                                                
02d166c8: str     x30, [sp, #-0x10]!                         
02d166cc: bl      #0x2b7105c                                 fn_2b7105c
## SetCurrentRoomIndex(int roomIndex) -> void
---- DreamHouse.DataDreamHouse::SetCurrentRoomIndex 0x2d166d0
02d166d0: stp     x30, x23, [sp, #-0x30]!                    
02d166d4: stp     x22, x21, [sp, #0x10]                      
02d166d8: stp     x20, x19, [sp, #0x20]                      
02d166dc: adrp    x20, #0x662f000                            
02d166e0: adrp    x22, #0x6269000                            
02d166e4: mov     w21, w1                                    
02d166e8: ldrb    w8, [x20, #0xfd9]                          
02d166ec: ldr     x22, [x22, #0x930]                         T:DreamHouse.DataDreamHouse/<>c__DisplayClass11_0
02d166f0: mov     x19, x0                                    
02d166f4: tbnz    w8, #0, #0x2d16760                         
02d166f8: adrp    x0, #0x6269000                             
02d166fc: ldr     x0, [x0, #0x938]                           T:DreamHouse.DataDreamHouse/DreamHouseOldRoomData
02d16700: bl      #0x2b70db0                                 fn_2b70db0
02d16704: adrp    x0, #0x6269000                             
02d16708: ldr     x0, [x0, #0x940]                           MS:System.Collections.Generic.List`1::Add
02d1670c: bl      #0x2b70db0                                 fn_2b70db0
02d16710: adrp    x0, #0x6269000                             
02d16714: ldr     x0, [x0, #0x948]                           MS:System.Collections.Generic.List`1::Find
02d16718: bl      #0x2b70db0                                 fn_2b70db0
02d1671c: adrp    x0, #0x6269000                             
02d16720: ldr     x0, [x0, #0x950]                           T:type57307(k15)
02d16724: bl      #0x2b70db0                                 fn_2b70db0
02d16728: adrp    x0, #0x6269000                             
02d1672c: ldr     x0, [x0, #0x920]                           MS:UnityEngine.Rendering.SerializedDictionary`2::.ctor
02d16730: bl      #0x2b70db0                                 fn_2b70db0
02d16734: adrp    x0, #0x6269000                             
02d16738: ldr     x0, [x0, #0x928]                           T:type57541(k15)
02d1673c: bl      #0x2b70db0                                 fn_2b70db0
02d16740: adrp    x0, #0x6269000                             
02d16744: ldr     x0, [x0, #0x958]                           M:DreamHouse.DataDreamHouse/<>c__DisplayClass11_0::<SetCurrentRoomIndex>b__0
02d16748: bl      #0x2b70db0                                 fn_2b70db0
02d1674c: adrp    x0, #0x6269000                             
02d16750: ldr     x0, [x0, #0x930]                           T:DreamHouse.DataDreamHouse/<>c__DisplayClass11_0
02d16754: bl      #0x2b70db0                                 fn_2b70db0
02d16758: mov     w8, #1                                     
02d1675c: strb    w8, [x20, #0xfd9]                          
02d16760: ldr     x0, [x22]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d16764: bl      #0x2b7104c                                 fn_2b7104c
02d16768: mov     x1, xzr                                    
02d1676c: mov     x20, x0                                    
02d16770: bl      #0x4e53e9c                                 System.Object::.ctor
02d16774: cbz     x20, #0x2d168c4                            
02d16778: ldr     x8, [x19, #0x20]                           ._dataSave
02d1677c: str     w21, [x20, #0x10]                          
02d16780: cbz     x8, #0x2d168c4                             
02d16784: adrp    x9, #0x6269000                             
02d16788: adrp    x23, #0x6269000                            
02d1678c: ldr     x9, [x9, #0x950]                           T:type57307(k15)
02d16790: ldr     x23, [x23, #0x958]                         M:DreamHouse.DataDreamHouse/<>c__DisplayClass11_0::<SetCurrentRoomIndex>b__0
02d16794: ldr     x22, [x8, #0x28]                           
02d16798: str     w21, [x8, #0x14]                           
02d1679c: ldr     x0, [x9]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d167a0: bl      #0x2b7104c                                 fn_2b7104c
02d167a4: ldr     x2, [x23]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d167a8: mov     x1, x20                                    
02d167ac: mov     x3, xzr                                    
02d167b0: mov     x21, x0                                    
02d167b4: bl      #0x399ba10                                 fn_399ba10
02d167b8: cbz     x22, #0x2d168c4                            
02d167bc: adrp    x8, #0x6269000                             
02d167c0: mov     x0, x22                                    
02d167c4: mov     x1, x21                                    
02d167c8: ldr     x8, [x8, #0x948]                           MS:System.Collections.Generic.List`1::Find
02d167cc: ldr     x2, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d167d0: bl      #0x35a9868                                 fn_35a9868
02d167d4: cbnz    x0, #0x2d168a4                             
02d167d8: ldr     x8, [x19, #0x20]                           ._dataSave
02d167dc: cbz     x8, #0x2d168c4                             
02d167e0: adrp    x9, #0x6269000                             
02d167e4: ldr     x9, [x9, #0x938]                           T:DreamHouse.DataDreamHouse/DreamHouseOldRoomData
02d167e8: ldr     x21, [x8, #0x28]                           T:Trading.TradingCounterRequest
02d167ec: ldr     x0, [x9]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d167f0: bl      #0x2b7104c                                 fn_2b7104c
02d167f4: mov     x22, x0                                    
02d167f8: bl      #0x2d168d0                                 DreamHouse.DataDreamHouse/DreamHouseOldRoomData::.ctor
02d167fc: cbz     x22, #0x2d168c4                            
02d16800: adrp    x8, #0x6269000                             
02d16804: ldr     x8, [x8, #0x928]                           T:type57541(k15)
02d16808: ldr     w9, [x20, #0x10]                           &2b706e8(=14cc74f191004000)
02d1680c: ldr     x0, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d16810: str     w9, [x22, #0x10]                           
02d16814: bl      #0x2b7104c                                 fn_2b7104c
02d16818: adrp    x8, #0x6269000                             
02d1681c: mov     x20, x0                                    
02d16820: ldr     x8, [x8, #0x920]                           MS:UnityEngine.Rendering.SerializedDictionary`2::.ctor
02d16824: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d16828: bl      #0x3bdaf20                                 fn_3bdaf20
02d1682c: mov     x0, x22                                    
02d16830: mov     x1, x20                                    
02d16834: str     x20, [x0, #0x18]!                          
02d16838: bl      #0x2b70d54                                 fn_2b70d54
02d1683c: cbz     x21, #0x2d168c4                            
02d16840: adrp    x9, #0x6269000                             
02d16844: ldr     x9, [x9, #0x940]                           MS:System.Collections.Generic.List`1::Add
02d16848: ldr     w10, [x21, #0x1c]                          
02d1684c: ldr     x8, [x21, #0x10]                           
02d16850: ldr     x9, [x9]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d16854: add     w10, w10, #1                               
02d16858: str     w10, [x21, #0x1c]                          
02d1685c: cbz     x8, #0x2d168c4                             
02d16860: ldrsw   x10, [x21, #0x18]                          
02d16864: ldr     w11, [x8, #0x18]                           M:Trading.TradingSession::<ValidateTrade>b__57_0
02d16868: cmp     w10, w11                                   
02d1686c: b.hs    #0x2d1688c                                 
02d16870: add     x0, x8, x10, lsl #3                        &6269000
02d16874: add     w9, w10, #1                                
02d16878: mov     x1, x22                                    
02d1687c: str     w9, [x21, #0x18]                           
02d16880: str     x22, [x0, #0x20]!                          ._dataSave
02d16884: bl      #0x2b70d54                                 fn_2b70d54
02d16888: b       #0x2d168a4                                 
02d1688c: ldr     x8, [x9, #0x20]                            M:Trading.TradingSession::<ValidateTrade>b__57_1
02d16890: mov     x0, x21                                    
02d16894: mov     x1, x22                                    
02d16898: ldr     x8, [x8, #0xc0]                            MS:System.Linq.Enumerable::Select
02d1689c: ldr     x2, [x8, #0x70]                            T:Trading.TradingSession/<>c__DisplayClass63_0
02d168a0: bl      #0x35a920c                                 fn_35a920c
02d168a4: ldr     x8, [x19]                                  
02d168a8: mov     x0, x19                                    
02d168ac: ldp     x20, x19, [sp, #0x20]                      
02d168b0: ldp     x22, x21, [sp, #0x10]                      
02d168b4: ldr     x1, [x8, #0x260]                           M:Trading.PopupTradingEmptyCollection::OnBtnLaterClick
02d168b8: ldr     x2, [x8, #0x258]                           M:Trading.PopupTradingEmptyCollection::OnBtnGoDiyClick
02d168bc: ldp     x30, x23, [sp], #0x30                      
02d168c0: br      x2                                         
02d168c4: bl      #0x2b7105c                                 fn_2b7105c
## GetCurrentRoomIndex() -> int
---- DreamHouse.DataDreamHouse::GetCurrentRoomIndex 0x2d16960
02d16960: ldr     x8, [x0, #0x20]                            ._dataSave
02d16964: cbz     x8, #0x2d16970                             
02d16968: ldr     w0, [x8, #0x14]                            
02d1696c: ret                                                
02d16970: str     x30, [sp, #-0x10]!                         
02d16974: bl      #0x2b7105c                                 fn_2b7105c
## UnlockRoom(int roomIndex) -> void
---- DreamHouse.DataDreamHouse::UnlockRoom 0x2d16978
02d16978: str     x30, [sp, #-0x30]!                         
02d1697c: stp     x22, x21, [sp, #0x10]                      
02d16980: stp     x20, x19, [sp, #0x20]                      
02d16984: adrp    x20, #0x662f000                            
02d16988: adrp    x22, #0x6269000                            
02d1698c: mov     w21, w1                                    
02d16990: ldrb    w8, [x20, #0xfda]                          
02d16994: ldr     x22, [x22, #0x960]                         T:DreamHouse.DataDreamHouse/<>c__DisplayClass13_0
02d16998: mov     x19, x0                                    
02d1699c: tbnz    w8, #0, #0x2d16a20                         
02d169a0: adrp    x0, #0x6269000                             
02d169a4: ldr     x0, [x0, #0x938]                           T:DreamHouse.DataDreamHouse/DreamHouseOldRoomData
02d169a8: bl      #0x2b70db0                                 fn_2b70db0
02d169ac: adrp    x0, #0x6266000                             
02d169b0: ldr     x0, [x0, #0x818]                           MS:System.Collections.Generic.List`1::Add
02d169b4: bl      #0x2b70db0                                 fn_2b70db0
02d169b8: adrp    x0, #0x6269000                             
02d169bc: ldr     x0, [x0, #0x940]                           MS:System.Collections.Generic.List`1::Add
02d169c0: bl      #0x2b70db0                                 fn_2b70db0
02d169c4: adrp    x0, #0x6266000                             
02d169c8: ldr     x0, [x0, #0x820]                           MS:System.Collections.Generic.List`1::Contains
02d169cc: bl      #0x2b70db0                                 fn_2b70db0
02d169d0: adrp    x0, #0x6269000                             
02d169d4: ldr     x0, [x0, #0x948]                           MS:System.Collections.Generic.List`1::Find
02d169d8: bl      #0x2b70db0                                 fn_2b70db0
02d169dc: adrp    x0, #0x6269000                             
02d169e0: ldr     x0, [x0, #0x950]                           T:type57307(k15)
02d169e4: bl      #0x2b70db0                                 fn_2b70db0
02d169e8: adrp    x0, #0x6269000                             
02d169ec: ldr     x0, [x0, #0x920]                           MS:UnityEngine.Rendering.SerializedDictionary`2::.ctor
02d169f0: bl      #0x2b70db0                                 fn_2b70db0
02d169f4: adrp    x0, #0x6269000                             
02d169f8: ldr     x0, [x0, #0x928]                           T:type57541(k15)
02d169fc: bl      #0x2b70db0                                 fn_2b70db0
02d16a00: adrp    x0, #0x6269000                             
02d16a04: ldr     x0, [x0, #0x968]                           M:DreamHouse.DataDreamHouse/<>c__DisplayClass13_0::<UnlockRoom>b__0
02d16a08: bl      #0x2b70db0                                 fn_2b70db0
02d16a0c: adrp    x0, #0x6269000                             
02d16a10: ldr     x0, [x0, #0x960]                           T:DreamHouse.DataDreamHouse/<>c__DisplayClass13_0
02d16a14: bl      #0x2b70db0                                 fn_2b70db0
02d16a18: mov     w8, #1                                     
02d16a1c: strb    w8, [x20, #0xfda]                          
02d16a20: ldr     x0, [x22]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d16a24: bl      #0x2b7104c                                 fn_2b7104c
02d16a28: mov     x1, xzr                                    
02d16a2c: mov     x20, x0                                    
02d16a30: bl      #0x4e53e9c                                 System.Object::.ctor
02d16a34: cbz     x20, #0x2d16c20                            
02d16a38: ldr     x8, [x19, #0x20]                           ._dataSave
02d16a3c: str     w21, [x20, #0x10]                          
02d16a40: cbz     x8, #0x2d16c20                             
02d16a44: ldr     x0, [x8, #0x18]                            
02d16a48: cbz     x0, #0x2d16c20                             
02d16a4c: adrp    x8, #0x6266000                             
02d16a50: mov     w1, w21                                    
02d16a54: ldr     x8, [x8, #0x820]                           MS:System.Collections.Generic.List`1::Contains
02d16a58: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d16a5c: bl      #0x3569f98                                 fn_3569f98
02d16a60: tbz     w0, #0, #0x2d16a74                         
02d16a64: ldp     x20, x19, [sp, #0x20]                      
02d16a68: ldp     x22, x21, [sp, #0x10]                      
02d16a6c: ldr     x30, [sp], #0x30                           
02d16a70: ret                                                
02d16a74: ldr     x8, [x19, #0x20]                           ._dataSave
02d16a78: cbz     x8, #0x2d16c20                             
02d16a7c: ldr     x0, [x8, #0x18]                            S:'level_show_popuprate'
02d16a80: cbz     x0, #0x2d16c20                             
02d16a84: adrp    x10, #0x6266000                            
02d16a88: ldr     x10, [x10, #0x818]                         MS:System.Collections.Generic.List`1::Add
02d16a8c: ldr     w11, [x0, #0x1c]                           [626901c]=0 f=0,0
02d16a90: ldr     x9, [x0, #0x10]                            M:Trading.TradingSession/<>c__DisplayClass56_0::<RemovePlayerItem>b__0
02d16a94: ldr     w1, [x20, #0x10]                           &2b706e8(=14cc74f191004000)
02d16a98: ldr     x10, [x10]                                 M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d16a9c: add     w11, w11, #1                               
02d16aa0: str     w11, [x0, #0x1c]                           
02d16aa4: cbz     x9, #0x2d16c20                             
02d16aa8: ldrsw   x11, [x0, #0x18]                           
02d16aac: ldr     w12, [x9, #0x18]                           
02d16ab0: cmp     w11, w12                                   
02d16ab4: b.hs    #0x2d16acc                                 
02d16ab8: add     x9, x9, x11, lsl #2                        
02d16abc: add     w10, w11, #1                               
02d16ac0: str     w10, [x0, #0x18]                           
02d16ac4: str     w1, [x9, #0x20]                            
02d16ac8: b       #0x2d16ae4                                 
02d16acc: ldr     x8, [x10, #0x20]                           S:'inter_ad_capping_time'
02d16ad0: ldr     x8, [x8, #0xc0]                            T:Firebase.RemoteConfig.ConfigValue
02d16ad4: ldr     x2, [x8, #0x70]                            S:'open_ad_id'
02d16ad8: bl      #0x3569c18                                 fn_3569c18
02d16adc: ldr     x8, [x19, #0x20]                           ._dataSave
02d16ae0: cbz     x8, #0x2d16c20                             
02d16ae4: adrp    x9, #0x6269000                             
02d16ae8: ldr     x9, [x9, #0x950]                           T:type57307(k15)
02d16aec: ldr     x21, [x8, #0x28]                           S:'banner_ad_on_off'
02d16af0: ldr     x0, [x9]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d16af4: bl      #0x2b7104c                                 fn_2b7104c
02d16af8: adrp    x8, #0x6269000                             
02d16afc: mov     x1, x20                                    
02d16b00: mov     x3, xzr                                    
02d16b04: ldr     x8, [x8, #0x968]                           M:DreamHouse.DataDreamHouse/<>c__DisplayClass13_0::<UnlockRoom>b__0
02d16b08: mov     x22, x0                                    
02d16b0c: ldr     x2, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d16b10: bl      #0x399ba10                                 fn_399ba10
02d16b14: cbz     x21, #0x2d16c20                            
02d16b18: adrp    x8, #0x6269000                             
02d16b1c: mov     x0, x21                                    
02d16b20: mov     x1, x22                                    
02d16b24: ldr     x8, [x8, #0x948]                           MS:System.Collections.Generic.List`1::Find
02d16b28: ldr     x2, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d16b2c: bl      #0x35a9868                                 fn_35a9868
02d16b30: cbnz    x0, #0x2d16c00                             
02d16b34: ldr     x8, [x19, #0x20]                           ._dataSave
02d16b38: cbz     x8, #0x2d16c20                             
02d16b3c: adrp    x9, #0x6269000                             
02d16b40: ldr     x9, [x9, #0x938]                           T:DreamHouse.DataDreamHouse/DreamHouseOldRoomData
02d16b44: ldr     x21, [x8, #0x28]                           T:Trading.TradingCounterRequest
02d16b48: ldr     x0, [x9]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d16b4c: bl      #0x2b7104c                                 fn_2b7104c
02d16b50: mov     x22, x0                                    
02d16b54: bl      #0x2d168d0                                 DreamHouse.DataDreamHouse/DreamHouseOldRoomData::.ctor
02d16b58: cbz     x22, #0x2d16c20                            
02d16b5c: adrp    x8, #0x6269000                             
02d16b60: ldr     x8, [x8, #0x928]                           T:type57541(k15)
02d16b64: ldr     w9, [x20, #0x10]                           &2b706e8(=14cc74f191004000)
02d16b68: ldr     x0, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d16b6c: str     w9, [x22, #0x10]                           
02d16b70: bl      #0x2b7104c                                 fn_2b7104c
02d16b74: adrp    x8, #0x6269000                             
02d16b78: mov     x20, x0                                    
02d16b7c: ldr     x8, [x8, #0x920]                           MS:UnityEngine.Rendering.SerializedDictionary`2::.ctor
02d16b80: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d16b84: bl      #0x3bdaf20                                 fn_3bdaf20
02d16b88: mov     x0, x22                                    
02d16b8c: mov     x1, x20                                    
02d16b90: str     x20, [x0, #0x18]!                          
02d16b94: bl      #0x2b70d54                                 fn_2b70d54
02d16b98: cbz     x21, #0x2d16c20                            
02d16b9c: adrp    x9, #0x6269000                             
02d16ba0: ldr     x9, [x9, #0x940]                           MS:System.Collections.Generic.List`1::Add
02d16ba4: ldr     w10, [x21, #0x1c]                          
02d16ba8: ldr     x8, [x21, #0x10]                           
02d16bac: ldr     x9, [x9]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d16bb0: add     w10, w10, #1                               
02d16bb4: str     w10, [x21, #0x1c]                          
02d16bb8: cbz     x8, #0x2d16c20                             
02d16bbc: ldrsw   x10, [x21, #0x18]                          
02d16bc0: ldr     w11, [x8, #0x18]                           M:Trading.TradingSession::<ValidateTrade>b__57_0
02d16bc4: cmp     w10, w11                                   
02d16bc8: b.hs    #0x2d16be8                                 
02d16bcc: add     x0, x8, x10, lsl #3                        &6269000
02d16bd0: add     w9, w10, #1                                
02d16bd4: mov     x1, x22                                    
02d16bd8: str     w9, [x21, #0x18]                           
02d16bdc: str     x22, [x0, #0x20]!                          ._dataSave
02d16be0: bl      #0x2b70d54                                 fn_2b70d54
02d16be4: b       #0x2d16c00                                 
02d16be8: ldr     x8, [x9, #0x20]                            M:Trading.TradingSession::<ValidateTrade>b__57_1
02d16bec: mov     x0, x21                                    
02d16bf0: mov     x1, x22                                    
02d16bf4: ldr     x8, [x8, #0xc0]                            MS:System.Linq.Enumerable::Select
02d16bf8: ldr     x2, [x8, #0x70]                            T:Trading.TradingSession/<>c__DisplayClass63_0
02d16bfc: bl      #0x35a920c                                 fn_35a920c
02d16c00: ldr     x8, [x19]                                  
02d16c04: mov     x0, x19                                    
02d16c08: ldp     x20, x19, [sp, #0x20]                      
02d16c0c: ldp     x22, x21, [sp, #0x10]                      
02d16c10: ldr     x1, [x8, #0x260]                           M:Trading.PopupTradingEmptyCollection::OnBtnLaterClick
02d16c14: ldr     x2, [x8, #0x258]                           M:Trading.PopupTradingEmptyCollection::OnBtnGoDiyClick
02d16c18: ldr     x30, [sp], #0x30                           
02d16c1c: br      x2                                         
02d16c20: bl      #0x2b7105c                                 fn_2b7105c
## IsRoomUnlocked(int roomIndex) -> bool
---- DreamHouse.DataDreamHouse::IsRoomUnlocked 0x2d16c2c
02d16c2c: stp     x30, x21, [sp, #-0x20]!                    
02d16c30: stp     x20, x19, [sp, #0x10]                      
02d16c34: adrp    x21, #0x662f000                            
02d16c38: mov     w19, w1                                    
02d16c3c: mov     x20, x0                                    
02d16c40: ldrb    w8, [x21, #0xfdb]                          
02d16c44: tbnz    w8, #0, #0x2d16c5c                         
02d16c48: adrp    x0, #0x6266000                             
02d16c4c: ldr     x0, [x0, #0x820]                           MS:System.Collections.Generic.List`1::Contains
02d16c50: bl      #0x2b70db0                                 fn_2b70db0
02d16c54: mov     w8, #1                                     
02d16c58: strb    w8, [x21, #0xfdb]                          
02d16c5c: ldr     x8, [x20, #0x20]                           ._dataSave
02d16c60: cbz     x8, #0x2d16c88                             
02d16c64: ldr     x0, [x8, #0x18]                            
02d16c68: cbz     x0, #0x2d16c88                             
02d16c6c: adrp    x8, #0x6266000                             
02d16c70: mov     w1, w19                                    
02d16c74: ldr     x8, [x8, #0x820]                           MS:System.Collections.Generic.List`1::Contains
02d16c78: ldp     x20, x19, [sp, #0x10]                      
02d16c7c: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d16c80: ldp     x30, x21, [sp], #0x20                      
02d16c84: b       #0x3569f98                                 
02d16c88: bl      #0x2b7105c                                 fn_2b7105c
## AddCurrentRoomStep(int stepIndex, int optionIndex) -> void
---- DreamHouse.DataDreamHouse::AddCurrentRoomStep 0x2d16c8c
02d16c8c: sub     sp, sp, #0x70                              
02d16c90: str     x30, [sp, #0x30]                           
02d16c94: stp     x24, x23, [sp, #0x40]                      
02d16c98: stp     x22, x21, [sp, #0x50]                      
02d16c9c: stp     x20, x19, [sp, #0x60]                      
02d16ca0: adrp    x22, #0x662f000                            
02d16ca4: mov     w20, w2                                    
02d16ca8: mov     w21, w1                                    
02d16cac: ldrb    w8, [x22, #0xfdc]                          
02d16cb0: mov     x19, x0                                    
02d16cb4: tbnz    w8, #0, #0x2d16d74                         
02d16cb8: adrp    x0, #0x6269000                             
02d16cbc: ldr     x0, [x0, #0x970]                           M:DreamHouse.DataDreamHouse::<AddCurrentRoomStep>b__15_0
02d16cc0: bl      #0x2b70db0                                 fn_2b70db0
02d16cc4: adrp    x0, #0x6269000                             
02d16cc8: ldr     x0, [x0, #0x978]                           MS:System.Collections.Generic.Dictionary`2::GetEnumerator
02d16ccc: bl      #0x2b70db0                                 fn_2b70db0
02d16cd0: adrp    x0, #0x6269000                             
02d16cd4: ldr     x0, [x0, #0x980]                           MS:System.Collections.Generic.Dictionary`2::TryAdd
02d16cd8: bl      #0x2b70db0                                 fn_2b70db0
02d16cdc: adrp    x0, #0x6269000                             
02d16ce0: ldr     x0, [x0, #0x988]                           MS:System.Collections.Generic.Dictionary`2::set_Item
02d16ce4: bl      #0x2b70db0                                 fn_2b70db0
02d16ce8: adrp    x0, #0x6269000                             
02d16cec: ldr     x0, [x0, #0x938]                           T:DreamHouse.DataDreamHouse/DreamHouseOldRoomData
02d16cf0: bl      #0x2b70db0                                 fn_2b70db0
02d16cf4: adrp    x0, #0x6269000                             
02d16cf8: ldr     x0, [x0, #0x990]                           MS:System.Collections.Generic.Dictionary`2/Enumerator::Dispose
02d16cfc: bl      #0x2b70db0                                 fn_2b70db0
02d16d00: adrp    x0, #0x6269000                             
02d16d04: ldr     x0, [x0, #0x998]                           MS:System.Collections.Generic.Dictionary`2/Enumerator::MoveNext
02d16d08: bl      #0x2b70db0                                 fn_2b70db0
02d16d0c: adrp    x0, #0x6269000                             
02d16d10: ldr     x0, [x0, #0x9a0]                           MS:System.Collections.Generic.Dictionary`2/Enumerator::get_Current
02d16d14: bl      #0x2b70db0                                 fn_2b70db0
02d16d18: adrp    x0, #0x6269000                             
02d16d1c: ldr     x0, [x0, #0x9a8]                           MS:System.Collections.Generic.KeyValuePair`2::get_Key
02d16d20: bl      #0x2b70db0                                 fn_2b70db0
02d16d24: adrp    x0, #0x6269000                             
02d16d28: ldr     x0, [x0, #0x9b0]                           MS:System.Collections.Generic.KeyValuePair`2::get_Value
02d16d2c: bl      #0x2b70db0                                 fn_2b70db0
02d16d30: adrp    x0, #0x6269000                             
02d16d34: ldr     x0, [x0, #0x940]                           MS:System.Collections.Generic.List`1::Add
02d16d38: bl      #0x2b70db0                                 fn_2b70db0
02d16d3c: adrp    x0, #0x6269000                             
02d16d40: ldr     x0, [x0, #0x948]                           MS:System.Collections.Generic.List`1::Find
02d16d44: bl      #0x2b70db0                                 fn_2b70db0
02d16d48: adrp    x0, #0x6269000                             
02d16d4c: ldr     x0, [x0, #0x950]                           T:type57307(k15)
02d16d50: bl      #0x2b70db0                                 fn_2b70db0
02d16d54: adrp    x0, #0x6269000                             
02d16d58: ldr     x0, [x0, #0x920]                           MS:UnityEngine.Rendering.SerializedDictionary`2::.ctor
02d16d5c: bl      #0x2b70db0                                 fn_2b70db0
02d16d60: adrp    x0, #0x6269000                             
02d16d64: ldr     x0, [x0, #0x928]                           T:type57541(k15)
02d16d68: bl      #0x2b70db0                                 fn_2b70db0
02d16d6c: mov     w8, #1                                     
02d16d70: strb    w8, [x22, #0xfdc]                          
02d16d74: movi    v0.2d, #0000000000000000                   
02d16d78: ldr     x8, [x19, #0x20]                           ._dataSave
02d16d7c: stp     q0, q0, [sp, #0x10]                        
02d16d80: cbz     x8, #0x2d16fd8                             
02d16d84: ldr     x0, [x8, #0x20]                            
02d16d88: cbz     x0, #0x2d16fd8                             
02d16d8c: adrp    x24, #0x6269000                            
02d16d90: mov     w1, w21                                    
02d16d94: mov     w2, w20                                    
02d16d98: ldr     x24, [x24, #0x980]                         MS:System.Collections.Generic.Dictionary`2::TryAdd
02d16d9c: ldr     x3, [x24]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d16da0: bl      #0x44ae2c4                                 fn_44ae2c4
02d16da4: tbz     w0, #0, #0x2d16dbc                         
02d16da8: ldr     x8, [x19]                                  
02d16dac: mov     x0, x19                                    
02d16db0: ldr     x9, [x8, #0x258]                           
02d16db4: ldr     x1, [x8, #0x260]                           
02d16db8: blr     x9                                         
02d16dbc: ldr     x8, [x19, #0x20]                           ._dataSave
02d16dc0: cbz     x8, #0x2d16fd8                             
02d16dc4: adrp    x9, #0x6269000                             
02d16dc8: adrp    x23, #0x6269000                            
02d16dcc: ldr     x9, [x9, #0x950]                           T:type57307(k15)
02d16dd0: ldr     x23, [x23, #0x970]                         M:DreamHouse.DataDreamHouse::<AddCurrentRoomStep>b__15_0
02d16dd4: ldr     x22, [x8, #0x28]                           
02d16dd8: ldr     x0, [x9]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d16ddc: bl      #0x2b7104c                                 fn_2b7104c
02d16de0: ldr     x2, [x23]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d16de4: mov     x1, x19                                    
02d16de8: mov     x3, xzr                                    
02d16dec: mov     x23, x0                                    
02d16df0: bl      #0x399ba10                                 fn_399ba10
02d16df4: cbz     x22, #0x2d16fd8                            
02d16df8: adrp    x8, #0x6269000                             
02d16dfc: mov     x0, x22                                    
02d16e00: mov     x1, x23                                    
02d16e04: ldr     x8, [x8, #0x948]                           MS:System.Collections.Generic.List`1::Find
02d16e08: ldr     x2, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d16e0c: bl      #0x35a9868                                 fn_35a9868
02d16e10: cbz     x0, #0x2d16e58                             
02d16e14: ldr     x0, [x0, #0x18]                            M:Trading.TradingSession::<ValidateTrade>b__57_0
02d16e18: cbz     x0, #0x2d16fd8                             
02d16e1c: ldr     x3, [x24]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d16e20: mov     w1, w21                                    
02d16e24: mov     w2, w20                                    
02d16e28: bl      #0x44ae2c4                                 fn_44ae2c4
02d16e2c: tbz     w0, #0, #0x2d16fbc                         
02d16e30: ldr     x8, [x19]                                  
02d16e34: mov     x0, x19                                    
02d16e38: ldr     x30, [sp, #0x30]                           
02d16e3c: ldp     x20, x19, [sp, #0x60]                      
02d16e40: ldp     x22, x21, [sp, #0x50]                      
02d16e44: ldr     x1, [x8, #0x260]                           M:Trading.PopupTradingEmptyCollection::OnBtnLaterClick
02d16e48: ldp     x24, x23, [sp, #0x40]                      
02d16e4c: ldr     x2, [x8, #0x258]                           M:Trading.PopupTradingEmptyCollection::OnBtnGoDiyClick
02d16e50: add     sp, sp, #0x70                              
02d16e54: br      x2                                         
02d16e58: adrp    x8, #0x6269000                             
02d16e5c: ldr     x8, [x8, #0x938]                           T:DreamHouse.DataDreamHouse/DreamHouseOldRoomData
02d16e60: ldr     x0, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d16e64: bl      #0x2b7104c                                 fn_2b7104c
02d16e68: mov     x20, x0                                    
02d16e6c: bl      #0x2d168d0                                 DreamHouse.DataDreamHouse/DreamHouseOldRoomData::.ctor
02d16e70: ldr     x8, [x19, #0x20]                           ._dataSave
02d16e74: cbz     x8, #0x2d16fd8                             
02d16e78: cbz     x20, #0x2d16fd8                            
02d16e7c: adrp    x9, #0x6269000                             
02d16e80: ldr     x9, [x9, #0x928]                           T:type57541(k15)
02d16e84: ldr     w8, [x8, #0x14]                            [6269014]=0 f=0,0
02d16e88: ldr     x0, [x9]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d16e8c: str     w8, [x20, #0x10]                           
02d16e90: bl      #0x2b7104c                                 fn_2b7104c
02d16e94: adrp    x8, #0x6269000                             
02d16e98: mov     x22, x0                                    
02d16e9c: ldr     x8, [x8, #0x920]                           MS:UnityEngine.Rendering.SerializedDictionary`2::.ctor
02d16ea0: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d16ea4: bl      #0x3bdaf20                                 fn_3bdaf20
02d16ea8: mov     x21, x20                                   
02d16eac: mov     x1, x22                                    
02d16eb0: str     x22, [x21, #0x18]!                         
02d16eb4: mov     x0, x21                                    
02d16eb8: bl      #0x2b70d54                                 fn_2b70d54
02d16ebc: ldr     x8, [x19, #0x20]                           ._dataSave
02d16ec0: cbz     x8, #0x2d16fd8                             
02d16ec4: ldr     x0, [x8, #0x20]                            M:Trading.TradingSession::<ValidateTrade>b__57_1
02d16ec8: cbz     x0, #0x2d16fd8                             
02d16ecc: adrp    x8, #0x6269000                             
02d16ed0: add     x24, sp, #0x10                             
02d16ed4: ldr     x8, [x8, #0x978]                           MS:System.Collections.Generic.Dictionary`2::GetEnumerator
02d16ed8: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d16edc: add     x8, sp, #0x10                              
02d16ee0: bl      #0x44accc8                                 fn_44accc8
02d16ee4: adrp    x22, #0x6269000                            
02d16ee8: adrp    x23, #0x6269000                            
02d16eec: ldr     x22, [x22, #0x998]                         MS:System.Collections.Generic.Dictionary`2/Enumerator::MoveNext
02d16ef0: ldr     x23, [x23, #0x988]                         MS:System.Collections.Generic.Dictionary`2::set_Item
02d16ef4: stp     xzr, x24, [sp]                             
02d16ef8: ldr     x1, [x22]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d16efc: add     x0, sp, #0x10                              
02d16f00: bl      #0x46e504c                                 fn_46e504c
02d16f04: tbz     w0, #0, #0x2d16f20                         
02d16f08: ldr     x0, [x21]                                  
02d16f0c: cbz     x0, #0x2d16fd4                             
02d16f10: ldp     w1, w2, [sp, #0x20]                        
02d16f14: ldr     x3, [x23]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d16f18: bl      #0x44ac8dc                                 fn_44ac8dc
02d16f1c: b       #0x2d16ef8                                 
02d16f20: adrp    x8, #0x6269000                             
02d16f24: add     x0, sp, #0x10                              
02d16f28: ldr     x8, [x8, #0x990]                           MS:System.Collections.Generic.Dictionary`2/Enumerator::Dispose
02d16f2c: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d16f30: bl      #0x46e5154                                 fn_46e5154
02d16f34: ldr     x8, [x19, #0x20]                           ._dataSave
02d16f38: cbz     x8, #0x2d16fd8                             
02d16f3c: ldr     x0, [x8, #0x28]                            T:Trading.TradingCounterRequest
02d16f40: cbz     x0, #0x2d16fd8                             
02d16f44: adrp    x9, #0x6269000                             
02d16f48: ldr     x9, [x9, #0x940]                           MS:System.Collections.Generic.List`1::Add
02d16f4c: ldr     w10, [x0, #0x1c]                           [626901c]=0 f=0,0
02d16f50: ldr     x8, [x0, #0x10]                            M:Trading.TradingSession/<>c__DisplayClass56_0::<RemovePlayerItem>b__0
02d16f54: ldr     x9, [x9]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d16f58: add     w10, w10, #1                               
02d16f5c: str     w10, [x0, #0x1c]                           
02d16f60: cbz     x8, #0x2d16fd8                             
02d16f64: ldrsw   x10, [x0, #0x18]                           
02d16f68: ldr     w11, [x8, #0x18]                           M:Trading.TradingSession::<ValidateTrade>b__57_0
02d16f6c: cmp     w10, w11                                   
02d16f70: b.hs    #0x2d16f94                                 
02d16f74: add     x8, x8, x10, lsl #3                        &6269000
02d16f78: add     w9, w10, #1                                
02d16f7c: mov     x1, x20                                    
02d16f80: str     w9, [x0, #0x18]                            
02d16f84: str     x20, [x8, #0x20]!                          
02d16f88: mov     x0, x8                                     
02d16f8c: bl      #0x2b70d54                                 fn_2b70d54
02d16f90: b       #0x2d16fa8                                 
02d16f94: ldr     x8, [x9, #0x20]                            M:Trading.TradingSession::<ValidateTrade>b__57_1
02d16f98: mov     x1, x20                                    
02d16f9c: ldr     x8, [x8, #0xc0]                            MS:System.Linq.Enumerable::Select
02d16fa0: ldr     x2, [x8, #0x70]                            T:Trading.TradingSession/<>c__DisplayClass63_0
02d16fa4: bl      #0x35a920c                                 fn_35a920c
02d16fa8: ldr     x8, [x19]                                  
02d16fac: mov     x0, x19                                    
02d16fb0: ldr     x9, [x8, #0x258]                           M:Trading.PopupTradingEmptyCollection::OnBtnGoDiyClick
02d16fb4: ldr     x1, [x8, #0x260]                           M:Trading.PopupTradingEmptyCollection::OnBtnLaterClick
02d16fb8: blr     x9                                         
02d16fbc: ldp     x20, x19, [sp, #0x60]                      
02d16fc0: ldr     x30, [sp, #0x30]                           
02d16fc4: ldp     x22, x21, [sp, #0x50]                      
02d16fc8: ldp     x24, x23, [sp, #0x40]                      
02d16fcc: add     sp, sp, #0x70                              
02d16fd0: ret                                                
02d16fd4: bl      #0x2b7105c                                 fn_2b7105c
02d16fd8: bl      #0x2b7105c                                 fn_2b7105c
02d16fdc: b       #0x2d16fe4                                 
02d16fe0: b       #0x2d16fe4                                 
02d16fe4: mov     x21, x0                                    
02d16fe8: cmp     w1, #1                                     
02d16fec: b.ne    #0x2d17028                                 
02d16ff0: mov     x0, x21                                    
02d16ff4: bl      #0x5e90260                                 fn_5e90260
02d16ff8: ldr     x21, [x0]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d16ffc: str     x21, [sp]                                  
02d17000: bl      #0x5e90270                                 fn_5e90270
02d17004: adrp    x8, #0x6269000                             
02d17008: ldr     x8, [x8, #0x990]                           MS:System.Collections.Generic.Dictionary`2/Enumerator::Dispose
02d1700c: ldr     x0, [sp, #8]                               
02d17010: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d17014: bl      #0x46e5154                                 fn_46e5154
02d17018: cbz     x21, #0x2d16f34                            
02d1701c: mov     x0, x21                                    
02d17020: bl      #0x2b71054                                 fn_2b71054
02d17024: mov     x21, x0                                    
02d17028: mov     x0, sp                                     
02d1702c: bl      #0x2737fb4                                 fn_2737fb4
02d17030: mov     x0, x21                                    
02d17034: bl      #0x2c6051c                                 fn_2c6051c
02d17038: bl      #0x27369b8                                 fn_27369b8
## RefreshCurrentRoomSteps() -> void
---- DreamHouse.DataDreamHouse::RefreshCurrentRoomSteps 0x2d1703c
02d1703c: str     x30, [sp, #-0x30]!                         
02d17040: stp     x22, x21, [sp, #0x10]                      
02d17044: stp     x20, x19, [sp, #0x20]                      
02d17048: adrp    x20, #0x662f000                            
02d1704c: adrp    x22, #0x6269000                            
02d17050: adrp    x21, #0x6269000                            
02d17054: ldrb    w8, [x20, #0xfdd]                          
02d17058: ldr     x22, [x22, #0x928]                         T:type57541(k15)
02d1705c: ldr     x21, [x21, #0x920]                         MS:UnityEngine.Rendering.SerializedDictionary`2::.ctor
02d17060: mov     x19, x0                                    
02d17064: tbnz    w8, #0, #0x2d17088                         
02d17068: adrp    x0, #0x6269000                             
02d1706c: ldr     x0, [x0, #0x920]                           MS:UnityEngine.Rendering.SerializedDictionary`2::.ctor
02d17070: bl      #0x2b70db0                                 fn_2b70db0
02d17074: adrp    x0, #0x6269000                             
02d17078: ldr     x0, [x0, #0x928]                           T:type57541(k15)
02d1707c: bl      #0x2b70db0                                 fn_2b70db0
02d17080: mov     w8, #1                                     
02d17084: strb    w8, [x20, #0xfdd]                          
02d17088: ldr     x0, [x22]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1708c: ldr     x20, [x19, #0x20]                          ._dataSave
02d17090: bl      #0x2b7104c                                 fn_2b7104c
02d17094: ldr     x1, [x21]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d17098: mov     x21, x0                                    
02d1709c: bl      #0x3bdaf20                                 fn_3bdaf20
02d170a0: cbz     x20, #0x2d170d4                            
02d170a4: str     x21, [x20, #0x20]!                         ._dataSave
02d170a8: mov     x0, x20                                    
02d170ac: mov     x1, x21                                    
02d170b0: bl      #0x2b70d54                                 fn_2b70d54
02d170b4: ldr     x8, [x19]                                  
02d170b8: mov     x0, x19                                    
02d170bc: ldp     x20, x19, [sp, #0x20]                      
02d170c0: ldp     x22, x21, [sp, #0x10]                      
02d170c4: ldr     x1, [x8, #0x260]                           
02d170c8: ldr     x2, [x8, #0x258]                           
02d170cc: ldr     x30, [sp], #0x30                           
02d170d0: br      x2                                         
02d170d4: bl      #0x2b7105c                                 fn_2b7105c
## LoadCurrentRoomSteps() -> void
---- DreamHouse.DataDreamHouse::LoadCurrentRoomSteps 0x2d170d8
02d170d8: sub     sp, sp, #0x60                              
02d170dc: stp     x30, x23, [sp, #0x30]                      
02d170e0: stp     x22, x21, [sp, #0x40]                      
02d170e4: stp     x20, x19, [sp, #0x50]                      
02d170e8: adrp    x20, #0x662f000                            
02d170ec: mov     x19, x0                                    
02d170f0: ldrb    w8, [x20, #0xfde]                          
02d170f4: tbnz    w8, #0, #0x2d17190                         
02d170f8: adrp    x0, #0x6269000                             
02d170fc: ldr     x0, [x0, #0x9b8]                           M:DreamHouse.DataDreamHouse::<LoadCurrentRoomSteps>b__17_0
02d17100: bl      #0x2b70db0                                 fn_2b70db0
02d17104: adrp    x0, #0x6269000                             
02d17108: ldr     x0, [x0, #0x978]                           MS:System.Collections.Generic.Dictionary`2::GetEnumerator
02d1710c: bl      #0x2b70db0                                 fn_2b70db0
02d17110: adrp    x0, #0x6269000                             
02d17114: ldr     x0, [x0, #0x988]                           MS:System.Collections.Generic.Dictionary`2::set_Item
02d17118: bl      #0x2b70db0                                 fn_2b70db0
02d1711c: adrp    x0, #0x6269000                             
02d17120: ldr     x0, [x0, #0x990]                           MS:System.Collections.Generic.Dictionary`2/Enumerator::Dispose
02d17124: bl      #0x2b70db0                                 fn_2b70db0
02d17128: adrp    x0, #0x6269000                             
02d1712c: ldr     x0, [x0, #0x998]                           MS:System.Collections.Generic.Dictionary`2/Enumerator::MoveNext
02d17130: bl      #0x2b70db0                                 fn_2b70db0
02d17134: adrp    x0, #0x6269000                             
02d17138: ldr     x0, [x0, #0x9a0]                           MS:System.Collections.Generic.Dictionary`2/Enumerator::get_Current
02d1713c: bl      #0x2b70db0                                 fn_2b70db0
02d17140: adrp    x0, #0x6269000                             
02d17144: ldr     x0, [x0, #0x9a8]                           MS:System.Collections.Generic.KeyValuePair`2::get_Key
02d17148: bl      #0x2b70db0                                 fn_2b70db0
02d1714c: adrp    x0, #0x6269000                             
02d17150: ldr     x0, [x0, #0x9b0]                           MS:System.Collections.Generic.KeyValuePair`2::get_Value
02d17154: bl      #0x2b70db0                                 fn_2b70db0
02d17158: adrp    x0, #0x6269000                             
02d1715c: ldr     x0, [x0, #0x948]                           MS:System.Collections.Generic.List`1::Find
02d17160: bl      #0x2b70db0                                 fn_2b70db0
02d17164: adrp    x0, #0x6269000                             
02d17168: ldr     x0, [x0, #0x950]                           T:type57307(k15)
02d1716c: bl      #0x2b70db0                                 fn_2b70db0
02d17170: adrp    x0, #0x6269000                             
02d17174: ldr     x0, [x0, #0x920]                           MS:UnityEngine.Rendering.SerializedDictionary`2::.ctor
02d17178: bl      #0x2b70db0                                 fn_2b70db0
02d1717c: adrp    x0, #0x6269000                             
02d17180: ldr     x0, [x0, #0x928]                           T:type57541(k15)
02d17184: bl      #0x2b70db0                                 fn_2b70db0
02d17188: mov     w8, #1                                     
02d1718c: strb    w8, [x20, #0xfde]                          
02d17190: movi    v0.2d, #0000000000000000                   
02d17194: ldr     x8, [x19, #0x20]                           ._dataSave
02d17198: stp     q0, q0, [sp, #0x10]                        
02d1719c: cbz     x8, #0x2d172dc                             
02d171a0: adrp    x9, #0x6269000                             
02d171a4: adrp    x21, #0x6269000                            
02d171a8: ldr     x9, [x9, #0x950]                           T:type57307(k15)
02d171ac: ldr     x21, [x21, #0x9b8]                         M:DreamHouse.DataDreamHouse::<LoadCurrentRoomSteps>b__17_0
02d171b0: ldr     x20, [x8, #0x28]                           
02d171b4: ldr     x0, [x9]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d171b8: bl      #0x2b7104c                                 fn_2b7104c
02d171bc: ldr     x2, [x21]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d171c0: mov     x1, x19                                    
02d171c4: mov     x3, xzr                                    
02d171c8: mov     x21, x0                                    
02d171cc: bl      #0x399ba10                                 fn_399ba10
02d171d0: cbz     x20, #0x2d172dc                            
02d171d4: adrp    x8, #0x6269000                             
02d171d8: adrp    x22, #0x6269000                            
02d171dc: adrp    x23, #0x6269000                            
02d171e0: ldr     x8, [x8, #0x948]                           MS:System.Collections.Generic.List`1::Find
02d171e4: ldr     x22, [x22, #0x928]                         T:type57541(k15)
02d171e8: ldr     x23, [x23, #0x920]                         MS:UnityEngine.Rendering.SerializedDictionary`2::.ctor
02d171ec: mov     x0, x20                                    
02d171f0: mov     x1, x21                                    
02d171f4: ldr     x2, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d171f8: bl      #0x35a9868                                 fn_35a9868
02d171fc: ldr     x8, [x22]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d17200: ldr     x21, [x19, #0x20]                          ._dataSave
02d17204: mov     x20, x0                                    
02d17208: mov     x0, x8                                     
02d1720c: bl      #0x2b7104c                                 fn_2b7104c
02d17210: ldr     x1, [x23]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d17214: mov     x22, x0                                    
02d17218: bl      #0x3bdaf20                                 fn_3bdaf20
02d1721c: cbz     x21, #0x2d172dc                            
02d17220: str     x22, [x21, #0x20]!                         ._dataSave
02d17224: mov     x0, x21                                    
02d17228: mov     x1, x22                                    
02d1722c: bl      #0x2b70d54                                 fn_2b70d54
02d17230: cbz     x20, #0x2d172ac                            
02d17234: ldr     x0, [x20, #0x18]                           [662f018]=6000014 f=2.40742e-35,0
02d17238: cbz     x0, #0x2d172dc                             
02d1723c: adrp    x8, #0x6269000                             
02d17240: adrp    x20, #0x6269000                            
02d17244: adrp    x22, #0x6269000                            
02d17248: ldr     x8, [x8, #0x978]                           MS:System.Collections.Generic.Dictionary`2::GetEnumerator
02d1724c: adrp    x21, #0x6269000                            
02d17250: ldr     x20, [x20, #0x998]                         MS:System.Collections.Generic.Dictionary`2/Enumerator::MoveNext
02d17254: ldr     x22, [x22, #0x988]                         MS:System.Collections.Generic.Dictionary`2::set_Item
02d17258: ldr     x21, [x21, #0x990]                         MS:System.Collections.Generic.Dictionary`2/Enumerator::Dispose
02d1725c: add     x23, sp, #0x10                             
02d17260: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d17264: add     x8, sp, #0x10                              
02d17268: bl      #0x44accc8                                 fn_44accc8
02d1726c: stp     xzr, x23, [sp]                             
02d17270: ldr     x1, [x20]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d17274: add     x0, sp, #0x10                              
02d17278: bl      #0x46e504c                                 fn_46e504c
02d1727c: tbz     w0, #0, #0x2d172a0                         
02d17280: ldr     x8, [x19, #0x20]                           ._dataSave
02d17284: cbz     x8, #0x2d172d4                             
02d17288: ldr     x0, [x8, #0x20]                            M:Trading.TradingSession::<ValidateTrade>b__57_1
02d1728c: cbz     x0, #0x2d172d8                             
02d17290: ldp     w1, w2, [sp, #0x20]                        
02d17294: ldr     x3, [x22]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d17298: bl      #0x44ac8dc                                 fn_44ac8dc
02d1729c: b       #0x2d17270                                 
02d172a0: ldr     x1, [x21]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d172a4: add     x0, sp, #0x10                              
02d172a8: bl      #0x46e5154                                 fn_46e5154
02d172ac: ldr     x8, [x19]                                  
02d172b0: mov     x0, x19                                    
02d172b4: ldr     x9, [x8, #0x258]                           M:Trading.PopupTradingEmptyCollection::OnBtnGoDiyClick
02d172b8: ldr     x1, [x8, #0x260]                           M:Trading.PopupTradingEmptyCollection::OnBtnLaterClick
02d172bc: blr     x9                                         
02d172c0: ldp     x20, x19, [sp, #0x50]                      
02d172c4: ldp     x22, x21, [sp, #0x40]                      
02d172c8: ldp     x30, x23, [sp, #0x30]                      
02d172cc: add     sp, sp, #0x60                              
02d172d0: ret                                                
02d172d4: bl      #0x2b7105c                                 fn_2b7105c
02d172d8: bl      #0x2b7105c                                 fn_2b7105c
02d172dc: bl      #0x2b7105c                                 fn_2b7105c
02d172e0: b       #0x2d172ec                                 
02d172e4: b       #0x2d172ec                                 
02d172e8: b       #0x2d172ec                                 
02d172ec: mov     x20, x0                                    
02d172f0: cmp     w1, #1                                     
02d172f4: b.ne    #0x2d17328                                 
02d172f8: mov     x0, x20                                    
02d172fc: bl      #0x5e90260                                 fn_5e90260
02d17300: ldr     x20, [x0]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d17304: str     x20, [sp]                                  
02d17308: bl      #0x5e90270                                 fn_5e90270
02d1730c: ldr     x0, [sp, #8]                               
02d17310: ldr     x1, [x21]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d17314: bl      #0x46e5154                                 fn_46e5154
02d17318: cbz     x20, #0x2d172ac                            
02d1731c: mov     x0, x20                                    
02d17320: bl      #0x2b71054                                 fn_2b71054
02d17324: mov     x20, x0                                    
02d17328: mov     x0, sp                                     
02d1732c: bl      #0x2737fb4                                 fn_2737fb4
02d17330: mov     x0, x20                                    
02d17334: bl      #0x2c6051c                                 fn_2c6051c
02d17338: bl      #0x27369b8                                 fn_27369b8
## GetCurrentRoomStep() -> int
---- DreamHouse.DataDreamHouse::GetCurrentRoomStep 0x2d1733c
02d1733c: str     x30, [sp, #-0x20]!                         
02d17340: stp     x20, x19, [sp, #0x10]                      
02d17344: adrp    x20, #0x662f000                            
02d17348: mov     x19, x0                                    
02d1734c: ldrb    w8, [x20, #0xfdf]                          
02d17350: tbnz    w8, #0, #0x2d17368                         
02d17354: adrp    x0, #0x6269000                             
02d17358: ldr     x0, [x0, #0x9c0]                           MS:System.Collections.Generic.Dictionary`2::get_Count
02d1735c: bl      #0x2b70db0                                 fn_2b70db0
02d17360: mov     w8, #1                                     
02d17364: strb    w8, [x20, #0xfdf]                          
02d17368: ldr     x8, [x19, #0x20]                           ._dataSave
02d1736c: cbz     x8, #0x2d17390                             
02d17370: ldr     x0, [x8, #0x20]                            
02d17374: cbz     x0, #0x2d17390                             
02d17378: adrp    x8, #0x6269000                             
02d1737c: ldr     x8, [x8, #0x9c0]                           MS:System.Collections.Generic.Dictionary`2::get_Count
02d17380: ldp     x20, x19, [sp, #0x10]                      
02d17384: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d17388: ldr     x30, [sp], #0x20                           
02d1738c: b       #0x44ac58c                                 
02d17390: bl      #0x2b7105c                                 fn_2b7105c
## SetDoneTutorial(bool isDone) -> void
---- DreamHouse.DataDreamHouse::SetDoneTutorial 0x2d17394
02d17394: ldr     x8, [x0, #0x20]                            ._dataSave
02d17398: cbz     x8, #0x2d173c4                             
02d1739c: ldrb    w10, [x8, #0x11]                           
02d173a0: and     w9, w1, #1                                 
02d173a4: cmp     w10, w9                                    
02d173a8: b.ne    #0x2d173b0                                 
02d173ac: ret                                                
02d173b0: strb    w9, [x8, #0x11]                            
02d173b4: ldr     x8, [x0]                                   
02d173b8: ldr     x1, [x8, #0x260]                           
02d173bc: ldr     x2, [x8, #0x258]                           
02d173c0: br      x2                                         
02d173c4: str     x30, [sp, #-0x10]!                         
02d173c8: bl      #0x2b7105c                                 fn_2b7105c
## IsDoneTutorial() -> bool
---- DreamHouse.DataDreamHouse::IsDoneTutorial 0x2d173cc
02d173cc: ldr     x8, [x0, #0x20]                            ._dataSave
02d173d0: cbz     x8, #0x2d173dc                             
02d173d4: ldrb    w0, [x8, #0x11]                            
02d173d8: ret                                                
02d173dc: str     x30, [sp, #-0x10]!                         
02d173e0: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- DreamHouse.DataDreamHouse::.ctor 0x2d173e4
02d173e4: mov     x1, xzr                                    
02d173e8: b       #0x2ca9988                                 GameData::.ctor
## <AddCurrentRoomStep>b__15_0(DreamHouse.DataDreamHouse/DreamHouseOldRoomData x) -> bool
---- DreamHouse.DataDreamHouse::<AddCurrentRoomStep>b__15_0 0x2d173ec
02d173ec: str     x30, [sp, #-0x10]!                         
02d173f0: cbz     x1, #0x2d17414                             
02d173f4: ldr     x8, [x0, #0x20]                            ._dataSave
02d173f8: cbz     x8, #0x2d17414                             
02d173fc: ldr     w9, [x1, #0x10]                            
02d17400: ldr     w8, [x8, #0x14]                            
02d17404: cmp     w9, w8                                     
02d17408: cset    w0, eq                                     
02d1740c: ldr     x30, [sp], #0x10                           
02d17410: ret                                                
02d17414: bl      #0x2b7105c                                 fn_2b7105c
## <LoadCurrentRoomSteps>b__17_0(DreamHouse.DataDreamHouse/DreamHouseOldRoomData x) -> bool
---- DreamHouse.DataDreamHouse::<LoadCurrentRoomSteps>b__17_0 0x2d17418
02d17418: str     x30, [sp, #-0x10]!                         
02d1741c: cbz     x1, #0x2d17440                             
02d17420: ldr     x8, [x0, #0x20]                            ._dataSave
02d17424: cbz     x8, #0x2d17440                             
02d17428: ldr     w9, [x1, #0x10]                            
02d1742c: ldr     w8, [x8, #0x14]                            
02d17430: cmp     w9, w8                                     
02d17434: cset    w0, eq                                     
02d17438: ldr     x30, [sp], #0x10                           
02d1743c: ret                                                
02d17440: bl      #0x2b7105c                                 fn_2b7105c
