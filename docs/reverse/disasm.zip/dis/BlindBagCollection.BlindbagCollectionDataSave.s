#### CLASS BlindBagCollection.BlindbagCollectionDataSave parent= object
#   field BoxsetDataSave                 System.Collections.Generic.List`1<BlindBagCollection.BoxsetData> off=0x10 attr=6 
## .ctor() -> void
---- BlindBagCollection.BlindbagCollectionDataSave::.ctor 0x2d36224
02d36224: mov     x1, xzr                                    
02d36228: b       #0x4e53e9c                                 System.Object::.ctor
