#### CLASS Jelly.IClickable parent= None
##  OnMouseButtonDown (no body)
##  OnMouseButtonDrag (no body)
##  OnMouseButtonUp (no body)
