#### CLASS FsnCollapAd parent= object
#   field androidCollapAd                UnityEngine.AndroidJavaObject                      off=0x10 attr=1 
#   field onFsnLoadListener              AndroidOnFsnLoadListener                           off=0x18 attr=1 
#   field onFsnCompletedListener         AndroidOnFsnCompletedListener                      off=0x20 attr=1 
#   field onFsnClosedListener            AndroidOnFsnCompletedListener                      off=0x28 attr=1 
## .ctor() -> void
---- FsnCollapAd::.ctor 0x2c94894
02c94894: str     x30, [sp, #-0x30]!                         
02c94898: stp     x22, x21, [sp, #0x10]                      
02c9489c: stp     x20, x19, [sp, #0x20]                      
02c948a0: adrp    x21, #0x662f000                            
02c948a4: adrp    x20, #0x6264000                            
02c948a8: mov     x19, x0                                    
02c948ac: ldrb    w8, [x21, #0x9ed]                          
02c948b0: ldr     x20, [x20, #0xa70]                         T:UnityEngine.Application
02c948b4: tbnz    w8, #0, #0x2c948f0                         
02c948b8: adrp    x0, #0x6263000                             
02c948bc: ldr     x0, [x0, #0xbd8]                           T:UnityEngine.AndroidJavaObject
02c948c0: bl      #0x2b70db0                                 fn_2b70db0
02c948c4: adrp    x0, #0x6264000                             
02c948c8: ldr     x0, [x0, #0xa70]                           T:UnityEngine.Application
02c948cc: bl      #0x2b70db0                                 fn_2b70db0
02c948d0: adrp    x0, #0x6263000                             
02c948d4: ldr     x0, [x0, #0xb70]                           MS:System.Array::Empty
02c948d8: bl      #0x2b70db0                                 fn_2b70db0
02c948dc: adrp    x0, #0x6265000                             
02c948e0: ldr     x0, [x0, #0x700]                           S:'com.ads.fsnforunity.fsnlib.FsnAd'
02c948e4: bl      #0x2b70db0                                 fn_2b70db0
02c948e8: mov     w8, #1                                     
02c948ec: strb    w8, [x21, #0x9ed]                          
02c948f0: mov     x0, x19                                    
02c948f4: mov     x1, xzr                                    
02c948f8: bl      #0x4e53e9c                                 System.Object::.ctor
02c948fc: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c94900: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c94904: cbnz    w8, #0x2c9490c                             
02c94908: bl      #0x2b70f30                                 fn_2b70f30
02c9490c: mov     x0, xzr                                    
02c94910: bl      #0x5aeb18c                                 UnityEngine.Application::get_platform
02c94914: cmp     w0, #0xb                                   
02c94918: b.ne    #0x2c949c4                                 
02c9491c: adrp    x8, #0x6263000                             
02c94920: ldr     x8, [x8, #0xb70]                           MS:System.Array::Empty
02c94924: ldr     x20, [x8]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c94928: ldr     x8, [x20, #0x38]                           M:UnityEngine.Rigidbody::MovePosition
02c9492c: cbnz    x8, #0x2c9493c                             
02c94930: mov     x0, x20                                    
02c94934: bl      #0x2ba9d7c                                 fn_2ba9d7c
02c94938: ldr     x8, [x20, #0x38]                           M:UnityEngine.Rigidbody::MovePosition
02c9493c: ldr     x0, [x8, #0x10]                            &2c498bc(=aa1f03e0d503245f)
02c94940: add     x8, x0, #0x135                             &6265135
02c94944: ldrh    w8, [x8]                                   
02c94948: tbnz    w8, #0, #0x2c94950                         
02c9494c: bl      #0x2ba9d20                                 fn_2ba9d20
02c94950: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c94954: cbnz    w8, #0x2c9495c                             
02c94958: bl      #0x2b70f30                                 fn_2b70f30
02c9495c: ldr     x8, [x20, #0x38]                           M:UnityEngine.Rigidbody::MovePosition
02c94960: adrp    x22, #0x6263000                            
02c94964: adrp    x21, #0x6265000                            
02c94968: ldr     x0, [x8, #0x10]                            &2c498bc(=aa1f03e0d503245f)
02c9496c: ldr     x22, [x22, #0xbd8]                         T:UnityEngine.AndroidJavaObject
02c94970: add     x8, x0, #0x135                             &6265135
02c94974: ldrh    w8, [x8]                                   
02c94978: ldr     x21, [x21, #0x700]                         S:'com.ads.fsnforunity.fsnlib.FsnAd'
02c9497c: tbnz    w8, #0, #0x2c94984                         
02c94980: bl      #0x2ba9d20                                 fn_2ba9d20
02c94984: ldr     x8, [x0, #0xb8]                            T:AdsManager/<>c__DisplayClass42_0
02c94988: ldr     x0, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c9498c: ldr     x20, [x8]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c94990: bl      #0x2b7104c                                 fn_2b7104c
02c94994: ldr     x1, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c94998: mov     x2, x20                                    
02c9499c: mov     x3, xzr                                    
02c949a0: mov     x21, x0                                    
02c949a4: bl      #0x5ad5b2c                                 UnityEngine.AndroidJavaObject::.ctor
02c949a8: str     x21, [x19, #0x10]!                         .androidCollapAd
02c949ac: mov     x0, x19                                    
02c949b0: mov     x1, x21                                    
02c949b4: ldp     x20, x19, [sp, #0x20]                      
02c949b8: ldp     x22, x21, [sp, #0x10]                      
02c949bc: ldr     x30, [sp], #0x30                           
02c949c0: b       #0x2b70d54                                 
02c949c4: ldp     x20, x19, [sp, #0x20]                      
02c949c8: ldp     x22, x21, [sp, #0x10]                      
02c949cc: ldr     x30, [sp], #0x30                           
02c949d0: ret                                                
## Init(string adUnitId, int countDownSec, bool loadNewAfterClose, bool startMuteVideo, bool autoDismissWhenAdClicked) -> void
---- FsnCollapAd::Init 0x2c949d4
02c949d4: sub     sp, sp, #0x60                              
02c949d8: str     x30, [sp, #0x10]                           
02c949dc: stp     x26, x25, [sp, #0x20]                      
02c949e0: stp     x24, x23, [sp, #0x30]                      
02c949e4: stp     x22, x21, [sp, #0x40]                      
02c949e8: stp     x20, x19, [sp, #0x50]                      
02c949ec: adrp    x21, #0x662f000                            
02c949f0: adrp    x26, #0x6264000                            
02c949f4: mov     w19, w5                                    
02c949f8: ldrb    w8, [x21, #0x9ee]                          
02c949fc: ldr     x26, [x26, #0xa70]                         T:UnityEngine.Application
02c94a00: mov     w22, w4                                    
02c94a04: mov     w23, w3                                    
02c94a08: mov     w24, w2                                    
02c94a0c: mov     x25, x1                                    
02c94a10: mov     x20, x0                                    
02c94a14: tbnz    w8, #0, #0x2c94a44                         
02c94a18: adrp    x0, #0x6264000                             
02c94a1c: ldr     x0, [x0, #0xa70]                           T:UnityEngine.Application
02c94a20: bl      #0x2b70db0                                 fn_2b70db0
02c94a24: adrp    x0, #0x6263000                             
02c94a28: ldr     x0, [x0, #0xa80]                           T:type24502(k1d)
02c94a2c: bl      #0x2b70db0                                 fn_2b70db0
02c94a30: adrp    x0, #0x6265000                             
02c94a34: ldr     x0, [x0, #0x708]                           S:'Init'
02c94a38: bl      #0x2b70db0                                 fn_2b70db0
02c94a3c: mov     w8, #1                                     
02c94a40: strb    w8, [x21, #0x9ee]                          
02c94a44: ldr     x0, [x26]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c94a48: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c94a4c: cbnz    w8, #0x2c94a54                             
02c94a50: bl      #0x2b70f30                                 fn_2b70f30
02c94a54: mov     x0, xzr                                    
02c94a58: bl      #0x5aeb18c                                 UnityEngine.Application::get_platform
02c94a5c: cmp     w0, #0xb                                   
02c94a60: b.ne    #0x2c94c08                                 
02c94a64: ldr     x20, [x20, #0x10]                          .androidCollapAd
02c94a68: cbz     x20, #0x2c94c08                            
02c94a6c: adrp    x8, #0x6263000                             
02c94a70: mov     w1, #5                                     
02c94a74: ldr     x8, [x8, #0xa80]                           T:type24502(k1d)
02c94a78: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c94a7c: bl      #0x2b70ea0                                 fn_2b70ea0
02c94a80: cbz     x0, #0x2c94c34                             
02c94a84: mov     x21, x0                                    
02c94a88: cbz     x25, #0x2c94aa0                            
02c94a8c: ldr     x8, [x21]                                  &2b706c4(=eb01011ff9400808)
02c94a90: mov     x0, x25                                    
02c94a94: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02c94a98: bl      #0x2b70f34                                 fn_2b70f34
02c94a9c: cbz     x0, #0x2c94c28                             
02c94aa0: ldr     w8, [x21, #0x18]                           [662f018]=6000014 f=2.40742e-35,0 .onFsnLoadListener
02c94aa4: cbz     w8, #0x2c94c24                             
02c94aa8: mov     x0, x21                                    
02c94aac: mov     x1, x25                                    
02c94ab0: str     x25, [x0, #0x20]!                          .onFsnCompletedListener
02c94ab4: bl      #0x2b70d54                                 fn_2b70d54
02c94ab8: adrp    x25, #0x6263000                            
02c94abc: add     x1, sp, #0x1c                              
02c94ac0: ldr     x25, [x25, #0x970]                         &6645c70(=0)
02c94ac4: str     w24, [sp, #0x1c]                           
02c94ac8: ldr     x0, [x25, #0x48]                           &6263098(=0)
02c94acc: bl      #0x2b70f38                                 fn_2b70f38
02c94ad0: mov     x24, x0                                    
02c94ad4: cbz     x0, #0x2c94aec                             
02c94ad8: ldr     x8, [x21]                                  &2b706c4(=eb01011ff9400808)
02c94adc: mov     x0, x24                                    
02c94ae0: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02c94ae4: bl      #0x2b70f34                                 fn_2b70f34
02c94ae8: cbz     x0, #0x2c94c28                             
02c94aec: ldr     w8, [x21, #0x18]                           [662f018]=6000014 f=2.40742e-35,0 .onFsnLoadListener
02c94af0: tst     w8, #0xfffffffe                            
02c94af4: b.eq    #0x2c94c24                                 
02c94af8: mov     x0, x21                                    
02c94afc: mov     x1, x24                                    
02c94b00: and     w23, w23, #1                               
02c94b04: str     x24, [x0, #0x28]!                          .onFsnClosedListener
02c94b08: bl      #0x2b70d54                                 fn_2b70d54
02c94b0c: ldr     x0, [x25, #0x28]                           [6263028]=0 f=0,0
02c94b10: add     x1, sp, #0x18                              
02c94b14: strb    w23, [sp, #0x18]                           
02c94b18: bl      #0x2b70f38                                 fn_2b70f38
02c94b1c: mov     x23, x0                                    
02c94b20: cbz     x0, #0x2c94b38                             
02c94b24: ldr     x8, [x21]                                  &2b706c4(=eb01011ff9400808)
02c94b28: mov     x0, x23                                    
02c94b2c: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02c94b30: bl      #0x2b70f34                                 fn_2b70f34
02c94b34: cbz     x0, #0x2c94c28                             
02c94b38: ldr     w8, [x21, #0x18]                           [662f018]=6000014 f=2.40742e-35,0 .onFsnLoadListener
02c94b3c: cmp     w8, #2                                     
02c94b40: b.ls    #0x2c94c24                                 
02c94b44: mov     x0, x21                                    
02c94b48: mov     x1, x23                                    
02c94b4c: and     w22, w22, #1                               
02c94b50: str     x23, [x0, #0x30]!                          
02c94b54: bl      #0x2b70d54                                 fn_2b70d54
02c94b58: ldr     x0, [x25, #0x28]                           [6263028]=0 f=0,0
02c94b5c: add     x1, sp, #0xc                               
02c94b60: strb    w22, [sp, #0xc]                            
02c94b64: bl      #0x2b70f38                                 fn_2b70f38
02c94b68: mov     x22, x0                                    
02c94b6c: cbz     x0, #0x2c94b84                             
02c94b70: ldr     x8, [x21]                                  &2b706c4(=eb01011ff9400808)
02c94b74: mov     x0, x22                                    
02c94b78: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02c94b7c: bl      #0x2b70f34                                 fn_2b70f34
02c94b80: cbz     x0, #0x2c94c28                             
02c94b84: ldr     w8, [x21, #0x18]                           [662f018]=6000014 f=2.40742e-35,0 .onFsnLoadListener
02c94b88: tst     w8, #0xfffffffc                            
02c94b8c: b.eq    #0x2c94c24                                 
02c94b90: mov     x0, x21                                    
02c94b94: mov     x1, x22                                    
02c94b98: and     w19, w19, #1                               
02c94b9c: str     x22, [x0, #0x38]!                          
02c94ba0: bl      #0x2b70d54                                 fn_2b70d54
02c94ba4: ldr     x0, [x25, #0x28]                           [6263028]=0 f=0,0
02c94ba8: add     x1, sp, #8                                 
02c94bac: strb    w19, [sp, #8]                              
02c94bb0: bl      #0x2b70f38                                 fn_2b70f38
02c94bb4: mov     x19, x0                                    
02c94bb8: cbz     x0, #0x2c94bd0                             
02c94bbc: ldr     x8, [x21]                                  &2b706c4(=eb01011ff9400808)
02c94bc0: mov     x0, x19                                    
02c94bc4: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02c94bc8: bl      #0x2b70f34                                 fn_2b70f34
02c94bcc: cbz     x0, #0x2c94c28                             
02c94bd0: ldr     w8, [x21, #0x18]                           [662f018]=6000014 f=2.40742e-35,0 .onFsnLoadListener
02c94bd4: cmp     w8, #4                                     
02c94bd8: b.ls    #0x2c94c24                                 
02c94bdc: mov     x0, x21                                    
02c94be0: mov     x1, x19                                    
02c94be4: str     x19, [x0, #0x40]!                          
02c94be8: bl      #0x2b70d54                                 fn_2b70d54
02c94bec: adrp    x8, #0x6265000                             
02c94bf0: mov     x0, x20                                    
02c94bf4: mov     x2, x21                                    
02c94bf8: ldr     x8, [x8, #0x708]                           S:'Init'
02c94bfc: mov     x3, xzr                                    
02c94c00: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c94c04: bl      #0x5ad5e34                                 UnityEngine.AndroidJavaObject::Call
02c94c08: ldp     x20, x19, [sp, #0x50]                      
02c94c0c: ldr     x30, [sp, #0x10]                           
02c94c10: ldp     x22, x21, [sp, #0x40]                      
02c94c14: ldp     x24, x23, [sp, #0x30]                      
02c94c18: ldp     x26, x25, [sp, #0x20]                      
02c94c1c: add     sp, sp, #0x60                              
02c94c20: ret                                                
02c94c24: bl      #0x2b71064                                 fn_2b71064
02c94c28: bl      #0x2b71080                                 fn_2b71080
02c94c2c: mov     x1, xzr                                    
02c94c30: bl      #0x2b70f20                                 fn_2b70f20
02c94c34: bl      #0x2b7105c                                 fn_2b7105c
## SetFsnListener(System.Action`2<int,string> onLoadingCompleted, System.Action onLoadingStarted, System.Action`4<string,string,double,string> onAdPaid) -> void
---- FsnCollapAd::SetFsnListener 0x2c94c38
02c94c38: str     x30, [sp, #-0x40]!                         
02c94c3c: stp     x24, x23, [sp, #0x10]                      
02c94c40: stp     x22, x21, [sp, #0x20]                      
02c94c44: stp     x20, x19, [sp, #0x30]                      
02c94c48: adrp    x23, #0x662f000                            
02c94c4c: adrp    x24, #0x6264000                            
02c94c50: mov     x20, x3                                    
02c94c54: ldrb    w8, [x23, #0x9ef]                          
02c94c58: ldr     x24, [x24, #0xa70]                         T:UnityEngine.Application
02c94c5c: mov     x21, x2                                    
02c94c60: mov     x22, x1                                    
02c94c64: mov     x19, x0                                    
02c94c68: tbnz    w8, #0, #0x2c94ca4                         
02c94c6c: adrp    x0, #0x6265000                             
02c94c70: ldr     x0, [x0, #0x710]                           T:AndroidOnFsnLoadListener
02c94c74: bl      #0x2b70db0                                 fn_2b70db0
02c94c78: adrp    x0, #0x6264000                             
02c94c7c: ldr     x0, [x0, #0xa70]                           T:UnityEngine.Application
02c94c80: bl      #0x2b70db0                                 fn_2b70db0
02c94c84: adrp    x0, #0x6263000                             
02c94c88: ldr     x0, [x0, #0xa80]                           T:type24502(k1d)
02c94c8c: bl      #0x2b70db0                                 fn_2b70db0
02c94c90: adrp    x0, #0x6265000                             
02c94c94: ldr     x0, [x0, #0x718]                           S:'SetFsnListener'
02c94c98: bl      #0x2b70db0                                 fn_2b70db0
02c94c9c: mov     w8, #1                                     
02c94ca0: strb    w8, [x23, #0x9ef]                          
02c94ca4: ldr     x0, [x24]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c94ca8: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c94cac: cbnz    w8, #0x2c94cb4                             
02c94cb0: bl      #0x2b70f30                                 fn_2b70f30
02c94cb4: mov     x0, xzr                                    
02c94cb8: bl      #0x5aeb18c                                 UnityEngine.Application::get_platform
02c94cbc: cmp     w0, #0xb                                   
02c94cc0: b.ne    #0x2c94d7c                                 
02c94cc4: adrp    x8, #0x6265000                             
02c94cc8: ldr     x8, [x8, #0x710]                           T:AndroidOnFsnLoadListener
02c94ccc: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c94cd0: bl      #0x2b7104c                                 fn_2b7104c
02c94cd4: mov     x1, x22                                    
02c94cd8: mov     x2, x21                                    
02c94cdc: mov     x3, x20                                    
02c94ce0: mov     x23, x0                                    
02c94ce4: bl      #0x2c933dc                                 AndroidOnFsnLoadListener::.ctor
02c94ce8: str     x23, [x19, #0x18]!                         .onFsnLoadListener
02c94cec: mov     x0, x19                                    
02c94cf0: mov     x1, x23                                    
02c94cf4: bl      #0x2b70d54                                 fn_2b70d54
02c94cf8: ldur    x20, [x19, #-8]                            
02c94cfc: cbz     x20, #0x2c94d7c                            
02c94d00: adrp    x8, #0x6263000                             
02c94d04: mov     w1, #1                                     
02c94d08: ldr     x8, [x8, #0xa80]                           T:type24502(k1d)
02c94d0c: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c94d10: bl      #0x2b70ea0                                 fn_2b70ea0
02c94d14: cbz     x0, #0x2c94d90                             
02c94d18: ldr     x19, [x19]                                 
02c94d1c: mov     x21, x0                                    
02c94d20: cbz     x19, #0x2c94d38                            
02c94d24: ldr     x8, [x21]                                  
02c94d28: mov     x0, x19                                    
02c94d2c: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02c94d30: bl      #0x2b70f34                                 fn_2b70f34
02c94d34: cbz     x0, #0x2c94d98                             
02c94d38: ldr     w8, [x21, #0x18]                           .onFsnLoadListener
02c94d3c: cbz     w8, #0x2c94d94                             
02c94d40: mov     x0, x21                                    
02c94d44: mov     x1, x19                                    
02c94d48: str     x19, [x0, #0x20]!                          .onFsnCompletedListener
02c94d4c: bl      #0x2b70d54                                 fn_2b70d54
02c94d50: adrp    x8, #0x6265000                             
02c94d54: mov     x0, x20                                    
02c94d58: mov     x2, x21                                    
02c94d5c: ldr     x8, [x8, #0x718]                           S:'SetFsnListener'
02c94d60: ldp     x20, x19, [sp, #0x30]                      
02c94d64: ldp     x22, x21, [sp, #0x20]                      
02c94d68: mov     x3, xzr                                    
02c94d6c: ldp     x24, x23, [sp, #0x10]                      
02c94d70: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c94d74: ldr     x30, [sp], #0x40                           
02c94d78: b       #0x5ad5e34                                 UnityEngine.AndroidJavaObject::Call
02c94d7c: ldp     x20, x19, [sp, #0x30]                      
02c94d80: ldp     x22, x21, [sp, #0x20]                      
02c94d84: ldp     x24, x23, [sp, #0x10]                      
02c94d88: ldr     x30, [sp], #0x40                           
02c94d8c: ret                                                
02c94d90: bl      #0x2b7105c                                 fn_2b7105c
02c94d94: bl      #0x2b71064                                 fn_2b71064
02c94d98: bl      #0x2b71080                                 fn_2b71080
02c94d9c: mov     x1, xzr                                    
02c94da0: bl      #0x2b70f20                                 fn_2b70f20
## SetOnCloseListener(System.Action`1<string> onAdClosed) -> void
---- FsnCollapAd::SetOnCloseListener 0x2c94da4
02c94da4: str     x30, [sp, #-0x30]!                         
02c94da8: stp     x22, x21, [sp, #0x10]                      
02c94dac: stp     x20, x19, [sp, #0x20]                      
02c94db0: adrp    x21, #0x662f000                            
02c94db4: adrp    x22, #0x6264000                            
02c94db8: mov     x20, x1                                    
02c94dbc: ldrb    w8, [x21, #0x9f0]                          
02c94dc0: ldr     x22, [x22, #0xa70]                         T:UnityEngine.Application
02c94dc4: mov     x19, x0                                    
02c94dc8: tbnz    w8, #0, #0x2c94e04                         
02c94dcc: adrp    x0, #0x6265000                             
02c94dd0: ldr     x0, [x0, #0x740]                           T:AndroidOnFsnCompletedListener
02c94dd4: bl      #0x2b70db0                                 fn_2b70db0
02c94dd8: adrp    x0, #0x6264000                             
02c94ddc: ldr     x0, [x0, #0xa70]                           T:UnityEngine.Application
02c94de0: bl      #0x2b70db0                                 fn_2b70db0
02c94de4: adrp    x0, #0x6263000                             
02c94de8: ldr     x0, [x0, #0xa80]                           T:type24502(k1d)
02c94dec: bl      #0x2b70db0                                 fn_2b70db0
02c94df0: adrp    x0, #0x6265000                             
02c94df4: ldr     x0, [x0, #0x7b0]                           S:'SetOnCloseListener'
02c94df8: bl      #0x2b70db0                                 fn_2b70db0
02c94dfc: mov     w8, #1                                     
02c94e00: strb    w8, [x21, #0x9f0]                          
02c94e04: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c94e08: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c94e0c: cbnz    w8, #0x2c94e14                             
02c94e10: bl      #0x2b70f30                                 fn_2b70f30
02c94e14: mov     x0, xzr                                    
02c94e18: bl      #0x5aeb18c                                 UnityEngine.Application::get_platform
02c94e1c: cmp     w0, #0xb                                   
02c94e20: b.ne    #0x2c94ec8                                 
02c94e24: adrp    x8, #0x6265000                             
02c94e28: ldr     x8, [x8, #0x740]                           T:AndroidOnFsnCompletedListener
02c94e2c: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c94e30: bl      #0x2b7104c                                 fn_2b7104c
02c94e34: mov     x1, x20                                    
02c94e38: mov     x22, x0                                    
02c94e3c: bl      #0x2c93874                                 AndroidOnFsnCompletedListener::.ctor
02c94e40: mov     x21, x19                                   
02c94e44: str     x22, [x21, #0x28]!                         .onFsnClosedListener
02c94e48: mov     x0, x21                                    
02c94e4c: mov     x1, x22                                    
02c94e50: bl      #0x2b70d54                                 fn_2b70d54
02c94e54: ldr     x19, [x19, #0x10]                          .androidCollapAd
02c94e58: cbz     x19, #0x2c94ec8                            
02c94e5c: adrp    x8, #0x6263000                             
02c94e60: ldr     x8, [x8, #0xa80]                           T:type24502(k1d)
02c94e64: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c94e68: mov     w1, #1                                     
02c94e6c: bl      #0x2b70ea0                                 fn_2b70ea0
02c94e70: mov     x20, x0                                    
02c94e74: cbz     x0, #0x2c94ed8                             
02c94e78: ldr     x21, [x21]                                 &2b706c4(=eb01011ff9400808)
02c94e7c: cbz     x21, #0x2c94e94                            
02c94e80: ldr     x8, [x20]                                  
02c94e84: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02c94e88: mov     x0, x21                                    
02c94e8c: bl      #0x2b70f34                                 fn_2b70f34
02c94e90: cbz     x0, #0x2c94ee0                             
02c94e94: ldr     w8, [x20, #0x18]                           .onFsnLoadListener
02c94e98: cbz     w8, #0x2c94edc                             
02c94e9c: mov     x0, x20                                    
02c94ea0: str     x21, [x0, #0x20]!                          .onFsnCompletedListener
02c94ea4: mov     x1, x21                                    
02c94ea8: bl      #0x2b70d54                                 fn_2b70d54
02c94eac: adrp    x8, #0x6265000                             
02c94eb0: ldr     x8, [x8, #0x7b0]                           S:'SetOnCloseListener'
02c94eb4: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c94eb8: mov     x0, x19                                    
02c94ebc: mov     x2, x20                                    
02c94ec0: mov     x3, xzr                                    
02c94ec4: bl      #0x5ad5e34                                 UnityEngine.AndroidJavaObject::Call
02c94ec8: ldp     x20, x19, [sp, #0x20]                      
02c94ecc: ldp     x22, x21, [sp, #0x10]                      
02c94ed0: ldr     x30, [sp], #0x30                           
02c94ed4: ret                                                
02c94ed8: bl      #0x2b7105c                                 fn_2b7105c
02c94edc: bl      #0x2b71064                                 fn_2b71064
02c94ee0: bl      #0x2b71080                                 fn_2b71080
02c94ee4: mov     x1, xzr                                    
02c94ee8: bl      #0x2b70f20                                 fn_2b70f20
02c94eec: b       #0x2c94ef4                                 
02c94ef0: b       #0x2c94ef4                                 
02c94ef4: mov     x19, x0                                    
02c94ef8: cmp     w1, #1                                     
02c94efc: b.ne    #0x2c94fc0                                 
02c94f00: mov     x0, x19                                    
02c94f04: bl      #0x5e90260                                 fn_5e90260
02c94f08: mov     x19, x0                                    
02c94f0c: adrp    x0, #0x6263000                             
02c94f10: ldr     x0, [x0, #0xae0]                           T:System.Exception
02c94f14: bl      #0x2b70dc4                                 fn_2b70dc4
02c94f18: ldr     x8, [x19]                                  
02c94f1c: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c94f20: bl      #0x2b71464                                 fn_2b71464
02c94f24: tbz     w0, #0, #0x2c94f94                         
02c94f28: ldr     x19, [x19]                                 
02c94f2c: bl      #0x5e90270                                 fn_5e90270
02c94f30: cbz     x19, #0x2c94fb4                            
02c94f34: ldr     x8, [x19]                                  
02c94f38: mov     x0, x19                                    
02c94f3c: ldp     x9, x1, [x8, #0x188]                       
02c94f40: blr     x9                                         
02c94f44: mov     x19, x0                                    
02c94f48: adrp    x0, #0x6265000                             
02c94f4c: ldr     x0, [x0, #0x7b8]                           S:'[FsnCollapAd] SetOnCloseListener failed (Ensure fsnlib.aar is updated)'
02c94f50: bl      #0x2b70dc4                                 fn_2b70dc4
02c94f54: mov     x1, x19                                    
02c94f58: mov     x2, xzr                                    
02c94f5c: bl      #0x4c9c514                                 System.String::Concat
02c94f60: mov     x19, x0                                    
02c94f64: adrp    x0, #0x6263000                             
02c94f68: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c94f6c: bl      #0x2b70dc4                                 fn_2b70dc4
02c94f70: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02c94f74: cbnz    w8, #0x2c94f7c                             
02c94f78: bl      #0x2b70f30                                 fn_2b70f30
02c94f7c: mov     x0, x19                                    
02c94f80: ldp     x20, x19, [sp, #0x20]                      
02c94f84: ldp     x22, x21, [sp, #0x10]                      
02c94f88: mov     x1, xzr                                    
02c94f8c: ldr     x30, [sp], #0x30                           
02c94f90: b       #0x5af2c94                                 UnityEngine.Debug::LogWarning
02c94f94: mov     w0, #8                                     
02c94f98: bl      #0x5e90290                                 fn_5e90290
02c94f9c: ldr     x8, [x19]                                  
02c94fa0: str     x8, [x0]                                   
02c94fa4: adrp    x1, #0x5e96000                             
02c94fa8: add     x1, x1, #0x758                             &5e96758
02c94fac: mov     x2, xzr                                    
02c94fb0: bl      #0x5e902a0                                 fn_5e902a0
02c94fb4: bl      #0x2b7105c                                 fn_2b7105c
02c94fb8: mov     x19, x0                                    
02c94fbc: bl      #0x5e90270                                 fn_5e90270
02c94fc0: mov     x0, x19                                    
02c94fc4: bl      #0x2c6051c                                 fn_2c6051c
02c94fc8: bl      #0x27369b8                                 fn_27369b8
## LoadAd() -> void
---- FsnCollapAd::LoadAd 0x2c94fcc
02c94fcc: stp     x30, x21, [sp, #-0x20]!                    
02c94fd0: stp     x20, x19, [sp, #0x10]                      
02c94fd4: adrp    x20, #0x662f000                            
02c94fd8: adrp    x21, #0x6264000                            
02c94fdc: mov     x19, x0                                    
02c94fe0: ldrb    w8, [x20, #0x9f1]                          
02c94fe4: ldr     x21, [x21, #0xa70]                         T:UnityEngine.Application
02c94fe8: tbnz    w8, #0, #0x2c95048                         
02c94fec: adrp    x0, #0x6263000                             
02c94ff0: ldr     x0, [x0, #0xc40]                           T:UnityEngine.AndroidJavaClass
02c94ff4: bl      #0x2b70db0                                 fn_2b70db0
02c94ff8: adrp    x0, #0x6263000                             
02c94ffc: ldr     x0, [x0, #0xc50]                           MS:UnityEngine.AndroidJavaObject::GetStatic
02c95000: bl      #0x2b70db0                                 fn_2b70db0
02c95004: adrp    x0, #0x6264000                             
02c95008: ldr     x0, [x0, #0xa70]                           T:UnityEngine.Application
02c9500c: bl      #0x2b70db0                                 fn_2b70db0
02c95010: adrp    x0, #0x6263000                             
02c95014: ldr     x0, [x0, #0xa80]                           T:type24502(k1d)
02c95018: bl      #0x2b70db0                                 fn_2b70db0
02c9501c: adrp    x0, #0x6265000                             
02c95020: ldr     x0, [x0, #0x728]                           S:'LoadAd'
02c95024: bl      #0x2b70db0                                 fn_2b70db0
02c95028: adrp    x0, #0x6265000                             
02c9502c: ldr     x0, [x0, #0x730]                           S:'com.unity3d.player.UnityPlayer'
02c95030: bl      #0x2b70db0                                 fn_2b70db0
02c95034: adrp    x0, #0x6265000                             
02c95038: ldr     x0, [x0, #0x738]                           S:'currentActivity'
02c9503c: bl      #0x2b70db0                                 fn_2b70db0
02c95040: mov     w8, #1                                     
02c95044: strb    w8, [x20, #0x9f1]                          
02c95048: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c9504c: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c95050: cbnz    w8, #0x2c95058                             
02c95054: bl      #0x2b70f30                                 fn_2b70f30
02c95058: mov     x0, xzr                                    
02c9505c: bl      #0x5aeb18c                                 UnityEngine.Application::get_platform
02c95060: cmp     w0, #0xb                                   
02c95064: b.ne    #0x2c95130                                 
02c95068: adrp    x8, #0x6263000                             
02c9506c: adrp    x20, #0x6265000                            
02c95070: ldr     x8, [x8, #0xc40]                           T:UnityEngine.AndroidJavaClass
02c95074: ldr     x20, [x20, #0x730]                         S:'com.unity3d.player.UnityPlayer'
02c95078: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c9507c: bl      #0x2b7104c                                 fn_2b7104c
02c95080: ldr     x1, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c95084: mov     x2, xzr                                    
02c95088: mov     x20, x0                                    
02c9508c: bl      #0x5ad2f6c                                 UnityEngine.AndroidJavaClass::.ctor
02c95090: cbz     x20, #0x2c9513c                            
02c95094: adrp    x8, #0x6265000                             
02c95098: adrp    x9, #0x6263000                             
02c9509c: mov     x0, x20                                    
02c950a0: ldr     x8, [x8, #0x738]                           S:'currentActivity'
02c950a4: ldr     x9, [x9, #0xc50]                           MS:UnityEngine.AndroidJavaObject::GetStatic
02c950a8: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c950ac: ldr     x2, [x9]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c950b0: bl      #0x3121808                                 fn_3121808
02c950b4: ldr     x19, [x19, #0x10]                          .androidCollapAd
02c950b8: cbz     x19, #0x2c95130                            
02c950bc: adrp    x8, #0x6263000                             
02c950c0: mov     x20, x0                                    
02c950c4: mov     w1, #1                                     
02c950c8: ldr     x8, [x8, #0xa80]                           T:type24502(k1d)
02c950cc: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c950d0: bl      #0x2b70ea0                                 fn_2b70ea0
02c950d4: cbz     x0, #0x2c9513c                             
02c950d8: mov     x21, x0                                    
02c950dc: cbz     x20, #0x2c950f4                            
02c950e0: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c950e4: mov     x0, x20                                    
02c950e8: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02c950ec: bl      #0x2b70f34                                 fn_2b70f34
02c950f0: cbz     x0, #0x2c95144                             
02c950f4: ldr     w8, [x21, #0x18]                           M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0::<DOSetFloat>b__1 .onFsnLoadListener
02c950f8: cbz     w8, #0x2c95140                             
02c950fc: mov     x0, x21                                    
02c95100: mov     x1, x20                                    
02c95104: str     x20, [x0, #0x20]!                          .onFsnCompletedListener
02c95108: bl      #0x2b70d54                                 fn_2b70d54
02c9510c: adrp    x8, #0x6265000                             
02c95110: mov     x0, x19                                    
02c95114: mov     x2, x21                                    
02c95118: ldr     x8, [x8, #0x728]                           S:'LoadAd'
02c9511c: ldp     x20, x19, [sp, #0x10]                      
02c95120: mov     x3, xzr                                    
02c95124: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c95128: ldp     x30, x21, [sp], #0x20                      
02c9512c: b       #0x5ad5e34                                 UnityEngine.AndroidJavaObject::Call
02c95130: ldp     x20, x19, [sp, #0x10]                      
02c95134: ldp     x30, x21, [sp], #0x20                      
02c95138: ret                                                
02c9513c: bl      #0x2b7105c                                 fn_2b7105c
02c95140: bl      #0x2b71064                                 fn_2b71064
02c95144: bl      #0x2b71080                                 fn_2b71080
02c95148: mov     x1, xzr                                    
02c9514c: bl      #0x2b70f20                                 fn_2b70f20
## ShowAd(System.Action`1<string> onAdCompleted, System.Action`1<string> onAdClosed) -> void
---- FsnCollapAd::ShowAd 0x2c95150
02c95150: stp     x30, x25, [sp, #-0x40]!                    
02c95154: stp     x24, x23, [sp, #0x10]                      
02c95158: stp     x22, x21, [sp, #0x20]                      
02c9515c: stp     x20, x19, [sp, #0x30]                      
02c95160: adrp    x20, #0x662f000                            
02c95164: adrp    x23, #0x6264000                            
02c95168: mov     x22, x2                                    
02c9516c: ldrb    w8, [x20, #0x9f2]                          
02c95170: ldr     x23, [x23, #0xa70]                         T:UnityEngine.Application
02c95174: mov     x21, x1                                    
02c95178: mov     x19, x0                                    
02c9517c: tbnz    w8, #0, #0x2c95200                         
02c95180: adrp    x0, #0x6263000                             
02c95184: ldr     x0, [x0, #0xc40]                           T:UnityEngine.AndroidJavaClass
02c95188: bl      #0x2b70db0                                 fn_2b70db0
02c9518c: adrp    x0, #0x6263000                             
02c95190: ldr     x0, [x0, #0xc50]                           MS:UnityEngine.AndroidJavaObject::GetStatic
02c95194: bl      #0x2b70db0                                 fn_2b70db0
02c95198: adrp    x0, #0x6265000                             
02c9519c: ldr     x0, [x0, #0x740]                           T:AndroidOnFsnCompletedListener
02c951a0: bl      #0x2b70db0                                 fn_2b70db0
02c951a4: adrp    x0, #0x6264000                             
02c951a8: ldr     x0, [x0, #0xa70]                           T:UnityEngine.Application
02c951ac: bl      #0x2b70db0                                 fn_2b70db0
02c951b0: adrp    x0, #0x6263000                             
02c951b4: ldr     x0, [x0, #0xa80]                           T:type24502(k1d)
02c951b8: bl      #0x2b70db0                                 fn_2b70db0
02c951bc: adrp    x0, #0x6265000                             
02c951c0: ldr     x0, [x0, #0x730]                           S:'com.unity3d.player.UnityPlayer'
02c951c4: bl      #0x2b70db0                                 fn_2b70db0
02c951c8: adrp    x0, #0x6265000                             
02c951cc: ldr     x0, [x0, #0x7c0]                           S:'closed'
02c951d0: bl      #0x2b70db0                                 fn_2b70db0
02c951d4: adrp    x0, #0x6265000                             
02c951d8: ldr     x0, [x0, #0x7c8]                           S:'ShowCollapAd'
02c951dc: bl      #0x2b70db0                                 fn_2b70db0
02c951e0: adrp    x0, #0x6263000                             
02c951e4: ldr     x0, [x0, #0xa90]                           S:''
02c951e8: bl      #0x2b70db0                                 fn_2b70db0
02c951ec: adrp    x0, #0x6265000                             
02c951f0: ldr     x0, [x0, #0x738]                           S:'currentActivity'
02c951f4: bl      #0x2b70db0                                 fn_2b70db0
02c951f8: mov     w8, #1                                     
02c951fc: strb    w8, [x20, #0x9f2]                          
02c95200: ldr     x0, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c95204: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c95208: cbnz    w8, #0x2c95210                             
02c9520c: bl      #0x2b70f30                                 fn_2b70f30
02c95210: mov     x0, xzr                                    
02c95214: bl      #0x5aeb18c                                 UnityEngine.Application::get_platform
02c95218: cmp     w0, #0xb                                   
02c9521c: b.ne    #0x2c953b4                                 
02c95220: adrp    x8, #0x6263000                             
02c95224: adrp    x20, #0x6265000                            
02c95228: ldr     x8, [x8, #0xc40]                           T:UnityEngine.AndroidJavaClass
02c9522c: ldr     x20, [x20, #0x730]                         S:'com.unity3d.player.UnityPlayer'
02c95230: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c95234: bl      #0x2b7104c                                 fn_2b7104c
02c95238: ldr     x1, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9523c: mov     x2, xzr                                    
02c95240: mov     x20, x0                                    
02c95244: bl      #0x5ad2f6c                                 UnityEngine.AndroidJavaClass::.ctor
02c95248: cbz     x20, #0x2c95624                            
02c9524c: adrp    x8, #0x6265000                             
02c95250: adrp    x9, #0x6263000                             
02c95254: mov     x0, x20                                    
02c95258: ldr     x8, [x8, #0x738]                           S:'currentActivity'
02c9525c: ldr     x9, [x9, #0xc50]                           MS:UnityEngine.AndroidJavaObject::GetStatic
02c95260: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c95264: ldr     x2, [x9]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c95268: bl      #0x3121808                                 fn_3121808
02c9526c: adrp    x24, #0x6265000                            
02c95270: mov     x20, x0                                    
02c95274: ldr     x24, [x24, #0x740]                         T:AndroidOnFsnCompletedListener
02c95278: ldr     x8, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c9527c: mov     x0, x8                                     
02c95280: bl      #0x2b7104c                                 fn_2b7104c
02c95284: mov     x1, x21                                    
02c95288: mov     x23, x0                                    
02c9528c: bl      #0x2c93874                                 AndroidOnFsnCompletedListener::.ctor
02c95290: mov     x21, x19                                   
02c95294: mov     x1, x23                                    
02c95298: str     x23, [x21, #0x20]!                         .onFsnCompletedListener
02c9529c: mov     x0, x21                                    
02c952a0: bl      #0x2b70d54                                 fn_2b70d54
02c952a4: cbz     x22, #0x2c95404                            
02c952a8: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c952ac: bl      #0x2b7104c                                 fn_2b7104c
02c952b0: mov     x1, x22                                    
02c952b4: mov     x23, x0                                    
02c952b8: bl      #0x2c93874                                 AndroidOnFsnCompletedListener::.ctor
02c952bc: mov     x24, x19                                   
02c952c0: mov     x1, x23                                    
02c952c4: str     x23, [x24, #0x28]!                         
02c952c8: mov     x0, x24                                    
02c952cc: bl      #0x2b70d54                                 fn_2b70d54
02c952d0: ldur    x22, [x24, #-0x18]                         
02c952d4: cbz     x22, #0x2c95610                            
02c952d8: adrp    x8, #0x6263000                             
02c952dc: ldr     x8, [x8, #0xa80]                           T:type24502(k1d)
02c952e0: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c952e4: mov     w1, #3                                     
02c952e8: bl      #0x2b70ea0                                 fn_2b70ea0
02c952ec: mov     x23, x0                                    
02c952f0: cbz     x0, #0x2c954c0                             
02c952f4: cbz     x20, #0x2c9530c                            
02c952f8: ldr     x8, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c952fc: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02c95300: mov     x0, x20                                    
02c95304: bl      #0x2b70f34                                 fn_2b70f34
02c95308: cbz     x0, #0x2c954dc                             
02c9530c: ldr     w8, [x23, #0x18]                           M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0::<DOSetFloat>b__1
02c95310: cbz     w8, #0x2c954c4                             
02c95314: mov     x0, x23                                    
02c95318: str     x20, [x0, #0x20]!                          .onFsnCompletedListener
02c9531c: mov     x1, x20                                    
02c95320: bl      #0x2b70d54                                 fn_2b70d54
02c95324: ldr     x25, [x21]                                 
02c95328: cbz     x25, #0x2c95340                            
02c9532c: ldr     x8, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c95330: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02c95334: mov     x0, x25                                    
02c95338: bl      #0x2b70f34                                 fn_2b70f34
02c9533c: cbz     x0, #0x2c954e8                             
02c95340: ldr     w8, [x23, #0x18]                           M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0::<DOSetFloat>b__1
02c95344: tst     w8, #0xfffffffe                            
02c95348: b.eq    #0x2c954c8                                 
02c9534c: mov     x0, x23                                    
02c95350: str     x25, [x0, #0x28]!                          .onFsnClosedListener
02c95354: mov     x1, x25                                    
02c95358: bl      #0x2b70d54                                 fn_2b70d54
02c9535c: ldr     x24, [x24]                                 M:AdsManager::<OnApplicationPause>b__26_0
02c95360: cbz     x24, #0x2c95378                            
02c95364: ldr     x8, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c95368: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02c9536c: mov     x0, x24                                    
02c95370: bl      #0x2b70f34                                 fn_2b70f34
02c95374: cbz     x0, #0x2c954f4                             
02c95378: ldr     w8, [x23, #0x18]                           M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0::<DOSetFloat>b__1
02c9537c: cmp     w8, #2                                     
02c95380: b.ls    #0x2c954cc                                 
02c95384: mov     x0, x23                                    
02c95388: str     x24, [x0, #0x30]!                          
02c9538c: mov     x1, x24                                    
02c95390: bl      #0x2b70d54                                 fn_2b70d54
02c95394: adrp    x8, #0x6265000                             
02c95398: ldr     x8, [x8, #0x7c8]                           S:'ShowCollapAd'
02c9539c: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c953a0: mov     x0, x22                                    
02c953a4: mov     x2, x23                                    
02c953a8: mov     x3, xzr                                    
02c953ac: bl      #0x5ad5e34                                 UnityEngine.AndroidJavaObject::Call
02c953b0: b       #0x2c95610                                 
02c953b4: cbz     x21, #0x2c953d4                            
02c953b8: adrp    x8, #0x6263000                             
02c953bc: ldr     x8, [x8, #0xa90]                           S:''
02c953c0: ldr     x0, [x21, #0x40]                           
02c953c4: ldr     x2, [x21, #0x28]                           .onFsnClosedListener
02c953c8: ldr     x1, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c953cc: ldr     x8, [x21, #0x18]                           .onFsnLoadListener
02c953d0: blr     x8                                         
02c953d4: cbz     x22, #0x2c95610                            
02c953d8: adrp    x8, #0x6265000                             
02c953dc: ldr     x8, [x8, #0x7c0]                           S:'closed'
02c953e0: ldr     x0, [x22, #0x40]                           
02c953e4: ldr     x2, [x22, #0x28]                           
02c953e8: ldr     x3, [x22, #0x18]                           
02c953ec: ldp     x20, x19, [sp, #0x30]                      
02c953f0: ldp     x22, x21, [sp, #0x20]                      
02c953f4: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c953f8: ldp     x24, x23, [sp, #0x10]                      
02c953fc: ldp     x30, x25, [sp], #0x40                      
02c95400: br      x3                                         
02c95404: ldr     x19, [x19, #0x10]                          .androidCollapAd
02c95408: cbz     x19, #0x2c95610                            
02c9540c: adrp    x8, #0x6263000                             
02c95410: mov     w1, #2                                     
02c95414: ldr     x8, [x8, #0xa80]                           T:type24502(k1d)
02c95418: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c9541c: bl      #0x2b70ea0                                 fn_2b70ea0
02c95420: cbz     x0, #0x2c95624                             
02c95424: mov     x22, x0                                    
02c95428: cbz     x20, #0x2c95440                            
02c9542c: ldr     x8, [x22]                                  
02c95430: mov     x0, x20                                    
02c95434: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02c95438: bl      #0x2b70f34                                 fn_2b70f34
02c9543c: cbz     x0, #0x2c954d0                             
02c95440: ldr     w8, [x22, #0x18]                           
02c95444: cbz     w8, #0x2c954bc                             
02c95448: mov     x0, x22                                    
02c9544c: mov     x1, x20                                    
02c95450: str     x20, [x0, #0x20]!                          .onFsnCompletedListener
02c95454: bl      #0x2b70d54                                 fn_2b70d54
02c95458: ldr     x20, [x21]                                 
02c9545c: cbz     x20, #0x2c95474                            
02c95460: ldr     x8, [x22]                                  
02c95464: mov     x0, x20                                    
02c95468: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02c9546c: bl      #0x2b70f34                                 fn_2b70f34
02c95470: cbz     x0, #0x2c954d0                             
02c95474: ldr     w8, [x22, #0x18]                           
02c95478: tst     w8, #0xfffffffe                            
02c9547c: b.eq    #0x2c954bc                                 
02c95480: mov     x0, x22                                    
02c95484: mov     x1, x20                                    
02c95488: str     x20, [x0, #0x28]!                          .onFsnClosedListener
02c9548c: bl      #0x2b70d54                                 fn_2b70d54
02c95490: adrp    x8, #0x6265000                             
02c95494: ldr     x8, [x8, #0x7c8]                           S:'ShowCollapAd'
02c95498: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c9549c: mov     x0, x19                                    
02c954a0: mov     x2, x22                                    
02c954a4: mov     x3, xzr                                    
02c954a8: ldp     x20, x19, [sp, #0x30]                      
02c954ac: ldp     x22, x21, [sp, #0x20]                      
02c954b0: ldp     x24, x23, [sp, #0x10]                      
02c954b4: ldp     x30, x25, [sp], #0x40                      
02c954b8: b       #0x5ad5e34                                 UnityEngine.AndroidJavaObject::Call
02c954bc: bl      #0x2b71064                                 fn_2b71064
02c954c0: bl      #0x2b7105c                                 fn_2b7105c
02c954c4: bl      #0x2b71064                                 fn_2b71064
02c954c8: bl      #0x2b71064                                 fn_2b71064
02c954cc: bl      #0x2b71064                                 fn_2b71064
02c954d0: bl      #0x2b71080                                 fn_2b71080
02c954d4: mov     x1, xzr                                    
02c954d8: bl      #0x2b70f20                                 fn_2b70f20
02c954dc: bl      #0x2b71080                                 fn_2b71080
02c954e0: mov     x1, xzr                                    
02c954e4: bl      #0x2b70f20                                 fn_2b70f20
02c954e8: bl      #0x2b71080                                 fn_2b71080
02c954ec: mov     x1, xzr                                    
02c954f0: bl      #0x2b70f20                                 fn_2b70f20
02c954f4: bl      #0x2b71080                                 fn_2b71080
02c954f8: mov     x1, xzr                                    
02c954fc: bl      #0x2b70f20                                 fn_2b70f20
02c95500: b       #0x2c9550c                                 
02c95504: b       #0x2c9550c                                 
02c95508: b       #0x2c9550c                                 
02c9550c: mov     x22, x0                                    
02c95510: cmp     w1, #1                                     
02c95514: b.ne    #0x2c95650                                 
02c95518: mov     x0, x22                                    
02c9551c: bl      #0x5e90260                                 fn_5e90260
02c95520: mov     x22, x0                                    
02c95524: adrp    x0, #0x6263000                             
02c95528: ldr     x0, [x0, #0xae0]                           T:System.Exception
02c9552c: bl      #0x2b70dc4                                 fn_2b70dc4
02c95530: ldr     x8, [x22]                                  
02c95534: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c95538: bl      #0x2b71464                                 fn_2b71464
02c9553c: tbz     w0, #0, #0x2c95628                         
02c95540: ldr     x22, [x22]                                 
02c95544: bl      #0x5e90270                                 fn_5e90270
02c95548: cbz     x22, #0x2c95624                            
02c9554c: ldr     x8, [x22]                                  
02c95550: mov     x0, x22                                    
02c95554: ldp     x9, x1, [x8, #0x188]                       
02c95558: blr     x9                                         
02c9555c: mov     x22, x0                                    
02c95560: adrp    x0, #0x6265000                             
02c95564: ldr     x0, [x0, #0x7d0]                           S:'[FsnCollapAd] 3-param ShowCollapAd failed, falling back to 2-param: '
02c95568: bl      #0x2b70dc4                                 fn_2b70dc4
02c9556c: mov     x1, x22                                    
02c95570: mov     x2, xzr                                    
02c95574: bl      #0x4c9c514                                 System.String::Concat
02c95578: mov     x22, x0                                    
02c9557c: adrp    x0, #0x6263000                             
02c95580: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02c95584: bl      #0x2b70dc4                                 fn_2b70dc4
02c95588: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02c9558c: cbnz    w8, #0x2c95594                             
02c95590: bl      #0x2b70f30                                 fn_2b70f30
02c95594: mov     x0, x22                                    
02c95598: mov     x1, xzr                                    
02c9559c: bl      #0x5af2c94                                 UnityEngine.Debug::LogWarning
02c955a0: ldr     x19, [x19, #0x10]                          .androidCollapAd
02c955a4: cbz     x19, #0x2c95610                            
02c955a8: adrp    x0, #0x6263000                             
02c955ac: ldr     x0, [x0, #0xa80]                           T:type24502(k1d)
02c955b0: bl      #0x2b70dc4                                 fn_2b70dc4
02c955b4: mov     w1, #2                                     
02c955b8: bl      #0x2b70ea0                                 fn_2b70ea0
02c955bc: cbz     x0, #0x2c95624                             
02c955c0: mov     x1, x20                                    
02c955c4: mov     x22, x0                                    
02c955c8: bl      #0x2736dcc                                 fn_2736dcc
02c955cc: mov     x0, x22                                    
02c955d0: mov     x1, xzr                                    
02c955d4: mov     x2, x20                                    
02c955d8: bl      #0x2736bf8                                 fn_2736bf8
02c955dc: ldr     x20, [x21]                                 
02c955e0: mov     x0, x22                                    
02c955e4: mov     x1, x20                                    
02c955e8: bl      #0x2736dcc                                 fn_2736dcc
02c955ec: mov     x0, x22                                    
02c955f0: mov     w1, #1                                     
02c955f4: mov     x2, x20                                    
02c955f8: bl      #0x2736bf8                                 fn_2736bf8
02c955fc: adrp    x0, #0x6265000                             
02c95600: ldr     x0, [x0, #0x7c8]                           S:'ShowCollapAd'
02c95604: bl      #0x2b70dc4                                 fn_2b70dc4
02c95608: mov     x1, x0                                     
02c9560c: b       #0x2c9549c                                 
02c95610: ldp     x20, x19, [sp, #0x30]                      
02c95614: ldp     x22, x21, [sp, #0x20]                      
02c95618: ldp     x24, x23, [sp, #0x10]                      
02c9561c: ldp     x30, x25, [sp], #0x40                      
02c95620: ret                                                
02c95624: bl      #0x2b7105c                                 fn_2b7105c
02c95628: mov     w0, #8                                     
02c9562c: bl      #0x5e90290                                 fn_5e90290
02c95630: ldr     x8, [x22]                                  
02c95634: str     x8, [x0]                                   
02c95638: adrp    x1, #0x5e96000                             
02c9563c: add     x1, x1, #0x758                             &5e96758
02c95640: mov     x2, xzr                                    
02c95644: bl      #0x5e902a0                                 fn_5e902a0
02c95648: mov     x22, x0                                    
02c9564c: bl      #0x5e90270                                 fn_5e90270
02c95650: mov     x0, x22                                    
02c95654: bl      #0x2c6051c                                 fn_2c6051c
02c95658: bl      #0x27369b8                                 fn_27369b8
## HideAd() -> void
---- FsnCollapAd::HideAd 0x2c9565c
02c9565c: stp     x30, x21, [sp, #-0x20]!                    
02c95660: stp     x20, x19, [sp, #0x10]                      
02c95664: adrp    x20, #0x662f000                            
02c95668: adrp    x21, #0x6264000                            
02c9566c: mov     x19, x0                                    
02c95670: ldrb    w8, [x20, #0x9f3]                          
02c95674: ldr     x21, [x21, #0xa70]                         T:UnityEngine.Application
02c95678: tbnz    w8, #0, #0x2c956a8                         
02c9567c: adrp    x0, #0x6264000                             
02c95680: ldr     x0, [x0, #0xa70]                           T:UnityEngine.Application
02c95684: bl      #0x2b70db0                                 fn_2b70db0
02c95688: adrp    x0, #0x6263000                             
02c9568c: ldr     x0, [x0, #0xb70]                           MS:System.Array::Empty
02c95690: bl      #0x2b70db0                                 fn_2b70db0
02c95694: adrp    x0, #0x6265000                             
02c95698: ldr     x0, [x0, #0x758]                           S:'HideAd'
02c9569c: bl      #0x2b70db0                                 fn_2b70db0
02c956a0: mov     w8, #1                                     
02c956a4: strb    w8, [x20, #0x9f3]                          
02c956a8: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c956ac: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c956b0: cbnz    w8, #0x2c956b8                             
02c956b4: bl      #0x2b70f30                                 fn_2b70f30
02c956b8: mov     x0, xzr                                    
02c956bc: bl      #0x5aeb18c                                 UnityEngine.Application::get_platform
02c956c0: cmp     w0, #0xb                                   
02c956c4: b.ne    #0x2c95750                                 
02c956c8: ldr     x19, [x19, #0x10]                          .androidCollapAd
02c956cc: cbz     x19, #0x2c95750                            
02c956d0: adrp    x8, #0x6263000                             
02c956d4: ldr     x8, [x8, #0xb70]                           MS:System.Array::Empty
02c956d8: ldr     x20, [x8]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c956dc: ldr     x8, [x20, #0x38]                           [662f038]=6000016 f=2.40742e-35,0
02c956e0: cbnz    x8, #0x2c956f0                             
02c956e4: mov     x0, x20                                    
02c956e8: bl      #0x2ba9d7c                                 fn_2ba9d7c
02c956ec: ldr     x8, [x20, #0x38]                           [662f038]=6000016 f=2.40742e-35,0
02c956f0: ldr     x0, [x8, #0x10]                            &2c498bc(=aa1f03e0d503245f)
02c956f4: add     x8, x0, #0x135                             &6265135
02c956f8: ldrh    w8, [x8]                                   
02c956fc: tbnz    w8, #0, #0x2c95704                         
02c95700: bl      #0x2ba9d20                                 fn_2ba9d20
02c95704: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c95708: cbnz    w8, #0x2c95710                             
02c9570c: bl      #0x2b70f30                                 fn_2b70f30
02c95710: ldr     x8, [x20, #0x38]                           [662f038]=6000016 f=2.40742e-35,0
02c95714: ldr     x0, [x8, #0x10]                            &2c498bc(=aa1f03e0d503245f)
02c95718: add     x8, x0, #0x135                             &6265135
02c9571c: ldrh    w8, [x8]                                   
02c95720: tbnz    w8, #0, #0x2c95728                         
02c95724: bl      #0x2ba9d20                                 fn_2ba9d20
02c95728: adrp    x9, #0x6265000                             
02c9572c: ldr     x8, [x0, #0xb8]                            T:AdsManager/<>c__DisplayClass42_0
02c95730: mov     x0, x19                                    
02c95734: ldr     x9, [x9, #0x758]                           S:'HideAd'
02c95738: ldp     x20, x19, [sp, #0x10]                      
02c9573c: ldr     x2, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c95740: mov     x3, xzr                                    
02c95744: ldr     x1, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02c95748: ldp     x30, x21, [sp], #0x20                      
02c9574c: b       #0x5ad5e34                                 UnityEngine.AndroidJavaObject::Call
02c95750: ldp     x20, x19, [sp, #0x10]                      
02c95754: ldp     x30, x21, [sp], #0x20                      
02c95758: ret                                                
## IsAdReady() -> bool
---- FsnCollapAd::IsAdReady 0x2c9575c
02c9575c: stp     x30, x21, [sp, #-0x20]!                    
02c95760: stp     x20, x19, [sp, #0x10]                      
02c95764: adrp    x20, #0x662f000                            
02c95768: mov     x19, x0                                    
02c9576c: ldrb    w8, [x20, #0x9f4]                          
02c95770: tbnz    w8, #0, #0x2c957a0                         
02c95774: adrp    x0, #0x6265000                             
02c95778: ldr     x0, [x0, #0x760]                           MS:UnityEngine.AndroidJavaObject::Call
02c9577c: bl      #0x2b70db0                                 fn_2b70db0
02c95780: adrp    x0, #0x6263000                             
02c95784: ldr     x0, [x0, #0xb70]                           MS:System.Array::Empty
02c95788: bl      #0x2b70db0                                 fn_2b70db0
02c9578c: adrp    x0, #0x6265000                             
02c95790: ldr     x0, [x0, #0x768]                           S:'IsAdReady'
02c95794: bl      #0x2b70db0                                 fn_2b70db0
02c95798: mov     w8, #1                                     
02c9579c: strb    w8, [x20, #0x9f4]                          
02c957a0: ldr     x19, [x19, #0x10]                          .androidCollapAd
02c957a4: cbz     x19, #0x2c95830                            
02c957a8: adrp    x8, #0x6263000                             
02c957ac: ldr     x8, [x8, #0xb70]                           MS:System.Array::Empty
02c957b0: ldr     x20, [x8]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c957b4: ldr     x8, [x20, #0x38]                           [662f038]=6000016 f=2.40742e-35,0
02c957b8: cbnz    x8, #0x2c957c8                             
02c957bc: mov     x0, x20                                    
02c957c0: bl      #0x2ba9d7c                                 fn_2ba9d7c
02c957c4: ldr     x8, [x20, #0x38]                           [662f038]=6000016 f=2.40742e-35,0
02c957c8: ldr     x0, [x8, #0x10]                            &2c498bc(=aa1f03e0d503245f)
02c957cc: add     x8, x0, #0x135                             &6265135
02c957d0: ldrh    w8, [x8]                                   
02c957d4: tbnz    w8, #0, #0x2c957dc                         
02c957d8: bl      #0x2ba9d20                                 fn_2ba9d20
02c957dc: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c957e0: cbnz    w8, #0x2c957e8                             
02c957e4: bl      #0x2b70f30                                 fn_2b70f30
02c957e8: ldr     x8, [x20, #0x38]                           [662f038]=6000016 f=2.40742e-35,0
02c957ec: adrp    x20, #0x6265000                            
02c957f0: adrp    x21, #0x6265000                            
02c957f4: ldr     x0, [x8, #0x10]                            &2c498bc(=aa1f03e0d503245f)
02c957f8: ldr     x20, [x20, #0x768]                         S:'IsAdReady'
02c957fc: add     x8, x0, #0x135                             &6265135
02c95800: ldrh    w8, [x8]                                   
02c95804: ldr     x21, [x21, #0x760]                         MS:UnityEngine.AndroidJavaObject::Call
02c95808: tbnz    w8, #0, #0x2c95810                         
02c9580c: bl      #0x2ba9d20                                 fn_2ba9d20
02c95810: ldr     x8, [x0, #0xb8]                            T:AdsManager/<>c__DisplayClass42_0
02c95814: ldr     x1, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c95818: mov     x0, x19                                    
02c9581c: ldp     x20, x19, [sp, #0x10]                      
02c95820: ldr     x3, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c95824: ldr     x2, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c95828: ldp     x30, x21, [sp], #0x20                      
02c9582c: b       #0x311f6d4                                 
02c95830: ldp     x20, x19, [sp, #0x10]                      
02c95834: mov     w0, wzr                                    
02c95838: ldp     x30, x21, [sp], #0x20                      
02c9583c: ret                                                
## IsAdLoading() -> bool
---- FsnCollapAd::IsAdLoading 0x2c95840
02c95840: stp     x30, x21, [sp, #-0x20]!                    
02c95844: stp     x20, x19, [sp, #0x10]                      
02c95848: adrp    x20, #0x662f000                            
02c9584c: mov     x19, x0                                    
02c95850: ldrb    w8, [x20, #0x9f5]                          
02c95854: tbnz    w8, #0, #0x2c95884                         
02c95858: adrp    x0, #0x6265000                             
02c9585c: ldr     x0, [x0, #0x760]                           MS:UnityEngine.AndroidJavaObject::Call
02c95860: bl      #0x2b70db0                                 fn_2b70db0
02c95864: adrp    x0, #0x6263000                             
02c95868: ldr     x0, [x0, #0xb70]                           MS:System.Array::Empty
02c9586c: bl      #0x2b70db0                                 fn_2b70db0
02c95870: adrp    x0, #0x6265000                             
02c95874: ldr     x0, [x0, #0x770]                           S:'IsAdLoading'
02c95878: bl      #0x2b70db0                                 fn_2b70db0
02c9587c: mov     w8, #1                                     
02c95880: strb    w8, [x20, #0x9f5]                          
02c95884: ldr     x19, [x19, #0x10]                          .androidCollapAd
02c95888: cbz     x19, #0x2c95914                            
02c9588c: adrp    x8, #0x6263000                             
02c95890: ldr     x8, [x8, #0xb70]                           MS:System.Array::Empty
02c95894: ldr     x20, [x8]                                  &2c5bbd4(=a9bd7bfdd503233f)
02c95898: ldr     x8, [x20, #0x38]                           [662f038]=6000016 f=2.40742e-35,0
02c9589c: cbnz    x8, #0x2c958ac                             
02c958a0: mov     x0, x20                                    
02c958a4: bl      #0x2ba9d7c                                 fn_2ba9d7c
02c958a8: ldr     x8, [x20, #0x38]                           [662f038]=6000016 f=2.40742e-35,0
02c958ac: ldr     x0, [x8, #0x10]                            &2c498bc(=aa1f03e0d503245f)
02c958b0: add     x8, x0, #0x135                             &6265135
02c958b4: ldrh    w8, [x8]                                   
02c958b8: tbnz    w8, #0, #0x2c958c0                         
02c958bc: bl      #0x2ba9d20                                 fn_2ba9d20
02c958c0: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c958c4: cbnz    w8, #0x2c958cc                             
02c958c8: bl      #0x2b70f30                                 fn_2b70f30
02c958cc: ldr     x8, [x20, #0x38]                           [662f038]=6000016 f=2.40742e-35,0
02c958d0: adrp    x20, #0x6265000                            
02c958d4: adrp    x21, #0x6265000                            
02c958d8: ldr     x0, [x8, #0x10]                            &2c498bc(=aa1f03e0d503245f)
02c958dc: ldr     x20, [x20, #0x770]                         S:'IsAdLoading'
02c958e0: add     x8, x0, #0x135                             &6265135
02c958e4: ldrh    w8, [x8]                                   
02c958e8: ldr     x21, [x21, #0x760]                         MS:UnityEngine.AndroidJavaObject::Call
02c958ec: tbnz    w8, #0, #0x2c958f4                         
02c958f0: bl      #0x2ba9d20                                 fn_2ba9d20
02c958f4: ldr     x8, [x0, #0xb8]                            T:AdsManager/<>c__DisplayClass42_0
02c958f8: ldr     x1, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c958fc: mov     x0, x19                                    
02c95900: ldp     x20, x19, [sp, #0x10]                      
02c95904: ldr     x3, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c95908: ldr     x2, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02c9590c: ldp     x30, x21, [sp], #0x20                      
02c95910: b       #0x311f6d4                                 
02c95914: ldp     x20, x19, [sp, #0x10]                      
02c95918: mov     w0, wzr                                    
02c9591c: ldp     x30, x21, [sp], #0x20                      
02c95920: ret                                                
## Release() -> void
---- FsnCollapAd::Release 0x2c95924
02c95924: stp     x30, x21, [sp, #-0x20]!                    
02c95928: stp     x20, x19, [sp, #0x10]                      
02c9592c: adrp    x20, #0x662f000                            
02c95930: adrp    x21, #0x6264000                            
02c95934: mov     x19, x0                                    
02c95938: ldrb    w8, [x20, #0x9f6]                          
02c9593c: ldr     x21, [x21, #0xa70]                         T:UnityEngine.Application
02c95940: tbnz    w8, #0, #0x2c95958                         
02c95944: adrp    x0, #0x6264000                             
02c95948: ldr     x0, [x0, #0xa70]                           T:UnityEngine.Application
02c9594c: bl      #0x2b70db0                                 fn_2b70db0
02c95950: mov     w8, #1                                     
02c95954: strb    w8, [x20, #0x9f6]                          
02c95958: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c9595c: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c95960: cbnz    w8, #0x2c95968                             
02c95964: bl      #0x2b70f30                                 fn_2b70f30
02c95968: mov     x0, xzr                                    
02c9596c: bl      #0x5aeb18c                                 UnityEngine.Application::get_platform
02c95970: cmp     w0, #0xb                                   
02c95974: b.ne    #0x2c959a0                                 
02c95978: ldr     x0, [x19, #0x10]!                          .androidCollapAd
02c9597c: cbz     x0, #0x2c95988                             
02c95980: mov     x1, xzr                                    
02c95984: bl      #0x5ad5140                                 UnityEngine.AndroidJavaObject::Dispose
02c95988: mov     x0, x19                                    
02c9598c: str     xzr, [x19]                                 
02c95990: mov     x1, xzr                                    
02c95994: ldp     x20, x19, [sp, #0x10]                      
02c95998: ldp     x30, x21, [sp], #0x20                      
02c9599c: b       #0x2b70d54                                 
02c959a0: ldp     x20, x19, [sp, #0x10]                      
02c959a4: ldp     x30, x21, [sp], #0x20                      
02c959a8: ret                                                
