#### CLASS DailyMission.IQuest parent= None
##  IsCorrect (no body)
