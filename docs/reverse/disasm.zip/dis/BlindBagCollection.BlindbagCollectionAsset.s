#### CLASS BlindBagCollection.BlindbagCollectionAsset/<>c__DisplayClass10_0 parent= object
#   field boxsetType                     BlindBagCollection.CollectionBoxsetType            off=0x10 attr=6 
#   field itemType                       BlindBagCollection.CollectionItemType              off=0x14 attr=6 
## .ctor() -> void
---- BlindBagCollection.BlindbagCollectionAsset/<>c__DisplayClass10_0::.ctor 0x2d3bd78
02d3bd78: mov     x1, xzr                                    
02d3bd7c: b       #0x4e53e9c                                 System.Object::.ctor
## <GetItemSprite>b__0(BlindBagCollection.CollectionBoxset b) -> bool
---- BlindBagCollection.BlindbagCollectionAsset/<>c__DisplayClass10_0::<GetItemSprite>b__0 0x2d3bdb4
02d3bdb4: ldr     w8, [x1]                                   
02d3bdb8: ldr     w9, [x0, #0x10]                            .boxsetType
02d3bdbc: cmp     w8, w9                                     
02d3bdc0: cset    w0, eq                                     
02d3bdc4: ret                                                
## <GetItemSprite>b__1(BlindBagCollection.CollectionItem c) -> bool
---- BlindBagCollection.BlindbagCollectionAsset/<>c__DisplayClass10_0::<GetItemSprite>b__1 0x2d3bdc8
02d3bdc8: ldr     w8, [x1]                                   
02d3bdcc: ldr     w9, [x0, #0x14]                            .itemType
02d3bdd0: cmp     w8, w9                                     
02d3bdd4: cset    w0, eq                                     
02d3bdd8: ret                                                
#### CLASS BlindBagCollection.BlindbagCollectionAsset/<>c__DisplayClass11_0 parent= object
#   field boxsetType                     BlindBagCollection.CollectionBoxsetType            off=0x10 attr=6 
#   field itemType                       BlindBagCollection.CollectionItemType              off=0x14 attr=6 
## .ctor() -> void
---- BlindBagCollection.BlindbagCollectionAsset/<>c__DisplayClass11_0::.ctor 0x2d3bd80
02d3bd80: mov     x1, xzr                                    
02d3bd84: b       #0x4e53e9c                                 System.Object::.ctor
## <GetItemID>b__0(BlindBagCollection.CollectionBoxset b) -> bool
---- BlindBagCollection.BlindbagCollectionAsset/<>c__DisplayClass11_0::<GetItemID>b__0 0x2d3bddc
02d3bddc: ldr     w8, [x1]                                   
02d3bde0: ldr     w9, [x0, #0x10]                            .boxsetType
02d3bde4: cmp     w8, w9                                     
02d3bde8: cset    w0, eq                                     
02d3bdec: ret                                                
## <GetItemID>b__1(BlindBagCollection.CollectionItem c) -> bool
---- BlindBagCollection.BlindbagCollectionAsset/<>c__DisplayClass11_0::<GetItemID>b__1 0x2d3bdf0
02d3bdf0: ldr     w8, [x1]                                   
02d3bdf4: ldr     w9, [x0, #0x14]                            .itemType
02d3bdf8: cmp     w8, w9                                     
02d3bdfc: cset    w0, eq                                     
02d3be00: ret                                                
#### CLASS BlindBagCollection.BlindbagCollectionAsset/<>c__DisplayClass12_0 parent= object
#   field boxsetType                     BlindBagCollection.CollectionBoxsetType            off=0x10 attr=6 
#   field itemType                       BlindBagCollection.CollectionItemType              off=0x14 attr=6 
## .ctor() -> void
---- BlindBagCollection.BlindbagCollectionAsset/<>c__DisplayClass12_0::.ctor 0x2d3bd88
02d3bd88: mov     x1, xzr                                    
02d3bd8c: b       #0x4e53e9c                                 System.Object::.ctor
## <GetRarity>b__0(BlindBagCollection.CollectionBoxset b) -> bool
---- BlindBagCollection.BlindbagCollectionAsset/<>c__DisplayClass12_0::<GetRarity>b__0 0x2d3be04
02d3be04: ldr     w8, [x1]                                   
02d3be08: ldr     w9, [x0, #0x10]                            .boxsetType
02d3be0c: cmp     w8, w9                                     
02d3be10: cset    w0, eq                                     
02d3be14: ret                                                
## <GetRarity>b__1(BlindBagCollection.CollectionItem c) -> bool
---- BlindBagCollection.BlindbagCollectionAsset/<>c__DisplayClass12_0::<GetRarity>b__1 0x2d3be18
02d3be18: ldr     w8, [x1]                                   
02d3be1c: ldr     w9, [x0, #0x14]                            .itemType
02d3be20: cmp     w8, w9                                     
02d3be24: cset    w0, eq                                     
02d3be28: ret                                                
#### CLASS BlindBagCollection.BlindbagCollectionAsset/<>c__DisplayClass12_1 parent= object
#   field decorItem                      BlindBagCollection.CollectionItem                  off=0x10 attr=6 
## .ctor() -> void
---- BlindBagCollection.BlindbagCollectionAsset/<>c__DisplayClass12_1::.ctor 0x2d3bd90
02d3bd90: mov     x1, xzr                                    
02d3bd94: b       #0x4e53e9c                                 System.Object::.ctor
## <GetRarity>b__2(Clicker.DecorKeycapItemData data) -> bool
---- BlindBagCollection.BlindbagCollectionAsset/<>c__DisplayClass12_1::<GetRarity>b__2 0x2d3be2c
02d3be2c: cbz     x1, #0x2d3be44                             
02d3be30: ldr     w8, [x1, #0x10]                            
02d3be34: ldr     w9, [x0, #0x20]                            
02d3be38: cmp     w8, w9                                     
02d3be3c: cset    w0, eq                                     
02d3be40: ret                                                
02d3be44: str     x30, [sp, #-0x10]!                         
02d3be48: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS BlindBagCollection.BlindbagCollectionAsset parent= GameAsset
#   field FullKeycapPrice                UnityEngine.Vector2Int                             off=0x18 attr=6 HeaderAttribute
#   field DecorItemPrice                 UnityEngine.Vector2Int                             off=0x20 attr=6 
#   field LuckBagChance                  int                                                off=0x28 attr=6 RangeAttribute
#   field CollectionBoxsets              System.Collections.Generic.List`1<BlindBagCollection.CollectionBoxset> off=0x30 attr=6 SpaceAttribute,HeaderAttribute
#   field CurrentProbabilities           System.Collections.Generic.List`1<int>             off=0x38 attr=6 
#   field BaseProbabilities              System.Collections.Generic.List`1<int>             off=0x40 attr=6 ReadOnlyAttribute
#   field _baseKeycapConfig              Clicker.BaseKeycapConfig                           off=0x48 attr=1 SerializeField
#   field _decorKeycapConfig             Clicker.DecorKeycapConfig                          off=0x50 attr=1 SerializeField
## GetRandomCollectionItemType() -> BlindBagCollection.CollectionItemType
---- BlindBagCollection.BlindbagCollectionAsset::GetRandomCollectionItemType 0x2d342ac
02d342ac: sub     sp, sp, #0xb0                              
02d342b0: stp     d15, d14, [sp, #0x10]                      
02d342b4: stp     d13, d12, [sp, #0x20]                      
02d342b8: stp     d11, d10, [sp, #0x30]                      
02d342bc: stp     d9, d8, [sp, #0x40]                        
02d342c0: stp     x29, x30, [sp, #0x50]                      
02d342c4: stp     x28, x27, [sp, #0x60]                      
02d342c8: stp     x26, x25, [sp, #0x70]                      
02d342cc: stp     x24, x23, [sp, #0x80]                      
02d342d0: stp     x22, x21, [sp, #0x90]                      
02d342d4: stp     x20, x19, [sp, #0xa0]                      
02d342d8: adrp    x20, #0x6630000                            
02d342dc: mov     x19, x0                                    
02d342e0: ldrb    w8, [x20, #0x158]                          
02d342e4: tbnz    w8, #0, #0x2d3432c                         
02d342e8: adrp    x0, #0x626a000                             
02d342ec: ldr     x0, [x0, #0x8f8]                           T:BlindBagCollection.CollectionItemType
02d342f0: bl      #0x2b70db0                                 fn_2b70db0
02d342f4: adrp    x0, #0x6268000                             
02d342f8: ldr     x0, [x0, #0xea8]                           MS:System.Collections.Generic.List`1::get_Count
02d342fc: bl      #0x2b70db0                                 fn_2b70db0
02d34300: adrp    x0, #0x626a000                             
02d34304: ldr     x0, [x0, #0x310]                           MS:System.Collections.Generic.List`1::get_Item
02d34308: bl      #0x2b70db0                                 fn_2b70db0
02d3430c: adrp    x0, #0x626a000                             
02d34310: ldr     x0, [x0, #0x350]                           MS:System.Collections.Generic.List`1::set_Item
02d34314: bl      #0x2b70db0                                 fn_2b70db0
02d34318: adrp    x0, #0x6265000                             
02d3431c: ldr     x0, [x0, #0xb48]                           T:System.Math
02d34320: bl      #0x2b70db0                                 fn_2b70db0
02d34324: mov     w8, #1                                     
02d34328: strb    w8, [x20, #0x158]                          
02d3432c: ldr     x8, [x19, #0x38]                           .CurrentProbabilities
02d34330: cbz     x8, #0x2d34338                             
02d34334: ldr     w8, [x8, #0x18]                            
02d34338: ldr     x9, [x19, #0x40]                           .BaseProbabilities
02d3433c: cbz     x9, #0x2d34344                             
02d34340: ldr     w9, [x9, #0x18]                            
02d34344: cmp     w8, w9                                     
02d34348: csel    w26, w8, w9, lt                            
02d3434c: cbz     w26, #0x2d34478                            
02d34350: cmp     w26, #1                                    
02d34354: b.lt    #0x2d34478                                 
02d34358: adrp    x27, #0x626a000                            
02d3435c: mov     w20, wzr                                   
02d34360: mov     w21, wzr                                   
02d34364: ldr     x27, [x27, #0x310]                         MS:System.Collections.Generic.List`1::get_Item
02d34368: ldr     x0, [x19, #0x38]                           .CurrentProbabilities
02d3436c: cbz     x0, #0x2d3484c                             
02d34370: ldr     x2, [x27]                                  T:type56879(k15)
02d34374: mov     w1, w21                                    
02d34378: bl      #0x3569920                                 fn_3569920
02d3437c: bic     w8, w0, w0, asr #31                        
02d34380: add     w21, w21, #1                               
02d34384: cmp     w26, w21                                   
02d34388: add     w20, w8, w20                               
02d3438c: b.ne    #0x2d34368                                 
02d34390: cmp     w20, #1                                    
02d34394: b.lt    #0x2d34478                                 
02d34398: mov     w0, wzr                                    
02d3439c: mov     w1, w20                                    
02d343a0: mov     x2, xzr                                    
02d343a4: bl      #0x5b2e000                                 UnityEngine.Random::Range
02d343a8: cmp     w26, #1                                    
02d343ac: b.lt    #0x2d343e4                                 
02d343b0: mov     w21, w0                                    
02d343b4: mov     w20, wzr                                   
02d343b8: ldr     x0, [x19, #0x38]                           .CurrentProbabilities
02d343bc: cbz     x0, #0x2d3484c                             
02d343c0: ldr     x2, [x27]                                  T:type56879(k15)
02d343c4: mov     w1, w20                                    
02d343c8: bl      #0x3569920                                 fn_3569920
02d343cc: bic     w8, w0, w0, asr #31                        
02d343d0: subs    w21, w21, w8                               
02d343d4: b.lt    #0x2d343e8                                 
02d343d8: add     w20, w20, #1                               
02d343dc: cmp     w26, w20                                   
02d343e0: b.ne    #0x2d343b8                                 
02d343e4: mov     w20, wzr                                   
02d343e8: ldr     x0, [x19, #0x40]                           .BaseProbabilities
02d343ec: cbz     x0, #0x2d3484c                             
02d343f0: ldr     x2, [x27]                                  T:type56879(k15)
02d343f4: mov     w1, w20                                    
02d343f8: bl      #0x3569920                                 fn_3569920
02d343fc: scvtf   s8, w0                                     
02d34400: adrp    x9, #0x662f000                             
02d34404: adrp    x8, #0x1084000                             
02d34408: ldrb    w9, [x9, #0xa8a]                           
02d3440c: ldr     s9, [x8, #0xeec]                           [1084eec]=457ff0003dcccccd f=0.1,4095
02d34410: cbnz    w9, #0x2d3442c                             
02d34414: adrp    x0, #0x6265000                             
02d34418: ldr     x0, [x0, #0xb48]                           T:System.Math
02d3441c: bl      #0x2b70db0                                 fn_2b70db0
02d34420: mov     w8, #1                                     
02d34424: adrp    x9, #0x662f000                             
02d34428: strb    w8, [x9, #0xa8a]                           
02d3442c: adrp    x8, #0x6265000                             
02d34430: fmul    s9, s8, s9                                 
02d34434: ldr     x8, [x8, #0xb48]                           T:System.Math
02d34438: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02d3443c: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02d34440: cbnz    w8, #0x2d34448                             
02d34444: bl      #0x2b70f30                                 fn_2b70f30
02d34448: fcvt    d8, s9                                     
02d3444c: add     x0, sp, #8                                 
02d34450: fmov    d0, d8                                     
02d34454: bl      #0x5e902c0                                 fn_5e902c0
02d34458: fcmp    s9, #0.0                                   
02d3445c: b.ge    #0x2d344ac                                 
02d34460: fmov    d1, #-0.50000000                           
02d34464: fcmp    d0, d1                                     
02d34468: b.ne    #0x2d344d4                                 
02d3446c: ldr     d0, [sp, #8]                               
02d34470: fmov    d1, #-1.00000000                           
02d34474: b       #0x2d344c0                                 
02d34478: mov     w0, wzr                                    
02d3447c: ldp     x20, x19, [sp, #0xa0]                      
02d34480: ldp     x22, x21, [sp, #0x90]                      
02d34484: ldp     x24, x23, [sp, #0x80]                      
02d34488: ldp     x26, x25, [sp, #0x70]                      
02d3448c: ldp     x28, x27, [sp, #0x60]                      
02d34490: ldp     x29, x30, [sp, #0x50]                      
02d34494: ldp     d9, d8, [sp, #0x40]                        
02d34498: ldp     d11, d10, [sp, #0x30]                      
02d3449c: ldp     d13, d12, [sp, #0x20]                      
02d344a0: ldp     d15, d14, [sp, #0x10]                      
02d344a4: add     sp, sp, #0xb0                              
02d344a8: ret                                                
02d344ac: fmov    d1, #0.50000000                            
02d344b0: fcmp    d0, d1                                     
02d344b4: b.ne    #0x2d344e0                                 
02d344b8: fmov    d1, #1.00000000                            
02d344bc: ldr     d0, [sp, #8]                               
02d344c0: fcvtzs  x8, d0                                     
02d344c4: fadd    d1, d0, d1                                 
02d344c8: tst     x8, #1                                     
02d344cc: fcsel   d8, d0, d1, eq                             
02d344d0: b       #0x2d344e8                                 
02d344d4: fadd    d0, d8, d1                                 
02d344d8: frintp  d8, d0                                     
02d344dc: b       #0x2d344e8                                 
02d344e0: fadd    d0, d8, d1                                 
02d344e4: frintm  d8, d0                                     
02d344e8: ldr     x0, [x19, #0x40]                           .BaseProbabilities
02d344ec: cbz     x0, #0x2d3484c                             
02d344f0: ldr     x2, [x27]                                  T:type56879(k15)
02d344f4: mov     w1, w20                                    
02d344f8: bl      #0x3569920                                 fn_3569920
02d344fc: ldr     x8, [x19, #0x38]                           .CurrentProbabilities
02d34500: cbz     x8, #0x2d3484c                             
02d34504: mov     x9, #0x7ff0000000000000                    
02d34508: fcvtzs  w10, d8                                    
02d3450c: ldr     x2, [x27]                                  T:type56879(k15)
02d34510: fmov    d0, x9                                     
02d34514: mov     w9, #-0xffffffff80000000                   
02d34518: mov     w1, w20                                    
02d3451c: fcmp    d8, d0                                     
02d34520: csel    w9, w9, w10, eq                            
02d34524: cmp     w9, #1                                     
02d34528: csinc   w10, w9, wzr, gt                           
02d3452c: cmp     w0, #1                                     
02d34530: mov     x0, x8                                     
02d34534: csel    w21, w9, w10, lt                           
02d34538: bl      #0x3569920                                 fn_3569920
02d3453c: ldr     x22, [x19, #0x38]                          .CurrentProbabilities
02d34540: cmp     w21, w0                                    
02d34544: csel    w25, w21, w0, lt                           
02d34548: cbz     x22, #0x2d3484c                            
02d3454c: ldr     x2, [x27]                                  T:type56879(k15)
02d34550: mov     x0, x22                                    
02d34554: mov     w1, w20                                    
02d34558: bl      #0x3569920                                 fn_3569920
02d3455c: adrp    x28, #0x626a000                            
02d34560: sub     w2, w0, w25                                
02d34564: mov     x0, x22                                    
02d34568: ldr     x28, [x28, #0x350]                         MS:System.Collections.Generic.List`1::set_Item
02d3456c: mov     w1, w20                                    
02d34570: ldr     x3, [x28]                                  T:type56879(k15)
02d34574: bl      #0x3569974                                 fn_3569974
02d34578: cmp     w25, #1                                    
02d3457c: ccmp    w26, #1, #8, ge                            
02d34580: b.ge    #0x2d345c8                                 
02d34584: cmp     w20, #1                                    
02d34588: b.ne    #0x2d347e0                                 
02d3458c: ldp     x20, x19, [sp, #0xa0]                      
02d34590: mov     w0, #1                                     
02d34594: ldp     x22, x21, [sp, #0x90]                      
02d34598: mov     w1, #6                                     
02d3459c: ldp     x24, x23, [sp, #0x80]                      
02d345a0: mov     x2, xzr                                    
02d345a4: ldp     x26, x25, [sp, #0x70]                      
02d345a8: ldp     x28, x27, [sp, #0x60]                      
02d345ac: ldp     x29, x30, [sp, #0x50]                      
02d345b0: ldp     d9, d8, [sp, #0x40]                        
02d345b4: ldp     d11, d10, [sp, #0x30]                      
02d345b8: ldp     d13, d12, [sp, #0x20]                      
02d345bc: ldp     d15, d14, [sp, #0x10]                      
02d345c0: add     sp, sp, #0xb0                              
02d345c4: b       #0x5b2e000                                 UnityEngine.Random::Range
02d345c8: mov     w21, wzr                                   
02d345cc: mov     w22, wzr                                   
02d345d0: cmp     w20, w22                                   
02d345d4: b.eq    #0x2d345f4                                 
02d345d8: ldr     x0, [x19, #0x40]                           .BaseProbabilities
02d345dc: cbz     x0, #0x2d3484c                             
02d345e0: ldr     x2, [x27]                                  T:type56879(k15)
02d345e4: mov     w1, w22                                    
02d345e8: bl      #0x3569920                                 fn_3569920
02d345ec: bic     w8, w0, w0, asr #31                        
02d345f0: add     w21, w8, w21                               
02d345f4: add     w22, w22, #1                               
02d345f8: cmp     w26, w22                                   
02d345fc: b.ne    #0x2d345d0                                 
02d34600: cmp     w21, #1                                    
02d34604: b.lt    #0x2d34584                                 
02d34608: cmp     w26, #1                                    
02d3460c: b.lt    #0x2d34584                                 
02d34610: scvtf   s9, w21                                    
02d34614: scvtf   s10, w25                                   
02d34618: mov     w29, wzr                                   
02d3461c: fmov    d11, #-0.50000000                          
02d34620: fmov    d12, #-1.00000000                          
02d34624: mov     w22, wzr                                   
02d34628: fmov    d13, #0.50000000                           
02d3462c: fmov    d14, #1.00000000                           
02d34630: mov     x24, #0x7ff0000000000000                   
02d34634: cmp     w20, w22                                   
02d34638: b.eq    #0x2d34744                                 
02d3463c: ldr     x0, [x19, #0x40]                           .BaseProbabilities
02d34640: cbz     x0, #0x2d3484c                             
02d34644: ldr     x2, [x27]                                  T:type56879(k15)
02d34648: mov     w1, w22                                    
02d3464c: bl      #0x3569920                                 fn_3569920
02d34650: adrp    x8, #0x662f000                             
02d34654: mov     w23, w0                                    
02d34658: ldrb    w8, [x8, #0xa8a]                           
02d3465c: cbnz    w8, #0x2d34678                             
02d34660: adrp    x0, #0x6265000                             
02d34664: ldr     x0, [x0, #0xb48]                           T:System.Math
02d34668: bl      #0x2b70db0                                 fn_2b70db0
02d3466c: adrp    x8, #0x662f000                             
02d34670: mov     w9, #1                                     
02d34674: strb    w9, [x8, #0xa8a]                           
02d34678: adrp    x8, #0x6265000                             
02d3467c: ldr     x8, [x8, #0xb48]                           T:System.Math
02d34680: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02d34684: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02d34688: cbnz    w8, #0x2d34690                             
02d3468c: bl      #0x2b70f30                                 fn_2b70f30
02d34690: scvtf   s0, w23                                    
02d34694: add     x0, sp, #8                                 
02d34698: fdiv    s0, s0, s9                                 
02d3469c: fmul    s15, s0, s10                               
02d346a0: fcvt    d8, s15                                    
02d346a4: fmov    d0, d8                                     
02d346a8: bl      #0x5e902c0                                 fn_5e902c0
02d346ac: fcmp    s15, #0.0                                  
02d346b0: b.ge    #0x2d346cc                                 
02d346b4: fcmp    d0, d11                                    
02d346b8: b.ne    #0x2d346ec                                 
02d346bc: ldr     d0, [sp, #8]                               
02d346c0: fcvtzs  x8, d0                                     
02d346c4: fadd    d1, d0, d12                                
02d346c8: b       #0x2d346e0                                 
02d346cc: fcmp    d0, d13                                    
02d346d0: b.ne    #0x2d346f8                                 
02d346d4: ldr     d0, [sp, #8]                               
02d346d8: fcvtzs  x8, d0                                     
02d346dc: fadd    d1, d0, d14                                
02d346e0: tst     x8, #1                                     
02d346e4: fcsel   d0, d0, d1, eq                             
02d346e8: b       #0x2d34700                                 
02d346ec: fadd    d0, d8, d11                                
02d346f0: frintp  d0, d0                                     
02d346f4: b       #0x2d34700                                 
02d346f8: fadd    d0, d8, d13                                
02d346fc: frintm  d0, d0                                     
02d34700: ldr     x23, [x19, #0x38]                          .CurrentProbabilities
02d34704: cbz     x23, #0x2d3484c                            
02d34708: fmov    d1, x24                                    
02d3470c: fcvtzs  w8, d0                                     
02d34710: ldr     x2, [x27]                                  T:type56879(k15)
02d34714: mov     w9, #-0xffffffff80000000                   
02d34718: mov     x0, x23                                    
02d3471c: mov     w1, w22                                    
02d34720: fcmp    d0, d1                                     
02d34724: csel    w21, w9, w8, eq                            
02d34728: bl      #0x3569920                                 fn_3569920
02d3472c: ldr     x3, [x28]                                  T:type56879(k15)
02d34730: add     w2, w0, w21                                
02d34734: mov     x0, x23                                    
02d34738: mov     w1, w22                                    
02d3473c: bl      #0x3569974                                 fn_3569974
02d34740: add     w29, w21, w29                              
02d34744: add     w22, w22, #1                               
02d34748: cmp     w26, w22                                   
02d3474c: b.ne    #0x2d34634                                 
02d34750: subs    w22, w25, w29                              
02d34754: b.eq    #0x2d34584                                 
02d34758: mov     w23, wzr                                   
02d3475c: cmp     w20, w23                                   
02d34760: b.eq    #0x2d347cc                                 
02d34764: ldr     x24, [x19, #0x38]                          .CurrentProbabilities
02d34768: cbz     x24, #0x2d3484c                            
02d3476c: ldr     x2, [x27]                                  T:type56879(k15)
02d34770: mov     x0, x24                                    
02d34774: mov     w1, w23                                    
02d34778: bl      #0x3569920                                 fn_3569920
02d3477c: adrp    x8, #0x6265000                             
02d34780: mov     w25, w0                                    
02d34784: ldr     x8, [x8, #0xb48]                           T:System.Math
02d34788: ldr     x8, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02d3478c: ldr     w9, [x8, #0xe4]                            [62650e4]=0 f=0,0
02d34790: cbnz    w9, #0x2d3479c                             
02d34794: mov     x0, x8                                     
02d34798: bl      #0x2b70f30                                 fn_2b70f30
02d3479c: mov     w0, w22                                    
02d347a0: mov     x1, xzr                                    
02d347a4: bl      #0x4e12a30                                 System.Math::Sign
02d347a8: ldr     x3, [x28]                                  T:type56879(k15)
02d347ac: add     w2, w0, w25                                
02d347b0: mov     x0, x24                                    
02d347b4: mov     w1, w23                                    
02d347b8: bl      #0x3569974                                 fn_3569974
02d347bc: mov     w0, w22                                    
02d347c0: mov     x1, xzr                                    
02d347c4: bl      #0x4e12a30                                 System.Math::Sign
02d347c8: sub     w22, w22, w0                               
02d347cc: add     w23, w23, #1                               
02d347d0: cmp     w23, w26                                   
02d347d4: b.ge    #0x2d34584                                 
02d347d8: cbnz    w22, #0x2d3475c                            
02d347dc: b       #0x2d34584                                 
02d347e0: adrp    x21, #0x6263000                            
02d347e4: adrp    x8, #0x626a000                             
02d347e8: ldr     x21, [x21, #0x970]                         &6645c70(=0)
02d347ec: ldr     x0, [x21, #0xe0]                           &2c5bf4c(=a9be7bfdd503233f)
02d347f0: ldr     x8, [x8, #0x8f8]                           T:BlindBagCollection.CollectionItemType
02d347f4: ldr     w9, [x0, #0xe4]                            [62650e4]=0 f=0,0
02d347f8: ldr     x19, [x8]                                  T:type56879(k15)
02d347fc: cbnz    w9, #0x2d34804                             
02d34800: bl      #0x2b70f30                                 fn_2b70f30
02d34804: mov     x0, x19                                    
02d34808: mov     x1, xzr                                    
02d3480c: bl      #0x4e20e5c                                 System.Type::GetTypeFromHandle
02d34810: ldr     x8, [x21, #0x98]                           [6263098]=0 f=0,0
02d34814: mov     x19, x0                                    
02d34818: ldr     w9, [x8, #0xe4]                            [626a0e4]=0 f=0,0
02d3481c: cbnz    w9, #0x2d34828                             
02d34820: mov     x0, x8                                     
02d34824: bl      #0x2b70f30                                 fn_2b70f30
02d34828: mov     x0, x19                                    
02d3482c: mov     x1, xzr                                    
02d34830: bl      #0x4e4676c                                 System.Enum::GetValues
02d34834: cbz     x0, #0x2d3484c                             
02d34838: mov     x1, xzr                                    
02d3483c: bl      #0x4e2ad14                                 System.Array::get_Length
02d34840: cmp     w20, w0                                    
02d34844: csel    w0, w20, wzr, lt                           
02d34848: b       #0x2d3447c                                 
02d3484c: bl      #0x2b7105c                                 fn_2b7105c
## GetRandomCollectionBoxsetType() -> BlindBagCollection.CollectionBoxsetType
---- BlindBagCollection.BlindbagCollectionAsset::GetRandomCollectionBoxsetType 0x2d34850
02d34850: sub     sp, sp, #0x50                              
02d34854: str     x30, [sp, #0x30]                           
02d34858: stp     x20, x19, [sp, #0x40]                      
02d3485c: adrp    x20, #0x6630000                            
02d34860: mov     x19, x0                                    
02d34864: ldrb    w8, [x20, #0x159]                          
02d34868: tbnz    w8, #0, #0x2d3488c                         
02d3486c: adrp    x0, #0x626a000                             
02d34870: ldr     x0, [x0, #0x900]                           MS:System.Collections.Generic.List`1::get_Count
02d34874: bl      #0x2b70db0                                 fn_2b70db0
02d34878: adrp    x0, #0x626a000                             
02d3487c: ldr     x0, [x0, #0x908]                           MS:System.Collections.Generic.List`1::get_Item
02d34880: bl      #0x2b70db0                                 fn_2b70db0
02d34884: mov     w8, #1                                     
02d34888: strb    w8, [x20, #0x159]                          
02d3488c: ldr     x8, [x19, #0x30]                           .CollectionBoxsets
02d34890: cbz     x8, #0x2d348dc                             
02d34894: ldr     w1, [x8, #0x18]                            
02d34898: mov     w0, wzr                                    
02d3489c: mov     x2, xzr                                    
02d348a0: bl      #0x5b2e000                                 UnityEngine.Random::Range
02d348a4: ldr     x9, [x19, #0x30]                           .CollectionBoxsets
02d348a8: cbz     x9, #0x2d348dc                             
02d348ac: adrp    x8, #0x626a000                             
02d348b0: mov     w1, w0                                     
02d348b4: mov     x0, x9                                     
02d348b8: ldr     x8, [x8, #0x908]                           MS:System.Collections.Generic.List`1::get_Item
02d348bc: ldr     x2, [x8]                                   T:type56879(k15)
02d348c0: add     x8, sp, #8                                 
02d348c4: bl      #0x4bbf25c                                 fn_4bbf25c
02d348c8: ldp     x20, x19, [sp, #0x40]                      
02d348cc: ldr     w0, [sp, #8]                               
02d348d0: ldr     x30, [sp, #0x30]                           
02d348d4: add     sp, sp, #0x50                              
02d348d8: ret                                                
02d348dc: bl      #0x2b7105c                                 fn_2b7105c
## GetItemSprite(BlindBagCollection.CollectionItemType itemType, BlindBagCollection.CollectionBoxsetType boxsetType) -> UnityEngine.Sprite
---- BlindBagCollection.BlindbagCollectionAsset::GetItemSprite 0x2d348e0
02d348e0: sub     sp, sp, #0x60                              
02d348e4: stp     x30, x23, [sp, #0x30]                      
02d348e8: stp     x22, x21, [sp, #0x40]                      
02d348ec: stp     x20, x19, [sp, #0x50]                      
02d348f0: adrp    x19, #0x6630000                            
02d348f4: adrp    x23, #0x626a000                            
02d348f8: mov     w21, w2                                    
02d348fc: ldrb    w8, [x19, #0x15a]                          
02d34900: ldr     x23, [x23, #0x910]                         T:BlindBagCollection.BlindbagCollectionAsset/<>c__DisplayClass10_0
02d34904: mov     w20, w1                                    
02d34908: mov     x22, x0                                    
02d3490c: tbnz    w8, #0, #0x2d349a8                         
02d34910: adrp    x0, #0x626a000                             
02d34914: ldr     x0, [x0, #0x918]                           T:BlindBagCollection.CollectionBoxsetType
02d34918: bl      #0x2b70db0                                 fn_2b70db0
02d3491c: adrp    x0, #0x626a000                             
02d34920: ldr     x0, [x0, #0x920]                           T:BlindBagCollection.CollectionItemType
02d34924: bl      #0x2b70db0                                 fn_2b70db0
02d34928: adrp    x0, #0x6263000                             
02d3492c: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02d34930: bl      #0x2b70db0                                 fn_2b70db0
02d34934: adrp    x0, #0x626a000                             
02d34938: ldr     x0, [x0, #0x928]                           MS:System.Collections.Generic.List`1::Find
02d3493c: bl      #0x2b70db0                                 fn_2b70db0
02d34940: adrp    x0, #0x626a000                             
02d34944: ldr     x0, [x0, #0x930]                           MS:System.Collections.Generic.List`1::Find
02d34948: bl      #0x2b70db0                                 fn_2b70db0
02d3494c: adrp    x0, #0x626a000                             
02d34950: ldr     x0, [x0, #0x938]                           T:type57235(k15)
02d34954: bl      #0x2b70db0                                 fn_2b70db0
02d34958: adrp    x0, #0x626a000                             
02d3495c: ldr     x0, [x0, #0x940]                           T:type57234(k15)
02d34960: bl      #0x2b70db0                                 fn_2b70db0
02d34964: adrp    x0, #0x626a000                             
02d34968: ldr     x0, [x0, #0x948]                           M:BlindBagCollection.BlindbagCollectionAsset/<>c__DisplayClass10_0::<GetItemSprite>b__0
02d3496c: bl      #0x2b70db0                                 fn_2b70db0
02d34970: adrp    x0, #0x626a000                             
02d34974: ldr     x0, [x0, #0x950]                           M:BlindBagCollection.BlindbagCollectionAsset/<>c__DisplayClass10_0::<GetItemSprite>b__1
02d34978: bl      #0x2b70db0                                 fn_2b70db0
02d3497c: adrp    x0, #0x626a000                             
02d34980: ldr     x0, [x0, #0x910]                           T:BlindBagCollection.BlindbagCollectionAsset/<>c__DisplayClass10_0
02d34984: bl      #0x2b70db0                                 fn_2b70db0
02d34988: adrp    x0, #0x626a000                             
02d3498c: ldr     x0, [x0, #0x958]                           S:'Decor type {0} not found in collection.'
02d34990: bl      #0x2b70db0                                 fn_2b70db0
02d34994: adrp    x0, #0x626a000                             
02d34998: ldr     x0, [x0, #0x960]                           S:'Decor type {0} not found in boxset {1}.'
02d3499c: bl      #0x2b70db0                                 fn_2b70db0
02d349a0: mov     w8, #1                                     
02d349a4: strb    w8, [x19, #0x15a]                          
02d349a8: ldr     x0, [x23]                                  T:type56879(k15)
02d349ac: bl      #0x2b7104c                                 fn_2b7104c
02d349b0: mov     x1, xzr                                    
02d349b4: mov     x19, x0                                    
02d349b8: bl      #0x4e53e9c                                 System.Object::.ctor
02d349bc: cbz     x19, #0x2d34b74                            
02d349c0: adrp    x8, #0x626a000                             
02d349c4: ldr     x8, [x8, #0x940]                           T:type57234(k15)
02d349c8: str     w21, [x19, #0x10]                          
02d349cc: adrp    x21, #0x626a000                            
02d349d0: ldr     x21, [x21, #0x948]                         M:BlindBagCollection.BlindbagCollectionAsset/<>c__DisplayClass10_0::<GetItemSprite>b__0
02d349d4: str     w20, [x19, #0x14]                          
02d349d8: ldr     x0, [x8]                                   T:type56879(k15)
02d349dc: ldr     x20, [x22, #0x30]                          
02d349e0: bl      #0x2b7104c                                 fn_2b7104c
02d349e4: ldr     x2, [x21]                                  T:type56879(k15)
02d349e8: mov     x1, x19                                    
02d349ec: mov     x3, xzr                                    
02d349f0: mov     x21, x0                                    
02d349f4: bl      #0x3999064                                 fn_3999064
02d349f8: cbz     x20, #0x2d34b74                            
02d349fc: adrp    x8, #0x626a000                             
02d34a00: mov     x0, x20                                    
02d34a04: mov     x1, x21                                    
02d34a08: ldr     x8, [x8, #0x928]                           MS:System.Collections.Generic.List`1::Find
02d34a0c: ldr     x2, [x8]                                   T:type56879(k15)
02d34a10: add     x8, sp, #8                                 
02d34a14: bl      #0x4bbfd34                                 fn_4bbfd34
02d34a18: ldr     w9, [sp, #8]                               
02d34a1c: ldr     w8, [x19, #0x10]                           
02d34a20: cmp     w8, w9                                     
02d34a24: b.ne    #0x2d34a98                                 
02d34a28: ldr     w8, [x19, #0x14]                           
02d34a2c: cbz     w8, #0x2d34ad0                             
02d34a30: adrp    x8, #0x626a000                             
02d34a34: ldr     x8, [x8, #0x938]                           T:type57235(k15)
02d34a38: ldr     x20, [sp, #0x28]                           
02d34a3c: ldr     x0, [x8]                                   T:type56879(k15)
02d34a40: bl      #0x2b7104c                                 fn_2b7104c
02d34a44: adrp    x8, #0x626a000                             
02d34a48: mov     x1, x19                                    
02d34a4c: mov     x3, xzr                                    
02d34a50: ldr     x8, [x8, #0x950]                           M:BlindBagCollection.BlindbagCollectionAsset/<>c__DisplayClass10_0::<GetItemSprite>b__1
02d34a54: mov     x21, x0                                    
02d34a58: ldr     x2, [x8]                                   T:type56879(k15)
02d34a5c: bl      #0x3999144                                 fn_3999144
02d34a60: cbz     x20, #0x2d34b74                            
02d34a64: adrp    x8, #0x626a000                             
02d34a68: mov     x0, x20                                    
02d34a6c: mov     x1, x21                                    
02d34a70: ldr     x8, [x8, #0x930]                           MS:System.Collections.Generic.List`1::Find
02d34a74: ldr     x2, [x8]                                   T:type56879(k15)
02d34a78: add     x8, sp, #8                                 
02d34a7c: bl      #0x4bc2bf8                                 fn_4bc2bf8
02d34a80: ldr     w9, [sp, #8]                               
02d34a84: ldr     w8, [x19, #0x14]                           
02d34a88: cmp     w8, w9                                     
02d34a8c: b.ne    #0x2d34ad8                                 
02d34a90: ldr     x0, [sp, #0x10]                            
02d34a94: b       #0x2d34b60                                 
02d34a98: adrp    x9, #0x626a000                             
02d34a9c: add     x1, sp, #8                                 
02d34aa0: ldr     x9, [x9, #0x918]                           T:BlindBagCollection.CollectionBoxsetType
02d34aa4: str     w8, [sp, #8]                               
02d34aa8: ldr     x0, [x9]                                   T:type56879(k15)
02d34aac: bl      #0x2b70f38                                 fn_2b70f38
02d34ab0: adrp    x8, #0x626a000                             
02d34ab4: mov     x1, x0                                     
02d34ab8: mov     x2, xzr                                    
02d34abc: ldr     x8, [x8, #0x958]                           S:'Decor type {0} not found in collection.'
02d34ac0: ldr     x8, [x8]                                   T:type56879(k15)
02d34ac4: mov     x0, x8                                     
02d34ac8: bl      #0x4c9d0ec                                 System.String::Format
02d34acc: b       #0x2d34b30                                 
02d34ad0: ldr     x0, [sp, #0x18]                            
02d34ad4: b       #0x2d34b60                                 
02d34ad8: adrp    x9, #0x626a000                             
02d34adc: add     x1, sp, #8                                 
02d34ae0: ldr     x9, [x9, #0x920]                           T:BlindBagCollection.CollectionItemType
02d34ae4: str     w8, [sp, #8]                               
02d34ae8: ldr     x0, [x9]                                   T:type56879(k15)
02d34aec: bl      #0x2b70f38                                 fn_2b70f38
02d34af0: adrp    x8, #0x626a000                             
02d34af4: mov     x20, x0                                    
02d34af8: add     x1, sp, #4                                 
02d34afc: ldr     x8, [x8, #0x918]                           T:BlindBagCollection.CollectionBoxsetType
02d34b00: ldr     w9, [x19, #0x10]                           
02d34b04: ldr     x0, [x8]                                   T:type56879(k15)
02d34b08: str     w9, [sp, #4]                               
02d34b0c: bl      #0x2b70f38                                 fn_2b70f38
02d34b10: adrp    x8, #0x626a000                             
02d34b14: mov     x2, x0                                     
02d34b18: mov     x1, x20                                    
02d34b1c: ldr     x8, [x8, #0x960]                           S:'Decor type {0} not found in boxset {1}.'
02d34b20: mov     x3, xzr                                    
02d34b24: ldr     x8, [x8]                                   T:type56879(k15)
02d34b28: mov     x0, x8                                     
02d34b2c: bl      #0x4ca7720                                 System.String::Format
02d34b30: adrp    x8, #0x6263000                             
02d34b34: mov     x19, x0                                    
02d34b38: ldr     x8, [x8, #0x928]                           T:UnityEngine.Debug
02d34b3c: ldr     x8, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02d34b40: ldr     w9, [x8, #0xe4]                            [62630e4]=0 f=0,0
02d34b44: cbnz    w9, #0x2d34b50                             
02d34b48: mov     x0, x8                                     
02d34b4c: bl      #0x2b70f30                                 fn_2b70f30
02d34b50: mov     x0, x19                                    
02d34b54: mov     x1, xzr                                    
02d34b58: bl      #0x5af2c94                                 UnityEngine.Debug::LogWarning
02d34b5c: mov     x0, xzr                                    
02d34b60: ldp     x20, x19, [sp, #0x50]                      
02d34b64: ldp     x22, x21, [sp, #0x40]                      
02d34b68: ldp     x30, x23, [sp, #0x30]                      
02d34b6c: add     sp, sp, #0x60                              
02d34b70: ret                                                
02d34b74: bl      #0x2b7105c                                 fn_2b7105c
## GetItemID(BlindBagCollection.CollectionItemType itemType, BlindBagCollection.CollectionBoxsetType boxsetType) -> int
---- BlindBagCollection.BlindbagCollectionAsset::GetItemID 0x2d34b78
02d34b78: sub     sp, sp, #0x60                              
02d34b7c: stp     x30, x23, [sp, #0x30]                      
02d34b80: stp     x22, x21, [sp, #0x40]                      
02d34b84: stp     x20, x19, [sp, #0x50]                      
02d34b88: adrp    x19, #0x6630000                            
02d34b8c: adrp    x23, #0x626a000                            
02d34b90: mov     w21, w2                                    
02d34b94: ldrb    w8, [x19, #0x15b]                          
02d34b98: ldr     x23, [x23, #0x968]                         T:BlindBagCollection.BlindbagCollectionAsset/<>c__DisplayClass11_0
02d34b9c: mov     w20, w1                                    
02d34ba0: mov     x22, x0                                    
02d34ba4: tbnz    w8, #0, #0x2d34c4c                         
02d34ba8: adrp    x0, #0x626a000                             
02d34bac: ldr     x0, [x0, #0x918]                           T:BlindBagCollection.CollectionBoxsetType
02d34bb0: bl      #0x2b70db0                                 fn_2b70db0
02d34bb4: adrp    x0, #0x626a000                             
02d34bb8: ldr     x0, [x0, #0x920]                           T:BlindBagCollection.CollectionItemType
02d34bbc: bl      #0x2b70db0                                 fn_2b70db0
02d34bc0: adrp    x0, #0x6263000                             
02d34bc4: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02d34bc8: bl      #0x2b70db0                                 fn_2b70db0
02d34bcc: adrp    x0, #0x626a000                             
02d34bd0: ldr     x0, [x0, #0x928]                           MS:System.Collections.Generic.List`1::Find
02d34bd4: bl      #0x2b70db0                                 fn_2b70db0
02d34bd8: adrp    x0, #0x626a000                             
02d34bdc: ldr     x0, [x0, #0x930]                           MS:System.Collections.Generic.List`1::Find
02d34be0: bl      #0x2b70db0                                 fn_2b70db0
02d34be4: adrp    x0, #0x626a000                             
02d34be8: ldr     x0, [x0, #0x938]                           T:type57235(k15)
02d34bec: bl      #0x2b70db0                                 fn_2b70db0
02d34bf0: adrp    x0, #0x626a000                             
02d34bf4: ldr     x0, [x0, #0x940]                           T:type57234(k15)
02d34bf8: bl      #0x2b70db0                                 fn_2b70db0
02d34bfc: adrp    x0, #0x6264000                             
02d34c00: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02d34c04: bl      #0x2b70db0                                 fn_2b70db0
02d34c08: adrp    x0, #0x626a000                             
02d34c0c: ldr     x0, [x0, #0x970]                           M:BlindBagCollection.BlindbagCollectionAsset/<>c__DisplayClass11_0::<GetItemID>b__0
02d34c10: bl      #0x2b70db0                                 fn_2b70db0
02d34c14: adrp    x0, #0x626a000                             
02d34c18: ldr     x0, [x0, #0x978]                           M:BlindBagCollection.BlindbagCollectionAsset/<>c__DisplayClass11_0::<GetItemID>b__1
02d34c1c: bl      #0x2b70db0                                 fn_2b70db0
02d34c20: adrp    x0, #0x626a000                             
02d34c24: ldr     x0, [x0, #0x968]                           T:BlindBagCollection.BlindbagCollectionAsset/<>c__DisplayClass11_0
02d34c28: bl      #0x2b70db0                                 fn_2b70db0
02d34c2c: adrp    x0, #0x626a000                             
02d34c30: ldr     x0, [x0, #0x958]                           S:'Decor type {0} not found in collection.'
02d34c34: bl      #0x2b70db0                                 fn_2b70db0
02d34c38: adrp    x0, #0x626a000                             
02d34c3c: ldr     x0, [x0, #0x960]                           S:'Decor type {0} not found in boxset {1}.'
02d34c40: bl      #0x2b70db0                                 fn_2b70db0
02d34c44: mov     w8, #1                                     
02d34c48: strb    w8, [x19, #0x15b]                          
02d34c4c: ldr     x0, [x23]                                  T:type56879(k15)
02d34c50: bl      #0x2b7104c                                 fn_2b7104c
02d34c54: mov     x1, xzr                                    
02d34c58: mov     x19, x0                                    
02d34c5c: bl      #0x4e53e9c                                 System.Object::.ctor
02d34c60: cbz     x19, #0x2d34e7c                            
02d34c64: adrp    x8, #0x626a000                             
02d34c68: ldr     x8, [x8, #0x940]                           T:type57234(k15)
02d34c6c: str     w21, [x19, #0x10]                          
02d34c70: adrp    x21, #0x626a000                            
02d34c74: ldr     x21, [x21, #0x970]                         M:BlindBagCollection.BlindbagCollectionAsset/<>c__DisplayClass11_0::<GetItemID>b__0
02d34c78: str     w20, [x19, #0x14]                          
02d34c7c: ldr     x0, [x8]                                   T:type56879(k15)
02d34c80: ldr     x20, [x22, #0x30]                          
02d34c84: bl      #0x2b7104c                                 fn_2b7104c
02d34c88: ldr     x2, [x21]                                  T:type56879(k15)
02d34c8c: mov     x1, x19                                    
02d34c90: mov     x3, xzr                                    
02d34c94: mov     x21, x0                                    
02d34c98: bl      #0x3999064                                 fn_3999064
02d34c9c: cbz     x20, #0x2d34e7c                            
02d34ca0: adrp    x8, #0x626a000                             
02d34ca4: mov     x0, x20                                    
02d34ca8: mov     x1, x21                                    
02d34cac: ldr     x8, [x8, #0x928]                           MS:System.Collections.Generic.List`1::Find
02d34cb0: ldr     x2, [x8]                                   T:type56879(k15)
02d34cb4: add     x8, sp, #8                                 
02d34cb8: bl      #0x4bbfd34                                 fn_4bbfd34
02d34cbc: ldr     w9, [sp, #8]                               
02d34cc0: ldr     w8, [x19, #0x10]                           
02d34cc4: cmp     w9, w8                                     
02d34cc8: b.ne    #0x2d34d44                                 
02d34ccc: ldr     w8, [x19, #0x14]                           
02d34cd0: cbz     w8, #0x2d34d7c                             
02d34cd4: adrp    x8, #0x626a000                             
02d34cd8: ldr     x8, [x8, #0x938]                           T:type57235(k15)
02d34cdc: ldr     x20, [sp, #0x28]                           
02d34ce0: ldr     x0, [x8]                                   T:type56879(k15)
02d34ce4: bl      #0x2b7104c                                 fn_2b7104c
02d34ce8: adrp    x8, #0x626a000                             
02d34cec: mov     x1, x19                                    
02d34cf0: mov     x3, xzr                                    
02d34cf4: ldr     x8, [x8, #0x978]                           M:BlindBagCollection.BlindbagCollectionAsset/<>c__DisplayClass11_0::<GetItemID>b__1
02d34cf8: mov     x21, x0                                    
02d34cfc: ldr     x2, [x8]                                   T:type56879(k15)
02d34d00: bl      #0x3999144                                 fn_3999144
02d34d04: cbz     x20, #0x2d34e7c                            
02d34d08: adrp    x8, #0x626a000                             
02d34d0c: mov     x0, x20                                    
02d34d10: mov     x1, x21                                    
02d34d14: ldr     x8, [x8, #0x930]                           MS:System.Collections.Generic.List`1::Find
02d34d18: ldr     x2, [x8]                                   T:type56879(k15)
02d34d1c: add     x8, sp, #8                                 
02d34d20: bl      #0x4bc2bf8                                 fn_4bc2bf8
02d34d24: ldr     w9, [sp, #8]                               
02d34d28: ldr     w8, [x19, #0x14]                           
02d34d2c: cmp     w9, w8                                     
02d34d30: b.ne    #0x2d34de0                                 
02d34d34: adrp    x21, #0x6264000                            
02d34d38: ldr     x21, [x21, #0xfc0]                         T:RemoteConfigManager
02d34d3c: ldp     w19, w20, [sp, #0x18]                      
02d34d40: b       #0x2d34d88                                 
02d34d44: adrp    x9, #0x626a000                             
02d34d48: add     x1, sp, #8                                 
02d34d4c: ldr     x9, [x9, #0x918]                           T:BlindBagCollection.CollectionBoxsetType
02d34d50: str     w8, [sp, #8]                               
02d34d54: ldr     x0, [x9]                                   T:type56879(k15)
02d34d58: bl      #0x2b70f38                                 fn_2b70f38
02d34d5c: adrp    x8, #0x626a000                             
02d34d60: mov     x1, x0                                     
02d34d64: mov     x2, xzr                                    
02d34d68: ldr     x8, [x8, #0x958]                           S:'Decor type {0} not found in collection.'
02d34d6c: ldr     x8, [x8]                                   T:type56879(k15)
02d34d70: mov     x0, x8                                     
02d34d74: bl      #0x4c9d0ec                                 System.String::Format
02d34d78: b       #0x2d34e38                                 
02d34d7c: adrp    x21, #0x6264000                            
02d34d80: ldr     x21, [x21, #0xfc0]                         T:RemoteConfigManager
02d34d84: ldp     w19, w20, [sp, #0x20]                      
02d34d88: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d34d8c: ldr     w8, [x0, #0xe4]                            [626a0e4]=0 f=0,0
02d34d90: cbnz    w8, #0x2d34d98                             
02d34d94: bl      #0x2b70f30                                 fn_2b70f30
02d34d98: adrp    x22, #0x662f000                            
02d34d9c: ldrb    w8, [x22, #0xbc1]                          
02d34da0: cbnz    w8, #0x2d34db8                             
02d34da4: adrp    x0, #0x6264000                             
02d34da8: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02d34dac: bl      #0x2b70db0                                 fn_2b70db0
02d34db0: mov     w8, #1                                     
02d34db4: strb    w8, [x22, #0xbc1]                          
02d34db8: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d34dbc: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02d34dc0: cbnz    w8, #0x2d34dcc                             
02d34dc4: bl      #0x2b70f30                                 fn_2b70f30
02d34dc8: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d34dcc: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d34dd0: ldr     w8, [x8, #0x10]                            T:Decor.DataDecor/CategoryData
02d34dd4: cmp     w8, #1                                     
02d34dd8: csel    w0, w19, w20, eq                           
02d34ddc: b       #0x2d34e68                                 
02d34de0: adrp    x9, #0x626a000                             
02d34de4: add     x1, sp, #8                                 
02d34de8: ldr     x9, [x9, #0x920]                           T:BlindBagCollection.CollectionItemType
02d34dec: str     w8, [sp, #8]                               
02d34df0: ldr     x0, [x9]                                   T:type56879(k15)
02d34df4: bl      #0x2b70f38                                 fn_2b70f38
02d34df8: adrp    x8, #0x626a000                             
02d34dfc: mov     x20, x0                                    
02d34e00: add     x1, sp, #4                                 
02d34e04: ldr     x8, [x8, #0x918]                           T:BlindBagCollection.CollectionBoxsetType
02d34e08: ldr     w9, [x19, #0x10]                           
02d34e0c: ldr     x0, [x8]                                   T:type56879(k15)
02d34e10: str     w9, [sp, #4]                               
02d34e14: bl      #0x2b70f38                                 fn_2b70f38
02d34e18: adrp    x8, #0x626a000                             
02d34e1c: mov     x2, x0                                     
02d34e20: mov     x1, x20                                    
02d34e24: ldr     x8, [x8, #0x960]                           S:'Decor type {0} not found in boxset {1}.'
02d34e28: mov     x3, xzr                                    
02d34e2c: ldr     x8, [x8]                                   T:type56879(k15)
02d34e30: mov     x0, x8                                     
02d34e34: bl      #0x4ca7720                                 System.String::Format
02d34e38: adrp    x8, #0x6263000                             
02d34e3c: mov     x19, x0                                    
02d34e40: ldr     x8, [x8, #0x928]                           T:UnityEngine.Debug
02d34e44: ldr     x8, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02d34e48: ldr     w9, [x8, #0xe4]                            [62630e4]=0 f=0,0
02d34e4c: cbnz    w9, #0x2d34e58                             
02d34e50: mov     x0, x8                                     
02d34e54: bl      #0x2b70f30                                 fn_2b70f30
02d34e58: mov     x0, x19                                    
02d34e5c: mov     x1, xzr                                    
02d34e60: bl      #0x5af2c94                                 UnityEngine.Debug::LogWarning
02d34e64: mov     w0, wzr                                    
02d34e68: ldp     x20, x19, [sp, #0x50]                      
02d34e6c: ldp     x22, x21, [sp, #0x40]                      
02d34e70: ldp     x30, x23, [sp, #0x30]                      
02d34e74: add     sp, sp, #0x60                              
02d34e78: ret                                                
02d34e7c: bl      #0x2b7105c                                 fn_2b7105c
## GetRarity(BlindBagCollection.CollectionItemType itemType, BlindBagCollection.CollectionBoxsetType boxsetType) -> RarityType
---- BlindBagCollection.BlindbagCollectionAsset::GetRarity 0x2d34e80
02d34e80: sub     sp, sp, #0x60                              
02d34e84: stp     x30, x23, [sp, #0x30]                      
02d34e88: stp     x22, x21, [sp, #0x40]                      
02d34e8c: stp     x20, x19, [sp, #0x50]                      
02d34e90: adrp    x20, #0x6630000                            
02d34e94: adrp    x23, #0x626a000                            
02d34e98: mov     w22, w2                                    
02d34e9c: ldrb    w8, [x20, #0x15c]                          
02d34ea0: ldr     x23, [x23, #0x980]                         T:BlindBagCollection.BlindbagCollectionAsset/<>c__DisplayClass12_0
02d34ea4: mov     w21, w1                                    
02d34ea8: mov     x19, x0                                    
02d34eac: tbnz    w8, #0, #0x2d34f78                         
02d34eb0: adrp    x0, #0x626a000                             
02d34eb4: ldr     x0, [x0, #0x918]                           T:BlindBagCollection.CollectionBoxsetType
02d34eb8: bl      #0x2b70db0                                 fn_2b70db0
02d34ebc: adrp    x0, #0x626a000                             
02d34ec0: ldr     x0, [x0, #0x920]                           T:BlindBagCollection.CollectionItemType
02d34ec4: bl      #0x2b70db0                                 fn_2b70db0
02d34ec8: adrp    x0, #0x6263000                             
02d34ecc: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02d34ed0: bl      #0x2b70db0                                 fn_2b70db0
02d34ed4: adrp    x0, #0x626a000                             
02d34ed8: ldr     x0, [x0, #0x928]                           MS:System.Collections.Generic.List`1::Find
02d34edc: bl      #0x2b70db0                                 fn_2b70db0
02d34ee0: adrp    x0, #0x626a000                             
02d34ee4: ldr     x0, [x0, #0x988]                           MS:System.Collections.Generic.List`1::Find
02d34ee8: bl      #0x2b70db0                                 fn_2b70db0
02d34eec: adrp    x0, #0x626a000                             
02d34ef0: ldr     x0, [x0, #0x930]                           MS:System.Collections.Generic.List`1::Find
02d34ef4: bl      #0x2b70db0                                 fn_2b70db0
02d34ef8: adrp    x0, #0x626a000                             
02d34efc: ldr     x0, [x0, #0x938]                           T:type57235(k15)
02d34f00: bl      #0x2b70db0                                 fn_2b70db0
02d34f04: adrp    x0, #0x626a000                             
02d34f08: ldr     x0, [x0, #0x990]                           T:type57241(k15)
02d34f0c: bl      #0x2b70db0                                 fn_2b70db0
02d34f10: adrp    x0, #0x626a000                             
02d34f14: ldr     x0, [x0, #0x940]                           T:type57234(k15)
02d34f18: bl      #0x2b70db0                                 fn_2b70db0
02d34f1c: adrp    x0, #0x626a000                             
02d34f20: ldr     x0, [x0, #0x998]                           M:BlindBagCollection.BlindbagCollectionAsset/<>c__DisplayClass12_0::<GetRarity>b__0
02d34f24: bl      #0x2b70db0                                 fn_2b70db0
02d34f28: adrp    x0, #0x626a000                             
02d34f2c: ldr     x0, [x0, #0x9a0]                           M:BlindBagCollection.BlindbagCollectionAsset/<>c__DisplayClass12_0::<GetRarity>b__1
02d34f30: bl      #0x2b70db0                                 fn_2b70db0
02d34f34: adrp    x0, #0x626a000                             
02d34f38: ldr     x0, [x0, #0x980]                           T:BlindBagCollection.BlindbagCollectionAsset/<>c__DisplayClass12_0
02d34f3c: bl      #0x2b70db0                                 fn_2b70db0
02d34f40: adrp    x0, #0x626a000                             
02d34f44: ldr     x0, [x0, #0x9a8]                           M:BlindBagCollection.BlindbagCollectionAsset/<>c__DisplayClass12_1::<GetRarity>b__2
02d34f48: bl      #0x2b70db0                                 fn_2b70db0
02d34f4c: adrp    x0, #0x626a000                             
02d34f50: ldr     x0, [x0, #0x9b0]                           T:BlindBagCollection.BlindbagCollectionAsset/<>c__DisplayClass12_1
02d34f54: bl      #0x2b70db0                                 fn_2b70db0
02d34f58: adrp    x0, #0x626a000                             
02d34f5c: ldr     x0, [x0, #0x958]                           S:'Decor type {0} not found in collection.'
02d34f60: bl      #0x2b70db0                                 fn_2b70db0
02d34f64: adrp    x0, #0x626a000                             
02d34f68: ldr     x0, [x0, #0x960]                           S:'Decor type {0} not found in boxset {1}.'
02d34f6c: bl      #0x2b70db0                                 fn_2b70db0
02d34f70: mov     w8, #1                                     
02d34f74: strb    w8, [x20, #0x15c]                          
02d34f78: ldr     x0, [x23]                                  T:type56879(k15)
02d34f7c: bl      #0x2b7104c                                 fn_2b7104c
02d34f80: mov     x1, xzr                                    
02d34f84: mov     x20, x0                                    
02d34f88: bl      #0x4e53e9c                                 System.Object::.ctor
02d34f8c: cbz     x20, #0x2d351e4                            
02d34f90: adrp    x8, #0x626a000                             
02d34f94: ldr     x8, [x8, #0x940]                           T:type57234(k15)
02d34f98: str     w22, [x20, #0x10]                          
02d34f9c: adrp    x22, #0x626a000                            
02d34fa0: ldr     x22, [x22, #0x998]                         M:BlindBagCollection.BlindbagCollectionAsset/<>c__DisplayClass12_0::<GetRarity>b__0
02d34fa4: str     w21, [x20, #0x14]                          
02d34fa8: ldr     x0, [x8]                                   T:type56879(k15)
02d34fac: ldr     x21, [x19, #0x30]                          .CollectionBoxsets
02d34fb0: bl      #0x2b7104c                                 fn_2b7104c
02d34fb4: ldr     x2, [x22]                                  T:type56879(k15)
02d34fb8: mov     x1, x20                                    
02d34fbc: mov     x3, xzr                                    
02d34fc0: mov     x22, x0                                    
02d34fc4: bl      #0x3999064                                 fn_3999064
02d34fc8: cbz     x21, #0x2d351e4                            
02d34fcc: adrp    x8, #0x626a000                             
02d34fd0: mov     x0, x21                                    
02d34fd4: mov     x1, x22                                    
02d34fd8: ldr     x8, [x8, #0x928]                           MS:System.Collections.Generic.List`1::Find
02d34fdc: ldr     x2, [x8]                                   T:type56879(k15)
02d34fe0: add     x8, sp, #8                                 
02d34fe4: bl      #0x4bbfd34                                 fn_4bbfd34
02d34fe8: ldr     w9, [sp, #8]                               
02d34fec: ldr     w8, [x20, #0x10]                           
02d34ff0: cmp     w9, w8                                     
02d34ff4: b.ne    #0x2d35108                                 
02d34ff8: ldr     w8, [x20, #0x14]                           
02d34ffc: cbz     w8, #0x2d35140                             
02d35000: adrp    x8, #0x626a000                             
02d35004: ldr     x8, [x8, #0x9b0]                           T:BlindBagCollection.BlindbagCollectionAsset/<>c__DisplayClass12_1
02d35008: ldr     x22, [sp, #0x28]                           
02d3500c: ldr     x0, [x8]                                   T:type56879(k15)
02d35010: bl      #0x2b7104c                                 fn_2b7104c
02d35014: mov     x1, xzr                                    
02d35018: mov     x21, x0                                    
02d3501c: bl      #0x4e53e9c                                 System.Object::.ctor
02d35020: adrp    x8, #0x626a000                             
02d35024: ldr     x8, [x8, #0x938]                           T:type57235(k15)
02d35028: ldr     x0, [x8]                                   T:type56879(k15)
02d3502c: bl      #0x2b7104c                                 fn_2b7104c
02d35030: adrp    x8, #0x626a000                             
02d35034: mov     x1, x20                                    
02d35038: mov     x3, xzr                                    
02d3503c: ldr     x8, [x8, #0x9a0]                           M:BlindBagCollection.BlindbagCollectionAsset/<>c__DisplayClass12_0::<GetRarity>b__1
02d35040: mov     x23, x0                                    
02d35044: ldr     x2, [x8]                                   T:type56879(k15)
02d35048: bl      #0x3999144                                 fn_3999144
02d3504c: cbz     x22, #0x2d351e4                            
02d35050: adrp    x8, #0x626a000                             
02d35054: mov     x0, x22                                    
02d35058: mov     x1, x23                                    
02d3505c: ldr     x8, [x8, #0x930]                           MS:System.Collections.Generic.List`1::Find
02d35060: ldr     x2, [x8]                                   T:type56879(k15)
02d35064: add     x8, sp, #8                                 
02d35068: bl      #0x4bc2bf8                                 fn_4bc2bf8
02d3506c: cbz     x21, #0x2d351e4                            
02d35070: ldur    q0, [sp, #8]                               
02d35074: ldr     x8, [sp, #0x18]                            
02d35078: add     x0, x21, #0x18                             
02d3507c: mov     x1, xzr                                    
02d35080: str     q0, [x21, #0x10]                           
02d35084: str     x8, [x21, #0x20]                           .DecorItemPrice
02d35088: bl      #0x2b70d54                                 fn_2b70d54
02d3508c: ldr     w9, [x21, #0x10]                           
02d35090: ldr     w8, [x20, #0x14]                           
02d35094: cmp     w9, w8                                     
02d35098: b.ne    #0x2d35148                                 
02d3509c: ldr     x0, [x19, #0x50]                           ._decorKeycapConfig
02d350a0: cbz     x0, #0x2d351e4                             
02d350a4: mov     x1, xzr                                    
02d350a8: bl      #0x2d5b4c0                                 Clicker.DecorKeycapConfig::get_DataList
02d350ac: adrp    x8, #0x626a000                             
02d350b0: mov     x19, x0                                    
02d350b4: ldr     x8, [x8, #0x990]                           T:type57241(k15)
02d350b8: ldr     x8, [x8]                                   T:type56879(k15)
02d350bc: mov     x0, x8                                     
02d350c0: bl      #0x2b7104c                                 fn_2b7104c
02d350c4: adrp    x8, #0x626a000                             
02d350c8: mov     x1, x21                                    
02d350cc: mov     x3, xzr                                    
02d350d0: ldr     x8, [x8, #0x9a8]                           M:BlindBagCollection.BlindbagCollectionAsset/<>c__DisplayClass12_1::<GetRarity>b__2
02d350d4: mov     x20, x0                                    
02d350d8: ldr     x2, [x8]                                   T:type56879(k15)
02d350dc: bl      #0x399ba10                                 fn_399ba10
02d350e0: cbz     x19, #0x2d351e4                            
02d350e4: adrp    x8, #0x626a000                             
02d350e8: mov     x0, x19                                    
02d350ec: mov     x1, x20                                    
02d350f0: ldr     x8, [x8, #0x988]                           MS:System.Collections.Generic.List`1::Find
02d350f4: ldr     x2, [x8]                                   T:type56879(k15)
02d350f8: bl      #0x35a9868                                 fn_35a9868
02d350fc: cbz     x0, #0x2d351d0                             
02d35100: ldr     w0, [x0, #0x24]                            [626a024]=0 f=0,0
02d35104: b       #0x2d351d0                                 
02d35108: adrp    x9, #0x626a000                             
02d3510c: add     x1, sp, #8                                 
02d35110: ldr     x9, [x9, #0x918]                           T:BlindBagCollection.CollectionBoxsetType
02d35114: str     w8, [sp, #8]                               
02d35118: ldr     x0, [x9]                                   T:type56879(k15)
02d3511c: bl      #0x2b70f38                                 fn_2b70f38
02d35120: adrp    x8, #0x626a000                             
02d35124: mov     x1, x0                                     
02d35128: mov     x2, xzr                                    
02d3512c: ldr     x8, [x8, #0x958]                           S:'Decor type {0} not found in collection.'
02d35130: ldr     x8, [x8]                                   T:type56879(k15)
02d35134: mov     x0, x8                                     
02d35138: bl      #0x4c9d0ec                                 System.String::Format
02d3513c: b       #0x2d351a0                                 
02d35140: mov     w0, #0x63                                  
02d35144: b       #0x2d351d0                                 
02d35148: adrp    x9, #0x626a000                             
02d3514c: add     x1, sp, #8                                 
02d35150: ldr     x9, [x9, #0x920]                           T:BlindBagCollection.CollectionItemType
02d35154: str     w8, [sp, #8]                               
02d35158: ldr     x0, [x9]                                   T:type56879(k15)
02d3515c: bl      #0x2b70f38                                 fn_2b70f38
02d35160: adrp    x8, #0x626a000                             
02d35164: mov     x19, x0                                    
02d35168: add     x1, sp, #4                                 
02d3516c: ldr     x8, [x8, #0x918]                           T:BlindBagCollection.CollectionBoxsetType
02d35170: ldr     w9, [x20, #0x10]                           
02d35174: ldr     x0, [x8]                                   T:type56879(k15)
02d35178: str     w9, [sp, #4]                               
02d3517c: bl      #0x2b70f38                                 fn_2b70f38
02d35180: adrp    x8, #0x626a000                             
02d35184: mov     x2, x0                                     
02d35188: mov     x1, x19                                    
02d3518c: ldr     x8, [x8, #0x960]                           S:'Decor type {0} not found in boxset {1}.'
02d35190: mov     x3, xzr                                    
02d35194: ldr     x8, [x8]                                   T:type56879(k15)
02d35198: mov     x0, x8                                     
02d3519c: bl      #0x4ca7720                                 System.String::Format
02d351a0: adrp    x8, #0x6263000                             
02d351a4: mov     x19, x0                                    
02d351a8: ldr     x8, [x8, #0x928]                           T:UnityEngine.Debug
02d351ac: ldr     x8, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02d351b0: ldr     w9, [x8, #0xe4]                            [62630e4]=0 f=0,0
02d351b4: cbnz    w9, #0x2d351c0                             
02d351b8: mov     x0, x8                                     
02d351bc: bl      #0x2b70f30                                 fn_2b70f30
02d351c0: mov     x0, x19                                    
02d351c4: mov     x1, xzr                                    
02d351c8: bl      #0x5af2c94                                 UnityEngine.Debug::LogWarning
02d351cc: mov     w0, wzr                                    
02d351d0: ldp     x20, x19, [sp, #0x50]                      
02d351d4: ldp     x22, x21, [sp, #0x40]                      
02d351d8: ldp     x30, x23, [sp, #0x30]                      
02d351dc: add     sp, sp, #0x60                              
02d351e0: ret                                                
02d351e4: bl      #0x2b7105c                                 fn_2b7105c
## GetRandomItemPrice(BlindBagCollection.CollectionItemType itemType) -> int
---- BlindBagCollection.BlindbagCollectionAsset::GetRandomItemPrice 0x2d351e8
02d351e8: mov     w8, #0x24                                  
02d351ec: cmp     w1, #0                                     
02d351f0: mov     w9, #0x1c                                  
02d351f4: mov     w10, #0x20                                 
02d351f8: mov     w11, #0x18                                 
02d351fc: csel    x9, x9, x8, eq                             
02d35200: csel    x8, x11, x10, eq                           
02d35204: ldr     w9, [x0, x9]                               
02d35208: mov     x2, xzr                                    
02d3520c: ldr     w8, [x0, x8]                               
02d35210: add     w1, w9, #1                                 
02d35214: mov     w0, w8                                     
02d35218: b       #0x5b2e000                                 UnityEngine.Random::Range
## .ctor() -> void
---- BlindBagCollection.BlindbagCollectionAsset::.ctor 0x2d3bd98
02d3bd98: adrp    x8, #0x1086000                             
02d3bd9c: mov     x1, xzr                                    
02d3bda0: ldr     q0, [x8, #0xa00]                           [1086a00]=12c000000c8 f=2.8026e-43,4.2039e-43
02d3bda4: mov     w8, #0x1e                                  
02d3bda8: str     w8, [x0, #0x28]                            .LuckBagChance
02d3bdac: stur    q0, [x0, #0x18]                            .FullKeycapPrice
02d3bdb0: b       #0x2cae4f0                                 GameAsset::.ctor
