#### CLASS DataLevelSave parent= object
#   field currentLevel                   int                                                off=0x10 attr=6 
#   field highestLevel                   int                                                off=0x14 attr=6 
## .ctor(int currentLevelId, int highestLevelId) -> void
---- DataLevelSave::.ctor 0x2ca9a30
02ca9a30: stp     x30, x21, [sp, #-0x20]!                    
02ca9a34: stp     x20, x19, [sp, #0x10]                      
02ca9a38: mov     w20, w1                                    
02ca9a3c: mov     x1, xzr                                    
02ca9a40: mov     w19, w2                                    
02ca9a44: mov     x21, x0                                    
02ca9a48: bl      #0x4e53e9c                                 System.Object::.ctor
02ca9a4c: stp     w20, w19, [x21, #0x10]                     .currentLevel
02ca9a50: ldp     x20, x19, [sp, #0x10]                      
02ca9a54: ldp     x30, x21, [sp], #0x20                      
02ca9a58: ret                                                
