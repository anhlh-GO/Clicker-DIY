#### CLASS DailyTask.Mission parent= object
#   field Id                             int                                                off=0x10 attr=6 
#   field TaskDescription                string                                             off=0x18 attr=6 
#   field MissionType                    DailyTask.MissionType                              off=0x20 attr=6 
#   field Icon                           UnityEngine.Sprite                                 off=0x28 attr=6 
#   field TargetProgress                 int                                                off=0x30 attr=6 
## .ctor() -> void
---- DailyTask.Mission::.ctor 0x2d2bfc0
02d2bfc0: mov     x1, xzr                                    
02d2bfc4: b       #0x4e53e9c                                 System.Object::.ctor
