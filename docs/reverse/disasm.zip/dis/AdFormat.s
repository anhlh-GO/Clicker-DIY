#### CLASS AdFormat parent= int
#   field value__                        int                                                off=0x10 attr=606 
#   field INTER                          AdFormat                                           off=0x0 attr=8056 
#   field REWARD                         AdFormat                                           off=0x0 attr=8056 
#   field BANNER                         AdFormat                                           off=0x0 attr=8056 
#   field MREC                           AdFormat                                           off=0x0 attr=8056 
#   field APP_OPEN                       AdFormat                                           off=0x0 attr=8056 
#   field APP_OPEN_GAM                   AdFormat                                           off=0x0 attr=8056 
#   field NATIVE                         AdFormat                                           off=0x0 attr=8056 
#   field INTER_GAM                      AdFormat                                           off=0x0 attr=8056 
#   field NATIVE_INTER                   AdFormat                                           off=0x0 attr=8056 
#   field DEV_KEY                        AdFormat                                           off=0x0 attr=8056 
#   field NATIVE_COLLAP                  AdFormat                                           off=0x0 attr=8056 
#   field NATIVE_BANNER                  AdFormat                                           off=0x0 attr=8056 
