#### CLASS ScoopGame.BlindBox/<>c parent= object
#   field <>9                            ScoopGame.BlindBox/<>c                             off=0x0 attr=36 
#   field <>9__24_0                      System.Action                                      off=0x8 attr=16 
## .cctor() -> void
---- ScoopGame.BlindBox/<>c::.cctor 0x2d3cca0
02d3cca0: str     x30, [sp, #-0x20]!                         
02d3cca4: stp     x20, x19, [sp, #0x10]                      
02d3cca8: adrp    x19, #0x6630000                            
02d3ccac: adrp    x20, #0x626a000                            
02d3ccb0: ldrb    w8, [x19, #0x16e]                          
02d3ccb4: ldr     x20, [x20, #0xd78]                         T:ScoopGame.BlindBox/<>c
02d3ccb8: tbnz    w8, #0, #0x2d3ccd0                         
02d3ccbc: adrp    x0, #0x626a000                             
02d3ccc0: ldr     x0, [x0, #0xd78]                           T:ScoopGame.BlindBox/<>c
02d3ccc4: bl      #0x2b70db0                                 fn_2b70db0
02d3ccc8: mov     w8, #1                                     
02d3cccc: strb    w8, [x19, #0x16e]                          
02d3ccd0: ldr     x0, [x20]                                  T:type56879(k15)
02d3ccd4: bl      #0x2b7104c                                 fn_2b7104c
02d3ccd8: mov     x1, xzr                                    
02d3ccdc: mov     x19, x0                                    
02d3cce0: bl      #0x4e53e9c                                 System.Object::.ctor
02d3cce4: ldr     x8, [x20]                                  T:type56879(k15)
02d3cce8: mov     x1, x19                                    
02d3ccec: ldr     x8, [x8, #0xb8]                            
02d3ccf0: str     x19, [x8]                                  
02d3ccf4: ldr     x8, [x20]                                  T:type56879(k15)
02d3ccf8: ldp     x20, x19, [sp, #0x10]                      
02d3ccfc: ldr     x0, [x8, #0xb8]                            
02d3cd00: ldr     x30, [sp], #0x20                           
02d3cd04: b       #0x2b70d54                                 
## .ctor() -> void
---- ScoopGame.BlindBox/<>c::.ctor 0x2d3cd08
02d3cd08: mov     x1, xzr                                    
02d3cd0c: b       #0x4e53e9c                                 System.Object::.ctor
## <OnPointerDown>b__24_0() -> void
---- ScoopGame.BlindBox/<>c::<OnPointerDown>b__24_0 0x2d3cd10
02d3cd10: ret                                                
#### CLASS ScoopGame.BlindBox/<>c__DisplayClass29_0 parent= object
#   field <>4__this                      ScoopGame.BlindBox                                 off=0x10 attr=6 
#   field onComplete                     System.Action                                      off=0x18 attr=6 
#   field <>9__1                         DG.Tweening.TweenCallback                          off=0x20 attr=6 
## .ctor() -> void
---- ScoopGame.BlindBox/<>c__DisplayClass29_0::.ctor 0x2d3c688
02d3c688: mov     x1, xzr                                    
02d3c68c: b       #0x4e53e9c                                 System.Object::.ctor
## <AnimOpen>b__0() -> void
---- ScoopGame.BlindBox/<>c__DisplayClass29_0::<AnimOpen>b__0 0x2d3cd14
02d3cd14: stp     x30, x23, [sp, #-0x30]!                    
02d3cd18: stp     x22, x21, [sp, #0x10]                      
02d3cd1c: stp     x20, x19, [sp, #0x20]                      
02d3cd20: adrp    x20, #0x6630000                            
02d3cd24: mov     x19, x0                                    
02d3cd28: ldrb    w8, [x20, #0x16f]                          
02d3cd2c: tbnz    w8, #0, #0x2d3cd74                         
02d3cd30: adrp    x0, #0x6263000                             
02d3cd34: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d3cd38: bl      #0x2b70db0                                 fn_2b70db0
02d3cd3c: adrp    x0, #0x6264000                             
02d3cd40: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d3cd44: bl      #0x2b70db0                                 fn_2b70db0
02d3cd48: adrp    x0, #0x6266000                             
02d3cd4c: ldr     x0, [x0, #0x928]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d3cd50: bl      #0x2b70db0                                 fn_2b70db0
02d3cd54: adrp    x0, #0x6266000                             
02d3cd58: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d3cd5c: bl      #0x2b70db0                                 fn_2b70db0
02d3cd60: adrp    x0, #0x626a000                             
02d3cd64: ldr     x0, [x0, #0xde8]                           M:ScoopGame.BlindBox/<>c__DisplayClass29_0::<AnimOpen>b__1
02d3cd68: bl      #0x2b70db0                                 fn_2b70db0
02d3cd6c: mov     w8, #1                                     
02d3cd70: strb    w8, [x20, #0x16f]                          
02d3cd74: ldr     x8, [x19, #0x10]                           .<>4__this
02d3cd78: cbz     x8, #0x2d3ce8c                             
02d3cd7c: adrp    x9, #0x6263000                             
02d3cd80: ldr     x9, [x9, #0x918]                           T:UnityEngine.Object
02d3cd84: ldr     x20, [x8, #0x78]                           
02d3cd88: ldr     x0, [x9]                                   &2c5bbd4(=a9bd7bfdd503233f)
02d3cd8c: ldr     w9, [x0, #0xe4]                            [626a0e4]=0 f=0,0
02d3cd90: cbnz    w9, #0x2d3cd98                             
02d3cd94: bl      #0x2b70f30                                 fn_2b70f30
02d3cd98: mov     x0, x20                                    
02d3cd9c: mov     x1, xzr                                    
02d3cda0: mov     x2, xzr                                    
02d3cda4: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d3cda8: tbz     w0, #0, #0x2d3cdc0                         
02d3cdac: ldr     x8, [x19, #0x10]                           .<>4__this
02d3cdb0: cbz     x8, #0x2d3ce8c                             
02d3cdb4: ldr     x0, [x8, #0x78]                            
02d3cdb8: cbz     x0, #0x2d3ce8c                             
02d3cdbc: bl      #0x2d3ce90                                 ScoopGame.BlindBoxPlate::SpawnCompliment
02d3cdc0: ldr     x8, [x19, #0x18]                           .onComplete
02d3cdc4: cbz     x8, #0x2d3cdd8                             
02d3cdc8: ldr     x9, [x8, #0x18]                            
02d3cdcc: ldr     x0, [x8, #0x40]                            
02d3cdd0: ldr     x1, [x8, #0x28]                            
02d3cdd4: blr     x9                                         
02d3cdd8: ldr     x8, [x19, #0x10]                           .<>4__this
02d3cddc: cbz     x8, #0x2d3ce8c                             
02d3cde0: adrp    x20, #0x6266000                            
02d3cde4: adrp    x23, #0x6266000                            
02d3cde8: adrp    x9, #0x1084000                             
02d3cdec: ldr     x20, [x20, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d3cdf0: ldr     x23, [x23, #0x928]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d3cdf4: ldr     x0, [x8, #0x28]                            
02d3cdf8: adrp    x8, #0x1084000                             
02d3cdfc: ldr     s1, [x9, #0xf10]                           [1084f10]=4110bc863e99999a f=0.3,9.04603
02d3ce00: mov     x1, xzr                                    
02d3ce04: ldr     s0, [x8, #0xcc4]                           [1084cc4]=3f8000543f4ccccd f=0.8,1.00001
02d3ce08: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d3ce0c: ldr     x2, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d3ce10: mov     w1, #1                                     
02d3ce14: bl      #0x336fa0c                                 fn_336fa0c
02d3ce18: mov     x21, x19                                   
02d3ce1c: mov     x20, x0                                    
02d3ce20: ldr     x22, [x21, #0x20]!                         .<>9__1
02d3ce24: cbnz    x22, #0x2d3ce64                            
02d3ce28: adrp    x8, #0x6264000                             
02d3ce2c: ldr     x8, [x8, #0xe8]                            T:DG.Tweening.TweenCallback
02d3ce30: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d3ce34: bl      #0x2b7104c                                 fn_2b7104c
02d3ce38: adrp    x8, #0x626a000                             
02d3ce3c: mov     x1, x19                                    
02d3ce40: mov     x3, xzr                                    
02d3ce44: ldr     x8, [x8, #0xde8]                           M:ScoopGame.BlindBox/<>c__DisplayClass29_0::<AnimOpen>b__1
02d3ce48: mov     x22, x0                                    
02d3ce4c: ldr     x2, [x8]                                   T:type56879(k15)
02d3ce50: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d3ce54: mov     x0, x21                                    
02d3ce58: mov     x1, x22                                    
02d3ce5c: str     x22, [x19, #0x20]                          .<>9__1
02d3ce60: bl      #0x2b70d54                                 fn_2b70d54
02d3ce64: ldr     x2, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d3ce68: mov     x0, x20                                    
02d3ce6c: mov     x1, x22                                    
02d3ce70: bl      #0x336f26c                                 fn_336f26c
02d3ce74: ldr     x0, [x19, #0x10]                           .<>4__this
02d3ce78: cbz     x0, #0x2d3ce8c                             
02d3ce7c: ldp     x20, x19, [sp, #0x20]                      
02d3ce80: ldp     x22, x21, [sp, #0x10]                      
02d3ce84: ldp     x30, x23, [sp], #0x30                      
02d3ce88: b       #0x2d3c690                                 ScoopGame.BlindBox::AnimFade
02d3ce8c: bl      #0x2b7105c                                 fn_2b7105c
## <AnimOpen>b__1() -> void
---- ScoopGame.BlindBox/<>c__DisplayClass29_0::<AnimOpen>b__1 0x2d3d030
02d3d030: stp     x30, x19, [sp, #-0x10]!                    
02d3d034: mov     x19, x0                                    
02d3d038: ldr     x0, [x0, #0x10]                            .<>4__this
02d3d03c: cbz     x0, #0x2d3d084                             
02d3d040: ldrb    w8, [x0, #0x60]                            
02d3d044: cbz     w8, #0x2d3d07c                             
02d3d048: mov     x0, xzr                                    
02d3d04c: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d3d050: cbz     x0, #0x2d3d084                             
02d3d054: movi    d1, #0000000000000000                      
02d3d058: movi    d2, #0000000000000000                      
02d3d05c: mov     w1, #0x13                                  
02d3d060: fmov    s0, #1.00000000                            
02d3d064: mov     w2, wzr                                    
02d3d068: mov     w3, wzr                                    
02d3d06c: mov     x4, xzr                                    
02d3d070: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d3d074: ldr     x0, [x19, #0x10]                           .<>4__this
02d3d078: cbz     x0, #0x2d3d084                             
02d3d07c: ldp     x30, x19, [sp], #0x10                      
02d3d080: b       #0x2d3c81c                                 ScoopGame.BlindBox::ShowAtCenter
02d3d084: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS ScoopGame.BlindBox/<>c__DisplayClass30_0 parent= object
#   field color                          UnityEngine.Color                                  off=0x10 attr=6 
#   field <>4__this                      ScoopGame.BlindBox                                 off=0x20 attr=6 
## .ctor() -> void
---- ScoopGame.BlindBox/<>c__DisplayClass30_0::.ctor 0x2d3c814
02d3c814: mov     x1, xzr                                    
02d3c818: b       #0x4e53e9c                                 System.Object::.ctor
## <AnimFade>b__0() -> float
---- ScoopGame.BlindBox/<>c__DisplayClass30_0::<AnimFade>b__0 0x2d3d088
02d3d088: ldr     s0, [x0, #0x1c]                            
02d3d08c: ret                                                
## <AnimFade>b__1(float alpha) -> void
---- ScoopGame.BlindBox/<>c__DisplayClass30_0::<AnimFade>b__1 0x2d3d090
02d3d090: stp     x30, x19, [sp, #-0x10]!                    
02d3d094: ldr     x8, [x0, #0x20]                            .<>4__this
02d3d098: str     s0, [x0, #0x1c]                            
02d3d09c: cbz     x8, #0x2d3d0c8                             
02d3d0a0: mov     x19, x0                                    
02d3d0a4: ldr     x0, [x8, #0x48]                            
02d3d0a8: cbz     x0, #0x2d3d0c8                             
02d3d0ac: mov     x1, xzr                                    
02d3d0b0: bl      #0x5002600                                 Spine.Unity.SkeletonRenderer::get_Skeleton
02d3d0b4: ldp     s0, s1, [x19, #0x10]                       .color
02d3d0b8: mov     x1, xzr                                    
02d3d0bc: ldp     s2, s3, [x19, #0x18]                       
02d3d0c0: ldp     x30, x19, [sp], #0x10                      
02d3d0c4: b       #0x5014060                                 Spine.Unity.SkeletonExtensions::SetColor
02d3d0c8: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS ScoopGame.BlindBox parent= UnityEngine.MonoBehaviour
#   field _srCharm                       UnityEngine.SpriteRenderer                         off=0x20 attr=1 SerializeField
#   field _tfCharm                       UnityEngine.Transform                              off=0x28 attr=1 SerializeField
#   field _goLuck                        UnityEngine.GameObject                             off=0x30 attr=1 SerializeField
#   field _collider                      UnityEngine.Collider2D                             off=0x38 attr=1 SerializeField
#   field _sortingGroup                  UnityEngine.Rendering.SortingGroup                 off=0x40 attr=1 SerializeField
#   field _bagSkeleton                   Spine.Unity.SkeletonAnimation                      off=0x48 attr=1 SerializeField
#   field ANIM_IDLE                      string                                             off=0x0 attr=8051 
#   field BAG_OPEN                       string                                             off=0x0 attr=8051 
#   field _screenInGame                  ScoopGame.ScreenInGame                             off=0x50 attr=1 
#   field _fadeTween                     DG.Tweening.Tween                                  off=0x58 attr=1 
#   field _isLuck                        bool                                               off=0x60 attr=1 
#   field _onPlatePos                    UnityEngine.Vector3                                off=0x64 attr=1 
#   field _tfPlate                       UnityEngine.Transform                              off=0x70 attr=1 
#   field _blindBoxPlate                 ScoopGame.BlindBoxPlate                            off=0x78 attr=1 
#   field _openDone                      bool                                               off=0x80 attr=1 
#   field _dataId                        int                                                off=0x84 attr=1 
## get_IsLuck() -> bool
---- ScoopGame.BlindBox::get_IsLuck 0x2d3c0a4
02d3c0a4: ldrb    w0, [x0, #0x60]                            ._isLuck
02d3c0a8: ret                                                
## get_OpenDone() -> bool
---- ScoopGame.BlindBox::get_OpenDone 0x2d3c0ac
02d3c0ac: ldrb    w0, [x0, #0x80]                            ._openDone
02d3c0b0: ret                                                
## get_DataId() -> int
---- ScoopGame.BlindBox::get_DataId 0x2d3c0b4
02d3c0b4: ldr     w0, [x0, #0x84]                            ._dataId
02d3c0b8: ret                                                
## Init(ScoopGame.BlindBoxPlate blindBoxPlate) -> void
---- ScoopGame.BlindBox::Init 0x2d3c0bc
02d3c0bc: str     x1, [x0, #0x78]!                           ._blindBoxPlate
02d3c0c0: b       #0x2b70d54                                 
## Start() -> void
---- ScoopGame.BlindBox::Start 0x2d3c0c4
02d3c0c4: stp     x30, x21, [sp, #-0x20]!                    
02d3c0c8: stp     x20, x19, [sp, #0x10]                      
02d3c0cc: adrp    x20, #0x6630000                            
02d3c0d0: adrp    x21, #0x6267000                            
02d3c0d4: mov     x19, x0                                    
02d3c0d8: ldrb    w8, [x20, #0x165]                          
02d3c0dc: ldr     x21, [x21, #0xbd0]                         MS:MonoSingleton`1::get_Instance
02d3c0e0: tbnz    w8, #0, #0x2d3c104                         
02d3c0e4: adrp    x0, #0x6267000                             
02d3c0e8: ldr     x0, [x0, #0xbd0]                           MS:MonoSingleton`1::get_Instance
02d3c0ec: bl      #0x2b70db0                                 fn_2b70db0
02d3c0f0: adrp    x0, #0x626a000                             
02d3c0f4: ldr     x0, [x0, #0xd68]                           MS:UIManager::GetScreen
02d3c0f8: bl      #0x2b70db0                                 fn_2b70db0
02d3c0fc: mov     w8, #1                                     
02d3c100: strb    w8, [x20, #0x165]                          
02d3c104: ldr     x0, [x21]                                  S:'didu'
02d3c108: bl      #0x3769600                                 fn_3769600
02d3c10c: cbz     x0, #0x2d3c138                             
02d3c110: adrp    x8, #0x626a000                             
02d3c114: ldr     x8, [x8, #0xd68]                           MS:UIManager::GetScreen
02d3c118: ldr     x1, [x8]                                   T:type56879(k15)
02d3c11c: bl      #0x33fbbd0                                 fn_33fbbd0
02d3c120: str     x0, [x19, #0x50]!                          ._screenInGame
02d3c124: mov     x1, x0                                     
02d3c128: mov     x0, x19                                    
02d3c12c: ldp     x20, x19, [sp, #0x10]                      
02d3c130: ldp     x30, x21, [sp], #0x20                      
02d3c134: b       #0x2b70d54                                 
02d3c138: bl      #0x2b7105c                                 fn_2b7105c
## OnPointerDown(UnityEngine.EventSystems.PointerEventData eventData) -> void
---- ScoopGame.BlindBox::OnPointerDown 0x2d3c13c
02d3c13c: str     x30, [sp, #-0x30]!                         
02d3c140: stp     x22, x21, [sp, #0x10]                      
02d3c144: stp     x20, x19, [sp, #0x20]                      
02d3c148: adrp    x20, #0x6630000                            
02d3c14c: adrp    x21, #0x6266000                            
02d3c150: mov     x19, x0                                    
02d3c154: ldrb    w8, [x20, #0x166]                          
02d3c158: ldr     x21, [x21, #0x948]                         T:Touch
02d3c15c: tbnz    w8, #0, #0x2d3c198                         
02d3c160: adrp    x0, #0x6264000                             
02d3c164: ldr     x0, [x0, #0xf90]                           T:System.Action
02d3c168: bl      #0x2b70db0                                 fn_2b70db0
02d3c16c: adrp    x0, #0x6266000                             
02d3c170: ldr     x0, [x0, #0x948]                           T:Touch
02d3c174: bl      #0x2b70db0                                 fn_2b70db0
02d3c178: adrp    x0, #0x626a000                             
02d3c17c: ldr     x0, [x0, #0xd70]                           M:ScoopGame.BlindBox/<>c::<OnPointerDown>b__24_0
02d3c180: bl      #0x2b70db0                                 fn_2b70db0
02d3c184: adrp    x0, #0x626a000                             
02d3c188: ldr     x0, [x0, #0xd78]                           T:ScoopGame.BlindBox/<>c
02d3c18c: bl      #0x2b70db0                                 fn_2b70db0
02d3c190: mov     w8, #1                                     
02d3c194: strb    w8, [x20, #0x166]                          
02d3c198: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d3c19c: ldr     w8, [x0, #0xe4]                            [626a0e4]=0 f=0,0
02d3c1a0: cbnz    w8, #0x2d3c1a8                             
02d3c1a4: bl      #0x2b70f30                                 fn_2b70f30
02d3c1a8: mov     x0, xzr                                    
02d3c1ac: bl      #0x2cd6230                                 Touch::IsPointerOverUIObject
02d3c1b0: tbz     w0, #0, #0x2d3c1c4                         
02d3c1b4: ldp     x20, x19, [sp, #0x20]                      
02d3c1b8: ldp     x22, x21, [sp, #0x10]                      
02d3c1bc: ldr     x30, [sp], #0x30                           
02d3c1c0: ret                                                
02d3c1c4: adrp    x22, #0x626a000                            
02d3c1c8: mov     x0, x19                                    
02d3c1cc: ldr     x22, [x22, #0xd78]                         T:ScoopGame.BlindBox/<>c
02d3c1d0: bl      #0x2d3c274                                 ScoopGame.BlindBox::CheckPairAndRegisterData
02d3c1d4: mov     x0, x19                                    
02d3c1d8: bl      #0x2d3c304                                 ScoopGame.BlindBox::DisableBagClick
02d3c1dc: ldr     x0, [x22]                                  T:type56879(k15)
02d3c1e0: ldr     w8, [x0, #0xe4]                            [626a0e4]=0 f=0,0
02d3c1e4: cbnz    w8, #0x2d3c1f0                             
02d3c1e8: bl      #0x2b70f30                                 fn_2b70f30
02d3c1ec: ldr     x0, [x22]                                  T:type56879(k15)
02d3c1f0: ldr     x8, [x0, #0xb8]                            MS:UnityEngine.Object::FindObjectsOfType
02d3c1f4: ldr     x20, [x8, #8]                              
02d3c1f8: cbnz    x20, #0x2d3c254                            
02d3c1fc: ldr     w9, [x0, #0xe4]                            [626a0e4]=0 f=0,0
02d3c200: cbnz    w9, #0x2d3c210                             
02d3c204: bl      #0x2b70f30                                 fn_2b70f30
02d3c208: ldr     x8, [x22]                                  T:type56879(k15)
02d3c20c: ldr     x8, [x8, #0xb8]                            
02d3c210: adrp    x9, #0x6264000                             
02d3c214: ldr     x9, [x9, #0xf90]                           T:System.Action
02d3c218: ldr     x21, [x8]                                  
02d3c21c: ldr     x0, [x9]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d3c220: bl      #0x2b7104c                                 fn_2b7104c
02d3c224: adrp    x8, #0x626a000                             
02d3c228: mov     x1, x21                                    
02d3c22c: mov     x3, xzr                                    
02d3c230: ldr     x8, [x8, #0xd70]                           M:ScoopGame.BlindBox/<>c::<OnPointerDown>b__24_0
02d3c234: mov     x20, x0                                    
02d3c238: ldr     x2, [x8]                                   T:type56879(k15)
02d3c23c: bl      #0x4d8ddbc                                 System.Action::.ctor
02d3c240: ldr     x8, [x22]                                  T:type56879(k15)
02d3c244: mov     x1, x20                                    
02d3c248: ldr     x0, [x8, #0xb8]                            MS:UnityEngine.Object::FindObjectsOfType
02d3c24c: str     x20, [x0, #8]!                             
02d3c250: bl      #0x2b70d54                                 fn_2b70d54
02d3c254: cbz     x19, #0x2d3c270                            
02d3c258: mov     x0, x19                                    
02d3c25c: mov     x1, x20                                    
02d3c260: ldp     x20, x19, [sp, #0x20]                      
02d3c264: ldp     x22, x21, [sp, #0x10]                      
02d3c268: ldr     x30, [sp], #0x30                           
02d3c26c: b       #0x2d3c320                                 ScoopGame.BlindBox::AnimOpen
02d3c270: bl      #0x2b7105c                                 fn_2b7105c
## CheckPairAndRegisterData() -> void
---- ScoopGame.BlindBox::CheckPairAndRegisterData 0x2d3c274
02d3c274: stp     x30, x21, [sp, #-0x20]!                    
02d3c278: stp     x20, x19, [sp, #0x10]                      
02d3c27c: adrp    x21, #0x6630000                            
02d3c280: adrp    x20, #0x626a000                            
02d3c284: mov     x19, x0                                    
02d3c288: ldrb    w8, [x21, #0x167]                          
02d3c28c: ldr     x20, [x20, #0xd80]                         MS:MonoSingleton`1::get_Instance
02d3c290: tbnz    w8, #0, #0x2d3c2a8                         
02d3c294: adrp    x0, #0x626a000                             
02d3c298: ldr     x0, [x0, #0xd80]                           MS:MonoSingleton`1::get_Instance
02d3c29c: bl      #0x2b70db0                                 fn_2b70db0
02d3c2a0: mov     w8, #1                                     
02d3c2a4: strb    w8, [x21, #0x167]                          
02d3c2a8: ldr     x0, [x20]                                  T:type56879(k15)
02d3c2ac: bl      #0x3769600                                 fn_3769600
02d3c2b0: cbz     x0, #0x2d3c300                             
02d3c2b4: ldr     w1, [x19, #0x84]                           ._dataId
02d3c2b8: mov     x2, xzr                                    
02d3c2bc: bl      #0x2d48958                                 ScoopGame.ScoopDataHolding::ThisItemMakePair
02d3c2c0: tbz     w0, #0, #0x2d3c2e0                         
02d3c2c4: ldr     x0, [x19, #0x30]                           ._goLuck
02d3c2c8: mov     w8, #1                                     
02d3c2cc: strb    w8, [x19, #0x60]                           ._isLuck
02d3c2d0: cbz     x0, #0x2d3c300                             
02d3c2d4: mov     w1, #1                                     
02d3c2d8: mov     x2, xzr                                    
02d3c2dc: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d3c2e0: ldr     x0, [x20]                                  T:type56879(k15)
02d3c2e4: bl      #0x3769600                                 fn_3769600
02d3c2e8: cbz     x0, #0x2d3c300                             
02d3c2ec: ldr     w1, [x19, #0x84]                           ._dataId
02d3c2f0: ldp     x20, x19, [sp, #0x10]                      
02d3c2f4: mov     x2, xzr                                    
02d3c2f8: ldp     x30, x21, [sp], #0x20                      
02d3c2fc: b       #0x2d48a5c                                 ScoopGame.ScoopDataHolding::RegisterItem
02d3c300: bl      #0x2b7105c                                 fn_2b7105c
## OnEnable() -> void
---- ScoopGame.BlindBox::OnEnable 0x2d3c4f0
02d3c4f0: ret                                                
## SetVisual(string skinName) -> void
---- ScoopGame.BlindBox::SetVisual 0x2d3c4f4
02d3c4f4: stp     x30, x21, [sp, #-0x20]!                    
02d3c4f8: stp     x20, x19, [sp, #0x10]                      
02d3c4fc: adrp    x21, #0x6630000                            
02d3c500: mov     x20, x1                                    
02d3c504: mov     x19, x0                                    
02d3c508: ldrb    w8, [x21, #0x168]                          
02d3c50c: tbnz    w8, #0, #0x2d3c548                         
02d3c510: adrp    x0, #0x6263000                             
02d3c514: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02d3c518: bl      #0x2b70db0                                 fn_2b70db0
02d3c51c: adrp    x0, #0x626a000                             
02d3c520: ldr     x0, [x0, #0xd98]                           S:"Skin '"
02d3c524: bl      #0x2b70db0                                 fn_2b70db0
02d3c528: adrp    x0, #0x626a000                             
02d3c52c: ldr     x0, [x0, #0xda0]                           S:"' not found!"
02d3c530: bl      #0x2b70db0                                 fn_2b70db0
02d3c534: adrp    x0, #0x626a000                             
02d3c538: ldr     x0, [x0, #0xda8]                           S:'animation'
02d3c53c: bl      #0x2b70db0                                 fn_2b70db0
02d3c540: mov     w8, #1                                     
02d3c544: strb    w8, [x21, #0x168]                          
02d3c548: ldr     x0, [x19, #0x48]                           ._bagSkeleton
02d3c54c: cbz     x0, #0x2d3c644                             
02d3c550: mov     x1, xzr                                    
02d3c554: bl      #0x5002600                                 Spine.Unity.SkeletonRenderer::get_Skeleton
02d3c558: cbz     x0, #0x2d3c644                             
02d3c55c: ldr     x0, [x0, #0x10]                            T:Decor.DataDecor/CategoryData
02d3c560: cbz     x0, #0x2d3c644                             
02d3c564: mov     x1, x20                                    
02d3c568: mov     x2, xzr                                    
02d3c56c: bl      #0x4fb4140                                 Spine.SkeletonData::FindSkin
02d3c570: cbz     x0, #0x2d3c5ec                             
02d3c574: mov     x21, x0                                    
02d3c578: ldr     x0, [x19, #0x48]                           ._bagSkeleton
02d3c57c: cbz     x0, #0x2d3c644                             
02d3c580: mov     x1, xzr                                    
02d3c584: bl      #0x5002600                                 Spine.Unity.SkeletonRenderer::get_Skeleton
02d3c588: cbz     x0, #0x2d3c644                             
02d3c58c: mov     x1, x21                                    
02d3c590: mov     x2, xzr                                    
02d3c594: bl      #0x4fa6330                                 Spine.Skeleton::SetSkin
02d3c598: ldr     x0, [x19, #0x48]                           ._bagSkeleton
02d3c59c: cbz     x0, #0x2d3c644                             
02d3c5a0: mov     x1, xzr                                    
02d3c5a4: bl      #0x5002600                                 Spine.Unity.SkeletonRenderer::get_Skeleton
02d3c5a8: cbz     x0, #0x2d3c644                             
02d3c5ac: mov     x1, xzr                                    
02d3c5b0: bl      #0x4fa9890                                 Spine.Skeleton::SetSlotsToSetupPose
02d3c5b4: ldr     x0, [x19, #0x48]                           ._bagSkeleton
02d3c5b8: cbz     x0, #0x2d3c644                             
02d3c5bc: mov     x1, xzr                                    
02d3c5c0: bl      #0x4ff6f18                                 Spine.Unity.SkeletonAnimation::get_AnimationState
02d3c5c4: cbz     x0, #0x2d3c644                             
02d3c5c8: adrp    x8, #0x626a000                             
02d3c5cc: mov     w1, wzr                                    
02d3c5d0: mov     w3, #1                                     
02d3c5d4: ldr     x8, [x8, #0xda8]                           S:'animation'
02d3c5d8: ldp     x20, x19, [sp, #0x10]                      
02d3c5dc: mov     x4, xzr                                    
02d3c5e0: ldr     x2, [x8]                                   T:type56879(k15)
02d3c5e4: ldp     x30, x21, [sp], #0x20                      
02d3c5e8: b       #0x4f97234                                 Spine.AnimationState::SetAnimation
02d3c5ec: adrp    x8, #0x626a000                             
02d3c5f0: adrp    x9, #0x626a000                             
02d3c5f4: mov     x1, x20                                    
02d3c5f8: ldr     x8, [x8, #0xd98]                           S:"Skin '"
02d3c5fc: ldr     x9, [x9, #0xda0]                           S:"' not found!"
02d3c600: mov     x3, xzr                                    
02d3c604: ldr     x0, [x8]                                   T:type56879(k15)
02d3c608: ldr     x2, [x9]                                   T:type56879(k15)
02d3c60c: bl      #0x4ca6dbc                                 System.String::Concat
02d3c610: adrp    x8, #0x6263000                             
02d3c614: mov     x19, x0                                    
02d3c618: ldr     x8, [x8, #0x928]                           T:UnityEngine.Debug
02d3c61c: ldr     x8, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02d3c620: ldr     w9, [x8, #0xe4]                            [62630e4]=0 f=0,0
02d3c624: cbnz    w9, #0x2d3c630                             
02d3c628: mov     x0, x8                                     
02d3c62c: bl      #0x2b70f30                                 fn_2b70f30
02d3c630: mov     x0, x19                                    
02d3c634: ldp     x20, x19, [sp, #0x10]                      
02d3c638: mov     x1, xzr                                    
02d3c63c: ldp     x30, x21, [sp], #0x20                      
02d3c640: b       #0x5af2c94                                 UnityEngine.Debug::LogWarning
02d3c644: bl      #0x2b7105c                                 fn_2b7105c
## SetCharm(int id, UnityEngine.Sprite sprite) -> void
---- ScoopGame.BlindBox::SetCharm 0x2d3c648
02d3c648: stp     x30, x19, [sp, #-0x10]!                    
02d3c64c: mov     x19, x0                                    
02d3c650: ldr     x0, [x0, #0x20]                            ._srCharm
02d3c654: str     w1, [x19, #0x84]                           ._dataId
02d3c658: cbz     x0, #0x2d3c684                             
02d3c65c: mov     x1, x2                                     
02d3c660: mov     x2, xzr                                    
02d3c664: bl      #0x5ae6dcc                                 UnityEngine.SpriteRenderer::set_sprite
02d3c668: ldr     x0, [x19, #0x30]                           ._goLuck
02d3c66c: strb    wzr, [x19, #0x60]                          ._isLuck
02d3c670: cbz     x0, #0x2d3c684                             
02d3c674: mov     w1, wzr                                    
02d3c678: mov     x2, xzr                                    
02d3c67c: ldp     x30, x19, [sp], #0x10                      
02d3c680: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d3c684: bl      #0x2b7105c                                 fn_2b7105c
## AnimOpen(System.Action onComplete) -> void
---- ScoopGame.BlindBox::AnimOpen 0x2d3c320
02d3c320: str     x30, [sp, #-0x30]!                         
02d3c324: stp     x22, x21, [sp, #0x10]                      
02d3c328: stp     x20, x19, [sp, #0x20]                      
02d3c32c: adrp    x19, #0x6630000                            
02d3c330: adrp    x22, #0x626a000                            
02d3c334: mov     x21, x1                                    
02d3c338: ldrb    w8, [x19, #0x169]                          
02d3c33c: ldr     x22, [x22, #0xd88]                         T:ScoopGame.BlindBox/<>c__DisplayClass29_0
02d3c340: mov     x20, x0                                    
02d3c344: tbnz    w8, #0, #0x2d3c38c                         
02d3c348: adrp    x0, #0x6264000                             
02d3c34c: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d3c350: bl      #0x2b70db0                                 fn_2b70db0
02d3c354: adrp    x0, #0x626a000                             
02d3c358: ldr     x0, [x0, #0xd90]                           M:ScoopGame.BlindBox/<>c__DisplayClass29_0::<AnimOpen>b__0
02d3c35c: bl      #0x2b70db0                                 fn_2b70db0
02d3c360: adrp    x0, #0x626a000                             
02d3c364: ldr     x0, [x0, #0xd88]                           T:ScoopGame.BlindBox/<>c__DisplayClass29_0
02d3c368: bl      #0x2b70db0                                 fn_2b70db0
02d3c36c: adrp    x0, #0x6267000                             
02d3c370: ldr     x0, [x0, #0xea8]                           T:Framework.Vibration
02d3c374: bl      #0x2b70db0                                 fn_2b70db0
02d3c378: adrp    x0, #0x626a000                             
02d3c37c: ldr     x0, [x0, #0x7d0]                           S:'bag_open'
02d3c380: bl      #0x2b70db0                                 fn_2b70db0
02d3c384: mov     w8, #1                                     
02d3c388: strb    w8, [x19, #0x169]                          
02d3c38c: ldr     x0, [x22]                                  T:type56879(k15)
02d3c390: bl      #0x2b7104c                                 fn_2b7104c
02d3c394: mov     x1, xzr                                    
02d3c398: mov     x19, x0                                    
02d3c39c: bl      #0x4e53e9c                                 System.Object::.ctor
02d3c3a0: cbz     x19, #0x2d3c4ec                            
02d3c3a4: mov     x0, x19                                    
02d3c3a8: mov     x1, x20                                    
02d3c3ac: str     x20, [x0, #0x10]!                          
02d3c3b0: bl      #0x2b70d54                                 fn_2b70d54
02d3c3b4: mov     x0, x19                                    
02d3c3b8: mov     x1, x21                                    
02d3c3bc: str     x21, [x0, #0x18]!                          
02d3c3c0: bl      #0x2b70d54                                 fn_2b70d54
02d3c3c4: mov     x0, xzr                                    
02d3c3c8: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d3c3cc: cbz     x0, #0x2d3c4ec                             
02d3c3d0: movi    d1, #0000000000000000                      
02d3c3d4: movi    d2, #0000000000000000                      
02d3c3d8: mov     w1, #0x10                                  
02d3c3dc: fmov    s0, #1.00000000                            
02d3c3e0: mov     w2, wzr                                    
02d3c3e4: mov     w3, wzr                                    
02d3c3e8: mov     x4, xzr                                    
02d3c3ec: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d3c3f0: mov     x0, xzr                                    
02d3c3f4: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d3c3f8: cbz     x0, #0x2d3c4ec                             
02d3c3fc: movi    d1, #0000000000000000                      
02d3c400: movi    d2, #0000000000000000                      
02d3c404: adrp    x21, #0x6267000                            
02d3c408: fmov    s0, #1.00000000                            
02d3c40c: ldr     x21, [x21, #0xea8]                         T:Framework.Vibration
02d3c410: mov     w1, #0x12                                  
02d3c414: mov     w2, wzr                                    
02d3c418: mov     w3, wzr                                    
02d3c41c: mov     x4, xzr                                    
02d3c420: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d3c424: ldr     x0, [x21]                                  S:'didu'
02d3c428: ldr     w8, [x0, #0xe4]                            [626a0e4]=0 f=0,0
02d3c42c: cbnz    w8, #0x2d3c434                             
02d3c430: bl      #0x2b70f30                                 fn_2b70f30
02d3c434: mov     w0, #0x3c                                  
02d3c438: mov     w1, #-1                                    
02d3c43c: mov     w2, wzr                                    
02d3c440: mov     x3, xzr                                    
02d3c444: bl      #0x2d6e144                                 Framework.Vibration::Vibrate
02d3c448: ldr     x21, [x20, #0x40]                          ._sortingGroup
02d3c44c: cbz     x21, #0x2d3c4ec                            
02d3c450: mov     x0, x21                                    
02d3c454: mov     x1, xzr                                    
02d3c458: bl      #0x5b547d4                                 UnityEngine.Rendering.SortingGroup::get_sortingOrder
02d3c45c: add     w1, w0, #3                                 
02d3c460: mov     x0, x21                                    
02d3c464: mov     x2, xzr                                    
02d3c468: bl      #0x5b54884                                 UnityEngine.Rendering.SortingGroup::set_sortingOrder
02d3c46c: ldr     x0, [x20, #0x48]                           ._bagSkeleton
02d3c470: cbz     x0, #0x2d3c4ec                             
02d3c474: mov     x1, xzr                                    
02d3c478: bl      #0x4ff6f18                                 Spine.Unity.SkeletonAnimation::get_AnimationState
02d3c47c: cbz     x0, #0x2d3c4ec                             
02d3c480: adrp    x8, #0x626a000                             
02d3c484: adrp    x20, #0x6264000                            
02d3c488: adrp    x21, #0x626a000                            
02d3c48c: ldr     x8, [x8, #0x7d0]                           S:'bag_open'
02d3c490: ldr     x20, [x20, #0xe8]                          T:DG.Tweening.TweenCallback
02d3c494: ldr     x21, [x21, #0xd90]                         M:ScoopGame.BlindBox/<>c__DisplayClass29_0::<AnimOpen>b__0
02d3c498: mov     w1, wzr                                    
02d3c49c: mov     w3, wzr                                    
02d3c4a0: mov     x4, xzr                                    
02d3c4a4: ldr     x2, [x8]                                   T:type56879(k15)
02d3c4a8: bl      #0x4f97234                                 Spine.AnimationState::SetAnimation
02d3c4ac: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d3c4b0: bl      #0x2b7104c                                 fn_2b7104c
02d3c4b4: ldr     x2, [x21]                                  T:type56879(k15)
02d3c4b8: mov     x1, x19                                    
02d3c4bc: mov     x3, xzr                                    
02d3c4c0: mov     x20, x0                                    
02d3c4c4: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d3c4c8: adrp    x8, #0x1084000                             
02d3c4cc: mov     x0, x20                                    
02d3c4d0: mov     w1, #1                                     
02d3c4d4: ldp     x20, x19, [sp, #0x20]                      
02d3c4d8: ldr     s0, [x8, #0xfb0]                           [1084fb0]=3f7d70a43ecccccd f=0.4,0.99
02d3c4dc: ldp     x22, x21, [sp, #0x10]                      
02d3c4e0: mov     x2, xzr                                    
02d3c4e4: ldr     x30, [sp], #0x30                           
02d3c4e8: b       #0x2d8f37c                                 DG.Tweening.DOVirtual::DelayedCall
02d3c4ec: bl      #0x2b7105c                                 fn_2b7105c
## AnimFade() -> void
---- ScoopGame.BlindBox::AnimFade 0x2d3c690
02d3c690: stp     x30, x25, [sp, #-0x40]!                    
02d3c694: stp     x24, x23, [sp, #0x10]                      
02d3c698: stp     x22, x21, [sp, #0x20]                      
02d3c69c: stp     x20, x19, [sp, #0x30]                      
02d3c6a0: adrp    x19, #0x6630000                            
02d3c6a4: adrp    x20, #0x626a000                            
02d3c6a8: mov     x21, x0                                    
02d3c6ac: ldrb    w8, [x19, #0x16a]                          
02d3c6b0: ldr     x20, [x20, #0xdb0]                         T:ScoopGame.BlindBox/<>c__DisplayClass30_0
02d3c6b4: tbnz    w8, #0, #0x2d3c708                         
02d3c6b8: adrp    x0, #0x6263000                             
02d3c6bc: ldr     x0, [x0, #0xfc0]                           T:type8528(k15)
02d3c6c0: bl      #0x2b70db0                                 fn_2b70db0
02d3c6c4: adrp    x0, #0x6263000                             
02d3c6c8: ldr     x0, [x0, #0xfc8]                           T:type8550(k15)
02d3c6cc: bl      #0x2b70db0                                 fn_2b70db0
02d3c6d0: adrp    x0, #0x6263000                             
02d3c6d4: ldr     x0, [x0, #0xfd0]                           T:DG.Tweening.DOTween
02d3c6d8: bl      #0x2b70db0                                 fn_2b70db0
02d3c6dc: adrp    x0, #0x626a000                             
02d3c6e0: ldr     x0, [x0, #0xdb8]                           M:ScoopGame.BlindBox/<>c__DisplayClass30_0::<AnimFade>b__0
02d3c6e4: bl      #0x2b70db0                                 fn_2b70db0
02d3c6e8: adrp    x0, #0x626a000                             
02d3c6ec: ldr     x0, [x0, #0xdc0]                           M:ScoopGame.BlindBox/<>c__DisplayClass30_0::<AnimFade>b__1
02d3c6f0: bl      #0x2b70db0                                 fn_2b70db0
02d3c6f4: adrp    x0, #0x626a000                             
02d3c6f8: ldr     x0, [x0, #0xdb0]                           T:ScoopGame.BlindBox/<>c__DisplayClass30_0
02d3c6fc: bl      #0x2b70db0                                 fn_2b70db0
02d3c700: mov     w8, #1                                     
02d3c704: strb    w8, [x19, #0x16a]                          
02d3c708: ldr     x0, [x20]                                  T:type56879(k15)
02d3c70c: bl      #0x2b7104c                                 fn_2b7104c
02d3c710: mov     x1, xzr                                    
02d3c714: mov     x20, x0                                    
02d3c718: bl      #0x4e53e9c                                 System.Object::.ctor
02d3c71c: cbz     x20, #0x2d3c810                            
02d3c720: mov     x0, x20                                    
02d3c724: mov     x1, x21                                    
02d3c728: str     x21, [x0, #0x20]!                          ._srCharm
02d3c72c: bl      #0x2b70d54                                 fn_2b70d54
02d3c730: mov     x19, x21                                   
02d3c734: ldr     x0, [x19, #0x58]!                          ._fadeTween
02d3c738: cbz     x0, #0x2d3c748                             
02d3c73c: mov     w1, wzr                                    
02d3c740: mov     x2, xzr                                    
02d3c744: bl      #0x2d8fe94                                 DG.Tweening.TweenExtensions::Kill
02d3c748: ldr     x0, [x21, #0x48]                           ._bagSkeleton
02d3c74c: cbz     x0, #0x2d3c810                             
02d3c750: adrp    x21, #0x6263000                            
02d3c754: adrp    x22, #0x626a000                            
02d3c758: adrp    x23, #0x6263000                            
02d3c75c: adrp    x24, #0x626a000                            
02d3c760: adrp    x25, #0x6263000                            
02d3c764: ldr     x21, [x21, #0xfc0]                         T:type8528(k15)
02d3c768: ldr     x22, [x22, #0xdb8]                         M:ScoopGame.BlindBox/<>c__DisplayClass30_0::<AnimFade>b__0
02d3c76c: ldr     x23, [x23, #0xfc8]                         T:type8550(k15)
02d3c770: ldr     x24, [x24, #0xdc0]                         M:ScoopGame.BlindBox/<>c__DisplayClass30_0::<AnimFade>b__1
02d3c774: ldr     x25, [x25, #0xfd0]                         T:DG.Tweening.DOTween
02d3c778: mov     x1, xzr                                    
02d3c77c: bl      #0x5002600                                 Spine.Unity.SkeletonRenderer::get_Skeleton
02d3c780: mov     x1, xzr                                    
02d3c784: bl      #0x5013fe4                                 Spine.Unity.SkeletonExtensions::GetColor
02d3c788: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d3c78c: stp     s0, s1, [x20, #0x10]                       
02d3c790: stp     s2, s3, [x20, #0x18]                       
02d3c794: bl      #0x2b7104c                                 fn_2b7104c
02d3c798: ldr     x2, [x22]                                  T:type56879(k15)
02d3c79c: mov     x1, x20                                    
02d3c7a0: mov     x3, xzr                                    
02d3c7a4: mov     x21, x0                                    
02d3c7a8: bl      #0x44536ec                                 fn_44536ec
02d3c7ac: ldr     x0, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d3c7b0: bl      #0x2b7104c                                 fn_2b7104c
02d3c7b4: ldr     x2, [x24]                                  T:type56879(k15)
02d3c7b8: mov     x1, x20                                    
02d3c7bc: mov     x3, xzr                                    
02d3c7c0: mov     x22, x0                                    
02d3c7c4: bl      #0x4454818                                 fn_4454818
02d3c7c8: ldr     x0, [x25]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d3c7cc: ldr     w8, [x0, #0xe4]                            [626a0e4]=0 f=0,0
02d3c7d0: cbnz    w8, #0x2d3c7d8                             
02d3c7d4: bl      #0x2b70f30                                 fn_2b70f30
02d3c7d8: movi    d0, #0000000000000000                      
02d3c7dc: fmov    s1, #0.50000000                            
02d3c7e0: mov     x0, x21                                    
02d3c7e4: mov     x1, x22                                    
02d3c7e8: mov     x2, xzr                                    
02d3c7ec: bl      #0x2d8b3b4                                 DG.Tweening.DOTween::To
02d3c7f0: mov     x1, x0                                     
02d3c7f4: mov     x0, x19                                    
02d3c7f8: str     x1, [x19]                                  
02d3c7fc: ldp     x20, x19, [sp, #0x30]                      
02d3c800: ldp     x22, x21, [sp, #0x20]                      
02d3c804: ldp     x24, x23, [sp, #0x10]                      
02d3c808: ldp     x30, x25, [sp], #0x40                      
02d3c80c: b       #0x2b70d54                                 
02d3c810: bl      #0x2b7105c                                 fn_2b7105c
## ShowAtCenter() -> void
---- ScoopGame.BlindBox::ShowAtCenter 0x2d3c81c
02d3c81c: stp     x30, x25, [sp, #-0x40]!                    
02d3c820: stp     x24, x23, [sp, #0x10]                      
02d3c824: stp     x22, x21, [sp, #0x20]                      
02d3c828: stp     x20, x19, [sp, #0x30]                      
02d3c82c: adrp    x20, #0x6630000                            
02d3c830: mov     x19, x0                                    
02d3c834: ldrb    w8, [x20, #0x16b]                          
02d3c838: tbnz    w8, #0, #0x2d3c868                         
02d3c83c: adrp    x0, #0x626a000                             
02d3c840: ldr     x0, [x0, #0xdc8]                           M:ScoopGame.BlindBox::<ShowAtCenter>b__31_0
02d3c844: bl      #0x2b70db0                                 fn_2b70db0
02d3c848: adrp    x0, #0x6264000                             
02d3c84c: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d3c850: bl      #0x2b70db0                                 fn_2b70db0
02d3c854: adrp    x0, #0x6267000                             
02d3c858: ldr     x0, [x0, #0xd30]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d3c85c: bl      #0x2b70db0                                 fn_2b70db0
02d3c860: mov     w8, #1                                     
02d3c864: strb    w8, [x20, #0x16b]                          
02d3c868: mov     x0, x19                                    
02d3c86c: mov     x1, xzr                                    
02d3c870: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d3c874: adrp    x21, #0x662f000                            
02d3c878: mov     x20, x0                                    
02d3c87c: ldrb    w8, [x21, #0x918]                          
02d3c880: cbnz    w8, #0x2d3c898                             
02d3c884: adrp    x0, #0x6264000                             
02d3c888: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d3c88c: bl      #0x2b70db0                                 fn_2b70db0
02d3c890: mov     w8, #1                                     
02d3c894: strb    w8, [x21, #0x918]                          
02d3c898: adrp    x24, #0x6264000                            
02d3c89c: fmov    s3, #0.50000000                            
02d3c8a0: adrp    x23, #0x6264000                            
02d3c8a4: ldr     x24, [x24, #0xd8]                          T:UnityEngine.Vector3
02d3c8a8: adrp    x21, #0x626a000                            
02d3c8ac: adrp    x22, #0x6267000                            
02d3c8b0: mov     x0, x20                                    
02d3c8b4: mov     w1, wzr                                    
02d3c8b8: mov     x2, xzr                                    
02d3c8bc: ldr     x8, [x24]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d3c8c0: ldr     x8, [x8, #0xb8]                            
02d3c8c4: ldr     d0, [x8, #0x18]                            
02d3c8c8: ldr     s1, [x8, #0x20]                            
02d3c8cc: ldr     x23, [x23, #0xe8]                          T:DG.Tweening.TweenCallback
02d3c8d0: ldr     x21, [x21, #0xdc8]                         M:ScoopGame.BlindBox::<ShowAtCenter>b__31_0
02d3c8d4: ldr     x22, [x22, #0xd30]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d3c8d8: fadd    v0.2s, v0.2s, v0.2s                        
02d3c8dc: fadd    s2, s1, s1                                 
02d3c8e0: mov     s1, v0.s[1]                                
02d3c8e4: bl      #0x2d975e4                                 DG.Tweening.ShortcutExtensions::DOMove
02d3c8e8: mov     x0, x19                                    
02d3c8ec: mov     x1, xzr                                    
02d3c8f0: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d3c8f4: adrp    x25, #0x662f000                            
02d3c8f8: mov     x20, x0                                    
02d3c8fc: ldrb    w8, [x25, #0x91a]                          
02d3c900: cbnz    w8, #0x2d3c918                             
02d3c904: adrp    x0, #0x6264000                             
02d3c908: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d3c90c: bl      #0x2b70db0                                 fn_2b70db0
02d3c910: mov     w8, #1                                     
02d3c914: strb    w8, [x25, #0x91a]                          
02d3c918: ldr     x8, [x24]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d3c91c: fmov    s3, #0.50000000                            
02d3c920: mov     x0, x20                                    
02d3c924: mov     w1, wzr                                    
02d3c928: mov     x2, xzr                                    
02d3c92c: ldr     x8, [x8, #0xb8]                            
02d3c930: ldp     s0, s1, [x8]                               
02d3c934: ldr     s2, [x8, #8]                               
02d3c938: bl      #0x2d983c8                                 DG.Tweening.ShortcutExtensions::DORotate
02d3c93c: ldr     x8, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d3c940: mov     x20, x0                                    
02d3c944: mov     x0, x8                                     
02d3c948: bl      #0x2b7104c                                 fn_2b7104c
02d3c94c: ldr     x2, [x21]                                  T:type56879(k15)
02d3c950: mov     x1, x19                                    
02d3c954: mov     x3, xzr                                    
02d3c958: mov     x21, x0                                    
02d3c95c: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d3c960: ldr     x2, [x22]                                  S:'didu'
02d3c964: mov     x0, x20                                    
02d3c968: mov     x1, x21                                    
02d3c96c: ldp     x20, x19, [sp, #0x30]                      
02d3c970: ldp     x22, x21, [sp, #0x20]                      
02d3c974: ldp     x24, x23, [sp, #0x10]                      
02d3c978: ldp     x30, x25, [sp], #0x40                      
02d3c97c: b       #0x336f26c                                 
## MoveToTray() -> void
---- ScoopGame.BlindBox::MoveToTray 0x2d3c980
02d3c980: stp     x30, x21, [sp, #-0x20]!                    
02d3c984: stp     x20, x19, [sp, #0x10]                      
02d3c988: adrp    x21, #0x6630000                            
02d3c98c: adrp    x20, #0x6263000                            
02d3c990: mov     x19, x0                                    
02d3c994: ldrb    w8, [x21, #0x16c]                          
02d3c998: ldr     x20, [x20, #0x918]                         T:UnityEngine.Object
02d3c99c: tbnz    w8, #0, #0x2d3c9d8                         
02d3c9a0: adrp    x0, #0x626a000                             
02d3c9a4: ldr     x0, [x0, #0xdd0]                           M:ScoopGame.BlindBox::<MoveToTray>b__32_0
02d3c9a8: bl      #0x2b70db0                                 fn_2b70db0
02d3c9ac: adrp    x0, #0x6263000                             
02d3c9b0: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d3c9b4: bl      #0x2b70db0                                 fn_2b70db0
02d3c9b8: adrp    x0, #0x6264000                             
02d3c9bc: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d3c9c0: bl      #0x2b70db0                                 fn_2b70db0
02d3c9c4: adrp    x0, #0x626a000                             
02d3c9c8: ldr     x0, [x0, #0xdd8]                           MS:DG.Tweening.TweenSettingsExtensions::OnStart
02d3c9cc: bl      #0x2b70db0                                 fn_2b70db0
02d3c9d0: mov     w8, #1                                     
02d3c9d4: strb    w8, [x21, #0x16c]                          
02d3c9d8: ldr     x0, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d3c9dc: ldr     x20, [x19, #0x70]                          ._tfPlate
02d3c9e0: ldr     w8, [x0, #0xe4]                            [626a0e4]=0 f=0,0
02d3c9e4: cbnz    w8, #0x2d3c9ec                             
02d3c9e8: bl      #0x2b70f30                                 fn_2b70f30
02d3c9ec: mov     x0, x20                                    
02d3c9f0: mov     x1, xzr                                    
02d3c9f4: mov     x2, xzr                                    
02d3c9f8: bl      #0x5b37d84                                 UnityEngine.Object::op_Equality
02d3c9fc: tbz     w0, #0, #0x2d3ca0c                         
02d3ca00: ldp     x20, x19, [sp, #0x10]                      
02d3ca04: ldp     x30, x21, [sp], #0x20                      
02d3ca08: ret                                                
02d3ca0c: ldr     x20, [x19, #0x40]                          ._sortingGroup
02d3ca10: cbz     x20, #0x2d3cb04                            
02d3ca14: mov     x0, x20                                    
02d3ca18: mov     x1, xzr                                    
02d3ca1c: bl      #0x5b547d4                                 UnityEngine.Rendering.SortingGroup::get_sortingOrder
02d3ca20: sub     w1, w0, #3                                 
02d3ca24: mov     x0, x20                                    
02d3ca28: mov     x2, xzr                                    
02d3ca2c: bl      #0x5b54884                                 UnityEngine.Rendering.SortingGroup::set_sortingOrder
02d3ca30: mov     x0, x19                                    
02d3ca34: mov     x1, xzr                                    
02d3ca38: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d3ca3c: cbz     x0, #0x2d3cb04                             
02d3ca40: ldr     x1, [x19, #0x70]                           ._tfPlate
02d3ca44: mov     x2, xzr                                    
02d3ca48: bl      #0x5b472ec                                 UnityEngine.Transform::SetParent
02d3ca4c: mov     x0, x19                                    
02d3ca50: mov     x1, xzr                                    
02d3ca54: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d3ca58: mov     w1, wzr                                    
02d3ca5c: mov     x2, xzr                                    
02d3ca60: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d3ca64: mov     x0, x19                                    
02d3ca68: mov     x1, xzr                                    
02d3ca6c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d3ca70: adrp    x8, #0x1084000                             
02d3ca74: fmov    s1, #0.50000000                            
02d3ca78: mov     x1, xzr                                    
02d3ca7c: ldr     s0, [x8, #0xf90]                           [1084f90]=38d1b7173ee66666 f=0.45,0.0001
02d3ca80: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02d3ca84: mov     x0, x19                                    
02d3ca88: mov     x1, xzr                                    
02d3ca8c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d3ca90: ldp     s0, s1, [x19, #0x64]                       ._onPlatePos
02d3ca94: fmov    s3, #1.00000000                            
02d3ca98: fmov    s4, #0.50000000                            
02d3ca9c: ldr     s2, [x19, #0x6c]                           
02d3caa0: mov     w1, #1                                     
02d3caa4: mov     w2, wzr                                    
02d3caa8: mov     x3, xzr                                    
02d3caac: bl      #0x2d9abb0                                 DG.Tweening.ShortcutExtensions::DOJump
02d3cab0: adrp    x8, #0x6264000                             
02d3cab4: mov     x20, x0                                    
02d3cab8: ldr     x8, [x8, #0xe8]                            T:DG.Tweening.TweenCallback
02d3cabc: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d3cac0: mov     x0, x8                                     
02d3cac4: bl      #0x2b7104c                                 fn_2b7104c
02d3cac8: adrp    x8, #0x626a000                             
02d3cacc: mov     x1, x19                                    
02d3cad0: mov     x3, xzr                                    
02d3cad4: ldr     x8, [x8, #0xdd0]                           M:ScoopGame.BlindBox::<MoveToTray>b__32_0
02d3cad8: mov     x21, x0                                    
02d3cadc: ldr     x2, [x8]                                   T:type56879(k15)
02d3cae0: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d3cae4: adrp    x8, #0x626a000                             
02d3cae8: mov     x0, x20                                    
02d3caec: mov     x1, x21                                    
02d3caf0: ldr     x8, [x8, #0xdd8]                           MS:DG.Tweening.TweenSettingsExtensions::OnStart
02d3caf4: ldp     x20, x19, [sp, #0x10]                      
02d3caf8: ldr     x2, [x8]                                   T:type56879(k15)
02d3cafc: ldp     x30, x21, [sp], #0x20                      
02d3cb00: b       #0x336f348                                 
02d3cb04: bl      #0x2b7105c                                 fn_2b7105c
## EnableClick() -> void
---- ScoopGame.BlindBox::EnableClick 0x2d3cb08
02d3cb08: ldr     x0, [x0, #0x38]                            ._collider
02d3cb0c: cbz     x0, #0x2d3cb1c                             
02d3cb10: mov     w1, #1                                     
02d3cb14: mov     x2, xzr                                    
02d3cb18: b       #0x5b33110                                 UnityEngine.Behaviour::set_enabled
02d3cb1c: str     x30, [sp, #-0x10]!                         
02d3cb20: bl      #0x2b7105c                                 fn_2b7105c
## DisableBagClick() -> void
---- ScoopGame.BlindBox::DisableBagClick 0x2d3c304
02d3c304: ldr     x0, [x0, #0x38]                            ._collider
02d3c308: cbz     x0, #0x2d3c318                             
02d3c30c: mov     w1, wzr                                    
02d3c310: mov     x2, xzr                                    
02d3c314: b       #0x5b33110                                 UnityEngine.Behaviour::set_enabled
02d3c318: str     x30, [sp, #-0x10]!                         
02d3c31c: bl      #0x2b7105c                                 fn_2b7105c
## SetDestination(UnityEngine.Transform tfPlate, UnityEngine.Vector3 landingPos) -> void
---- ScoopGame.BlindBox::SetDestination 0x2d3cb24
02d3cb24: str     d10, [sp, #-0x30]!                         
02d3cb28: stp     d9, d8, [sp, #0x10]                        
02d3cb2c: stp     x30, x19, [sp, #0x20]                      
02d3cb30: mov     x19, x0                                    
02d3cb34: fmov    s8, s2                                     
02d3cb38: fmov    s9, s1                                     
02d3cb3c: str     x1, [x19, #0x70]!                          ._tfPlate
02d3cb40: mov     x0, x19                                    
02d3cb44: fmov    s10, s0                                    
02d3cb48: bl      #0x2b70d54                                 fn_2b70d54
02d3cb4c: stp     s10, s9, [x19, #-0xc]                      
02d3cb50: stur    s8, [x19, #-4]                             
02d3cb54: ldp     x30, x19, [sp, #0x20]                      
02d3cb58: ldp     d9, d8, [sp, #0x10]                        
02d3cb5c: ldr     d10, [sp], #0x30                           
02d3cb60: ret                                                
## .ctor() -> void
---- ScoopGame.BlindBox::.ctor 0x2d3cb64
02d3cb64: str     x30, [sp, #-0x20]!                         
02d3cb68: stp     x20, x19, [sp, #0x10]                      
02d3cb6c: adrp    x20, #0x662f000                            
02d3cb70: mov     x19, x0                                    
02d3cb74: ldrb    w8, [x20, #0x91a]                          
02d3cb78: cbnz    w8, #0x2d3cb90                             
02d3cb7c: adrp    x0, #0x6264000                             
02d3cb80: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d3cb84: bl      #0x2b70db0                                 fn_2b70db0
02d3cb88: mov     w8, #1                                     
02d3cb8c: strb    w8, [x20, #0x91a]                          
02d3cb90: adrp    x8, #0x6264000                             
02d3cb94: mov     x0, x19                                    
02d3cb98: mov     x1, xzr                                    
02d3cb9c: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02d3cba0: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d3cba4: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d3cba8: ldr     d0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d3cbac: ldr     s1, [x8, #8]                               T:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0
02d3cbb0: stur    d0, [x19, #0x64]                           ._onPlatePos
02d3cbb4: str     s1, [x19, #0x6c]                           
02d3cbb8: ldp     x20, x19, [sp, #0x10]                      
02d3cbbc: ldr     x30, [sp], #0x20                           
02d3cbc0: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
## <ShowAtCenter>b__31_0() -> void
---- ScoopGame.BlindBox::<ShowAtCenter>b__31_0 0x2d3cbc4
02d3cbc4: stp     x30, x23, [sp, #-0x30]!                    
02d3cbc8: stp     x22, x21, [sp, #0x10]                      
02d3cbcc: stp     x20, x19, [sp, #0x20]                      
02d3cbd0: adrp    x20, #0x6630000                            
02d3cbd4: mov     x19, x0                                    
02d3cbd8: ldrb    w8, [x20, #0x16d]                          
02d3cbdc: tbnz    w8, #0, #0x2d3cc00                         
02d3cbe0: adrp    x0, #0x6264000                             
02d3cbe4: ldr     x0, [x0, #0xf90]                           T:System.Action
02d3cbe8: bl      #0x2b70db0                                 fn_2b70db0
02d3cbec: adrp    x0, #0x626a000                             
02d3cbf0: ldr     x0, [x0, #0xde0]                           M:ScoopGame.BlindBox::<ShowAtCenter>b__31_1
02d3cbf4: bl      #0x2b70db0                                 fn_2b70db0
02d3cbf8: mov     w8, #1                                     
02d3cbfc: strb    w8, [x20, #0x16d]                          
02d3cc00: ldr     x0, [x19, #0x30]                           ._goLuck
02d3cc04: cbz     x0, #0x2d3cc8c                             
02d3cc08: mov     w1, wzr                                    
02d3cc0c: mov     x2, xzr                                    
02d3cc10: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d3cc14: ldr     x0, [x19, #0x20]                           ._srCharm
02d3cc18: cbz     x0, #0x2d3cc8c                             
02d3cc1c: adrp    x21, #0x6264000                            
02d3cc20: adrp    x22, #0x626a000                            
02d3cc24: mov     x1, xzr                                    
02d3cc28: ldr     x21, [x21, #0xf90]                         T:System.Action
02d3cc2c: ldr     x22, [x22, #0xde0]                         M:ScoopGame.BlindBox::<ShowAtCenter>b__31_1
02d3cc30: ldr     x20, [x19, #0x50]                          ._screenInGame
02d3cc34: bl      #0x5ae6cfc                                 UnityEngine.SpriteRenderer::get_sprite
02d3cc38: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d3cc3c: ldrb    w23, [x19, #0x60]                          ._isLuck
02d3cc40: mov     x21, x0                                    
02d3cc44: mov     x0, x8                                     
02d3cc48: bl      #0x2b7104c                                 fn_2b7104c
02d3cc4c: ldr     x2, [x22]                                  T:type56879(k15)
02d3cc50: mov     x1, x19                                    
02d3cc54: mov     x3, xzr                                    
02d3cc58: mov     x22, x0                                    
02d3cc5c: bl      #0x4d8ddbc                                 System.Action::.ctor
02d3cc60: cbz     x20, #0x2d3cc8c                            
02d3cc64: mov     x0, x20                                    
02d3cc68: mov     x1, x21                                    
02d3cc6c: mov     x3, x22                                    
02d3cc70: ldp     x20, x19, [sp, #0x20]                      
02d3cc74: cmp     w23, #0                                    
02d3cc78: ldp     x22, x21, [sp, #0x10]                      
02d3cc7c: cset    w2, ne                                     
02d3cc80: mov     x4, xzr                                    
02d3cc84: ldp     x30, x23, [sp], #0x30                      
02d3cc88: b       #0x2d4bf0c                                 ScoopGame.ScreenInGame::ShowCharmFlyToBasket
02d3cc8c: bl      #0x2b7105c                                 fn_2b7105c
## <ShowAtCenter>b__31_1() -> void
---- ScoopGame.BlindBox::<ShowAtCenter>b__31_1 0x2d3cc90
02d3cc90: b       #0x2d3c980                                 ScoopGame.BlindBox::MoveToTray
## <MoveToTray>b__32_0() -> void
---- ScoopGame.BlindBox::<MoveToTray>b__32_0 0x2d3cc94
02d3cc94: mov     w8, #1                                     
02d3cc98: strb    w8, [x0, #0x80]                            ._openDone
02d3cc9c: ret                                                
