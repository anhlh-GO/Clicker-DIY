#### CLASS Clicker.DraggableKeychain parent= Clicker.DraggableClickerItem
## .ctor() -> void
---- Clicker.DraggableKeychain::.ctor 0x2d61d28
02d61d28: mov     w8, #-1                                    
02d61d2c: mov     x1, xzr                                    
02d61d30: str     w8, [x0, #0x58]                            
02d61d34: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
