#### CLASS Clicker.CategoryButton parent= UnityEngine.MonoBehaviour
#   field _goSelected                    UnityEngine.GameObject                             off=0x20 attr=1 SerializeField
#   field _tfIcon                        UnityEngine.Transform                              off=0x28 attr=1 SerializeField
#   field _buttonThis                    UnityEngine.UI.Button                              off=0x30 attr=1 SerializeField
## get_Button() -> UnityEngine.UI.Button
---- Clicker.CategoryButton::get_Button 0x2d664bc
02d664bc: ldr     x0, [x0, #0x30]                            ._buttonThis
02d664c0: ret                                                
## SetSelected(bool isSelected) -> void
---- Clicker.CategoryButton::SetSelected 0x2d664c4
02d664c4: stp     x30, x21, [sp, #-0x20]!                    
02d664c8: stp     x20, x19, [sp, #0x10]                      
02d664cc: mov     x19, x0                                    
02d664d0: ldr     x0, [x0, #0x20]                            ._goSelected
02d664d4: cbz     x0, #0x2d66594                             
02d664d8: mov     w20, w1                                    
02d664dc: and     w1, w1, #1                                 
02d664e0: mov     x2, xzr                                    
02d664e4: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d664e8: adrp    x21, #0x662f000                            
02d664ec: ldr     x19, [x19, #0x28]                          ._tfIcon
02d664f0: ldrb    w8, [x21, #0xa74]                          
02d664f4: tbz     w20, #0, #0x2d6652c                        
02d664f8: cbnz    w8, #0x2d66510                             
02d664fc: adrp    x0, #0x6264000                             
02d66500: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d66504: bl      #0x2b70db0                                 fn_2b70db0
02d66508: mov     w8, #1                                     
02d6650c: strb    w8, [x21, #0xa74]                          
02d66510: adrp    x8, #0x6264000                             
02d66514: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02d66518: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d6651c: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d66520: ldur    d0, [x8, #0xc]                             
02d66524: ldr     s2, [x8, #0x14]                            [6264014]=0 f=0,0
02d66528: b       #0x2d66578                                 
02d6652c: cbnz    w8, #0x2d66544                             
02d66530: adrp    x0, #0x6264000                             
02d66534: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d66538: bl      #0x2b70db0                                 fn_2b70db0
02d6653c: mov     w8, #1                                     
02d66540: strb    w8, [x21, #0xa74]                          
02d66544: adrp    x8, #0x6264000                             
02d66548: mov     w9, #0x999a                                
02d6654c: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02d66550: movk    w9, #0x3f59, lsl #16                       
02d66554: dup     v0.2s, w9                                  
02d66558: adrp    x9, #0x1084000                             
02d6655c: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d66560: ldr     s3, [x9, #0xcf0]                           [1084cf0]=3f99999a3f59999a f=0.85,1.2
02d66564: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d66568: ldur    d1, [x8, #0xc]                             
02d6656c: ldr     s2, [x8, #0x14]                            [6264014]=0 f=0,0
02d66570: fmul    v0.2s, v1.2s, v0.2s                        
02d66574: fmul    s2, s2, s3                                 
02d66578: cbz     x19, #0x2d66594                            
02d6657c: mov     x0, x19                                    
02d66580: ldp     x20, x19, [sp, #0x10]                      
02d66584: mov     s1, v0.s[1]                                
02d66588: mov     x1, xzr                                    
02d6658c: ldp     x30, x21, [sp], #0x20                      
02d66590: b       #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d66594: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Clicker.CategoryButton::.ctor 0x2d66598
02d66598: mov     x1, xzr                                    
02d6659c: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
