#### CLASS Assets.SimpleLocalization.Scripts.LocalizedDropdown parent= UnityEngine.MonoBehaviour
#   field LocalizationKeys               string[]                                           off=0x20 attr=6 
## Start() -> void
---- Assets.SimpleLocalization.Scripts.LocalizedDropdown::Start 0x2d7c5e0
02d7c5e0: stp     x30, x23, [sp, #-0x30]!                    
02d7c5e4: stp     x22, x21, [sp, #0x10]                      
02d7c5e8: stp     x20, x19, [sp, #0x20]                      
02d7c5ec: adrp    x23, #0x6630000                            
02d7c5f0: adrp    x22, #0x6264000                            
02d7c5f4: adrp    x20, #0x626c000                            
02d7c5f8: adrp    x21, #0x6266000                            
02d7c5fc: ldr     x22, [x22, #0xf90]                         T:System.Action
02d7c600: ldrb    w8, [x23, #0x418]                          
02d7c604: ldr     x20, [x20, #0xc60]                         M:Assets.SimpleLocalization.Scripts.LocalizedDropdown::Localize
02d7c608: ldr     x21, [x21, #0x9f0]                         T:Assets.SimpleLocalization.Scripts.LocalizationManager
02d7c60c: mov     x19, x0                                    
02d7c610: tbnz    w8, #0, #0x2d7c640                         
02d7c614: adrp    x0, #0x6264000                             
02d7c618: ldr     x0, [x0, #0xf90]                           T:System.Action
02d7c61c: bl      #0x2b70db0                                 fn_2b70db0
02d7c620: adrp    x0, #0x6266000                             
02d7c624: ldr     x0, [x0, #0x9f0]                           T:Assets.SimpleLocalization.Scripts.LocalizationManager
02d7c628: bl      #0x2b70db0                                 fn_2b70db0
02d7c62c: adrp    x0, #0x626c000                             
02d7c630: ldr     x0, [x0, #0xc60]                           M:Assets.SimpleLocalization.Scripts.LocalizedDropdown::Localize
02d7c634: bl      #0x2b70db0                                 fn_2b70db0
02d7c638: mov     w8, #1                                     
02d7c63c: strb    w8, [x23, #0x418]                          
02d7c640: mov     x0, x19                                    
02d7c644: bl      #0x2d7c688                                 Assets.SimpleLocalization.Scripts.LocalizedDropdown::Localize
02d7c648: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d7c64c: bl      #0x2b7104c                                 fn_2b7104c
02d7c650: ldr     x2, [x20]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7c654: mov     x1, x19                                    
02d7c658: mov     x3, xzr                                    
02d7c65c: mov     x20, x0                                    
02d7c660: bl      #0x4d8ddbc                                 System.Action::.ctor
02d7c664: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7c668: ldr     w8, [x0, #0xe4]                            [626c0e4]=0 f=0,0
02d7c66c: cbnz    w8, #0x2d7c674                             
02d7c670: bl      #0x2b70f30                                 fn_2b70f30
02d7c674: mov     x0, x20                                    
02d7c678: ldp     x20, x19, [sp, #0x20]                      
02d7c67c: ldp     x22, x21, [sp, #0x10]                      
02d7c680: ldp     x30, x23, [sp], #0x30                      
02d7c684: b       #0x2d7ad04                                 Assets.SimpleLocalization.Scripts.LocalizationManager::add_OnLocalizationChanged
## OnDestroy() -> void
---- Assets.SimpleLocalization.Scripts.LocalizedDropdown::OnDestroy 0x2d7c810
02d7c810: stp     x30, x23, [sp, #-0x30]!                    
02d7c814: stp     x22, x21, [sp, #0x10]                      
02d7c818: stp     x20, x19, [sp, #0x20]                      
02d7c81c: adrp    x22, #0x6630000                            
02d7c820: adrp    x23, #0x6264000                            
02d7c824: adrp    x20, #0x626c000                            
02d7c828: adrp    x21, #0x6266000                            
02d7c82c: ldr     x23, [x23, #0xf90]                         T:System.Action
02d7c830: ldrb    w8, [x22, #0x419]                          
02d7c834: ldr     x20, [x20, #0xc60]                         M:Assets.SimpleLocalization.Scripts.LocalizedDropdown::Localize
02d7c838: ldr     x21, [x21, #0x9f0]                         T:Assets.SimpleLocalization.Scripts.LocalizationManager
02d7c83c: mov     x19, x0                                    
02d7c840: tbnz    w8, #0, #0x2d7c870                         
02d7c844: adrp    x0, #0x6264000                             
02d7c848: ldr     x0, [x0, #0xf90]                           T:System.Action
02d7c84c: bl      #0x2b70db0                                 fn_2b70db0
02d7c850: adrp    x0, #0x6266000                             
02d7c854: ldr     x0, [x0, #0x9f0]                           T:Assets.SimpleLocalization.Scripts.LocalizationManager
02d7c858: bl      #0x2b70db0                                 fn_2b70db0
02d7c85c: adrp    x0, #0x626c000                             
02d7c860: ldr     x0, [x0, #0xc60]                           M:Assets.SimpleLocalization.Scripts.LocalizedDropdown::Localize
02d7c864: bl      #0x2b70db0                                 fn_2b70db0
02d7c868: mov     w8, #1                                     
02d7c86c: strb    w8, [x22, #0x419]                          
02d7c870: ldr     x0, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d7c874: bl      #0x2b7104c                                 fn_2b7104c
02d7c878: ldr     x2, [x20]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7c87c: mov     x1, x19                                    
02d7c880: mov     x3, xzr                                    
02d7c884: mov     x20, x0                                    
02d7c888: bl      #0x4d8ddbc                                 System.Action::.ctor
02d7c88c: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7c890: ldr     w8, [x0, #0xe4]                            [626c0e4]=0 f=0,0
02d7c894: cbnz    w8, #0x2d7c89c                             
02d7c898: bl      #0x2b70f30                                 fn_2b70f30
02d7c89c: mov     x0, x20                                    
02d7c8a0: ldp     x20, x19, [sp, #0x20]                      
02d7c8a4: ldp     x22, x21, [sp, #0x10]                      
02d7c8a8: ldp     x30, x23, [sp], #0x30                      
02d7c8ac: b       #0x2d7b144                                 Assets.SimpleLocalization.Scripts.LocalizationManager::remove_OnLocalizationChanged
## Localize() -> void
---- Assets.SimpleLocalization.Scripts.LocalizedDropdown::Localize 0x2d7c688
02d7c688: stp     x30, x25, [sp, #-0x40]!                    
02d7c68c: stp     x24, x23, [sp, #0x10]                      
02d7c690: stp     x22, x21, [sp, #0x20]                      
02d7c694: stp     x20, x19, [sp, #0x30]                      
02d7c698: adrp    x20, #0x6630000                            
02d7c69c: adrp    x21, #0x626c000                            
02d7c6a0: mov     x19, x0                                    
02d7c6a4: ldrb    w8, [x20, #0x41a]                          
02d7c6a8: ldr     x21, [x21, #0xc68]                         MS:UnityEngine.Component::GetComponent
02d7c6ac: tbnz    w8, #0, #0x2d7c6dc                         
02d7c6b0: adrp    x0, #0x626c000                             
02d7c6b4: ldr     x0, [x0, #0xc68]                           MS:UnityEngine.Component::GetComponent
02d7c6b8: bl      #0x2b70db0                                 fn_2b70db0
02d7c6bc: adrp    x0, #0x626c000                             
02d7c6c0: ldr     x0, [x0, #0xc70]                           MS:System.Collections.Generic.List`1::get_Item
02d7c6c4: bl      #0x2b70db0                                 fn_2b70db0
02d7c6c8: adrp    x0, #0x6266000                             
02d7c6cc: ldr     x0, [x0, #0x9f0]                           T:Assets.SimpleLocalization.Scripts.LocalizationManager
02d7c6d0: bl      #0x2b70db0                                 fn_2b70db0
02d7c6d4: mov     w8, #1                                     
02d7c6d8: strb    w8, [x20, #0x41a]                          
02d7c6dc: ldr     x1, [x21]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7c6e0: mov     x0, x19                                    
02d7c6e4: bl      #0x3140c84                                 fn_3140c84
02d7c6e8: ldr     x8, [x19, #0x20]                           .LocalizationKeys
02d7c6ec: cbz     x8, #0x2d7c78c                             
02d7c6f0: adrp    x25, #0x626c000                            
02d7c6f4: adrp    x24, #0x6266000                            
02d7c6f8: mov     x20, x0                                    
02d7c6fc: ldr     x25, [x25, #0xc70]                         MS:System.Collections.Generic.List`1::get_Item
02d7c700: ldr     x24, [x24, #0x9f0]                         T:Assets.SimpleLocalization.Scripts.LocalizationManager
02d7c704: mov     x21, xzr                                   
02d7c708: ldr     x9, [x8, #0x18]                            
02d7c70c: cmp     x21, w9, sxtw                              
02d7c710: b.ge    #0x2d7c790                                 
02d7c714: cbz     x20, #0x2d7c78c                            
02d7c718: mov     x0, x20                                    
02d7c71c: mov     x1, xzr                                    
02d7c720: bl      #0x5c491a0                                 UnityEngine.UI.Dropdown::get_options
02d7c724: cbz     x0, #0x2d7c78c                             
02d7c728: ldr     x2, [x25]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d7c72c: mov     w1, w21                                    
02d7c730: bl      #0x35a8f3c                                 fn_35a8f3c
02d7c734: ldr     x8, [x19, #0x20]                           .LocalizationKeys
02d7c738: cbz     x8, #0x2d7c78c                             
02d7c73c: ldr     w9, [x8, #0x18]                            
02d7c740: cmp     x21, x9                                    
02d7c744: b.hs    #0x2d7c80c                                 
02d7c748: mov     x22, x0                                    
02d7c74c: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7c750: add     x8, x8, x21, lsl #3                        
02d7c754: ldr     w9, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d7c758: ldr     x23, [x8, #0x20]                           
02d7c75c: cbnz    w9, #0x2d7c764                             
02d7c760: bl      #0x2b70f30                                 fn_2b70f30
02d7c764: mov     x0, x23                                    
02d7c768: bl      #0x2d76794                                 Assets.SimpleLocalization.Scripts.LocalizationManager::Localize
02d7c76c: cbz     x22, #0x2d7c78c                            
02d7c770: mov     x1, x0                                     
02d7c774: str     x0, [x22, #0x10]!                          
02d7c778: mov     x0, x22                                    
02d7c77c: bl      #0x2b70d54                                 fn_2b70d54
02d7c780: ldr     x8, [x19, #0x20]                           .LocalizationKeys
02d7c784: add     x21, x21, #1                               &626c001
02d7c788: cbnz    x8, #0x2d7c708                             
02d7c78c: bl      #0x2b7105c                                 fn_2b7105c
02d7c790: cbz     x20, #0x2d7c78c                            
02d7c794: ldrsw   x10, [x20, #0x128]                         
02d7c798: cmp     w10, w9                                    
02d7c79c: b.ge    #0x2d7c7f8                                 
02d7c7a0: cmp     w10, w9                                    
02d7c7a4: b.hs    #0x2d7c80c                                 
02d7c7a8: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d7c7ac: add     x8, x8, x10, lsl #3                        
02d7c7b0: ldr     x19, [x20, #0x108]                         
02d7c7b4: ldr     w9, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d7c7b8: ldr     x20, [x8, #0x20]                           
02d7c7bc: cbnz    w9, #0x2d7c7c4                             
02d7c7c0: bl      #0x2b70f30                                 fn_2b70f30
02d7c7c4: mov     x0, x20                                    
02d7c7c8: bl      #0x2d76794                                 Assets.SimpleLocalization.Scripts.LocalizationManager::Localize
02d7c7cc: cbz     x19, #0x2d7c78c                            
02d7c7d0: ldr     x8, [x19]                                  
02d7c7d4: mov     x1, x0                                     
02d7c7d8: mov     x0, x19                                    
02d7c7dc: ldp     x20, x19, [sp, #0x30]                      
02d7c7e0: ldp     x22, x21, [sp, #0x20]                      
02d7c7e4: ldr     x2, [x8, #0x5f0]                           
02d7c7e8: ldp     x24, x23, [sp, #0x10]                      
02d7c7ec: ldr     x3, [x8, #0x5e8]                           
02d7c7f0: ldp     x30, x25, [sp], #0x40                      
02d7c7f4: br      x3                                         
02d7c7f8: ldp     x20, x19, [sp, #0x30]                      
02d7c7fc: ldp     x22, x21, [sp, #0x20]                      
02d7c800: ldp     x24, x23, [sp, #0x10]                      
02d7c804: ldp     x30, x25, [sp], #0x40                      
02d7c808: ret                                                
02d7c80c: bl      #0x2b71064                                 fn_2b71064
## .ctor() -> void
---- Assets.SimpleLocalization.Scripts.LocalizedDropdown::.ctor 0x2d7c8b0
02d7c8b0: mov     x1, xzr                                    
02d7c8b4: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
