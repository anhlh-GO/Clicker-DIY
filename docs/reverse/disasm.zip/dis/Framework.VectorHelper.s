#### CLASS Framework.VectorHelper parent= object
## RoundVector(UnityEngine.Vector2 vector) -> UnityEngine.Vector2
---- Framework.VectorHelper::RoundVector 0x2cc2c98
02cc2c98: movi    d2, #0000000000000000                      
02cc2c9c: b       #0x2cc2ca0                                 Framework.VectorHelper::RoundVector
## RoundVector(UnityEngine.Vector3 vector) -> UnityEngine.Vector3
---- Framework.VectorHelper::RoundVector 0x2cc2ca0
02cc2ca0: sub     sp, sp, #0x30                              
02cc2ca4: str     d10, [sp, #0x10]                           
02cc2ca8: stp     d9, d8, [sp, #0x18]                        
02cc2cac: str     x30, [sp, #0x28]                           
02cc2cb0: fmov    s9, s0                                     
02cc2cb4: fcvt    d0, s0                                     
02cc2cb8: add     x0, sp, #8                                 
02cc2cbc: fmov    s8, s2                                     
02cc2cc0: fmov    s10, s1                                    
02cc2cc4: bl      #0x5e902c0                                 fn_5e902c0
02cc2cc8: fcmp    s9, #0.0                                   
02cc2ccc: b.ge    #0x2cc2ce8                                 
02cc2cd0: fmov    d1, #-0.50000000                           
02cc2cd4: fcmp    d0, d1                                     
02cc2cd8: b.ne    #0x2cc2d14                                 
02cc2cdc: ldr     d0, [sp, #8]                               
02cc2ce0: fmov    s2, #-1.00000000                           
02cc2ce4: b       #0x2cc2cfc                                 
02cc2ce8: fmov    d1, #0.50000000                            
02cc2cec: fcmp    d0, d1                                     
02cc2cf0: b.ne    #0x2cc2d24                                 
02cc2cf4: ldr     d0, [sp, #8]                               
02cc2cf8: fmov    s2, #1.00000000                            
02cc2cfc: fcvt    s1, d0                                     
02cc2d00: fcvtzs  x8, d0                                     
02cc2d04: fadd    s0, s1, s2                                 
02cc2d08: tst     x8, #1                                     
02cc2d0c: fcsel   s9, s1, s0, eq                             
02cc2d10: b       #0x2cc2d30                                 
02cc2d14: fmov    s0, #-0.50000000                           
02cc2d18: fadd    s0, s9, s0                                 
02cc2d1c: frintp  s9, s0                                     
02cc2d20: b       #0x2cc2d30                                 
02cc2d24: fmov    s0, #0.50000000                            
02cc2d28: fadd    s0, s9, s0                                 
02cc2d2c: frintm  s9, s0                                     
02cc2d30: fcvt    d0, s10                                    
02cc2d34: add     x0, sp, #8                                 
02cc2d38: bl      #0x5e902c0                                 fn_5e902c0
02cc2d3c: fcmp    s10, #0.0                                  
02cc2d40: b.ge    #0x2cc2d5c                                 
02cc2d44: fmov    d1, #-0.50000000                           
02cc2d48: fcmp    d0, d1                                     
02cc2d4c: b.ne    #0x2cc2d88                                 
02cc2d50: ldr     d0, [sp, #8]                               
02cc2d54: fmov    s2, #-1.00000000                           
02cc2d58: b       #0x2cc2d70                                 
02cc2d5c: fmov    d1, #0.50000000                            
02cc2d60: fcmp    d0, d1                                     
02cc2d64: b.ne    #0x2cc2d98                                 
02cc2d68: ldr     d0, [sp, #8]                               
02cc2d6c: fmov    s2, #1.00000000                            
02cc2d70: fcvt    s1, d0                                     
02cc2d74: fcvtzs  x8, d0                                     
02cc2d78: fadd    s0, s1, s2                                 
02cc2d7c: tst     x8, #1                                     
02cc2d80: fcsel   s10, s1, s0, eq                            
02cc2d84: b       #0x2cc2da4                                 
02cc2d88: fmov    s0, #-0.50000000                           
02cc2d8c: fadd    s0, s10, s0                                
02cc2d90: frintp  s10, s0                                    
02cc2d94: b       #0x2cc2da4                                 
02cc2d98: fmov    s0, #0.50000000                            
02cc2d9c: fadd    s0, s10, s0                                
02cc2da0: frintm  s10, s0                                    
02cc2da4: fcvt    d0, s8                                     
02cc2da8: add     x0, sp, #8                                 
02cc2dac: bl      #0x5e902c0                                 fn_5e902c0
02cc2db0: fcmp    s8, #0.0                                   
02cc2db4: b.ge    #0x2cc2dd0                                 
02cc2db8: fmov    d1, #-0.50000000                           
02cc2dbc: fcmp    d0, d1                                     
02cc2dc0: b.ne    #0x2cc2dfc                                 
02cc2dc4: ldr     d0, [sp, #8]                               
02cc2dc8: fmov    s2, #-1.00000000                           
02cc2dcc: b       #0x2cc2de4                                 
02cc2dd0: fmov    d1, #0.50000000                            
02cc2dd4: fcmp    d0, d1                                     
02cc2dd8: b.ne    #0x2cc2e0c                                 
02cc2ddc: ldr     d0, [sp, #8]                               
02cc2de0: fmov    s2, #1.00000000                            
02cc2de4: fcvt    s1, d0                                     
02cc2de8: fcvtzs  x8, d0                                     
02cc2dec: fadd    s0, s1, s2                                 
02cc2df0: tst     x8, #1                                     
02cc2df4: fcsel   s2, s1, s0, eq                             
02cc2df8: b       #0x2cc2e18                                 
02cc2dfc: fmov    s0, #-0.50000000                           
02cc2e00: fadd    s0, s8, s0                                 
02cc2e04: frintp  s2, s0                                     
02cc2e08: b       #0x2cc2e18                                 
02cc2e0c: fmov    s0, #0.50000000                            
02cc2e10: fadd    s0, s8, s0                                 
02cc2e14: frintm  s2, s0                                     
02cc2e18: fmov    s0, s9                                     
02cc2e1c: ldp     d9, d8, [sp, #0x18]                        
02cc2e20: fmov    s1, s10                                    
02cc2e24: ldr     x30, [sp, #0x28]                           
02cc2e28: ldr     d10, [sp, #0x10]                           
02cc2e2c: add     sp, sp, #0x30                              
02cc2e30: ret                                                
## RandomVector(UnityEngine.Vector2 minimum, UnityEngine.Vector2 maximum) -> UnityEngine.Vector2
---- Framework.VectorHelper::RandomVector 0x2cc2e34
02cc2e34: fmov    s4, s3                                     
02cc2e38: fmov    s3, s2                                     
02cc2e3c: movi    d2, #0000000000000000                      
02cc2e40: movi    d5, #0000000000000000                      
02cc2e44: b       #0x2cc2e48                                 Framework.VectorHelper::RandomVector
## RandomVector(UnityEngine.Vector3 minimum, UnityEngine.Vector3 maximum) -> UnityEngine.Vector3
---- Framework.VectorHelper::RandomVector 0x2cc2e48
02cc2e48: str     d12, [sp, #-0x30]!                         
02cc2e4c: stp     d11, d10, [sp, #8]                         
02cc2e50: stp     d9, d8, [sp, #0x18]                        
02cc2e54: str     x30, [sp, #0x28]                           
02cc2e58: fmov    s11, s1                                    
02cc2e5c: fmov    s1, s3                                     
02cc2e60: mov     x0, xzr                                    
02cc2e64: fmov    s8, s5                                     
02cc2e68: fmov    s9, s4                                     
02cc2e6c: fmov    s10, s2                                    
02cc2e70: bl      #0x5b2dfc0                                 UnityEngine.Random::Range
02cc2e74: fmov    s12, s0                                    
02cc2e78: fmov    s0, s11                                    
02cc2e7c: mov     x0, xzr                                    
02cc2e80: fmov    s1, s9                                     
02cc2e84: bl      #0x5b2dfc0                                 UnityEngine.Random::Range
02cc2e88: fmov    s9, s0                                     
02cc2e8c: fmov    s0, s10                                    
02cc2e90: mov     x0, xzr                                    
02cc2e94: fmov    s1, s8                                     
02cc2e98: bl      #0x5b2dfc0                                 UnityEngine.Random::Range
02cc2e9c: fmov    s1, s9                                     
02cc2ea0: ldp     d9, d8, [sp, #0x18]                        
02cc2ea4: ldp     d11, d10, [sp, #8]                         
02cc2ea8: fmov    s2, s0                                     
02cc2eac: ldr     x30, [sp, #0x28]                           
02cc2eb0: fmov    s0, s12                                    
02cc2eb4: ldr     d12, [sp], #0x30                           
02cc2eb8: ret                                                
## GetRandomDirVector2() -> UnityEngine.Vector2
---- Framework.VectorHelper::GetRandomDirVector2 0x2cc2ebc
02cc2ebc: stp     d9, d8, [sp, #-0x30]!                      
02cc2ec0: stp     x30, xzr, [sp, #0x10]                      
02cc2ec4: stp     x20, x19, [sp, #0x20]                      
02cc2ec8: adrp    x19, #0x662f000                            
02cc2ecc: ldrb    w8, [x19, #0xbda]                          
02cc2ed0: cbnz    w8, #0x2cc2ee8                             
02cc2ed4: adrp    x0, #0x6266000                             
02cc2ed8: ldr     x0, [x0, #0x970]                           T:UnityEngine.Vector2
02cc2edc: bl      #0x2b70db0                                 fn_2b70db0
02cc2ee0: mov     w8, #1                                     
02cc2ee4: strb    w8, [x19, #0xbda]                          
02cc2ee8: adrp    x19, #0x6266000                            
02cc2eec: adrp    x20, #0x662f000                            
02cc2ef0: ldr     x19, [x19, #0x970]                         T:UnityEngine.Vector2
02cc2ef4: ldrb    w9, [x20, #0xca2]                          
02cc2ef8: ldr     x8, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cc2efc: ldr     x8, [x8, #0xb8]                            
02cc2f00: ldp     s8, s9, [x8]                               
02cc2f04: cbnz    w9, #0x2cc2f20                             
02cc2f08: mov     x0, x19                                    
02cc2f0c: bl      #0x2b70db0                                 fn_2b70db0
02cc2f10: ldr     x8, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cc2f14: mov     w9, #1                                     
02cc2f18: strb    w9, [x20, #0xca2]                          
02cc2f1c: ldr     x8, [x8, #0xb8]                            
02cc2f20: movi    d2, #0000000000000000                      
02cc2f24: movi    d5, #0000000000000000                      
02cc2f28: fmov    s0, s8                                     
02cc2f2c: fmov    s1, s9                                     
02cc2f30: ldp     s3, s4, [x8, #8]                           
02cc2f34: bl      #0x2cc2e48                                 Framework.VectorHelper::RandomVector
02cc2f38: add     x0, sp, #0x18                              
02cc2f3c: mov     x1, xzr                                    
02cc2f40: stp     s0, s1, [sp, #0x18]                        
02cc2f44: bl      #0x5b28290                                 UnityEngine.Vector2::Normalize
02cc2f48: ldp     x20, x19, [sp, #0x20]                      
02cc2f4c: ldr     x30, [sp, #0x10]                           
02cc2f50: ldp     d9, d8, [sp], #0x30                        
02cc2f54: ret                                                
## GetRandomDirVector3() -> UnityEngine.Vector3
---- Framework.VectorHelper::GetRandomDirVector3 0x2cc2f58
02cc2f58: str     d10, [sp, #-0x30]!                         
02cc2f5c: stp     d9, d8, [sp, #8]                           
02cc2f60: str     x30, [sp, #0x18]                           
02cc2f64: stp     x20, x19, [sp, #0x20]                      
02cc2f68: adrp    x19, #0x662f000                            
02cc2f6c: ldrb    w8, [x19, #0x91a]                          
02cc2f70: cbnz    w8, #0x2cc2f88                             
02cc2f74: adrp    x0, #0x6264000                             
02cc2f78: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02cc2f7c: bl      #0x2b70db0                                 fn_2b70db0
02cc2f80: mov     w8, #1                                     
02cc2f84: strb    w8, [x19, #0x91a]                          
02cc2f88: adrp    x19, #0x6264000                            
02cc2f8c: adrp    x20, #0x662f000                            
02cc2f90: ldr     x19, [x19, #0xd8]                          T:UnityEngine.Vector3
02cc2f94: ldrb    w9, [x20, #0xa74]                          
02cc2f98: ldr     x8, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cc2f9c: ldr     x8, [x8, #0xb8]                            
02cc2fa0: ldp     s8, s9, [x8]                               
02cc2fa4: ldr     s10, [x8, #8]                              
02cc2fa8: cbnz    w9, #0x2cc2fc4                             
02cc2fac: mov     x0, x19                                    
02cc2fb0: bl      #0x2b70db0                                 fn_2b70db0
02cc2fb4: ldr     x8, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cc2fb8: mov     w9, #1                                     
02cc2fbc: strb    w9, [x20, #0xa74]                          
02cc2fc0: ldr     x8, [x8, #0xb8]                            
02cc2fc4: fmov    s0, s8                                     
02cc2fc8: fmov    s1, s9                                     
02cc2fcc: ldr     s5, [x8, #0x14]                            
02cc2fd0: fmov    s2, s10                                    
02cc2fd4: ldp     s3, s4, [x8, #0xc]                         
02cc2fd8: bl      #0x2cc2e48                                 Framework.VectorHelper::RandomVector
02cc2fdc: fmov    s8, s0                                     
02cc2fe0: fmov    s9, s1                                     
02cc2fe4: adrp    x20, #0x662f000                            
02cc2fe8: fmov    s10, s2                                    
02cc2fec: ldrb    w8, [x20, #0xca8]                          
02cc2ff0: cbnz    w8, #0x2cc3008                             
02cc2ff4: adrp    x0, #0x6264000                             
02cc2ff8: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02cc2ffc: bl      #0x2b70db0                                 fn_2b70db0
02cc3000: mov     w8, #1                                     
02cc3004: strb    w8, [x20, #0xca8]                          
02cc3008: adrp    x20, #0x662f000                            
02cc300c: ldrb    w8, [x20, #0xca7]                          
02cc3010: cbnz    w8, #0x2cc3028                             
02cc3014: adrp    x0, #0x6265000                             
02cc3018: ldr     x0, [x0, #0xb48]                           T:System.Math
02cc301c: bl      #0x2b70db0                                 fn_2b70db0
02cc3020: mov     w8, #1                                     
02cc3024: strb    w8, [x20, #0xca7]                          
02cc3028: adrp    x8, #0x6265000                             
02cc302c: ldr     x8, [x8, #0xb48]                           T:System.Math
02cc3030: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02cc3034: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02cc3038: cbnz    w8, #0x2cc3040                             
02cc303c: bl      #0x2b70f30                                 fn_2b70f30
02cc3040: fmul    s0, s8, s8                                 
02cc3044: fmul    s1, s9, s9                                 
02cc3048: adrp    x8, #0x1084000                             
02cc304c: fadd    s0, s0, s1                                 
02cc3050: fmul    s1, s10, s10                               
02cc3054: fadd    s0, s1, s0                                 
02cc3058: fsqrt   s2, s0                                     
02cc305c: ldr     s0, [x8, #0xfe0]                           [1084fe0]=3d5df3603727c5ac f=1e-05,0.0541872
02cc3060: fcmp    s2, s0                                     
02cc3064: b.le    #0x2cc3078                                 
02cc3068: fdiv    s0, s8, s2                                 
02cc306c: fdiv    s1, s9, s2                                 
02cc3070: fdiv    s2, s10, s2                                
02cc3074: b       #0x2cc3088                                 
02cc3078: ldr     x8, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cc307c: ldr     x8, [x8, #0xb8]                            [10840b8]=2632726f74636556 f=7.20646e+31,6.19112e-16
02cc3080: ldp     s1, s2, [x8, #4]                           
02cc3084: ldr     s0, [x8]                                   [1084000]=287475706e49646c f=1.5582e+28,1.35702e-14
02cc3088: ldp     x20, x19, [sp, #0x20]                      
02cc308c: ldr     x30, [sp, #0x18]                           
02cc3090: ldp     d9, d8, [sp, #8]                           
02cc3094: ldr     d10, [sp], #0x30                           
02cc3098: ret                                                
## RotatePointAroundPivot(UnityEngine.Vector3 point, UnityEngine.Vector3 pivot, float angle) -> UnityEngine.Vector3
---- Framework.VectorHelper::RotatePointAroundPivot 0x2cc309c
02cc309c: stp     d11, d10, [sp, #-0x30]!                    
02cc30a0: stp     d9, d8, [sp, #0x10]                        
02cc30a4: str     x30, [sp, #0x20]                           
02cc30a8: adrp    x8, #0x1085000                             
02cc30ac: fmov    s10, s1                                    
02cc30b0: fmov    s11, s0                                    
02cc30b4: ldr     s1, [x8, #0x10]                            [1085010]=4202c6f23c8efa35 f=0.0174533,32.6943
02cc30b8: add     x0, sp, #0x2c                              
02cc30bc: add     x1, sp, #0x28                              
02cc30c0: fmov    s8, s4                                     
02cc30c4: fmov    s9, s3                                     
02cc30c8: fmul    s1, s6, s1                                 
02cc30cc: fmov    s0, s1                                     
02cc30d0: bl      #0x5e90310                                 fn_5e90310
02cc30d4: fsub    s0, s11, s9                                
02cc30d8: fsub    s1, s10, s8                                
02cc30dc: ldr     x30, [sp, #0x20]                           
02cc30e0: ldp     s2, s3, [sp, #0x28]                        
02cc30e4: fmul    s4, s0, s3                                 
02cc30e8: fmul    s5, s1, s2                                 
02cc30ec: fmul    s0, s0, s2                                 
02cc30f0: fmul    s1, s1, s3                                 
02cc30f4: fadd    s2, s4, s5                                 
02cc30f8: fsub    s0, s0, s1                                 
02cc30fc: fadd    s1, s8, s2                                 
02cc3100: movi    d2, #0000000000000000                      
02cc3104: fadd    s0, s9, s0                                 
02cc3108: ldp     d9, d8, [sp, #0x10]                        
02cc310c: ldp     d11, d10, [sp], #0x30                      
02cc3110: ret                                                
## RotatePointAroundPivot(UnityEngine.Vector3 point, UnityEngine.Vector3 pivot, UnityEngine.Vector3 angle) -> UnityEngine.Vector3
---- Framework.VectorHelper::RotatePointAroundPivot 0x2cc3114
02cc3114: sub     sp, sp, #0x50                              
02cc3118: stp     d13, d12, [sp, #0x10]                      
02cc311c: stp     d11, d10, [sp, #0x20]                      
02cc3120: stp     d9, d8, [sp, #0x30]                        
02cc3124: str     x30, [sp, #0x40]                           
02cc3128: mov     w8, #0xfa35                                
02cc312c: fmov    s10, s3                                    
02cc3130: ldr     s3, [sp, #0x50]                            
02cc3134: movk    w8, #0x3c8e, lsl #16                       
02cc3138: fmov    s9, s4                                     
02cc313c: fmov    s8, s5                                     
02cc3140: dup     v4.2s, w8                                  
02cc3144: add     x8, sp, #0x54                              
02cc3148: ldr     s5, [sp, #0x58]                            
02cc314c: ld1     {v3.s}[1], [x8]                            
02cc3150: adrp    x8, #0x1085000                             
02cc3154: mov     x0, sp                                     
02cc3158: ldr     s6, [x8, #0x10]                            [1085010]=4202c6f23c8efa35 f=0.0174533,32.6943
02cc315c: mov     x1, xzr                                    
02cc3160: fsub    s11, s0, s10                               
02cc3164: fsub    s12, s1, s9                                
02cc3168: fsub    s13, s2, s8                                
02cc316c: fmul    v3.2s, v3.2s, v4.2s                        
02cc3170: fmul    s4, s5, s6                                 
02cc3174: str     d3, [sp]                                   
02cc3178: str     s4, [sp, #8]                               
02cc317c: bl      #0x5b2607c                                 UnityEngine.Quaternion::Internal_FromEulerRad
02cc3180: fmov    s4, s11                                    
02cc3184: fmov    s5, s12                                    
02cc3188: mov     x0, xzr                                    
02cc318c: fmov    s6, s13                                    
02cc3190: bl      #0x5b26598                                 UnityEngine.Quaternion::op_Multiply
02cc3194: fadd    s0, s10, s0                                
02cc3198: fadd    s1, s9, s1                                 
02cc319c: ldr     x30, [sp, #0x40]                           
02cc31a0: fadd    s2, s8, s2                                 
02cc31a4: ldp     d9, d8, [sp, #0x30]                        
02cc31a8: ldp     d11, d10, [sp, #0x20]                      
02cc31ac: ldp     d13, d12, [sp, #0x10]                      
02cc31b0: add     sp, sp, #0x50                              
02cc31b4: ret                                                
## RotatePointAroundPivot(UnityEngine.Vector3 point, UnityEngine.Vector3 pivot, UnityEngine.Quaternion quaternion) -> UnityEngine.Vector3
---- Framework.VectorHelper::RotatePointAroundPivot 0x2cc31b8
02cc31b8: str     d10, [sp, #-0x20]!                         
02cc31bc: stp     d9, d8, [sp, #8]                           
02cc31c0: str     x30, [sp, #0x18]                           
02cc31c4: fmov    s8, s5                                     
02cc31c8: fmov    s9, s4                                     
02cc31cc: mov     x0, xzr                                    
02cc31d0: fsub    s4, s0, s3                                 
02cc31d4: fmov    s10, s3                                    
02cc31d8: fsub    s5, s1, s9                                 
02cc31dc: fsub    s6, s2, s8                                 
02cc31e0: ldp     s0, s1, [sp, #0x20]                        
02cc31e4: ldp     s2, s3, [sp, #0x28]                        
02cc31e8: bl      #0x5b26598                                 UnityEngine.Quaternion::op_Multiply
02cc31ec: fadd    s1, s9, s1                                 
02cc31f0: fadd    s2, s8, s2                                 
02cc31f4: ldr     x30, [sp, #0x18]                           
02cc31f8: ldp     d9, d8, [sp, #8]                           
02cc31fc: fadd    s0, s10, s0                                
02cc3200: ldr     d10, [sp], #0x20                           
02cc3204: ret                                                
## RotateVector2(UnityEngine.Vector2 vector, float angle) -> UnityEngine.Vector2
---- Framework.VectorHelper::RotateVector2 0x2cc3208
02cc3208: stp     d9, d8, [sp, #-0x20]!                      
02cc320c: str     x30, [sp, #0x10]                           
02cc3210: fmov    s8, s1                                     
02cc3214: fmov    s9, s0                                     
02cc3218: fcmp    s2, #0.0                                   
02cc321c: b.eq    #0x2cc3254                                 
02cc3220: adrp    x8, #0x1085000                             
02cc3224: add     x0, sp, #0x1c                              
02cc3228: add     x1, sp, #0x18                              
02cc322c: ldr     s0, [x8, #0x10]                            [1085010]=4202c6f23c8efa35 f=0.0174533,32.6943
02cc3230: fmul    s0, s2, s0                                 
02cc3234: bl      #0x5e90310                                 fn_5e90310
02cc3238: ldp     s1, s0, [sp, #0x18]                        
02cc323c: fmul    s2, s9, s1                                 
02cc3240: fmul    s3, s8, s0                                 
02cc3244: fmul    s0, s9, s0                                 
02cc3248: fmul    s1, s8, s1                                 
02cc324c: fsub    s9, s2, s3                                 
02cc3250: fadd    s8, s0, s1                                 
02cc3254: ldr     x30, [sp, #0x10]                           
02cc3258: fmov    s0, s9                                     
02cc325c: fmov    s1, s8                                     
02cc3260: ldp     d9, d8, [sp], #0x20                        
02cc3264: ret                                                
##  Swap (no body)
## Approximately(float a, float b, float tolerance) -> bool
---- Framework.VectorHelper::Approximately 0x2cc3268
02cc3268: fabd    s0, s0, s1                                 
02cc326c: fcmp    s0, s2                                     
02cc3270: cset    w0, ls                                     
02cc3274: ret                                                
## CrossProduct2D(UnityEngine.Vector2 a, UnityEngine.Vector2 b) -> float
---- Framework.VectorHelper::CrossProduct2D 0x2cc3278
02cc3278: fmul    s1, s1, s2                                 
02cc327c: fmul    s0, s0, s3                                 
02cc3280: fsub    s0, s0, s1                                 
02cc3284: ret                                                
## IntersectLineSegments2D(UnityEngine.Vector2 p1start, UnityEngine.Vector2 p1end, UnityEngine.Vector2 p2start, UnityEngine.Vector2 p2end, UnityEngine.Vector2 intersection) -> bool
---- Framework.VectorHelper::IntersectLineSegments2D 0x2cc3288
02cc3288: sub     sp, sp, #0x80                              
02cc328c: stp     d11, d10, [sp, #0x40]                      
02cc3290: stp     d9, d8, [sp, #0x50]                        
02cc3294: str     x30, [sp, #0x60]                           
02cc3298: stp     x20, x19, [sp, #0x70]                      
02cc329c: fmov    s10, s7                                    
02cc32a0: fmov    s11, s6                                    
02cc32a4: adrp    x20, #0x662f000                            
02cc32a8: fmov    s8, s5                                     
02cc32ac: fmov    s9, s4                                     
02cc32b0: ldrb    w8, [x20, #0xc30]                          
02cc32b4: mov     x19, x0                                    
02cc32b8: tbnz    w8, #0, #0x2cc32e0                         
02cc32bc: adrp    x0, #0x6267000                             
02cc32c0: ldr     x0, [x0, #0x158]                           MS:Framework.VectorHelper::Swap
02cc32c4: stp     q3, q2, [sp]                               
02cc32c8: stp     q0, q1, [sp, #0x20]                        
02cc32cc: bl      #0x2b70db0                                 fn_2b70db0
02cc32d0: ldp     q3, q2, [sp]                               
02cc32d4: mov     w8, #1                                     
02cc32d8: ldp     q0, q1, [sp, #0x20]                        
02cc32dc: strb    w8, [x20, #0xc30]                          
02cc32e0: mov     v16.16b, v0.16b                            
02cc32e4: mov     v2.s[1], v3.s[0]                           
02cc32e8: adrp    x8, #0x1084000                             
02cc32ec: fsub    s18, s11, s9                               
02cc32f0: fsub    s3, s10, s8                                
02cc32f4: ldr     s6, [x8, #0xfe0]                           [1084fe0]=3d5df3603727c5ac f=1e-05,0.0541872
02cc32f8: str     xzr, [sp, #0x68]                           
02cc32fc: mov     v16.s[1], v1.s[0]                          
02cc3300: fsub    v17.2s, v2.2s, v16.2s                      
02cc3304: fsub    s2, s9, s0                                 
02cc3308: fsub    s0, s8, s1                                 
02cc330c: fmul    s4, s3, s17                                
02cc3310: fmul    s5, s18, v17.s[1]                          
02cc3314: fabd    s7, s4, s5                                 
02cc3318: fcmp    s7, s6                                     
02cc331c: b.ls    #0x2cc338c                                 
02cc3320: dup     v6.2s, v17.s[0]                            
02cc3324: mov     v7.16b, v17.16b                            
02cc3328: adrp    x8, #0x1086000                             
02cc332c: fsub    s1, s4, s5                                 
02cc3330: mov     v7.s[0], v3.s[0]                           
02cc3334: mov     v6.s[0], v18.s[0]                          
02cc3338: dup     v1.2s, v1.s[0]                             
02cc333c: fmul    v2.2s, v7.2s, v2.s[0]                      
02cc3340: fmul    v0.2s, v6.2s, v0.s[0]                      
02cc3344: fsub    v0.2s, v2.2s, v0.2s                        
02cc3348: ldr     q2, [x8, #0x810]                           [1086810]=3f8000003f800000 f=1,1
02cc334c: fdiv    v0.2s, v0.2s, v1.2s                        
02cc3350: mov     v1.16b, v0.16b                             
02cc3354: mov     v1.d[1], v0.d[0]                           
02cc3358: fcmge   v3.4s, v2.4s, v1.4s                        
02cc335c: fcmge   v1.4s, v1.4s, v2.4s                        
02cc3360: mvn     v2.16b, v3.16b                             
02cc3364: mvn     v1.16b, v1.16b                             
02cc3368: xtn     v2.4h, v2.4s                               
02cc336c: xtn     v1.4h, v1.4s                               
02cc3370: mov     v2.s[1], v1.s[1]                           
02cc3374: shl     v1.4h, v2.4h, #0xf                         
02cc3378: cmlt    v1.4h, v1.4h, #0                           
02cc337c: umaxv   h1, v1.4h                                  
02cc3380: fmov    w8, s1                                     
02cc3384: tbnz    w8, #0, #0x2cc33a4                         
02cc3388: b       #0x2cc3480                                 
02cc338c: mov     s4, v17.s[1]                               
02cc3390: fmul    s7, s17, s0                                
02cc3394: fmul    s5, s4, s2                                 
02cc3398: fabd    s5, s5, s7                                 
02cc339c: fcmp    s5, s6                                     
02cc33a0: b.ls    #0x2cc33e0                                 
02cc33a4: adrp    x20, #0x662f000                            
02cc33a8: ldrb    w8, [x20, #0xbda]                          
02cc33ac: cbnz    w8, #0x2cc33c4                             
02cc33b0: adrp    x0, #0x6266000                             
02cc33b4: ldr     x0, [x0, #0x970]                           T:UnityEngine.Vector2
02cc33b8: bl      #0x2b70db0                                 fn_2b70db0
02cc33bc: mov     w8, #1                                     
02cc33c0: strb    w8, [x20, #0xbda]                          
02cc33c4: adrp    x8, #0x6266000                             
02cc33c8: mov     w0, wzr                                    
02cc33cc: ldr     x8, [x8, #0x970]                           T:UnityEngine.Vector2
02cc33d0: ldr     x8, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cc33d4: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02cc33d8: ldr     d0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cc33dc: b       #0x2cc348c                                 
02cc33e0: fmul    v5.2s, v17.2s, v17.2s                      
02cc33e4: fmul    s6, s4, s4                                 
02cc33e8: fmul    s3, s4, s3                                 
02cc33ec: fmul    s1, s17, s18                               
02cc33f0: fadd    s5, s5, s6                                 
02cc33f4: fadd    s3, s1, s3                                 
02cc33f8: fdiv    s6, s17, s5                                
02cc33fc: fcmp    s3, #0.0                                   
02cc3400: fdiv    s7, s4, s5                                 
02cc3404: fmul    s1, s2, s6                                 
02cc3408: fdiv    s4, s3, s5                                 
02cc340c: fmul    s0, s0, s7                                 
02cc3410: fadd    s1, s1, s0                                 
02cc3414: fadd    s0, s1, s4                                 
02cc3418: stp     s0, s1, [sp, #0x68]                        
02cc341c: b.pl    #0x2cc3444                                 
02cc3420: adrp    x8, #0x6267000                             
02cc3424: add     x0, sp, #0x6c                              
02cc3428: add     x1, sp, #0x68                              
02cc342c: ldr     x8, [x8, #0x158]                           MS:Framework.VectorHelper::Swap
02cc3430: stp     q17, q16, [sp, #0x20]                      
02cc3434: ldr     x2, [x8]                                   S:'didu'
02cc3438: bl      #0x3435f14                                 fn_3435f14
02cc343c: ldp     q17, q16, [sp, #0x20]                      
02cc3440: ldp     s0, s1, [sp, #0x68]                        
02cc3444: fmov    s2, #1.00000000                            
02cc3448: fcmp    s1, s2                                     
02cc344c: b.hi    #0x2cc33a4                                 
02cc3450: fcmp    s0, #0.0                                   
02cc3454: b.lt    #0x2cc33a4                                 
02cc3458: movi    d2, #0000000000000000                      
02cc345c: fcmp    s1, #0.0                                   
02cc3460: fmov    s3, #1.00000000                            
02cc3464: fcsel   s1, s2, s1, mi                             
02cc3468: fcmp    s0, s3                                     
02cc346c: fmov    s2, #0.50000000                            
02cc3470: fcsel   s0, s3, s0, gt                             
02cc3474: fsub    s0, s0, s1                                 
02cc3478: fmul    s0, s0, s2                                 
02cc347c: fadd    s0, s1, s0                                 
02cc3480: fmul    v0.2s, v17.2s, v0.s[0]                     
02cc3484: mov     w0, #1                                     
02cc3488: fadd    v0.2s, v16.2s, v0.2s                       
02cc348c: str     d0, [x19]                                  
02cc3490: ldp     x20, x19, [sp, #0x70]                      
02cc3494: ldp     d9, d8, [sp, #0x50]                        
02cc3498: ldr     x30, [sp, #0x60]                           
02cc349c: ldp     d11, d10, [sp, #0x40]                      
02cc34a0: add     sp, sp, #0x80                              
02cc34a4: ret                                                
