#### CLASS Clicker.PrinterMachine parent= UnityEngine.MonoBehaviour
#   field _printerProcess                Clicker.PrinterProcess                             off=0x20 attr=1 SerializeField
#   field _printerRail                   Clicker.PrinterRail                                off=0x28 attr=1 SerializeField
#   field _printer2DButton               Clicker.Printer2DButton                            off=0x30 attr=1 SerializeField
#   field _tfBasePrinterKeycapHolder     UnityEngine.Transform                              off=0x38 attr=1 SerializeField
#   field _currentBasePrinter            Clicker.BasePrinterObject                          off=0x40 attr=1 SerializeField
#   field _goHandTutorial                UnityEngine.GameObject                             off=0x48 attr=1 SerializeField
#   field _isProcessing                  bool                                               off=0x50 attr=1 
#   field _nextTimer                     float                                              off=0x54 attr=1 
#   field _soundChannel                  Framework.SoundChannel                             off=0x58 attr=1 
## Awake() -> void
---- Clicker.PrinterMachine::Awake 0x2d646f4
02d646f4: stp     x30, x19, [sp, #-0x10]!                    
02d646f8: mov     x19, x0                                    
02d646fc: ldr     x0, [x0, #0x30]                            ._printer2DButton
02d64700: cbz     x0, #0x2d6472c                             
02d64704: mov     x1, x19                                    
02d64708: bl      #0x2d643dc                                 Clicker.Printer2DButton::Init
02d6470c: ldr     x0, [x19, #0x20]                           ._printerProcess
02d64710: cbz     x0, #0x2d6472c                             
02d64714: bl      #0x2d64730                                 Clicker.PrinterProcess::ResetStatus
02d64718: ldr     x0, [x19, #0x20]                           ._printerProcess
02d6471c: cbz     x0, #0x2d6472c                             
02d64720: mov     w1, wzr                                    
02d64724: ldp     x30, x19, [sp], #0x10                      
02d64728: b       #0x2d6485c                                 Clicker.PrinterProcess::OnMachineStateChange
02d6472c: bl      #0x2b7105c                                 fn_2b7105c
## OnDisable() -> void
---- Clicker.PrinterMachine::OnDisable 0x2d648a4
02d648a4: stp     x30, x21, [sp, #-0x20]!                    
02d648a8: stp     x20, x19, [sp, #0x10]                      
02d648ac: adrp    x21, #0x6630000                            
02d648b0: adrp    x20, #0x6263000                            
02d648b4: mov     x19, x0                                    
02d648b8: ldrb    w8, [x21, #0x31c]                          
02d648bc: ldr     x20, [x20, #0x918]                         T:UnityEngine.Object
02d648c0: tbnz    w8, #0, #0x2d648d8                         
02d648c4: adrp    x0, #0x6263000                             
02d648c8: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d648cc: bl      #0x2b70db0                                 fn_2b70db0
02d648d0: mov     w8, #1                                     
02d648d4: strb    w8, [x21, #0x31c]                          
02d648d8: ldr     x0, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d648dc: ldr     x20, [x19, #0x58]!                         ._soundChannel
02d648e0: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d648e4: cbnz    w8, #0x2d648ec                             
02d648e8: bl      #0x2b70f30                                 fn_2b70f30
02d648ec: mov     x0, x20                                    
02d648f0: mov     x1, xzr                                    
02d648f4: mov     x2, xzr                                    
02d648f8: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d648fc: tbz     w0, #0, #0x2d64928                         
02d64900: ldr     x0, [x19]                                  
02d64904: cbz     x0, #0x2d64934                             
02d64908: mov     x1, xzr                                    
02d6490c: bl      #0x2d86940                                 Framework.SoundChannel::Stop
02d64910: mov     x0, x19                                    
02d64914: str     xzr, [x19]                                 
02d64918: mov     x1, xzr                                    
02d6491c: ldp     x20, x19, [sp, #0x10]                      
02d64920: ldp     x30, x21, [sp], #0x20                      
02d64924: b       #0x2b70d54                                 
02d64928: ldp     x20, x19, [sp, #0x10]                      
02d6492c: ldp     x30, x21, [sp], #0x20                      
02d64930: ret                                                
02d64934: bl      #0x2b7105c                                 fn_2b7105c
## OnDestroy() -> void
---- Clicker.PrinterMachine::OnDestroy 0x2d64938
02d64938: stp     x30, x21, [sp, #-0x20]!                    
02d6493c: stp     x20, x19, [sp, #0x10]                      
02d64940: adrp    x21, #0x6630000                            
02d64944: adrp    x20, #0x6263000                            
02d64948: mov     x19, x0                                    
02d6494c: ldrb    w8, [x21, #0x31d]                          
02d64950: ldr     x20, [x20, #0x918]                         T:UnityEngine.Object
02d64954: tbnz    w8, #0, #0x2d6496c                         
02d64958: adrp    x0, #0x6263000                             
02d6495c: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d64960: bl      #0x2b70db0                                 fn_2b70db0
02d64964: mov     w8, #1                                     
02d64968: strb    w8, [x21, #0x31d]                          
02d6496c: ldr     x0, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d64970: ldr     x20, [x19, #0x58]!                         ._soundChannel
02d64974: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d64978: cbnz    w8, #0x2d64980                             
02d6497c: bl      #0x2b70f30                                 fn_2b70f30
02d64980: mov     x0, x20                                    
02d64984: mov     x1, xzr                                    
02d64988: mov     x2, xzr                                    
02d6498c: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d64990: tbz     w0, #0, #0x2d649bc                         
02d64994: ldr     x0, [x19]                                  
02d64998: cbz     x0, #0x2d649c8                             
02d6499c: mov     x1, xzr                                    
02d649a0: bl      #0x2d86940                                 Framework.SoundChannel::Stop
02d649a4: mov     x0, x19                                    
02d649a8: str     xzr, [x19]                                 
02d649ac: mov     x1, xzr                                    
02d649b0: ldp     x20, x19, [sp, #0x10]                      
02d649b4: ldp     x30, x21, [sp], #0x20                      
02d649b8: b       #0x2b70d54                                 
02d649bc: ldp     x20, x19, [sp, #0x10]                      
02d649c0: ldp     x30, x21, [sp], #0x20                      
02d649c4: ret                                                
02d649c8: bl      #0x2b7105c                                 fn_2b7105c
## ResetStatus() -> void
---- Clicker.PrinterMachine::ResetStatus 0x2d649cc
02d649cc: stp     x30, x19, [sp, #-0x10]!                    
02d649d0: mov     x19, x0                                    
02d649d4: ldr     x0, [x0, #0x20]                            ._printerProcess
02d649d8: strb    wzr, [x19, #0x50]                          ._isProcessing
02d649dc: cbz     x0, #0x2d64a18                             
02d649e0: bl      #0x2d64730                                 Clicker.PrinterProcess::ResetStatus
02d649e4: ldr     x0, [x19, #0x20]                           ._printerProcess
02d649e8: cbz     x0, #0x2d64a18                             
02d649ec: mov     w1, wzr                                    
02d649f0: bl      #0x2d6485c                                 Clicker.PrinterProcess::OnMachineStateChange
02d649f4: ldr     x0, [x19, #0x28]                           ._printerRail
02d649f8: cbz     x0, #0x2d64a18                             
02d649fc: bl      #0x2d64a1c                                 Clicker.PrinterRail::ResetRails
02d64a00: ldr     x0, [x19, #0x48]                           ._goHandTutorial
02d64a04: cbz     x0, #0x2d64a18                             
02d64a08: mov     w1, #1                                     
02d64a0c: mov     x2, xzr                                    
02d64a10: ldp     x30, x19, [sp], #0x10                      
02d64a14: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d64a18: bl      #0x2b7105c                                 fn_2b7105c
## OnPrinterButtonClick() -> void
---- Clicker.PrinterMachine::OnPrinterButtonClick 0x2d64514
02d64514: str     x30, [sp, #-0x30]!                         
02d64518: stp     x22, x21, [sp, #0x10]                      
02d6451c: stp     x20, x19, [sp, #0x20]                      
02d64520: adrp    x20, #0x6630000                            
02d64524: mov     x19, x0                                    
02d64528: ldrb    w8, [x20, #0x31e]                          
02d6452c: tbnz    w8, #0, #0x2d64568                         
02d64530: adrp    x0, #0x6264000                             
02d64534: ldr     x0, [x0, #0xf90]                           T:System.Action
02d64538: bl      #0x2b70db0                                 fn_2b70db0
02d6453c: adrp    x0, #0x6267000                             
02d64540: ldr     x0, [x0, #0xbd0]                           MS:MonoSingleton`1::get_Instance
02d64544: bl      #0x2b70db0                                 fn_2b70db0
02d64548: adrp    x0, #0x626c000                             
02d6454c: ldr     x0, [x0, #0xe0]                            M:Clicker.PrinterMachine::<OnPrinterButtonClick>b__13_0
02d64550: bl      #0x2b70db0                                 fn_2b70db0
02d64554: adrp    x0, #0x626c000                             
02d64558: ldr     x0, [x0, #0xe8]                            MS:UIManager::GetScreen
02d6455c: bl      #0x2b70db0                                 fn_2b70db0
02d64560: mov     w8, #1                                     
02d64564: strb    w8, [x20, #0x31e]                          
02d64568: mov     x0, xzr                                    
02d6456c: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d64570: cbz     x0, #0x2d646bc                             
02d64574: movi    d1, #0000000000000000                      
02d64578: movi    d2, #0000000000000000                      
02d6457c: mov     w1, #0x22                                  
02d64580: fmov    s0, #1.00000000                            
02d64584: mov     w2, wzr                                    
02d64588: mov     w3, wzr                                    
02d6458c: mov     x4, xzr                                    
02d64590: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d64594: mov     x0, xzr                                    
02d64598: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d6459c: cbz     x0, #0x2d646bc                             
02d645a0: movi    d1, #0000000000000000                      
02d645a4: movi    d2, #0000000000000000                      
02d645a8: mov     w1, #0x21                                  
02d645ac: fmov    s0, #1.00000000                            
02d645b0: mov     w2, #1                                     
02d645b4: mov     w3, wzr                                    
02d645b8: mov     x4, xzr                                    
02d645bc: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d645c0: mov     x20, x19                                   
02d645c4: mov     x1, x0                                     
02d645c8: str     x0, [x20, #0x58]!                          ._soundChannel
02d645cc: mov     x0, x20                                    
02d645d0: bl      #0x2b70d54                                 fn_2b70d54
02d645d4: ldur    x0, [x20, #-0x10]                          
02d645d8: cbz     x0, #0x2d646bc                             
02d645dc: mov     w1, wzr                                    
02d645e0: mov     x2, xzr                                    
02d645e4: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d645e8: ldr     x8, [x19, #0x30]                           ._printer2DButton
02d645ec: cbz     x8, #0x2d646bc                             
02d645f0: ldr     x0, [x8, #0x20]                            
02d645f4: cbz     x0, #0x2d646bc                             
02d645f8: mov     w1, wzr                                    
02d645fc: mov     x2, xzr                                    
02d64600: bl      #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d64604: ldr     x0, [x19, #0x20]                           ._printerProcess
02d64608: cbz     x0, #0x2d646bc                             
02d6460c: bl      #0x2d64730                                 Clicker.PrinterProcess::ResetStatus
02d64610: ldr     x0, [x19, #0x20]                           ._printerProcess
02d64614: cbz     x0, #0x2d646bc                             
02d64618: mov     w1, #1                                     
02d6461c: mov     w20, #1                                    
02d64620: bl      #0x2d6485c                                 Clicker.PrinterProcess::OnMachineStateChange
02d64624: ldr     x0, [x19, #0x28]                           ._printerRail
02d64628: cbz     x0, #0x2d646bc                             
02d6462c: adrp    x21, #0x6267000                            
02d64630: ldr     x21, [x21, #0xbd0]                         MS:MonoSingleton`1::get_Instance
02d64634: bl      #0x2d64a1c                                 Clicker.PrinterRail::ResetRails
02d64638: ldr     x0, [x21]                                  S:'didu'
02d6463c: strb    w20, [x19, #0x50]                          ._isProcessing
02d64640: bl      #0x3769600                                 fn_3769600
02d64644: cbz     x0, #0x2d646bc                             
02d64648: adrp    x8, #0x626c000                             
02d6464c: ldr     x8, [x8, #0xe8]                            MS:UIManager::GetScreen
02d64650: ldr     x1, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d64654: bl      #0x33fbbd0                                 fn_33fbbd0
02d64658: cbz     x0, #0x2d646bc                             
02d6465c: ldr     x0, [x0, #0x58]                            T:UnityEngine.EventSystems.EventTrigger/TriggerEvent ._soundChannel
02d64660: cbz     x0, #0x2d646bc                             
02d64664: adrp    x21, #0x6264000                            
02d64668: adrp    x22, #0x626c000                            
02d6466c: mov     w1, #1                                     
02d64670: ldr     x21, [x21, #0xf90]                         T:System.Action
02d64674: ldr     x22, [x22, #0xe0]                          M:Clicker.PrinterMachine::<OnPrinterButtonClick>b__13_0
02d64678: mov     x2, xzr                                    
02d6467c: bl      #0x2d70e3c                                 Clicker.Printer3DUIContent::ShowBtnSpeedUp
02d64680: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d64684: ldr     x20, [x19, #0x28]                          ._printerRail
02d64688: bl      #0x2b7104c                                 fn_2b7104c
02d6468c: ldr     x2, [x22]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d64690: mov     x1, x19                                    
02d64694: mov     x3, xzr                                    
02d64698: mov     x21, x0                                    
02d6469c: bl      #0x4d8ddbc                                 System.Action::.ctor
02d646a0: cbz     x20, #0x2d646bc                            
02d646a4: mov     x0, x20                                    
02d646a8: mov     x1, x21                                    
02d646ac: ldp     x20, x19, [sp, #0x20]                      
02d646b0: ldp     x22, x21, [sp, #0x10]                      
02d646b4: ldr     x30, [sp], #0x30                           
02d646b8: b       #0x2d64a9c                                 Clicker.PrinterRail::StartMoveRail
02d646bc: bl      #0x2b7105c                                 fn_2b7105c
## OnSpeedUpButtonClick() -> void
---- Clicker.PrinterMachine::OnSpeedUpButtonClick 0x2d646e0
02d646e0: ldr     x0, [x0, #0x28]                            ._printerRail
02d646e4: cbz     x0, #0x2d646ec                             
02d646e8: b       #0x2d64b84                                 Clicker.PrinterRail::SpeedUp
02d646ec: str     x30, [sp, #-0x10]!                         
02d646f0: bl      #0x2b7105c                                 fn_2b7105c
## Update() -> void
---- Clicker.PrinterMachine::Update 0x2d64be0
02d64be0: str     d8, [sp, #-0x20]!                          
02d64be4: stp     x30, x19, [sp, #0x10]                      
02d64be8: ldrb    w8, [x0, #0x50]                            ._isProcessing
02d64bec: cbz     w8, #0x2d64c44                             
02d64bf0: mov     x19, x0                                    
02d64bf4: ldr     s8, [x0, #0x54]                            ._nextTimer
02d64bf8: mov     x0, xzr                                    
02d64bfc: bl      #0x5b432fc                                 UnityEngine.Time::get_time
02d64c00: fcmp    s8, s0                                     
02d64c04: b.pl    #0x2d64c44                                 
02d64c08: mov     x0, xzr                                    
02d64c0c: bl      #0x5b432fc                                 UnityEngine.Time::get_time
02d64c10: adrp    x8, #0x1084000                             
02d64c14: ldr     x0, [x19, #0x28]                           ._printerRail
02d64c18: ldr     s1, [x8, #0xeec]                           [1084eec]=457ff0003dcccccd f=0.1,4095
02d64c1c: fadd    s0, s0, s1                                 
02d64c20: str     s0, [x19, #0x54]                           ._nextTimer
02d64c24: cbz     x0, #0x2d64c50                             
02d64c28: ldr     x19, [x19, #0x20]                          ._printerProcess
02d64c2c: bl      #0x2d64c54                                 Clicker.PrinterRail::get_Progress
02d64c30: cbz     x19, #0x2d64c50                            
02d64c34: mov     x0, x19                                    
02d64c38: ldp     x30, x19, [sp, #0x10]                      
02d64c3c: ldr     d8, [sp], #0x20                            
02d64c40: b       #0x2d64cc4                                 Clicker.PrinterProcess::SetProcess
02d64c44: ldp     x30, x19, [sp, #0x10]                      
02d64c48: ldr     d8, [sp], #0x20                            
02d64c4c: ret                                                
02d64c50: bl      #0x2b7105c                                 fn_2b7105c
## ChangeBaseKeycap(Clicker.BasePrinterObject basePrinterObject) -> void
---- Clicker.PrinterMachine::ChangeBaseKeycap 0x2d64dd8
02d64dd8: stp     x30, x23, [sp, #-0x30]!                    
02d64ddc: stp     x22, x21, [sp, #0x10]                      
02d64de0: stp     x20, x19, [sp, #0x20]                      
02d64de4: adrp    x20, #0x6630000                            
02d64de8: adrp    x23, #0x6263000                            
02d64dec: mov     x21, x1                                    
02d64df0: ldrb    w8, [x20, #0x31f]                          
02d64df4: ldr     x23, [x23, #0x918]                         T:UnityEngine.Object
02d64df8: mov     x19, x0                                    
02d64dfc: tbnz    w8, #0, #0x2d64e20                         
02d64e00: adrp    x0, #0x626c000                             
02d64e04: ldr     x0, [x0, #0x110]                           MS:UnityEngine.Object::Instantiate
02d64e08: bl      #0x2b70db0                                 fn_2b70db0
02d64e0c: adrp    x0, #0x6263000                             
02d64e10: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d64e14: bl      #0x2b70db0                                 fn_2b70db0
02d64e18: mov     w8, #1                                     
02d64e1c: strb    w8, [x20, #0x31f]                          
02d64e20: ldr     x0, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d64e24: mov     x20, x19                                   
02d64e28: ldr     x22, [x20, #0x40]!                         ._currentBasePrinter
02d64e2c: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d64e30: cbnz    w8, #0x2d64e38                             
02d64e34: bl      #0x2b70f30                                 fn_2b70f30
02d64e38: mov     x0, x22                                    
02d64e3c: mov     x1, xzr                                    
02d64e40: mov     x2, xzr                                    
02d64e44: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d64e48: tbz     w0, #0, #0x2d64e80                         
02d64e4c: ldr     x0, [x20]                                  
02d64e50: cbz     x0, #0x2d64f80                             
02d64e54: mov     x1, xzr                                    
02d64e58: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d64e5c: ldr     x8, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d64e60: mov     x22, x0                                    
02d64e64: ldr     w9, [x8, #0xe4]                            
02d64e68: cbnz    w9, #0x2d64e74                             
02d64e6c: mov     x0, x8                                     
02d64e70: bl      #0x2b70f30                                 fn_2b70f30
02d64e74: mov     x0, x22                                    
02d64e78: mov     x1, xzr                                    
02d64e7c: bl      #0x5b3ca38                                 UnityEngine.Object::Destroy
02d64e80: ldr     x0, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d64e84: adrp    x23, #0x626c000                            
02d64e88: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d64e8c: ldr     x23, [x23, #0x110]                         MS:UnityEngine.Object::Instantiate
02d64e90: ldr     x22, [x19, #0x38]                          ._tfBasePrinterKeycapHolder
02d64e94: cbnz    w8, #0x2d64e9c                             
02d64e98: bl      #0x2b70f30                                 fn_2b70f30
02d64e9c: ldr     x2, [x23]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d64ea0: mov     x0, x21                                    
02d64ea4: mov     x1, x22                                    
02d64ea8: bl      #0x3275fcc                                 fn_3275fcc
02d64eac: mov     x1, x0                                     
02d64eb0: str     x0, [x20]                                  
02d64eb4: mov     x0, x20                                    
02d64eb8: bl      #0x2b70d54                                 fn_2b70d54
02d64ebc: ldr     x0, [x20]                                  
02d64ec0: cbz     x0, #0x2d64f80                             
02d64ec4: mov     x1, xzr                                    
02d64ec8: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d64ecc: adrp    x22, #0x662f000                            
02d64ed0: mov     x21, x0                                    
02d64ed4: ldrb    w8, [x22, #0x91a]                          
02d64ed8: cbnz    w8, #0x2d64ef0                             
02d64edc: adrp    x0, #0x6264000                             
02d64ee0: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d64ee4: bl      #0x2b70db0                                 fn_2b70db0
02d64ee8: mov     w8, #1                                     
02d64eec: strb    w8, [x22, #0x91a]                          
02d64ef0: cbz     x21, #0x2d64f80                            
02d64ef4: adrp    x22, #0x6264000                            
02d64ef8: mov     x0, x21                                    
02d64efc: mov     x1, xzr                                    
02d64f00: ldr     x22, [x22, #0xd8]                          T:UnityEngine.Vector3
02d64f04: ldr     x8, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d64f08: ldr     x8, [x8, #0xb8]                            
02d64f0c: ldp     s1, s2, [x8, #4]                           
02d64f10: ldr     s0, [x8]                                   
02d64f14: bl      #0x5b45cec                                 UnityEngine.Transform::set_localPosition
02d64f18: ldr     x0, [x20]                                  
02d64f1c: cbz     x0, #0x2d64f80                             
02d64f20: mov     x1, xzr                                    
02d64f24: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d64f28: adrp    x21, #0x662f000                            
02d64f2c: mov     x20, x0                                    
02d64f30: ldrb    w8, [x21, #0xa74]                          
02d64f34: cbnz    w8, #0x2d64f4c                             
02d64f38: adrp    x0, #0x6264000                             
02d64f3c: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d64f40: bl      #0x2b70db0                                 fn_2b70db0
02d64f44: mov     w8, #1                                     
02d64f48: strb    w8, [x21, #0xa74]                          
02d64f4c: cbz     x20, #0x2d64f80                            
02d64f50: ldr     x8, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d64f54: mov     x0, x20                                    
02d64f58: mov     x1, xzr                                    
02d64f5c: ldr     x8, [x8, #0xb8]                            
02d64f60: ldp     s1, s2, [x8, #0x10]                        
02d64f64: ldr     s0, [x8, #0xc]                             
02d64f68: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d64f6c: mov     x0, x19                                    
02d64f70: ldp     x20, x19, [sp, #0x20]                      
02d64f74: ldp     x22, x21, [sp, #0x10]                      
02d64f78: ldp     x30, x23, [sp], #0x30                      
02d64f7c: b       #0x2d64f84                                 Clicker.PrinterMachine::OnBaseKeycapChange
02d64f80: bl      #0x2b7105c                                 fn_2b7105c
## OnBaseKeycapChange() -> void
---- Clicker.PrinterMachine::OnBaseKeycapChange 0x2d64f84
02d64f84: str     d8, [sp, #-0x20]!                          
02d64f88: str     x30, [sp, #8]                              
02d64f8c: stp     x20, x19, [sp, #0x10]                      
02d64f90: ldr     x8, [x0, #0x40]                            ._currentBasePrinter
02d64f94: cbz     x8, #0x2d64ff4                             
02d64f98: mov     x19, x0                                    
02d64f9c: ldr     x0, [x8, #0x28]                            
02d64fa0: cbz     x0, #0x2d64ff4                             
02d64fa4: ldr     x20, [x19, #0x28]                          ._printerRail
02d64fa8: mov     x1, xzr                                    
02d64fac: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d64fb0: ldr     x8, [x19, #0x40]                           ._currentBasePrinter
02d64fb4: cbz     x8, #0x2d64ff4                             
02d64fb8: ldr     x0, [x8, #0x20]                            
02d64fbc: cbz     x0, #0x2d64ff4                             
02d64fc0: mov     x1, xzr                                    
02d64fc4: fmov    s8, s1                                     
02d64fc8: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d64fcc: cbz     x20, #0x2d64ff4                            
02d64fd0: fmov    s0, s8                                     
02d64fd4: mov     x0, x20                                    
02d64fd8: bl      #0x2d64ff8                                 Clicker.PrinterRail::SetLimit
02d64fdc: ldr     x0, [x19, #0x28]                           ._printerRail
02d64fe0: cbz     x0, #0x2d64ff4                             
02d64fe4: ldp     x20, x19, [sp, #0x10]                      
02d64fe8: ldr     x30, [sp, #8]                              
02d64fec: ldr     d8, [sp], #0x20                            
02d64ff0: b       #0x2d64a1c                                 Clicker.PrinterRail::ResetRails
02d64ff4: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Clicker.PrinterMachine::.ctor 0x2d6504c
02d6504c: mov     x1, xzr                                    
02d65050: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
## <OnPrinterButtonClick>b__13_0() -> void
---- Clicker.PrinterMachine::<OnPrinterButtonClick>b__13_0 0x2d65054
02d65054: stp     x30, x21, [sp, #-0x20]!                    
02d65058: stp     x20, x19, [sp, #0x10]                      
02d6505c: adrp    x21, #0x6630000                            
02d65060: adrp    x20, #0x6263000                            
02d65064: mov     x19, x0                                    
02d65068: ldrb    w8, [x21, #0x320]                          
02d6506c: ldr     x20, [x20, #0x918]                         T:UnityEngine.Object
02d65070: tbnz    w8, #0, #0x2d650a0                         
02d65074: adrp    x0, #0x6267000                             
02d65078: ldr     x0, [x0, #0xbd0]                           MS:MonoSingleton`1::get_Instance
02d6507c: bl      #0x2b70db0                                 fn_2b70db0
02d65080: adrp    x0, #0x6263000                             
02d65084: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d65088: bl      #0x2b70db0                                 fn_2b70db0
02d6508c: adrp    x0, #0x626c000                             
02d65090: ldr     x0, [x0, #0xe8]                            MS:UIManager::GetScreen
02d65094: bl      #0x2b70db0                                 fn_2b70db0
02d65098: mov     w8, #1                                     
02d6509c: strb    w8, [x21, #0x320]                          
02d650a0: ldr     x0, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d650a4: mov     x20, x19                                   
02d650a8: ldr     x21, [x20, #0x58]!                         &2c497b4(=2a1f03e0d503245f) ._soundChannel
02d650ac: ldr     w8, [x0, #0xe4]                            [626c0e4]=0 f=0,0
02d650b0: cbnz    w8, #0x2d650b8                             
02d650b4: bl      #0x2b70f30                                 fn_2b70f30
02d650b8: mov     x0, x21                                    
02d650bc: mov     x1, xzr                                    
02d650c0: mov     x2, xzr                                    
02d650c4: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d650c8: tbz     w0, #0, #0x2d650ec                         
02d650cc: ldr     x0, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d650d0: cbz     x0, #0x2d65198                             
02d650d4: mov     x1, xzr                                    
02d650d8: bl      #0x2d86940                                 Framework.SoundChannel::Stop
02d650dc: mov     x0, x20                                    
02d650e0: mov     x1, xzr                                    
02d650e4: str     xzr, [x20]                                 
02d650e8: bl      #0x2b70d54                                 fn_2b70d54
02d650ec: mov     x0, xzr                                    
02d650f0: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d650f4: cbz     x0, #0x2d65198                             
02d650f8: movi    d1, #0000000000000000                      
02d650fc: movi    d2, #0000000000000000                      
02d65100: adrp    x8, #0x1084000                             
02d65104: adrp    x20, #0x6267000                            
02d65108: ldr     s0, [x8, #0xf10]                           [1084f10]=4110bc863e99999a f=0.3,9.04603
02d6510c: mov     w1, #0x20                                  
02d65110: ldr     x20, [x20, #0xbd0]                         MS:MonoSingleton`1::get_Instance
02d65114: mov     w2, wzr                                    
02d65118: mov     w3, wzr                                    
02d6511c: mov     x4, xzr                                    
02d65120: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d65124: ldr     x0, [x20]                                  S:'didu'
02d65128: bl      #0x3769600                                 fn_3769600
02d6512c: cbz     x0, #0x2d65198                             
02d65130: adrp    x21, #0x626c000                            
02d65134: ldr     x21, [x21, #0xe8]                          MS:UIManager::GetScreen
02d65138: ldr     x1, [x21]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d6513c: bl      #0x33fbbd0                                 fn_33fbbd0
02d65140: cbz     x0, #0x2d65198                             
02d65144: ldr     x0, [x0, #0x58]                            T:UnityEngine.EventSystems.EventTrigger/TriggerEvent ._soundChannel
02d65148: cbz     x0, #0x2d65198                             
02d6514c: mov     w1, wzr                                    
02d65150: mov     x2, xzr                                    
02d65154: bl      #0x2d70e3c                                 Clicker.Printer3DUIContent::ShowBtnSpeedUp
02d65158: ldr     x0, [x20]                                  S:'didu'
02d6515c: bl      #0x3769600                                 fn_3769600
02d65160: cbz     x0, #0x2d65198                             
02d65164: ldr     x1, [x21]                                  M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d65168: bl      #0x33fbbd0                                 fn_33fbbd0
02d6516c: cbz     x0, #0x2d65198                             
02d65170: mov     w1, #1                                     
02d65174: bl      #0x2d6519c                                 Clicker.IngameClickerScreen::ShowBtnNext
02d65178: ldr     x0, [x19, #0x20]                           ._printerProcess
02d6517c: cbz     x0, #0x2d65198                             
02d65180: mov     w1, wzr                                    
02d65184: bl      #0x2d6485c                                 Clicker.PrinterProcess::OnMachineStateChange
02d65188: strb    wzr, [x19, #0x50]                          ._isProcessing
02d6518c: ldp     x20, x19, [sp, #0x10]                      
02d65190: ldp     x30, x21, [sp], #0x20                      
02d65194: ret                                                
02d65198: bl      #0x2b7105c                                 fn_2b7105c
