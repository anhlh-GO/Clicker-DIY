#### CLASS IAPProduct parent= object
#   field productId                      IAPKey                                             off=0x10 attr=6 
#   field productType                    UnityEngine.Purchasing.ProductType                 off=0x14 attr=6 
#   field displayName                    string                                             off=0x18 attr=6 
#   field price                          int                                                off=0x20 attr=6 
#   field priceFloat                     float                                              off=0x24 attr=6 
## .ctor() -> void
---- IAPProduct::.ctor 0x2ca7fb4
02ca7fb4: mov     x1, xzr                                    
02ca7fb8: b       #0x4e53e9c                                 System.Object::.ctor
