#### CLASS LanguageItem/<>c__DisplayClass8_0 parent= object
#   field onSelected                     System.Action`1<LanguageItem>                      off=0x10 attr=6 
#   field <>4__this                      LanguageItem                                       off=0x18 attr=6 
## .ctor() -> void
---- LanguageItem/<>c__DisplayClass8_0::.ctor 0x2caff0c
02caff0c: mov     x1, xzr                                    
02caff10: b       #0x4e53e9c                                 System.Object::.ctor
## <Init>b__0() -> void
---- LanguageItem/<>c__DisplayClass8_0::<Init>b__0 0x2caff6c
02caff6c: ldr     x8, [x0, #0x10]                            .onSelected
02caff70: cbz     x8, #0x2caff88                             
02caff74: ldr     x1, [x0, #0x18]                            .<>4__this
02caff78: ldr     x0, [x8, #0x40]                            
02caff7c: ldr     x2, [x8, #0x28]                            
02caff80: ldr     x3, [x8, #0x18]                            
02caff84: br      x3                                         
02caff88: ret                                                
#### CLASS LanguageItem parent= UnityEngine.MonoBehaviour
#   field _button                        UnityEngine.UI.Button                              off=0x20 attr=1 SerializeField
#   field _boxImage                      UnityEngine.UI.Image                               off=0x28 attr=1 SerializeField
#   field _icon                          UnityEngine.UI.Image                               off=0x30 attr=1 SerializeField
#   field _titleText                     TMPro.TextMeshProUGUI                              off=0x38 attr=1 SerializeField
#   field _selectedIcon                  UnityEngine.GameObject                             off=0x40 attr=1 SerializeField
#   field _selectedBoxSprite             UnityEngine.Sprite                                 off=0x48 attr=1 SerializeField
#   field _unselectedBoxSprite           UnityEngine.Sprite                                 off=0x50 attr=1 SerializeField
#   field _isSelected                    bool                                               off=0x58 attr=1 
## Init(string title, UnityEngine.Sprite iconSprite, bool isSelected, System.Action`1<LanguageItem> onSelected) -> void
---- LanguageItem::Init 0x2cafdd4
02cafdd4: stp     x30, x25, [sp, #-0x40]!                    
02cafdd8: stp     x24, x23, [sp, #0x10]                      
02cafddc: stp     x22, x21, [sp, #0x20]                      
02cafde0: stp     x20, x19, [sp, #0x30]                      
02cafde4: adrp    x22, #0x662f000                            
02cafde8: adrp    x25, #0x6266000                            
02cafdec: mov     x24, x4                                    
02cafdf0: ldrb    w8, [x22, #0xb60]                          
02cafdf4: ldr     x25, [x25, #0x9e0]                         T:LanguageItem/<>c__DisplayClass8_0
02cafdf8: mov     w19, w3                                    
02cafdfc: mov     x21, x2                                    
02cafe00: mov     x23, x1                                    
02cafe04: mov     x20, x0                                    
02cafe08: tbnz    w8, #0, #0x2cafe38                         
02cafe0c: adrp    x0, #0x6266000                             
02cafe10: ldr     x0, [x0, #0x9e8]                           M:LanguageItem/<>c__DisplayClass8_0::<Init>b__0
02cafe14: bl      #0x2b70db0                                 fn_2b70db0
02cafe18: adrp    x0, #0x6266000                             
02cafe1c: ldr     x0, [x0, #0x9e0]                           T:LanguageItem/<>c__DisplayClass8_0
02cafe20: bl      #0x2b70db0                                 fn_2b70db0
02cafe24: adrp    x0, #0x6265000                             
02cafe28: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02cafe2c: bl      #0x2b70db0                                 fn_2b70db0
02cafe30: mov     w8, #1                                     
02cafe34: strb    w8, [x22, #0xb60]                          
02cafe38: ldr     x0, [x25]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cafe3c: bl      #0x2b7104c                                 fn_2b7104c
02cafe40: mov     x1, xzr                                    
02cafe44: mov     x22, x0                                    
02cafe48: bl      #0x4e53e9c                                 System.Object::.ctor
02cafe4c: cbz     x22, #0x2caff08                            
02cafe50: mov     x0, x22                                    
02cafe54: mov     x1, x24                                    
02cafe58: str     x24, [x0, #0x10]!                          
02cafe5c: bl      #0x2b70d54                                 fn_2b70d54
02cafe60: mov     x0, x22                                    
02cafe64: mov     x1, x20                                    
02cafe68: str     x20, [x0, #0x18]!                          
02cafe6c: bl      #0x2b70d54                                 fn_2b70d54
02cafe70: ldr     x0, [x20, #0x38]                           ._titleText
02cafe74: cbz     x0, #0x2caff08                             
02cafe78: ldr     x8, [x0]                                   M:AdsManager::<OnApplicationPause>b__26_0
02cafe7c: mov     x1, x23                                    
02cafe80: ldr     x9, [x8, #0x558]                           
02cafe84: ldr     x2, [x8, #0x560]                           
02cafe88: blr     x9                                         
02cafe8c: ldr     x0, [x20, #0x30]                           ._icon
02cafe90: cbz     x0, #0x2caff08                             
02cafe94: mov     x1, x21                                    
02cafe98: mov     x2, xzr                                    
02cafe9c: bl      #0x5c45aa0                                 UnityEngine.UI.Image::set_sprite
02cafea0: and     w1, w19, #1                                
02cafea4: mov     x0, x20                                    
02cafea8: bl      #0x2caff14                                 LanguageItem::SetSelected
02cafeac: ldr     x8, [x20, #0x20]                           ._button
02cafeb0: cbz     x8, #0x2caff08                             
02cafeb4: adrp    x9, #0x6265000                             
02cafeb8: adrp    x20, #0x6266000                            
02cafebc: ldr     x9, [x9, #0x3f0]                           T:UnityEngine.Events.UnityAction
02cafec0: ldr     x20, [x20, #0x9e8]                         M:LanguageItem/<>c__DisplayClass8_0::<Init>b__0
02cafec4: ldr     x19, [x8, #0x100]                          
02cafec8: ldr     x0, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02cafecc: bl      #0x2b7104c                                 fn_2b7104c
02cafed0: ldr     x2, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cafed4: mov     x1, x22                                    
02cafed8: mov     x3, xzr                                    
02cafedc: mov     x20, x0                                    
02cafee0: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02cafee4: cbz     x19, #0x2caff08                            
02cafee8: mov     x0, x19                                    
02cafeec: mov     x1, x20                                    
02cafef0: mov     x2, xzr                                    
02cafef4: ldp     x20, x19, [sp, #0x30]                      
02cafef8: ldp     x22, x21, [sp, #0x20]                      
02cafefc: ldp     x24, x23, [sp, #0x10]                      
02caff00: ldp     x30, x25, [sp], #0x40                      
02caff04: b       #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02caff08: bl      #0x2b7105c                                 fn_2b7105c
## SetSelected(bool isSelected) -> void
---- LanguageItem::SetSelected 0x2caff14
02caff14: stp     x30, x19, [sp, #-0x10]!                    
02caff18: mov     x19, x0                                    
02caff1c: ldr     x0, [x0, #0x40]                            ._selectedIcon
02caff20: strb    w1, [x19, #0x58]                           ._isSelected
02caff24: cbz     x0, #0x2caff60                             
02caff28: and     w1, w1, #1                                 
02caff2c: mov     x2, xzr                                    
02caff30: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02caff34: ldr     x0, [x19, #0x28]                           ._boxImage
02caff38: cbz     x0, #0x2caff60                             
02caff3c: ldrb    w8, [x19, #0x58]                           ._isSelected
02caff40: mov     w9, #0x50                                  
02caff44: mov     x2, xzr                                    
02caff48: cmp     w8, #0                                     
02caff4c: mov     w8, #0x48                                  
02caff50: csel    x8, x9, x8, eq                             
02caff54: ldr     x1, [x19, x8]                              
02caff58: ldp     x30, x19, [sp], #0x10                      
02caff5c: b       #0x5c45aa0                                 UnityEngine.UI.Image::set_sprite
02caff60: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- LanguageItem::.ctor 0x2caff64
02caff64: mov     x1, xzr                                    
02caff68: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
