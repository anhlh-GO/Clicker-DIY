#### CLASS DreamHouse.DecorItem/<>c__DisplayClass7_0 parent= object
#   field onClickCallback                System.Action`1<DreamHouse.DecorItem>              off=0x10 attr=6 
#   field <>4__this                      DreamHouse.DecorItem                               off=0x18 attr=6 
## .ctor() -> void
---- DreamHouse.DecorItem/<>c__DisplayClass7_0::.ctor 0x2d175f8
02d175f8: mov     x1, xzr                                    
02d175fc: b       #0x4e53e9c                                 System.Object::.ctor
## <OnInit>b__0() -> void
---- DreamHouse.DecorItem/<>c__DisplayClass7_0::<OnInit>b__0 0x2d17984
02d17984: ldr     x8, [x0, #0x10]                            .onClickCallback
02d17988: cbz     x8, #0x2d179a0                             
02d1798c: ldr     x1, [x0, #0x18]                            .<>4__this
02d17990: ldr     x0, [x8, #0x40]                            
02d17994: ldr     x2, [x8, #0x28]                            
02d17998: ldr     x3, [x8, #0x18]                            
02d1799c: br      x3                                         
02d179a0: ret                                                
#### CLASS DreamHouse.DecorItem parent= UnityEngine.MonoBehaviour
#   field _markPointButton               DreamHouse.ButtonObject                            off=0x20 attr=1 SerializeField
#   field _currentDecorObject            UnityEngine.GameObject                             off=0x28 attr=1 
#   field _currentItemIndex              int                                                off=0x30 attr=1 
#   field _decorItemAsset                DreamHouse.DecorItemAsset                          off=0x38 attr=1 
## get_MarkPointTransform() -> UnityEngine.Transform
---- DreamHouse.DecorItem::get_MarkPointTransform 0x2d17484
02d17484: ldr     x0, [x0, #0x20]                            ._markPointButton
02d17488: cbz     x0, #0x2d17494                             
02d1748c: mov     x1, xzr                                    
02d17490: b       #0x5b3391c                                 UnityEngine.Component::get_transform
02d17494: str     x30, [sp, #-0x10]!                         
02d17498: bl      #0x2b7105c                                 fn_2b7105c
## OnDestroy() -> void
---- DreamHouse.DecorItem::OnDestroy 0x2d1749c
02d1749c: str     x30, [sp, #-0x10]!                         
02d174a0: ldr     x8, [x0, #0x20]                            ._markPointButton
02d174a4: cbz     x8, #0x2d174bc                             
02d174a8: ldr     x0, [x8, #0x20]                            
02d174ac: cbz     x0, #0x2d174bc                             
02d174b0: mov     x1, xzr                                    
02d174b4: ldr     x30, [sp], #0x10                           
02d174b8: b       #0x5b4ce48                                 UnityEngine.Events.UnityEventBase::RemoveAllListeners
02d174bc: bl      #0x2b7105c                                 fn_2b7105c
## OnInit(DreamHouse.DecorItemAsset decorItemAsset, System.Action`1<DreamHouse.DecorItem> onClickCallback) -> DreamHouse.DecorItem
---- DreamHouse.DecorItem::OnInit 0x2d174c0
02d174c0: stp     x30, x23, [sp, #-0x30]!                    
02d174c4: stp     x22, x21, [sp, #0x10]                      
02d174c8: stp     x20, x19, [sp, #0x20]                      
02d174cc: adrp    x20, #0x662f000                            
02d174d0: adrp    x23, #0x6269000                            
02d174d4: mov     x22, x2                                    
02d174d8: ldrb    w8, [x20, #0xfe2]                          
02d174dc: ldr     x23, [x23, #0x9c8]                         T:DreamHouse.DecorItem/<>c__DisplayClass7_0
02d174e0: mov     x21, x1                                    
02d174e4: mov     x19, x0                                    
02d174e8: tbnz    w8, #0, #0x2d17518                         
02d174ec: adrp    x0, #0x6269000                             
02d174f0: ldr     x0, [x0, #0x9d0]                           M:DreamHouse.DecorItem/<>c__DisplayClass7_0::<OnInit>b__0
02d174f4: bl      #0x2b70db0                                 fn_2b70db0
02d174f8: adrp    x0, #0x6269000                             
02d174fc: ldr     x0, [x0, #0x9c8]                           T:DreamHouse.DecorItem/<>c__DisplayClass7_0
02d17500: bl      #0x2b70db0                                 fn_2b70db0
02d17504: adrp    x0, #0x6265000                             
02d17508: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d1750c: bl      #0x2b70db0                                 fn_2b70db0
02d17510: mov     w8, #1                                     
02d17514: strb    w8, [x20, #0xfe2]                          
02d17518: ldr     x0, [x23]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1751c: bl      #0x2b7104c                                 fn_2b7104c
02d17520: mov     x1, xzr                                    
02d17524: mov     x20, x0                                    
02d17528: bl      #0x4e53e9c                                 System.Object::.ctor
02d1752c: cbz     x20, #0x2d175f4                            
02d17530: mov     x0, x20                                    
02d17534: mov     x1, x22                                    
02d17538: str     x22, [x0, #0x10]!                          
02d1753c: bl      #0x2b70d54                                 fn_2b70d54
02d17540: mov     x0, x20                                    
02d17544: mov     x1, x19                                    
02d17548: str     x19, [x0, #0x18]!                          
02d1754c: bl      #0x2b70d54                                 fn_2b70d54
02d17550: mov     x22, x19                                   
02d17554: mov     x1, x21                                    
02d17558: str     x21, [x22, #0x38]!                         
02d1755c: mov     x0, x22                                    
02d17560: bl      #0x2b70d54                                 fn_2b70d54
02d17564: ldur    x0, [x22, #-0x18]                          
02d17568: cbz     x0, #0x2d175f4                             
02d1756c: mov     w1, wzr                                    
02d17570: bl      #0x2d15f04                                 DreamHouse.ButtonObject::SetInteractable
02d17574: ldr     x0, [x19, #0x20]                           ._markPointButton
02d17578: cbz     x0, #0x2d175f4                             
02d1757c: mov     x1, xzr                                    
02d17580: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d17584: cbz     x0, #0x2d175f4                             
02d17588: mov     w1, wzr                                    
02d1758c: mov     x2, xzr                                    
02d17590: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d17594: ldr     x8, [x19, #0x20]                           ._markPointButton
02d17598: cbz     x8, #0x2d175f4                             
02d1759c: adrp    x9, #0x6265000                             
02d175a0: adrp    x22, #0x6269000                            
02d175a4: ldr     x9, [x9, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d175a8: ldr     x22, [x22, #0x9d0]                         M:DreamHouse.DecorItem/<>c__DisplayClass7_0::<OnInit>b__0
02d175ac: ldr     x21, [x8, #0x20]                           
02d175b0: ldr     x0, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02d175b4: bl      #0x2b7104c                                 fn_2b7104c
02d175b8: ldr     x2, [x22]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d175bc: mov     x1, x20                                    
02d175c0: mov     x3, xzr                                    
02d175c4: mov     x22, x0                                    
02d175c8: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d175cc: cbz     x21, #0x2d175f4                            
02d175d0: mov     x0, x21                                    
02d175d4: mov     x1, x22                                    
02d175d8: mov     x2, xzr                                    
02d175dc: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d175e0: mov     x0, x19                                    
02d175e4: ldp     x20, x19, [sp, #0x20]                      
02d175e8: ldp     x22, x21, [sp, #0x10]                      
02d175ec: ldp     x30, x23, [sp], #0x30                      
02d175f0: ret                                                
02d175f4: bl      #0x2b7105c                                 fn_2b7105c
## SetActiveMarkPoint(bool isActive) -> void
---- DreamHouse.DecorItem::SetActiveMarkPoint 0x2d17600
02d17600: str     x30, [sp, #-0x20]!                         
02d17604: stp     x20, x19, [sp, #0x10]                      
02d17608: mov     x20, x0                                    
02d1760c: ldr     x0, [x0, #0x20]                            ._markPointButton
02d17610: cbz     x0, #0x2d17648                             
02d17614: mov     w19, w1                                    
02d17618: mov     x1, xzr                                    
02d1761c: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d17620: cbz     x0, #0x2d17648                             
02d17624: and     w1, w19, #1                                
02d17628: mov     x2, xzr                                    
02d1762c: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d17630: ldr     x0, [x20, #0x20]                           ._markPointButton
02d17634: cbz     x0, #0x2d17648                             
02d17638: and     w1, w19, #1                                
02d1763c: ldp     x20, x19, [sp, #0x10]                      
02d17640: ldr     x30, [sp], #0x20                           
02d17644: b       #0x2d15f04                                 DreamHouse.ButtonObject::SetInteractable
02d17648: bl      #0x2b7105c                                 fn_2b7105c
## CreateDecorItemObject(int itemIndex) -> UnityEngine.GameObject
---- DreamHouse.DecorItem::CreateDecorItemObject 0x2d1764c
02d1764c: str     x30, [sp, #-0x40]!                         
02d17650: stp     x24, x23, [sp, #0x10]                      
02d17654: stp     x22, x21, [sp, #0x20]                      
02d17658: stp     x20, x19, [sp, #0x30]                      
02d1765c: adrp    x19, #0x662f000                            
02d17660: adrp    x23, #0x6263000                            
02d17664: mov     w20, w1                                    
02d17668: ldrb    w8, [x19, #0xfe3]                          
02d1766c: ldr     x23, [x23, #0x918]                         T:UnityEngine.Object
02d17670: mov     x21, x0                                    
02d17674: tbnz    w8, #0, #0x2d176b0                         
02d17678: adrp    x0, #0x6263000                             
02d1767c: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02d17680: bl      #0x2b70db0                                 fn_2b70db0
02d17684: adrp    x0, #0x6264000                             
02d17688: ldr     x0, [x0, #0xec8]                           MS:UnityEngine.Object::Instantiate
02d1768c: bl      #0x2b70db0                                 fn_2b70db0
02d17690: adrp    x0, #0x6263000                             
02d17694: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d17698: bl      #0x2b70db0                                 fn_2b70db0
02d1769c: adrp    x0, #0x6269000                             
02d176a0: ldr     x0, [x0, #0x9d8]                           S:'Created Decor Item Object: '
02d176a4: bl      #0x2b70db0                                 fn_2b70db0
02d176a8: mov     w8, #1                                     
02d176ac: strb    w8, [x19, #0xfe3]                          
02d176b0: ldr     x0, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d176b4: mov     x19, x21                                   
02d176b8: ldr     x22, [x19, #0x28]!                         [662f028]=6000015 f=2.40742e-35,0 ._currentDecorObject
02d176bc: ldr     w8, [x0, #0xe4]                            [62690e4]=0 f=0,0
02d176c0: cbnz    w8, #0x2d176c8                             
02d176c4: bl      #0x2b70f30                                 fn_2b70f30
02d176c8: mov     x0, x22                                    
02d176cc: mov     x1, xzr                                    
02d176d0: mov     x2, xzr                                    
02d176d4: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d176d8: tbz     w0, #0, #0x2d176e8                         
02d176dc: ldr     w8, [x21, #0x30]                           ._currentItemIndex
02d176e0: cmp     w8, w20                                    
02d176e4: b.eq    #0x2d17890                                 
02d176e8: mov     x0, x21                                    
02d176ec: bl      #0x2d178ac                                 DreamHouse.DecorItem::RemoveDecorItemObject
02d176f0: ldr     x0, [x21, #0x38]                           ._decorItemAsset
02d176f4: str     w20, [x21, #0x30]                          ._currentItemIndex
02d176f8: cbz     x0, #0x2d178a8                             
02d176fc: mov     w1, w20                                    
02d17700: bl      #0x2d15c80                                 DreamHouse.DecorItemAsset::GetDecorItemConfigByIndex
02d17704: cbz     x0, #0x2d178a8                             
02d17708: adrp    x24, #0x6264000                            
02d1770c: mov     x20, x0                                    
02d17710: mov     x1, xzr                                    
02d17714: ldr     x24, [x24, #0xec8]                         MS:UnityEngine.Object::Instantiate
02d17718: ldr     x22, [x0, #0x20]                           M:Trading.TradingSession::<ValidateTrade>b__57_1 ._markPointButton
02d1771c: mov     x0, x21                                    
02d17720: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d17724: ldr     x8, [x23]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d17728: mov     x21, x0                                    
02d1772c: ldr     w9, [x8, #0xe4]                            
02d17730: cbnz    w9, #0x2d1773c                             
02d17734: mov     x0, x8                                     
02d17738: bl      #0x2b70f30                                 fn_2b70f30
02d1773c: ldr     x2, [x24]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d17740: mov     x0, x22                                    
02d17744: mov     x1, x21                                    
02d17748: bl      #0x3275fcc                                 fn_3275fcc
02d1774c: mov     x1, x0                                     
02d17750: str     x0, [x19]                                  
02d17754: mov     x0, x19                                    
02d17758: bl      #0x2b70d54                                 fn_2b70d54
02d1775c: ldr     x0, [x19]                                  &2b706c4(=eb01011ff9400808)
02d17760: cbz     x0, #0x2d178a8                             
02d17764: mov     x1, xzr                                    
02d17768: bl      #0x5b368f0                                 UnityEngine.GameObject::get_transform
02d1776c: cbz     x0, #0x2d178a8                             
02d17770: ldp     s1, s2, [x20, #0x2c]                       
02d17774: mov     x1, xzr                                    
02d17778: ldr     s0, [x20, #0x28]                           ._currentDecorObject
02d1777c: bl      #0x5b45cec                                 UnityEngine.Transform::set_localPosition
02d17780: ldr     x0, [x19]                                  &2b706c4(=eb01011ff9400808)
02d17784: cbz     x0, #0x2d178a8                             
02d17788: mov     x1, xzr                                    
02d1778c: bl      #0x5b368f0                                 UnityEngine.GameObject::get_transform
02d17790: adrp    x22, #0x662f000                            
02d17794: mov     x21, x0                                    
02d17798: ldrb    w8, [x22, #0xbdf]                          
02d1779c: cbnz    w8, #0x2d177b4                             
02d177a0: adrp    x0, #0x6266000                             
02d177a4: ldr     x0, [x0, #0xd30]                           T:UnityEngine.Quaternion
02d177a8: bl      #0x2b70db0                                 fn_2b70db0
02d177ac: mov     w8, #1                                     
02d177b0: strb    w8, [x22, #0xbdf]                          
02d177b4: cbz     x21, #0x2d178a8                            
02d177b8: adrp    x8, #0x6266000                             
02d177bc: mov     x0, x21                                    
02d177c0: mov     x1, xzr                                    
02d177c4: ldr     x8, [x8, #0xd30]                           T:UnityEngine.Quaternion
02d177c8: ldr     x8, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d177cc: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02d177d0: ldp     s2, s3, [x8, #8]                           
02d177d4: ldp     s0, s1, [x8]                               
02d177d8: bl      #0x5b46cdc                                 UnityEngine.Transform::set_localRotation
02d177dc: ldr     x0, [x19]                                  &2b706c4(=eb01011ff9400808)
02d177e0: cbz     x0, #0x2d178a8                             
02d177e4: mov     x1, xzr                                    
02d177e8: bl      #0x5b368f0                                 UnityEngine.GameObject::get_transform
02d177ec: adrp    x22, #0x662f000                            
02d177f0: mov     x21, x0                                    
02d177f4: ldrb    w8, [x22, #0xa74]                          
02d177f8: cbnz    w8, #0x2d17810                             
02d177fc: adrp    x0, #0x6264000                             
02d17800: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d17804: bl      #0x2b70db0                                 fn_2b70db0
02d17808: mov     w8, #1                                     
02d1780c: strb    w8, [x22, #0xa74]                          
02d17810: cbz     x21, #0x2d178a8                            
02d17814: adrp    x8, #0x6264000                             
02d17818: mov     x0, x21                                    
02d1781c: mov     x1, xzr                                    
02d17820: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02d17824: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d17828: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d1782c: ldp     s1, s2, [x8, #0x10]                        
02d17830: ldr     s0, [x8, #0xc]                             [626400c]=0 f=0,0
02d17834: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d17838: ldr     x0, [x20, #0x20]                           ._markPointButton
02d1783c: cbz     x0, #0x2d178a8                             
02d17840: adrp    x20, #0x6269000                            
02d17844: adrp    x21, #0x6263000                            
02d17848: mov     x1, xzr                                    
02d1784c: ldr     x20, [x20, #0x9d8]                         S:'Created Decor Item Object: '
02d17850: ldr     x21, [x21, #0x928]                         T:UnityEngine.Debug
02d17854: bl      #0x5b3bba4                                 UnityEngine.Object::get_name
02d17858: ldr     x8, [x20]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1785c: mov     x1, x0                                     
02d17860: mov     x2, xzr                                    
02d17864: mov     x0, x8                                     
02d17868: bl      #0x4c9c514                                 System.String::Concat
02d1786c: ldr     x8, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d17870: mov     x20, x0                                    
02d17874: ldr     w9, [x8, #0xe4]                            [62640e4]=0 f=0,0
02d17878: cbnz    w9, #0x2d17884                             
02d1787c: mov     x0, x8                                     
02d17880: bl      #0x2b70f30                                 fn_2b70f30
02d17884: mov     x0, x20                                    
02d17888: mov     x1, xzr                                    
02d1788c: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02d17890: ldr     x0, [x19]                                  &2b706c4(=eb01011ff9400808)
02d17894: ldp     x20, x19, [sp, #0x30]                      
02d17898: ldp     x22, x21, [sp, #0x20]                      
02d1789c: ldp     x24, x23, [sp, #0x10]                      
02d178a0: ldr     x30, [sp], #0x40                           
02d178a4: ret                                                
02d178a8: bl      #0x2b7105c                                 fn_2b7105c
## RemoveDecorItemObject() -> void
---- DreamHouse.DecorItem::RemoveDecorItemObject 0x2d178ac
02d178ac: stp     x30, x21, [sp, #-0x20]!                    
02d178b0: stp     x20, x19, [sp, #0x10]                      
02d178b4: adrp    x20, #0x662f000                            
02d178b8: adrp    x21, #0x6263000                            
02d178bc: mov     x19, x0                                    
02d178c0: ldrb    w8, [x20, #0xfe4]                          
02d178c4: ldr     x21, [x21, #0x918]                         T:UnityEngine.Object
02d178c8: tbnz    w8, #0, #0x2d178e0                         
02d178cc: adrp    x0, #0x6263000                             
02d178d0: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d178d4: bl      #0x2b70db0                                 fn_2b70db0
02d178d8: mov     w8, #1                                     
02d178dc: strb    w8, [x20, #0xfe4]                          
02d178e0: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d178e4: ldr     x20, [x19, #0x28]!                         ._currentDecorObject
02d178e8: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d178ec: cbnz    w8, #0x2d178f4                             
02d178f0: bl      #0x2b70f30                                 fn_2b70f30
02d178f4: mov     x0, x20                                    
02d178f8: mov     x1, xzr                                    
02d178fc: mov     x2, xzr                                    
02d17900: bl      #0x5b37d84                                 UnityEngine.Object::op_Equality
02d17904: tbz     w0, #0, #0x2d17914                         
02d17908: ldp     x20, x19, [sp, #0x10]                      
02d1790c: ldp     x30, x21, [sp], #0x20                      
02d17910: ret                                                
02d17914: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d17918: ldr     x20, [x19]                                 
02d1791c: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d17920: cbnz    w8, #0x2d17928                             
02d17924: bl      #0x2b70f30                                 fn_2b70f30
02d17928: mov     x0, x20                                    
02d1792c: mov     x1, xzr                                    
02d17930: bl      #0x5b3ca38                                 UnityEngine.Object::Destroy
02d17934: mov     x0, x19                                    
02d17938: str     xzr, [x19]                                 
02d1793c: mov     x1, xzr                                    
02d17940: ldp     x20, x19, [sp, #0x10]                      
02d17944: ldp     x30, x21, [sp], #0x20                      
02d17948: b       #0x2b70d54                                 
## GetMarkPointPos() -> UnityEngine.Vector3
---- DreamHouse.DecorItem::GetMarkPointPos 0x2d1794c
02d1794c: str     x30, [sp, #-0x10]!                         
02d17950: ldr     x0, [x0, #0x20]                            ._markPointButton
02d17954: cbz     x0, #0x2d17970                             
02d17958: mov     x1, xzr                                    
02d1795c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d17960: cbz     x0, #0x2d17970                             
02d17964: mov     x1, xzr                                    
02d17968: ldr     x30, [sp], #0x10                           
02d1796c: b       #0x5b467ac                                 UnityEngine.Transform::get_position
02d17970: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- DreamHouse.DecorItem::.ctor 0x2d17974
02d17974: mov     w8, #-1                                    
02d17978: mov     x1, xzr                                    
02d1797c: str     w8, [x0, #0x30]                            ._currentItemIndex
02d17980: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
