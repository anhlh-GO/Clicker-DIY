#### CLASS Blindbag.BillLine parent= PoolElement
#   field _itemNameText                  TMPro.TextMeshProUGUI                              off=0x28 attr=1 SerializeField
#   field _priceText                     TMPro.TextMeshProUGUI                              off=0x30 attr=1 SerializeField
#   field _totalPrice                    int                                                off=0x38 attr=1 
#   field _time                          int                                                off=0x3c attr=1 
#   field _itemName                      string                                             off=0x40 attr=1 
## get_TotalPrice() -> int
---- Blindbag.BillLine::get_TotalPrice 0x2d4fe64
02d4fe64: ldr     w0, [x0, #0x38]                            ._totalPrice
02d4fe68: ret                                                
## SetData(string itemName, int price, Spine.Unity.SkeletonAnimation bagSpine) -> void
---- Blindbag.BillLine::SetData 0x2d4fe6c
02d4fe6c: sub     sp, sp, #0x40                              
02d4fe70: stp     x30, x23, [sp, #0x10]                      
02d4fe74: stp     x22, x21, [sp, #0x20]                      
02d4fe78: stp     x20, x19, [sp, #0x30]                      
02d4fe7c: adrp    x23, #0x6630000                            
02d4fe80: adrp    x22, #0x6266000                            
02d4fe84: mov     w20, w2                                    
02d4fe88: ldrb    w8, [x23, #0x24c]                          
02d4fe8c: ldr     x22, [x22, #0x9f0]                         T:Assets.SimpleLocalization.Scripts.LocalizationManager
02d4fe90: mov     x21, x1                                    
02d4fe94: mov     x19, x0                                    
02d4fe98: str     w2, [sp, #0xc]                             
02d4fe9c: tbnz    w8, #0, #0x2d4fec0                         
02d4fea0: adrp    x0, #0x6266000                             
02d4fea4: ldr     x0, [x0, #0x9f0]                           T:Assets.SimpleLocalization.Scripts.LocalizationManager
02d4fea8: bl      #0x2b70db0                                 fn_2b70db0
02d4feac: adrp    x0, #0x626b000                             
02d4feb0: ldr     x0, [x0, #0x798]                           S:' x{0}'
02d4feb4: bl      #0x2b70db0                                 fn_2b70db0
02d4feb8: mov     w8, #1                                     
02d4febc: strb    w8, [x23, #0x24c]                          
02d4fec0: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d4fec4: adrp    x22, #0x626b000                            
02d4fec8: mov     w9, #1                                     
02d4fecc: ldr     w8, [x0, #0xe4]                            [626b0e4]=0 f=0,0
02d4fed0: ldr     x22, [x22, #0x798]                         S:' x{0}'
02d4fed4: str     w9, [x19, #0x3c]                           ._time
02d4fed8: cbnz    w8, #0x2d4fee0                             
02d4fedc: bl      #0x2b70f30                                 fn_2b70f30
02d4fee0: mov     x0, x21                                    
02d4fee4: mov     x1, xzr                                    
02d4fee8: bl      #0x2d76794                                 Assets.SimpleLocalization.Scripts.LocalizationManager::Localize
02d4feec: mov     x21, x19                                   
02d4fef0: mov     x1, x0                                     
02d4fef4: str     x0, [x21, #0x40]!                          ._itemName
02d4fef8: mov     x0, x21                                    
02d4fefc: bl      #0x2b70d54                                 fn_2b70d54
02d4ff00: adrp    x8, #0x6263000                             
02d4ff04: add     x1, sp, #8                                 
02d4ff08: ldr     x8, [x8, #0x970]                           &6645c70(=0)
02d4ff0c: ldur    w9, [x21, #-4]                             
02d4ff10: stur    w20, [x21, #-8]                            
02d4ff14: ldur    x20, [x21, #-0x18]                         
02d4ff18: ldr     x21, [x21]                                 
02d4ff1c: ldr     x0, [x8, #0x48]                            &6263098(=0)
02d4ff20: str     w9, [sp, #8]                               
02d4ff24: bl      #0x2b70f38                                 fn_2b70f38
02d4ff28: ldr     x8, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d4ff2c: mov     x1, x0                                     
02d4ff30: mov     x2, xzr                                    
02d4ff34: mov     x0, x8                                     
02d4ff38: bl      #0x4c9d0ec                                 System.String::Format
02d4ff3c: mov     x1, x0                                     
02d4ff40: mov     x0, x21                                    
02d4ff44: mov     x2, xzr                                    
02d4ff48: bl      #0x4c9c514                                 System.String::Concat
02d4ff4c: cbz     x20, #0x2d4ffa8                            
02d4ff50: ldr     x8, [x20]                                  
02d4ff54: mov     x1, x0                                     
02d4ff58: mov     x0, x20                                    
02d4ff5c: ldr     x9, [x8, #0x558]                           &2c5d934(=d65f03c0d503245f)
02d4ff60: ldr     x2, [x8, #0x560]                           &2c5d58c(=14c8cc6cd503245f)
02d4ff64: blr     x9                                         
02d4ff68: ldr     x19, [x19, #0x30]                          ._priceText
02d4ff6c: add     x0, sp, #0xc                               
02d4ff70: mov     x1, xzr                                    
02d4ff74: bl      #0x4e0ea3c                                 System.Int32::ToString
02d4ff78: cbz     x19, #0x2d4ffa8                            
02d4ff7c: ldr     x8, [x19]                                  
02d4ff80: mov     x1, x0                                     
02d4ff84: mov     x0, x19                                    
02d4ff88: ldr     x9, [x8, #0x558]                           &2c5d934(=d65f03c0d503245f)
02d4ff8c: ldr     x2, [x8, #0x560]                           &2c5d58c(=14c8cc6cd503245f)
02d4ff90: blr     x9                                         
02d4ff94: ldp     x20, x19, [sp, #0x30]                      
02d4ff98: ldp     x22, x21, [sp, #0x20]                      
02d4ff9c: ldp     x30, x23, [sp, #0x10]                      
02d4ffa0: add     sp, sp, #0x40                              
02d4ffa4: ret                                                
02d4ffa8: bl      #0x2b7105c                                 fn_2b7105c
## UpdatePrice(int price) -> void
---- Blindbag.BillLine::UpdatePrice 0x2d4ffac
02d4ffac: str     x30, [sp, #-0x30]!                         
02d4ffb0: stp     x22, x21, [sp, #0x10]                      
02d4ffb4: stp     x20, x19, [sp, #0x20]                      
02d4ffb8: adrp    x20, #0x6630000                            
02d4ffbc: mov     w21, w1                                    
02d4ffc0: mov     x19, x0                                    
02d4ffc4: ldrb    w8, [x20, #0x24d]                          
02d4ffc8: tbnz    w8, #0, #0x2d4ffe0                         
02d4ffcc: adrp    x0, #0x626b000                             
02d4ffd0: ldr     x0, [x0, #0x798]                           S:' x{0}'
02d4ffd4: bl      #0x2b70db0                                 fn_2b70db0
02d4ffd8: mov     w8, #1                                     
02d4ffdc: strb    w8, [x20, #0x24d]                          
02d4ffe0: mov     x0, x19                                    
02d4ffe4: mov     x1, xzr                                    
02d4ffe8: ldr     w8, [x0, #0x38]!                           MS:UnityEngine.Component::GetComponent ._totalPrice
02d4ffec: ldur    x20, [x0, #-8]                             
02d4fff0: add     w8, w8, w21                                
02d4fff4: str     w8, [x0]                                   
02d4fff8: bl      #0x4e0ea3c                                 System.Int32::ToString
02d4fffc: cbz     x20, #0x2d5009c                            
02d50000: ldr     x8, [x20]                                  
02d50004: adrp    x22, #0x626b000                            
02d50008: mov     x1, x0                                     
02d5000c: ldr     x22, [x22, #0x798]                         S:' x{0}'
02d50010: mov     x0, x20                                    
02d50014: ldr     x9, [x8, #0x558]                           
02d50018: ldr     x2, [x8, #0x560]                           
02d5001c: blr     x9                                         
02d50020: adrp    x9, #0x6263000                             
02d50024: ldr     w8, [x19, #0x3c]                           ._time
02d50028: add     x1, sp, #0xc                               
02d5002c: ldr     x9, [x9, #0x970]                           &6645c70(=0)
02d50030: ldr     x20, [x19, #0x28]                          ._itemNameText
02d50034: ldr     x21, [x19, #0x40]                          ._itemName
02d50038: add     w8, w8, #1                                 
02d5003c: ldr     x0, [x9, #0x48]                            &6263098(=0)
02d50040: str     w8, [x19, #0x3c]                           ._time
02d50044: str     w8, [sp, #0xc]                             
02d50048: bl      #0x2b70f38                                 fn_2b70f38
02d5004c: ldr     x8, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d50050: mov     x1, x0                                     
02d50054: mov     x2, xzr                                    
02d50058: mov     x0, x8                                     
02d5005c: bl      #0x4c9d0ec                                 System.String::Format
02d50060: mov     x1, x0                                     
02d50064: mov     x0, x21                                    
02d50068: mov     x2, xzr                                    
02d5006c: bl      #0x4c9c514                                 System.String::Concat
02d50070: cbz     x20, #0x2d5009c                            
02d50074: ldr     x8, [x20]                                  
02d50078: mov     x1, x0                                     
02d5007c: mov     x0, x20                                    
02d50080: ldr     x9, [x8, #0x558]                           
02d50084: ldr     x2, [x8, #0x560]                           
02d50088: blr     x9                                         
02d5008c: ldp     x20, x19, [sp, #0x20]                      
02d50090: ldp     x22, x21, [sp, #0x10]                      
02d50094: ldr     x30, [sp], #0x30                           
02d50098: ret                                                
02d5009c: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Blindbag.BillLine::.ctor 0x2d500a0
02d500a0: mov     x1, xzr                                    
02d500a4: b       #0x2cd6228                                 PoolElement::.ctor
