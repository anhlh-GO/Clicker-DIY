#### CLASS CameraController/<>c__DisplayClass21_0 parent= object
#   field onCompleted                    System.Action                                      off=0x10 attr=6 
## .ctor() -> void
---- CameraController/<>c__DisplayClass21_0::.ctor 0x2cda0f0
02cda0f0: mov     x1, xzr                                    
02cda0f4: b       #0x4e53e9c                                 System.Object::.ctor
## <DoPosition>b__0() -> void
---- CameraController/<>c__DisplayClass21_0::<DoPosition>b__0 0x2cda760
02cda760: ldr     x8, [x0, #0x10]                            .onCompleted
02cda764: cbz     x8, #0x2cda778                             
02cda768: ldr     x0, [x8, #0x40]                            
02cda76c: ldr     x1, [x8, #0x28]                            
02cda770: ldr     x2, [x8, #0x18]                            
02cda774: br      x2                                         
02cda778: ret                                                
#### CLASS CameraController/<>c__DisplayClass24_0 parent= object
#   field callback                       System.Action                                      off=0x10 attr=6 
## .ctor() -> void
---- CameraController/<>c__DisplayClass24_0::.ctor 0x2cda2a4
02cda2a4: mov     x1, xzr                                    
02cda2a8: b       #0x4e53e9c                                 System.Object::.ctor
## <SetSizeWithTween>b__0() -> void
---- CameraController/<>c__DisplayClass24_0::<SetSizeWithTween>b__0 0x2cda77c
02cda77c: ldr     x8, [x0, #0x10]                            .callback
02cda780: cbz     x8, #0x2cda794                             
02cda784: ldr     x0, [x8, #0x40]                            
02cda788: ldr     x1, [x8, #0x28]                            
02cda78c: ldr     x2, [x8, #0x18]                            
02cda790: br      x2                                         
02cda794: ret                                                
#### CLASS CameraController/<>c__DisplayClass25_0 parent= object
#   field callback                       System.Action                                      off=0x10 attr=6 
## .ctor() -> void
---- CameraController/<>c__DisplayClass25_0::.ctor 0x2cda420
02cda420: mov     x1, xzr                                    
02cda424: b       #0x4e53e9c                                 System.Object::.ctor
## <SetSizeWithTweenUseTween>b__0() -> void
---- CameraController/<>c__DisplayClass25_0::<SetSizeWithTweenUseTween>b__0 0x2cda798
02cda798: ldr     x8, [x0, #0x10]                            .callback
02cda79c: cbz     x8, #0x2cda7b0                             
02cda7a0: ldr     x0, [x8, #0x40]                            
02cda7a4: ldr     x1, [x8, #0x28]                            
02cda7a8: ldr     x2, [x8, #0x18]                            
02cda7ac: br      x2                                         
02cda7b0: ret                                                
#### CLASS CameraController/<>c__DisplayClass29_0 parent= object
#   field onComplete                     System.Action                                      off=0x10 attr=6 
## .ctor() -> void
---- CameraController/<>c__DisplayClass29_0::.ctor 0x2cda5e0
02cda5e0: mov     x1, xzr                                    
02cda5e4: b       #0x4e53e9c                                 System.Object::.ctor
## <DoLocalMoveX>b__0() -> void
---- CameraController/<>c__DisplayClass29_0::<DoLocalMoveX>b__0 0x2cda7b4
02cda7b4: ldr     x8, [x0, #0x10]                            .onComplete
02cda7b8: cbz     x8, #0x2cda7cc                             
02cda7bc: ldr     x0, [x8, #0x40]                            
02cda7c0: ldr     x1, [x8, #0x28]                            
02cda7c4: ldr     x2, [x8, #0x18]                            
02cda7c8: br      x2                                         
02cda7cc: ret                                                
#### CLASS CameraController/<>c__DisplayClass30_0 parent= object
#   field onComplete                     System.Action                                      off=0x10 attr=6 
## .ctor() -> void
---- CameraController/<>c__DisplayClass30_0::.ctor 0x2cda704
02cda704: mov     x1, xzr                                    
02cda708: b       #0x4e53e9c                                 System.Object::.ctor
## <DoLocalMoveY>b__0() -> void
---- CameraController/<>c__DisplayClass30_0::<DoLocalMoveY>b__0 0x2cda7d0
02cda7d0: ldr     x8, [x0, #0x10]                            .onComplete
02cda7d4: cbz     x8, #0x2cda7e8                             
02cda7d8: ldr     x0, [x8, #0x40]                            
02cda7dc: ldr     x1, [x8, #0x28]                            
02cda7e0: ldr     x2, [x8, #0x18]                            
02cda7e4: br      x2                                         
02cda7e8: ret                                                
#### CLASS CameraController parent= MonoSingleton`1<CameraController>
#   field _baseAspect                    float                                              off=0x20 attr=1 SerializeField
#   field _camera                        UnityEngine.Camera                                 off=0x28 attr=1 SerializeField
#   field _uiCamera                      UnityEngine.Camera                                 off=0x30 attr=1 SerializeField
#   field _isInvert                      bool                                               off=0x38 attr=1 SerializeField
#   field <CurAspect>k__BackingField     float                                              off=0x3c attr=1 CompilerGeneratedAttribute
#   field <AspectScale>k__BackingField   float                                              off=0x40 attr=1 CompilerGeneratedAttribute
#   field <CurOrthoSize>k__BackingField  float                                              off=0x44 attr=1 CompilerGeneratedAttribute
## get_CurAspect() -> float
---- CameraController::get_CurAspect 0x2cd9f20
02cd9f20: ldr     s0, [x0, #0x3c]                            .<CurAspect>k__BackingField
02cd9f24: ret                                                
## set_CurAspect(float value) -> void
---- CameraController::set_CurAspect 0x2cd9f28
02cd9f28: str     s0, [x0, #0x3c]                            .<CurAspect>k__BackingField
02cd9f2c: ret                                                
## get_AspectScale() -> float
---- CameraController::get_AspectScale 0x2cd9f30
02cd9f30: ldr     s0, [x0, #0x40]                            .<AspectScale>k__BackingField
02cd9f34: ret                                                
## set_AspectScale(float value) -> void
---- CameraController::set_AspectScale 0x2cd9f38
02cd9f38: str     s0, [x0, #0x40]                            .<AspectScale>k__BackingField
02cd9f3c: ret                                                
## get_CurOrthoSize() -> float
---- CameraController::get_CurOrthoSize 0x2cd9f40
02cd9f40: ldr     s0, [x0, #0x44]                            .<CurOrthoSize>k__BackingField
02cd9f44: ret                                                
## set_CurOrthoSize(float value) -> void
---- CameraController::set_CurOrthoSize 0x2cd9f48
02cd9f48: str     s0, [x0, #0x44]                            .<CurOrthoSize>k__BackingField
02cd9f4c: ret                                                
## get_Camera() -> UnityEngine.Camera
---- CameraController::get_Camera 0x2cd9f50
02cd9f50: ldr     x0, [x0, #0x28]                            ._camera
02cd9f54: ret                                                
## get_CameraUI() -> UnityEngine.Camera
---- CameraController::get_CameraUI 0x2cd9f58
02cd9f58: ldr     x0, [x0, #0x30]                            ._uiCamera
02cd9f5c: ret                                                
## SetPosition(float x, float y) -> void
---- CameraController::SetPosition 0x2cd9f60
02cd9f60: stp     d9, d8, [sp, #-0x20]!                      
02cd9f64: stp     x30, x19, [sp, #0x10]                      
02cd9f68: mov     x1, xzr                                    
02cd9f6c: fmov    s8, s1                                     
02cd9f70: fmov    s9, s0                                     
02cd9f74: mov     x19, x0                                    
02cd9f78: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cd9f7c: fmov    s0, s9                                     
02cd9f80: mov     x1, xzr                                    
02cd9f84: bl      #0x2dbfb20                                 Redcode.Extensions.TransformExtensions::SetPositionX
02cd9f88: mov     x0, x19                                    
02cd9f8c: mov     x1, xzr                                    
02cd9f90: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cd9f94: ldp     x30, x19, [sp, #0x10]                      
02cd9f98: fmov    s0, s8                                     
02cd9f9c: mov     x1, xzr                                    
02cd9fa0: ldp     d9, d8, [sp], #0x20                        
02cd9fa4: b       #0x2dbfb58                                 Redcode.Extensions.TransformExtensions::SetPositionY
## DoPosition(float x, float y, float time, System.Action onCompleted) -> void
---- CameraController::DoPosition 0x2cd9fa8
02cd9fa8: str     d10, [sp, #-0x50]!                         
02cd9fac: stp     d9, d8, [sp, #8]                           
02cd9fb0: str     x30, [sp, #0x18]                           
02cd9fb4: stp     x24, x23, [sp, #0x20]                      
02cd9fb8: stp     x22, x21, [sp, #0x30]                      
02cd9fbc: stp     x20, x19, [sp, #0x40]                      
02cd9fc0: fmov    s8, s2                                     
02cd9fc4: fmov    s9, s1                                     
02cd9fc8: adrp    x20, #0x662f000                            
02cd9fcc: fmov    s10, s0                                    
02cd9fd0: adrp    x22, #0x6267000                            
02cd9fd4: ldrb    w8, [x20, #0xd4c]                          
02cd9fd8: ldr     x22, [x22, #0xb40]                         T:CameraController/<>c__DisplayClass21_0
02cd9fdc: mov     x21, x1                                    
02cd9fe0: mov     x19, x0                                    
02cd9fe4: tbnz    w8, #0, #0x2cda020                         
02cd9fe8: adrp    x0, #0x6264000                             
02cd9fec: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02cd9ff0: bl      #0x2b70db0                                 fn_2b70db0
02cd9ff4: adrp    x0, #0x6266000                             
02cd9ff8: ldr     x0, [x0, #0x928]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02cd9ffc: bl      #0x2b70db0                                 fn_2b70db0
02cda000: adrp    x0, #0x6267000                             
02cda004: ldr     x0, [x0, #0xb48]                           M:CameraController/<>c__DisplayClass21_0::<DoPosition>b__0
02cda008: bl      #0x2b70db0                                 fn_2b70db0
02cda00c: adrp    x0, #0x6267000                             
02cda010: ldr     x0, [x0, #0xb40]                           T:CameraController/<>c__DisplayClass21_0
02cda014: bl      #0x2b70db0                                 fn_2b70db0
02cda018: mov     w8, #1                                     
02cda01c: strb    w8, [x20, #0xd4c]                          
02cda020: ldr     x0, [x22]                                  S:'didu'
02cda024: bl      #0x2b7104c                                 fn_2b7104c
02cda028: mov     x1, xzr                                    
02cda02c: mov     x20, x0                                    
02cda030: bl      #0x4e53e9c                                 System.Object::.ctor
02cda034: cbz     x20, #0x2cda0ec                            
02cda038: adrp    x22, #0x6264000                            
02cda03c: adrp    x23, #0x6267000                            
02cda040: adrp    x24, #0x6266000                            
02cda044: ldr     x22, [x22, #0xe8]                          T:DG.Tweening.TweenCallback
02cda048: ldr     x23, [x23, #0xb48]                         M:CameraController/<>c__DisplayClass21_0::<DoPosition>b__0
02cda04c: ldr     x24, [x24, #0x928]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02cda050: mov     x0, x20                                    
02cda054: mov     x1, x21                                    
02cda058: str     x21, [x0, #0x10]!                          
02cda05c: bl      #0x2b70d54                                 fn_2b70d54
02cda060: mov     x0, x19                                    
02cda064: mov     x1, xzr                                    
02cda068: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cda06c: fmov    s0, s10                                    
02cda070: fmov    s1, s8                                     
02cda074: mov     w1, wzr                                    
02cda078: mov     x2, xzr                                    
02cda07c: bl      #0x2d977b8                                 DG.Tweening.ShortcutExtensions::DOMoveX
02cda080: mov     x0, x19                                    
02cda084: mov     x1, xzr                                    
02cda088: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cda08c: fmov    s0, s9                                     
02cda090: fmov    s1, s8                                     
02cda094: mov     w1, wzr                                    
02cda098: mov     x2, xzr                                    
02cda09c: bl      #0x2d97988                                 DG.Tweening.ShortcutExtensions::DOMoveY
02cda0a0: ldr     x8, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cda0a4: mov     x19, x0                                    
02cda0a8: mov     x0, x8                                     
02cda0ac: bl      #0x2b7104c                                 fn_2b7104c
02cda0b0: ldr     x2, [x23]                                  S:'didu'
02cda0b4: mov     x1, x20                                    
02cda0b8: mov     x3, xzr                                    
02cda0bc: mov     x21, x0                                    
02cda0c0: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02cda0c4: ldr     x2, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cda0c8: mov     x0, x19                                    
02cda0cc: mov     x1, x21                                    
02cda0d0: ldp     x20, x19, [sp, #0x40]                      
02cda0d4: ldr     x30, [sp, #0x18]                           
02cda0d8: ldp     x22, x21, [sp, #0x30]                      
02cda0dc: ldp     x24, x23, [sp, #0x20]                      
02cda0e0: ldp     d9, d8, [sp, #8]                           
02cda0e4: ldr     d10, [sp], #0x50                           
02cda0e8: b       #0x336f26c                                 
02cda0ec: bl      #0x2b7105c                                 fn_2b7105c
## SetSize(float size, bool needAdapt) -> void
---- CameraController::SetSize 0x2cda0f8
02cda0f8: tbz     w1, #0, #0x2cda104                         
02cda0fc: mov     w1, wzr                                    
02cda100: b       #0x2cda11c                                 CameraController::AdaptResolution
02cda104: ldr     x0, [x0, #0x28]                            ._camera
02cda108: cbz     x0, #0x2cda114                             
02cda10c: mov     x1, xzr                                    
02cda110: b       #0x5aedc54                                 UnityEngine.Camera::set_orthographicSize
02cda114: str     x30, [sp, #-0x10]!                         
02cda118: bl      #0x2b7105c                                 fn_2b7105c
## SetSizeHasClamp(float size, bool needAdapt) -> void
---- CameraController::SetSizeHasClamp 0x2cda144
02cda144: tbz     w1, #0, #0x2cda150                         
02cda148: mov     w1, #1                                     
02cda14c: b       #0x2cda11c                                 CameraController::AdaptResolution
02cda150: ldr     x0, [x0, #0x28]                            ._camera
02cda154: cbz     x0, #0x2cda160                             
02cda158: mov     x1, xzr                                    
02cda15c: b       #0x5aedc54                                 UnityEngine.Camera::set_orthographicSize
02cda160: str     x30, [sp, #-0x10]!                         
02cda164: bl      #0x2b7105c                                 fn_2b7105c
## SetSizeWithTween(float size, float duration, float delayTime, System.Action callback) -> void
---- CameraController::SetSizeWithTween 0x2cda168
02cda168: str     d10, [sp, #-0x60]!                         
02cda16c: stp     d9, d8, [sp, #0x10]                        
02cda170: stp     x30, x25, [sp, #0x20]                      
02cda174: stp     x24, x23, [sp, #0x30]                      
02cda178: stp     x22, x21, [sp, #0x40]                      
02cda17c: stp     x20, x19, [sp, #0x50]                      
02cda180: fmov    s8, s2                                     
02cda184: fmov    s9, s1                                     
02cda188: adrp    x21, #0x662f000                            
02cda18c: fmov    s10, s0                                    
02cda190: adrp    x22, #0x6267000                            
02cda194: ldrb    w8, [x21, #0xd4d]                          
02cda198: ldr     x22, [x22, #0xb50]                         T:CameraController/<>c__DisplayClass24_0
02cda19c: mov     x19, x1                                    
02cda1a0: mov     x20, x0                                    
02cda1a4: tbnz    w8, #0, #0x2cda1ec                         
02cda1a8: adrp    x0, #0x6264000                             
02cda1ac: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02cda1b0: bl      #0x2b70db0                                 fn_2b70db0
02cda1b4: adrp    x0, #0x6266000                             
02cda1b8: ldr     x0, [x0, #0xc90]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02cda1bc: bl      #0x2b70db0                                 fn_2b70db0
02cda1c0: adrp    x0, #0x6266000                             
02cda1c4: ldr     x0, [x0, #0xe00]                           MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02cda1c8: bl      #0x2b70db0                                 fn_2b70db0
02cda1cc: adrp    x0, #0x6267000                             
02cda1d0: ldr     x0, [x0, #0xb58]                           M:CameraController/<>c__DisplayClass24_0::<SetSizeWithTween>b__0
02cda1d4: bl      #0x2b70db0                                 fn_2b70db0
02cda1d8: adrp    x0, #0x6267000                             
02cda1dc: ldr     x0, [x0, #0xb50]                           T:CameraController/<>c__DisplayClass24_0
02cda1e0: bl      #0x2b70db0                                 fn_2b70db0
02cda1e4: mov     w8, #1                                     
02cda1e8: strb    w8, [x21, #0xd4d]                          
02cda1ec: ldr     x0, [x22]                                  S:'didu'
02cda1f0: bl      #0x2b7104c                                 fn_2b7104c
02cda1f4: mov     x1, xzr                                    
02cda1f8: mov     x21, x0                                    
02cda1fc: bl      #0x4e53e9c                                 System.Object::.ctor
02cda200: cbz     x21, #0x2cda2a0                            
02cda204: adrp    x22, #0x6266000                            
02cda208: adrp    x23, #0x6264000                            
02cda20c: adrp    x24, #0x6267000                            
02cda210: adrp    x25, #0x6266000                            
02cda214: ldr     x22, [x22, #0xe00]                         MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02cda218: ldr     x23, [x23, #0xe8]                          T:DG.Tweening.TweenCallback
02cda21c: ldr     x24, [x24, #0xb58]                         M:CameraController/<>c__DisplayClass24_0::<SetSizeWithTween>b__0
02cda220: ldr     x25, [x25, #0xc90]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02cda224: mov     x0, x21                                    
02cda228: mov     x1, x19                                    
02cda22c: str     x19, [x0, #0x10]!                          
02cda230: bl      #0x2b70d54                                 fn_2b70d54
02cda234: fmov    s0, s10                                    
02cda238: fmov    s1, s9                                     
02cda23c: ldr     x0, [x20, #0x28]                           ._camera
02cda240: mov     x1, xzr                                    
02cda244: bl      #0x2d94340                                 DG.Tweening.ShortcutExtensions::DOOrthoSize
02cda248: fmov    s0, s8                                     
02cda24c: ldr     x1, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cda250: bl      #0x336f7fc                                 fn_336f7fc
02cda254: ldr     x8, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cda258: mov     x19, x0                                    
02cda25c: mov     x0, x8                                     
02cda260: bl      #0x2b7104c                                 fn_2b7104c
02cda264: ldr     x2, [x24]                                  S:'didu'
02cda268: mov     x1, x21                                    
02cda26c: mov     x3, xzr                                    
02cda270: mov     x20, x0                                    
02cda274: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02cda278: ldr     x2, [x25]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cda27c: mov     x0, x19                                    
02cda280: mov     x1, x20                                    
02cda284: ldp     x20, x19, [sp, #0x50]                      
02cda288: ldp     x22, x21, [sp, #0x40]                      
02cda28c: ldp     x24, x23, [sp, #0x30]                      
02cda290: ldp     x30, x25, [sp, #0x20]                      
02cda294: ldp     d9, d8, [sp, #0x10]                        
02cda298: ldr     d10, [sp], #0x60                           
02cda29c: b       #0x336f26c                                 
02cda2a0: bl      #0x2b7105c                                 fn_2b7105c
## SetSizeWithTweenUseTween(float size, float duration, float delayTime, bool isTween, System.Action callback) -> void
---- CameraController::SetSizeWithTweenUseTween 0x2cda2ac
02cda2ac: str     d10, [sp, #-0x70]!                         
02cda2b0: stp     d9, d8, [sp, #0x10]                        
02cda2b4: stp     x30, x27, [sp, #0x20]                      
02cda2b8: stp     x26, x25, [sp, #0x30]                      
02cda2bc: stp     x24, x23, [sp, #0x40]                      
02cda2c0: stp     x22, x21, [sp, #0x50]                      
02cda2c4: stp     x20, x19, [sp, #0x60]                      
02cda2c8: fmov    s8, s2                                     
02cda2cc: fmov    s9, s1                                     
02cda2d0: adrp    x22, #0x662f000                            
02cda2d4: fmov    s10, s0                                    
02cda2d8: adrp    x23, #0x6267000                            
02cda2dc: ldrb    w8, [x22, #0xd4e]                          
02cda2e0: ldr     x23, [x23, #0xb60]                         T:CameraController/<>c__DisplayClass25_0
02cda2e4: mov     x20, x2                                    
02cda2e8: mov     w19, w1                                    
02cda2ec: mov     x21, x0                                    
02cda2f0: tbnz    w8, #0, #0x2cda344                         
02cda2f4: adrp    x0, #0x6264000                             
02cda2f8: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02cda2fc: bl      #0x2b70db0                                 fn_2b70db0
02cda300: adrp    x0, #0x6266000                             
02cda304: ldr     x0, [x0, #0xc90]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02cda308: bl      #0x2b70db0                                 fn_2b70db0
02cda30c: adrp    x0, #0x6266000                             
02cda310: ldr     x0, [x0, #0xe00]                           MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02cda314: bl      #0x2b70db0                                 fn_2b70db0
02cda318: adrp    x0, #0x6267000                             
02cda31c: ldr     x0, [x0, #0x978]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02cda320: bl      #0x2b70db0                                 fn_2b70db0
02cda324: adrp    x0, #0x6267000                             
02cda328: ldr     x0, [x0, #0xb68]                           M:CameraController/<>c__DisplayClass25_0::<SetSizeWithTweenUseTween>b__0
02cda32c: bl      #0x2b70db0                                 fn_2b70db0
02cda330: adrp    x0, #0x6267000                             
02cda334: ldr     x0, [x0, #0xb60]                           T:CameraController/<>c__DisplayClass25_0
02cda338: bl      #0x2b70db0                                 fn_2b70db0
02cda33c: mov     w8, #1                                     
02cda340: strb    w8, [x22, #0xd4e]                          
02cda344: ldr     x0, [x23]                                  S:'didu'
02cda348: bl      #0x2b7104c                                 fn_2b7104c
02cda34c: mov     x1, xzr                                    
02cda350: mov     x22, x0                                    
02cda354: bl      #0x4e53e9c                                 System.Object::.ctor
02cda358: cbz     x22, #0x2cda41c                            
02cda35c: adrp    x23, #0x6266000                            
02cda360: adrp    x24, #0x6267000                            
02cda364: adrp    x25, #0x6264000                            
02cda368: adrp    x26, #0x6267000                            
02cda36c: adrp    x27, #0x6266000                            
02cda370: ldr     x23, [x23, #0xe00]                         MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02cda374: ldr     x24, [x24, #0x978]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02cda378: ldr     x25, [x25, #0xe8]                          T:DG.Tweening.TweenCallback
02cda37c: ldr     x26, [x26, #0xb68]                         M:CameraController/<>c__DisplayClass25_0::<SetSizeWithTweenUseTween>b__0
02cda380: ldr     x27, [x27, #0xc90]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02cda384: mov     x0, x22                                    
02cda388: mov     x1, x20                                    
02cda38c: str     x20, [x0, #0x10]!                          
02cda390: bl      #0x2b70d54                                 fn_2b70d54
02cda394: fmov    s0, s10                                    
02cda398: fmov    s1, s9                                     
02cda39c: ldr     x0, [x21, #0x28]                           ._camera
02cda3a0: tst     w19, #1                                    
02cda3a4: mov     w8, #0x1a                                  
02cda3a8: mov     x1, xzr                                    
02cda3ac: cinc    w19, w8, eq                                
02cda3b0: bl      #0x2d94340                                 DG.Tweening.ShortcutExtensions::DOOrthoSize
02cda3b4: fmov    s0, s8                                     
02cda3b8: ldr     x1, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cda3bc: bl      #0x336f7fc                                 fn_336f7fc
02cda3c0: ldr     x2, [x24]                                  S:'didu'
02cda3c4: mov     w1, w19                                    
02cda3c8: bl      #0x336fa0c                                 fn_336fa0c
02cda3cc: ldr     x8, [x25]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cda3d0: mov     x19, x0                                    
02cda3d4: mov     x0, x8                                     
02cda3d8: bl      #0x2b7104c                                 fn_2b7104c
02cda3dc: ldr     x2, [x26]                                  S:'didu'
02cda3e0: mov     x1, x22                                    
02cda3e4: mov     x3, xzr                                    
02cda3e8: mov     x20, x0                                    
02cda3ec: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02cda3f0: ldr     x2, [x27]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cda3f4: mov     x0, x19                                    
02cda3f8: mov     x1, x20                                    
02cda3fc: ldp     x20, x19, [sp, #0x60]                      
02cda400: ldp     x22, x21, [sp, #0x50]                      
02cda404: ldp     x24, x23, [sp, #0x40]                      
02cda408: ldp     x26, x25, [sp, #0x30]                      
02cda40c: ldp     x30, x27, [sp, #0x20]                      
02cda410: ldp     d9, d8, [sp, #0x10]                        
02cda414: ldr     d10, [sp], #0x70                           
02cda418: b       #0x336f26c                                 
02cda41c: bl      #0x2b7105c                                 fn_2b7105c
## EnableUICamera(bool value) -> void
---- CameraController::EnableUICamera 0x2cda428
02cda428: ldr     x0, [x0, #0x30]                            ._uiCamera
02cda42c: cbz     x0, #0x2cda43c                             
02cda430: and     w1, w1, #1                                 
02cda434: mov     x2, xzr                                    
02cda438: b       #0x5b33110                                 UnityEngine.Behaviour::set_enabled
02cda43c: str     x30, [sp, #-0x10]!                         
02cda440: bl      #0x2b7105c                                 fn_2b7105c
## AdaptResolution(float size, bool hasClamp) -> void
---- CameraController::AdaptResolution 0x2cda11c
02cda11c: stp     x30, x19, [sp, #-0x10]!                    
02cda120: mov     x19, x0                                    
02cda124: bl      #0x2cda444                                 CameraController::GetAdaptResolution
02cda128: ldr     x0, [x19, #0x28]                           ._camera
02cda12c: cbz     x0, #0x2cda140                             
02cda130: ldr     s0, [x19, #0x44]                           .<CurOrthoSize>k__BackingField
02cda134: mov     x1, xzr                                    
02cda138: ldp     x30, x19, [sp], #0x10                      
02cda13c: b       #0x5aedc54                                 UnityEngine.Camera::set_orthographicSize
02cda140: bl      #0x2b7105c                                 fn_2b7105c
## GetAdaptResolution(float size, bool hasClamp) -> float
---- CameraController::GetAdaptResolution 0x2cda444
02cda444: str     d8, [sp, #-0x30]!                          
02cda448: stp     x30, x21, [sp, #0x10]                      
02cda44c: stp     x20, x19, [sp, #0x20]                      
02cda450: mov     x19, x0                                    
02cda454: mov     x0, xzr                                    
02cda458: mov     w20, w1                                    
02cda45c: fmov    s8, s0                                     
02cda460: bl      #0x5afb724                                 UnityEngine.Screen::get_height
02cda464: mov     w21, w0                                    
02cda468: mov     x0, xzr                                    
02cda46c: bl      #0x5afb6fc                                 UnityEngine.Screen::get_width
02cda470: scvtf   s0, w21                                    
02cda474: scvtf   s1, w0                                     
02cda478: ldrb    w8, [x19, #0x38]                           ._isInvert
02cda47c: fdiv    s1, s0, s1                                 
02cda480: ldr     s0, [x19, #0x20]                           ._baseAspect
02cda484: fdiv    s0, s1, s0                                 
02cda488: stp     s1, s0, [x19, #0x3c]                       .<CurAspect>k__BackingField
02cda48c: cbz     w8, #0x2cda49c                             
02cda490: fmov    s1, #1.00000000                            
02cda494: fdiv    s0, s1, s0                                 
02cda498: str     s0, [x19, #0x40]                           .<AspectScale>k__BackingField
02cda49c: fmul    s0, s0, s8                                 
02cda4a0: ldp     x30, x21, [sp, #0x10]                      
02cda4a4: fcmp    s0, s8                                     
02cda4a8: cset    w8, mi                                     
02cda4ac: tst     w20, w8                                    
02cda4b0: fcsel   s0, s8, s0, ne                             
02cda4b4: str     s0, [x19, #0x44]                           .<CurOrthoSize>k__BackingField
02cda4b8: ldp     x20, x19, [sp, #0x20]                      
02cda4bc: ldr     d8, [sp], #0x30                            
02cda4c0: ret                                                
## DoLocalMoveX(float posX, float duration, System.Action onComplete) -> void
---- CameraController::DoLocalMoveX 0x2cda4c4
02cda4c4: stp     d9, d8, [sp, #-0x50]!                      
02cda4c8: str     x30, [sp, #0x10]                           
02cda4cc: stp     x24, x23, [sp, #0x20]                      
02cda4d0: stp     x22, x21, [sp, #0x30]                      
02cda4d4: stp     x20, x19, [sp, #0x40]                      
02cda4d8: fmov    s8, s1                                     
02cda4dc: fmov    s9, s0                                     
02cda4e0: adrp    x21, #0x662f000                            
02cda4e4: adrp    x22, #0x6267000                            
02cda4e8: ldrb    w8, [x21, #0xd4f]                          
02cda4ec: mov     x19, x1                                    
02cda4f0: ldr     x22, [x22, #0xb70]                         T:CameraController/<>c__DisplayClass29_0
02cda4f4: mov     x20, x0                                    
02cda4f8: tbnz    w8, #0, #0x2cda534                         
02cda4fc: adrp    x0, #0x6264000                             
02cda500: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02cda504: bl      #0x2b70db0                                 fn_2b70db0
02cda508: adrp    x0, #0x6266000                             
02cda50c: ldr     x0, [x0, #0x928]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02cda510: bl      #0x2b70db0                                 fn_2b70db0
02cda514: adrp    x0, #0x6267000                             
02cda518: ldr     x0, [x0, #0xb78]                           M:CameraController/<>c__DisplayClass29_0::<DoLocalMoveX>b__0
02cda51c: bl      #0x2b70db0                                 fn_2b70db0
02cda520: adrp    x0, #0x6267000                             
02cda524: ldr     x0, [x0, #0xb70]                           T:CameraController/<>c__DisplayClass29_0
02cda528: bl      #0x2b70db0                                 fn_2b70db0
02cda52c: mov     w8, #1                                     
02cda530: strb    w8, [x21, #0xd4f]                          
02cda534: ldr     x0, [x22]                                  S:'didu'
02cda538: bl      #0x2b7104c                                 fn_2b7104c
02cda53c: mov     x1, xzr                                    
02cda540: mov     x21, x0                                    
02cda544: bl      #0x4e53e9c                                 System.Object::.ctor
02cda548: cbz     x21, #0x2cda5dc                            
02cda54c: adrp    x22, #0x6264000                            
02cda550: adrp    x23, #0x6267000                            
02cda554: adrp    x24, #0x6266000                            
02cda558: ldr     x22, [x22, #0xe8]                          T:DG.Tweening.TweenCallback
02cda55c: ldr     x23, [x23, #0xb78]                         M:CameraController/<>c__DisplayClass29_0::<DoLocalMoveX>b__0
02cda560: ldr     x24, [x24, #0x928]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02cda564: mov     x0, x21                                    
02cda568: mov     x1, x19                                    
02cda56c: str     x19, [x0, #0x10]!                          
02cda570: bl      #0x2b70d54                                 fn_2b70d54
02cda574: mov     x0, x20                                    
02cda578: mov     x1, xzr                                    
02cda57c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cda580: fmov    s0, s9                                     
02cda584: fmov    s1, s8                                     
02cda588: mov     w1, wzr                                    
02cda58c: mov     x2, xzr                                    
02cda590: bl      #0x2d97eac                                 DG.Tweening.ShortcutExtensions::DOLocalMoveX
02cda594: ldr     x8, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cda598: mov     x19, x0                                    
02cda59c: mov     x0, x8                                     
02cda5a0: bl      #0x2b7104c                                 fn_2b7104c
02cda5a4: ldr     x2, [x23]                                  S:'didu'
02cda5a8: mov     x1, x21                                    
02cda5ac: mov     x3, xzr                                    
02cda5b0: mov     x20, x0                                    
02cda5b4: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02cda5b8: ldr     x2, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cda5bc: mov     x0, x19                                    
02cda5c0: mov     x1, x20                                    
02cda5c4: ldp     x20, x19, [sp, #0x40]                      
02cda5c8: ldr     x30, [sp, #0x10]                           
02cda5cc: ldp     x22, x21, [sp, #0x30]                      
02cda5d0: ldp     x24, x23, [sp, #0x20]                      
02cda5d4: ldp     d9, d8, [sp], #0x50                        
02cda5d8: b       #0x336f26c                                 
02cda5dc: bl      #0x2b7105c                                 fn_2b7105c
## DoLocalMoveY(float posY, float duration, System.Action onComplete) -> void
---- CameraController::DoLocalMoveY 0x2cda5e8
02cda5e8: stp     d9, d8, [sp, #-0x50]!                      
02cda5ec: str     x30, [sp, #0x10]                           
02cda5f0: stp     x24, x23, [sp, #0x20]                      
02cda5f4: stp     x22, x21, [sp, #0x30]                      
02cda5f8: stp     x20, x19, [sp, #0x40]                      
02cda5fc: fmov    s8, s1                                     
02cda600: fmov    s9, s0                                     
02cda604: adrp    x21, #0x662f000                            
02cda608: adrp    x22, #0x6267000                            
02cda60c: ldrb    w8, [x21, #0xd50]                          
02cda610: mov     x19, x1                                    
02cda614: ldr     x22, [x22, #0xb80]                         T:CameraController/<>c__DisplayClass30_0
02cda618: mov     x20, x0                                    
02cda61c: tbnz    w8, #0, #0x2cda658                         
02cda620: adrp    x0, #0x6264000                             
02cda624: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02cda628: bl      #0x2b70db0                                 fn_2b70db0
02cda62c: adrp    x0, #0x6266000                             
02cda630: ldr     x0, [x0, #0x928]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02cda634: bl      #0x2b70db0                                 fn_2b70db0
02cda638: adrp    x0, #0x6267000                             
02cda63c: ldr     x0, [x0, #0xb88]                           M:CameraController/<>c__DisplayClass30_0::<DoLocalMoveY>b__0
02cda640: bl      #0x2b70db0                                 fn_2b70db0
02cda644: adrp    x0, #0x6267000                             
02cda648: ldr     x0, [x0, #0xb80]                           T:CameraController/<>c__DisplayClass30_0
02cda64c: bl      #0x2b70db0                                 fn_2b70db0
02cda650: mov     w8, #1                                     
02cda654: strb    w8, [x21, #0xd50]                          
02cda658: ldr     x0, [x22]                                  S:'didu'
02cda65c: bl      #0x2b7104c                                 fn_2b7104c
02cda660: mov     x1, xzr                                    
02cda664: mov     x21, x0                                    
02cda668: bl      #0x4e53e9c                                 System.Object::.ctor
02cda66c: cbz     x21, #0x2cda700                            
02cda670: adrp    x22, #0x6264000                            
02cda674: adrp    x23, #0x6267000                            
02cda678: adrp    x24, #0x6266000                            
02cda67c: ldr     x22, [x22, #0xe8]                          T:DG.Tweening.TweenCallback
02cda680: ldr     x23, [x23, #0xb88]                         M:CameraController/<>c__DisplayClass30_0::<DoLocalMoveY>b__0
02cda684: ldr     x24, [x24, #0x928]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02cda688: mov     x0, x21                                    
02cda68c: mov     x1, x19                                    
02cda690: str     x19, [x0, #0x10]!                          
02cda694: bl      #0x2b70d54                                 fn_2b70d54
02cda698: mov     x0, x20                                    
02cda69c: mov     x1, xzr                                    
02cda6a0: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cda6a4: fmov    s0, s9                                     
02cda6a8: fmov    s1, s8                                     
02cda6ac: mov     w1, wzr                                    
02cda6b0: mov     x2, xzr                                    
02cda6b4: bl      #0x2d98060                                 DG.Tweening.ShortcutExtensions::DOLocalMoveY
02cda6b8: ldr     x8, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cda6bc: mov     x19, x0                                    
02cda6c0: mov     x0, x8                                     
02cda6c4: bl      #0x2b7104c                                 fn_2b7104c
02cda6c8: ldr     x2, [x23]                                  S:'didu'
02cda6cc: mov     x1, x21                                    
02cda6d0: mov     x3, xzr                                    
02cda6d4: mov     x20, x0                                    
02cda6d8: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02cda6dc: ldr     x2, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cda6e0: mov     x0, x19                                    
02cda6e4: mov     x1, x20                                    
02cda6e8: ldp     x20, x19, [sp, #0x40]                      
02cda6ec: ldr     x30, [sp, #0x10]                           
02cda6f0: ldp     x22, x21, [sp, #0x30]                      
02cda6f4: ldp     x24, x23, [sp, #0x20]                      
02cda6f8: ldp     d9, d8, [sp], #0x50                        
02cda6fc: b       #0x336f26c                                 
02cda700: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- CameraController::.ctor 0x2cda70c
02cda70c: stp     x30, x21, [sp, #-0x20]!                    
02cda710: stp     x20, x19, [sp, #0x10]                      
02cda714: adrp    x21, #0x662f000                            
02cda718: adrp    x20, #0x6267000                            
02cda71c: mov     x19, x0                                    
02cda720: ldrb    w8, [x21, #0xd51]                          
02cda724: ldr     x20, [x20, #0xb90]                         MS:MonoSingleton`1::.ctor
02cda728: tbnz    w8, #0, #0x2cda740                         
02cda72c: adrp    x0, #0x6267000                             
02cda730: ldr     x0, [x0, #0xb90]                           MS:MonoSingleton`1::.ctor
02cda734: bl      #0x2b70db0                                 fn_2b70db0
02cda738: mov     w8, #1                                     
02cda73c: strb    w8, [x21, #0xd51]                          
02cda740: mov     w8, #0x8e39                                
02cda744: ldr     x1, [x20]                                  S:'didu'
02cda748: mov     x0, x19                                    
02cda74c: movk    w8, #0x3fe3, lsl #16                       
02cda750: str     w8, [x19, #0x20]                           ._baseAspect
02cda754: ldp     x20, x19, [sp, #0x10]                      
02cda758: ldp     x30, x21, [sp], #0x20                      
02cda75c: b       #0x3769e18                                 
