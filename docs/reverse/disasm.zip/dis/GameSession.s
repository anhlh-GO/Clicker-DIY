#### CLASS GameSession parent= MonoSingleton`1<GameSession>
#   field _mainCharacter                 UnityEngine.GameObject                             off=0x20 attr=1 SerializeField
#   field _characterContainer            UnityEngine.Transform                              off=0x28 attr=1 SerializeField
#   field _background                    UnityEngine.GameObject                             off=0x30 attr=1 SerializeField
#   field <Avatar>k__BackingField        UnityEngine.Sprite                                 off=0x38 attr=1 CompilerGeneratedAttribute
#   field <IsPlayAGame>k__BackingField   bool                                               off=0x40 attr=1 CompilerGeneratedAttribute
#   field <CanShowSpecial>k__BackingField bool                                               off=0x41 attr=1 CompilerGeneratedAttribute
#   field <InterShownCount>k__BackingField int                                                off=0x44 attr=1 CompilerGeneratedAttribute
#   field <ScoopOrderId>k__BackingField  int                                                off=0x48 attr=1 CompilerGeneratedAttribute
#   field <PopupRemoveAdShown>k__BackingField bool                                               off=0x4c attr=1 CompilerGeneratedAttribute
#   field SceneLoadFromLoading           bool                                               off=0x4d attr=6 
#   field _characterIntialScale          UnityEngine.Vector3                                off=0x50 attr=1 
#   field AnimNeedToCast                 HomeUnlockType                                     off=0x5c attr=6 
#   field BackFromGameMode               GameModeEnum                                       off=0x60 attr=6 
#   field <OrderAvatar>k__BackingField   UnityEngine.Sprite                                 off=0x68 attr=1 CompilerGeneratedAttribute
## get_Avatar() -> UnityEngine.Sprite
---- GameSession::get_Avatar 0x2cac8b8
02cac8b8: ldr     x0, [x0, #0x38]                            .<Avatar>k__BackingField
02cac8bc: ret                                                
## set_Avatar(UnityEngine.Sprite value) -> void
---- GameSession::set_Avatar 0x2cac8c0
02cac8c0: str     x1, [x0, #0x38]!                           .<Avatar>k__BackingField
02cac8c4: b       #0x2b70d54                                 
## get_IsPlayAGame() -> bool
---- GameSession::get_IsPlayAGame 0x2cac8c8
02cac8c8: ldrb    w0, [x0, #0x40]                            .<IsPlayAGame>k__BackingField
02cac8cc: ret                                                
## set_IsPlayAGame(bool value) -> void
---- GameSession::set_IsPlayAGame 0x2cac8d0
02cac8d0: strb    w1, [x0, #0x40]                            .<IsPlayAGame>k__BackingField
02cac8d4: ret                                                
## get_CanShowSpecial() -> bool
---- GameSession::get_CanShowSpecial 0x2cac8d8
02cac8d8: ldrb    w0, [x0, #0x41]                            .<CanShowSpecial>k__BackingField
02cac8dc: ret                                                
## set_CanShowSpecial(bool value) -> void
---- GameSession::set_CanShowSpecial 0x2cac8e0
02cac8e0: strb    w1, [x0, #0x41]                            .<CanShowSpecial>k__BackingField
02cac8e4: ret                                                
## get_InterShownCount() -> int
---- GameSession::get_InterShownCount 0x2cac8e8
02cac8e8: ldr     w0, [x0, #0x44]                            .<InterShownCount>k__BackingField
02cac8ec: ret                                                
## set_InterShownCount(int value) -> void
---- GameSession::set_InterShownCount 0x2cac8f0
02cac8f0: str     w1, [x0, #0x44]                            .<InterShownCount>k__BackingField
02cac8f4: ret                                                
## get_ScoopOrderId() -> int
---- GameSession::get_ScoopOrderId 0x2cac8f8
02cac8f8: ldr     w0, [x0, #0x48]                            .<ScoopOrderId>k__BackingField
02cac8fc: ret                                                
## set_ScoopOrderId(int value) -> void
---- GameSession::set_ScoopOrderId 0x2cac900
02cac900: str     w1, [x0, #0x48]                            .<ScoopOrderId>k__BackingField
02cac904: ret                                                
## get_PopupRemoveAdShown() -> bool
---- GameSession::get_PopupRemoveAdShown 0x2cac908
02cac908: ldrb    w0, [x0, #0x4c]                            .<PopupRemoveAdShown>k__BackingField
02cac90c: ret                                                
## set_PopupRemoveAdShown(bool value) -> void
---- GameSession::set_PopupRemoveAdShown 0x2cac910
02cac910: strb    w1, [x0, #0x4c]                            .<PopupRemoveAdShown>k__BackingField
02cac914: ret                                                
## get_MainCharacter() -> UnityEngine.GameObject
---- GameSession::get_MainCharacter 0x2cac918
02cac918: ldr     x0, [x0, #0x20]                            ._mainCharacter
02cac91c: ret                                                
## get_Background() -> UnityEngine.GameObject
---- GameSession::get_Background 0x2cac920
02cac920: ldr     x0, [x0, #0x30]                            ._background
02cac924: ret                                                
## get_CharacterContainer() -> UnityEngine.GameObject
---- GameSession::get_CharacterContainer 0x2cac928
02cac928: ldr     x0, [x0, #0x28]                            ._characterContainer
02cac92c: cbz     x0, #0x2cac938                             
02cac930: mov     x1, xzr                                    
02cac934: b       #0x5b339ec                                 UnityEngine.Component::get_gameObject
02cac938: str     x30, [sp, #-0x10]!                         
02cac93c: bl      #0x2b7105c                                 fn_2b7105c
## get_OrderAvatar() -> UnityEngine.Sprite
---- GameSession::get_OrderAvatar 0x2cac940
02cac940: ldr     x0, [x0, #0x68]                            .<OrderAvatar>k__BackingField
02cac944: ret                                                
## set_OrderAvatar(UnityEngine.Sprite value) -> void
---- GameSession::set_OrderAvatar 0x2cac948
02cac948: str     x1, [x0, #0x68]!                           .<OrderAvatar>k__BackingField
02cac94c: b       #0x2b70d54                                 
## Initiate() -> void
---- GameSession::Initiate 0x2cac950
02cac950: stp     x30, x21, [sp, #-0x20]!                    
02cac954: stp     x20, x19, [sp, #0x10]                      
02cac958: adrp    x20, #0x662f000                            
02cac95c: adrp    x21, #0x6266000                            
02cac960: mov     x19, x0                                    
02cac964: ldrb    w8, [x20, #0xb35]                          
02cac968: ldr     x21, [x21, #0x868]                         MS:MonoSingleton`1::Initiate
02cac96c: tbnz    w8, #0, #0x2cac984                         
02cac970: adrp    x0, #0x6266000                             
02cac974: ldr     x0, [x0, #0x868]                           MS:MonoSingleton`1::Initiate
02cac978: bl      #0x2b70db0                                 fn_2b70db0
02cac97c: mov     w8, #1                                     
02cac980: strb    w8, [x20, #0xb35]                          
02cac984: mov     x0, x19                                    
02cac988: ldp     x20, x19, [sp, #0x10]                      
02cac98c: ldr     x1, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cac990: ldp     x30, x21, [sp], #0x20                      
02cac994: b       #0x3769de4                                 
## Start() -> void
---- GameSession::Start 0x2cac998
02cac998: stp     x30, x19, [sp, #-0x10]!                    
02cac99c: mov     w8, #1                                     
02cac9a0: mov     x19, x0                                    
02cac9a4: strb    w8, [x0, #0x41]                            .<CanShowSpecial>k__BackingField
02cac9a8: bl      #0x2cac9c4                                 GameSession::UpdateAvatar
02cac9ac: mov     x0, x19                                    
02cac9b0: bl      #0x2cacaa0                                 GameSession::GenCharacter
02cac9b4: mov     x0, x19                                    
02cac9b8: mov     w1, wzr                                    
02cac9bc: ldp     x30, x19, [sp], #0x10                      
02cac9c0: b       #0x2cacd8c                                 GameSession::SetActiveCharacter
## ClearSession() -> void
---- GameSession::ClearSession 0x2cace04
02cace04: ret                                                
## SetActiveCharacter(bool active) -> void
---- GameSession::SetActiveCharacter 0x2cacd8c
02cacd8c: str     x30, [sp, #-0x20]!                         
02cacd90: stp     x20, x19, [sp, #0x10]                      
02cacd94: mov     x19, x0                                    
02cacd98: ldr     x0, [x0, #0x20]                            ._mainCharacter
02cacd9c: mov     w20, w1                                    
02cacda0: cbz     x0, #0x2cacdb0                             
02cacda4: and     w1, w20, #1                                
02cacda8: mov     x2, xzr                                    
02cacdac: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cacdb0: ldr     x0, [x19, #0x28]                           ._characterContainer
02cacdb4: cbz     x0, #0x2cacdfc                             
02cacdb8: mov     x1, xzr                                    
02cacdbc: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02cacdc0: cbz     x0, #0x2cacdfc                             
02cacdc4: and     w1, w20, #1                                
02cacdc8: mov     x2, xzr                                    
02cacdcc: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cacdd0: ldr     x0, [x19, #0x20]                           ._mainCharacter
02cacdd4: cbz     x0, #0x2cacdfc                             
02cacdd8: mov     x1, xzr                                    
02cacddc: bl      #0x5b368f0                                 UnityEngine.GameObject::get_transform
02cacde0: cbz     x0, #0x2cacdfc                             
02cacde4: ldp     s0, s1, [x19, #0x50]                       ._characterIntialScale
02cacde8: mov     x1, xzr                                    
02cacdec: ldr     s2, [x19, #0x58]                           
02cacdf0: ldp     x20, x19, [sp, #0x10]                      
02cacdf4: ldr     x30, [sp], #0x20                           
02cacdf8: b       #0x5b470cc                                 UnityEngine.Transform::set_localScale
02cacdfc: bl      #0x2b7105c                                 fn_2b7105c
## SetActiveCharacter(float scaleMultiplier, float yOffset) -> UnityEngine.Vector2
---- GameSession::SetActiveCharacter 0x2cace08
02cace08: stp     d11, d10, [sp, #-0x40]!                    
02cace0c: stp     d9, d8, [sp, #0x10]                        
02cace10: str     x30, [sp, #0x20]                           
02cace14: stp     x20, x19, [sp, #0x30]                      
02cace18: mov     x19, x0                                    
02cace1c: ldr     x0, [x0, #0x20]                            ._mainCharacter
02cace20: cbz     x0, #0x2cacf38                             
02cace24: mov     x1, xzr                                    
02cace28: fmov    s8, s1                                     
02cace2c: fmov    s11, s0                                    
02cace30: bl      #0x5b368f0                                 UnityEngine.GameObject::get_transform
02cace34: cbz     x0, #0x2cacf38                             
02cace38: mov     x1, xzr                                    
02cace3c: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02cace40: fmov    s9, s0                                     
02cace44: fmov    s10, s1                                    
02cace48: ldr     x0, [x19, #0x20]                           ._mainCharacter
02cace4c: cbz     x0, #0x2cace5c                             
02cace50: mov     w1, #1                                     
02cace54: mov     x2, xzr                                    
02cace58: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cace5c: ldr     x0, [x19, #0x28]                           ._characterContainer
02cace60: cbz     x0, #0x2cacf38                             
02cace64: mov     x1, xzr                                    
02cace68: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02cace6c: cbz     x0, #0x2cacf38                             
02cace70: mov     w1, #1                                     
02cace74: mov     x2, xzr                                    
02cace78: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cace7c: ldr     x0, [x19, #0x20]                           ._mainCharacter
02cace80: cbz     x0, #0x2cacf38                             
02cace84: mov     x1, xzr                                    
02cace88: bl      #0x5b368f0                                 UnityEngine.GameObject::get_transform
02cace8c: cbz     x0, #0x2cacf38                             
02cace90: ldp     s1, s0, [x19, #0x54]                       
02cace94: mov     x1, xzr                                    
02cace98: ldr     s3, [x19, #0x50]                           ._characterIntialScale
02cace9c: fmul    s2, s0, s11                                
02cacea0: fmul    s1, s1, s11                                
02cacea4: fmul    s0, s3, s11                                
02cacea8: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02caceac: ldr     x0, [x19, #0x20]                           ._mainCharacter
02caceb0: cbz     x0, #0x2cacf38                             
02caceb4: mov     x1, xzr                                    
02caceb8: bl      #0x5b368f0                                 UnityEngine.GameObject::get_transform
02cacebc: ldr     x8, [x19, #0x20]                           ._mainCharacter
02cacec0: cbz     x8, #0x2cacf38                             
02cacec4: mov     x20, x0                                    
02cacec8: mov     x0, x8                                     
02cacecc: mov     x1, xzr                                    
02caced0: bl      #0x5b368f0                                 UnityEngine.GameObject::get_transform
02caced4: cbz     x0, #0x2cacf38                             
02caced8: mov     x1, xzr                                    
02cacedc: bl      #0x5b45c24                                 UnityEngine.Transform::get_localPosition
02cacee0: ldr     x0, [x19, #0x20]                           ._mainCharacter
02cacee4: cbz     x0, #0x2cacf38                             
02cacee8: mov     x1, xzr                                    
02caceec: fmov    s11, s0                                    
02cacef0: bl      #0x5b368f0                                 UnityEngine.GameObject::get_transform
02cacef4: cbz     x0, #0x2cacf38                             
02cacef8: mov     x1, xzr                                    
02cacefc: bl      #0x5b45c24                                 UnityEngine.Transform::get_localPosition
02cacf00: cbz     x20, #0x2cacf38                            
02cacf04: fadd    s1, s1, s8                                 
02cacf08: movi    d2, #0000000000000000                      
02cacf0c: mov     x0, x20                                    
02cacf10: fmov    s0, s11                                    
02cacf14: mov     x1, xzr                                    
02cacf18: bl      #0x5b45cec                                 UnityEngine.Transform::set_localPosition
02cacf1c: fmov    s0, s9                                     
02cacf20: ldp     x20, x19, [sp, #0x30]                      
02cacf24: ldp     d9, d8, [sp, #0x10]                        
02cacf28: fmov    s1, s10                                    
02cacf2c: ldr     x30, [sp, #0x20]                           
02cacf30: ldp     d11, d10, [sp], #0x40                      
02cacf34: ret                                                
02cacf38: bl      #0x2b7105c                                 fn_2b7105c
## GenCharacter() -> void
---- GameSession::GenCharacter 0x2cacaa0
02cacaa0: str     x30, [sp, #-0x40]!                         
02cacaa4: stp     x24, x23, [sp, #0x10]                      
02cacaa8: stp     x22, x21, [sp, #0x20]                      
02cacaac: stp     x20, x19, [sp, #0x30]                      
02cacab0: adrp    x19, #0x662f000                            
02cacab4: adrp    x21, #0x6266000                            
02cacab8: mov     x20, x0                                    
02cacabc: ldrb    w8, [x19, #0xb36]                          
02cacac0: ldr     x21, [x21, #0x658]                         MS:MonoSingleton`1::get_Instance
02cacac4: tbnz    w8, #0, #0x2cacb24                         
02cacac8: adrp    x0, #0x6266000                             
02cacacc: ldr     x0, [x0, #0x870]                           MS:DataManager::GetAsset
02cacad0: bl      #0x2b70db0                                 fn_2b70db0
02cacad4: adrp    x0, #0x6266000                             
02cacad8: ldr     x0, [x0, #0x878]                           MS:DataManager::GetData
02cacadc: bl      #0x2b70db0                                 fn_2b70db0
02cacae0: adrp    x0, #0x6266000                             
02cacae4: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02cacae8: bl      #0x2b70db0                                 fn_2b70db0
02cacaec: adrp    x0, #0x6264000                             
02cacaf0: ldr     x0, [x0, #0xec8]                           MS:UnityEngine.Object::Instantiate
02cacaf4: bl      #0x2b70db0                                 fn_2b70db0
02cacaf8: adrp    x0, #0x6263000                             
02cacafc: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02cacb00: bl      #0x2b70db0                                 fn_2b70db0
02cacb04: adrp    x0, #0x6266000                             
02cacb08: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02cacb0c: bl      #0x2b70db0                                 fn_2b70db0
02cacb10: adrp    x0, #0x6266000                             
02cacb14: ldr     x0, [x0, #0x888]                           S:'CharacterChanger'
02cacb18: bl      #0x2b70db0                                 fn_2b70db0
02cacb1c: mov     w8, #1                                     
02cacb20: strb    w8, [x19, #0xb36]                          
02cacb24: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cacb28: bl      #0x3769600                                 fn_3769600
02cacb2c: cbz     x0, #0x2cacd88                             
02cacb30: adrp    x8, #0x6266000                             
02cacb34: mov     x21, x0                                    
02cacb38: ldr     x8, [x8, #0x878]                           MS:DataManager::GetData
02cacb3c: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cacb40: bl      #0x3168dd0                                 fn_3168dd0
02cacb44: cbz     x0, #0x2cacd88                             
02cacb48: adrp    x24, #0x6263000                            
02cacb4c: mov     w1, wzr                                    
02cacb50: mov     x2, xzr                                    
02cacb54: ldr     x24, [x24, #0x918]                         T:UnityEngine.Object
02cacb58: bl      #0x2d25c44                                 Decor.DataDecor::GetSelectedItem
02cacb5c: ldr     x8, [x24]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cacb60: mov     x19, x20                                   
02cacb64: mov     w22, w0                                    
02cacb68: ldr     x23, [x19, #0x20]!                         &2b706f0(=d65f03c0f9400800) ._mainCharacter
02cacb6c: ldr     w9, [x8, #0xe4]                            [62660e4]=0 f=0,0
02cacb70: cbnz    w9, #0x2cacb7c                             
02cacb74: mov     x0, x8                                     
02cacb78: bl      #0x2b70f30                                 fn_2b70f30
02cacb7c: mov     x0, x23                                    
02cacb80: mov     x1, xzr                                    
02cacb84: bl      #0x5b3bb1c                                 UnityEngine.Object::op_Implicit
02cacb88: tbz     w0, #0, #0x2cacbc0                         
02cacb8c: ldr     x0, [x19]                                  &2b706c4(=eb01011ff9400808)
02cacb90: cbz     x0, #0x2cacd88                             
02cacb94: mov     x1, xzr                                    
02cacb98: bl      #0x5b37654                                 UnityEngine.GameObject::get_gameObject
02cacb9c: ldr     x8, [x24]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cacba0: mov     x23, x0                                    
02cacba4: ldr     w9, [x8, #0xe4]                            [62660e4]=0 f=0,0
02cacba8: cbnz    w9, #0x2cacbb4                             
02cacbac: mov     x0, x8                                     
02cacbb0: bl      #0x2b70f30                                 fn_2b70f30
02cacbb4: mov     x0, x23                                    
02cacbb8: mov     x1, xzr                                    
02cacbbc: bl      #0x5b3ca38                                 UnityEngine.Object::Destroy
02cacbc0: adrp    x8, #0x6266000                             
02cacbc4: mov     x0, x21                                    
02cacbc8: ldr     x8, [x8, #0x870]                           MS:DataManager::GetAsset
02cacbcc: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cacbd0: bl      #0x3168af0                                 fn_3168af0
02cacbd4: cbz     x0, #0x2cacd88                             
02cacbd8: adrp    x8, #0x6266000                             
02cacbdc: mov     x2, xzr                                    
02cacbe0: ldr     x8, [x8, #0x888]                           S:'CharacterChanger'
02cacbe4: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cacbe8: bl      #0x2d25ed4                                 Decor.DecorAsset::GetCategoryAssetByName
02cacbec: cbz     x0, #0x2cacd88                             
02cacbf0: mov     w1, w22                                    
02cacbf4: mov     x2, xzr                                    
02cacbf8: bl      #0x2d24a4c                                 Decor.CategoryAsset::GetOptionDataByID
02cacbfc: cbz     x0, #0x2cacd88                             
02cacc00: ldr     x8, [x24]                                  &2c5bbd4(=a9bd7bfdd503233f)
02cacc04: adrp    x22, #0x6264000                            
02cacc08: ldr     x22, [x22, #0xec8]                         MS:UnityEngine.Object::Instantiate
02cacc0c: ldr     x21, [x0, #0x38]                           S:'native_collap_id' .<Avatar>k__BackingField
02cacc10: ldr     x20, [x20, #0x28]                          ._characterContainer
02cacc14: ldr     w9, [x8, #0xe4]                            [62660e4]=0 f=0,0
02cacc18: cbnz    w9, #0x2cacc24                             
02cacc1c: mov     x0, x8                                     
02cacc20: bl      #0x2b70f30                                 fn_2b70f30
02cacc24: ldr     x2, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cacc28: mov     x0, x21                                    
02cacc2c: mov     x1, x20                                    
02cacc30: bl      #0x3275fcc                                 fn_3275fcc
02cacc34: mov     x1, x0                                     
02cacc38: str     x0, [x19]                                  
02cacc3c: mov     x0, x19                                    
02cacc40: bl      #0x2b70d54                                 fn_2b70d54
02cacc44: ldr     x0, [x19]                                  &2b706c4(=eb01011ff9400808)
02cacc48: cbz     x0, #0x2cacd88                             
02cacc4c: mov     x1, xzr                                    
02cacc50: bl      #0x5b368f0                                 UnityEngine.GameObject::get_transform
02cacc54: mov     w1, wzr                                    
02cacc58: mov     x2, xzr                                    
02cacc5c: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02cacc60: ldr     x0, [x19]                                  &2b706c4(=eb01011ff9400808)
02cacc64: cbz     x0, #0x2cacd88                             
02cacc68: mov     x1, xzr                                    
02cacc6c: bl      #0x5b368f0                                 UnityEngine.GameObject::get_transform
02cacc70: adrp    x22, #0x662f000                            
02cacc74: mov     x20, x0                                    
02cacc78: ldrb    w8, [x22, #0x91a]                          
02cacc7c: cbnz    w8, #0x2cacc94                             
02cacc80: adrp    x0, #0x6264000                             
02cacc84: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02cacc88: bl      #0x2b70db0                                 fn_2b70db0
02cacc8c: mov     w8, #1                                     
02cacc90: strb    w8, [x22, #0x91a]                          
02cacc94: cbz     x20, #0x2cacd88                            
02cacc98: adrp    x21, #0x6264000                            
02cacc9c: mov     x0, x20                                    
02cacca0: mov     x1, xzr                                    
02cacca4: ldr     x21, [x21, #0xd8]                          T:UnityEngine.Vector3
02cacca8: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02caccac: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02caccb0: ldp     s1, s2, [x8, #4]                           
02caccb4: ldr     s0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caccb8: bl      #0x5b45cec                                 UnityEngine.Transform::set_localPosition
02caccbc: ldr     x0, [x19]                                  &2b706c4(=eb01011ff9400808)
02caccc0: cbz     x0, #0x2cacd88                             
02caccc4: mov     x1, xzr                                    
02caccc8: bl      #0x5b368f0                                 UnityEngine.GameObject::get_transform
02cacccc: ldrb    w8, [x22, #0x91a]                          
02caccd0: mov     x20, x0                                    
02caccd4: cbnz    w8, #0x2caccec                             
02caccd8: adrp    x0, #0x6264000                             
02caccdc: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02cacce0: bl      #0x2b70db0                                 fn_2b70db0
02cacce4: mov     w8, #1                                     
02cacce8: strb    w8, [x22, #0x91a]                          
02caccec: cbz     x20, #0x2cacd88                            
02caccf0: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02caccf4: mov     x0, x20                                    
02caccf8: mov     x1, xzr                                    
02caccfc: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02cacd00: ldp     s1, s2, [x8, #4]                           
02cacd04: ldr     s0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cacd08: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02cacd0c: ldr     x0, [x19]                                  &2b706c4(=eb01011ff9400808)
02cacd10: cbz     x0, #0x2cacd88                             
02cacd14: adrp    x20, #0x6266000                            
02cacd18: mov     x1, xzr                                    
02cacd1c: ldr     x20, [x20, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02cacd20: bl      #0x5b368f0                                 UnityEngine.GameObject::get_transform
02cacd24: adrp    x22, #0x662f000                            
02cacd28: mov     x19, x0                                    
02cacd2c: ldrb    w8, [x22, #0xa74]                          
02cacd30: cbnz    w8, #0x2cacd48                             
02cacd34: adrp    x0, #0x6264000                             
02cacd38: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02cacd3c: bl      #0x2b70db0                                 fn_2b70db0
02cacd40: mov     w8, #1                                     
02cacd44: strb    w8, [x22, #0xa74]                          
02cacd48: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cacd4c: mov     x0, x19                                    
02cacd50: mov     x1, xzr                                    
02cacd54: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02cacd58: ldp     s0, s1, [x8, #0xc]                         
02cacd5c: ldr     s2, [x8, #0x14]                            [6266014]=0 f=0,0
02cacd60: adrp    x8, #0x1084000                             
02cacd64: ldr     s3, [x8, #0xda8]                           [1084da8]=da242603eb851ec f=0.36,1e-30
02cacd68: bl      #0x2d98af8                                 DG.Tweening.ShortcutExtensions::DOScale
02cacd6c: ldr     x2, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cacd70: ldp     x20, x19, [sp, #0x30]                      
02cacd74: ldp     x22, x21, [sp, #0x20]                      
02cacd78: mov     w1, #0x1b                                  
02cacd7c: ldp     x24, x23, [sp, #0x10]                      
02cacd80: ldr     x30, [sp], #0x40                           
02cacd84: b       #0x336fa0c                                 
02cacd88: bl      #0x2b7105c                                 fn_2b7105c
## SetCharacter(UnityEngine.GameObject character) -> void
---- GameSession::SetCharacter 0x2cacf3c
02cacf3c: str     x1, [x0, #0x20]!                           ._mainCharacter
02cacf40: b       #0x2b70d54                                 
## SetActiveBackground(bool active) -> void
---- GameSession::SetActiveBackground 0x2cace00
02cace00: ret                                                
## UpdateAvatar() -> void
---- GameSession::UpdateAvatar 0x2cac9c4
02cac9c4: stp     x30, x21, [sp, #-0x20]!                    
02cac9c8: stp     x20, x19, [sp, #0x10]                      
02cac9cc: adrp    x21, #0x662f000                            
02cac9d0: adrp    x20, #0x6266000                            
02cac9d4: mov     x19, x0                                    
02cac9d8: ldrb    w8, [x21, #0xb37]                          
02cac9dc: ldr     x20, [x20, #0x658]                         MS:MonoSingleton`1::get_Instance
02cac9e0: tbnz    w8, #0, #0x2caca10                         
02cac9e4: adrp    x0, #0x6266000                             
02cac9e8: ldr     x0, [x0, #0x870]                           MS:DataManager::GetAsset
02cac9ec: bl      #0x2b70db0                                 fn_2b70db0
02cac9f0: adrp    x0, #0x6266000                             
02cac9f4: ldr     x0, [x0, #0x878]                           MS:DataManager::GetData
02cac9f8: bl      #0x2b70db0                                 fn_2b70db0
02cac9fc: adrp    x0, #0x6266000                             
02caca00: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02caca04: bl      #0x2b70db0                                 fn_2b70db0
02caca08: mov     w8, #1                                     
02caca0c: strb    w8, [x21, #0xb37]                          
02caca10: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caca14: bl      #0x3769600                                 fn_3769600
02caca18: cbz     x0, #0x2caca9c                             
02caca1c: adrp    x8, #0x6266000                             
02caca20: ldr     x8, [x8, #0x878]                           MS:DataManager::GetData
02caca24: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caca28: bl      #0x3168dd0                                 fn_3168dd0
02caca2c: cbz     x0, #0x2caca9c                             
02caca30: mov     w1, wzr                                    
02caca34: mov     x2, xzr                                    
02caca38: bl      #0x2d25c44                                 Decor.DataDecor::GetSelectedItem
02caca3c: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caca40: mov     w20, w0                                    
02caca44: mov     x0, x8                                     
02caca48: bl      #0x3769600                                 fn_3769600
02caca4c: cbz     x0, #0x2caca9c                             
02caca50: adrp    x8, #0x6266000                             
02caca54: ldr     x8, [x8, #0x870]                           MS:DataManager::GetAsset
02caca58: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caca5c: bl      #0x3168af0                                 fn_3168af0
02caca60: cbz     x0, #0x2caca9c                             
02caca64: mov     w1, wzr                                    
02caca68: mov     x2, xzr                                    
02caca6c: bl      #0x2d249f4                                 Decor.DecorAsset::GetCategoryAssetByIndex
02caca70: cbz     x0, #0x2caca9c                             
02caca74: mov     w1, w20                                    
02caca78: mov     x2, xzr                                    
02caca7c: bl      #0x2d24a4c                                 Decor.CategoryAsset::GetOptionDataByID
02caca80: cbz     x0, #0x2caca9c                             
02caca84: ldr     x1, [x0, #0x28]                            S:'banner_ad_on_off' ._characterContainer
02caca88: str     x1, [x19, #0x38]!                          .<Avatar>k__BackingField
02caca8c: mov     x0, x19                                    
02caca90: ldp     x20, x19, [sp, #0x10]                      
02caca94: ldp     x30, x21, [sp], #0x20                      
02caca98: b       #0x2b70d54                                 
02caca9c: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- GameSession::.ctor 0x2cacf44
02cacf44: str     x30, [sp, #-0x30]!                         
02cacf48: stp     x22, x21, [sp, #0x10]                      
02cacf4c: stp     x20, x19, [sp, #0x20]                      
02cacf50: adrp    x20, #0x662f000                            
02cacf54: mov     x19, x0                                    
02cacf58: ldrb    w8, [x20, #0xb38]                          
02cacf5c: tbnz    w8, #0, #0x2cacf74                         
02cacf60: adrp    x0, #0x6266000                             
02cacf64: ldr     x0, [x0, #0x890]                           MS:MonoSingleton`1::.ctor
02cacf68: bl      #0x2b70db0                                 fn_2b70db0
02cacf6c: mov     w8, #1                                     
02cacf70: strb    w8, [x20, #0xb38]                          
02cacf74: adrp    x21, #0x662f000                            
02cacf78: adrp    x20, #0x6266000                            
02cacf7c: mov     w22, #1                                    
02cacf80: ldrb    w8, [x21, #0xa74]                          
02cacf84: ldr     x20, [x20, #0x890]                         MS:MonoSingleton`1::.ctor
02cacf88: strb    w22, [x19, #0x4d]                          .SceneLoadFromLoading
02cacf8c: cbnz    w8, #0x2cacfa0                             
02cacf90: adrp    x0, #0x6264000                             
02cacf94: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02cacf98: bl      #0x2b70db0                                 fn_2b70db0
02cacf9c: strb    w22, [x21, #0xa74]                         
02cacfa0: adrp    x8, #0x6264000                             
02cacfa4: mov     x0, x19                                    
02cacfa8: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02cacfac: ldr     x1, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cacfb0: ldp     x22, x21, [sp, #0x10]                      
02cacfb4: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cacfb8: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02cacfbc: ldur    d0, [x8, #0xc]                             
02cacfc0: ldr     s1, [x8, #0x14]                            [6264014]=0 f=0,0
02cacfc4: mov     w8, #0x63                                  
02cacfc8: str     w8, [x19, #0x5c]                           .AnimNeedToCast
02cacfcc: str     d0, [x19, #0x50]                           ._characterIntialScale
02cacfd0: str     s1, [x19, #0x58]                           
02cacfd4: ldp     x20, x19, [sp, #0x20]                      
02cacfd8: ldr     x30, [sp], #0x30                           
02cacfdc: b       #0x3769e18                                 
