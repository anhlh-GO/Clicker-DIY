#### CLASS AppOpenAdApplovinControl/<LoadAppOpenAdAfterDelay>d__6 parent= object
#   field <>1__state                     int                                                off=0x10 attr=1 
#   field <>2__current                   object                                             off=0x18 attr=1 
#   field delay                          float                                              off=0x20 attr=6 
#   field <>4__this                      AppOpenAdApplovinControl                           off=0x28 attr=6 
## .ctor(int <>1__state) -> void
---- AppOpenAdApplovinControl/<LoadAppOpenAdAfterDelay>d__6::.ctor 0x2c8d9ac
02c8d9ac: str     x30, [sp, #-0x20]!                         
02c8d9b0: stp     x20, x19, [sp, #0x10]                      
02c8d9b4: mov     w19, w1                                    
02c8d9b8: mov     x1, xzr                                    
02c8d9bc: mov     x20, x0                                    
02c8d9c0: bl      #0x4e53e9c                                 System.Object::.ctor
02c8d9c4: str     w19, [x20, #0x10]                          .<>1__state
02c8d9c8: ldp     x20, x19, [sp, #0x10]                      
02c8d9cc: ldr     x30, [sp], #0x20                           
02c8d9d0: ret                                                
## System.IDisposable.Dispose() -> void
---- AppOpenAdApplovinControl/<LoadAppOpenAdAfterDelay>d__6::System.IDisposable.Dispose 0x2c8db00
02c8db00: ret                                                
## MoveNext() -> bool
---- AppOpenAdApplovinControl/<LoadAppOpenAdAfterDelay>d__6::MoveNext 0x2c8db04
02c8db04: str     d8, [sp, #-0x30]!                          
02c8db08: stp     x30, x21, [sp, #0x10]                      
02c8db0c: stp     x20, x19, [sp, #0x20]                      
02c8db10: adrp    x20, #0x662f000                            
02c8db14: mov     x19, x0                                    
02c8db18: ldrb    w8, [x20, #0x98e]                          
02c8db1c: tbnz    w8, #0, #0x2c8db34                         
02c8db20: adrp    x0, #0x6264000                             
02c8db24: ldr     x0, [x0, #0xf58]                           T:UnityEngine.WaitForSeconds
02c8db28: bl      #0x2b70db0                                 fn_2b70db0
02c8db2c: mov     w8, #1                                     
02c8db30: strb    w8, [x20, #0x98e]                          
02c8db34: ldr     w21, [x19, #0x10]                          .<>1__state
02c8db38: cbz     w21, #0x2c8db5c                            
02c8db3c: cmp     w21, #1                                    
02c8db40: b.ne    #0x2c8dba0                                 
02c8db44: ldr     x0, [x19, #0x28]                           .<>4__this
02c8db48: mov     w8, #-1                                    
02c8db4c: str     w8, [x19, #0x10]                           .<>1__state
02c8db50: cbz     x0, #0x2c8dbb8                             
02c8db54: bl      #0x2c8d8b0                                 AppOpenAdApplovinControl::LoadAppOpenAd
02c8db58: b       #0x2c8dba0                                 
02c8db5c: adrp    x8, #0x6264000                             
02c8db60: mov     w9, #-1                                    
02c8db64: ldr     x8, [x8, #0xf58]                           T:UnityEngine.WaitForSeconds
02c8db68: ldr     s8, [x19, #0x20]                           .delay
02c8db6c: str     w9, [x19, #0x10]                           .<>1__state
02c8db70: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c8db74: bl      #0x2b7104c                                 fn_2b7104c
02c8db78: fmov    s0, s8                                     
02c8db7c: mov     x1, xzr                                    
02c8db80: mov     x20, x0                                    
02c8db84: bl      #0x5b3e5e8                                 UnityEngine.WaitForSeconds::.ctor
02c8db88: mov     x0, x19                                    
02c8db8c: mov     x1, x20                                    
02c8db90: str     x20, [x0, #0x18]!                          .<>2__current
02c8db94: bl      #0x2b70d54                                 fn_2b70d54
02c8db98: mov     w8, #1                                     
02c8db9c: str     w8, [x19, #0x10]                           .<>1__state
02c8dba0: cmp     w21, #0                                    
02c8dba4: ldp     x20, x19, [sp, #0x20]                      
02c8dba8: ldp     x30, x21, [sp, #0x10]                      
02c8dbac: cset    w0, eq                                     
02c8dbb0: ldr     d8, [sp], #0x30                            
02c8dbb4: ret                                                
02c8dbb8: bl      #0x2b7105c                                 fn_2b7105c
## System.Collections.Generic.IEnumerator<System.Object>.get_Current() -> object
---- AppOpenAdApplovinControl/<LoadAppOpenAdAfterDelay>d__6::System.Collections.Generic.IEnumerator<System.Object>.get_Current 0x2c8dbbc
02c8dbbc: ldr     x0, [x0, #0x18]                            .<>2__current
02c8dbc0: ret                                                
## System.Collections.IEnumerator.Reset() -> void
---- AppOpenAdApplovinControl/<LoadAppOpenAdAfterDelay>d__6::System.Collections.IEnumerator.Reset 0x2c8dbc4
02c8dbc4: stp     x30, x19, [sp, #-0x10]!                    
02c8dbc8: adrp    x0, #0x6264000                             
02c8dbcc: ldr     x0, [x0, #0xf60]                           T:System.NotSupportedException
02c8dbd0: bl      #0x2b70dc4                                 fn_2b70dc4
02c8dbd4: bl      #0x2b7104c                                 fn_2b7104c
02c8dbd8: mov     x1, xzr                                    
02c8dbdc: mov     x19, x0                                    
02c8dbe0: bl      #0x4e14238                                 System.NotSupportedException::.ctor
02c8dbe4: adrp    x0, #0x6265000                             
02c8dbe8: ldr     x0, [x0, #0x398]                           M:AppOpenAdApplovinControl/<LoadAppOpenAdAfterDelay>d__6::System.Collections.IEnumerator.Reset
02c8dbec: bl      #0x2b70dc4                                 fn_2b70dc4
02c8dbf0: mov     x1, x0                                     
02c8dbf4: mov     x0, x19                                    
02c8dbf8: bl      #0x2b70f20                                 fn_2b70f20
## System.Collections.IEnumerator.get_Current() -> object
---- AppOpenAdApplovinControl/<LoadAppOpenAdAfterDelay>d__6::System.Collections.IEnumerator.get_Current 0x2c8dbfc
02c8dbfc: ldr     x0, [x0, #0x18]                            .<>2__current
02c8dc00: ret                                                
#### CLASS AppOpenAdApplovinControl parent= ApplovinEventBase
#   field _showAdAction                  System.Action                                      off=0x30 attr=1 
#   field _adKey                         string                                             off=0x38 attr=1 
## Start() -> void
---- AppOpenAdApplovinControl::Start 0x2c8d690
02c8d690: mov     w8, #4                                     
02c8d694: str     w8, [x0, #0x28]                            
02c8d698: ret                                                
## InitAd() -> void
---- AppOpenAdApplovinControl::InitAd 0x2c8d69c
02c8d69c: stp     x30, x23, [sp, #-0x30]!                    
02c8d6a0: stp     x22, x21, [sp, #0x10]                      
02c8d6a4: stp     x20, x19, [sp, #0x20]                      
02c8d6a8: adrp    x21, #0x662f000                            
02c8d6ac: adrp    x20, #0x6264000                            
02c8d6b0: mov     x19, x0                                    
02c8d6b4: ldrb    w8, [x21, #0x989]                          
02c8d6b8: ldr     x20, [x20, #0xfc0]                         T:RemoteConfigManager
02c8d6bc: tbnz    w8, #0, #0x2c8d6f8                         
02c8d6c0: adrp    x0, #0x6265000                             
02c8d6c4: ldr     x0, [x0, #0x350]                           T:type7232(k15)
02c8d6c8: bl      #0x2b70db0                                 fn_2b70db0
02c8d6cc: adrp    x0, #0x6265000                             
02c8d6d0: ldr     x0, [x0, #0x358]                           T:type7234(k15)
02c8d6d4: bl      #0x2b70db0                                 fn_2b70db0
02c8d6d8: adrp    x0, #0x6265000                             
02c8d6dc: ldr     x0, [x0, #0x360]                           T:type7277(k15)
02c8d6e0: bl      #0x2b70db0                                 fn_2b70db0
02c8d6e4: adrp    x0, #0x6264000                             
02c8d6e8: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02c8d6ec: bl      #0x2b70db0                                 fn_2b70db0
02c8d6f0: mov     w8, #1                                     
02c8d6f4: strb    w8, [x21, #0x989]                          
02c8d6f8: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c8d6fc: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c8d700: cbnz    w8, #0x2c8d708                             
02c8d704: bl      #0x2b70f30                                 fn_2b70f30
02c8d708: adrp    x21, #0x662f000                            
02c8d70c: ldrb    w8, [x21, #0xa7f]                          
02c8d710: cbnz    w8, #0x2c8d728                             
02c8d714: adrp    x0, #0x6264000                             
02c8d718: ldr     x0, [x0, #0xfc0]                           T:RemoteConfigManager
02c8d71c: bl      #0x2b70db0                                 fn_2b70db0
02c8d720: mov     w8, #1                                     
02c8d724: strb    w8, [x21, #0xa7f]                          
02c8d728: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c8d72c: adrp    x21, #0x6265000                            
02c8d730: adrp    x23, #0x6265000                            
02c8d734: adrp    x22, #0x6265000                            
02c8d738: ldr     x21, [x21, #0x350]                         T:type7232(k15)
02c8d73c: ldr     x23, [x23, #0x358]                         T:type7234(k15)
02c8d740: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02c8d744: ldr     x22, [x22, #0x360]                         T:type7277(k15)
02c8d748: cbnz    w8, #0x2c8d754                             
02c8d74c: bl      #0x2b70f30                                 fn_2b70f30
02c8d750: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02c8d754: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02c8d758: mov     x0, x19                                    
02c8d75c: ldr     x1, [x8, #0x18]                            
02c8d760: str     x1, [x0, #0x38]!                           ._adKey
02c8d764: bl      #0x2b70d54                                 fn_2b70d54
02c8d768: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8d76c: bl      #0x2b7104c                                 fn_2b7104c
02c8d770: ldr     x8, [x19]                                  
02c8d774: mov     x1, x19                                    
02c8d778: mov     x3, xzr                                    
02c8d77c: mov     x20, x0                                    
02c8d780: ldr     x2, [x8, #0x180]                           
02c8d784: bl      #0x453ce6c                                 fn_453ce6c
02c8d788: mov     x0, x20                                    
02c8d78c: mov     x1, xzr                                    
02c8d790: bl      #0x4c5c7c4                                 MaxSdkCallbacks/AppOpen::add_OnAdLoadedEvent
02c8d794: ldr     x0, [x23]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8d798: bl      #0x2b7104c                                 fn_2b7104c
02c8d79c: ldr     x8, [x19]                                  
02c8d7a0: mov     x1, x19                                    
02c8d7a4: mov     x3, xzr                                    
02c8d7a8: mov     x20, x0                                    
02c8d7ac: ldr     x2, [x8, #0x190]                           
02c8d7b0: bl      #0x453ce6c                                 fn_453ce6c
02c8d7b4: mov     x0, x20                                    
02c8d7b8: mov     x1, xzr                                    
02c8d7bc: bl      #0x4c5c9dc                                 MaxSdkCallbacks/AppOpen::add_OnAdLoadFailedEvent
02c8d7c0: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8d7c4: bl      #0x2b7104c                                 fn_2b7104c
02c8d7c8: ldr     x8, [x19]                                  
02c8d7cc: mov     x1, x19                                    
02c8d7d0: mov     x3, xzr                                    
02c8d7d4: mov     x20, x0                                    
02c8d7d8: ldr     x2, [x8, #0x1a0]                           
02c8d7dc: bl      #0x453ce6c                                 fn_453ce6c
02c8d7e0: mov     x0, x20                                    
02c8d7e4: mov     x1, xzr                                    
02c8d7e8: bl      #0x4c5cbd4                                 MaxSdkCallbacks/AppOpen::add_OnAdDisplayedEvent
02c8d7ec: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8d7f0: bl      #0x2b7104c                                 fn_2b7104c
02c8d7f4: ldr     x8, [x19]                                  
02c8d7f8: mov     x1, x19                                    
02c8d7fc: mov     x3, xzr                                    
02c8d800: mov     x20, x0                                    
02c8d804: ldr     x2, [x8, #0x1d0]                           
02c8d808: bl      #0x453e174                                 fn_453e174
02c8d80c: mov     x0, x20                                    
02c8d810: mov     x1, xzr                                    
02c8d814: bl      #0x4c5cdcc                                 MaxSdkCallbacks/AppOpen::add_OnAdDisplayFailedEvent
02c8d818: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8d81c: bl      #0x2b7104c                                 fn_2b7104c
02c8d820: ldr     x8, [x19]                                  
02c8d824: mov     x1, x19                                    
02c8d828: mov     x3, xzr                                    
02c8d82c: mov     x20, x0                                    
02c8d830: ldr     x2, [x8, #0x1b0]                           
02c8d834: bl      #0x453ce6c                                 fn_453ce6c
02c8d838: mov     x0, x20                                    
02c8d83c: mov     x1, xzr                                    
02c8d840: bl      #0x4c5cfc4                                 MaxSdkCallbacks/AppOpen::add_OnAdClickedEvent
02c8d844: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8d848: bl      #0x2b7104c                                 fn_2b7104c
02c8d84c: ldr     x8, [x19]                                  
02c8d850: mov     x1, x19                                    
02c8d854: mov     x3, xzr                                    
02c8d858: mov     x20, x0                                    
02c8d85c: ldr     x2, [x8, #0x1c0]                           
02c8d860: bl      #0x453ce6c                                 fn_453ce6c
02c8d864: mov     x0, x20                                    
02c8d868: mov     x1, xzr                                    
02c8d86c: bl      #0x4c5d5ac                                 MaxSdkCallbacks/AppOpen::add_OnAdHiddenEvent
02c8d870: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8d874: bl      #0x2b7104c                                 fn_2b7104c
02c8d878: ldr     x8, [x19]                                  
02c8d87c: mov     x1, x19                                    
02c8d880: mov     x3, xzr                                    
02c8d884: mov     x20, x0                                    
02c8d888: ldr     x2, [x8, #0x1e0]                           
02c8d88c: bl      #0x453ce6c                                 fn_453ce6c
02c8d890: mov     x0, x20                                    
02c8d894: mov     x1, xzr                                    
02c8d898: bl      #0x4c5d1bc                                 MaxSdkCallbacks/AppOpen::add_OnAdRevenuePaidEvent
02c8d89c: mov     x0, x19                                    
02c8d8a0: ldp     x20, x19, [sp, #0x20]                      
02c8d8a4: ldp     x22, x21, [sp, #0x10]                      
02c8d8a8: ldp     x30, x23, [sp], #0x30                      
02c8d8ac: b       #0x2c8d8b0                                 AppOpenAdApplovinControl::LoadAppOpenAd
## LoadAppOpenAd() -> void
---- AppOpenAdApplovinControl::LoadAppOpenAd 0x2c8d8b0
02c8d8b0: stp     x30, x21, [sp, #-0x20]!                    
02c8d8b4: stp     x20, x19, [sp, #0x10]                      
02c8d8b8: adrp    x21, #0x662f000                            
02c8d8bc: adrp    x20, #0x6265000                            
02c8d8c0: mov     x19, x0                                    
02c8d8c4: ldrb    w8, [x21, #0x98a]                          
02c8d8c8: ldr     x20, [x20, #0x2f8]                         T:MaxSdkAndroid
02c8d8cc: tbnz    w8, #0, #0x2c8d8e4                         
02c8d8d0: adrp    x0, #0x6265000                             
02c8d8d4: ldr     x0, [x0, #0x2f8]                           T:MaxSdkAndroid
02c8d8d8: bl      #0x2b70db0                                 fn_2b70db0
02c8d8dc: mov     w8, #1                                     
02c8d8e0: strb    w8, [x21, #0x98a]                          
02c8d8e4: ldr     x0, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8d8e8: ldr     x19, [x19, #0x38]                          ._adKey
02c8d8ec: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c8d8f0: cbnz    w8, #0x2c8d8f8                             
02c8d8f4: bl      #0x2b70f30                                 fn_2b70f30
02c8d8f8: mov     x0, x19                                    
02c8d8fc: ldp     x20, x19, [sp, #0x10]                      
02c8d900: mov     x1, xzr                                    
02c8d904: ldp     x30, x21, [sp], #0x20                      
02c8d908: b       #0x4c5427c                                 MaxSdkAndroid::LoadAppOpenAd
## TryLoadAppOpenAd() -> void
---- AppOpenAdApplovinControl::TryLoadAppOpenAd 0x2c8d90c
02c8d90c: stp     x30, x19, [sp, #-0x10]!                    
02c8d910: fmov    s0, #2.00000000                            
02c8d914: mov     x19, x0                                    
02c8d918: bl      #0x2c8d930                                 AppOpenAdApplovinControl::LoadAppOpenAdAfterDelay
02c8d91c: mov     x1, x0                                     
02c8d920: mov     x0, x19                                    
02c8d924: mov     x2, xzr                                    
02c8d928: ldp     x30, x19, [sp], #0x10                      
02c8d92c: b       #0x5b389f0                                 UnityEngine.MonoBehaviour::StartCoroutine
## LoadAppOpenAdAfterDelay(float delay) -> System.Collections.IEnumerator
---- AppOpenAdApplovinControl::LoadAppOpenAdAfterDelay 0x2c8d930
02c8d930: str     d8, [sp, #-0x30]!                          
02c8d934: stp     x30, x21, [sp, #0x10]                      
02c8d938: stp     x20, x19, [sp, #0x20]                      
02c8d93c: fmov    s8, s0                                     
02c8d940: adrp    x20, #0x662f000                            
02c8d944: adrp    x21, #0x6265000                            
02c8d948: ldrb    w8, [x20, #0x98b]                          
02c8d94c: ldr     x21, [x21, #0x388]                         T:AppOpenAdApplovinControl/<LoadAppOpenAdAfterDelay>d__6
02c8d950: mov     x19, x0                                    
02c8d954: tbnz    w8, #0, #0x2c8d96c                         
02c8d958: adrp    x0, #0x6265000                             
02c8d95c: ldr     x0, [x0, #0x388]                           T:AppOpenAdApplovinControl/<LoadAppOpenAdAfterDelay>d__6
02c8d960: bl      #0x2b70db0                                 fn_2b70db0
02c8d964: mov     w8, #1                                     
02c8d968: strb    w8, [x20, #0x98b]                          
02c8d96c: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8d970: bl      #0x2b7104c                                 fn_2b7104c
02c8d974: mov     x1, xzr                                    
02c8d978: mov     x20, x0                                    
02c8d97c: bl      #0x4e53e9c                                 System.Object::.ctor
02c8d980: mov     x0, x20                                    
02c8d984: mov     x1, x19                                    
02c8d988: str     wzr, [x20, #0x10]                          
02c8d98c: str     x19, [x0, #0x28]!                          
02c8d990: bl      #0x2b70d54                                 fn_2b70d54
02c8d994: mov     x0, x20                                    
02c8d998: str     s8, [x20, #0x20]                           
02c8d99c: ldp     x20, x19, [sp, #0x20]                      
02c8d9a0: ldp     x30, x21, [sp, #0x10]                      
02c8d9a4: ldr     d8, [sp], #0x30                            
02c8d9a8: ret                                                
## ShowAd(System.Action onComplete) -> void
---- AppOpenAdApplovinControl::ShowAd 0x2c8cac8
02c8cac8: str     x30, [sp, #-0x30]!                         
02c8cacc: stp     x22, x21, [sp, #0x10]                      
02c8cad0: stp     x20, x19, [sp, #0x20]                      
02c8cad4: adrp    x19, #0x662f000                            
02c8cad8: adrp    x22, #0x6265000                            
02c8cadc: mov     x21, x1                                    
02c8cae0: ldrb    w8, [x19, #0x98c]                          
02c8cae4: ldr     x22, [x22, #0x2f8]                         T:MaxSdkAndroid
02c8cae8: mov     x20, x0                                    
02c8caec: tbnz    w8, #0, #0x2c8cb04                         
02c8caf0: adrp    x0, #0x6265000                             
02c8caf4: ldr     x0, [x0, #0x2f8]                           T:MaxSdkAndroid
02c8caf8: bl      #0x2b70db0                                 fn_2b70db0
02c8cafc: mov     w8, #1                                     
02c8cb00: strb    w8, [x19, #0x98c]                          
02c8cb04: mov     x19, x20                                   
02c8cb08: mov     x1, x21                                    
02c8cb0c: str     x21, [x19, #0x30]!                         ._showAdAction
02c8cb10: mov     x0, x19                                    
02c8cb14: bl      #0x2b70d54                                 fn_2b70d54
02c8cb18: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8cb1c: ldr     x21, [x19, #8]                             [662f008]=6000013 f=2.40742e-35,0
02c8cb20: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c8cb24: cbnz    w8, #0x2c8cb2c                             
02c8cb28: bl      #0x2b70f30                                 fn_2b70f30
02c8cb2c: mov     x0, x21                                    
02c8cb30: mov     x1, xzr                                    
02c8cb34: bl      #0x4c54394                                 MaxSdkAndroid::IsAppOpenAdReady
02c8cb38: tbz     w0, #0, #0x2c8cb70                         
02c8cb3c: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8cb40: ldr     x19, [x20, #0x38]                          ._adKey
02c8cb44: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02c8cb48: cbnz    w8, #0x2c8cb50                             
02c8cb4c: bl      #0x2b70f30                                 fn_2b70f30
02c8cb50: mov     x0, x19                                    
02c8cb54: ldp     x20, x19, [sp, #0x20]                      
02c8cb58: ldp     x22, x21, [sp, #0x10]                      
02c8cb5c: mov     x1, xzr                                    
02c8cb60: mov     x2, xzr                                    
02c8cb64: mov     x3, xzr                                    
02c8cb68: ldr     x30, [sp], #0x30                           
02c8cb6c: b       #0x4c544c0                                 MaxSdkAndroid::ShowAppOpenAd
02c8cb70: ldr     x8, [x19]                                  &2b706c4(=eb01011ff9400808)
02c8cb74: cbz     x8, #0x2c8cb88                             
02c8cb78: ldr     x9, [x8, #0x18]                            
02c8cb7c: ldr     x0, [x8, #0x40]                            
02c8cb80: ldr     x1, [x8, #0x28]                            
02c8cb84: blr     x9                                         
02c8cb88: mov     x0, x19                                    
02c8cb8c: str     xzr, [x19]                                 
02c8cb90: mov     x1, xzr                                    
02c8cb94: ldp     x20, x19, [sp, #0x20]                      
02c8cb98: ldp     x22, x21, [sp, #0x10]                      
02c8cb9c: ldr     x30, [sp], #0x30                           
02c8cba0: b       #0x2b70d54                                 
## OnAdHiddenEvent(string adUnitID, MaxSdkBase/AdInfo adInfo) -> void
---- AppOpenAdApplovinControl::OnAdHiddenEvent 0x2c8d9d4
02c8d9d4: str     x30, [sp, #-0x20]!                         
02c8d9d8: stp     x20, x19, [sp, #0x10]                      
02c8d9dc: mov     x19, x0                                    
02c8d9e0: bl      #0x2c8bea0                                 ApplovinEventBase::OnAdHiddenEvent
02c8d9e4: mov     x20, x19                                   
02c8d9e8: ldr     x8, [x20, #0x30]!                          ._showAdAction
02c8d9ec: cbz     x8, #0x2c8da00                             
02c8d9f0: ldr     x9, [x8, #0x18]                            
02c8d9f4: ldr     x0, [x8, #0x40]                            
02c8d9f8: ldr     x1, [x8, #0x28]                            
02c8d9fc: blr     x9                                         
02c8da00: mov     x0, x20                                    
02c8da04: mov     x1, xzr                                    
02c8da08: str     xzr, [x19, #0x30]                          ._showAdAction
02c8da0c: bl      #0x2b70d54                                 fn_2b70d54
02c8da10: mov     x0, x19                                    
02c8da14: ldp     x20, x19, [sp, #0x10]                      
02c8da18: ldr     x30, [sp], #0x20                           
02c8da1c: b       #0x2c8d8b0                                 AppOpenAdApplovinControl::LoadAppOpenAd
## OnAdDisplayFailedEvent(string adUnitId, MaxSdkBase/ErrorInfo errorInfo, MaxSdkBase/AdInfo adInfo) -> void
---- AppOpenAdApplovinControl::OnAdDisplayFailedEvent 0x2c8da20
02c8da20: str     x30, [sp, #-0x20]!                         
02c8da24: stp     x20, x19, [sp, #0x10]                      
02c8da28: mov     x19, x0                                    
02c8da2c: bl      #0x2c8bfac                                 ApplovinEventBase::OnAdDisplayFailedEvent
02c8da30: mov     x20, x19                                   
02c8da34: ldr     x8, [x20, #0x30]!                          ._showAdAction
02c8da38: cbz     x8, #0x2c8da4c                             
02c8da3c: ldr     x9, [x8, #0x18]                            
02c8da40: ldr     x0, [x8, #0x40]                            
02c8da44: ldr     x1, [x8, #0x28]                            
02c8da48: blr     x9                                         
02c8da4c: mov     x0, x20                                    
02c8da50: mov     x1, xzr                                    
02c8da54: str     xzr, [x19, #0x30]                          ._showAdAction
02c8da58: bl      #0x2b70d54                                 fn_2b70d54
02c8da5c: fmov    s0, #2.00000000                            
02c8da60: mov     x0, x19                                    
02c8da64: bl      #0x2c8d930                                 AppOpenAdApplovinControl::LoadAppOpenAdAfterDelay
02c8da68: mov     x1, x0                                     
02c8da6c: mov     x0, x19                                    
02c8da70: mov     x2, xzr                                    
02c8da74: ldp     x20, x19, [sp, #0x10]                      
02c8da78: ldr     x30, [sp], #0x20                           
02c8da7c: b       #0x5b389f0                                 UnityEngine.MonoBehaviour::StartCoroutine
## OnAdLoadFailedEvent(string adUnitId, MaxSdkBase/ErrorInfo errorInfo) -> void
---- AppOpenAdApplovinControl::OnAdLoadFailedEvent 0x2c8da80
02c8da80: stp     x30, x19, [sp, #-0x10]!                    
02c8da84: mov     x19, x0                                    
02c8da88: bl      #0x2c8bb74                                 ApplovinEventBase::OnAdLoadFailedEvent
02c8da8c: fmov    s0, #2.00000000                            
02c8da90: mov     x0, x19                                    
02c8da94: bl      #0x2c8d930                                 AppOpenAdApplovinControl::LoadAppOpenAdAfterDelay
02c8da98: mov     x1, x0                                     
02c8da9c: mov     x0, x19                                    
02c8daa0: mov     x2, xzr                                    
02c8daa4: ldp     x30, x19, [sp], #0x10                      
02c8daa8: b       #0x5b389f0                                 UnityEngine.MonoBehaviour::StartCoroutine
## .ctor() -> void
---- AppOpenAdApplovinControl::.ctor 0x2c8daac
02c8daac: stp     x30, x21, [sp, #-0x20]!                    
02c8dab0: stp     x20, x19, [sp, #0x10]                      
02c8dab4: adrp    x20, #0x662f000                            
02c8dab8: adrp    x21, #0x6265000                            
02c8dabc: mov     x19, x0                                    
02c8dac0: ldrb    w8, [x20, #0x98d]                          
02c8dac4: ldr     x21, [x21, #0x390]                         S:'244ec69f520af62f'
02c8dac8: tbnz    w8, #0, #0x2c8dae0                         
02c8dacc: adrp    x0, #0x6265000                             
02c8dad0: ldr     x0, [x0, #0x390]                           S:'244ec69f520af62f'
02c8dad4: bl      #0x2b70db0                                 fn_2b70db0
02c8dad8: mov     w8, #1                                     
02c8dadc: strb    w8, [x20, #0x98d]                          
02c8dae0: ldr     x1, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02c8dae4: mov     x0, x19                                    
02c8dae8: str     x1, [x0, #0x38]!                           ._adKey
02c8daec: bl      #0x2b70d54                                 fn_2b70d54
02c8daf0: mov     x0, x19                                    
02c8daf4: ldp     x20, x19, [sp, #0x10]                      
02c8daf8: ldp     x30, x21, [sp], #0x20                      
02c8dafc: b       #0x2c8c870                                 ApplovinEventBase::.ctor
