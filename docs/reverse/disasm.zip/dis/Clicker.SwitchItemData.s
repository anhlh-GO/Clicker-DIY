#### CLASS Clicker.SwitchItemData parent= object
#   field Id                             int                                                off=0x10 attr=6 
#   field Icon                           UnityEngine.Sprite                                 off=0x18 attr=6 
#   field SoundName                      string                                             off=0x20 attr=6 
#   field Color                          UnityEngine.Color                                  off=0x28 attr=6 
#   field UnlockMethod                   Clicker.UnlockMethod                               off=0x38 attr=6 
## .ctor() -> void
---- Clicker.SwitchItemData::.ctor 0x2d5bf48
02d5bf48: fmov    v0.4s, #1.00000000                         
02d5bf4c: mov     x1, xzr                                    
02d5bf50: stur    q0, [x0, #0x28]                            .Color
02d5bf54: b       #0x4e53e9c                                 System.Object::.ctor
