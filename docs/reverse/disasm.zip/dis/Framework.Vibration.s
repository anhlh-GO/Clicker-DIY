#### CLASS Framework.Vibration/PredefinedEffect parent= object
#   field EFFECT_CLICK                   int                                                off=0x0 attr=16 
#   field EFFECT_DOUBLE_CLICK            int                                                off=0x4 attr=16 
#   field EFFECT_HEAVY_CLICK             int                                                off=0x8 attr=16 
#   field EFFECT_TICK                    int                                                off=0xc attr=16 
#### CLASS Framework.Vibration/logLevel parent= int
#   field value__                        int                                                off=0x10 attr=606 
#   field Disabled                       Framework.Vibration/logLevel                       off=0x0 attr=8056 
#   field Info                           Framework.Vibration/logLevel                       off=0x0 attr=8056 
#   field Warning                        Framework.Vibration/logLevel                       off=0x0 attr=8056 
#### CLASS Framework.Vibration/<>c__DisplayClass10_0 parent= System.ValueType
#   field milliseconds                   long                                               off=0x10 attr=6 
#   field amplitude                      int                                                off=0x18 attr=6 
#   field cancel                         bool                                               off=0x1c attr=6 
#### CLASS Framework.Vibration/<>c__DisplayClass11_0 parent= System.ValueType
#   field pattern                        long[]                                             off=0x10 attr=6 
#   field amplitudes                     int[]                                              off=0x18 attr=6 
#   field repeat                         int                                                off=0x20 attr=6 
#   field cancel                         bool                                               off=0x24 attr=6 
#### CLASS Framework.Vibration/<>c__DisplayClass12_0 parent= System.ValueType
#   field effectId                       int                                                off=0x10 attr=6 
#### CLASS Framework.Vibration parent= object
#   field IsVibrationOn                  bool                                               off=0x0 attr=16 
#   field LogLevel                       Framework.Vibration/logLevel                       off=0x4 attr=16 
#   field vibrator                       UnityEngine.AndroidJavaObject                      off=0x8 attr=11 
#   field vibrationEffectClass           UnityEngine.AndroidJavaClass                       off=0x10 attr=11 
#   field defaultAmplitude               int                                                off=0x18 attr=11 
#   field ApiLevel                       int                                                off=0x1c attr=11 
#   field isInitialized                  bool                                               off=0x20 attr=11 
## doesSupportVibrationEffect() -> bool
---- Framework.Vibration::doesSupportVibrationEffect 0x2d870e0
02d870e0: str     x30, [sp, #-0x20]!                         
02d870e4: stp     x20, x19, [sp, #0x10]                      
02d870e8: adrp    x20, #0x6630000                            
02d870ec: adrp    x19, #0x6267000                            
02d870f0: ldrb    w8, [x20, #0x496]                          
02d870f4: ldr     x19, [x19, #0xea8]                         T:Framework.Vibration
02d870f8: tbnz    w8, #0, #0x2d87110                         
02d870fc: adrp    x0, #0x6267000                             
02d87100: ldr     x0, [x0, #0xea8]                           T:Framework.Vibration
02d87104: bl      #0x2b70db0                                 fn_2b70db0
02d87108: mov     w8, #1                                     
02d8710c: strb    w8, [x20, #0x496]                          
02d87110: ldr     x0, [x19]                                  S:'didu'
02d87114: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02d87118: cbnz    w8, #0x2d87124                             
02d8711c: bl      #0x2b70f30                                 fn_2b70f30
02d87120: ldr     x0, [x19]                                  S:'didu'
02d87124: ldr     x8, [x0, #0xb8]                            M:Framework.SceneUtils/<CRUnloadSceneAsync>d__2::System.Collections.IEnumerator.Reset
02d87128: ldp     x20, x19, [sp, #0x10]                      
02d8712c: ldr     w8, [x8, #0x1c]                            
02d87130: cmp     w8, #0x19                                  
02d87134: cset    w0, gt                                     
02d87138: ldr     x30, [sp], #0x20                           
02d8713c: ret                                                
## doesSupportPredefinedEffect() -> bool
---- Framework.Vibration::doesSupportPredefinedEffect 0x2d87140
02d87140: str     x30, [sp, #-0x20]!                         
02d87144: stp     x20, x19, [sp, #0x10]                      
02d87148: adrp    x20, #0x6630000                            
02d8714c: adrp    x19, #0x6267000                            
02d87150: ldrb    w8, [x20, #0x497]                          
02d87154: ldr     x19, [x19, #0xea8]                         T:Framework.Vibration
02d87158: tbnz    w8, #0, #0x2d87170                         
02d8715c: adrp    x0, #0x6267000                             
02d87160: ldr     x0, [x0, #0xea8]                           T:Framework.Vibration
02d87164: bl      #0x2b70db0                                 fn_2b70db0
02d87168: mov     w8, #1                                     
02d8716c: strb    w8, [x20, #0x497]                          
02d87170: ldr     x0, [x19]                                  S:'didu'
02d87174: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02d87178: cbnz    w8, #0x2d87184                             
02d8717c: bl      #0x2b70f30                                 fn_2b70f30
02d87180: ldr     x0, [x19]                                  S:'didu'
02d87184: ldr     x8, [x0, #0xb8]                            M:Framework.SceneUtils/<CRUnloadSceneAsync>d__2::System.Collections.IEnumerator.Reset
02d87188: ldp     x20, x19, [sp, #0x10]                      
02d8718c: ldr     w8, [x8, #0x1c]                            
02d87190: cmp     w8, #0x1c                                  
02d87194: cset    w0, gt                                     
02d87198: ldr     x30, [sp], #0x20                           
02d8719c: ret                                                
## Initialize() -> void
---- Framework.Vibration::Initialize 0x2d871a0
02d871a0: sub     sp, sp, #0x70                              
02d871a4: stp     x30, x23, [sp, #0x40]                      
02d871a8: stp     x22, x21, [sp, #0x50]                      
02d871ac: stp     x20, x19, [sp, #0x60]                      
02d871b0: adrp    x20, #0x6630000                            
02d871b4: adrp    x19, #0x6264000                            
02d871b8: ldrb    w8, [x20, #0x498]                          
02d871bc: ldr     x19, [x19, #0xa70]                         T:UnityEngine.Application
02d871c0: tbnz    w8, #0, #0x2d872d4                         
02d871c4: adrp    x0, #0x6263000                             
02d871c8: ldr     x0, [x0, #0xc40]                           T:UnityEngine.AndroidJavaClass
02d871cc: bl      #0x2b70db0                                 fn_2b70db0
02d871d0: adrp    x0, #0x6267000                             
02d871d4: ldr     x0, [x0, #0x3e0]                           MS:UnityEngine.AndroidJavaObject::Call
02d871d8: bl      #0x2b70db0                                 fn_2b70db0
02d871dc: adrp    x0, #0x6263000                             
02d871e0: ldr     x0, [x0, #0xc50]                           MS:UnityEngine.AndroidJavaObject::GetStatic
02d871e4: bl      #0x2b70db0                                 fn_2b70db0
02d871e8: adrp    x0, #0x6266000                             
02d871ec: ldr     x0, [x0, #0x168]                           MS:UnityEngine.AndroidJavaObject::GetStatic
02d871f0: bl      #0x2b70db0                                 fn_2b70db0
02d871f4: adrp    x0, #0x6264000                             
02d871f8: ldr     x0, [x0, #0xa70]                           T:UnityEngine.Application
02d871fc: bl      #0x2b70db0                                 fn_2b70db0
02d87200: adrp    x0, #0x6263000                             
02d87204: ldr     x0, [x0, #0x980]                           T:System.IDisposable
02d87208: bl      #0x2b70db0                                 fn_2b70db0
02d8720c: adrp    x0, #0x6263000                             
02d87210: ldr     x0, [x0, #0xa80]                           T:type24502(k1d)
02d87214: bl      #0x2b70db0                                 fn_2b70db0
02d87218: adrp    x0, #0x626d000                             
02d8721c: ldr     x0, [x0, #0x310]                           T:Framework.Vibration/PredefinedEffect
02d87220: bl      #0x2b70db0                                 fn_2b70db0
02d87224: adrp    x0, #0x6267000                             
02d87228: ldr     x0, [x0, #0xea8]                           T:Framework.Vibration
02d8722c: bl      #0x2b70db0                                 fn_2b70db0
02d87230: adrp    x0, #0x6268000                             
02d87234: ldr     x0, [x0, #0xce8]                           S:'SDK_INT'
02d87238: bl      #0x2b70db0                                 fn_2b70db0
02d8723c: adrp    x0, #0x6268000                             
02d87240: ldr     x0, [x0, #0xcf0]                           S:'EFFECT_CLICK'
02d87244: bl      #0x2b70db0                                 fn_2b70db0
02d87248: adrp    x0, #0x6268000                             
02d8724c: ldr     x0, [x0, #0xcf8]                           S:'android.os.VibrationEffect'
02d87250: bl      #0x2b70db0                                 fn_2b70db0
02d87254: adrp    x0, #0x6265000                             
02d87258: ldr     x0, [x0, #0x730]                           S:'com.unity3d.player.UnityPlayer'
02d8725c: bl      #0x2b70db0                                 fn_2b70db0
02d87260: adrp    x0, #0x6268000                             
02d87264: ldr     x0, [x0, #0xd00]                           S:'DEFAULT_AMPLITUDE'
02d87268: bl      #0x2b70db0                                 fn_2b70db0
02d8726c: adrp    x0, #0x6268000                             
02d87270: ldr     x0, [x0, #0xd08]                           S:'vibrator'
02d87274: bl      #0x2b70db0                                 fn_2b70db0
02d87278: adrp    x0, #0x6268000                             
02d8727c: ldr     x0, [x0, #0xd10]                           S:'getSystemService'
02d87280: bl      #0x2b70db0                                 fn_2b70db0
02d87284: adrp    x0, #0x6268000                             
02d87288: ldr     x0, [x0, #0xd18]                           S:'EFFECT_DOUBLE_CLICK'
02d8728c: bl      #0x2b70db0                                 fn_2b70db0
02d87290: adrp    x0, #0x6268000                             
02d87294: ldr     x0, [x0, #0xd20]                           S:'android.os.Build$VERSION'
02d87298: bl      #0x2b70db0                                 fn_2b70db0
02d8729c: adrp    x0, #0x6268000                             
02d872a0: ldr     x0, [x0, #0xd28]                           S:'EFFECT_HEAVY_CLICK'
02d872a4: bl      #0x2b70db0                                 fn_2b70db0
02d872a8: adrp    x0, #0x6268000                             
02d872ac: ldr     x0, [x0, #0xd30]                           S:'Vibration component initialized'
02d872b0: bl      #0x2b70db0                                 fn_2b70db0
02d872b4: adrp    x0, #0x6268000                             
02d872b8: ldr     x0, [x0, #0xd38]                           S:'EFFECT_TICK'
02d872bc: bl      #0x2b70db0                                 fn_2b70db0
02d872c0: adrp    x0, #0x6265000                             
02d872c4: ldr     x0, [x0, #0x738]                           S:'currentActivity'
02d872c8: bl      #0x2b70db0                                 fn_2b70db0
02d872cc: mov     w8, #1                                     
02d872d0: strb    w8, [x20, #0x498]                          
02d872d4: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d872d8: stp     xzr, xzr, [sp, #0x30]                      
02d872dc: str     xzr, [sp, #0x28]                           
02d872e0: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02d872e4: cbnz    w8, #0x2d872ec                             
02d872e8: bl      #0x2b70f30                                 fn_2b70f30
02d872ec: adrp    x21, #0x6267000                            
02d872f0: mov     x0, xzr                                    
02d872f4: ldr     x21, [x21, #0xea8]                         T:Framework.Vibration
02d872f8: bl      #0x5aeb258                                 UnityEngine.Application::get_isConsolePlatform
02d872fc: tbz     w0, #0, #0x2d87308                         
02d87300: mov     x0, xzr                                    
02d87304: bl      #0x5b1c460                                 UnityEngine.Handheld::Vibrate
02d87308: ldr     x0, [x21]                                  S:'didu'
02d8730c: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02d87310: cbnz    w8, #0x2d8731c                             
02d87314: bl      #0x2b70f30                                 fn_2b70f30
02d87318: ldr     x0, [x21]                                  S:'didu'
02d8731c: ldr     x8, [x0, #0xb8]                            T:AdsManager/<>c__DisplayClass42_0
02d87320: ldrb    w8, [x8, #0x20]                            
02d87324: cbnz    w8, #0x2d87820                             
02d87328: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d8732c: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02d87330: cbnz    w8, #0x2d87338                             
02d87334: bl      #0x2b70f30                                 fn_2b70f30
02d87338: mov     x0, xzr                                    
02d8733c: bl      #0x5aeb18c                                 UnityEngine.Application::get_platform
02d87340: cmp     w0, #0xb                                   
02d87344: b.ne    #0x2d87820                                 
02d87348: adrp    x22, #0x6263000                            
02d8734c: ldr     x22, [x22, #0xc40]                         T:UnityEngine.AndroidJavaClass
02d87350: ldr     x0, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d87354: bl      #0x2b7104c                                 fn_2b7104c
02d87358: adrp    x8, #0x6268000                             
02d8735c: mov     x2, xzr                                    
02d87360: mov     x19, x0                                    
02d87364: ldr     x8, [x8, #0xd20]                           S:'android.os.Build$VERSION'
02d87368: ldr     x1, [x8]                                   S:'{0}/2'
02d8736c: bl      #0x5ad2f6c                                 UnityEngine.AndroidJavaClass::.ctor
02d87370: add     x8, sp, #0x38                              
02d87374: str     x19, [sp, #0x38]                           
02d87378: stp     xzr, x8, [sp, #0x18]                       
02d8737c: cbz     x19, #0x2d87834                            
02d87380: adrp    x8, #0x6268000                             
02d87384: adrp    x9, #0x6266000                             
02d87388: ldr     x8, [x8, #0xce8]                           S:'SDK_INT'
02d8738c: ldr     x9, [x9, #0x168]                           MS:UnityEngine.AndroidJavaObject::GetStatic
02d87390: ldr     x1, [x8]                                   S:'{0}/2'
02d87394: ldr     x2, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d87398: mov     x0, x19                                    
02d8739c: bl      #0x31217c8                                 fn_31217c8
02d873a0: mov     w20, w0                                    
02d873a4: ldr     x0, [x21]                                  S:'didu'
02d873a8: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02d873ac: cbnz    w8, #0x2d873b8                             
02d873b0: bl      #0x2b70f30                                 fn_2b70f30
02d873b4: ldr     x0, [x21]                                  S:'didu'
02d873b8: ldr     x8, [x0, #0xb8]                            T:AdsManager/<>c__DisplayClass42_0
02d873bc: mov     x19, xzr                                   
02d873c0: str     w20, [x8, #0x1c]                           
02d873c4: add     x8, sp, #0x38                              
02d873c8: ldr     x20, [x8]                                  S:'{0}/2'
02d873cc: cbz     x20, #0x2d87430                            
02d873d0: adrp    x10, #0x6263000                            
02d873d4: ldr     x8, [x20]                                  
02d873d8: ldr     x10, [x10, #0x980]                         T:System.IDisposable
02d873dc: ldrh    w9, [x8, #0x12e]                           
02d873e0: ldr     x1, [x10]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d873e4: cbz     x9, #0x2d87408                             
02d873e8: ldr     x10, [x8, #0xb0]                           S:'penguin_close_mouth'
02d873ec: add     x10, x10, #8                               &6263008
02d873f0: ldur    x11, [x10, #-8]                            
02d873f4: cmp     x11, x1                                    
02d873f8: b.eq    #0x2d87418                                 
02d873fc: subs    x9, x9, #1                                 
02d87400: add     x10, x10, #0x10                            &6263010
02d87404: b.ne    #0x2d873f0                                 
02d87408: mov     x0, x20                                    
02d8740c: mov     w2, wzr                                    
02d87410: bl      #0x2baa05c                                 fn_2baa05c
02d87414: b       #0x2d87424                                 
02d87418: ldrsw   x9, [x10]                                  
02d8741c: add     x8, x8, x9, lsl #4                         &6268000
02d87420: add     x0, x8, #0x138                             &6268138
02d87424: ldp     x8, x1, [x0]                               
02d87428: mov     x0, x20                                    
02d8742c: blr     x8                                         
02d87430: cbnz    x19, #0x2d87838                            
02d87434: ldr     x0, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d87438: bl      #0x2b7104c                                 fn_2b7104c
02d8743c: adrp    x8, #0x6265000                             
02d87440: mov     x2, xzr                                    
02d87444: mov     x19, x0                                    
02d87448: ldr     x8, [x8, #0x730]                           S:'com.unity3d.player.UnityPlayer'
02d8744c: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02d87450: bl      #0x5ad2f6c                                 UnityEngine.AndroidJavaClass::.ctor
02d87454: add     x8, sp, #0x30                              
02d87458: str     x19, [sp, #0x30]                           
02d8745c: stp     xzr, x8, [sp, #0x18]                       
02d87460: cbz     x19, #0x2d87840                            
02d87464: adrp    x8, #0x6265000                             
02d87468: adrp    x9, #0x6263000                             
02d8746c: ldr     x8, [x8, #0x738]                           S:'currentActivity'
02d87470: ldr     x9, [x9, #0xc50]                           MS:UnityEngine.AndroidJavaObject::GetStatic
02d87474: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02d87478: ldr     x2, [x9]                                   &2c5bbd4(=a9bd7bfdd503233f)
02d8747c: mov     x0, x19                                    
02d87480: bl      #0x3121808                                 fn_3121808
02d87484: mov     x19, x0                                    
02d87488: add     x8, sp, #0x28                              
02d8748c: str     x0, [sp, #0x28]                            
02d87490: stp     xzr, x8, [sp, #8]                          
02d87494: cbz     x0, #0x2d875d8                             
02d87498: adrp    x8, #0x6263000                             
02d8749c: ldr     x8, [x8, #0xa80]                           T:type24502(k1d)
02d874a0: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02d874a4: mov     w1, #1                                     
02d874a8: bl      #0x2b70ea0                                 fn_2b70ea0
02d874ac: mov     x20, x0                                    
02d874b0: cbz     x0, #0x2d8784c                             
02d874b4: adrp    x23, #0x6268000                            
02d874b8: ldr     x23, [x23, #0xd08]                         S:'vibrator'
02d874bc: ldr     x0, [x23]                                  S:'{0}/2'
02d874c0: cbz     x0, #0x2d874d4                             
02d874c4: ldr     x8, [x20]                                  
02d874c8: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02d874cc: bl      #0x2b70f34                                 fn_2b70f34
02d874d0: cbz     x0, #0x2d87854                             
02d874d4: ldr     w8, [x20, #0x18]                           .defaultAmplitude
02d874d8: cbz     w8, #0x2d87850                             
02d874dc: ldr     x1, [x23]                                  S:'{0}/2'
02d874e0: mov     x0, x20                                    
02d874e4: str     x1, [x0, #0x20]!                           .isInitialized
02d874e8: bl      #0x2b70d54                                 fn_2b70d54
02d874ec: adrp    x8, #0x6268000                             
02d874f0: adrp    x9, #0x6267000                             
02d874f4: ldr     x8, [x8, #0xd10]                           S:'getSystemService'
02d874f8: ldr     x9, [x9, #0x3e0]                           MS:UnityEngine.AndroidJavaObject::Call
02d874fc: ldr     x1, [x8]                                   S:'{0}/2'
02d87500: ldr     x3, [x9]                                   S:'didu'
02d87504: mov     x0, x19                                    
02d87508: mov     x2, x20                                    
02d8750c: bl      #0x311f8b4                                 fn_311f8b4
02d87510: mov     x19, x0                                    
02d87514: ldr     x0, [x21]                                  S:'didu'
02d87518: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02d8751c: cbnz    w8, #0x2d87528                             
02d87520: bl      #0x2b70f30                                 fn_2b70f30
02d87524: ldr     x0, [x21]                                  S:'didu'
02d87528: ldr     x0, [x0, #0xb8]                            T:AdsManager/<>c__DisplayClass42_0
02d8752c: str     x19, [x0, #8]!                             
02d87530: mov     x1, x19                                    
02d87534: bl      #0x2b70d54                                 fn_2b70d54
02d87538: bl      #0x2d870e0                                 Framework.Vibration::doesSupportVibrationEffect
02d8753c: tbz     w0, #0, #0x2d875e4                         
02d87540: ldr     x0, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d87544: bl      #0x2b7104c                                 fn_2b7104c
02d87548: adrp    x8, #0x6268000                             
02d8754c: mov     x19, x0                                    
02d87550: ldr     x8, [x8, #0xcf8]                           S:'android.os.VibrationEffect'
02d87554: ldr     x1, [x8]                                   S:'{0}/2'
02d87558: mov     x2, xzr                                    
02d8755c: bl      #0x5ad2f6c                                 UnityEngine.AndroidJavaClass::.ctor
02d87560: ldr     x0, [x21]                                  S:'didu'
02d87564: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02d87568: cbnz    w8, #0x2d87574                             
02d8756c: bl      #0x2b70f30                                 fn_2b70f30
02d87570: ldr     x0, [x21]                                  S:'didu'
02d87574: ldr     x0, [x0, #0xb8]                            T:AdsManager/<>c__DisplayClass42_0
02d87578: str     x19, [x0, #0x10]!                          .vibrationEffectClass
02d8757c: mov     x1, x19                                    
02d87580: bl      #0x2b70d54                                 fn_2b70d54
02d87584: ldr     x8, [x21]                                  S:'didu'
02d87588: ldr     x8, [x8, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02d8758c: ldr     x0, [x8, #0x10]                            MS:DG.Tweening.TweenSettingsExtensions::SetLoops
02d87590: cbz     x0, #0x2d87860                             
02d87594: adrp    x8, #0x6268000                             
02d87598: adrp    x9, #0x6266000                             
02d8759c: ldr     x8, [x8, #0xd00]                           S:'DEFAULT_AMPLITUDE'
02d875a0: ldr     x9, [x9, #0x168]                           MS:UnityEngine.AndroidJavaObject::GetStatic
02d875a4: ldr     x1, [x8]                                   S:'{0}/2'
02d875a8: ldr     x2, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d875ac: bl      #0x31217c8                                 fn_31217c8
02d875b0: mov     w8, w0                                     
02d875b4: cmp     w0, #0xff                                  
02d875b8: mov     w9, #0xff                                  
02d875bc: ldr     x0, [x21]                                  S:'didu'
02d875c0: csel    w8, w8, w9, lt                             
02d875c4: cmp     w8, #1                                     
02d875c8: ldr     x9, [x0, #0xb8]                            T:AdsManager/<>c__DisplayClass42_0
02d875cc: csinc   w8, w8, wzr, gt                            
02d875d0: str     w8, [x9, #0x18]                            
02d875d4: b       #0x2d875e8                                 
02d875d8: mov     w23, wzr                                   
02d875dc: mov     w22, #7                                    
02d875e0: b       #0x2d876f8                                 
02d875e4: ldr     x0, [x21]                                  S:'didu'
02d875e8: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02d875ec: cbnz    w8, #0x2d875f4                             
02d875f0: bl      #0x2b70f30                                 fn_2b70f30
02d875f4: bl      #0x2d87140                                 Framework.Vibration::doesSupportPredefinedEffect
02d875f8: tbz     w0, #0, #0x2d876e8                         
02d875fc: ldr     x0, [x21]                                  S:'didu'
02d87600: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02d87604: cbnz    w8, #0x2d87610                             
02d87608: bl      #0x2b70f30                                 fn_2b70f30
02d8760c: ldr     x0, [x21]                                  S:'didu'
02d87610: ldr     x8, [x0, #0xb8]                            T:AdsManager/<>c__DisplayClass42_0
02d87614: ldr     x0, [x8, #0x10]                            MS:DG.Tweening.TweenSettingsExtensions::SetLoops
02d87618: cbz     x0, #0x2d87864                             
02d8761c: adrp    x8, #0x6268000                             
02d87620: adrp    x19, #0x6266000                            
02d87624: ldr     x8, [x8, #0xcf0]                           S:'EFFECT_CLICK'
02d87628: ldr     x19, [x19, #0x168]                         MS:UnityEngine.AndroidJavaObject::GetStatic
02d8762c: ldr     x1, [x8]                                   S:'{0}/2'
02d87630: ldr     x2, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d87634: bl      #0x31217c8                                 fn_31217c8
02d87638: adrp    x20, #0x626d000                            
02d8763c: ldr     x20, [x20, #0x310]                         T:Framework.Vibration/PredefinedEffect
02d87640: ldr     x8, [x20]                                  MS:System.Collections.Generic.List`1::.ctor
02d87644: ldr     x8, [x8, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02d87648: str     w0, [x8]                                   
02d8764c: ldr     x8, [x21]                                  S:'didu'
02d87650: ldr     x8, [x8, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02d87654: ldr     x0, [x8, #0x10]                            MS:DG.Tweening.TweenSettingsExtensions::SetLoops
02d87658: cbz     x0, #0x2d87868                             
02d8765c: adrp    x8, #0x6268000                             
02d87660: ldr     x8, [x8, #0xd18]                           S:'EFFECT_DOUBLE_CLICK'
02d87664: ldr     x2, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d87668: ldr     x1, [x8]                                   S:'{0}/2'
02d8766c: bl      #0x31217c8                                 fn_31217c8
02d87670: ldr     x8, [x20]                                  MS:System.Collections.Generic.List`1::.ctor
02d87674: ldr     x8, [x8, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02d87678: str     w0, [x8, #4]                               
02d8767c: ldr     x8, [x21]                                  S:'didu'
02d87680: ldr     x8, [x8, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02d87684: ldr     x0, [x8, #0x10]                            MS:DG.Tweening.TweenSettingsExtensions::SetLoops
02d87688: cbz     x0, #0x2d8786c                             
02d8768c: adrp    x8, #0x6268000                             
02d87690: ldr     x8, [x8, #0xd28]                           S:'EFFECT_HEAVY_CLICK'
02d87694: ldr     x2, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d87698: ldr     x1, [x8]                                   S:'{0}/2'
02d8769c: bl      #0x31217c8                                 fn_31217c8
02d876a0: ldr     x8, [x20]                                  MS:System.Collections.Generic.List`1::.ctor
02d876a4: ldr     x9, [x21]                                  S:'didu'
02d876a8: ldr     x8, [x8, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02d876ac: str     w0, [x8, #8]                               
02d876b0: ldr     x8, [x9, #0xb8]                            S:'banner_native_refresh_time'
02d876b4: ldr     x0, [x8, #0x10]                            MS:DG.Tweening.TweenSettingsExtensions::SetLoops
02d876b8: cbz     x0, #0x2d87870                             
02d876bc: adrp    x8, #0x6268000                             
02d876c0: ldr     x8, [x8, #0xd38]                           S:'EFFECT_TICK'
02d876c4: ldr     x2, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d876c8: ldr     x1, [x8]                                   S:'{0}/2'
02d876cc: bl      #0x31217c8                                 fn_31217c8
02d876d0: ldr     x8, [x20]                                  MS:System.Collections.Generic.List`1::.ctor
02d876d4: mov     x19, xzr                                   
02d876d8: mov     w23, wzr                                   
02d876dc: ldr     x8, [x8, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02d876e0: str     w0, [x8, #0xc]                             
02d876e4: b       #0x2d876f0                                 
02d876e8: mov     x19, xzr                                   
02d876ec: mov     w23, wzr                                   
02d876f0: mov     w22, #7                                    
02d876f4: add     x8, sp, #0x28                              
02d876f8: ldr     x20, [x8]                                  S:'{0}/2'
02d876fc: cbz     x20, #0x2d87760                            
02d87700: adrp    x10, #0x6263000                            
02d87704: ldr     x8, [x20]                                  MS:System.Collections.Generic.List`1::.ctor
02d87708: ldr     x10, [x10, #0x980]                         T:System.IDisposable
02d8770c: ldrh    w9, [x8, #0x12e]                           
02d87710: ldr     x1, [x10]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d87714: cbz     x9, #0x2d87738                             
02d87718: ldr     x10, [x8, #0xb0]                           S:'penguin_close_mouth'
02d8771c: add     x10, x10, #8                               &6263008
02d87720: ldur    x11, [x10, #-8]                            
02d87724: cmp     x11, x1                                    
02d87728: b.eq    #0x2d87748                                 
02d8772c: subs    x9, x9, #1                                 
02d87730: add     x10, x10, #0x10                            &6263010
02d87734: b.ne    #0x2d87720                                 
02d87738: mov     x0, x20                                    
02d8773c: mov     w2, wzr                                    
02d87740: bl      #0x2baa05c                                 fn_2baa05c
02d87744: b       #0x2d87754                                 
02d87748: ldrsw   x9, [x10]                                  
02d8774c: add     x8, x8, x9, lsl #4                         &6268000
02d87750: add     x0, x8, #0x138                             &6268138
02d87754: ldp     x8, x1, [x0]                               
02d87758: mov     x0, x20                                    
02d8775c: blr     x8                                         
02d87760: cbnz    x19, #0x2d87844                            
02d87764: tbz     w23, #0, #0x2d8776c                        
02d87768: mov     w22, wzr                                   
02d8776c: ldr     x8, [sp, #0x20]                            
02d87770: ldr     x19, [x8]                                  S:'{0}/2'
02d87774: cbz     x19, #0x2d877d8                            
02d87778: adrp    x10, #0x6263000                            
02d8777c: ldr     x8, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d87780: ldr     x10, [x10, #0x980]                         T:System.IDisposable
02d87784: ldrh    w9, [x8, #0x12e]                           
02d87788: ldr     x1, [x10]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d8778c: cbz     x9, #0x2d877b0                             
02d87790: ldr     x10, [x8, #0xb0]                           S:'penguin_close_mouth'
02d87794: add     x10, x10, #8                               &6263008
02d87798: ldur    x11, [x10, #-8]                            
02d8779c: cmp     x11, x1                                    
02d877a0: b.eq    #0x2d877c0                                 
02d877a4: subs    x9, x9, #1                                 
02d877a8: add     x10, x10, #0x10                            &6263010
02d877ac: b.ne    #0x2d87798                                 
02d877b0: mov     x0, x19                                    
02d877b4: mov     w2, wzr                                    
02d877b8: bl      #0x2baa05c                                 fn_2baa05c
02d877bc: b       #0x2d877cc                                 
02d877c0: ldrsw   x9, [x10]                                  
02d877c4: add     x8, x8, x9, lsl #4                         &6268000
02d877c8: add     x0, x8, #0x138                             &6268138
02d877cc: ldp     x8, x1, [x0]                               
02d877d0: mov     x0, x19                                    
02d877d4: blr     x8                                         
02d877d8: ldr     x0, [sp, #0x18]                            
02d877dc: cbnz    x0, #0x2d8783c                             
02d877e0: cmp     w22, #7                                    
02d877e4: b.eq    #0x2d877ec                                 
02d877e8: cbnz    w22, #0x2d87820                            
02d877ec: ldr     x0, [x21]                                  S:'didu'
02d877f0: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02d877f4: cbnz    w8, #0x2d877fc                             
02d877f8: bl      #0x2b70f30                                 fn_2b70f30
02d877fc: adrp    x8, #0x6268000                             
02d87800: mov     w1, #1                                     
02d87804: mov     w19, #1                                    
02d87808: ldr     x8, [x8, #0xd30]                           S:'Vibration component initialized'
02d8780c: ldr     x0, [x8]                                   S:'{0}/2'
02d87810: bl      #0x2d87980                                 Framework.Vibration::logAuto
02d87814: ldr     x8, [x21]                                  S:'didu'
02d87818: ldr     x8, [x8, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02d8781c: strb    w19, [x8, #0x20]                           
02d87820: ldp     x20, x19, [sp, #0x60]                      
02d87824: ldp     x22, x21, [sp, #0x50]                      
02d87828: ldp     x30, x23, [sp, #0x40]                      
02d8782c: add     sp, sp, #0x70                              
02d87830: ret                                                
02d87834: bl      #0x2b7105c                                 fn_2b7105c
02d87838: mov     x0, x19                                    
02d8783c: bl      #0x2b71054                                 fn_2b71054
02d87840: bl      #0x2b7105c                                 fn_2b7105c
02d87844: mov     x0, x19                                    
02d87848: bl      #0x2b71054                                 fn_2b71054
02d8784c: bl      #0x2b7105c                                 fn_2b7105c
02d87850: bl      #0x2b71064                                 fn_2b71064
02d87854: bl      #0x2b71080                                 fn_2b71080
02d87858: mov     x1, xzr                                    
02d8785c: bl      #0x2b70f20                                 fn_2b70f20
02d87860: bl      #0x2b7105c                                 fn_2b7105c
02d87864: bl      #0x2b7105c                                 fn_2b7105c
02d87868: bl      #0x2b7105c                                 fn_2b7105c
02d8786c: bl      #0x2b7105c                                 fn_2b7105c
02d87870: bl      #0x2b7105c                                 fn_2b7105c
02d87874: b       #0x2d87904                                 
02d87878: b       #0x2d87904                                 
02d8787c: b       #0x2d87904                                 
02d87880: b       #0x2d87904                                 
02d87884: b       #0x2d87904                                 
02d87888: b       #0x2d87904                                 
02d8788c: b       #0x2d87904                                 
02d87890: b       #0x2d87904                                 
02d87894: b       #0x2d87904                                 
02d87898: b       #0x2d87904                                 
02d8789c: b       #0x2d87904                                 
02d878a0: b       #0x2d87904                                 
02d878a4: b       #0x2d87904                                 
02d878a8: b       #0x2d87904                                 
02d878ac: b       #0x2d878f8                                 
02d878b0: b       #0x2d878f8                                 
02d878b4: b       #0x2d878bc                                 
02d878b8: b       #0x2d87904                                 
02d878bc: mov     x19, x0                                    
02d878c0: cmp     w1, #1                                     
02d878c4: b.ne    #0x2d878e8                                 
02d878c8: mov     x0, x19                                    
02d878cc: bl      #0x5e90260                                 fn_5e90260
02d878d0: ldr     x19, [x0]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d878d4: str     x19, [sp, #0x18]                           
02d878d8: bl      #0x5e90270                                 fn_5e90270
02d878dc: ldr     x8, [sp, #0x20]                            
02d878e0: b       #0x2d873c8                                 
02d878e4: mov     x19, x0                                    
02d878e8: add     x0, sp, #0x18                              
02d878ec: bl      #0x27369c4                                 fn_27369c4
02d878f0: b       #0x2d87974                                 
02d878f4: b       #0x2d87904                                 
02d878f8: mov     x20, x1                                    
02d878fc: mov     x19, x0                                    
02d87900: b       #0x2d87948                                 
02d87904: mov     x20, x1                                    
02d87908: mov     x19, x0                                    
02d8790c: cmp     w20, #1                                    
02d87910: b.ne    #0x2d87940                                 
02d87914: mov     x0, x19                                    
02d87918: bl      #0x5e90260                                 fn_5e90260
02d8791c: ldr     x19, [x0]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d87920: str     x19, [sp, #8]                              
02d87924: bl      #0x5e90270                                 fn_5e90270
02d87928: ldr     x8, [sp, #0x10]                            
02d8792c: mov     w22, wzr                                   
02d87930: mov     w23, #1                                    
02d87934: b       #0x2d876f8                                 
02d87938: mov     x20, x1                                    
02d8793c: mov     x19, x0                                    
02d87940: add     x0, sp, #8                                 
02d87944: bl      #0x27369c4                                 fn_27369c4
02d87948: cmp     w20, #1                                    
02d8794c: b.ne    #0x2d8796c                                 
02d87950: mov     x0, x19                                    
02d87954: bl      #0x5e90260                                 fn_5e90260
02d87958: ldr     x8, [x0]                                   M:AdsManager::<OnApplicationPause>b__26_0
02d8795c: str     x8, [sp, #0x18]                            
02d87960: bl      #0x5e90270                                 fn_5e90270
02d87964: b       #0x2d87768                                 
02d87968: mov     x19, x0                                    
02d8796c: add     x0, sp, #0x18                              
02d87970: bl      #0x27369c4                                 fn_27369c4
02d87974: mov     x0, x19                                    
02d87978: bl      #0x2c6051c                                 fn_2c6051c
02d8797c: bl      #0x27369b8                                 fn_27369b8
## Vibrate(long milliseconds, int amplitude, bool cancel) -> void
---- Framework.Vibration::Vibrate 0x2d6e144
02d6e144: sub     sp, sp, #0x50                              
02d6e148: str     x30, [sp, #0x10]                           
02d6e14c: stp     x24, x23, [sp, #0x20]                      
02d6e150: stp     x22, x21, [sp, #0x30]                      
02d6e154: stp     x20, x19, [sp, #0x40]                      
02d6e158: adrp    x24, #0x6630000                            
02d6e15c: adrp    x22, #0x6267000                            
02d6e160: mov     w21, w2                                    
02d6e164: ldrb    w8, [x24, #0x499]                          
02d6e168: ldr     x22, [x22, #0xea8]                         T:Framework.Vibration
02d6e16c: mov     w20, w1                                    
02d6e170: mov     x19, x0                                    
02d6e174: and     w23, w2, #1                                
02d6e178: tbnz    w8, #0, #0x2d6e1e4                         
02d6e17c: adrp    x0, #0x6266000                             
02d6e180: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d6e184: bl      #0x2b70db0                                 fn_2b70db0
02d6e188: adrp    x0, #0x6266000                             
02d6e18c: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d6e190: bl      #0x2b70db0                                 fn_2b70db0
02d6e194: adrp    x0, #0x6267000                             
02d6e198: ldr     x0, [x0, #0xea8]                           T:Framework.Vibration
02d6e19c: bl      #0x2b70db0                                 fn_2b70db0
02d6e1a0: adrp    x0, #0x6268000                             
02d6e1a4: ldr     x0, [x0, #0xd40]                           S:": Device doesn't have Amplitude Control, but Amplitude was set"
02d6e1a8: bl      #0x2b70db0                                 fn_2b70db0
02d6e1ac: adrp    x0, #0x6268000                             
02d6e1b0: ldr     x0, [x0, #0xd48]                           S:": Device doesn't have Vibrator"
02d6e1b4: bl      #0x2b70db0                                 fn_2b70db0
02d6e1b8: adrp    x0, #0x6268000                             
02d6e1bc: ldr     x0, [x0, #0xd50]                           S:': Not initialized'
02d6e1c0: bl      #0x2b70db0                                 fn_2b70db0
02d6e1c4: adrp    x0, #0x6268000                             
02d6e1c8: ldr     x0, [x0, #0xd58]                           S:': Effect called'
02d6e1cc: bl      #0x2b70db0                                 fn_2b70db0
02d6e1d0: adrp    x0, #0x6268000                             
02d6e1d4: ldr     x0, [x0, #0xd60]                           S:': Legacy called'
02d6e1d8: bl      #0x2b70db0                                 fn_2b70db0
02d6e1dc: mov     w8, #1                                     
02d6e1e0: strb    w8, [x24, #0x499]                          
02d6e1e4: ldr     x0, [x22]                                  S:'didu'
02d6e1e8: stp     x19, xzr, [sp]                             
02d6e1ec: str     w20, [sp, #8]                              
02d6e1f0: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02d6e1f4: strb    w23, [sp, #0xc]                            
02d6e1f8: cbnz    w8, #0x2d6e204                             
02d6e1fc: bl      #0x2b70f30                                 fn_2b70f30
02d6e200: ldr     x0, [x22]                                  S:'didu'
02d6e204: ldr     x8, [x0, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02d6e208: ldrb    w8, [x8]                                   
02d6e20c: cbz     w8, #0x2d6e33c                             
02d6e210: adrp    x8, #0x6266000                             
02d6e214: ldr     x8, [x8, #0x658]                           MS:MonoSingleton`1::get_Instance
02d6e218: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6e21c: bl      #0x3769600                                 fn_3769600
02d6e220: cbz     x0, #0x2d6e448                             
02d6e224: adrp    x8, #0x6266000                             
02d6e228: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02d6e22c: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6e230: bl      #0x3168dd0                                 fn_3168dd0
02d6e234: cbz     x0, #0x2d6e448                             
02d6e238: mov     x1, xzr                                    
02d6e23c: bl      #0x2cab9f8                                 DataUser::HasVibration
02d6e240: tbz     w0, #0, #0x2d6e33c                         
02d6e244: cbnz    x19, #0x2d6e250                            
02d6e248: mov     w19, #0x64                                 
02d6e24c: str     x19, [sp]                                  
02d6e250: ldr     x0, [x22]                                  S:'didu'
02d6e254: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02d6e258: cbnz    w8, #0x2d6e260                             
02d6e25c: bl      #0x2b70f30                                 fn_2b70f30
02d6e260: bl      #0x2d871a0                                 Framework.Vibration::Initialize
02d6e264: ldr     x0, [x22]                                  S:'didu'
02d6e268: ldr     x8, [x0, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02d6e26c: ldrb    w9, [x8, #0x20]                            
02d6e270: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02d6e274: cbz     w9, #0x2d6e354                             
02d6e278: cbnz    w8, #0x2d6e280                             
02d6e27c: bl      #0x2b70f30                                 fn_2b70f30
02d6e280: bl      #0x2d87b4c                                 Framework.Vibration::HasVibrator
02d6e284: tbz     w0, #0, #0x2d6e36c                         
02d6e288: tbz     w21, #0, #0x2d6e2a0                        
02d6e28c: ldr     x0, [x22]                                  S:'didu'
02d6e290: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02d6e294: cbnz    w8, #0x2d6e29c                             
02d6e298: bl      #0x2b70f30                                 fn_2b70f30
02d6e29c: bl      #0x2d87c78                                 Framework.Vibration::Cancel
02d6e2a0: ldr     x0, [x22]                                  S:'didu'
02d6e2a4: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02d6e2a8: cbnz    w8, #0x2d6e2b0                             
02d6e2ac: bl      #0x2b70f30                                 fn_2b70f30
02d6e2b0: bl      #0x2d870e0                                 Framework.Vibration::doesSupportVibrationEffect
02d6e2b4: tbz     w0, #0, #0x2d6e38c                         
02d6e2b8: cmp     w20, #0xff                                 
02d6e2bc: mov     w23, #0xff                                 
02d6e2c0: ldr     x0, [x22]                                  S:'didu'
02d6e2c4: csel    w8, w20, w23, lt                           
02d6e2c8: cmp     w8, #0                                     
02d6e2cc: csinv   w21, w8, wzr, ge                           
02d6e2d0: cmp     w20, #0                                    
02d6e2d4: csel    w20, w23, w21, lt                          
02d6e2d8: cmp     w20, #0xff                                 
02d6e2dc: str     w20, [sp, #8]                              
02d6e2e0: b.eq    #0x2d6e3cc                                 
02d6e2e4: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02d6e2e8: cbnz    w8, #0x2d6e2f0                             
02d6e2ec: bl      #0x2b70f30                                 fn_2b70f30
02d6e2f0: bl      #0x2d87da8                                 Framework.Vibration::HasAmplitudeControl
02d6e2f4: tbnz    w0, #0, #0x2d6e32c                         
02d6e2f8: ldr     x0, [x22]                                  S:'didu'
02d6e2fc: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02d6e300: cbnz    w8, #0x2d6e308                             
02d6e304: bl      #0x2b70f30                                 fn_2b70f30
02d6e308: mov     x0, sp                                     
02d6e30c: bl      #0x2d87a94                                 Framework.Vibration::<Vibrate>g__funcToStr|10_0
02d6e310: adrp    x8, #0x6268000                             
02d6e314: mov     x2, xzr                                    
02d6e318: ldr     x8, [x8, #0xd40]                           S:": Device doesn't have Amplitude Control, but Amplitude was set"
02d6e31c: ldr     x1, [x8]                                   S:'{0}/2'
02d6e320: bl      #0x4c9c514                                 System.String::Concat
02d6e324: mov     w1, #2                                     
02d6e328: bl      #0x2d87980                                 Framework.Vibration::logAuto
02d6e32c: ldr     x0, [x22]                                  S:'didu'
02d6e330: cbz     w20, #0x2d6e3b0                            
02d6e334: mov     w23, w21                                   
02d6e338: b       #0x2d6e3cc                                 
02d6e33c: ldp     x20, x19, [sp, #0x40]                      
02d6e340: ldr     x30, [sp, #0x10]                           
02d6e344: ldp     x22, x21, [sp, #0x30]                      
02d6e348: ldp     x24, x23, [sp, #0x20]                      
02d6e34c: add     sp, sp, #0x50                              
02d6e350: ret                                                
02d6e354: cbnz    w8, #0x2d6e35c                             
02d6e358: bl      #0x2b70f30                                 fn_2b70f30
02d6e35c: adrp    x20, #0x6268000                            
02d6e360: mov     w19, #2                                    
02d6e364: ldr     x20, [x20, #0xd50]                         S:': Not initialized'
02d6e368: b       #0x2d6e418                                 
02d6e36c: ldr     x0, [x22]                                  S:'didu'
02d6e370: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02d6e374: cbnz    w8, #0x2d6e37c                             
02d6e378: bl      #0x2b70f30                                 fn_2b70f30
02d6e37c: adrp    x20, #0x6268000                            
02d6e380: mov     w19, #2                                    
02d6e384: ldr     x20, [x20, #0xd48]                         S:": Device doesn't have Vibrator"
02d6e388: b       #0x2d6e418                                 
02d6e38c: ldr     x0, [x22]                                  S:'didu'
02d6e390: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02d6e394: cbnz    w8, #0x2d6e39c                             
02d6e398: bl      #0x2b70f30                                 fn_2b70f30
02d6e39c: mov     x0, x19                                    
02d6e3a0: bl      #0x2d880f4                                 Framework.Vibration::vibrateLegacy
02d6e3a4: adrp    x20, #0x6268000                            
02d6e3a8: ldr     x20, [x20, #0xd60]                         S:': Legacy called'
02d6e3ac: b       #0x2d6e414                                 
02d6e3b0: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02d6e3b4: cbnz    w8, #0x2d6e3c0                             
02d6e3b8: bl      #0x2b70f30                                 fn_2b70f30
02d6e3bc: ldr     x0, [x22]                                  S:'didu'
02d6e3c0: ldr     x8, [x0, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02d6e3c4: ldr     w23, [x8, #0x18]                           M:LuckyWheelPopup/<>c__DisplayClass50_0::<RunAnimation>b__0
02d6e3c8: str     w23, [sp, #8]                              
02d6e3cc: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02d6e3d0: cbnz    w8, #0x2d6e3d8                             
02d6e3d4: bl      #0x2b70f30                                 fn_2b70f30
02d6e3d8: bl      #0x2d87da8                                 Framework.Vibration::HasAmplitudeControl
02d6e3dc: mov     w8, w0                                     
02d6e3e0: ldr     x0, [x22]                                  S:'didu'
02d6e3e4: tst     w8, #1                                     
02d6e3e8: mov     w8, #0xff                                  
02d6e3ec: ldr     w9, [x0, #0xe4]                            [62680e4]=0 f=0,0
02d6e3f0: csel    w20, w23, w8, ne                           
02d6e3f4: str     w20, [sp, #8]                              
02d6e3f8: cbnz    w9, #0x2d6e400                             
02d6e3fc: bl      #0x2b70f30                                 fn_2b70f30
02d6e400: mov     x0, x19                                    
02d6e404: mov     w1, w20                                    
02d6e408: bl      #0x2d87ee8                                 Framework.Vibration::vibrateEffect
02d6e40c: adrp    x20, #0x6268000                            
02d6e410: ldr     x20, [x20, #0xd58]                         S:': Effect called'
02d6e414: mov     w19, #1                                    
02d6e418: mov     x0, sp                                     
02d6e41c: bl      #0x2d87a94                                 Framework.Vibration::<Vibrate>g__funcToStr|10_0
02d6e420: ldr     x1, [x20]                                  S:'{0}/2'
02d6e424: mov     x2, xzr                                    
02d6e428: bl      #0x4c9c514                                 System.String::Concat
02d6e42c: mov     w1, w19                                    
02d6e430: ldp     x20, x19, [sp, #0x40]                      
02d6e434: ldp     x22, x21, [sp, #0x30]                      
02d6e438: ldr     x30, [sp, #0x10]                           
02d6e43c: ldp     x24, x23, [sp, #0x20]                      
02d6e440: add     sp, sp, #0x50                              
02d6e444: b       #0x2d87980                                 Framework.Vibration::logAuto
02d6e448: bl      #0x2b7105c                                 fn_2b7105c
## Vibrate(long[] pattern, int[] amplitudes, int repeat, bool cancel) -> void
---- Framework.Vibration::Vibrate 0x2d8820c
02d8820c: sub     sp, sp, #0x60                              
02d88210: str     x30, [sp, #0x20]                           
02d88214: stp     x24, x23, [sp, #0x30]                      
02d88218: stp     x22, x21, [sp, #0x40]                      
02d8821c: stp     x20, x19, [sp, #0x50]                      
02d88220: adrp    x23, #0x6630000                            
02d88224: adrp    x22, #0x6267000                            
02d88228: mov     w19, w2                                    
02d8822c: ldrb    w8, [x23, #0x49a]                          
02d88230: ldr     x22, [x22, #0xea8]                         T:Framework.Vibration
02d88234: mov     x20, x1                                    
02d88238: mov     x21, x0                                    
02d8823c: and     w24, w3, #1                                
02d88240: tbnz    w8, #0, #0x2d882ac                         
02d88244: adrp    x0, #0x6267000                             
02d88248: ldr     x0, [x0, #0xea8]                           T:Framework.Vibration
02d8824c: bl      #0x2b70db0                                 fn_2b70db0
02d88250: adrp    x0, #0x6268000                             
02d88254: ldr     x0, [x0, #0xd98]                           S:": Device doesn't have Amplitude Control, but Amplitudes was set"
02d88258: bl      #0x2b70db0                                 fn_2b70db0
02d8825c: adrp    x0, #0x6268000                             
02d88260: ldr     x0, [x0, #0xda0]                           S:': Effect with amplitudes called'
02d88264: bl      #0x2b70db0                                 fn_2b70db0
02d88268: adrp    x0, #0x6268000                             
02d8826c: ldr     x0, [x0, #0xda8]                           S:': Length of Amplitudes array is not equal to Pattern array. Amplitudes'
02d88270: bl      #0x2b70db0                                 fn_2b70db0
02d88274: adrp    x0, #0x6268000                             
02d88278: ldr     x0, [x0, #0xd48]                           S:": Device doesn't have Vibrator"
02d8827c: bl      #0x2b70db0                                 fn_2b70db0
02d88280: adrp    x0, #0x6268000                             
02d88284: ldr     x0, [x0, #0xd50]                           S:': Not initialized'
02d88288: bl      #0x2b70db0                                 fn_2b70db0
02d8828c: adrp    x0, #0x6268000                             
02d88290: ldr     x0, [x0, #0xd58]                           S:': Effect called'
02d88294: bl      #0x2b70db0                                 fn_2b70db0
02d88298: adrp    x0, #0x6268000                             
02d8829c: ldr     x0, [x0, #0xd60]                           S:': Legacy called'
02d882a0: bl      #0x2b70db0                                 fn_2b70db0
02d882a4: mov     w8, #1                                     
02d882a8: strb    w8, [x23, #0x49a]                          
02d882ac: add     x0, sp, #8                                 
02d882b0: mov     x1, x21                                    
02d882b4: stp     xzr, xzr, [sp, #0x10]                      
02d882b8: add     x23, sp, #8                                
02d882bc: str     x21, [sp, #8]                              
02d882c0: bl      #0x2b70d54                                 fn_2b70d54
02d882c4: add     x0, x23, #8                                &6630008
02d882c8: mov     x1, x20                                    
02d882cc: str     x20, [sp, #0x10]                           
02d882d0: bl      #0x2b70d54                                 fn_2b70d54
02d882d4: ldr     x0, [x22]                                  S:'didu'
02d882d8: str     w19, [sp, #0x18]                           
02d882dc: strb    w24, [sp, #0x1c]                           
02d882e0: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02d882e4: cbnz    w8, #0x2d882ec                             
02d882e8: bl      #0x2b70f30                                 fn_2b70f30
02d882ec: bl      #0x2d871a0                                 Framework.Vibration::Initialize
02d882f0: ldr     x0, [x22]                                  S:'didu'
02d882f4: ldr     x8, [x0, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02d882f8: ldrb    w9, [x8, #0x20]                            
02d882fc: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02d88300: cbz     w9, #0x2d8846c                             
02d88304: cbnz    w8, #0x2d8830c                             
02d88308: bl      #0x2b70f30                                 fn_2b70f30
02d8830c: bl      #0x2d87b4c                                 Framework.Vibration::HasVibrator
02d88310: tbz     w0, #0, #0x2d88484                         
02d88314: ldr     x19, [sp, #0x10]                           
02d88318: cbz     x19, #0x2d88398                            
02d8831c: ldr     x8, [sp, #8]                               
02d88320: cbz     x8, #0x2d88538                             
02d88324: ldr     w9, [x19, #0x18]                           .defaultAmplitude
02d88328: ldr     w8, [x8, #0x18]                            
02d8832c: cmp     w9, w8                                     
02d88330: b.eq    #0x2d88380                                 
02d88334: ldr     x0, [x22]                                  S:'didu'
02d88338: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02d8833c: cbnz    w8, #0x2d88344                             
02d88340: bl      #0x2b70f30                                 fn_2b70f30
02d88344: add     x0, sp, #8                                 
02d88348: bl      #0x2d8853c                                 Framework.Vibration::<Vibrate>g__funcToStr|11_0
02d8834c: adrp    x8, #0x6268000                             
02d88350: mov     x2, xzr                                    
02d88354: ldr     x8, [x8, #0xda8]                           S:': Length of Amplitudes array is not equal to Pattern array. Amplitudes'
02d88358: ldr     x1, [x8]                                   S:'{0}/2'
02d8835c: bl      #0x4c9c514                                 System.String::Concat
02d88360: mov     w1, #2                                     
02d88364: bl      #0x2d87980                                 Framework.Vibration::logAuto
02d88368: add     x0, x23, #8                                &6630008
02d8836c: mov     x1, xzr                                    
02d88370: str     xzr, [sp, #0x10]                           
02d88374: bl      #0x2b70d54                                 fn_2b70d54
02d88378: ldr     x19, [sp, #0x10]                           
02d8837c: cbz     x19, #0x2d88398                            
02d88380: ldr     x0, [x22]                                  S:'didu'
02d88384: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02d88388: cbnz    w8, #0x2d88390                             
02d8838c: bl      #0x2b70f30                                 fn_2b70f30
02d88390: mov     x0, x19                                    
02d88394: bl      #0x2d88718                                 Framework.Vibration::clampAmplitudesArray
02d88398: ldrb    w8, [sp, #0x1c]                            
02d8839c: tbz     w8, #0, #0x2d883b4                         
02d883a0: ldr     x0, [x22]                                  S:'didu'
02d883a4: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02d883a8: cbnz    w8, #0x2d883b0                             
02d883ac: bl      #0x2b70f30                                 fn_2b70f30
02d883b0: bl      #0x2d87c78                                 Framework.Vibration::Cancel
02d883b4: ldr     x0, [x22]                                  S:'didu'
02d883b8: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02d883bc: cbnz    w8, #0x2d883c4                             
02d883c0: bl      #0x2b70f30                                 fn_2b70f30
02d883c4: bl      #0x2d870e0                                 Framework.Vibration::doesSupportVibrationEffect
02d883c8: tbz     w0, #0, #0x2d884a4                         
02d883cc: ldr     x8, [sp, #0x10]                            
02d883d0: cbz     x8, #0x2d884d4                             
02d883d4: ldr     x0, [x22]                                  S:'didu'
02d883d8: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02d883dc: cbnz    w8, #0x2d883e4                             
02d883e0: bl      #0x2b70f30                                 fn_2b70f30
02d883e4: bl      #0x2d87da8                                 Framework.Vibration::HasAmplitudeControl
02d883e8: tbnz    w0, #0, #0x2d88430                         
02d883ec: ldr     x0, [x22]                                  S:'didu'
02d883f0: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02d883f4: cbnz    w8, #0x2d883fc                             
02d883f8: bl      #0x2b70f30                                 fn_2b70f30
02d883fc: add     x0, sp, #8                                 
02d88400: bl      #0x2d8853c                                 Framework.Vibration::<Vibrate>g__funcToStr|11_0
02d88404: adrp    x8, #0x6268000                             
02d88408: mov     x2, xzr                                    
02d8840c: ldr     x8, [x8, #0xd98]                           S:": Device doesn't have Amplitude Control, but Amplitudes was set"
02d88410: ldr     x1, [x8]                                   S:'{0}/2'
02d88414: bl      #0x4c9c514                                 System.String::Concat
02d88418: mov     w1, #2                                     
02d8841c: bl      #0x2d87980                                 Framework.Vibration::logAuto
02d88420: add     x0, x23, #8                                &6630008
02d88424: mov     x1, xzr                                    
02d88428: str     xzr, [sp, #0x10]                           
02d8842c: bl      #0x2b70d54                                 fn_2b70d54
02d88430: ldr     x19, [sp, #0x10]                           
02d88434: cbz     x19, #0x2d884d4                            
02d88438: ldr     x0, [x22]                                  S:'didu'
02d8843c: ldr     x21, [sp, #8]                              
02d88440: ldr     w20, [sp, #0x18]                           
02d88444: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02d88448: cbnz    w8, #0x2d88450                             
02d8844c: bl      #0x2b70f30                                 fn_2b70f30
02d88450: mov     x0, x21                                    
02d88454: mov     x1, x19                                    
02d88458: mov     w2, w20                                    
02d8845c: bl      #0x2d88774                                 Framework.Vibration::vibrateEffect
02d88460: adrp    x20, #0x6268000                            
02d88464: ldr     x20, [x20, #0xda0]                         S:': Effect with amplitudes called'
02d88468: b       #0x2d88500                                 
02d8846c: cbnz    w8, #0x2d88474                             
02d88470: bl      #0x2b70f30                                 fn_2b70f30
02d88474: adrp    x20, #0x6268000                            
02d88478: mov     w19, #2                                    
02d8847c: ldr     x20, [x20, #0xd50]                         S:': Not initialized'
02d88480: b       #0x2d88504                                 
02d88484: ldr     x0, [x22]                                  S:'didu'
02d88488: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02d8848c: cbnz    w8, #0x2d88494                             
02d88490: bl      #0x2b70f30                                 fn_2b70f30
02d88494: adrp    x20, #0x6268000                            
02d88498: mov     w19, #2                                    
02d8849c: ldr     x20, [x20, #0xd48]                         S:": Device doesn't have Vibrator"
02d884a0: b       #0x2d88504                                 
02d884a4: ldr     x0, [x22]                                  S:'didu'
02d884a8: ldr     x19, [sp, #8]                              
02d884ac: ldr     w20, [sp, #0x18]                           
02d884b0: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02d884b4: cbnz    w8, #0x2d884bc                             
02d884b8: bl      #0x2b70f30                                 fn_2b70f30
02d884bc: mov     x0, x19                                    
02d884c0: mov     w1, w20                                    
02d884c4: bl      #0x2d88b94                                 Framework.Vibration::vibrateLegacy
02d884c8: adrp    x20, #0x6268000                            
02d884cc: ldr     x20, [x20, #0xd60]                         S:': Legacy called'
02d884d0: b       #0x2d88500                                 
02d884d4: ldr     x0, [x22]                                  S:'didu'
02d884d8: ldr     x19, [sp, #8]                              
02d884dc: ldr     w20, [sp, #0x18]                           
02d884e0: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02d884e4: cbnz    w8, #0x2d884ec                             
02d884e8: bl      #0x2b70f30                                 fn_2b70f30
02d884ec: mov     x0, x19                                    
02d884f0: mov     w1, w20                                    
02d884f4: bl      #0x2d88988                                 Framework.Vibration::vibrateEffect
02d884f8: adrp    x20, #0x6268000                            
02d884fc: ldr     x20, [x20, #0xd58]                         S:': Effect called'
02d88500: mov     w19, #1                                    
02d88504: add     x0, sp, #8                                 
02d88508: bl      #0x2d8853c                                 Framework.Vibration::<Vibrate>g__funcToStr|11_0
02d8850c: ldr     x1, [x20]                                  S:'{0}/2'
02d88510: mov     x2, xzr                                    
02d88514: bl      #0x4c9c514                                 System.String::Concat
02d88518: mov     w1, w19                                    
02d8851c: bl      #0x2d87980                                 Framework.Vibration::logAuto
02d88520: ldp     x20, x19, [sp, #0x50]                      
02d88524: ldr     x30, [sp, #0x20]                           
02d88528: ldp     x22, x21, [sp, #0x40]                      
02d8852c: ldp     x24, x23, [sp, #0x30]                      
02d88530: add     sp, sp, #0x60                              
02d88534: ret                                                
02d88538: bl      #0x2b7105c                                 fn_2b7105c
## VibratePredefined(int effectId, bool cancel) -> void
---- Framework.Vibration::VibratePredefined 0x2d88ce4
02d88ce4: str     x30, [sp, #-0x30]!                         
02d88ce8: stp     x22, x21, [sp, #0x10]                      
02d88cec: stp     x20, x19, [sp, #0x20]                      
02d88cf0: adrp    x22, #0x6630000                            
02d88cf4: adrp    x21, #0x6267000                            
02d88cf8: mov     w20, w1                                    
02d88cfc: ldrb    w8, [x22, #0x49b]                          
02d88d00: ldr     x21, [x21, #0xea8]                         T:Framework.Vibration
02d88d04: mov     w19, w0                                    
02d88d08: tbnz    w8, #0, #0x2d88d50                         
02d88d0c: adrp    x0, #0x6267000                             
02d88d10: ldr     x0, [x0, #0xea8]                           T:Framework.Vibration
02d88d14: bl      #0x2b70db0                                 fn_2b70db0
02d88d18: adrp    x0, #0x6268000                             
02d88d1c: ldr     x0, [x0, #0xdb8]                           S:': Predefined effect called'
02d88d20: bl      #0x2b70db0                                 fn_2b70db0
02d88d24: adrp    x0, #0x6268000                             
02d88d28: ldr     x0, [x0, #0xd48]                           S:": Device doesn't have Vibrator"
02d88d2c: bl      #0x2b70db0                                 fn_2b70db0
02d88d30: adrp    x0, #0x6268000                             
02d88d34: ldr     x0, [x0, #0xd50]                           S:': Not initialized'
02d88d38: bl      #0x2b70db0                                 fn_2b70db0
02d88d3c: adrp    x0, #0x6268000                             
02d88d40: ldr     x0, [x0, #0xdc0]                           S:": Device doesn't support Predefined Effects (Api Level >= 29)"
02d88d44: bl      #0x2b70db0                                 fn_2b70db0
02d88d48: mov     w8, #1                                     
02d88d4c: strb    w8, [x22, #0x49b]                          
02d88d50: ldr     x0, [x21]                                  S:'didu'
02d88d54: str     w19, [sp, #0xc]                            
02d88d58: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02d88d5c: cbnz    w8, #0x2d88d64                             
02d88d60: bl      #0x2b70f30                                 fn_2b70f30
02d88d64: bl      #0x2d871a0                                 Framework.Vibration::Initialize
02d88d68: ldr     x0, [x21]                                  S:'didu'
02d88d6c: ldr     x8, [x0, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02d88d70: ldrb    w9, [x8, #0x20]                            
02d88d74: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02d88d78: cbz     w9, #0x2d88de8                             
02d88d7c: cbnz    w8, #0x2d88d84                             
02d88d80: bl      #0x2b70f30                                 fn_2b70f30
02d88d84: bl      #0x2d87b4c                                 Framework.Vibration::HasVibrator
02d88d88: mov     w8, w0                                     
02d88d8c: ldr     x0, [x21]                                  S:'didu'
02d88d90: ldr     w9, [x0, #0xe4]                            [62680e4]=0 f=0,0
02d88d94: tbz     w8, #0, #0x2d88e00                         
02d88d98: cbnz    w9, #0x2d88da0                             
02d88d9c: bl      #0x2b70f30                                 fn_2b70f30
02d88da0: bl      #0x2d87140                                 Framework.Vibration::doesSupportPredefinedEffect
02d88da4: tbz     w0, #0, #0x2d88e18                         
02d88da8: tbz     w20, #0, #0x2d88dc0                        
02d88dac: ldr     x0, [x21]                                  S:'didu'
02d88db0: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02d88db4: cbnz    w8, #0x2d88dbc                             
02d88db8: bl      #0x2b70f30                                 fn_2b70f30
02d88dbc: bl      #0x2d87c78                                 Framework.Vibration::Cancel
02d88dc0: ldr     x0, [x21]                                  S:'didu'
02d88dc4: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02d88dc8: cbnz    w8, #0x2d88dd0                             
02d88dcc: bl      #0x2b70f30                                 fn_2b70f30
02d88dd0: mov     w0, w19                                    
02d88dd4: bl      #0x2d88ed4                                 Framework.Vibration::vibrateEffectPredefined
02d88dd8: adrp    x20, #0x6268000                            
02d88ddc: mov     w19, #1                                    
02d88de0: ldr     x20, [x20, #0xdb8]                         S:': Predefined effect called'
02d88de4: b       #0x2d88e34                                 
02d88de8: cbnz    w8, #0x2d88df0                             
02d88dec: bl      #0x2b70f30                                 fn_2b70f30
02d88df0: adrp    x20, #0x6268000                            
02d88df4: mov     w19, #2                                    
02d88df8: ldr     x20, [x20, #0xd50]                         S:': Not initialized'
02d88dfc: b       #0x2d88e34                                 
02d88e00: cbnz    w9, #0x2d88e08                             
02d88e04: bl      #0x2b70f30                                 fn_2b70f30
02d88e08: adrp    x20, #0x6268000                            
02d88e0c: mov     w19, #2                                    
02d88e10: ldr     x20, [x20, #0xd48]                         S:": Device doesn't have Vibrator"
02d88e14: b       #0x2d88e34                                 
02d88e18: ldr     x0, [x21]                                  S:'didu'
02d88e1c: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02d88e20: cbnz    w8, #0x2d88e28                             
02d88e24: bl      #0x2b70f30                                 fn_2b70f30
02d88e28: adrp    x20, #0x6268000                            
02d88e2c: mov     w19, #2                                    
02d88e30: ldr     x20, [x20, #0xdc0]                         S:": Device doesn't support Predefined Effects (Api Level >= 29)"
02d88e34: add     x0, sp, #0xc                               
02d88e38: bl      #0x2d88e5c                                 Framework.Vibration::<VibratePredefined>g__funcToStr|12_0
02d88e3c: ldr     x1, [x20]                                  S:'{0}/2'
02d88e40: mov     x2, xzr                                    
02d88e44: bl      #0x4c9c514                                 System.String::Concat
02d88e48: mov     w1, w19                                    
02d88e4c: ldp     x20, x19, [sp, #0x20]                      
02d88e50: ldp     x22, x21, [sp, #0x10]                      
02d88e54: ldr     x30, [sp], #0x30                           
02d88e58: b       #0x2d87980                                 Framework.Vibration::logAuto
## ParsePattern(string pattern) -> long[]
---- Framework.Vibration::ParsePattern 0x2d890d0
02d890d0: str     x30, [sp, #-0x30]!                         
02d890d4: stp     x22, x21, [sp, #0x10]                      
02d890d8: stp     x20, x19, [sp, #0x20]                      
02d890dc: adrp    x20, #0x6630000                            
02d890e0: mov     x19, x0                                    
02d890e4: ldrb    w8, [x20, #0x49c]                          
02d890e8: tbnz    w8, #0, #0x2d89100                         
02d890ec: adrp    x0, #0x6268000                             
02d890f0: ldr     x0, [x0, #0xdd0]                           T:type24405(k1d)
02d890f4: bl      #0x2b70db0                                 fn_2b70db0
02d890f8: mov     w8, #1                                     
02d890fc: strb    w8, [x20, #0x49c]                          
02d89100: adrp    x20, #0x6268000                            
02d89104: ldr     x20, [x20, #0xdd0]                         T:type24405(k1d)
02d89108: str     wzr, [sp, #0xc]                            
02d8910c: cbz     x19, #0x2d891e0                            
02d89110: mov     x0, x19                                    
02d89114: mov     x1, xzr                                    
02d89118: bl      #0x4cab1c4                                 System.String::Trim
02d8911c: cbz     x0, #0x2d891f8                             
02d89120: mov     w1, #0x2c                                  
02d89124: mov     w2, wzr                                    
02d89128: mov     x3, xzr                                    
02d8912c: bl      #0x4ca92f8                                 System.String::Split
02d89130: cbz     x0, #0x2d891f8                             
02d89134: mov     x19, x0                                    
02d89138: ldr     x0, [x20]                                  S:'{0}/2'
02d8913c: ldr     w1, [x19, #0x18]                           .defaultAmplitude
02d89140: bl      #0x2b70ea0                                 fn_2b70ea0
02d89144: ldr     w8, [x19, #0x18]                           .defaultAmplitude
02d89148: mov     x20, x0                                    
02d8914c: cmp     w8, #1                                     
02d89150: b.lt    #0x2d891cc                                 
02d89154: mov     w21, #4                                    
02d89158: sub     x22, x21, #4                               
02d8915c: cmp     w22, w8                                    
02d89160: b.hs    #0x2d891fc                                 
02d89164: ldr     x0, [x19, x21, lsl #3]                     
02d89168: cbz     x0, #0x2d891f8                             
02d8916c: mov     x1, xzr                                    
02d89170: bl      #0x4cab1c4                                 System.String::Trim
02d89174: add     x1, sp, #0xc                               
02d89178: mov     x2, xzr                                    
02d8917c: bl      #0x4e0f150                                 System.Int32::TryParse
02d89180: tbz     w0, #0, #0x2d891a0                         
02d89184: cbz     x20, #0x2d891f8                            
02d89188: ldr     w8, [x20, #0x18]                           M:LuckyWheelPopup/<>c__DisplayClass50_0::<RunAnimation>b__0 .defaultAmplitude
02d8918c: cmp     w22, w8                                    
02d89190: b.hs    #0x2d891fc                                 
02d89194: ldr     w8, [sp, #0xc]                             
02d89198: bic     w8, w8, w8, asr #31                        
02d8919c: b       #0x2d891b4                                 
02d891a0: cbz     x20, #0x2d891f8                            
02d891a4: ldr     w8, [x20, #0x18]                           M:LuckyWheelPopup/<>c__DisplayClass50_0::<RunAnimation>b__0 .defaultAmplitude
02d891a8: cmp     w22, w8                                    
02d891ac: b.hs    #0x2d891fc                                 
02d891b0: mov     x8, xzr                                    
02d891b4: str     x8, [x20, x21, lsl #3]                     
02d891b8: add     x21, x21, #1                               
02d891bc: ldr     w8, [x19, #0x18]                           .defaultAmplitude
02d891c0: sub     w9, w21, #4                                
02d891c4: cmp     w9, w8                                     
02d891c8: b.lt    #0x2d89158                                 
02d891cc: mov     x0, x20                                    
02d891d0: ldp     x20, x19, [sp, #0x20]                      
02d891d4: ldp     x22, x21, [sp, #0x10]                      
02d891d8: ldr     x30, [sp], #0x30                           
02d891dc: ret                                                
02d891e0: ldr     x0, [x20]                                  S:'{0}/2'
02d891e4: ldp     x20, x19, [sp, #0x20]                      
02d891e8: ldp     x22, x21, [sp, #0x10]                      
02d891ec: mov     w1, wzr                                    
02d891f0: ldr     x30, [sp], #0x30                           
02d891f4: b       #0x2b70ea0                                 
02d891f8: bl      #0x2b7105c                                 fn_2b7105c
02d891fc: bl      #0x2b71064                                 fn_2b71064
## GetApiLevel() -> int
---- Framework.Vibration::GetApiLevel 0x2d89200
02d89200: str     x30, [sp, #-0x20]!                         
02d89204: stp     x20, x19, [sp, #0x10]                      
02d89208: adrp    x20, #0x6630000                            
02d8920c: adrp    x19, #0x6267000                            
02d89210: ldrb    w8, [x20, #0x49d]                          
02d89214: ldr     x19, [x19, #0xea8]                         T:Framework.Vibration
02d89218: tbnz    w8, #0, #0x2d89230                         
02d8921c: adrp    x0, #0x6267000                             
02d89220: ldr     x0, [x0, #0xea8]                           T:Framework.Vibration
02d89224: bl      #0x2b70db0                                 fn_2b70db0
02d89228: mov     w8, #1                                     
02d8922c: strb    w8, [x20, #0x49d]                          
02d89230: ldr     x0, [x19]                                  S:'didu'
02d89234: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02d89238: cbnz    w8, #0x2d89244                             
02d8923c: bl      #0x2b70f30                                 fn_2b70f30
02d89240: ldr     x0, [x19]                                  S:'didu'
02d89244: ldr     x8, [x0, #0xb8]                            M:Framework.SceneUtils/<CRUnloadSceneAsync>d__2::System.Collections.IEnumerator.Reset
02d89248: ldp     x20, x19, [sp, #0x10]                      
02d8924c: ldr     w0, [x8, #0x1c]                            
02d89250: ldr     x30, [sp], #0x20                           
02d89254: ret                                                
## GetDefaultAmplitude() -> int
---- Framework.Vibration::GetDefaultAmplitude 0x2d89258
02d89258: str     x30, [sp, #-0x20]!                         
02d8925c: stp     x20, x19, [sp, #0x10]                      
02d89260: adrp    x20, #0x6630000                            
02d89264: adrp    x19, #0x6267000                            
02d89268: ldrb    w8, [x20, #0x49e]                          
02d8926c: ldr     x19, [x19, #0xea8]                         T:Framework.Vibration
02d89270: tbnz    w8, #0, #0x2d89288                         
02d89274: adrp    x0, #0x6267000                             
02d89278: ldr     x0, [x0, #0xea8]                           T:Framework.Vibration
02d8927c: bl      #0x2b70db0                                 fn_2b70db0
02d89280: mov     w8, #1                                     
02d89284: strb    w8, [x20, #0x49e]                          
02d89288: ldr     x0, [x19]                                  S:'didu'
02d8928c: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02d89290: cbnz    w8, #0x2d8929c                             
02d89294: bl      #0x2b70f30                                 fn_2b70f30
02d89298: ldr     x0, [x19]                                  S:'didu'
02d8929c: ldr     x8, [x0, #0xb8]                            M:Framework.SceneUtils/<CRUnloadSceneAsync>d__2::System.Collections.IEnumerator.Reset
02d892a0: ldp     x20, x19, [sp, #0x10]                      
02d892a4: ldr     w0, [x8, #0x18]                            
02d892a8: ldr     x30, [sp], #0x20                           
02d892ac: ret                                                
## HasVibrator() -> bool
---- Framework.Vibration::HasVibrator 0x2d87b4c
02d87b4c: stp     x30, x21, [sp, #-0x20]!                    
02d87b50: stp     x20, x19, [sp, #0x10]                      
02d87b54: adrp    x19, #0x6630000                            
02d87b58: adrp    x20, #0x6267000                            
02d87b5c: ldrb    w8, [x19, #0x49f]                          
02d87b60: ldr     x20, [x20, #0xea8]                         T:Framework.Vibration
02d87b64: tbnz    w8, #0, #0x2d87ba0                         
02d87b68: adrp    x0, #0x6265000                             
02d87b6c: ldr     x0, [x0, #0x760]                           MS:UnityEngine.AndroidJavaObject::Call
02d87b70: bl      #0x2b70db0                                 fn_2b70db0
02d87b74: adrp    x0, #0x6263000                             
02d87b78: ldr     x0, [x0, #0xb70]                           MS:System.Array::Empty
02d87b7c: bl      #0x2b70db0                                 fn_2b70db0
02d87b80: adrp    x0, #0x6267000                             
02d87b84: ldr     x0, [x0, #0xea8]                           T:Framework.Vibration
02d87b88: bl      #0x2b70db0                                 fn_2b70db0
02d87b8c: adrp    x0, #0x6268000                             
02d87b90: ldr     x0, [x0, #0xd70]                           S:'hasVibrator'
02d87b94: bl      #0x2b70db0                                 fn_2b70db0
02d87b98: mov     w8, #1                                     
02d87b9c: strb    w8, [x19, #0x49f]                          
02d87ba0: ldr     x0, [x20]                                  S:'didu'
02d87ba4: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02d87ba8: cbnz    w8, #0x2d87bb4                             
02d87bac: bl      #0x2b70f30                                 fn_2b70f30
02d87bb0: ldr     x0, [x20]                                  S:'didu'
02d87bb4: ldr     x8, [x0, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02d87bb8: ldr     x19, [x8, #8]                              
02d87bbc: cbz     x19, #0x2d87c64                            
02d87bc0: adrp    x21, #0x6263000                            
02d87bc4: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02d87bc8: ldr     x21, [x21, #0xb70]                         MS:System.Array::Empty
02d87bcc: cbnz    w8, #0x2d87be0                             
02d87bd0: bl      #0x2b70f30                                 fn_2b70f30
02d87bd4: ldr     x8, [x20]                                  S:'didu'
02d87bd8: ldr     x8, [x8, #0xb8]                            
02d87bdc: ldr     x19, [x8, #8]                              
02d87be0: ldr     x20, [x21]                                 &2c5bbd4(=a9bd7bfdd503233f)
02d87be4: ldr     x8, [x20, #0x38]                           MS:System.Nullable`1::get_Value
02d87be8: cbnz    x8, #0x2d87bf8                             
02d87bec: mov     x0, x20                                    
02d87bf0: bl      #0x2ba9d7c                                 fn_2ba9d7c
02d87bf4: ldr     x8, [x20, #0x38]                           MS:System.Nullable`1::get_Value
02d87bf8: ldr     x0, [x8, #0x10]                            
02d87bfc: add     x8, x0, #0x135                             &6268135
02d87c00: ldrh    w8, [x8]                                   
02d87c04: tbnz    w8, #0, #0x2d87c0c                         
02d87c08: bl      #0x2ba9d20                                 fn_2ba9d20
02d87c0c: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02d87c10: cbnz    w8, #0x2d87c18                             
02d87c14: bl      #0x2b70f30                                 fn_2b70f30
02d87c18: ldr     x8, [x20, #0x38]                           MS:System.Nullable`1::get_Value
02d87c1c: ldr     x0, [x8, #0x10]                            
02d87c20: add     x8, x0, #0x135                             &6268135
02d87c24: ldrh    w8, [x8]                                   
02d87c28: tbnz    w8, #0, #0x2d87c30                         
02d87c2c: bl      #0x2ba9d20                                 fn_2ba9d20
02d87c30: cbz     x19, #0x2d87c74                            
02d87c34: adrp    x8, #0x6268000                             
02d87c38: adrp    x9, #0x6265000                             
02d87c3c: ldr     x8, [x8, #0xd70]                           S:'hasVibrator'
02d87c40: ldr     x9, [x9, #0x760]                           MS:UnityEngine.AndroidJavaObject::Call
02d87c44: ldr     x10, [x0, #0xb8]                           T:LuckyWheelPopup/<>c__DisplayClass54_0
02d87c48: mov     x0, x19                                    
02d87c4c: ldp     x20, x19, [sp, #0x10]                      
02d87c50: ldr     x2, [x10]                                  
02d87c54: ldr     x1, [x8]                                   S:'{0}/2'
02d87c58: ldr     x3, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02d87c5c: ldp     x30, x21, [sp], #0x20                      
02d87c60: b       #0x311f6d4                                 
02d87c64: ldp     x20, x19, [sp, #0x10]                      
02d87c68: mov     w0, wzr                                    
02d87c6c: ldp     x30, x21, [sp], #0x20                      
02d87c70: ret                                                
02d87c74: bl      #0x2b7105c                                 fn_2b7105c
## HasAmplitudeControl() -> bool
---- Framework.Vibration::HasAmplitudeControl 0x2d87da8
02d87da8: str     x30, [sp, #-0x20]!                         
02d87dac: stp     x20, x19, [sp, #0x10]                      
02d87db0: adrp    x20, #0x6630000                            
02d87db4: adrp    x19, #0x6267000                            
02d87db8: ldrb    w8, [x20, #0x4a0]                          
02d87dbc: ldr     x19, [x19, #0xea8]                         T:Framework.Vibration
02d87dc0: tbnz    w8, #0, #0x2d87dfc                         
02d87dc4: adrp    x0, #0x6265000                             
02d87dc8: ldr     x0, [x0, #0x760]                           MS:UnityEngine.AndroidJavaObject::Call
02d87dcc: bl      #0x2b70db0                                 fn_2b70db0
02d87dd0: adrp    x0, #0x6263000                             
02d87dd4: ldr     x0, [x0, #0xb70]                           MS:System.Array::Empty
02d87dd8: bl      #0x2b70db0                                 fn_2b70db0
02d87ddc: adrp    x0, #0x6267000                             
02d87de0: ldr     x0, [x0, #0xea8]                           T:Framework.Vibration
02d87de4: bl      #0x2b70db0                                 fn_2b70db0
02d87de8: adrp    x0, #0x6268000                             
02d87dec: ldr     x0, [x0, #0xd88]                           S:'hasAmplitudeControl'
02d87df0: bl      #0x2b70db0                                 fn_2b70db0
02d87df4: mov     w8, #1                                     
02d87df8: strb    w8, [x20, #0x4a0]                          
02d87dfc: ldr     x0, [x19]                                  S:'didu'
02d87e00: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02d87e04: cbnz    w8, #0x2d87e0c                             
02d87e08: bl      #0x2b70f30                                 fn_2b70f30
02d87e0c: bl      #0x2d87b4c                                 Framework.Vibration::HasVibrator
02d87e10: tbz     w0, #0, #0x2d87ed4                         
02d87e14: ldr     x0, [x19]                                  S:'didu'
02d87e18: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02d87e1c: cbnz    w8, #0x2d87e24                             
02d87e20: bl      #0x2b70f30                                 fn_2b70f30
02d87e24: bl      #0x2d870e0                                 Framework.Vibration::doesSupportVibrationEffect
02d87e28: tbz     w0, #0, #0x2d87ed4                         
02d87e2c: ldr     x0, [x19]                                  S:'didu'
02d87e30: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02d87e34: cbnz    w8, #0x2d87e40                             
02d87e38: bl      #0x2b70f30                                 fn_2b70f30
02d87e3c: ldr     x0, [x19]                                  S:'didu'
02d87e40: adrp    x8, #0x6263000                             
02d87e44: ldr     x8, [x8, #0xb70]                           MS:System.Array::Empty
02d87e48: ldr     x9, [x0, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02d87e4c: ldr     x20, [x8]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d87e50: ldr     x19, [x9, #8]                              
02d87e54: ldr     x8, [x20, #0x38]                           
02d87e58: cbnz    x8, #0x2d87e68                             
02d87e5c: mov     x0, x20                                    
02d87e60: bl      #0x2ba9d7c                                 fn_2ba9d7c
02d87e64: ldr     x8, [x20, #0x38]                           
02d87e68: ldr     x0, [x8, #0x10]                            &2c498bc(=aa1f03e0d503245f)
02d87e6c: add     x8, x0, #0x135                             &6268135
02d87e70: ldrh    w8, [x8]                                   
02d87e74: tbnz    w8, #0, #0x2d87e7c                         
02d87e78: bl      #0x2ba9d20                                 fn_2ba9d20
02d87e7c: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02d87e80: cbnz    w8, #0x2d87e88                             
02d87e84: bl      #0x2b70f30                                 fn_2b70f30
02d87e88: ldr     x8, [x20, #0x38]                           
02d87e8c: ldr     x0, [x8, #0x10]                            &2c498bc(=aa1f03e0d503245f)
02d87e90: add     x8, x0, #0x135                             &6268135
02d87e94: ldrh    w8, [x8]                                   
02d87e98: tbnz    w8, #0, #0x2d87ea0                         
02d87e9c: bl      #0x2ba9d20                                 fn_2ba9d20
02d87ea0: cbz     x19, #0x2d87ee4                            
02d87ea4: adrp    x8, #0x6268000                             
02d87ea8: adrp    x10, #0x6265000                            
02d87eac: ldr     x8, [x8, #0xd88]                           S:'hasAmplitudeControl'
02d87eb0: ldr     x9, [x0, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02d87eb4: ldr     x10, [x10, #0x760]                         MS:UnityEngine.AndroidJavaObject::Call
02d87eb8: mov     x0, x19                                    
02d87ebc: ldp     x20, x19, [sp, #0x10]                      
02d87ec0: ldr     x2, [x9]                                   
02d87ec4: ldr     x1, [x8]                                   S:'{0}/2'
02d87ec8: ldr     x3, [x10]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d87ecc: ldr     x30, [sp], #0x20                           
02d87ed0: b       #0x311f6d4                                 
02d87ed4: ldp     x20, x19, [sp, #0x10]                      
02d87ed8: mov     w0, wzr                                    
02d87edc: ldr     x30, [sp], #0x20                           
02d87ee0: ret                                                
02d87ee4: bl      #0x2b7105c                                 fn_2b7105c
## Cancel() -> void
---- Framework.Vibration::Cancel 0x2d87c78
02d87c78: str     x30, [sp, #-0x20]!                         
02d87c7c: stp     x20, x19, [sp, #0x10]                      
02d87c80: adrp    x20, #0x6630000                            
02d87c84: adrp    x19, #0x6267000                            
02d87c88: ldrb    w8, [x20, #0x4a1]                          
02d87c8c: ldr     x19, [x19, #0xea8]                         T:Framework.Vibration
02d87c90: tbnz    w8, #0, #0x2d87ccc                         
02d87c94: adrp    x0, #0x6263000                             
02d87c98: ldr     x0, [x0, #0xb70]                           MS:System.Array::Empty
02d87c9c: bl      #0x2b70db0                                 fn_2b70db0
02d87ca0: adrp    x0, #0x6267000                             
02d87ca4: ldr     x0, [x0, #0xea8]                           T:Framework.Vibration
02d87ca8: bl      #0x2b70db0                                 fn_2b70db0
02d87cac: adrp    x0, #0x6268000                             
02d87cb0: ldr     x0, [x0, #0xd78]                           S:'cancel'
02d87cb4: bl      #0x2b70db0                                 fn_2b70db0
02d87cb8: adrp    x0, #0x6268000                             
02d87cbc: ldr     x0, [x0, #0xd80]                           S:'Cancel (): Called'
02d87cc0: bl      #0x2b70db0                                 fn_2b70db0
02d87cc4: mov     w8, #1                                     
02d87cc8: strb    w8, [x20, #0x4a1]                          
02d87ccc: ldr     x0, [x19]                                  S:'didu'
02d87cd0: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02d87cd4: cbnz    w8, #0x2d87cdc                             
02d87cd8: bl      #0x2b70f30                                 fn_2b70f30
02d87cdc: bl      #0x2d87b4c                                 Framework.Vibration::HasVibrator
02d87ce0: tbz     w0, #0, #0x2d87d98                         
02d87ce4: ldr     x0, [x19]                                  S:'didu'
02d87ce8: adrp    x20, #0x6263000                            
02d87cec: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02d87cf0: ldr     x20, [x20, #0xb70]                         MS:System.Array::Empty
02d87cf4: cbnz    w8, #0x2d87d00                             
02d87cf8: bl      #0x2b70f30                                 fn_2b70f30
02d87cfc: ldr     x0, [x19]                                  S:'didu'
02d87d00: ldr     x20, [x20]                                 &2c5bbd4(=a9bd7bfdd503233f)
02d87d04: ldr     x9, [x0, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02d87d08: ldr     x8, [x20, #0x38]                           &6260bd8(=0)
02d87d0c: ldr     x19, [x9, #8]                              
02d87d10: cbnz    x8, #0x2d87d20                             
02d87d14: mov     x0, x20                                    
02d87d18: bl      #0x2ba9d7c                                 fn_2ba9d7c
02d87d1c: ldr     x8, [x20, #0x38]                           &6260bd8(=0)
02d87d20: ldr     x0, [x8, #0x10]                            
02d87d24: add     x8, x0, #0x135                             &6268135
02d87d28: ldrh    w8, [x8]                                   
02d87d2c: tbnz    w8, #0, #0x2d87d34                         
02d87d30: bl      #0x2ba9d20                                 fn_2ba9d20
02d87d34: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02d87d38: cbnz    w8, #0x2d87d40                             
02d87d3c: bl      #0x2b70f30                                 fn_2b70f30
02d87d40: ldr     x8, [x20, #0x38]                           &6260bd8(=0)
02d87d44: ldr     x0, [x8, #0x10]                            
02d87d48: add     x8, x0, #0x135                             &6268135
02d87d4c: ldrh    w8, [x8]                                   
02d87d50: tbnz    w8, #0, #0x2d87d58                         
02d87d54: bl      #0x2ba9d20                                 fn_2ba9d20
02d87d58: cbz     x19, #0x2d87da4                            
02d87d5c: adrp    x9, #0x6268000                             
02d87d60: ldr     x8, [x0, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02d87d64: mov     x0, x19                                    
02d87d68: ldr     x9, [x9, #0xd78]                           S:'cancel'
02d87d6c: mov     x3, xzr                                    
02d87d70: ldr     x2, [x8]                                   
02d87d74: ldr     x1, [x9]                                   S:'{0}/2'
02d87d78: bl      #0x5ad5e34                                 UnityEngine.AndroidJavaObject::Call
02d87d7c: adrp    x8, #0x6268000                             
02d87d80: mov     w1, #1                                     
02d87d84: ldr     x8, [x8, #0xd80]                           S:'Cancel (): Called'
02d87d88: ldp     x20, x19, [sp, #0x10]                      
02d87d8c: ldr     x0, [x8]                                   S:'{0}/2'
02d87d90: ldr     x30, [sp], #0x20                           
02d87d94: b       #0x2d87980                                 Framework.Vibration::logAuto
02d87d98: ldp     x20, x19, [sp, #0x10]                      
02d87d9c: ldr     x30, [sp], #0x20                           
02d87da0: ret                                                
02d87da4: bl      #0x2b7105c                                 fn_2b7105c
## vibrateEffect(long milliseconds, int amplitude) -> void
---- Framework.Vibration::vibrateEffect 0x2d87ee8
02d87ee8: sub     sp, sp, #0x40                              
02d87eec: str     x30, [sp, #0x10]                           
02d87ef0: stp     x22, x21, [sp, #0x20]                      
02d87ef4: stp     x20, x19, [sp, #0x30]                      
02d87ef8: adrp    x22, #0x6630000                            
02d87efc: adrp    x21, #0x6267000                            
02d87f00: mov     w19, w1                                    
02d87f04: ldrb    w8, [x22, #0x4a2]                          
02d87f08: ldr     x21, [x21, #0xea8]                         T:Framework.Vibration
02d87f0c: mov     x20, x0                                    
02d87f10: tbnz    w8, #0, #0x2d87f4c                         
02d87f14: adrp    x0, #0x6263000                             
02d87f18: ldr     x0, [x0, #0x980]                           T:System.IDisposable
02d87f1c: bl      #0x2b70db0                                 fn_2b70db0
02d87f20: adrp    x0, #0x6263000                             
02d87f24: ldr     x0, [x0, #0xa80]                           T:type24502(k1d)
02d87f28: bl      #0x2b70db0                                 fn_2b70db0
02d87f2c: adrp    x0, #0x6267000                             
02d87f30: ldr     x0, [x0, #0xea8]                           T:Framework.Vibration
02d87f34: bl      #0x2b70db0                                 fn_2b70db0
02d87f38: adrp    x0, #0x6268000                             
02d87f3c: ldr     x0, [x0, #0xd90]                           S:'vibrate'
02d87f40: bl      #0x2b70db0                                 fn_2b70db0
02d87f44: mov     w8, #1                                     
02d87f48: strb    w8, [x22, #0x4a2]                          
02d87f4c: ldr     x0, [x21]                                  S:'didu'
02d87f50: str     xzr, [sp, #0x18]                           
02d87f54: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02d87f58: cbnz    w8, #0x2d87f60                             
02d87f5c: bl      #0x2b70f30                                 fn_2b70f30
02d87f60: mov     x0, x20                                    
02d87f64: mov     w1, w19                                    
02d87f68: bl      #0x2d892b0                                 Framework.Vibration::createEffect_OneShot
02d87f6c: mov     x8, x0                                     
02d87f70: ldr     x0, [x21]                                  S:'didu'
02d87f74: add     x9, sp, #0x18                              
02d87f78: str     x8, [sp, #0x18]                            
02d87f7c: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02d87f80: stp     xzr, x9, [sp]                              
02d87f84: cbnz    w8, #0x2d87f90                             
02d87f88: bl      #0x2b70f30                                 fn_2b70f30
02d87f8c: ldr     x0, [x21]                                  S:'didu'
02d87f90: adrp    x8, #0x6263000                             
02d87f94: ldr     x8, [x8, #0xa80]                           T:type24502(k1d)
02d87f98: ldr     x9, [x0, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02d87f9c: ldr     x19, [x9, #8]                              
02d87fa0: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02d87fa4: mov     w1, #1                                     
02d87fa8: bl      #0x2b70ea0                                 fn_2b70ea0
02d87fac: mov     x20, x0                                    
02d87fb0: cbz     x0, #0x2d88090                             
02d87fb4: ldr     x21, [sp, #0x18]                           
02d87fb8: cbz     x21, #0x2d87fd0                            
02d87fbc: ldr     x8, [x20]                                  
02d87fc0: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02d87fc4: mov     x0, x21                                    
02d87fc8: bl      #0x2b70f34                                 fn_2b70f34
02d87fcc: cbz     x0, #0x2d880a0                             
02d87fd0: ldr     w8, [x20, #0x18]                           .defaultAmplitude
02d87fd4: cbz     w8, #0x2d8809c                             
02d87fd8: mov     x0, x20                                    
02d87fdc: str     x21, [x0, #0x20]!                          .isInitialized
02d87fe0: mov     x1, x21                                    
02d87fe4: bl      #0x2b70d54                                 fn_2b70d54
02d87fe8: cbz     x19, #0x2d88090                            
02d87fec: adrp    x8, #0x6268000                             
02d87ff0: ldr     x8, [x8, #0xd90]                           S:'vibrate'
02d87ff4: ldr     x1, [x8]                                   S:'{0}/2'
02d87ff8: mov     x0, x19                                    
02d87ffc: mov     x2, x20                                    
02d88000: mov     x3, xzr                                    
02d88004: bl      #0x5ad5e34                                 UnityEngine.AndroidJavaObject::Call
02d88008: mov     x19, xzr                                   
02d8800c: add     x8, sp, #0x18                              
02d88010: ldr     x20, [x8]                                  S:'{0}/2'
02d88014: cbz     x20, #0x2d88078                            
02d88018: adrp    x10, #0x6263000                            
02d8801c: ldr     x8, [x20]                                  
02d88020: ldr     x10, [x10, #0x980]                         T:System.IDisposable
02d88024: ldrh    w9, [x8, #0x12e]                           
02d88028: ldr     x1, [x10]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d8802c: cbz     x9, #0x2d88050                             
02d88030: ldr     x10, [x8, #0xb0]                           S:'penguin_close_mouth'
02d88034: add     x10, x10, #8                               &6263008
02d88038: ldur    x11, [x10, #-8]                            
02d8803c: cmp     x11, x1                                    
02d88040: b.eq    #0x2d88060                                 
02d88044: subs    x9, x9, #1                                 
02d88048: add     x10, x10, #0x10                            &6263010
02d8804c: b.ne    #0x2d88038                                 
02d88050: mov     x0, x20                                    
02d88054: mov     w2, wzr                                    
02d88058: bl      #0x2baa05c                                 fn_2baa05c
02d8805c: b       #0x2d8806c                                 
02d88060: ldrsw   x9, [x10]                                  
02d88064: add     x8, x8, x9, lsl #4                         &6268000
02d88068: add     x0, x8, #0x138                             &6268138
02d8806c: ldp     x8, x1, [x0]                               
02d88070: mov     x0, x20                                    
02d88074: blr     x8                                         
02d88078: cbnz    x19, #0x2d88094                            
02d8807c: ldp     x20, x19, [sp, #0x30]                      
02d88080: ldr     x30, [sp, #0x10]                           
02d88084: ldp     x22, x21, [sp, #0x20]                      
02d88088: add     sp, sp, #0x40                              
02d8808c: ret                                                
02d88090: bl      #0x2b7105c                                 fn_2b7105c
02d88094: mov     x0, x19                                    
02d88098: bl      #0x2b71054                                 fn_2b71054
02d8809c: bl      #0x2b71064                                 fn_2b71064
02d880a0: bl      #0x2b71080                                 fn_2b71080
02d880a4: mov     x1, xzr                                    
02d880a8: bl      #0x2b70f20                                 fn_2b70f20
02d880ac: b       #0x2d880b4                                 
02d880b0: b       #0x2d880b4                                 
02d880b4: mov     x19, x0                                    
02d880b8: cmp     w1, #1                                     
02d880bc: b.ne    #0x2d880e0                                 
02d880c0: mov     x0, x19                                    
02d880c4: bl      #0x5e90260                                 fn_5e90260
02d880c8: ldr     x19, [x0]                                  S:'{0}/2'
02d880cc: str     x19, [sp]                                  
02d880d0: bl      #0x5e90270                                 fn_5e90270
02d880d4: ldr     x8, [sp, #8]                               
02d880d8: b       #0x2d88010                                 
02d880dc: mov     x19, x0                                    
02d880e0: mov     x0, sp                                     
02d880e4: bl      #0x27369c4                                 fn_27369c4
02d880e8: mov     x0, x19                                    
02d880ec: bl      #0x2c6051c                                 fn_2c6051c
02d880f0: bl      #0x27369b8                                 fn_27369b8
## vibrateLegacy(long milliseconds) -> void
---- Framework.Vibration::vibrateLegacy 0x2d880f4
02d880f4: sub     sp, sp, #0x30                              
02d880f8: stp     x30, x21, [sp, #0x10]                      
02d880fc: stp     x20, x19, [sp, #0x20]                      
02d88100: adrp    x21, #0x6630000                            
02d88104: adrp    x19, #0x6267000                            
02d88108: mov     x20, x0                                    
02d8810c: ldrb    w8, [x21, #0x4a3]                          
02d88110: ldr     x19, [x19, #0xea8]                         T:Framework.Vibration
02d88114: tbnz    w8, #0, #0x2d88144                         
02d88118: adrp    x0, #0x6263000                             
02d8811c: ldr     x0, [x0, #0xa80]                           T:type24502(k1d)
02d88120: bl      #0x2b70db0                                 fn_2b70db0
02d88124: adrp    x0, #0x6267000                             
02d88128: ldr     x0, [x0, #0xea8]                           T:Framework.Vibration
02d8812c: bl      #0x2b70db0                                 fn_2b70db0
02d88130: adrp    x0, #0x6268000                             
02d88134: ldr     x0, [x0, #0xd90]                           S:'vibrate'
02d88138: bl      #0x2b70db0                                 fn_2b70db0
02d8813c: mov     w8, #1                                     
02d88140: strb    w8, [x21, #0x4a3]                          
02d88144: ldr     x0, [x19]                                  S:'didu'
02d88148: adrp    x21, #0x6263000                            
02d8814c: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02d88150: ldr     x21, [x21, #0xa80]                         T:type24502(k1d)
02d88154: cbnz    w8, #0x2d88160                             
02d88158: bl      #0x2b70f30                                 fn_2b70f30
02d8815c: ldr     x0, [x19]                                  S:'didu'
02d88160: ldr     x8, [x0, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02d88164: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d88168: mov     w1, #1                                     
02d8816c: ldr     x19, [x8, #8]                              
02d88170: bl      #0x2b70ea0                                 fn_2b70ea0
02d88174: adrp    x8, #0x6263000                             
02d88178: mov     x21, x0                                    
02d8817c: add     x1, sp, #8                                 
02d88180: ldr     x8, [x8, #0x970]                           &6645c70(=0)
02d88184: str     x20, [sp, #8]                              
02d88188: ldr     x0, [x8, #0x68]                            &2c497cc(=d65f03c0d503245f)
02d8818c: bl      #0x2b70f38                                 fn_2b70f38
02d88190: cbz     x21, #0x2d881f8                            
02d88194: mov     x20, x0                                    
02d88198: cbz     x0, #0x2d881b0                             
02d8819c: ldr     x8, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d881a0: mov     x0, x20                                    
02d881a4: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02d881a8: bl      #0x2b70f34                                 fn_2b70f34
02d881ac: cbz     x0, #0x2d88200                             
02d881b0: ldr     w8, [x21, #0x18]                           &2c5d934(=d65f03c0d503245f) .defaultAmplitude
02d881b4: cbz     w8, #0x2d881fc                             
02d881b8: mov     x0, x21                                    
02d881bc: mov     x1, x20                                    
02d881c0: str     x20, [x0, #0x20]!                          .isInitialized
02d881c4: bl      #0x2b70d54                                 fn_2b70d54
02d881c8: cbz     x19, #0x2d881f8                            
02d881cc: adrp    x8, #0x6268000                             
02d881d0: mov     x0, x19                                    
02d881d4: mov     x2, x21                                    
02d881d8: ldr     x8, [x8, #0xd90]                           S:'vibrate'
02d881dc: mov     x3, xzr                                    
02d881e0: ldr     x1, [x8]                                   S:'{0}/2'
02d881e4: bl      #0x5ad5e34                                 UnityEngine.AndroidJavaObject::Call
02d881e8: ldp     x20, x19, [sp, #0x20]                      
02d881ec: ldp     x30, x21, [sp, #0x10]                      
02d881f0: add     sp, sp, #0x30                              
02d881f4: ret                                                
02d881f8: bl      #0x2b7105c                                 fn_2b7105c
02d881fc: bl      #0x2b71064                                 fn_2b71064
02d88200: bl      #0x2b71080                                 fn_2b71080
02d88204: mov     x1, xzr                                    
02d88208: bl      #0x2b70f20                                 fn_2b70f20
## vibrateEffect(long[] pattern, int repeat) -> void
---- Framework.Vibration::vibrateEffect 0x2d88988
02d88988: sub     sp, sp, #0x40                              
02d8898c: str     x30, [sp, #0x10]                           
02d88990: stp     x22, x21, [sp, #0x20]                      
02d88994: stp     x20, x19, [sp, #0x30]                      
02d88998: adrp    x22, #0x6630000                            
02d8899c: adrp    x21, #0x6267000                            
02d889a0: mov     w19, w1                                    
02d889a4: ldrb    w8, [x22, #0x4a4]                          
02d889a8: ldr     x21, [x21, #0xea8]                         T:Framework.Vibration
02d889ac: mov     x20, x0                                    
02d889b0: tbnz    w8, #0, #0x2d889ec                         
02d889b4: adrp    x0, #0x6263000                             
02d889b8: ldr     x0, [x0, #0x980]                           T:System.IDisposable
02d889bc: bl      #0x2b70db0                                 fn_2b70db0
02d889c0: adrp    x0, #0x6263000                             
02d889c4: ldr     x0, [x0, #0xa80]                           T:type24502(k1d)
02d889c8: bl      #0x2b70db0                                 fn_2b70db0
02d889cc: adrp    x0, #0x6267000                             
02d889d0: ldr     x0, [x0, #0xea8]                           T:Framework.Vibration
02d889d4: bl      #0x2b70db0                                 fn_2b70db0
02d889d8: adrp    x0, #0x6268000                             
02d889dc: ldr     x0, [x0, #0xd90]                           S:'vibrate'
02d889e0: bl      #0x2b70db0                                 fn_2b70db0
02d889e4: mov     w8, #1                                     
02d889e8: strb    w8, [x22, #0x4a4]                          
02d889ec: ldr     x0, [x21]                                  S:'didu'
02d889f0: str     xzr, [sp, #0x18]                           
02d889f4: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02d889f8: cbnz    w8, #0x2d88a00                             
02d889fc: bl      #0x2b70f30                                 fn_2b70f30
02d88a00: mov     x0, x20                                    
02d88a04: mov     w1, w19                                    
02d88a08: bl      #0x2d89430                                 Framework.Vibration::createEffect_Waveform
02d88a0c: mov     x8, x0                                     
02d88a10: ldr     x0, [x21]                                  S:'didu'
02d88a14: add     x9, sp, #0x18                              
02d88a18: str     x8, [sp, #0x18]                            
02d88a1c: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02d88a20: stp     xzr, x9, [sp]                              
02d88a24: cbnz    w8, #0x2d88a30                             
02d88a28: bl      #0x2b70f30                                 fn_2b70f30
02d88a2c: ldr     x0, [x21]                                  S:'didu'
02d88a30: adrp    x8, #0x6263000                             
02d88a34: ldr     x8, [x8, #0xa80]                           T:type24502(k1d)
02d88a38: ldr     x9, [x0, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02d88a3c: ldr     x19, [x9, #8]                              
02d88a40: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02d88a44: mov     w1, #1                                     
02d88a48: bl      #0x2b70ea0                                 fn_2b70ea0
02d88a4c: mov     x20, x0                                    
02d88a50: cbz     x0, #0x2d88b30                             
02d88a54: ldr     x21, [sp, #0x18]                           
02d88a58: cbz     x21, #0x2d88a70                            
02d88a5c: ldr     x8, [x20]                                  
02d88a60: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02d88a64: mov     x0, x21                                    
02d88a68: bl      #0x2b70f34                                 fn_2b70f34
02d88a6c: cbz     x0, #0x2d88b40                             
02d88a70: ldr     w8, [x20, #0x18]                           .defaultAmplitude
02d88a74: cbz     w8, #0x2d88b3c                             
02d88a78: mov     x0, x20                                    
02d88a7c: str     x21, [x0, #0x20]!                          .isInitialized
02d88a80: mov     x1, x21                                    
02d88a84: bl      #0x2b70d54                                 fn_2b70d54
02d88a88: cbz     x19, #0x2d88b30                            
02d88a8c: adrp    x8, #0x6268000                             
02d88a90: ldr     x8, [x8, #0xd90]                           S:'vibrate'
02d88a94: ldr     x1, [x8]                                   S:'{0}/2'
02d88a98: mov     x0, x19                                    
02d88a9c: mov     x2, x20                                    
02d88aa0: mov     x3, xzr                                    
02d88aa4: bl      #0x5ad5e34                                 UnityEngine.AndroidJavaObject::Call
02d88aa8: mov     x19, xzr                                   
02d88aac: add     x8, sp, #0x18                              
02d88ab0: ldr     x20, [x8]                                  S:'{0}/2'
02d88ab4: cbz     x20, #0x2d88b18                            
02d88ab8: adrp    x10, #0x6263000                            
02d88abc: ldr     x8, [x20]                                  
02d88ac0: ldr     x10, [x10, #0x980]                         T:System.IDisposable
02d88ac4: ldrh    w9, [x8, #0x12e]                           
02d88ac8: ldr     x1, [x10]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d88acc: cbz     x9, #0x2d88af0                             
02d88ad0: ldr     x10, [x8, #0xb0]                           S:'penguin_close_mouth'
02d88ad4: add     x10, x10, #8                               &6263008
02d88ad8: ldur    x11, [x10, #-8]                            
02d88adc: cmp     x11, x1                                    
02d88ae0: b.eq    #0x2d88b00                                 
02d88ae4: subs    x9, x9, #1                                 
02d88ae8: add     x10, x10, #0x10                            &6263010
02d88aec: b.ne    #0x2d88ad8                                 
02d88af0: mov     x0, x20                                    
02d88af4: mov     w2, wzr                                    
02d88af8: bl      #0x2baa05c                                 fn_2baa05c
02d88afc: b       #0x2d88b0c                                 
02d88b00: ldrsw   x9, [x10]                                  
02d88b04: add     x8, x8, x9, lsl #4                         &6268000
02d88b08: add     x0, x8, #0x138                             &6268138
02d88b0c: ldp     x8, x1, [x0]                               
02d88b10: mov     x0, x20                                    
02d88b14: blr     x8                                         
02d88b18: cbnz    x19, #0x2d88b34                            
02d88b1c: ldp     x20, x19, [sp, #0x30]                      
02d88b20: ldr     x30, [sp, #0x10]                           
02d88b24: ldp     x22, x21, [sp, #0x20]                      
02d88b28: add     sp, sp, #0x40                              
02d88b2c: ret                                                
02d88b30: bl      #0x2b7105c                                 fn_2b7105c
02d88b34: mov     x0, x19                                    
02d88b38: bl      #0x2b71054                                 fn_2b71054
02d88b3c: bl      #0x2b71064                                 fn_2b71064
02d88b40: bl      #0x2b71080                                 fn_2b71080
02d88b44: mov     x1, xzr                                    
02d88b48: bl      #0x2b70f20                                 fn_2b70f20
02d88b4c: b       #0x2d88b54                                 
02d88b50: b       #0x2d88b54                                 
02d88b54: mov     x19, x0                                    
02d88b58: cmp     w1, #1                                     
02d88b5c: b.ne    #0x2d88b80                                 
02d88b60: mov     x0, x19                                    
02d88b64: bl      #0x5e90260                                 fn_5e90260
02d88b68: ldr     x19, [x0]                                  S:'{0}/2'
02d88b6c: str     x19, [sp]                                  
02d88b70: bl      #0x5e90270                                 fn_5e90270
02d88b74: ldr     x8, [sp, #8]                               
02d88b78: b       #0x2d88ab0                                 
02d88b7c: mov     x19, x0                                    
02d88b80: mov     x0, sp                                     
02d88b84: bl      #0x27369c4                                 fn_27369c4
02d88b88: mov     x0, x19                                    
02d88b8c: bl      #0x2c6051c                                 fn_2c6051c
02d88b90: bl      #0x27369b8                                 fn_27369b8
## vibrateLegacy(long[] pattern, int repeat) -> void
---- Framework.Vibration::vibrateLegacy 0x2d88b94
02d88b94: str     x30, [sp, #-0x30]!                         
02d88b98: stp     x22, x21, [sp, #0x10]                      
02d88b9c: stp     x20, x19, [sp, #0x20]                      
02d88ba0: adrp    x21, #0x6630000                            
02d88ba4: adrp    x20, #0x6267000                            
02d88ba8: mov     w19, w1                                    
02d88bac: ldrb    w8, [x21, #0x4a5]                          
02d88bb0: ldr     x20, [x20, #0xea8]                         T:Framework.Vibration
02d88bb4: mov     x22, x0                                    
02d88bb8: tbnz    w8, #0, #0x2d88be8                         
02d88bbc: adrp    x0, #0x6263000                             
02d88bc0: ldr     x0, [x0, #0xa80]                           T:type24502(k1d)
02d88bc4: bl      #0x2b70db0                                 fn_2b70db0
02d88bc8: adrp    x0, #0x6267000                             
02d88bcc: ldr     x0, [x0, #0xea8]                           T:Framework.Vibration
02d88bd0: bl      #0x2b70db0                                 fn_2b70db0
02d88bd4: adrp    x0, #0x6268000                             
02d88bd8: ldr     x0, [x0, #0xd90]                           S:'vibrate'
02d88bdc: bl      #0x2b70db0                                 fn_2b70db0
02d88be0: mov     w8, #1                                     
02d88be4: strb    w8, [x21, #0x4a5]                          
02d88be8: ldr     x0, [x20]                                  S:'didu'
02d88bec: adrp    x21, #0x6263000                            
02d88bf0: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02d88bf4: ldr     x21, [x21, #0xa80]                         T:type24502(k1d)
02d88bf8: cbnz    w8, #0x2d88c04                             
02d88bfc: bl      #0x2b70f30                                 fn_2b70f30
02d88c00: ldr     x0, [x20]                                  S:'didu'
02d88c04: ldr     x8, [x0, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02d88c08: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d88c0c: mov     w1, #2                                     
02d88c10: ldr     x20, [x8, #8]                              
02d88c14: bl      #0x2b70ea0                                 fn_2b70ea0
02d88c18: cbz     x0, #0x2d88cd0                             
02d88c1c: mov     x21, x0                                    
02d88c20: cbz     x22, #0x2d88c38                            
02d88c24: ldr     x8, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d88c28: mov     x0, x22                                    
02d88c2c: ldr     x1, [x8, #0x40]                            
02d88c30: bl      #0x2b70f34                                 fn_2b70f34
02d88c34: cbz     x0, #0x2d88cd8                             
02d88c38: ldr     w8, [x21, #0x18]                           &2c5d934(=d65f03c0d503245f) .defaultAmplitude
02d88c3c: cbz     w8, #0x2d88cd4                             
02d88c40: mov     x0, x21                                    
02d88c44: mov     x1, x22                                    
02d88c48: str     x22, [x0, #0x20]!                          .isInitialized
02d88c4c: bl      #0x2b70d54                                 fn_2b70d54
02d88c50: adrp    x8, #0x6263000                             
02d88c54: add     x1, sp, #0xc                               
02d88c58: ldr     x8, [x8, #0x970]                           &6645c70(=0)
02d88c5c: str     w19, [sp, #0xc]                            
02d88c60: ldr     x0, [x8, #0x48]                            &6263098(=0)
02d88c64: bl      #0x2b70f38                                 fn_2b70f38
02d88c68: mov     x19, x0                                    
02d88c6c: cbz     x0, #0x2d88c84                             
02d88c70: ldr     x8, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d88c74: mov     x0, x19                                    
02d88c78: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02d88c7c: bl      #0x2b70f34                                 fn_2b70f34
02d88c80: cbz     x0, #0x2d88cd8                             
02d88c84: ldr     w8, [x21, #0x18]                           &2c5d934(=d65f03c0d503245f) .defaultAmplitude
02d88c88: tst     w8, #0xfffffffe                            
02d88c8c: b.eq    #0x2d88cd4                                 
02d88c90: mov     x0, x21                                    
02d88c94: mov     x1, x19                                    
02d88c98: str     x19, [x0, #0x28]!                          
02d88c9c: bl      #0x2b70d54                                 fn_2b70d54
02d88ca0: cbz     x20, #0x2d88cd0                            
02d88ca4: adrp    x8, #0x6268000                             
02d88ca8: mov     x0, x20                                    
02d88cac: mov     x2, x21                                    
02d88cb0: ldr     x8, [x8, #0xd90]                           S:'vibrate'
02d88cb4: mov     x3, xzr                                    
02d88cb8: ldr     x1, [x8]                                   S:'{0}/2'
02d88cbc: bl      #0x5ad5e34                                 UnityEngine.AndroidJavaObject::Call
02d88cc0: ldp     x20, x19, [sp, #0x20]                      
02d88cc4: ldp     x22, x21, [sp, #0x10]                      
02d88cc8: ldr     x30, [sp], #0x30                           
02d88ccc: ret                                                
02d88cd0: bl      #0x2b7105c                                 fn_2b7105c
02d88cd4: bl      #0x2b71064                                 fn_2b71064
02d88cd8: bl      #0x2b71080                                 fn_2b71080
02d88cdc: mov     x1, xzr                                    
02d88ce0: bl      #0x2b70f20                                 fn_2b70f20
## vibrateEffect(long[] pattern, int[] amplitudes, int repeat) -> void
---- Framework.Vibration::vibrateEffect 0x2d88774
02d88774: sub     sp, sp, #0x50                              
02d88778: stp     x30, x23, [sp, #0x20]                      
02d8877c: stp     x22, x21, [sp, #0x30]                      
02d88780: stp     x20, x19, [sp, #0x40]                      
02d88784: adrp    x23, #0x6630000                            
02d88788: adrp    x22, #0x6267000                            
02d8878c: mov     w19, w2                                    
02d88790: ldrb    w8, [x23, #0x4a6]                          
02d88794: ldr     x22, [x22, #0xea8]                         T:Framework.Vibration
02d88798: mov     x20, x1                                    
02d8879c: mov     x21, x0                                    
02d887a0: tbnz    w8, #0, #0x2d887dc                         
02d887a4: adrp    x0, #0x6263000                             
02d887a8: ldr     x0, [x0, #0x980]                           T:System.IDisposable
02d887ac: bl      #0x2b70db0                                 fn_2b70db0
02d887b0: adrp    x0, #0x6263000                             
02d887b4: ldr     x0, [x0, #0xa80]                           T:type24502(k1d)
02d887b8: bl      #0x2b70db0                                 fn_2b70db0
02d887bc: adrp    x0, #0x6267000                             
02d887c0: ldr     x0, [x0, #0xea8]                           T:Framework.Vibration
02d887c4: bl      #0x2b70db0                                 fn_2b70db0
02d887c8: adrp    x0, #0x6268000                             
02d887cc: ldr     x0, [x0, #0xd90]                           S:'vibrate'
02d887d0: bl      #0x2b70db0                                 fn_2b70db0
02d887d4: mov     w8, #1                                     
02d887d8: strb    w8, [x23, #0x4a6]                          
02d887dc: ldr     x0, [x22]                                  S:'didu'
02d887e0: str     xzr, [sp, #0x18]                           
02d887e4: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02d887e8: cbnz    w8, #0x2d887f0                             
02d887ec: bl      #0x2b70f30                                 fn_2b70f30
02d887f0: mov     x0, x21                                    
02d887f4: mov     x1, x20                                    
02d887f8: mov     w2, w19                                    
02d887fc: bl      #0x2d89594                                 Framework.Vibration::createEffect_Waveform
02d88800: mov     x8, x0                                     
02d88804: ldr     x0, [x22]                                  S:'didu'
02d88808: add     x9, sp, #0x18                              
02d8880c: str     x8, [sp, #0x18]                            
02d88810: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02d88814: stp     xzr, x9, [sp, #8]                          
02d88818: cbnz    w8, #0x2d88824                             
02d8881c: bl      #0x2b70f30                                 fn_2b70f30
02d88820: ldr     x0, [x22]                                  S:'didu'
02d88824: adrp    x8, #0x6263000                             
02d88828: ldr     x8, [x8, #0xa80]                           T:type24502(k1d)
02d8882c: ldr     x9, [x0, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02d88830: ldr     x19, [x9, #8]                              
02d88834: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02d88838: mov     w1, #1                                     
02d8883c: bl      #0x2b70ea0                                 fn_2b70ea0
02d88840: mov     x20, x0                                    
02d88844: cbz     x0, #0x2d88924                             
02d88848: ldr     x21, [sp, #0x18]                           
02d8884c: cbz     x21, #0x2d88864                            
02d88850: ldr     x8, [x20]                                  
02d88854: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02d88858: mov     x0, x21                                    
02d8885c: bl      #0x2b70f34                                 fn_2b70f34
02d88860: cbz     x0, #0x2d88934                             
02d88864: ldr     w8, [x20, #0x18]                           .defaultAmplitude
02d88868: cbz     w8, #0x2d88930                             
02d8886c: mov     x0, x20                                    
02d88870: str     x21, [x0, #0x20]!                          .isInitialized
02d88874: mov     x1, x21                                    
02d88878: bl      #0x2b70d54                                 fn_2b70d54
02d8887c: cbz     x19, #0x2d88924                            
02d88880: adrp    x8, #0x6268000                             
02d88884: ldr     x8, [x8, #0xd90]                           S:'vibrate'
02d88888: ldr     x1, [x8]                                   S:'{0}/2'
02d8888c: mov     x0, x19                                    
02d88890: mov     x2, x20                                    
02d88894: mov     x3, xzr                                    
02d88898: bl      #0x5ad5e34                                 UnityEngine.AndroidJavaObject::Call
02d8889c: mov     x19, xzr                                   
02d888a0: add     x8, sp, #0x18                              
02d888a4: ldr     x20, [x8]                                  S:'{0}/2'
02d888a8: cbz     x20, #0x2d8890c                            
02d888ac: adrp    x10, #0x6263000                            
02d888b0: ldr     x8, [x20]                                  
02d888b4: ldr     x10, [x10, #0x980]                         T:System.IDisposable
02d888b8: ldrh    w9, [x8, #0x12e]                           
02d888bc: ldr     x1, [x10]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d888c0: cbz     x9, #0x2d888e4                             
02d888c4: ldr     x10, [x8, #0xb0]                           S:'penguin_close_mouth'
02d888c8: add     x10, x10, #8                               &6263008
02d888cc: ldur    x11, [x10, #-8]                            
02d888d0: cmp     x11, x1                                    
02d888d4: b.eq    #0x2d888f4                                 
02d888d8: subs    x9, x9, #1                                 
02d888dc: add     x10, x10, #0x10                            &6263010
02d888e0: b.ne    #0x2d888cc                                 
02d888e4: mov     x0, x20                                    
02d888e8: mov     w2, wzr                                    
02d888ec: bl      #0x2baa05c                                 fn_2baa05c
02d888f0: b       #0x2d88900                                 
02d888f4: ldrsw   x9, [x10]                                  
02d888f8: add     x8, x8, x9, lsl #4                         &6268000
02d888fc: add     x0, x8, #0x138                             &6268138
02d88900: ldp     x8, x1, [x0]                               
02d88904: mov     x0, x20                                    
02d88908: blr     x8                                         
02d8890c: cbnz    x19, #0x2d88928                            
02d88910: ldp     x20, x19, [sp, #0x40]                      
02d88914: ldp     x22, x21, [sp, #0x30]                      
02d88918: ldp     x30, x23, [sp, #0x20]                      
02d8891c: add     sp, sp, #0x50                              
02d88920: ret                                                
02d88924: bl      #0x2b7105c                                 fn_2b7105c
02d88928: mov     x0, x19                                    
02d8892c: bl      #0x2b71054                                 fn_2b71054
02d88930: bl      #0x2b71064                                 fn_2b71064
02d88934: bl      #0x2b71080                                 fn_2b71080
02d88938: mov     x1, xzr                                    
02d8893c: bl      #0x2b70f20                                 fn_2b70f20
02d88940: b       #0x2d88948                                 
02d88944: b       #0x2d88948                                 
02d88948: mov     x19, x0                                    
02d8894c: cmp     w1, #1                                     
02d88950: b.ne    #0x2d88974                                 
02d88954: mov     x0, x19                                    
02d88958: bl      #0x5e90260                                 fn_5e90260
02d8895c: ldr     x19, [x0]                                  S:'{0}/2'
02d88960: str     x19, [sp, #8]                              
02d88964: bl      #0x5e90270                                 fn_5e90270
02d88968: ldr     x8, [sp, #0x10]                            
02d8896c: b       #0x2d888a4                                 
02d88970: mov     x19, x0                                    
02d88974: add     x0, sp, #8                                 
02d88978: bl      #0x27369c4                                 fn_27369c4
02d8897c: mov     x0, x19                                    
02d88980: bl      #0x2c6051c                                 fn_2c6051c
02d88984: bl      #0x27369b8                                 fn_27369b8
## vibrateEffectPredefined(int effectId) -> void
---- Framework.Vibration::vibrateEffectPredefined 0x2d88ed4
02d88ed4: sub     sp, sp, #0x40                              
02d88ed8: stp     x30, x21, [sp, #0x20]                      
02d88edc: stp     x20, x19, [sp, #0x30]                      
02d88ee0: adrp    x21, #0x6630000                            
02d88ee4: adrp    x20, #0x6267000                            
02d88ee8: mov     w19, w0                                    
02d88eec: ldrb    w8, [x21, #0x4a7]                          
02d88ef0: ldr     x20, [x20, #0xea8]                         T:Framework.Vibration
02d88ef4: tbnz    w8, #0, #0x2d88f30                         
02d88ef8: adrp    x0, #0x6263000                             
02d88efc: ldr     x0, [x0, #0x980]                           T:System.IDisposable
02d88f00: bl      #0x2b70db0                                 fn_2b70db0
02d88f04: adrp    x0, #0x6263000                             
02d88f08: ldr     x0, [x0, #0xa80]                           T:type24502(k1d)
02d88f0c: bl      #0x2b70db0                                 fn_2b70db0
02d88f10: adrp    x0, #0x6267000                             
02d88f14: ldr     x0, [x0, #0xea8]                           T:Framework.Vibration
02d88f18: bl      #0x2b70db0                                 fn_2b70db0
02d88f1c: adrp    x0, #0x6268000                             
02d88f20: ldr     x0, [x0, #0xd90]                           S:'vibrate'
02d88f24: bl      #0x2b70db0                                 fn_2b70db0
02d88f28: mov     w8, #1                                     
02d88f2c: strb    w8, [x21, #0x4a7]                          
02d88f30: ldr     x0, [x20]                                  S:'didu'
02d88f34: str     xzr, [sp, #0x18]                           
02d88f38: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02d88f3c: cbnz    w8, #0x2d88f44                             
02d88f40: bl      #0x2b70f30                                 fn_2b70f30
02d88f44: mov     w0, w19                                    
02d88f48: bl      #0x2d89738                                 Framework.Vibration::createEffect_Predefined
02d88f4c: mov     x8, x0                                     
02d88f50: ldr     x0, [x20]                                  S:'didu'
02d88f54: add     x9, sp, #0x18                              
02d88f58: str     x8, [sp, #0x18]                            
02d88f5c: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02d88f60: stp     xzr, x9, [sp, #8]                          
02d88f64: cbnz    w8, #0x2d88f70                             
02d88f68: bl      #0x2b70f30                                 fn_2b70f30
02d88f6c: ldr     x0, [x20]                                  S:'didu'
02d88f70: adrp    x8, #0x6263000                             
02d88f74: ldr     x8, [x8, #0xa80]                           T:type24502(k1d)
02d88f78: ldr     x9, [x0, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02d88f7c: ldr     x19, [x9, #8]                              
02d88f80: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02d88f84: mov     w1, #1                                     
02d88f88: bl      #0x2b70ea0                                 fn_2b70ea0
02d88f8c: mov     x20, x0                                    
02d88f90: cbz     x0, #0x2d8906c                             
02d88f94: ldr     x21, [sp, #0x18]                           
02d88f98: cbz     x21, #0x2d88fb0                            
02d88f9c: ldr     x8, [x20]                                  S:'didu'
02d88fa0: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02d88fa4: mov     x0, x21                                    
02d88fa8: bl      #0x2b70f34                                 fn_2b70f34
02d88fac: cbz     x0, #0x2d8907c                             
02d88fb0: ldr     w8, [x20, #0x18]                           S:'android.content.Intent' .defaultAmplitude
02d88fb4: cbz     w8, #0x2d89078                             
02d88fb8: mov     x0, x20                                    
02d88fbc: str     x21, [x0, #0x20]!                          .isInitialized
02d88fc0: mov     x1, x21                                    
02d88fc4: bl      #0x2b70d54                                 fn_2b70d54
02d88fc8: cbz     x19, #0x2d8906c                            
02d88fcc: adrp    x8, #0x6268000                             
02d88fd0: ldr     x8, [x8, #0xd90]                           S:'vibrate'
02d88fd4: ldr     x1, [x8]                                   S:'{0}/2'
02d88fd8: mov     x0, x19                                    
02d88fdc: mov     x2, x20                                    
02d88fe0: mov     x3, xzr                                    
02d88fe4: bl      #0x5ad5e34                                 UnityEngine.AndroidJavaObject::Call
02d88fe8: mov     x19, xzr                                   
02d88fec: add     x8, sp, #0x18                              
02d88ff0: ldr     x20, [x8]                                  S:'{0}/2'
02d88ff4: cbz     x20, #0x2d89058                            
02d88ff8: adrp    x10, #0x6263000                            
02d88ffc: ldr     x8, [x20]                                  S:'didu'
02d89000: b       #0x5e8fffc                                 
02d89004: ldrh    w9, [x8, #0x12e]                           
02d89008: ldr     x1, [x10]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d8900c: cbz     x9, #0x2d89030                             
02d89010: ldr     x10, [x8, #0xb0]                           S:'penguin_close_mouth'
02d89014: add     x10, x10, #8                               &6263008
02d89018: ldur    x11, [x10, #-8]                            
02d8901c: cmp     x11, x1                                    
02d89020: b.eq    #0x2d89040                                 
02d89024: subs    x9, x9, #1                                 
02d89028: add     x10, x10, #0x10                            &6263010
02d8902c: b.ne    #0x2d89018                                 
02d89030: mov     x0, x20                                    
02d89034: mov     w2, wzr                                    
02d89038: bl      #0x2baa05c                                 fn_2baa05c
02d8903c: b       #0x2d8904c                                 
02d89040: ldrsw   x9, [x10]                                  
02d89044: add     x8, x8, x9, lsl #4                         &6268000
02d89048: add     x0, x8, #0x138                             &6268138
02d8904c: ldp     x8, x1, [x0]                               
02d89050: mov     x0, x20                                    
02d89054: blr     x8                                         
02d89058: cbnz    x19, #0x2d89070                            
02d8905c: ldp     x20, x19, [sp, #0x30]                      
02d89060: ldp     x30, x21, [sp, #0x20]                      
02d89064: add     sp, sp, #0x40                              
02d89068: ret                                                
02d8906c: bl      #0x2b7105c                                 fn_2b7105c
02d89070: mov     x0, x19                                    
02d89074: bl      #0x2b71054                                 fn_2b71054
02d89078: bl      #0x2b71064                                 fn_2b71064
02d8907c: bl      #0x2b71080                                 fn_2b71080
02d89080: mov     x1, xzr                                    
02d89084: bl      #0x2b70f20                                 fn_2b70f20
02d89088: b       #0x2d89090                                 
02d8908c: b       #0x2d89090                                 
02d89090: mov     x19, x0                                    
02d89094: cmp     w1, #1                                     
02d89098: b.ne    #0x2d890bc                                 
02d8909c: mov     x0, x19                                    
02d890a0: bl      #0x5e90260                                 fn_5e90260
02d890a4: ldr     x19, [x0]                                  S:'{0}/2'
02d890a8: str     x19, [sp, #8]                              
02d890ac: bl      #0x5e90270                                 fn_5e90270
02d890b0: ldr     x8, [sp, #0x10]                            
02d890b4: b       #0x2d88ff0                                 
02d890b8: mov     x19, x0                                    
02d890bc: add     x0, sp, #8                                 
02d890c0: bl      #0x27369c4                                 fn_27369c4
02d890c4: mov     x0, x19                                    
02d890c8: bl      #0x2c6051c                                 fn_2c6051c
02d890cc: bl      #0x27369b8                                 fn_27369b8
## createEffect_OneShot(long milliseconds, int amplitude) -> UnityEngine.AndroidJavaObject
---- Framework.Vibration::createEffect_OneShot 0x2d892b0
02d892b0: sub     sp, sp, #0x40                              
02d892b4: stp     x30, x23, [sp, #0x10]                      
02d892b8: stp     x22, x21, [sp, #0x20]                      
02d892bc: stp     x20, x19, [sp, #0x30]                      
02d892c0: adrp    x21, #0x6630000                            
02d892c4: adrp    x20, #0x6267000                            
02d892c8: mov     w19, w1                                    
02d892cc: ldrb    w8, [x21, #0x4a8]                          
02d892d0: ldr     x20, [x20, #0xea8]                         T:Framework.Vibration
02d892d4: mov     x22, x0                                    
02d892d8: tbnz    w8, #0, #0x2d89314                         
02d892dc: adrp    x0, #0x6266000                             
02d892e0: ldr     x0, [x0, #0x160]                           MS:UnityEngine.AndroidJavaObject::CallStatic
02d892e4: bl      #0x2b70db0                                 fn_2b70db0
02d892e8: adrp    x0, #0x6263000                             
02d892ec: ldr     x0, [x0, #0xa80]                           T:type24502(k1d)
02d892f0: bl      #0x2b70db0                                 fn_2b70db0
02d892f4: adrp    x0, #0x6267000                             
02d892f8: ldr     x0, [x0, #0xea8]                           T:Framework.Vibration
02d892fc: bl      #0x2b70db0                                 fn_2b70db0
02d89300: adrp    x0, #0x6268000                             
02d89304: ldr     x0, [x0, #0xdd8]                           S:'createOneShot'
02d89308: bl      #0x2b70db0                                 fn_2b70db0
02d8930c: mov     w8, #1                                     
02d89310: strb    w8, [x21, #0x4a8]                          
02d89314: ldr     x0, [x20]                                  S:'didu'
02d89318: adrp    x21, #0x6263000                            
02d8931c: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02d89320: ldr     x21, [x21, #0xa80]                         T:type24502(k1d)
02d89324: cbnz    w8, #0x2d89330                             
02d89328: bl      #0x2b70f30                                 fn_2b70f30
02d8932c: ldr     x0, [x20]                                  S:'didu'
02d89330: ldr     x8, [x0, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02d89334: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d89338: mov     w1, #2                                     
02d8933c: ldr     x20, [x8, #0x10]                           
02d89340: bl      #0x2b70ea0                                 fn_2b70ea0
02d89344: adrp    x23, #0x6263000                            
02d89348: mov     x21, x0                                    
02d8934c: add     x1, sp, #8                                 
02d89350: ldr     x23, [x23, #0x970]                         &6645c70(=0)
02d89354: str     x22, [sp, #8]                              
02d89358: ldr     x0, [x23, #0x68]                           &2c497cc(=d65f03c0d503245f)
02d8935c: bl      #0x2b70f38                                 fn_2b70f38
02d89360: cbz     x21, #0x2d8941c                            
02d89364: mov     x22, x0                                    
02d89368: cbz     x0, #0x2d89380                             
02d8936c: ldr     x8, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d89370: mov     x0, x22                                    
02d89374: ldr     x1, [x8, #0x40]                            
02d89378: bl      #0x2b70f34                                 fn_2b70f34
02d8937c: cbz     x0, #0x2d89424                             
02d89380: ldr     w8, [x21, #0x18]                           &2c5d934(=d65f03c0d503245f) .defaultAmplitude
02d89384: cbz     w8, #0x2d89420                             
02d89388: mov     x0, x21                                    
02d8938c: mov     x1, x22                                    
02d89390: str     x22, [x0, #0x20]!                          .isInitialized
02d89394: bl      #0x2b70d54                                 fn_2b70d54
02d89398: ldr     x0, [x23, #0x48]                           &6263098(=0)
02d8939c: add     x1, sp, #4                                 
02d893a0: str     w19, [sp, #4]                              
02d893a4: bl      #0x2b70f38                                 fn_2b70f38
02d893a8: mov     x19, x0                                    
02d893ac: cbz     x0, #0x2d893c4                             
02d893b0: ldr     x8, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d893b4: mov     x0, x19                                    
02d893b8: ldr     x1, [x8, #0x40]                            
02d893bc: bl      #0x2b70f34                                 fn_2b70f34
02d893c0: cbz     x0, #0x2d89424                             
02d893c4: ldr     w8, [x21, #0x18]                           &2c5d934(=d65f03c0d503245f) .defaultAmplitude
02d893c8: tst     w8, #0xfffffffe                            
02d893cc: b.eq    #0x2d89420                                 
02d893d0: mov     x0, x21                                    
02d893d4: mov     x1, x19                                    
02d893d8: str     x19, [x0, #0x28]!                          
02d893dc: bl      #0x2b70d54                                 fn_2b70d54
02d893e0: cbz     x20, #0x2d8941c                            
02d893e4: adrp    x8, #0x6268000                             
02d893e8: adrp    x9, #0x6266000                             
02d893ec: mov     x0, x20                                    
02d893f0: ldr     x8, [x8, #0xdd8]                           S:'createOneShot'
02d893f4: ldr     x9, [x9, #0x160]                           MS:UnityEngine.AndroidJavaObject::CallStatic
02d893f8: mov     x2, x21                                    
02d893fc: ldr     x1, [x8]                                   S:'{0}/2'
02d89400: ldr     x3, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d89404: bl      #0x31200ac                                 fn_31200ac
02d89408: ldp     x20, x19, [sp, #0x30]                      
02d8940c: ldp     x22, x21, [sp, #0x20]                      
02d89410: ldp     x30, x23, [sp, #0x10]                      
02d89414: add     sp, sp, #0x40                              
02d89418: ret                                                
02d8941c: bl      #0x2b7105c                                 fn_2b7105c
02d89420: bl      #0x2b71064                                 fn_2b71064
02d89424: bl      #0x2b71080                                 fn_2b71080
02d89428: mov     x1, xzr                                    
02d8942c: bl      #0x2b70f20                                 fn_2b70f20
## createEffect_Predefined(int effectId) -> UnityEngine.AndroidJavaObject
---- Framework.Vibration::createEffect_Predefined 0x2d89738
02d89738: sub     sp, sp, #0x30                              
02d8973c: stp     x30, x21, [sp, #0x10]                      
02d89740: stp     x20, x19, [sp, #0x20]                      
02d89744: adrp    x21, #0x6630000                            
02d89748: adrp    x20, #0x6267000                            
02d8974c: mov     w19, w0                                    
02d89750: ldrb    w8, [x21, #0x4a9]                          
02d89754: ldr     x20, [x20, #0xea8]                         T:Framework.Vibration
02d89758: tbnz    w8, #0, #0x2d89794                         
02d8975c: adrp    x0, #0x6266000                             
02d89760: ldr     x0, [x0, #0x160]                           MS:UnityEngine.AndroidJavaObject::CallStatic
02d89764: bl      #0x2b70db0                                 fn_2b70db0
02d89768: adrp    x0, #0x6263000                             
02d8976c: ldr     x0, [x0, #0xa80]                           T:type24502(k1d)
02d89770: bl      #0x2b70db0                                 fn_2b70db0
02d89774: adrp    x0, #0x6267000                             
02d89778: ldr     x0, [x0, #0xea8]                           T:Framework.Vibration
02d8977c: bl      #0x2b70db0                                 fn_2b70db0
02d89780: adrp    x0, #0x6268000                             
02d89784: ldr     x0, [x0, #0xde8]                           S:'createPredefined'
02d89788: bl      #0x2b70db0                                 fn_2b70db0
02d8978c: mov     w8, #1                                     
02d89790: strb    w8, [x21, #0x4a9]                          
02d89794: ldr     x0, [x20]                                  S:'didu'
02d89798: adrp    x21, #0x6263000                            
02d8979c: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02d897a0: ldr     x21, [x21, #0xa80]                         T:type24502(k1d)
02d897a4: cbnz    w8, #0x2d897b0                             
02d897a8: bl      #0x2b70f30                                 fn_2b70f30
02d897ac: ldr     x0, [x20]                                  S:'didu'
02d897b0: ldr     x8, [x0, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02d897b4: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d897b8: mov     w1, #1                                     
02d897bc: ldr     x20, [x8, #0x10]                           
02d897c0: bl      #0x2b70ea0                                 fn_2b70ea0
02d897c4: adrp    x8, #0x6263000                             
02d897c8: mov     x21, x0                                    
02d897cc: add     x1, sp, #0xc                               
02d897d0: ldr     x8, [x8, #0x970]                           &6645c70(=0)
02d897d4: str     w19, [sp, #0xc]                            
02d897d8: ldr     x0, [x8, #0x48]                            &6263098(=0)
02d897dc: bl      #0x2b70f38                                 fn_2b70f38
02d897e0: cbz     x21, #0x2d89850                            
02d897e4: mov     x19, x0                                    
02d897e8: cbz     x0, #0x2d89800                             
02d897ec: ldr     x8, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d897f0: mov     x0, x19                                    
02d897f4: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02d897f8: bl      #0x2b70f34                                 fn_2b70f34
02d897fc: cbz     x0, #0x2d89858                             
02d89800: ldr     w8, [x21, #0x18]                           &2c5d934(=d65f03c0d503245f) .defaultAmplitude
02d89804: cbz     w8, #0x2d89854                             
02d89808: mov     x0, x21                                    
02d8980c: mov     x1, x19                                    
02d89810: str     x19, [x0, #0x20]!                          .isInitialized
02d89814: bl      #0x2b70d54                                 fn_2b70d54
02d89818: cbz     x20, #0x2d89850                            
02d8981c: adrp    x8, #0x6268000                             
02d89820: adrp    x9, #0x6266000                             
02d89824: mov     x0, x20                                    
02d89828: ldr     x8, [x8, #0xde8]                           S:'createPredefined'
02d8982c: ldr     x9, [x9, #0x160]                           MS:UnityEngine.AndroidJavaObject::CallStatic
02d89830: mov     x2, x21                                    
02d89834: ldr     x1, [x8]                                   S:'{0}/2'
02d89838: ldr     x3, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d8983c: bl      #0x31200ac                                 fn_31200ac
02d89840: ldp     x20, x19, [sp, #0x20]                      
02d89844: ldp     x30, x21, [sp, #0x10]                      
02d89848: add     sp, sp, #0x30                              
02d8984c: ret                                                
02d89850: bl      #0x2b7105c                                 fn_2b7105c
02d89854: bl      #0x2b71064                                 fn_2b71064
02d89858: bl      #0x2b71080                                 fn_2b71080
02d8985c: mov     x1, xzr                                    
02d89860: bl      #0x2b70f20                                 fn_2b70f20
## createEffect_Waveform(long[] timings, int[] amplitudes, int repeat) -> UnityEngine.AndroidJavaObject
---- Framework.Vibration::createEffect_Waveform 0x2d89594
02d89594: sub     sp, sp, #0x40                              
02d89598: stp     x30, x23, [sp, #0x10]                      
02d8959c: stp     x22, x21, [sp, #0x20]                      
02d895a0: stp     x20, x19, [sp, #0x30]                      
02d895a4: adrp    x22, #0x6630000                            
02d895a8: adrp    x21, #0x6267000                            
02d895ac: mov     w19, w2                                    
02d895b0: ldrb    w8, [x22, #0x4aa]                          
02d895b4: ldr     x21, [x21, #0xea8]                         T:Framework.Vibration
02d895b8: mov     x20, x1                                    
02d895bc: mov     x23, x0                                    
02d895c0: tbnz    w8, #0, #0x2d895fc                         
02d895c4: adrp    x0, #0x6266000                             
02d895c8: ldr     x0, [x0, #0x160]                           MS:UnityEngine.AndroidJavaObject::CallStatic
02d895cc: bl      #0x2b70db0                                 fn_2b70db0
02d895d0: adrp    x0, #0x6263000                             
02d895d4: ldr     x0, [x0, #0xa80]                           T:type24502(k1d)
02d895d8: bl      #0x2b70db0                                 fn_2b70db0
02d895dc: adrp    x0, #0x6267000                             
02d895e0: ldr     x0, [x0, #0xea8]                           T:Framework.Vibration
02d895e4: bl      #0x2b70db0                                 fn_2b70db0
02d895e8: adrp    x0, #0x6268000                             
02d895ec: ldr     x0, [x0, #0xde0]                           S:'createWaveform'
02d895f0: bl      #0x2b70db0                                 fn_2b70db0
02d895f4: mov     w8, #1                                     
02d895f8: strb    w8, [x22, #0x4aa]                          
02d895fc: ldr     x0, [x21]                                  S:'didu'
02d89600: adrp    x22, #0x6263000                            
02d89604: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02d89608: ldr     x22, [x22, #0xa80]                         T:type24502(k1d)
02d8960c: cbnz    w8, #0x2d89618                             
02d89610: bl      #0x2b70f30                                 fn_2b70f30
02d89614: ldr     x0, [x21]                                  S:'didu'
02d89618: ldr     x8, [x0, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02d8961c: ldr     x0, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d89620: mov     w1, #3                                     
02d89624: ldr     x21, [x8, #0x10]                           
02d89628: bl      #0x2b70ea0                                 fn_2b70ea0
02d8962c: cbz     x0, #0x2d89728                             
02d89630: mov     x22, x0                                    
02d89634: cbz     x23, #0x2d8964c                            
02d89638: ldr     x8, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d8963c: mov     x0, x23                                    
02d89640: ldr     x1, [x8, #0x40]                            
02d89644: bl      #0x2b70f34                                 fn_2b70f34
02d89648: cbz     x0, #0x2d8972c                             
02d8964c: ldr     w8, [x22, #0x18]                           &2c5d934(=d65f03c0d503245f)
02d89650: cbz     w8, #0x2d89724                             
02d89654: mov     x0, x22                                    
02d89658: mov     x1, x23                                    
02d8965c: str     x23, [x0, #0x20]!                          .isInitialized
02d89660: bl      #0x2b70d54                                 fn_2b70d54
02d89664: cbz     x20, #0x2d8967c                            
02d89668: ldr     x8, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d8966c: mov     x0, x20                                    
02d89670: ldr     x1, [x8, #0x40]                            
02d89674: bl      #0x2b70f34                                 fn_2b70f34
02d89678: cbz     x0, #0x2d8972c                             
02d8967c: ldr     w8, [x22, #0x18]                           &2c5d934(=d65f03c0d503245f)
02d89680: tst     w8, #0xfffffffe                            
02d89684: b.eq    #0x2d89724                                 
02d89688: mov     x0, x22                                    
02d8968c: mov     x1, x20                                    
02d89690: str     x20, [x0, #0x28]!                          
02d89694: bl      #0x2b70d54                                 fn_2b70d54
02d89698: adrp    x8, #0x6263000                             
02d8969c: add     x1, sp, #0xc                               
02d896a0: ldr     x8, [x8, #0x970]                           &6645c70(=0)
02d896a4: str     w19, [sp, #0xc]                            
02d896a8: ldr     x0, [x8, #0x48]                            &6263098(=0)
02d896ac: bl      #0x2b70f38                                 fn_2b70f38
02d896b0: mov     x19, x0                                    
02d896b4: cbz     x0, #0x2d896cc                             
02d896b8: ldr     x8, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d896bc: mov     x0, x19                                    
02d896c0: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02d896c4: bl      #0x2b70f34                                 fn_2b70f34
02d896c8: cbz     x0, #0x2d8972c                             
02d896cc: ldr     w8, [x22, #0x18]                           &2c5d934(=d65f03c0d503245f)
02d896d0: cmp     w8, #2                                     
02d896d4: b.ls    #0x2d89724                                 
02d896d8: mov     x0, x22                                    
02d896dc: mov     x1, x19                                    
02d896e0: str     x19, [x0, #0x30]!                          
02d896e4: bl      #0x2b70d54                                 fn_2b70d54
02d896e8: cbz     x21, #0x2d89728                            
02d896ec: adrp    x8, #0x6268000                             
02d896f0: adrp    x9, #0x6266000                             
02d896f4: mov     x0, x21                                    
02d896f8: ldr     x8, [x8, #0xde0]                           S:'createWaveform'
02d896fc: ldr     x9, [x9, #0x160]                           MS:UnityEngine.AndroidJavaObject::CallStatic
02d89700: mov     x2, x22                                    
02d89704: ldr     x1, [x8]                                   S:'{0}/2'
02d89708: ldr     x3, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d8970c: bl      #0x31200ac                                 fn_31200ac
02d89710: ldp     x20, x19, [sp, #0x30]                      
02d89714: ldp     x22, x21, [sp, #0x20]                      
02d89718: ldp     x30, x23, [sp, #0x10]                      
02d8971c: add     sp, sp, #0x40                              
02d89720: ret                                                
02d89724: bl      #0x2b71064                                 fn_2b71064
02d89728: bl      #0x2b7105c                                 fn_2b7105c
02d8972c: bl      #0x2b71080                                 fn_2b71080
02d89730: mov     x1, xzr                                    
02d89734: bl      #0x2b70f20                                 fn_2b70f20
## createEffect_Waveform(long[] timings, int repeat) -> UnityEngine.AndroidJavaObject
---- Framework.Vibration::createEffect_Waveform 0x2d89430
02d89430: str     x30, [sp, #-0x30]!                         
02d89434: stp     x22, x21, [sp, #0x10]                      
02d89438: stp     x20, x19, [sp, #0x20]                      
02d8943c: adrp    x22, #0x6630000                            
02d89440: adrp    x20, #0x6267000                            
02d89444: mov     w19, w1                                    
02d89448: ldrb    w8, [x22, #0x4ab]                          
02d8944c: ldr     x20, [x20, #0xea8]                         T:Framework.Vibration
02d89450: mov     x21, x0                                    
02d89454: tbnz    w8, #0, #0x2d89490                         
02d89458: adrp    x0, #0x6266000                             
02d8945c: ldr     x0, [x0, #0x160]                           MS:UnityEngine.AndroidJavaObject::CallStatic
02d89460: bl      #0x2b70db0                                 fn_2b70db0
02d89464: adrp    x0, #0x6263000                             
02d89468: ldr     x0, [x0, #0xa80]                           T:type24502(k1d)
02d8946c: bl      #0x2b70db0                                 fn_2b70db0
02d89470: adrp    x0, #0x6267000                             
02d89474: ldr     x0, [x0, #0xea8]                           T:Framework.Vibration
02d89478: bl      #0x2b70db0                                 fn_2b70db0
02d8947c: adrp    x0, #0x6268000                             
02d89480: ldr     x0, [x0, #0xde0]                           S:'createWaveform'
02d89484: bl      #0x2b70db0                                 fn_2b70db0
02d89488: mov     w8, #1                                     
02d8948c: strb    w8, [x22, #0x4ab]                          
02d89490: ldr     x0, [x20]                                  S:'didu'
02d89494: adrp    x22, #0x6263000                            
02d89498: ldr     w8, [x0, #0xe4]                            [62680e4]=0 f=0,0
02d8949c: ldr     x22, [x22, #0xa80]                         T:type24502(k1d)
02d894a0: cbnz    w8, #0x2d894ac                             
02d894a4: bl      #0x2b70f30                                 fn_2b70f30
02d894a8: ldr     x0, [x20]                                  S:'didu'
02d894ac: ldr     x8, [x0, #0xb8]                            T:LuckyWheelPopup/<>c__DisplayClass54_0
02d894b0: ldr     x0, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d894b4: mov     w1, #2                                     
02d894b8: ldr     x20, [x8, #0x10]                           
02d894bc: bl      #0x2b70ea0                                 fn_2b70ea0
02d894c0: cbz     x0, #0x2d89580                             
02d894c4: mov     x22, x0                                    
02d894c8: cbz     x21, #0x2d894e0                            
02d894cc: ldr     x8, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d894d0: mov     x0, x21                                    
02d894d4: ldr     x1, [x8, #0x40]                            
02d894d8: bl      #0x2b70f34                                 fn_2b70f34
02d894dc: cbz     x0, #0x2d89588                             
02d894e0: ldr     w8, [x22, #0x18]                           &2c5d934(=d65f03c0d503245f)
02d894e4: cbz     w8, #0x2d89584                             
02d894e8: mov     x0, x22                                    
02d894ec: mov     x1, x21                                    
02d894f0: str     x21, [x0, #0x20]!                          .isInitialized
02d894f4: bl      #0x2b70d54                                 fn_2b70d54
02d894f8: adrp    x8, #0x6263000                             
02d894fc: add     x1, sp, #0xc                               
02d89500: ldr     x8, [x8, #0x970]                           &6645c70(=0)
02d89504: str     w19, [sp, #0xc]                            
02d89508: ldr     x0, [x8, #0x48]                            &6263098(=0)
02d8950c: bl      #0x2b70f38                                 fn_2b70f38
02d89510: mov     x19, x0                                    
02d89514: cbz     x0, #0x2d8952c                             
02d89518: ldr     x8, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d8951c: mov     x0, x19                                    
02d89520: ldr     x1, [x8, #0x40]                            [6263040]=0 f=0,0
02d89524: bl      #0x2b70f34                                 fn_2b70f34
02d89528: cbz     x0, #0x2d89588                             
02d8952c: ldr     w8, [x22, #0x18]                           &2c5d934(=d65f03c0d503245f)
02d89530: tst     w8, #0xfffffffe                            
02d89534: b.eq    #0x2d89584                                 
02d89538: mov     x0, x22                                    
02d8953c: mov     x1, x19                                    
02d89540: str     x19, [x0, #0x28]!                          
02d89544: bl      #0x2b70d54                                 fn_2b70d54
02d89548: cbz     x20, #0x2d89580                            
02d8954c: adrp    x8, #0x6268000                             
02d89550: adrp    x9, #0x6266000                             
02d89554: mov     x0, x20                                    
02d89558: ldr     x8, [x8, #0xde0]                           S:'createWaveform'
02d8955c: ldr     x9, [x9, #0x160]                           MS:UnityEngine.AndroidJavaObject::CallStatic
02d89560: mov     x2, x22                                    
02d89564: ldr     x1, [x8]                                   S:'{0}/2'
02d89568: ldr     x3, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d8956c: bl      #0x31200ac                                 fn_31200ac
02d89570: ldp     x20, x19, [sp, #0x20]                      
02d89574: ldp     x22, x21, [sp, #0x10]                      
02d89578: ldr     x30, [sp], #0x30                           
02d8957c: ret                                                
02d89580: bl      #0x2b7105c                                 fn_2b7105c
02d89584: bl      #0x2b71064                                 fn_2b71064
02d89588: bl      #0x2b71080                                 fn_2b71080
02d8958c: mov     x1, xzr                                    
02d89590: bl      #0x2b70f20                                 fn_2b70f20
## logAuto(string text, Framework.Vibration/logLevel level) -> void
---- Framework.Vibration::logAuto 0x2d87980
02d87980: stp     x30, x21, [sp, #-0x20]!                    
02d87984: stp     x20, x19, [sp, #0x10]                      
02d87988: adrp    x21, #0x6630000                            
02d8798c: mov     w20, w1                                    
02d87990: mov     x19, x0                                    
02d87994: ldrb    w8, [x21, #0x4ac]                          
02d87998: tbnz    w8, #0, #0x2d879bc                         
02d8799c: adrp    x0, #0x6263000                             
02d879a0: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02d879a4: bl      #0x2b70db0                                 fn_2b70db0
02d879a8: adrp    x0, #0x6267000                             
02d879ac: ldr     x0, [x0, #0xea8]                           T:Framework.Vibration
02d879b0: bl      #0x2b70db0                                 fn_2b70db0
02d879b4: mov     w8, #1                                     
02d879b8: strb    w8, [x21, #0x4ac]                          
02d879bc: cbz     x19, #0x2d87a88                            
02d879c0: cmp     w20, #1                                    
02d879c4: csinc   w8, w20, wzr, hi                           
02d879c8: cmp     w8, #1                                     
02d879cc: b.eq    #0x2d87a30                                 
02d879d0: cmp     w8, #2                                     
02d879d4: b.ne    #0x2d87a88                                 
02d879d8: adrp    x20, #0x6267000                            
02d879dc: ldr     x20, [x20, #0xea8]                         T:Framework.Vibration
02d879e0: ldr     x0, [x20]                                  S:'didu'
02d879e4: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02d879e8: cbnz    w8, #0x2d879f4                             
02d879ec: bl      #0x2b70f30                                 fn_2b70f30
02d879f0: ldr     x0, [x20]                                  S:'didu'
02d879f4: ldr     x8, [x0, #0xb8]                            M:Framework.SceneUtils/<CRUnloadSceneAsync>d__2::System.Collections.IEnumerator.Reset
02d879f8: ldr     w8, [x8, #4]                               
02d879fc: cmp     w8, #2                                     
02d87a00: b.ne    #0x2d87a88                                 
02d87a04: adrp    x8, #0x6263000                             
02d87a08: ldr     x8, [x8, #0x928]                           T:UnityEngine.Debug
02d87a0c: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02d87a10: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02d87a14: cbnz    w8, #0x2d87a1c                             
02d87a18: bl      #0x2b70f30                                 fn_2b70f30
02d87a1c: mov     x0, x19                                    
02d87a20: ldp     x20, x19, [sp, #0x10]                      
02d87a24: mov     x1, xzr                                    
02d87a28: ldp     x30, x21, [sp], #0x20                      
02d87a2c: b       #0x5af2c94                                 UnityEngine.Debug::LogWarning
02d87a30: adrp    x20, #0x6267000                            
02d87a34: ldr     x20, [x20, #0xea8]                         T:Framework.Vibration
02d87a38: ldr     x0, [x20]                                  S:'didu'
02d87a3c: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02d87a40: cbnz    w8, #0x2d87a4c                             
02d87a44: bl      #0x2b70f30                                 fn_2b70f30
02d87a48: ldr     x0, [x20]                                  S:'didu'
02d87a4c: ldr     x8, [x0, #0xb8]                            M:Framework.SceneUtils/<CRUnloadSceneAsync>d__2::System.Collections.IEnumerator.Reset
02d87a50: ldr     w8, [x8, #4]                               [6263004]=0 f=0,0
02d87a54: cmp     w8, #1                                     
02d87a58: b.lt    #0x2d87a88                                 
02d87a5c: adrp    x8, #0x6263000                             
02d87a60: ldr     x8, [x8, #0x928]                           T:UnityEngine.Debug
02d87a64: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02d87a68: ldr     w8, [x0, #0xe4]                            [62670e4]=0 f=0,0
02d87a6c: cbnz    w8, #0x2d87a74                             
02d87a70: bl      #0x2b70f30                                 fn_2b70f30
02d87a74: mov     x0, x19                                    
02d87a78: ldp     x20, x19, [sp, #0x10]                      
02d87a7c: mov     x1, xzr                                    
02d87a80: ldp     x30, x21, [sp], #0x20                      
02d87a84: b       #0x5af21f4                                 UnityEngine.Debug::Log
02d87a88: ldp     x20, x19, [sp, #0x10]                      
02d87a8c: ldp     x30, x21, [sp], #0x20                      
02d87a90: ret                                                
## arrToStr(long[] array) -> string
---- Framework.Vibration::arrToStr 0x2d89864
02d89864: str     x30, [sp, #-0x20]!                         
02d89868: stp     x20, x19, [sp, #0x10]                      
02d8986c: adrp    x20, #0x6630000                            
02d89870: mov     x19, x0                                    
02d89874: ldrb    w8, [x20, #0x4ad]                          
02d89878: tbnz    w8, #0, #0x2d898a8                         
02d8987c: adrp    x0, #0x6268000                             
02d89880: ldr     x0, [x0, #0xdf0]                           MS:System.String::Join
02d89884: bl      #0x2b70db0                                 fn_2b70db0
02d89888: adrp    x0, #0x6263000                             
02d8988c: ldr     x0, [x0, #0x9b0]                           S:'null'
02d89890: bl      #0x2b70db0                                 fn_2b70db0
02d89894: adrp    x0, #0x6266000                             
02d89898: ldr     x0, [x0, #0x2f8]                           S:', '
02d8989c: bl      #0x2b70db0                                 fn_2b70db0
02d898a0: mov     w8, #1                                     
02d898a4: strb    w8, [x20, #0x4ad]                          
02d898a8: cbz     x19, #0x2d898d4                            
02d898ac: adrp    x8, #0x6266000                             
02d898b0: adrp    x9, #0x6268000                             
02d898b4: mov     x1, x19                                    
02d898b8: ldr     x8, [x8, #0x2f8]                           S:', '
02d898bc: ldr     x9, [x9, #0xdf0]                           MS:System.String::Join
02d898c0: ldp     x20, x19, [sp, #0x10]                      
02d898c4: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d898c8: ldr     x2, [x9]                                   S:'{0}/2'
02d898cc: ldr     x30, [sp], #0x20                           
02d898d0: b       #0x3346e00                                 
02d898d4: adrp    x8, #0x6263000                             
02d898d8: ldr     x8, [x8, #0x9b0]                           S:'null'
02d898dc: ldp     x20, x19, [sp, #0x10]                      
02d898e0: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02d898e4: ldr     x30, [sp], #0x20                           
02d898e8: ret                                                
## arrToStr(int[] array) -> string
---- Framework.Vibration::arrToStr 0x2d898ec
02d898ec: str     x30, [sp, #-0x20]!                         
02d898f0: stp     x20, x19, [sp, #0x10]                      
02d898f4: adrp    x20, #0x6630000                            
02d898f8: mov     x19, x0                                    
02d898fc: ldrb    w8, [x20, #0x4ae]                          
02d89900: tbnz    w8, #0, #0x2d89930                         
02d89904: adrp    x0, #0x6268000                             
02d89908: ldr     x0, [x0, #0xdf8]                           MS:System.String::Join
02d8990c: bl      #0x2b70db0                                 fn_2b70db0
02d89910: adrp    x0, #0x6263000                             
02d89914: ldr     x0, [x0, #0x9b0]                           S:'null'
02d89918: bl      #0x2b70db0                                 fn_2b70db0
02d8991c: adrp    x0, #0x6266000                             
02d89920: ldr     x0, [x0, #0x2f8]                           S:', '
02d89924: bl      #0x2b70db0                                 fn_2b70db0
02d89928: mov     w8, #1                                     
02d8992c: strb    w8, [x20, #0x4ae]                          
02d89930: cbz     x19, #0x2d8995c                            
02d89934: adrp    x8, #0x6266000                             
02d89938: adrp    x9, #0x6268000                             
02d8993c: mov     x1, x19                                    
02d89940: ldr     x8, [x8, #0x2f8]                           S:', '
02d89944: ldr     x9, [x9, #0xdf8]                           MS:System.String::Join
02d89948: ldp     x20, x19, [sp, #0x10]                      
02d8994c: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d89950: ldr     x2, [x9]                                   S:'{0}/2'
02d89954: ldr     x30, [sp], #0x20                           
02d89958: b       #0x3346d28                                 
02d8995c: adrp    x8, #0x6263000                             
02d89960: ldr     x8, [x8, #0x9b0]                           S:'null'
02d89964: ldp     x20, x19, [sp, #0x10]                      
02d89968: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02d8996c: ldr     x30, [sp], #0x20                           
02d89970: ret                                                
## clampAmplitudesArray(int[] amplitudes) -> void
---- Framework.Vibration::clampAmplitudesArray 0x2d88718
02d88718: str     x30, [sp, #-0x10]!                         
02d8871c: cbz     x0, #0x2d88770                             
02d88720: ldr     x9, [x0, #0x18]                            .defaultAmplitude
02d88724: cmp     w9, #1                                     
02d88728: b.lt    #0x2d88764                                 
02d8872c: bic     w8, w9, w9, asr #31                        
02d88730: and     x9, x9, #0xffffffff                        
02d88734: add     x10, x0, #0x20                             
02d88738: mov     w11, #0xff                                 
02d8873c: cbz     x9, #0x2d8876c                             
02d88740: ldr     w12, [x10]                                 
02d88744: sub     x8, x8, #1                                 
02d88748: sub     x9, x9, #1                                 
02d8874c: cmp     w12, #0xff                                 
02d88750: csel    w12, w12, w11, lt                          
02d88754: cmp     w12, #1                                    
02d88758: csinc   w12, w12, wzr, gt                          
02d8875c: str     w12, [x10], #4                             
02d88760: cbnz    x8, #0x2d8873c                             
02d88764: ldr     x30, [sp], #0x10                           
02d88768: ret                                                
02d8876c: bl      #0x2b71064                                 fn_2b71064
02d88770: bl      #0x2b7105c                                 fn_2b7105c
## .cctor() -> void
---- Framework.Vibration::.cctor 0x2d89974
02d89974: str     x30, [sp, #-0x20]!                         
02d89978: stp     x20, x19, [sp, #0x10]                      
02d8997c: adrp    x20, #0x6630000                            
02d89980: adrp    x19, #0x6267000                            
02d89984: ldrb    w8, [x20, #0x4af]                          
02d89988: ldr     x19, [x19, #0xea8]                         T:Framework.Vibration
02d8998c: tbnz    w8, #0, #0x2d899a4                         
02d89990: adrp    x0, #0x6267000                             
02d89994: ldr     x0, [x0, #0xea8]                           T:Framework.Vibration
02d89998: bl      #0x2b70db0                                 fn_2b70db0
02d8999c: mov     w8, #1                                     
02d899a0: strb    w8, [x20, #0x4af]                          
02d899a4: ldr     x8, [x19]                                  S:'didu'
02d899a8: mov     x1, xzr                                    
02d899ac: ldr     x0, [x8, #0xb8]                            
02d899b0: mov     w8, #1                                     
02d899b4: strb    w8, [x0]                                   
02d899b8: str     wzr, [x0, #4]                              
02d899bc: str     xzr, [x0, #8]!                             
02d899c0: bl      #0x2b70d54                                 fn_2b70d54
02d899c4: ldr     x8, [x19]                                  S:'didu'
02d899c8: mov     x1, xzr                                    
02d899cc: ldr     x0, [x8, #0xb8]                            
02d899d0: str     xzr, [x0, #0x10]!                          .vibrationEffectClass
02d899d4: bl      #0x2b70d54                                 fn_2b70d54
02d899d8: ldr     x8, [x19]                                  S:'didu'
02d899dc: adrp    x9, #0x1041000                             
02d899e0: ldr     d0, [x9, #0x2d0]                           [10412d0]=1000000ff f=3.57331e-43,1.4013e-45
02d899e4: ldp     x20, x19, [sp, #0x10]                      
02d899e8: ldr     x8, [x8, #0xb8]                            
02d899ec: str     d0, [x8, #0x18]                            
02d899f0: strb    wzr, [x8, #0x20]                           
02d899f4: ldr     x30, [sp], #0x20                           
02d899f8: ret                                                
02d899fc: stp     x30, x19, [sp, #-0x10]!                    
02d89a00: adrp    x19, #0x662f000                            
02d89a04: ldrb    w8, [x19, #0xbdb]                          
02d89a08: cbnz    w8, #0x2d89a20                             
02d89a0c: adrp    x0, #0x639d000                             
02d89a10: add     x0, x0, #0x1d8                             &639d1d8
02d89a14: bl      #0x2b70db0                                 fn_2b70db0
02d89a18: mov     w8, #1                                     
02d89a1c: strb    w8, [x19, #0xbdb]                          
02d89a20: adrp    x19, #0x639d000                            
02d89a24: add     x19, x19, #0x1d8                           &639d1d8
02d89a28: ldr     x0, [x19]                                  [639d000]=20010d61 f=1.09312e-19,0
02d89a2c: ldr     w8, [x0, #0xe4]                            [639d0e4]=20010e7b00000000 f=0,1.09315e-19
02d89a30: cbnz    w8, #0x2d89a3c                             
02d89a34: bl      #0x2b70f30                                 fn_2b70f30
02d89a38: ldr     x0, [x19]                                  [639d000]=20010d61 f=1.09312e-19,0
02d89a3c: ldr     x8, [x0, #0xb8]                            [639d0b8]=20010e5b f=1.09315e-19,0
02d89a40: ldr     x0, [x8, #0x10]                            
02d89a44: ldp     x30, x19, [sp], #0x10                      
02d89a48: ret                                                
02d89a4c: str     x30, [sp, #-0x30]!                         
02d89a50: stp     x22, x21, [sp, #0x10]                      
02d89a54: stp     x20, x19, [sp, #0x20]                      
02d89a58: ldr     x20, [x0, #0x40]                           [639d040]=20010de1 f=1.09313e-19,0
02d89a5c: mov     x19, x0                                    
02d89a60: cbz     x20, #0x2d89a6c                            
02d89a64: str     xzr, [x19, #0x40]                          
02d89a68: b       #0x2d89ae8                                 
02d89a6c: ldr     x0, [x19, #0x10]                           [639d010]=20010d8d f=1.09312e-19,0 .vibrationEffectClass
02d89a70: cbz     x0, #0x2d89b18                             
02d89a74: ldr     w8, [x0, #0x18]                            [639d018]=20010da5 f=1.09312e-19,0 .defaultAmplitude
02d89a78: cbz     w8, #0x2d89ac0                             
02d89a7c: ldr     x9, [x1, #0x20]                            
02d89a80: sub     w22, w8, #1                                
02d89a84: mov     x21, x1                                    
02d89a88: mov     w1, w22                                    
02d89a8c: ldr     x9, [x9, #0xc0]                            [10410c0]=3c00000003 f=4.2039e-45,8.40779e-44
02d89a90: ldr     x2, [x9, #0x50]                            [1041050]=3 f=4.2039e-45,0
02d89a94: bl      #0x35a8f3c                                 fn_35a8f3c
02d89a98: ldr     x8, [x19, #0x10]                           [639d010]=20010d8d f=1.09312e-19,0 .vibrationEffectClass
02d89a9c: cbz     x8, #0x2d89b18                             
02d89aa0: ldr     x9, [x21, #0x20]                           .isInitialized
02d89aa4: mov     x20, x0                                    
02d89aa8: mov     x0, x8                                     
02d89aac: mov     w1, w22                                    
02d89ab0: ldr     x9, [x9, #0xc0]                            [10410c0]=3c00000003 f=4.2039e-45,8.40779e-44
02d89ab4: ldr     x2, [x9, #0x58]                            [1041058]=b00000001 f=1.4013e-45,1.54143e-44
02d89ab8: bl      #0x35aaa5c                                 fn_35aaa5c
02d89abc: b       #0x2d89ae8                                 
02d89ac0: ldr     x8, [x19, #0x18]                           [639d018]=20010da5 f=1.09312e-19,0 .defaultAmplitude
02d89ac4: cbz     x8, #0x2d89b18                             
02d89ac8: ldr     x9, [x8, #0x18]                            
02d89acc: ldr     x0, [x8, #0x40]                            
02d89ad0: ldr     x1, [x8, #0x28]                            
02d89ad4: blr     x9                                         
02d89ad8: ldr     w8, [x19, #0x48]                           [639d048]=20010def f=1.09313e-19,0
02d89adc: mov     x20, x0                                    
02d89ae0: add     w8, w8, #1                                 
02d89ae4: str     w8, [x19, #0x48]                           
02d89ae8: ldr     x8, [x19, #0x20]                           [639d020]=20010db1 f=1.09313e-19,0 .isInitialized
02d89aec: cbz     x8, #0x2d89b04                             
02d89af0: ldr     x9, [x8, #0x18]                            
02d89af4: ldr     x0, [x8, #0x40]                            
02d89af8: mov     x1, x20                                    
02d89afc: ldr     x2, [x8, #0x28]                            
02d89b00: blr     x9                                         
02d89b04: mov     x0, x20                                    
02d89b08: ldp     x20, x19, [sp, #0x20]                      
02d89b0c: ldp     x22, x21, [sp, #0x10]                      
02d89b10: ldr     x30, [sp], #0x30                           
02d89b14: ret                                                
02d89b18: bl      #0x2b7105c                                 fn_2b7105c
## <Vibrate>g__funcToStr|10_0(Framework.Vibration/<>c__DisplayClass10_0 ) -> string
---- Framework.Vibration::<Vibrate>g__funcToStr|10_0 0x2d87a94
02d87a94: sub     sp, sp, #0x40                              
02d87a98: stp     x30, x23, [sp, #0x10]                      
02d87a9c: stp     x22, x21, [sp, #0x20]                      
02d87aa0: stp     x20, x19, [sp, #0x30]                      
02d87aa4: adrp    x20, #0x6630000                            
02d87aa8: adrp    x22, #0x6268000                            
02d87aac: mov     x19, x0                                    
02d87ab0: ldrb    w8, [x20, #0x4b0]                          
02d87ab4: ldr     x22, [x22, #0xd68]                         S:'Vibrate ({0}, {1}, {2})'
02d87ab8: tbnz    w8, #0, #0x2d87ad0                         
02d87abc: adrp    x0, #0x6268000                             
02d87ac0: ldr     x0, [x0, #0xd68]                           S:'Vibrate ({0}, {1}, {2})'
02d87ac4: bl      #0x2b70db0                                 fn_2b70db0
02d87ac8: mov     w8, #1                                     
02d87acc: strb    w8, [x20, #0x4b0]                          
02d87ad0: adrp    x23, #0x6263000                            
02d87ad4: add     x1, sp, #8                                 
02d87ad8: ldr     x23, [x23, #0x970]                         &6645c70(=0)
02d87adc: ldr     x8, [x19]                                  
02d87ae0: ldr     x0, [x23, #0x68]                           &2c497cc(=d65f03c0d503245f)
02d87ae4: str     x8, [sp, #8]                               
02d87ae8: bl      #0x2b70f38                                 fn_2b70f38
02d87aec: mov     x20, x0                                    
02d87af0: ldr     w8, [x19, #8]                              
02d87af4: ldr     x0, [x23, #0x48]                           &6263098(=0)
02d87af8: add     x1, sp, #4                                 
02d87afc: str     w8, [sp, #4]                               
02d87b00: bl      #0x2b70f38                                 fn_2b70f38
02d87b04: mov     x21, x0                                    
02d87b08: ldrb    w8, [x19, #0xc]                            
02d87b0c: ldr     x0, [x23, #0x28]                           [6263028]=0 f=0,0
02d87b10: mov     x1, sp                                     
02d87b14: strb    w8, [sp]                                   
02d87b18: bl      #0x2b70f38                                 fn_2b70f38
02d87b1c: ldr     x8, [x22]                                  S:'{0}/2'
02d87b20: mov     x3, x0                                     
02d87b24: mov     x1, x20                                    
02d87b28: mov     x2, x21                                    
02d87b2c: mov     x4, xzr                                    
02d87b30: mov     x0, x8                                     
02d87b34: bl      #0x4ca7764                                 System.String::Format
02d87b38: ldp     x20, x19, [sp, #0x30]                      
02d87b3c: ldp     x22, x21, [sp, #0x20]                      
02d87b40: ldp     x30, x23, [sp, #0x10]                      
02d87b44: add     sp, sp, #0x40                              
02d87b48: ret                                                
## <Vibrate>g__funcToStr|11_0(Framework.Vibration/<>c__DisplayClass11_0 ) -> string
---- Framework.Vibration::<Vibrate>g__funcToStr|11_0 0x2d8853c
02d8853c: str     x30, [sp, #-0x30]!                         
02d88540: stp     x22, x21, [sp, #0x10]                      
02d88544: stp     x20, x19, [sp, #0x20]                      
02d88548: adrp    x21, #0x6630000                            
02d8854c: adrp    x22, #0x6263000                            
02d88550: adrp    x19, #0x6267000                            
02d88554: ldrb    w8, [x21, #0x4b1]                          
02d88558: ldr     x22, [x22, #0xa80]                         T:type24502(k1d)
02d8855c: ldr     x19, [x19, #0xea8]                         T:Framework.Vibration
02d88560: mov     x20, x0                                    
02d88564: tbnz    w8, #0, #0x2d88594                         
02d88568: adrp    x0, #0x6263000                             
02d8856c: ldr     x0, [x0, #0xa80]                           T:type24502(k1d)
02d88570: bl      #0x2b70db0                                 fn_2b70db0
02d88574: adrp    x0, #0x6267000                             
02d88578: ldr     x0, [x0, #0xea8]                           T:Framework.Vibration
02d8857c: bl      #0x2b70db0                                 fn_2b70db0
02d88580: adrp    x0, #0x6268000                             
02d88584: ldr     x0, [x0, #0xdb0]                           S:'Vibrate (({0}), ({1}), {2}, {3})'
02d88588: bl      #0x2b70db0                                 fn_2b70db0
02d8858c: mov     w8, #1                                     
02d88590: strb    w8, [x21, #0x4b1]                          
02d88594: ldr     x0, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d88598: mov     w1, #4                                     
02d8859c: bl      #0x2b70ea0                                 fn_2b70ea0
02d885a0: ldr     x8, [x19]                                  S:'didu'
02d885a4: ldr     x21, [x20]                                 
02d885a8: mov     x19, x0                                    
02d885ac: ldr     w9, [x8, #0xe4]                            
02d885b0: cbnz    w9, #0x2d885bc                             
02d885b4: mov     x0, x8                                     
02d885b8: bl      #0x2b70f30                                 fn_2b70f30
02d885bc: mov     x0, x21                                    
02d885c0: bl      #0x2d89864                                 Framework.Vibration::arrToStr
02d885c4: cbz     x19, #0x2d88714                            
02d885c8: mov     x21, x0                                    
02d885cc: cbz     x0, #0x2d885e4                             
02d885d0: ldr     x8, [x19]                                  S:'didu'
02d885d4: mov     x0, x21                                    
02d885d8: ldr     x1, [x8, #0x40]                            
02d885dc: bl      #0x2b70f34                                 fn_2b70f34
02d885e0: cbz     x0, #0x2d88708                             
02d885e4: ldr     w8, [x19, #0x18]                           S:'android.content.Intent' .defaultAmplitude
02d885e8: cbz     w8, #0x2d88704                             
02d885ec: mov     x0, x19                                    
02d885f0: mov     x1, x21                                    
02d885f4: str     x21, [x0, #0x20]!                          .isInitialized
02d885f8: bl      #0x2b70d54                                 fn_2b70d54
02d885fc: ldr     x0, [x20, #8]                              
02d88600: bl      #0x2d898ec                                 Framework.Vibration::arrToStr
02d88604: mov     x21, x0                                    
02d88608: cbz     x0, #0x2d88620                             
02d8860c: ldr     x8, [x19]                                  S:'didu'
02d88610: mov     x0, x21                                    
02d88614: ldr     x1, [x8, #0x40]                            
02d88618: bl      #0x2b70f34                                 fn_2b70f34
02d8861c: cbz     x0, #0x2d88708                             
02d88620: ldr     w8, [x19, #0x18]                           S:'android.content.Intent' .defaultAmplitude
02d88624: tst     w8, #0xfffffffe                            
02d88628: b.eq    #0x2d88704                                 
02d8862c: mov     x0, x19                                    
02d88630: mov     x1, x21                                    
02d88634: str     x21, [x0, #0x28]!                          
02d88638: bl      #0x2b70d54                                 fn_2b70d54
02d8863c: adrp    x22, #0x6263000                            
02d88640: add     x1, sp, #0xc                               
02d88644: ldr     x22, [x22, #0x970]                         &6645c70(=0)
02d88648: ldr     w8, [x20, #0x10]                           .vibrationEffectClass
02d8864c: ldr     x0, [x22, #0x48]                           &6263098(=0)
02d88650: str     w8, [sp, #0xc]                             
02d88654: bl      #0x2b70f38                                 fn_2b70f38
02d88658: mov     x21, x0                                    
02d8865c: cbz     x0, #0x2d88674                             
02d88660: ldr     x8, [x19]                                  S:'didu'
02d88664: mov     x0, x21                                    
02d88668: ldr     x1, [x8, #0x40]                            
02d8866c: bl      #0x2b70f34                                 fn_2b70f34
02d88670: cbz     x0, #0x2d88708                             
02d88674: ldr     w8, [x19, #0x18]                           S:'android.content.Intent' .defaultAmplitude
02d88678: cmp     w8, #2                                     
02d8867c: b.ls    #0x2d88704                                 
02d88680: mov     x0, x19                                    
02d88684: mov     x1, x21                                    
02d88688: str     x21, [x0, #0x30]!                          
02d8868c: bl      #0x2b70d54                                 fn_2b70d54
02d88690: ldrb    w8, [x20, #0x14]                           
02d88694: ldr     x0, [x22, #0x28]                           [6263028]=0 f=0,0
02d88698: add     x1, sp, #8                                 
02d8869c: strb    w8, [sp, #8]                               
02d886a0: bl      #0x2b70f38                                 fn_2b70f38
02d886a4: mov     x20, x0                                    
02d886a8: cbz     x0, #0x2d886c0                             
02d886ac: ldr     x8, [x19]                                  S:'didu'
02d886b0: mov     x0, x20                                    
02d886b4: ldr     x1, [x8, #0x40]                            
02d886b8: bl      #0x2b70f34                                 fn_2b70f34
02d886bc: cbz     x0, #0x2d88708                             
02d886c0: ldr     w8, [x19, #0x18]                           S:'android.content.Intent' .defaultAmplitude
02d886c4: tst     w8, #0xfffffffc                            
02d886c8: b.eq    #0x2d88704                                 
02d886cc: adrp    x21, #0x6268000                            
02d886d0: mov     x0, x19                                    
02d886d4: mov     x1, x20                                    
02d886d8: ldr     x21, [x21, #0xdb0]                         S:'Vibrate (({0}), ({1}), {2}, {3})'
02d886dc: str     x20, [x0, #0x38]!                          
02d886e0: bl      #0x2b70d54                                 fn_2b70d54
02d886e4: ldr     x0, [x21]                                  S:'{0}/2'
02d886e8: mov     x1, x19                                    
02d886ec: mov     x2, xzr                                    
02d886f0: bl      #0x4ca77a8                                 System.String::Format
02d886f4: ldp     x20, x19, [sp, #0x20]                      
02d886f8: ldp     x22, x21, [sp, #0x10]                      
02d886fc: ldr     x30, [sp], #0x30                           
02d88700: ret                                                
02d88704: bl      #0x2b71064                                 fn_2b71064
02d88708: bl      #0x2b71080                                 fn_2b71080
02d8870c: mov     x1, xzr                                    
02d88710: bl      #0x2b70f20                                 fn_2b70f20
02d88714: bl      #0x2b7105c                                 fn_2b7105c
## <VibratePredefined>g__funcToStr|12_0(Framework.Vibration/<>c__DisplayClass12_0 ) -> string
---- Framework.Vibration::<VibratePredefined>g__funcToStr|12_0 0x2d88e5c
02d88e5c: sub     sp, sp, #0x30                              
02d88e60: stp     x30, x21, [sp, #0x10]                      
02d88e64: stp     x20, x19, [sp, #0x20]                      
02d88e68: adrp    x21, #0x6630000                            
02d88e6c: adrp    x20, #0x6268000                            
02d88e70: mov     x19, x0                                    
02d88e74: ldrb    w8, [x21, #0x4b2]                          
02d88e78: ldr     x20, [x20, #0xdc8]                         S:'VibratePredefined ({0})'
02d88e7c: tbnz    w8, #0, #0x2d88e94                         
02d88e80: adrp    x0, #0x6268000                             
02d88e84: ldr     x0, [x0, #0xdc8]                           S:'VibratePredefined ({0})'
02d88e88: bl      #0x2b70db0                                 fn_2b70db0
02d88e8c: mov     w8, #1                                     
02d88e90: strb    w8, [x21, #0x4b2]                          
02d88e94: adrp    x8, #0x6263000                             
02d88e98: add     x1, sp, #0xc                               
02d88e9c: ldr     x8, [x8, #0x970]                           &6645c70(=0)
02d88ea0: ldr     w9, [x19]                                  
02d88ea4: ldr     x0, [x8, #0x48]                            &6263098(=0)
02d88ea8: str     w9, [sp, #0xc]                             
02d88eac: bl      #0x2b70f38                                 fn_2b70f38
02d88eb0: ldr     x8, [x20]                                  S:'{0}/2'
02d88eb4: mov     x1, x0                                     
02d88eb8: mov     x2, xzr                                    
02d88ebc: mov     x0, x8                                     
02d88ec0: bl      #0x4c9d0ec                                 System.String::Format
02d88ec4: ldp     x20, x19, [sp, #0x20]                      
02d88ec8: ldp     x30, x21, [sp, #0x10]                      
02d88ecc: add     sp, sp, #0x30                              
02d88ed0: ret                                                
