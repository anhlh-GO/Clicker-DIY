#### CLASS BlindBagCollection.SellItem parent= UnityEngine.MonoBehaviour
#   field _itemImage                     UnityEngine.UI.Image                               off=0x20 attr=1 SerializeField
#   field _priceText                     TMPro.TMP_Text                                     off=0x28 attr=1 SerializeField
#   field _countText                     TMPro.TextMeshProUGUI                              off=0x30 attr=1 SerializeField
#   field _count                         int                                                off=0x38 attr=1 
## get_ItemSprite() -> UnityEngine.Sprite
---- BlindBagCollection.SellItem::get_ItemSprite 0x2d30fec
02d30fec: ldr     x8, [x0, #0x20]                            ._itemImage
02d30ff0: cbz     x8, #0x2d30ffc                             
02d30ff4: ldr     x0, [x8, #0xd8]                            
02d30ff8: ret                                                
02d30ffc: str     x30, [sp, #-0x10]!                         
02d31000: bl      #0x2b7105c                                 fn_2b7105c
## SetItem(UnityEngine.Sprite itemSprite, int price) -> void
---- BlindBagCollection.SellItem::SetItem 0x2d30a08
02d30a08: sub     sp, sp, #0x30                              
02d30a0c: stp     x30, x21, [sp, #0x10]                      
02d30a10: stp     x20, x19, [sp, #0x20]                      
02d30a14: adrp    x21, #0x6630000                            
02d30a18: mov     x20, x1                                    
02d30a1c: mov     x19, x0                                    
02d30a20: ldrb    w8, [x21, #0x154]                          
02d30a24: str     w2, [sp, #0xc]                             
02d30a28: tbnz    w8, #0, #0x2d30a40                         
02d30a2c: adrp    x0, #0x6267000                             
02d30a30: ldr     x0, [x0, #0x300]                           S:'x'
02d30a34: bl      #0x2b70db0                                 fn_2b70db0
02d30a38: mov     w8, #1                                     
02d30a3c: strb    w8, [x21, #0x154]                          
02d30a40: ldr     x0, [x19, #0x20]                           ._itemImage
02d30a44: cbz     x0, #0x2d30ae0                             
02d30a48: mov     x1, x20                                    
02d30a4c: mov     x2, xzr                                    
02d30a50: bl      #0x5c45aa0                                 UnityEngine.UI.Image::set_sprite
02d30a54: ldr     x20, [x19, #0x28]                          ._priceText
02d30a58: add     x0, sp, #0xc                               
02d30a5c: mov     x1, xzr                                    
02d30a60: bl      #0x4e0ea3c                                 System.Int32::ToString
02d30a64: cbz     x20, #0x2d30ae0                            
02d30a68: ldr     x8, [x20]                                  
02d30a6c: adrp    x21, #0x6267000                            
02d30a70: mov     x1, x0                                     
02d30a74: ldr     x21, [x21, #0x300]                         S:'x'
02d30a78: mov     x0, x20                                    
02d30a7c: ldr     x9, [x8, #0x558]                           
02d30a80: ldr     x2, [x8, #0x560]                           
02d30a84: blr     x9                                         
02d30a88: mov     w8, #1                                     
02d30a8c: mov     x1, xzr                                    
02d30a90: str     w8, [x19, #0x38]!                          ._count
02d30a94: ldur    x20, [x19, #-8]                            
02d30a98: mov     x0, x19                                    
02d30a9c: bl      #0x4e0ea3c                                 System.Int32::ToString
02d30aa0: ldr     x8, [x21]                                  S:'didu'
02d30aa4: mov     x1, x0                                     
02d30aa8: mov     x2, xzr                                    
02d30aac: mov     x0, x8                                     
02d30ab0: bl      #0x4c9c514                                 System.String::Concat
02d30ab4: cbz     x20, #0x2d30ae0                            
02d30ab8: ldr     x8, [x20]                                  
02d30abc: mov     x1, x0                                     
02d30ac0: mov     x0, x20                                    
02d30ac4: ldr     x9, [x8, #0x558]                           
02d30ac8: ldr     x2, [x8, #0x560]                           
02d30acc: blr     x9                                         
02d30ad0: ldp     x20, x19, [sp, #0x20]                      
02d30ad4: ldp     x30, x21, [sp, #0x10]                      
02d30ad8: add     sp, sp, #0x30                              
02d30adc: ret                                                
02d30ae0: bl      #0x2b7105c                                 fn_2b7105c
## AddDuplicate() -> void
---- BlindBagCollection.SellItem::AddDuplicate 0x2d3097c
02d3097c: stp     x30, x21, [sp, #-0x20]!                    
02d30980: stp     x20, x19, [sp, #0x10]                      
02d30984: adrp    x19, #0x6630000                            
02d30988: adrp    x21, #0x6267000                            
02d3098c: mov     x20, x0                                    
02d30990: ldrb    w8, [x19, #0x155]                          
02d30994: ldr     x21, [x21, #0x300]                         S:'x'
02d30998: tbnz    w8, #0, #0x2d309b0                         
02d3099c: adrp    x0, #0x6267000                             
02d309a0: ldr     x0, [x0, #0x300]                           S:'x'
02d309a4: bl      #0x2b70db0                                 fn_2b70db0
02d309a8: mov     w8, #1                                     
02d309ac: strb    w8, [x19, #0x155]                          
02d309b0: ldr     w8, [x20, #0x38]!                          ._count
02d309b4: ldur    x19, [x20, #-8]                            
02d309b8: mov     x0, x20                                    
02d309bc: mov     x1, xzr                                    
02d309c0: add     w8, w8, #1                                 
02d309c4: str     w8, [x20]                                  
02d309c8: bl      #0x4e0ea3c                                 System.Int32::ToString
02d309cc: ldr     x8, [x21]                                  S:'didu'
02d309d0: mov     x1, x0                                     
02d309d4: mov     x2, xzr                                    
02d309d8: mov     x0, x8                                     
02d309dc: bl      #0x4c9c514                                 System.String::Concat
02d309e0: cbz     x19, #0x2d30a04                            
02d309e4: ldr     x8, [x19]                                  
02d309e8: mov     x1, x0                                     
02d309ec: mov     x0, x19                                    
02d309f0: ldp     x20, x19, [sp, #0x10]                      
02d309f4: ldr     x2, [x8, #0x560]                           
02d309f8: ldr     x3, [x8, #0x558]                           
02d309fc: ldp     x30, x21, [sp], #0x20                      
02d30a00: br      x3                                         
02d30a04: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- BlindBagCollection.SellItem::.ctor 0x2d3bad0
02d3bad0: mov     x1, xzr                                    
02d3bad4: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
