#### CLASS RateApp parent= object
## CallRateInApp() -> void
---- RateApp::CallRateInApp 0x2ca4350
02ca4350: ret                                                
## CallRateApp() -> void
---- RateApp::CallRateApp 0x2ca38bc
02ca38bc: str     x30, [sp, #-0x20]!                         
02ca38c0: stp     x20, x19, [sp, #0x10]                      
02ca38c4: adrp    x20, #0x662f000                            
02ca38c8: adrp    x19, #0x6264000                            
02ca38cc: ldrb    w8, [x20, #0xac7]                          
02ca38d0: ldr     x19, [x19, #0xa70]                         T:UnityEngine.Application
02ca38d4: tbnz    w8, #0, #0x2ca38f8                         
02ca38d8: adrp    x0, #0x6264000                             
02ca38dc: ldr     x0, [x0, #0xa70]                           T:UnityEngine.Application
02ca38e0: bl      #0x2b70db0                                 fn_2b70db0
02ca38e4: adrp    x0, #0x6266000                             
02ca38e8: ldr     x0, [x0, #0x110]                           S:'https://play.google.com/store/apps/details?id='
02ca38ec: bl      #0x2b70db0                                 fn_2b70db0
02ca38f0: mov     w8, #1                                     
02ca38f4: strb    w8, [x20, #0xac7]                          
02ca38f8: ldr     x0, [x19]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca38fc: adrp    x19, #0x6266000                            
02ca3900: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02ca3904: ldr     x19, [x19, #0x110]                         S:'https://play.google.com/store/apps/details?id='
02ca3908: cbnz    w8, #0x2ca3910                             
02ca390c: bl      #0x2b70f30                                 fn_2b70f30
02ca3910: mov     x0, xzr                                    
02ca3914: bl      #0x5aeac78                                 UnityEngine.Application::get_identifier
02ca3918: ldr     x8, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca391c: mov     x1, x0                                     
02ca3920: mov     x2, xzr                                    
02ca3924: mov     x0, x8                                     
02ca3928: bl      #0x4c9c514                                 System.String::Concat
02ca392c: ldp     x20, x19, [sp, #0x10]                      
02ca3930: mov     x1, xzr                                    
02ca3934: ldr     x30, [sp], #0x20                           
02ca3938: b       #0x5aeaf10                                 UnityEngine.Application::OpenURL
