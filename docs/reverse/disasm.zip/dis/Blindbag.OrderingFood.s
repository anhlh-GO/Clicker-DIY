#### CLASS Blindbag.OrderingFood/<>c__DisplayClass24_0 parent= object
#   field onCompleted                    System.Action                                      off=0x10 attr=6 
## .ctor() -> void
---- Blindbag.OrderingFood/<>c__DisplayClass24_0::.ctor 0x2d55144
02d55144: mov     x1, xzr                                    
02d55148: b       #0x4e53e9c                                 System.Object::.ctor
## <FadeOut>b__0() -> void
---- Blindbag.OrderingFood/<>c__DisplayClass24_0::<FadeOut>b__0 0x2d5566c
02d5566c: ldr     x8, [x0, #0x10]                            .onCompleted
02d55670: cbz     x8, #0x2d55684                             
02d55674: ldr     x0, [x8, #0x40]                            
02d55678: ldr     x1, [x8, #0x28]                            
02d5567c: ldr     x2, [x8, #0x18]                            
02d55680: br      x2                                         
02d55684: ret                                                
#### CLASS Blindbag.OrderingFood parent= PoolElement
#   field _isTriggered                   bool                                               off=0x28 attr=1 SerializeField
#   field _food                          UnityEngine.SpriteRenderer                         off=0x30 attr=1 SerializeField
#   field OnScanItem                     System.Action`1<Blindbag.OrderingFood>             off=0x38 attr=6 
#   field _id                            int                                                off=0x40 attr=1 
#   field _foodName                      string                                             off=0x48 attr=1 
#   field _price                         int                                                off=0x50 attr=1 
#   field _target                        UnityEngine.Transform                              off=0x58 attr=1 
#   field _cachedEuler                   UnityEngine.Vector3                                off=0x60 attr=1 
#   field _cachedPosition                UnityEngine.Vector3                                off=0x6c attr=1 
#   field _mainCamera                    UnityEngine.Camera                                 off=0x78 attr=1 
#   field _dragSpeed                     float                                              off=0x80 attr=1 
## get_Id() -> int
---- Blindbag.OrderingFood::get_Id 0x2d54ea0
02d54ea0: ldr     w0, [x0, #0x40]                            ._id
02d54ea4: ret                                                
## get_Price() -> int
---- Blindbag.OrderingFood::get_Price 0x2d54ea8
02d54ea8: ldr     w0, [x0, #0x50]                            ._price
02d54eac: ret                                                
## get_FoodName() -> string
---- Blindbag.OrderingFood::get_FoodName 0x2d54eb0
02d54eb0: ldr     x0, [x0, #0x48]                            ._foodName
02d54eb4: ret                                                
## get_Visual() -> UnityEngine.Sprite
---- Blindbag.OrderingFood::get_Visual 0x2d54eb8
02d54eb8: ldr     x0, [x0, #0x30]                            ._food
02d54ebc: cbz     x0, #0x2d54ec8                             
02d54ec0: mov     x1, xzr                                    
02d54ec4: b       #0x5ae6cfc                                 UnityEngine.SpriteRenderer::get_sprite
02d54ec8: str     x30, [sp, #-0x10]!                         
02d54ecc: bl      #0x2b7105c                                 fn_2b7105c
## get_HalfHeight() -> float
---- Blindbag.OrderingFood::get_HalfHeight 0x2d54ed0
02d54ed0: str     x30, [sp, #-0x10]!                         
02d54ed4: ldr     x0, [x0, #0x30]                            ._food
02d54ed8: cbz     x0, #0x2d54ef4                             
02d54edc: mov     x1, xzr                                    
02d54ee0: bl      #0x5ae6f78                                 UnityEngine.SpriteRenderer::get_size
02d54ee4: fmov    s0, #0.50000000                            
02d54ee8: fmul    s0, s1, s0                                 
02d54eec: ldr     x30, [sp], #0x10                           
02d54ef0: ret                                                
02d54ef4: bl      #0x2b7105c                                 fn_2b7105c
## get_HalfWidth() -> float
---- Blindbag.OrderingFood::get_HalfWidth 0x2d54ef8
02d54ef8: str     x30, [sp, #-0x10]!                         
02d54efc: ldr     x0, [x0, #0x30]                            ._food
02d54f00: cbz     x0, #0x2d54f1c                             
02d54f04: mov     x1, xzr                                    
02d54f08: bl      #0x5ae6f78                                 UnityEngine.SpriteRenderer::get_size
02d54f0c: fmov    s1, #0.50000000                            
02d54f10: fmul    s0, s0, s1                                 
02d54f14: ldr     x30, [sp], #0x10                           
02d54f18: ret                                                
02d54f1c: bl      #0x2b7105c                                 fn_2b7105c
## OnDespawned() -> void
---- Blindbag.OrderingFood::OnDespawned 0x2d54f20
02d54f20: stp     x30, x19, [sp, #-0x10]!                    
02d54f24: mov     x19, x0                                    
02d54f28: bl      #0x2d54f4c                                 Blindbag.OrderingFood::RemoveCollider
02d54f2c: mov     x0, x19                                    
02d54f30: mov     x1, xzr                                    
02d54f34: str     xzr, [x0, #0x38]!                          .OnScanItem
02d54f38: bl      #0x2b70d54                                 fn_2b70d54
02d54f3c: mov     x0, x19                                    
02d54f40: mov     x1, xzr                                    
02d54f44: ldp     x30, x19, [sp], #0x10                      
02d54f48: b       #0x2cdcae4                                 PoolElement::OnDespawned
## FadeOut(float duration, System.Action onCompleted) -> void
---- Blindbag.OrderingFood::FadeOut 0x2d5500c
02d5500c: str     d8, [sp, #-0x40]!                          
02d55010: stp     x30, x23, [sp, #0x10]                      
02d55014: stp     x22, x21, [sp, #0x20]                      
02d55018: stp     x20, x19, [sp, #0x30]                      
02d5501c: fmov    s8, s0                                     
02d55020: adrp    x20, #0x6630000                            
02d55024: adrp    x22, #0x626b000                            
02d55028: ldrb    w8, [x20, #0x26f]                          
02d5502c: ldr     x22, [x22, #0x9a8]                         T:Blindbag.OrderingFood/<>c__DisplayClass24_0
02d55030: mov     x21, x1                                    
02d55034: mov     x19, x0                                    
02d55038: tbnz    w8, #0, #0x2d55074                         
02d5503c: adrp    x0, #0x6264000                             
02d55040: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d55044: bl      #0x2b70db0                                 fn_2b70db0
02d55048: adrp    x0, #0x6266000                             
02d5504c: ldr     x0, [x0, #0xcb0]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d55050: bl      #0x2b70db0                                 fn_2b70db0
02d55054: adrp    x0, #0x626b000                             
02d55058: ldr     x0, [x0, #0x9b0]                           M:Blindbag.OrderingFood/<>c__DisplayClass24_0::<FadeOut>b__0
02d5505c: bl      #0x2b70db0                                 fn_2b70db0
02d55060: adrp    x0, #0x626b000                             
02d55064: ldr     x0, [x0, #0x9a8]                           T:Blindbag.OrderingFood/<>c__DisplayClass24_0
02d55068: bl      #0x2b70db0                                 fn_2b70db0
02d5506c: mov     w8, #1                                     
02d55070: strb    w8, [x20, #0x26f]                          
02d55074: ldr     x0, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d55078: bl      #0x2b7104c                                 fn_2b7104c
02d5507c: mov     x1, xzr                                    
02d55080: mov     x20, x0                                    
02d55084: bl      #0x4e53e9c                                 System.Object::.ctor
02d55088: cbz     x20, #0x2d55140                            
02d5508c: mov     x0, x20                                    
02d55090: mov     x1, x21                                    
02d55094: str     x21, [x0, #0x10]!                          
02d55098: bl      #0x2b70d54                                 fn_2b70d54
02d5509c: ldr     x0, [x19, #0x30]                           ._food
02d550a0: mov     w1, wzr                                    
02d550a4: mov     x2, xzr                                    
02d550a8: bl      #0x2d9d5d0                                 DG.Tweening.ShortcutExtensions::DOKill
02d550ac: ldr     x0, [x19, #0x30]                           ._food
02d550b0: cbz     x0, #0x2d55140                             
02d550b4: adrp    x21, #0x6264000                            
02d550b8: adrp    x22, #0x626b000                            
02d550bc: adrp    x23, #0x6266000                            
02d550c0: ldr     x21, [x21, #0xe8]                          T:DG.Tweening.TweenCallback
02d550c4: ldr     x22, [x22, #0x9b0]                         M:Blindbag.OrderingFood/<>c__DisplayClass24_0::<FadeOut>b__0
02d550c8: ldr     x23, [x23, #0xcb0]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d550cc: mov     x1, xzr                                    
02d550d0: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d550d4: fmov    s1, s8                                     
02d550d8: fmov    s0, #5.00000000                            
02d550dc: mov     w1, wzr                                    
02d550e0: mov     x2, xzr                                    
02d550e4: bl      #0x2d98060                                 DG.Tweening.ShortcutExtensions::DOLocalMoveY
02d550e8: movi    d0, #0000000000000000                      
02d550ec: fmov    s1, s8                                     
02d550f0: ldr     x0, [x19, #0x30]                           ._food
02d550f4: mov     x1, xzr                                    
02d550f8: bl      #0x2c77d0c                                 DG.Tweening.DOTweenModuleSprite::DOFade
02d550fc: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d55100: mov     x19, x0                                    
02d55104: mov     x0, x8                                     
02d55108: bl      #0x2b7104c                                 fn_2b7104c
02d5510c: ldr     x2, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d55110: mov     x1, x20                                    
02d55114: mov     x3, xzr                                    
02d55118: mov     x21, x0                                    
02d5511c: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d55120: ldr     x2, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d55124: mov     x0, x19                                    
02d55128: mov     x1, x21                                    
02d5512c: ldp     x20, x19, [sp, #0x30]                      
02d55130: ldp     x22, x21, [sp, #0x20]                      
02d55134: ldp     x30, x23, [sp, #0x10]                      
02d55138: ldr     d8, [sp], #0x40                            
02d5513c: b       #0x336f26c                                 
02d55140: bl      #0x2b7105c                                 fn_2b7105c
## SetSprite(UnityEngine.Sprite sprite) -> void
---- Blindbag.OrderingFood::SetSprite 0x2d5514c
02d5514c: ldr     x0, [x0, #0x30]                            ._food
02d55150: cbz     x0, #0x2d5515c                             
02d55154: mov     x2, xzr                                    
02d55158: b       #0x5ae6dcc                                 UnityEngine.SpriteRenderer::set_sprite
02d5515c: str     x30, [sp, #-0x10]!                         
02d55160: bl      #0x2b7105c                                 fn_2b7105c
## SetData(string foodName, int price, int id) -> void
---- Blindbag.OrderingFood::SetData 0x2d55164
02d55164: stp     x30, x21, [sp, #-0x20]!                    
02d55168: stp     x20, x19, [sp, #0x10]                      
02d5516c: mov     x21, x0                                    
02d55170: mov     w19, w3                                    
02d55174: mov     w20, w2                                    
02d55178: str     x1, [x21, #0x48]!                          ._foodName
02d5517c: mov     x0, x21                                    
02d55180: bl      #0x2b70d54                                 fn_2b70d54
02d55184: str     w20, [x21, #8]                             
02d55188: stur    w19, [x21, #-8]                            
02d5518c: ldp     x20, x19, [sp, #0x10]                      
02d55190: ldp     x30, x21, [sp], #0x20                      
02d55194: ret                                                
## AddCollider() -> void
---- Blindbag.OrderingFood::AddCollider 0x2d55198
02d55198: str     x30, [sp, #-0x20]!                         
02d5519c: stp     x20, x19, [sp, #0x10]                      
02d551a0: adrp    x20, #0x6630000                            
02d551a4: mov     x19, x0                                    
02d551a8: ldrb    w8, [x20, #0x270]                          
02d551ac: tbnz    w8, #0, #0x2d551c4                         
02d551b0: adrp    x0, #0x626b000                             
02d551b4: ldr     x0, [x0, #0x7c8]                           MS:UnityEngine.GameObject::AddComponent
02d551b8: bl      #0x2b70db0                                 fn_2b70db0
02d551bc: mov     w8, #1                                     
02d551c0: strb    w8, [x20, #0x270]                          
02d551c4: mov     x0, x19                                    
02d551c8: bl      #0x2d54f4c                                 Blindbag.OrderingFood::RemoveCollider
02d551cc: mov     x0, x19                                    
02d551d0: mov     x1, xzr                                    
02d551d4: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d551d8: cbz     x0, #0x2d551f4                             
02d551dc: adrp    x8, #0x626b000                             
02d551e0: ldr     x8, [x8, #0x7c8]                           MS:UnityEngine.GameObject::AddComponent
02d551e4: ldp     x20, x19, [sp, #0x10]                      
02d551e8: ldr     x1, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d551ec: ldr     x30, [sp], #0x20                           
02d551f0: b       #0x31d1114                                 
02d551f4: bl      #0x2b7105c                                 fn_2b7105c
## RemoveCollider() -> void
---- Blindbag.OrderingFood::RemoveCollider 0x2d54f4c
02d54f4c: str     x30, [sp, #-0x20]!                         
02d54f50: stp     x20, x19, [sp, #0x10]                      
02d54f54: adrp    x20, #0x6630000                            
02d54f58: mov     x19, x0                                    
02d54f5c: ldrb    w8, [x20, #0x271]                          
02d54f60: tbnz    w8, #0, #0x2d54f84                         
02d54f64: adrp    x0, #0x626b000                             
02d54f68: ldr     x0, [x0, #0x3c8]                           MS:UnityEngine.GameObject::GetComponent
02d54f6c: bl      #0x2b70db0                                 fn_2b70db0
02d54f70: adrp    x0, #0x6263000                             
02d54f74: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d54f78: bl      #0x2b70db0                                 fn_2b70db0
02d54f7c: mov     w8, #1                                     
02d54f80: strb    w8, [x20, #0x271]                          
02d54f84: mov     x0, x19                                    
02d54f88: mov     x1, xzr                                    
02d54f8c: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d54f90: cbz     x0, #0x2d55008                             
02d54f94: adrp    x8, #0x626b000                             
02d54f98: adrp    x20, #0x6263000                            
02d54f9c: ldr     x8, [x8, #0x3c8]                           MS:UnityEngine.GameObject::GetComponent
02d54fa0: ldr     x20, [x20, #0x918]                         T:UnityEngine.Object
02d54fa4: ldr     x1, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d54fa8: bl      #0x31d11a4                                 fn_31d11a4
02d54fac: ldr     x8, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d54fb0: mov     x19, x0                                    
02d54fb4: ldr     w9, [x8, #0xe4]                            [626b0e4]=0 f=0,0
02d54fb8: cbnz    w9, #0x2d54fc4                             
02d54fbc: mov     x0, x8                                     
02d54fc0: bl      #0x2b70f30                                 fn_2b70f30
02d54fc4: mov     x0, x19                                    
02d54fc8: mov     x1, xzr                                    
02d54fcc: mov     x2, xzr                                    
02d54fd0: bl      #0x5b3666c                                 UnityEngine.Object::op_Inequality
02d54fd4: tbz     w0, #0, #0x2d54ffc                         
02d54fd8: ldr     x0, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d54fdc: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d54fe0: cbnz    w8, #0x2d54fe8                             
02d54fe4: bl      #0x2b70f30                                 fn_2b70f30
02d54fe8: mov     x0, x19                                    
02d54fec: ldp     x20, x19, [sp, #0x10]                      
02d54ff0: mov     x1, xzr                                    
02d54ff4: ldr     x30, [sp], #0x20                           
02d54ff8: b       #0x5b3ca38                                 UnityEngine.Object::Destroy
02d54ffc: ldp     x20, x19, [sp, #0x10]                      
02d55000: ldr     x30, [sp], #0x20                           
02d55004: ret                                                
02d55008: bl      #0x2b7105c                                 fn_2b7105c
## OnMouseButtonDown() -> void
---- Blindbag.OrderingFood::OnMouseButtonDown 0x2d551f8
02d551f8: str     x30, [sp, #-0x20]!                         
02d551fc: stp     x20, x19, [sp, #0x10]                      
02d55200: mov     x1, xzr                                    
02d55204: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d55208: adrp    x20, #0x662f000                            
02d5520c: mov     x19, x0                                    
02d55210: ldrb    w8, [x20, #0x91a]                          
02d55214: cbnz    w8, #0x2d5522c                             
02d55218: adrp    x0, #0x6264000                             
02d5521c: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d55220: bl      #0x2b70db0                                 fn_2b70db0
02d55224: mov     w8, #1                                     
02d55228: strb    w8, [x20, #0x91a]                          
02d5522c: cbz     x19, #0x2d5525c                            
02d55230: adrp    x8, #0x6264000                             
02d55234: mov     x0, x19                                    
02d55238: mov     x1, xzr                                    
02d5523c: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02d55240: ldp     x20, x19, [sp, #0x10]                      
02d55244: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d55248: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d5524c: ldp     s0, s1, [x8]                               
02d55250: ldr     s2, [x8, #8]                               T:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0
02d55254: ldr     x30, [sp], #0x20                           
02d55258: b       #0x5b46c88                                 UnityEngine.Transform::set_localEulerAngles
02d5525c: bl      #0x2b7105c                                 fn_2b7105c
## OnMouseButtonDrag() -> void
---- Blindbag.OrderingFood::OnMouseButtonDrag 0x2d55260
02d55260: stp     d13, d12, [sp, #-0x50]!                    
02d55264: stp     d11, d10, [sp, #0x10]                      
02d55268: stp     d9, d8, [sp, #0x20]                        
02d5526c: str     x30, [sp, #0x30]                           
02d55270: stp     x20, x19, [sp, #0x40]                      
02d55274: adrp    x20, #0x6630000                            
02d55278: mov     x19, x0                                    
02d5527c: ldrb    w8, [x20, #0x272]                          
02d55280: tbnz    w8, #0, #0x2d55298                         
02d55284: adrp    x0, #0x6266000                             
02d55288: ldr     x0, [x0, #0x938]                           MS:UnityEngine.InputSystem.InputControl`1::ReadValue
02d5528c: bl      #0x2b70db0                                 fn_2b70db0
02d55290: mov     w8, #1                                     
02d55294: strb    w8, [x20, #0x272]                          
02d55298: ldrb    w8, [x19, #0x28]                           ._isTriggered
02d5529c: cbz     w8, #0x2d552b8                             
02d552a0: ldp     x20, x19, [sp, #0x40]                      
02d552a4: ldr     x30, [sp, #0x30]                           
02d552a8: ldp     d9, d8, [sp, #0x20]                        
02d552ac: ldp     d11, d10, [sp, #0x10]                      
02d552b0: ldp     d13, d12, [sp], #0x50                      
02d552b4: ret                                                
02d552b8: adrp    x20, #0x662f000                            
02d552bc: ldrb    w8, [x20, #0xbd9]                          
02d552c0: cbnz    w8, #0x2d552d8                             
02d552c4: adrp    x0, #0x6266000                             
02d552c8: ldr     x0, [x0, #0x950]                           T:UnityEngine.InputSystem.Pointer
02d552cc: bl      #0x2b70db0                                 fn_2b70db0
02d552d0: mov     w8, #1                                     
02d552d4: strb    w8, [x20, #0xbd9]                          
02d552d8: adrp    x8, #0x6266000                             
02d552dc: ldr     x8, [x8, #0x950]                           T:UnityEngine.InputSystem.Pointer
02d552e0: ldr     x8, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d552e4: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02d552e8: ldr     x8, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d552ec: cbz     x8, #0x2d552a0                             
02d552f0: ldr     x0, [x8, #0x188]                           S:'makeText'
02d552f4: cbz     x0, #0x2d55494                             
02d552f8: adrp    x8, #0x6266000                             
02d552fc: ldr     x8, [x8, #0x938]                           MS:UnityEngine.InputSystem.InputControl`1::ReadValue
02d55300: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d55304: bl      #0x4a187c4                                 fn_4a187c4
02d55308: movi    d2, #0000000000000000                      
02d5530c: movi    d3, #0000000000000000                      
02d55310: mov     x0, x19                                    
02d55314: bl      #0x2d55498                                 Blindbag.OrderingFood::WordPosition
02d55318: mov     x0, x19                                    
02d5531c: mov     x1, xzr                                    
02d55320: fmov    s8, s0                                     
02d55324: fmov    s9, s1                                     
02d55328: fmov    s10, s2                                    
02d5532c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d55330: mov     x20, x0                                    
02d55334: mov     x0, x19                                    
02d55338: mov     x1, xzr                                    
02d5533c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d55340: cbz     x0, #0x2d55494                             
02d55344: mov     x1, xzr                                    
02d55348: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d5534c: mov     x0, xzr                                    
02d55350: fmov    s11, s0                                    
02d55354: fmov    s12, s1                                    
02d55358: fmov    s13, s2                                    
02d5535c: bl      #0x5b433a4                                 UnityEngine.Time::get_deltaTime
02d55360: cbz     x20, #0x2d55494                            
02d55364: ldr     s1, [x19, #0x80]                           ._dragSpeed
02d55368: movi    d2, #0000000000000000                      
02d5536c: fsub    s3, s8, s11                                
02d55370: mov     x0, x20                                    
02d55374: mov     x1, xzr                                    
02d55378: fmul    s0, s0, s1                                 
02d5537c: fmov    s1, #1.00000000                            
02d55380: fcmp    s0, s1                                     
02d55384: fcsel   s1, s1, s0, gt                             
02d55388: fcmp    s0, #0.0                                   
02d5538c: fsub    s0, s10, s13                               
02d55390: fcsel   s1, s2, s1, mi                             
02d55394: fsub    s2, s9, s12                                
02d55398: fmul    s0, s0, s1                                 
02d5539c: fmul    s4, s2, s1                                 
02d553a0: fmul    s3, s3, s1                                 
02d553a4: fadd    s2, s13, s0                                
02d553a8: fadd    s1, s12, s4                                
02d553ac: fadd    s0, s11, s3                                
02d553b0: bl      #0x5b46888                                 UnityEngine.Transform::set_position
02d553b4: mov     x0, x19                                    
02d553b8: mov     x1, xzr                                    
02d553bc: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d553c0: cbz     x0, #0x2d55494                             
02d553c4: mov     x1, xzr                                    
02d553c8: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d553cc: ldr     x0, [x19, #0x58]                           ._target
02d553d0: cbz     x0, #0x2d55494                             
02d553d4: mov     x1, xzr                                    
02d553d8: fmov    s8, s0                                     
02d553dc: fmov    s9, s1                                     
02d553e0: fmov    s10, s2                                    
02d553e4: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02d553e8: fmov    s11, s0                                    
02d553ec: fmov    s12, s1                                    
02d553f0: adrp    x20, #0x6630000                            
02d553f4: fmov    s13, s2                                    
02d553f8: ldrb    w8, [x20, #0x1d5]                          
02d553fc: cbnz    w8, #0x2d55414                             
02d55400: adrp    x0, #0x6265000                             
02d55404: ldr     x0, [x0, #0xb48]                           T:System.Math
02d55408: bl      #0x2b70db0                                 fn_2b70db0
02d5540c: mov     w8, #1                                     
02d55410: strb    w8, [x20, #0x1d5]                          
02d55414: adrp    x8, #0x6265000                             
02d55418: ldr     x8, [x8, #0xb48]                           T:System.Math
02d5541c: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02d55420: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02d55424: cbnz    w8, #0x2d5542c                             
02d55428: bl      #0x2b70f30                                 fn_2b70f30
02d5542c: fsub    s0, s9, s12                                
02d55430: fsub    s1, s8, s11                                
02d55434: fsub    s2, s10, s13                               
02d55438: fmul    s1, s1, s1                                 
02d5543c: fmul    s0, s0, s0                                 
02d55440: fadd    s0, s1, s0                                 
02d55444: fmul    s1, s2, s2                                 
02d55448: fadd    s0, s1, s0                                 
02d5544c: fmov    s1, #0.50000000                            
02d55450: fsqrt   s0, s0                                     
02d55454: fcmp    s0, s1                                     
02d55458: b.pl    #0x2d552a0                                 
02d5545c: ldr     x8, [x19, #0x38]                           .OnScanItem
02d55460: mov     w9, #1                                     
02d55464: strb    w9, [x19, #0x28]                           ._isTriggered
02d55468: cbz     x8, #0x2d552a0                             
02d5546c: mov     x1, x19                                    
02d55470: ldp     x20, x19, [sp, #0x40]                      
02d55474: ldp     d9, d8, [sp, #0x20]                        
02d55478: ldr     x0, [x8, #0x40]                            S:'done_ad'
02d5547c: ldp     d11, d10, [sp, #0x10]                      
02d55480: ldr     x2, [x8, #0x28]                            T:AdsManager/<ISetAOAInterval>d__33
02d55484: ldr     x3, [x8, #0x18]                            T:AdsManager/<IEHideAdResume>d__30
02d55488: ldr     x30, [sp, #0x30]                           
02d5548c: ldp     d13, d12, [sp], #0x50                      
02d55490: br      x3                                         
02d55494: bl      #0x2b7105c                                 fn_2b7105c
## OnMouseButtonUp() -> void
---- Blindbag.OrderingFood::OnMouseButtonUp 0x2d5555c
02d5555c: stp     x30, x19, [sp, #-0x10]!                    
02d55560: ldrb    w8, [x0, #0x28]                            ._isTriggered
02d55564: cbz     w8, #0x2d55570                             
02d55568: ldp     x30, x19, [sp], #0x10                      
02d5556c: ret                                                
02d55570: mov     x1, xzr                                    
02d55574: mov     x19, x0                                    
02d55578: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d5557c: cbz     x0, #0x2d555b4                             
02d55580: ldp     s1, s2, [x19, #0x64]                       
02d55584: mov     x1, xzr                                    
02d55588: ldr     s0, [x19, #0x60]                           ._cachedEuler
02d5558c: bl      #0x5b46c88                                 UnityEngine.Transform::set_localEulerAngles
02d55590: mov     x0, x19                                    
02d55594: mov     x1, xzr                                    
02d55598: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d5559c: cbz     x0, #0x2d555b4                             
02d555a0: ldp     s0, s1, [x19, #0x6c]                       ._cachedPosition
02d555a4: mov     x1, xzr                                    
02d555a8: ldr     s2, [x19, #0x74]                           
02d555ac: ldp     x30, x19, [sp], #0x10                      
02d555b0: b       #0x5b45cec                                 UnityEngine.Transform::set_localPosition
02d555b4: bl      #0x2b7105c                                 fn_2b7105c
## InitializedBuying(UnityEngine.Transform target) -> void
---- Blindbag.OrderingFood::InitializedBuying 0x2d555b8
02d555b8: stp     x30, x21, [sp, #-0x20]!                    
02d555bc: stp     x20, x19, [sp, #0x10]                      
02d555c0: mov     x20, x1                                    
02d555c4: mov     x1, xzr                                    
02d555c8: mov     x19, x0                                    
02d555cc: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d555d0: mov     x21, x0                                    
02d555d4: mov     w0, #-0x46                                 
02d555d8: mov     w1, #0x46                                  
02d555dc: mov     x2, xzr                                    
02d555e0: bl      #0x5b2e000                                 UnityEngine.Random::Range
02d555e4: cbz     x21, #0x2d55658                            
02d555e8: scvtf   s2, w0                                     
02d555ec: movi    d0, #0000000000000000                      
02d555f0: mov     x0, x21                                    
02d555f4: movi    d1, #0000000000000000                      
02d555f8: mov     x1, xzr                                    
02d555fc: bl      #0x5b46c88                                 UnityEngine.Transform::set_localEulerAngles
02d55600: mov     x0, x19                                    
02d55604: mov     x1, xzr                                    
02d55608: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d5560c: cbz     x0, #0x2d55658                             
02d55610: mov     x1, xzr                                    
02d55614: bl      #0x5b46ba8                                 UnityEngine.Transform::get_localEulerAngles
02d55618: mov     x0, x19                                    
02d5561c: mov     x1, xzr                                    
02d55620: stp     s0, s1, [x19, #0x60]                       ._cachedEuler
02d55624: str     s2, [x19, #0x68]                           
02d55628: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d5562c: cbz     x0, #0x2d55658                             
02d55630: mov     x1, xzr                                    
02d55634: bl      #0x5b45c24                                 UnityEngine.Transform::get_localPosition
02d55638: str     x20, [x19, #0x58]!                         ._target
02d5563c: mov     x0, x19                                    
02d55640: stp     s0, s1, [x19, #0x14]                       
02d55644: mov     x1, x20                                    
02d55648: str     s2, [x19, #0x1c]                           
02d5564c: ldp     x20, x19, [sp, #0x10]                      
02d55650: ldp     x30, x21, [sp], #0x20                      
02d55654: b       #0x2b70d54                                 
02d55658: bl      #0x2b7105c                                 fn_2b7105c
## WordPosition(UnityEngine.Vector3 inputPosition, float z) -> UnityEngine.Vector3
---- Blindbag.OrderingFood::WordPosition 0x2d55498
02d55498: stp     d11, d10, [sp, #-0x40]!                    
02d5549c: stp     d9, d8, [sp, #0x10]                        
02d554a0: stp     x30, x21, [sp, #0x20]                      
02d554a4: stp     x20, x19, [sp, #0x30]                      
02d554a8: fmov    s8, s3                                     
02d554ac: fmov    s9, s2                                     
02d554b0: adrp    x21, #0x6630000                            
02d554b4: fmov    s10, s1                                    
02d554b8: fmov    s11, s0                                    
02d554bc: adrp    x20, #0x6263000                            
02d554c0: ldrb    w8, [x21, #0x273]                          
02d554c4: ldr     x20, [x20, #0x918]                         T:UnityEngine.Object
02d554c8: mov     x19, x0                                    
02d554cc: tbnz    w8, #0, #0x2d554e4                         
02d554d0: adrp    x0, #0x6263000                             
02d554d4: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02d554d8: bl      #0x2b70db0                                 fn_2b70db0
02d554dc: mov     w8, #1                                     
02d554e0: strb    w8, [x21, #0x273]                          
02d554e4: ldr     x0, [x20]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d554e8: ldr     x20, [x19, #0x78]!                         ._mainCamera
02d554ec: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d554f0: cbnz    w8, #0x2d554f8                             
02d554f4: bl      #0x2b70f30                                 fn_2b70f30
02d554f8: mov     x0, x20                                    
02d554fc: mov     x1, xzr                                    
02d55500: mov     x2, xzr                                    
02d55504: bl      #0x5b37d84                                 UnityEngine.Object::op_Equality
02d55508: tbz     w0, #0, #0x2d55524                         
02d5550c: mov     x0, xzr                                    
02d55510: bl      #0x5aefe28                                 UnityEngine.Camera::get_main
02d55514: mov     x1, x0                                     
02d55518: str     x0, [x19]                                  
02d5551c: mov     x0, x19                                    
02d55520: bl      #0x2b70d54                                 fn_2b70d54
02d55524: ldr     x0, [x19]                                  
02d55528: cbz     x0, #0x2d55558                             
02d5552c: fmov    s0, s11                                    
02d55530: fmov    s1, s10                                    
02d55534: mov     x1, xzr                                    
02d55538: fmov    s2, s9                                     
02d5553c: bl      #0x5aefbb0                                 UnityEngine.Camera::ScreenToWorldPoint
02d55540: fmov    s2, s8                                     
02d55544: ldp     x20, x19, [sp, #0x30]                      
02d55548: ldp     x30, x21, [sp, #0x20]                      
02d5554c: ldp     d9, d8, [sp, #0x10]                        
02d55550: ldp     d11, d10, [sp], #0x40                      
02d55554: ret                                                
02d55558: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Blindbag.OrderingFood::.ctor 0x2d5565c
02d5565c: mov     w8, #0x41a00000                            
02d55660: mov     x1, xzr                                    
02d55664: str     w8, [x0, #0x80]                            ._dragSpeed
02d55668: b       #0x2cd6228                                 PoolElement::.ctor
