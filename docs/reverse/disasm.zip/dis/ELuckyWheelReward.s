#### CLASS ELuckyWheelReward parent= int
#   field value__                        int                                                off=0x10 attr=606 
#   field Coins                          ELuckyWheelReward                                  off=0x0 attr=8056 
#   field Item                           ELuckyWheelReward                                  off=0x0 attr=8056 
