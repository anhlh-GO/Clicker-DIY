#### CLASS EventDispatcherExtension parent= object
## RegisterListener(UnityEngine.MonoBehaviour listener, EventID eventID, System.Action`1<object> callback) -> void
---- EventDispatcherExtension::RegisterListener 0x2cdc254
02cdc254: str     x30, [sp, #-0x20]!                         
02cdc258: stp     x20, x19, [sp, #0x10]                      
02cdc25c: mov     x19, x2                                    
02cdc260: mov     w20, w1                                    
02cdc264: bl      #0x2cdba74                                 EventDispatcher::get_Instance
02cdc268: cbz     x0, #0x2cdc280                             
02cdc26c: mov     w1, w20                                    
02cdc270: mov     x2, x19                                    
02cdc274: ldp     x20, x19, [sp, #0x10]                      
02cdc278: ldr     x30, [sp], #0x20                           
02cdc27c: b       #0x2cdbe2c                                 EventDispatcher::RegisterListener
02cdc280: bl      #0x2b7105c                                 fn_2b7105c
## PostEvent(UnityEngine.MonoBehaviour listener, EventID eventID, object param) -> void
---- EventDispatcherExtension::PostEvent 0x2cdc284
02cdc284: str     x30, [sp, #-0x20]!                         
02cdc288: stp     x20, x19, [sp, #0x10]                      
02cdc28c: mov     x19, x2                                    
02cdc290: mov     w20, w1                                    
02cdc294: bl      #0x2cdba74                                 EventDispatcher::get_Instance
02cdc298: cbz     x0, #0x2cdc2b0                             
02cdc29c: mov     w1, w20                                    
02cdc2a0: mov     x2, x19                                    
02cdc2a4: ldp     x20, x19, [sp, #0x10]                      
02cdc2a8: ldr     x30, [sp], #0x20                           
02cdc2ac: b       #0x2cdbfc8                                 EventDispatcher::PostEvent
02cdc2b0: bl      #0x2b7105c                                 fn_2b7105c
## PostEvent(UnityEngine.MonoBehaviour sender, EventID eventID) -> void
---- EventDispatcherExtension::PostEvent 0x2cdc2b4
02cdc2b4: stp     x30, x19, [sp, #-0x10]!                    
02cdc2b8: mov     w19, w1                                    
02cdc2bc: bl      #0x2cdba74                                 EventDispatcher::get_Instance
02cdc2c0: cbz     x0, #0x2cdc2d4                             
02cdc2c4: mov     w1, w19                                    
02cdc2c8: mov     x2, xzr                                    
02cdc2cc: ldp     x30, x19, [sp], #0x10                      
02cdc2d0: b       #0x2cdbfc8                                 EventDispatcher::PostEvent
02cdc2d4: bl      #0x2b7105c                                 fn_2b7105c
