#### CLASS DailyMission.DailyConfig parent= UnityEngine.ScriptableObject
#   field Contents                       System.Collections.Generic.List`1<DailyMission.DailyContent> off=0x18 attr=6 
## GetConfig(int index) -> DailyMission.DailyContent
---- DailyMission.DailyConfig::GetConfig 0x2d76398
02d76398: stp     x30, x21, [sp, #-0x20]!                    
02d7639c: stp     x20, x19, [sp, #0x10]                      
02d763a0: adrp    x21, #0x6630000                            
02d763a4: mov     w19, w1                                    
02d763a8: mov     x20, x0                                    
02d763ac: ldrb    w8, [x21, #0x3d9]                          
02d763b0: tbnz    w8, #0, #0x2d763c8                         
02d763b4: adrp    x0, #0x626c000                             
02d763b8: ldr     x0, [x0, #0x838]                           MS:System.Collections.Generic.List`1::get_Item
02d763bc: bl      #0x2b70db0                                 fn_2b70db0
02d763c0: mov     w8, #1                                     
02d763c4: strb    w8, [x21, #0x3d9]                          
02d763c8: ldr     x0, [x20, #0x18]                           .Contents
02d763cc: cbz     x0, #0x2d763f0                             
02d763d0: adrp    x8, #0x626c000                             
02d763d4: ldr     x8, [x8, #0x838]                           MS:System.Collections.Generic.List`1::get_Item
02d763d8: ldr     x2, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d763dc: mov     w1, w19                                    
02d763e0: bl      #0x35a8f3c                                 fn_35a8f3c
02d763e4: ldp     x20, x19, [sp, #0x10]                      
02d763e8: ldp     x30, x21, [sp], #0x20                      
02d763ec: ret                                                
02d763f0: bl      #0x2b7105c                                 fn_2b7105c
02d763f4: b       #0x2d763f8                                 
02d763f8: mov     x19, x0                                    
02d763fc: cmp     w1, #1                                     
02d76400: b.ne    #0x2d7648c                                 
02d76404: mov     x0, x19                                    
02d76408: bl      #0x5e90260                                 fn_5e90260
02d7640c: mov     x19, x0                                    
02d76410: adrp    x0, #0x6263000                             
02d76414: ldr     x0, [x0, #0xae0]                           T:System.Exception
02d76418: bl      #0x2b70dc4                                 fn_2b70dc4
02d7641c: ldr     x8, [x19]                                  
02d76420: ldr     x1, [x8]                                   M:Clicker.GlowSprite2DItem::<DoGlow>b__10_2
02d76424: bl      #0x2b71464                                 fn_2b71464
02d76428: tbz     w0, #0, #0x2d76464                         
02d7642c: bl      #0x5e90270                                 fn_5e90270
02d76430: adrp    x0, #0x6263000                             
02d76434: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02d76438: bl      #0x2b70dc4                                 fn_2b70dc4
02d7643c: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02d76440: cbnz    w8, #0x2d76448                             
02d76444: bl      #0x2b70f30                                 fn_2b70f30
02d76448: adrp    x0, #0x626c000                             
02d7644c: ldr     x0, [x0, #0x840]                           S:'Out of range !'
02d76450: bl      #0x2b70dc4                                 fn_2b70dc4
02d76454: mov     x1, xzr                                    
02d76458: bl      #0x5af2840                                 UnityEngine.Debug::LogError
02d7645c: mov     x0, xzr                                    
02d76460: b       #0x2d763e4                                 
02d76464: mov     w0, #8                                     
02d76468: bl      #0x5e90290                                 fn_5e90290
02d7646c: ldr     x8, [x19]                                  
02d76470: str     x8, [x0]                                   
02d76474: adrp    x1, #0x5e96000                             
02d76478: add     x1, x1, #0x758                             &5e96758
02d7647c: mov     x2, xzr                                    
02d76480: bl      #0x5e902a0                                 fn_5e902a0
02d76484: mov     x19, x0                                    
02d76488: bl      #0x5e90270                                 fn_5e90270
02d7648c: mov     x0, x19                                    
02d76490: bl      #0x2c6051c                                 fn_2c6051c
02d76494: bl      #0x27369b8                                 fn_27369b8
## .ctor() -> void
---- DailyMission.DailyConfig::.ctor 0x2d76498
02d76498: mov     x1, xzr                                    
02d7649c: b       #0x5b398f0                                 UnityEngine.ScriptableObject::.ctor
