#### CLASS Framework.HoldToTriggerButton parent= UnityEngine.MonoBehaviour
#   field _holdDuration                  float                                              off=0x20 attr=1 SerializeField
#   field _button                        UnityEngine.UI.Button                              off=0x28 attr=1 
#   field _onHold                        bool                                               off=0x30 attr=1 
#   field _holdingTime                   float                                              off=0x34 attr=1 
## Awake() -> void
---- Framework.HoldToTriggerButton::Awake 0x2cc455c
02cc455c: stp     x30, x21, [sp, #-0x20]!                    
02cc4560: stp     x20, x19, [sp, #0x10]                      
02cc4564: adrp    x20, #0x662f000                            
02cc4568: adrp    x21, #0x6267000                            
02cc456c: mov     x19, x0                                    
02cc4570: ldrb    w8, [x20, #0xc3e]                          
02cc4574: ldr     x21, [x21, #0x1b8]                         MS:UnityEngine.Component::GetComponent
02cc4578: tbnz    w8, #0, #0x2cc4590                         
02cc457c: adrp    x0, #0x6267000                             
02cc4580: ldr     x0, [x0, #0x1b8]                           MS:UnityEngine.Component::GetComponent
02cc4584: bl      #0x2b70db0                                 fn_2b70db0
02cc4588: mov     w8, #1                                     
02cc458c: strb    w8, [x20, #0xc3e]                          
02cc4590: ldr     x1, [x21]                                  S:'didu'
02cc4594: mov     x0, x19                                    
02cc4598: bl      #0x3140c84                                 fn_3140c84
02cc459c: str     x0, [x19, #0x28]!                          ._button
02cc45a0: mov     x1, x0                                     
02cc45a4: mov     x0, x19                                    
02cc45a8: ldp     x20, x19, [sp, #0x10]                      
02cc45ac: ldp     x30, x21, [sp], #0x20                      
02cc45b0: b       #0x2b70d54                                 
## Update() -> void
---- Framework.HoldToTriggerButton::Update 0x2cc45b4
02cc45b4: str     d8, [sp, #-0x20]!                          
02cc45b8: stp     x30, x19, [sp, #0x10]                      
02cc45bc: ldrb    w8, [x0, #0x30]                            ._onHold
02cc45c0: cbz     w8, #0x2cc45f8                             
02cc45c4: ldr     x8, [x0, #0x28]                            ._button
02cc45c8: mov     x19, x0                                    
02cc45cc: cbz     x8, #0x2cc462c                             
02cc45d0: ldrb    w8, [x8, #0xd8]                            
02cc45d4: cbz     w8, #0x2cc45f8                             
02cc45d8: ldr     s8, [x19, #0x34]                           ._holdingTime
02cc45dc: mov     x0, xzr                                    
02cc45e0: bl      #0x5b433a4                                 UnityEngine.Time::get_deltaTime
02cc45e4: fadd    s0, s8, s0                                 
02cc45e8: ldr     s1, [x19, #0x20]                           ._holdDuration
02cc45ec: fcmp    s0, s1                                     
02cc45f0: str     s0, [x19, #0x34]                           ._holdingTime
02cc45f4: b.ge    #0x2cc4604                                 
02cc45f8: ldp     x30, x19, [sp, #0x10]                      
02cc45fc: ldr     d8, [sp], #0x20                            
02cc4600: ret                                                
02cc4604: fsub    s0, s0, s1                                 
02cc4608: ldr     x8, [x19, #0x28]                           ._button
02cc460c: str     s0, [x19, #0x34]                           ._holdingTime
02cc4610: cbz     x8, #0x2cc462c                             
02cc4614: ldr     x0, [x8, #0x100]                           
02cc4618: cbz     x0, #0x2cc462c                             
02cc461c: ldp     x30, x19, [sp, #0x10]                      
02cc4620: mov     x1, xzr                                    
02cc4624: ldr     d8, [sp], #0x20                            
02cc4628: b       #0x5b4d278                                 UnityEngine.Events.UnityEvent::Invoke
02cc462c: bl      #0x2b7105c                                 fn_2b7105c
## OnPointerDown(UnityEngine.EventSystems.PointerEventData eventData) -> void
---- Framework.HoldToTriggerButton::OnPointerDown 0x2cc4630
02cc4630: ldr     x8, [x0, #0x28]                            ._button
02cc4634: str     wzr, [x0, #0x34]                           ._holdingTime
02cc4638: cbz     x8, #0x2cc4648                             
02cc463c: ldrb    w8, [x8, #0xd8]                            
02cc4640: strb    w8, [x0, #0x30]                            ._onHold
02cc4644: ret                                                
02cc4648: str     x30, [sp, #-0x10]!                         
02cc464c: bl      #0x2b7105c                                 fn_2b7105c
## OnPointerUp(UnityEngine.EventSystems.PointerEventData eventData) -> void
---- Framework.HoldToTriggerButton::OnPointerUp 0x2cc4650
02cc4650: strb    wzr, [x0, #0x30]                           ._onHold
02cc4654: ret                                                
## .ctor() -> void
---- Framework.HoldToTriggerButton::.ctor 0x2cc4658
02cc4658: mov     w8, #0x999a                                
02cc465c: mov     x1, xzr                                    
02cc4660: movk    w8, #0x3e19, lsl #16                       
02cc4664: str     w8, [x0, #0x20]                            ._holdDuration
02cc4668: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
