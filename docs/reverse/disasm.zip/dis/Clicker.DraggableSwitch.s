#### CLASS Clicker.DraggableSwitch parent= Clicker.DraggableClickerItem
## .ctor() -> void
---- Clicker.DraggableSwitch::.ctor 0x2d61d38
02d61d38: mov     w8, #-1                                    
02d61d3c: mov     x1, xzr                                    
02d61d40: str     w8, [x0, #0x58]                            
02d61d44: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
