#### CLASS Framework.SoundChannel/<AutoStopCoroutine>d__13 parent= object
#   field <>1__state                     int                                                off=0x10 attr=1 
#   field <>2__current                   object                                             off=0x18 attr=1 
#   field time                           float                                              off=0x20 attr=6 
#   field <>4__this                      Framework.SoundChannel                             off=0x28 attr=6 
## .ctor(int <>1__state) -> void
---- Framework.SoundChannel/<AutoStopCoroutine>d__13::.ctor 0x2d86e14
02d86e14: str     x30, [sp, #-0x20]!                         
02d86e18: stp     x20, x19, [sp, #0x10]                      
02d86e1c: mov     w19, w1                                    
02d86e20: mov     x1, xzr                                    
02d86e24: mov     x20, x0                                    
02d86e28: bl      #0x4e53e9c                                 System.Object::.ctor
02d86e2c: str     w19, [x20, #0x10]                          .<>1__state
02d86e30: ldp     x20, x19, [sp, #0x10]                      
02d86e34: ldr     x30, [sp], #0x20                           
02d86e38: ret                                                
## System.IDisposable.Dispose() -> void
---- Framework.SoundChannel/<AutoStopCoroutine>d__13::System.IDisposable.Dispose 0x2d86e94
02d86e94: ret                                                
## MoveNext() -> bool
---- Framework.SoundChannel/<AutoStopCoroutine>d__13::MoveNext 0x2d86e98
02d86e98: str     d8, [sp, #-0x30]!                          
02d86e9c: stp     x30, x21, [sp, #0x10]                      
02d86ea0: stp     x20, x19, [sp, #0x20]                      
02d86ea4: adrp    x20, #0x6630000                            
02d86ea8: mov     x19, x0                                    
02d86eac: ldrb    w8, [x20, #0x494]                          
02d86eb0: tbnz    w8, #0, #0x2d86ec8                         
02d86eb4: adrp    x0, #0x6264000                             
02d86eb8: ldr     x0, [x0, #0xf58]                           T:UnityEngine.WaitForSeconds
02d86ebc: bl      #0x2b70db0                                 fn_2b70db0
02d86ec0: mov     w8, #1                                     
02d86ec4: strb    w8, [x20, #0x494]                          
02d86ec8: ldr     w21, [x19, #0x10]                          .<>1__state
02d86ecc: cbz     w21, #0x2d86ef0                            
02d86ed0: cmp     w21, #1                                    
02d86ed4: b.ne    #0x2d86f34                                 
02d86ed8: ldr     x0, [x19, #0x28]                           .<>4__this
02d86edc: mov     w8, #-1                                    
02d86ee0: str     w8, [x19, #0x10]                           .<>1__state
02d86ee4: cbz     x0, #0x2d86f4c                             
02d86ee8: bl      #0x2d86940                                 Framework.SoundChannel::Stop
02d86eec: b       #0x2d86f34                                 
02d86ef0: adrp    x8, #0x6264000                             
02d86ef4: mov     w9, #-1                                    
02d86ef8: ldr     x8, [x8, #0xf58]                           T:UnityEngine.WaitForSeconds
02d86efc: ldr     s8, [x19, #0x20]                           .time
02d86f00: str     w9, [x19, #0x10]                           .<>1__state
02d86f04: ldr     x0, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d86f08: bl      #0x2b7104c                                 fn_2b7104c
02d86f0c: fmov    s0, s8                                     
02d86f10: mov     x1, xzr                                    
02d86f14: mov     x20, x0                                    
02d86f18: bl      #0x5b3e5e8                                 UnityEngine.WaitForSeconds::.ctor
02d86f1c: mov     x0, x19                                    
02d86f20: mov     x1, x20                                    
02d86f24: str     x20, [x0, #0x18]!                          .<>2__current
02d86f28: bl      #0x2b70d54                                 fn_2b70d54
02d86f2c: mov     w8, #1                                     
02d86f30: str     w8, [x19, #0x10]                           .<>1__state
02d86f34: cmp     w21, #0                                    
02d86f38: ldp     x20, x19, [sp, #0x20]                      
02d86f3c: ldp     x30, x21, [sp, #0x10]                      
02d86f40: cset    w0, eq                                     
02d86f44: ldr     d8, [sp], #0x30                            
02d86f48: ret                                                
02d86f4c: bl      #0x2b7105c                                 fn_2b7105c
## System.Collections.Generic.IEnumerator<System.Object>.get_Current() -> object
---- Framework.SoundChannel/<AutoStopCoroutine>d__13::System.Collections.Generic.IEnumerator<System.Object>.get_Current 0x2d86f50
02d86f50: ldr     x0, [x0, #0x18]                            .<>2__current
02d86f54: ret                                                
## System.Collections.IEnumerator.Reset() -> void
---- Framework.SoundChannel/<AutoStopCoroutine>d__13::System.Collections.IEnumerator.Reset 0x2d86f58
02d86f58: stp     x30, x19, [sp, #-0x10]!                    
02d86f5c: adrp    x0, #0x6264000                             
02d86f60: ldr     x0, [x0, #0xf60]                           T:System.NotSupportedException
02d86f64: bl      #0x2b70dc4                                 fn_2b70dc4
02d86f68: bl      #0x2b7104c                                 fn_2b7104c
02d86f6c: mov     x1, xzr                                    
02d86f70: mov     x19, x0                                    
02d86f74: bl      #0x4e14238                                 System.NotSupportedException::.ctor
02d86f78: adrp    x0, #0x626d000                             
02d86f7c: ldr     x0, [x0, #0x2f8]                           M:Framework.SoundChannel/<AutoStopCoroutine>d__13::System.Collections.IEnumerator.Reset
02d86f80: bl      #0x2b70dc4                                 fn_2b70dc4
02d86f84: mov     x1, x0                                     
02d86f88: mov     x0, x19                                    
02d86f8c: bl      #0x2b70f20                                 fn_2b70f20
## System.Collections.IEnumerator.get_Current() -> object
---- Framework.SoundChannel/<AutoStopCoroutine>d__13::System.Collections.IEnumerator.get_Current 0x2d86f90
02d86f90: ldr     x0, [x0, #0x18]                            .<>2__current
02d86f94: ret                                                
#### CLASS Framework.SoundChannel/<AutoStopCoroutine>d__14 parent= object
#   field <>1__state                     int                                                off=0x10 attr=1 
#   field <>2__current                   object                                             off=0x18 attr=1 
#   field <>4__this                      Framework.SoundChannel                             off=0x20 attr=6 
## .ctor(int <>1__state) -> void
---- Framework.SoundChannel/<AutoStopCoroutine>d__14::.ctor 0x2d86e3c
02d86e3c: str     x30, [sp, #-0x20]!                         
02d86e40: stp     x20, x19, [sp, #0x10]                      
02d86e44: mov     w19, w1                                    
02d86e48: mov     x1, xzr                                    
02d86e4c: mov     x20, x0                                    
02d86e50: bl      #0x4e53e9c                                 System.Object::.ctor
02d86e54: str     w19, [x20, #0x10]                          .<>1__state
02d86e58: ldp     x20, x19, [sp, #0x10]                      
02d86e5c: ldr     x30, [sp], #0x20                           
02d86e60: ret                                                
## System.IDisposable.Dispose() -> void
---- Framework.SoundChannel/<AutoStopCoroutine>d__14::System.IDisposable.Dispose 0x2d86f98
02d86f98: ret                                                
## MoveNext() -> bool
---- Framework.SoundChannel/<AutoStopCoroutine>d__14::MoveNext 0x2d86f9c
02d86f9c: str     x30, [sp, #-0x30]!                         
02d86fa0: stp     x22, x21, [sp, #0x10]                      
02d86fa4: stp     x20, x19, [sp, #0x20]                      
02d86fa8: adrp    x20, #0x6630000                            
02d86fac: mov     x19, x0                                    
02d86fb0: ldrb    w8, [x20, #0x495]                          
02d86fb4: tbnz    w8, #0, #0x2d86fe4                         
02d86fb8: adrp    x0, #0x6265000                             
02d86fbc: ldr     x0, [x0, #0xfb0]                           T:type9979(k15)
02d86fc0: bl      #0x2b70db0                                 fn_2b70db0
02d86fc4: adrp    x0, #0x626d000                             
02d86fc8: ldr     x0, [x0, #0x300]                           M:Framework.SoundChannel::<AutoStopCoroutine>b__14_0
02d86fcc: bl      #0x2b70db0                                 fn_2b70db0
02d86fd0: adrp    x0, #0x6265000                             
02d86fd4: ldr     x0, [x0, #0xfd8]                           T:UnityEngine.WaitUntil
02d86fd8: bl      #0x2b70db0                                 fn_2b70db0
02d86fdc: mov     w8, #1                                     
02d86fe0: strb    w8, [x20, #0x495]                          
02d86fe4: ldr     w22, [x19, #0x10]                          .<>1__state
02d86fe8: ldr     x20, [x19, #0x20]                          .<>4__this
02d86fec: cbz     w22, #0x2d87010                            
02d86ff0: cmp     w22, #1                                    
02d86ff4: b.ne    #0x2d8707c                                 
02d86ff8: mov     w8, #-1                                    
02d86ffc: str     w8, [x19, #0x10]                           .<>1__state
02d87000: cbz     x20, #0x2d87094                            
02d87004: mov     x0, x20                                    
02d87008: bl      #0x2d86940                                 Framework.SoundChannel::Stop
02d8700c: b       #0x2d8707c                                 
02d87010: adrp    x8, #0x6265000                             
02d87014: mov     w9, #-1                                    
02d87018: ldr     x8, [x8, #0xfb0]                           T:type9979(k15)
02d8701c: str     w9, [x19, #0x10]                           .<>1__state
02d87020: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02d87024: bl      #0x2b7104c                                 fn_2b7104c
02d87028: adrp    x8, #0x626d000                             
02d8702c: mov     x1, x20                                    
02d87030: mov     x3, xzr                                    
02d87034: ldr     x8, [x8, #0x300]                           M:Framework.SoundChannel::<AutoStopCoroutine>b__14_0
02d87038: mov     x21, x0                                    
02d8703c: ldr     x2, [x8]                                   MS:System.Collections.Generic.List`1::.ctor
02d87040: bl      #0x4932dc8                                 fn_4932dc8
02d87044: adrp    x8, #0x6265000                             
02d87048: ldr     x8, [x8, #0xfd8]                           T:UnityEngine.WaitUntil
02d8704c: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02d87050: bl      #0x2b7104c                                 fn_2b7104c
02d87054: mov     x1, x21                                    
02d87058: mov     x2, xzr                                    
02d8705c: mov     x20, x0                                    
02d87060: bl      #0x5b3e7e4                                 UnityEngine.WaitUntil::.ctor
02d87064: mov     x0, x19                                    
02d87068: mov     x1, x20                                    
02d8706c: str     x20, [x0, #0x18]!                          .<>2__current
02d87070: bl      #0x2b70d54                                 fn_2b70d54
02d87074: mov     w8, #1                                     
02d87078: str     w8, [x19, #0x10]                           .<>1__state
02d8707c: cmp     w22, #0                                    
02d87080: ldp     x20, x19, [sp, #0x20]                      
02d87084: ldp     x22, x21, [sp, #0x10]                      
02d87088: cset    w0, eq                                     
02d8708c: ldr     x30, [sp], #0x30                           
02d87090: ret                                                
02d87094: bl      #0x2b7105c                                 fn_2b7105c
## System.Collections.Generic.IEnumerator<System.Object>.get_Current() -> object
---- Framework.SoundChannel/<AutoStopCoroutine>d__14::System.Collections.Generic.IEnumerator<System.Object>.get_Current 0x2d87098
02d87098: ldr     x0, [x0, #0x18]                            .<>2__current
02d8709c: ret                                                
## System.Collections.IEnumerator.Reset() -> void
---- Framework.SoundChannel/<AutoStopCoroutine>d__14::System.Collections.IEnumerator.Reset 0x2d870a0
02d870a0: stp     x30, x19, [sp, #-0x10]!                    
02d870a4: adrp    x0, #0x6264000                             
02d870a8: ldr     x0, [x0, #0xf60]                           T:System.NotSupportedException
02d870ac: bl      #0x2b70dc4                                 fn_2b70dc4
02d870b0: bl      #0x2b7104c                                 fn_2b7104c
02d870b4: mov     x1, xzr                                    
02d870b8: mov     x19, x0                                    
02d870bc: bl      #0x4e14238                                 System.NotSupportedException::.ctor
02d870c0: adrp    x0, #0x626d000                             
02d870c4: ldr     x0, [x0, #0x308]                           M:Framework.SoundChannel/<AutoStopCoroutine>d__14::System.Collections.IEnumerator.Reset
02d870c8: bl      #0x2b70dc4                                 fn_2b70dc4
02d870cc: mov     x1, x0                                     
02d870d0: mov     x0, x19                                    
02d870d4: bl      #0x2b70f20                                 fn_2b70f20
## System.Collections.IEnumerator.get_Current() -> object
---- Framework.SoundChannel/<AutoStopCoroutine>d__14::System.Collections.IEnumerator.get_Current 0x2d870d8
02d870d8: ldr     x0, [x0, #0x18]                            .<>2__current
02d870dc: ret                                                
#### CLASS Framework.SoundChannel parent= UnityEngine.MonoBehaviour
#   field IsPlay                         bool                                               off=0x20 attr=6 
#   field Source                         UnityEngine.AudioSource                            off=0x28 attr=6 
#   field SoundKey                       Framework.ESound                                   off=0x30 attr=6 
## get_IsMute() -> bool
---- Framework.SoundChannel::get_IsMute 0x2d86cfc
02d86cfc: ldr     x0, [x0, #0x28]                            .Source
02d86d00: cbz     x0, #0x2d86d0c                             
02d86d04: mov     x1, xzr                                    
02d86d08: b       #0x5adfd28                                 UnityEngine.AudioSource::get_mute
02d86d0c: str     x30, [sp, #-0x10]!                         
02d86d10: bl      #0x2b7105c                                 fn_2b7105c
## set_IsMute(bool value) -> void
---- Framework.SoundChannel::set_IsMute 0x2d84d18
02d84d18: ldr     x0, [x0, #0x28]                            .Source
02d84d1c: cbz     x0, #0x2d84d2c                             
02d84d20: and     w1, w1, #1                                 
02d84d24: mov     x2, xzr                                    
02d84d28: b       #0x5adfddc                                 UnityEngine.AudioSource::set_mute
02d84d2c: str     x30, [sp, #-0x10]!                         
02d84d30: bl      #0x2b7105c                                 fn_2b7105c
## Play(Framework.ESound soundKey, UnityEngine.AudioClip clip, float volume, float delay) -> void
---- Framework.SoundChannel::Play 0x2d859e8
02d859e8: stp     d9, d8, [sp, #-0x20]!                      
02d859ec: stp     x30, x19, [sp, #0x10]                      
02d859f0: mov     x19, x0                                    
02d859f4: ldr     x0, [x0, #0x28]                            .Source
02d859f8: mov     w8, #1                                     
02d859fc: strb    w8, [x19, #0x20]                           .IsPlay
02d85a00: str     w1, [x19, #0x30]                           .SoundKey
02d85a04: cbz     x0, #0x2d85a78                             
02d85a08: mov     x1, x2                                     
02d85a0c: mov     x2, xzr                                    
02d85a10: fmov    s8, s1                                     
02d85a14: fmov    s9, s0                                     
02d85a18: bl      #0x5adf8dc                                 UnityEngine.AudioSource::set_clip
02d85a1c: ldr     x0, [x19, #0x28]                           .Source
02d85a20: cbz     x0, #0x2d85a78                             
02d85a24: fmov    s0, s9                                     
02d85a28: mov     x1, xzr                                    
02d85a2c: bl      #0x5adf65c                                 UnityEngine.AudioSource::set_volume
02d85a30: ldr     x0, [x19, #0x28]                           .Source
02d85a34: cbz     x0, #0x2d85a78                             
02d85a38: mov     w1, wzr                                    
02d85a3c: mov     x2, xzr                                    
02d85a40: bl      #0x5adfc64                                 UnityEngine.AudioSource::set_loop
02d85a44: ldr     x0, [x19, #0x28]                           .Source
02d85a48: cbz     x0, #0x2d85a78                             
02d85a4c: fmov    s0, s8                                     
02d85a50: mov     x1, xzr                                    
02d85a54: bl      #0x5adfa1c                                 UnityEngine.AudioSource::PlayDelayed
02d85a58: mov     x0, x19                                    
02d85a5c: bl      #0x2d86d14                                 Framework.SoundChannel::AutoStopCoroutine
02d85a60: mov     x1, x0                                     
02d85a64: mov     x0, x19                                    
02d85a68: mov     x2, xzr                                    
02d85a6c: ldp     x30, x19, [sp, #0x10]                      
02d85a70: ldp     d9, d8, [sp], #0x20                        
02d85a74: b       #0x5b389f0                                 UnityEngine.MonoBehaviour::StartCoroutine
02d85a78: bl      #0x2b7105c                                 fn_2b7105c
## PlayLoop(Framework.ESound soundKey, UnityEngine.AudioClip clip, float volume, float delay, bool isSetTimeStop, float timeStop) -> void
---- Framework.SoundChannel::PlayLoop 0x2d85920
02d85920: str     d10, [sp, #-0x30]!                         
02d85924: stp     d9, d8, [sp, #8]                           
02d85928: str     x30, [sp, #0x18]                           
02d8592c: stp     x20, x19, [sp, #0x20]                      
02d85930: mov     x19, x0                                    
02d85934: ldr     x0, [x0, #0x28]                            .Source
02d85938: mov     w8, #1                                     
02d8593c: strb    w8, [x19, #0x20]                           .IsPlay
02d85940: str     w1, [x19, #0x30]                           .SoundKey
02d85944: cbz     x0, #0x2d859e4                             
02d85948: mov     x1, x2                                     
02d8594c: mov     x2, xzr                                    
02d85950: fmov    s8, s2                                     
02d85954: mov     w20, w3                                    
02d85958: fmov    s9, s1                                     
02d8595c: fmov    s10, s0                                    
02d85960: bl      #0x5adf8dc                                 UnityEngine.AudioSource::set_clip
02d85964: ldr     x0, [x19, #0x28]                           .Source
02d85968: cbz     x0, #0x2d859e4                             
02d8596c: fmov    s0, s10                                    
02d85970: mov     x1, xzr                                    
02d85974: bl      #0x5adf65c                                 UnityEngine.AudioSource::set_volume
02d85978: ldr     x0, [x19, #0x28]                           .Source
02d8597c: cbz     x0, #0x2d859e4                             
02d85980: mov     w1, #1                                     
02d85984: mov     x2, xzr                                    
02d85988: bl      #0x5adfc64                                 UnityEngine.AudioSource::set_loop
02d8598c: ldr     x0, [x19, #0x28]                           .Source
02d85990: cbz     x0, #0x2d859e4                             
02d85994: fmov    s0, s9                                     
02d85998: mov     x1, xzr                                    
02d8599c: bl      #0x5adfa1c                                 UnityEngine.AudioSource::PlayDelayed
02d859a0: tbz     w20, #0, #0x2d859d0                        
02d859a4: fadd    s0, s9, s8                                 
02d859a8: mov     x0, x19                                    
02d859ac: bl      #0x2d86d80                                 Framework.SoundChannel::AutoStopCoroutine
02d859b0: mov     x1, x0                                     
02d859b4: mov     x0, x19                                    
02d859b8: ldr     x30, [sp, #0x18]                           
02d859bc: ldp     x20, x19, [sp, #0x20]                      
02d859c0: mov     x2, xzr                                    
02d859c4: ldp     d9, d8, [sp, #8]                           
02d859c8: ldr     d10, [sp], #0x30                           
02d859cc: b       #0x5b389f0                                 UnityEngine.MonoBehaviour::StartCoroutine
02d859d0: ldp     x20, x19, [sp, #0x20]                      
02d859d4: ldr     x30, [sp, #0x18]                           
02d859d8: ldp     d9, d8, [sp, #8]                           
02d859dc: ldr     d10, [sp], #0x30                           
02d859e0: ret                                                
02d859e4: bl      #0x2b7105c                                 fn_2b7105c
## Stop() -> void
---- Framework.SoundChannel::Stop 0x2d86940
02d86940: stp     x30, x19, [sp, #-0x10]!                    
02d86944: mov     x19, x0                                    
02d86948: ldr     x0, [x0, #0x28]                            .Source
02d8694c: strb    wzr, [x19, #0x20]                          .IsPlay
02d86950: cbz     x0, #0x2d8696c                             
02d86954: mov     x1, xzr                                    
02d86958: bl      #0x5adfa40                                 UnityEngine.AudioSource::Stop
02d8695c: mov     x0, x19                                    
02d86960: mov     x1, xzr                                    
02d86964: ldp     x30, x19, [sp], #0x10                      
02d86968: b       #0x5b38f60                                 UnityEngine.MonoBehaviour::StopAllCoroutines
02d8696c: bl      #0x2b7105c                                 fn_2b7105c
## Pause() -> void
---- Framework.SoundChannel::Pause 0x2d86984
02d86984: stp     x30, x19, [sp, #-0x10]!                    
02d86988: mov     x19, x0                                    
02d8698c: ldr     x0, [x0, #0x28]                            .Source
02d86990: strb    wzr, [x19, #0x20]                          .IsPlay
02d86994: cbz     x0, #0x2d869b0                             
02d86998: mov     x1, xzr                                    
02d8699c: bl      #0x5adfa48                                 UnityEngine.AudioSource::Pause
02d869a0: mov     x0, x19                                    
02d869a4: mov     x1, xzr                                    
02d869a8: ldp     x30, x19, [sp], #0x10                      
02d869ac: b       #0x5b38f60                                 UnityEngine.MonoBehaviour::StopAllCoroutines
02d869b0: bl      #0x2b7105c                                 fn_2b7105c
## Resume() -> void
---- Framework.SoundChannel::Resume 0x2d869c8
02d869c8: stp     x30, x19, [sp, #-0x10]!                    
02d869cc: mov     x19, x0                                    
02d869d0: ldr     x0, [x0, #0x28]                            .Source
02d869d4: mov     w8, #1                                     
02d869d8: strb    w8, [x19, #0x20]                           .IsPlay
02d869dc: cbz     x0, #0x2d86a04                             
02d869e0: mov     x1, xzr                                    
02d869e4: bl      #0x5adfafc                                 UnityEngine.AudioSource::UnPause
02d869e8: mov     x0, x19                                    
02d869ec: bl      #0x2d86d14                                 Framework.SoundChannel::AutoStopCoroutine
02d869f0: mov     x1, x0                                     
02d869f4: mov     x0, x19                                    
02d869f8: mov     x2, xzr                                    
02d869fc: ldp     x30, x19, [sp], #0x10                      
02d86a00: b       #0x5b389f0                                 UnityEngine.MonoBehaviour::StartCoroutine
02d86a04: bl      #0x2b7105c                                 fn_2b7105c
## SetVolume(float volume) -> void
---- Framework.SoundChannel::SetVolume 0x2d86dfc
02d86dfc: ldr     x0, [x0, #0x28]                            .Source
02d86e00: cbz     x0, #0x2d86e0c                             
02d86e04: mov     x1, xzr                                    
02d86e08: b       #0x5adf65c                                 UnityEngine.AudioSource::set_volume
02d86e0c: str     x30, [sp, #-0x10]!                         
02d86e10: bl      #0x2b7105c                                 fn_2b7105c
## IsPaused() -> bool
---- Framework.SoundChannel::IsPaused 0x2d86b68
02d86b68: str     d8, [sp, #-0x20]!                          
02d86b6c: stp     x30, x19, [sp, #0x10]                      
02d86b70: ldrb    w8, [x0, #0x20]                            .IsPlay
02d86b74: cbnz    w8, #0x2d86bd0                             
02d86b78: mov     x19, x0                                    
02d86b7c: ldr     x0, [x0, #0x28]                            .Source
02d86b80: cbz     x0, #0x2d86be0                             
02d86b84: mov     x1, xzr                                    
02d86b88: bl      #0x5adf738                                 UnityEngine.AudioSource::get_time
02d86b8c: fcmp    s0, #0.0                                   
02d86b90: b.le    #0x2d86bd0                                 
02d86b94: ldr     x0, [x19, #0x28]                           .Source
02d86b98: cbz     x0, #0x2d86be0                             
02d86b9c: mov     x1, xzr                                    
02d86ba0: bl      #0x5adf738                                 UnityEngine.AudioSource::get_time
02d86ba4: ldr     x0, [x19, #0x28]                           .Source
02d86ba8: cbz     x0, #0x2d86be0                             
02d86bac: mov     x1, xzr                                    
02d86bb0: fmov    s8, s0                                     
02d86bb4: bl      #0x5adf7ec                                 UnityEngine.AudioSource::get_clip
02d86bb8: cbz     x0, #0x2d86be0                             
02d86bbc: mov     x1, xzr                                    
02d86bc0: bl      #0x5aded84                                 UnityEngine.AudioClip::get_length
02d86bc4: fcmp    s8, s0                                     
02d86bc8: cset    w0, mi                                     
02d86bcc: b       #0x2d86bd4                                 
02d86bd0: mov     w0, wzr                                    
02d86bd4: ldp     x30, x19, [sp, #0x10]                      
02d86bd8: ldr     d8, [sp], #0x20                            
02d86bdc: ret                                                
02d86be0: bl      #0x2b7105c                                 fn_2b7105c
## AutoStopCoroutine(float time) -> System.Collections.IEnumerator
---- Framework.SoundChannel::AutoStopCoroutine 0x2d86d80
02d86d80: str     d8, [sp, #-0x30]!                          
02d86d84: stp     x30, x21, [sp, #0x10]                      
02d86d88: stp     x20, x19, [sp, #0x20]                      
02d86d8c: fmov    s8, s0                                     
02d86d90: adrp    x20, #0x6630000                            
02d86d94: adrp    x21, #0x626d000                            
02d86d98: ldrb    w8, [x20, #0x492]                          
02d86d9c: ldr     x21, [x21, #0x2f0]                         T:Framework.SoundChannel/<AutoStopCoroutine>d__13
02d86da0: mov     x19, x0                                    
02d86da4: tbnz    w8, #0, #0x2d86dbc                         
02d86da8: adrp    x0, #0x626d000                             
02d86dac: ldr     x0, [x0, #0x2f0]                           T:Framework.SoundChannel/<AutoStopCoroutine>d__13
02d86db0: bl      #0x2b70db0                                 fn_2b70db0
02d86db4: mov     w8, #1                                     
02d86db8: strb    w8, [x20, #0x492]                          
02d86dbc: ldr     x0, [x21]                                  MS:System.Collections.Generic.List`1::.ctor
02d86dc0: bl      #0x2b7104c                                 fn_2b7104c
02d86dc4: mov     x1, xzr                                    
02d86dc8: mov     x20, x0                                    
02d86dcc: bl      #0x4e53e9c                                 System.Object::.ctor
02d86dd0: mov     x0, x20                                    
02d86dd4: mov     x1, x19                                    
02d86dd8: str     wzr, [x20, #0x10]                          
02d86ddc: str     x19, [x0, #0x28]!                          .Source
02d86de0: bl      #0x2b70d54                                 fn_2b70d54
02d86de4: mov     x0, x20                                    
02d86de8: str     s8, [x20, #0x20]                           .IsPlay
02d86dec: ldp     x20, x19, [sp, #0x20]                      
02d86df0: ldp     x30, x21, [sp, #0x10]                      
02d86df4: ldr     d8, [sp], #0x30                            
02d86df8: ret                                                
## AutoStopCoroutine() -> System.Collections.IEnumerator
---- Framework.SoundChannel::AutoStopCoroutine 0x2d86d14
02d86d14: stp     x30, x21, [sp, #-0x20]!                    
02d86d18: stp     x20, x19, [sp, #0x10]                      
02d86d1c: adrp    x20, #0x6630000                            
02d86d20: adrp    x21, #0x626d000                            
02d86d24: mov     x19, x0                                    
02d86d28: ldrb    w8, [x20, #0x493]                          
02d86d2c: ldr     x21, [x21, #0x2e8]                         T:Framework.SoundChannel/<AutoStopCoroutine>d__14
02d86d30: tbnz    w8, #0, #0x2d86d48                         
02d86d34: adrp    x0, #0x626d000                             
02d86d38: ldr     x0, [x0, #0x2e8]                           T:Framework.SoundChannel/<AutoStopCoroutine>d__14
02d86d3c: bl      #0x2b70db0                                 fn_2b70db0
02d86d40: mov     w8, #1                                     
02d86d44: strb    w8, [x20, #0x493]                          
02d86d48: ldr     x0, [x21]                                  MS:System.Collections.Generic.List`1::.ctor
02d86d4c: bl      #0x2b7104c                                 fn_2b7104c
02d86d50: mov     x1, xzr                                    
02d86d54: mov     x20, x0                                    
02d86d58: bl      #0x4e53e9c                                 System.Object::.ctor
02d86d5c: mov     x0, x20                                    
02d86d60: mov     x1, x19                                    
02d86d64: str     wzr, [x20, #0x10]                          
02d86d68: str     x19, [x0, #0x20]!                          .IsPlay
02d86d6c: bl      #0x2b70d54                                 fn_2b70d54
02d86d70: mov     x0, x20                                    
02d86d74: ldp     x20, x19, [sp, #0x10]                      
02d86d78: ldp     x30, x21, [sp], #0x20                      
02d86d7c: ret                                                
## .ctor() -> void
---- Framework.SoundChannel::.ctor 0x2d86e64
02d86e64: mov     x1, xzr                                    
02d86e68: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
## <AutoStopCoroutine>b__14_0() -> bool
---- Framework.SoundChannel::<AutoStopCoroutine>b__14_0 0x2d86e6c
02d86e6c: str     x30, [sp, #-0x10]!                         
02d86e70: ldr     x0, [x0, #0x28]                            .Source
02d86e74: cbz     x0, #0x2d86e90                             
02d86e78: mov     x1, xzr                                    
02d86e7c: bl      #0x5adfbb0                                 UnityEngine.AudioSource::get_isPlaying
02d86e80: mov     w8, #1                                     
02d86e84: bic     w0, w8, w0                                 
02d86e88: ldr     x30, [sp], #0x10                           
02d86e8c: ret                                                
02d86e90: bl      #0x2b7105c                                 fn_2b7105c
