#### CLASS Framework.PathUtils parent= object
#   field DOWNLOAD_FOLDER_NAME           string                                             off=0x0 attr=8056 
#   field SAVE_FOLDER_NAME               string                                             off=0x0 attr=8056 
#   field SCREENSHOT_FOLDER_NAME         string                                             off=0x0 attr=8056 
## GetDataPath() -> string
---- Framework.PathUtils::GetDataPath 0x2cc162c
02cc162c: str     x30, [sp, #-0x20]!                         
02cc1630: stp     x20, x19, [sp, #0x10]                      
02cc1634: adrp    x19, #0x662f000                            
02cc1638: adrp    x20, #0x6264000                            
02cc163c: ldrb    w8, [x19, #0xc18]                          
02cc1640: ldr     x20, [x20, #0xa70]                         T:UnityEngine.Application
02cc1644: tbnz    w8, #0, #0x2cc165c                         
02cc1648: adrp    x0, #0x6264000                             
02cc164c: ldr     x0, [x0, #0xa70]                           T:UnityEngine.Application
02cc1650: bl      #0x2b70db0                                 fn_2b70db0
02cc1654: mov     w8, #1                                     
02cc1658: strb    w8, [x19, #0xc18]                          
02cc165c: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cc1660: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02cc1664: cbnz    w8, #0x2cc166c                             
02cc1668: bl      #0x2b70f30                                 fn_2b70f30
02cc166c: ldp     x20, x19, [sp, #0x10]                      
02cc1670: mov     x0, xzr                                    
02cc1674: ldr     x30, [sp], #0x20                           
02cc1678: b       #0x5aea748                                 UnityEngine.Application::get_persistentDataPath
## GetDownloadFolderPath(bool autoCreate) -> string
---- Framework.PathUtils::GetDownloadFolderPath 0x2cc167c
02cc167c: stp     x30, x21, [sp, #-0x20]!                    
02cc1680: stp     x20, x19, [sp, #0x10]                      
02cc1684: adrp    x21, #0x662f000                            
02cc1688: adrp    x20, #0x6267000                            
02cc168c: mov     w19, w0                                    
02cc1690: ldrb    w8, [x21, #0xc19]                          
02cc1694: ldr     x20, [x20, #0x60]                          T:System.IO.Path
02cc1698: tbnz    w8, #0, #0x2cc16bc                         
02cc169c: adrp    x0, #0x6267000                             
02cc16a0: ldr     x0, [x0, #0x60]                            T:System.IO.Path
02cc16a4: bl      #0x2b70db0                                 fn_2b70db0
02cc16a8: adrp    x0, #0x6267000                             
02cc16ac: ldr     x0, [x0, #0x68]                            S:'Download'
02cc16b0: bl      #0x2b70db0                                 fn_2b70db0
02cc16b4: mov     w8, #1                                     
02cc16b8: strb    w8, [x21, #0xc19]                          
02cc16bc: adrp    x21, #0x6267000                            
02cc16c0: ldr     x21, [x21, #0x68]                          S:'Download'
02cc16c4: bl      #0x2cc162c                                 Framework.PathUtils::GetDataPath
02cc16c8: ldr     x8, [x20]                                  S:'didu'
02cc16cc: mov     x20, x0                                    
02cc16d0: ldr     w9, [x8, #0xe4]                            
02cc16d4: cbnz    w9, #0x2cc16e0                             
02cc16d8: mov     x0, x8                                     
02cc16dc: bl      #0x2b70f30                                 fn_2b70f30
02cc16e0: ldr     x1, [x21]                                  S:'didu'
02cc16e4: mov     x0, x20                                    
02cc16e8: mov     x2, xzr                                    
02cc16ec: bl      #0x4de8b90                                 System.IO.Path::Combine
02cc16f0: mov     x1, xzr                                    
02cc16f4: mov     x20, x0                                    
02cc16f8: bl      #0x4dd8ac0                                 System.IO.Directory::Exists
02cc16fc: tbnz    w0, #0, #0x2cc1710                         
02cc1700: tbz     w19, #0, #0x2cc1710                        
02cc1704: mov     x0, x20                                    
02cc1708: mov     x1, xzr                                    
02cc170c: bl      #0x4dd8938                                 System.IO.Directory::CreateDirectory
02cc1710: mov     x0, x20                                    
02cc1714: ldp     x20, x19, [sp, #0x10]                      
02cc1718: ldp     x30, x21, [sp], #0x20                      
02cc171c: ret                                                
## GetSaveFolderPath(bool autoCreate) -> string
---- Framework.PathUtils::GetSaveFolderPath 0x2cc1720
02cc1720: stp     x30, x21, [sp, #-0x20]!                    
02cc1724: stp     x20, x19, [sp, #0x10]                      
02cc1728: adrp    x21, #0x662f000                            
02cc172c: adrp    x20, #0x6267000                            
02cc1730: mov     w19, w0                                    
02cc1734: ldrb    w8, [x21, #0xc1a]                          
02cc1738: ldr     x20, [x20, #0x60]                          T:System.IO.Path
02cc173c: tbnz    w8, #0, #0x2cc1760                         
02cc1740: adrp    x0, #0x6267000                             
02cc1744: ldr     x0, [x0, #0x60]                            T:System.IO.Path
02cc1748: bl      #0x2b70db0                                 fn_2b70db0
02cc174c: adrp    x0, #0x6267000                             
02cc1750: ldr     x0, [x0, #0x70]                            S:'Save'
02cc1754: bl      #0x2b70db0                                 fn_2b70db0
02cc1758: mov     w8, #1                                     
02cc175c: strb    w8, [x21, #0xc1a]                          
02cc1760: adrp    x21, #0x6267000                            
02cc1764: ldr     x21, [x21, #0x70]                          S:'Save'
02cc1768: bl      #0x2cc162c                                 Framework.PathUtils::GetDataPath
02cc176c: ldr     x8, [x20]                                  S:'didu'
02cc1770: mov     x20, x0                                    
02cc1774: ldr     w9, [x8, #0xe4]                            
02cc1778: cbnz    w9, #0x2cc1784                             
02cc177c: mov     x0, x8                                     
02cc1780: bl      #0x2b70f30                                 fn_2b70f30
02cc1784: ldr     x1, [x21]                                  S:'didu'
02cc1788: mov     x0, x20                                    
02cc178c: mov     x2, xzr                                    
02cc1790: bl      #0x4de8b90                                 System.IO.Path::Combine
02cc1794: mov     x1, xzr                                    
02cc1798: mov     x20, x0                                    
02cc179c: bl      #0x4dd8ac0                                 System.IO.Directory::Exists
02cc17a0: tbnz    w0, #0, #0x2cc17b4                         
02cc17a4: tbz     w19, #0, #0x2cc17b4                        
02cc17a8: mov     x0, x20                                    
02cc17ac: mov     x1, xzr                                    
02cc17b0: bl      #0x4dd8938                                 System.IO.Directory::CreateDirectory
02cc17b4: mov     x0, x20                                    
02cc17b8: ldp     x20, x19, [sp, #0x10]                      
02cc17bc: ldp     x30, x21, [sp], #0x20                      
02cc17c0: ret                                                
## GetScreenShotFolderPath(bool autoCreate) -> string
---- Framework.PathUtils::GetScreenShotFolderPath 0x2cc17c4
02cc17c4: stp     x30, x21, [sp, #-0x20]!                    
02cc17c8: stp     x20, x19, [sp, #0x10]                      
02cc17cc: adrp    x21, #0x662f000                            
02cc17d0: adrp    x20, #0x6267000                            
02cc17d4: mov     w19, w0                                    
02cc17d8: ldrb    w8, [x21, #0xc1b]                          
02cc17dc: ldr     x20, [x20, #0x60]                          T:System.IO.Path
02cc17e0: tbnz    w8, #0, #0x2cc1804                         
02cc17e4: adrp    x0, #0x6267000                             
02cc17e8: ldr     x0, [x0, #0x60]                            T:System.IO.Path
02cc17ec: bl      #0x2b70db0                                 fn_2b70db0
02cc17f0: adrp    x0, #0x6267000                             
02cc17f4: ldr     x0, [x0, #0x78]                            S:'Screenshot'
02cc17f8: bl      #0x2b70db0                                 fn_2b70db0
02cc17fc: mov     w8, #1                                     
02cc1800: strb    w8, [x21, #0xc1b]                          
02cc1804: adrp    x21, #0x6267000                            
02cc1808: ldr     x21, [x21, #0x78]                          S:'Screenshot'
02cc180c: bl      #0x2cc162c                                 Framework.PathUtils::GetDataPath
02cc1810: ldr     x8, [x20]                                  S:'didu'
02cc1814: mov     x20, x0                                    
02cc1818: ldr     w9, [x8, #0xe4]                            
02cc181c: cbnz    w9, #0x2cc1828                             
02cc1820: mov     x0, x8                                     
02cc1824: bl      #0x2b70f30                                 fn_2b70f30
02cc1828: ldr     x1, [x21]                                  S:'didu'
02cc182c: mov     x0, x20                                    
02cc1830: mov     x2, xzr                                    
02cc1834: bl      #0x4de8b90                                 System.IO.Path::Combine
02cc1838: mov     x1, xzr                                    
02cc183c: mov     x20, x0                                    
02cc1840: bl      #0x4dd8ac0                                 System.IO.Directory::Exists
02cc1844: tbnz    w0, #0, #0x2cc1858                         
02cc1848: tbz     w19, #0, #0x2cc1858                        
02cc184c: mov     x0, x20                                    
02cc1850: mov     x1, xzr                                    
02cc1854: bl      #0x4dd8938                                 System.IO.Directory::CreateDirectory
02cc1858: mov     x0, x20                                    
02cc185c: ldp     x20, x19, [sp, #0x10]                      
02cc1860: ldp     x30, x21, [sp], #0x20                      
02cc1864: ret                                                
