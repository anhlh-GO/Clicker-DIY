#### CLASS PoolerBase`1 parent= UnityEngine.MonoBehaviour
#   field _prefab                        T                                                  off=0x0 attr=1 
#   field _pool                          UnityEngine.Pool.ObjectPool`1<T>                   off=0x0 attr=1 
##  get_Pool (no body)
##  set_Pool (no body)
##  InitPool (no body)
##  CreateSetup (no body)
##  GetSetup (no body)
##  ReleaseSetup (no body)
##  DestroySetup (no body)
##  Get (no body)
##  Release (no body)
##  .ctor (no body)
