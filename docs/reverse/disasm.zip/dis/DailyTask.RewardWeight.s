#### CLASS DailyTask.RewardWeight parent= object
#   field RewardAmount                   int                                                off=0x10 attr=6 
#   field Weight                         int                                                off=0x14 attr=6 
## .ctor() -> void
---- DailyTask.RewardWeight::.ctor 0x2d2bfc8
02d2bfc8: mov     x1, xzr                                    
02d2bfcc: b       #0x4e53e9c                                 System.Object::.ctor
