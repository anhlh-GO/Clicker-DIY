#### CLASS RemoveAdsPackPopup parent= PopupBase
#   field _packRect                      UnityEngine.RectTransform                          off=0x38 attr=1 SpaceAttribute,HeaderAttribute,SerializeField
#   field noAdsPack                      UnityEngine.GameObject                             off=0x40 attr=1 SerializeField
#   field specialPack                    UnityEngine.GameObject                             off=0x48 attr=1 SerializeField
#   field _closeButton                   UnityEngine.UI.Button                              off=0x50 attr=1 SerializeField
#   field _noAdsButton                   UnityEngine.UI.Button                              off=0x58 attr=1 SerializeField
#   field _specialPackButton             UnityEngine.UI.Button                              off=0x60 attr=1 SerializeField
#   field _contentGroup                  UnityEngine.CanvasGroup                            off=0x68 attr=1 SpaceAttribute,HeaderAttribute,SerializeField
#   field _effectGroup                   UnityEngine.CanvasGroup                            off=0x70 attr=1 SerializeField
#   field _noAdsIcon                     UnityEngine.UI.Image                               off=0x78 attr=1 SerializeField
#   field _skinIcon                      UnityEngine.UI.Image                               off=0x80 attr=1 SerializeField
#   field _noAdsPosition                 UnityEngine.RectTransform                          off=0x88 attr=1 SpaceAttribute,HeaderAttribute,SerializeField
#   field _skinPosition                  UnityEngine.RectTransform                          off=0x90 attr=1 SerializeField
#   field _txtPriceNormal                TMPro.TMP_Text                                     off=0x98 attr=1 SpaceAttribute,HeaderAttribute,SerializeField
#   field _txtPriceSpecial               TMPro.TMP_Text                                     off=0xa0 attr=1 SerializeField
#   field dataUser                       DataUser                                           off=0xa8 attr=1 
#   field dataSaveUser                   DataSaveUser                                       off=0xb0 attr=1 
#   field _noAdsIconStartPosition        UnityEngine.Vector2                                off=0xb8 attr=1 
#   field _skinIconStartPosition         UnityEngine.Vector2                                off=0xc0 attr=1 
## Awake() -> void
---- RemoveAdsPackPopup::Awake 0x2cb0948
02cb0948: str     x30, [sp, #-0x30]!                         
02cb094c: stp     x22, x21, [sp, #0x10]                      
02cb0950: stp     x20, x19, [sp, #0x20]                      
02cb0954: adrp    x20, #0x662f000                            
02cb0958: adrp    x21, #0x6266000                            
02cb095c: mov     x19, x0                                    
02cb0960: ldrb    w8, [x20, #0xb69]                          
02cb0964: ldr     x21, [x21, #0x658]                         MS:MonoSingleton`1::get_Instance
02cb0968: tbnz    w8, #0, #0x2cb09bc                         
02cb096c: adrp    x0, #0x6266000                             
02cb0970: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02cb0974: bl      #0x2b70db0                                 fn_2b70db0
02cb0978: adrp    x0, #0x6266000                             
02cb097c: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02cb0980: bl      #0x2b70db0                                 fn_2b70db0
02cb0984: adrp    x0, #0x6266000                             
02cb0988: ldr     x0, [x0, #0xa48]                           M:RemoveAdsPackPopup::OnCloseButtonClicked
02cb098c: bl      #0x2b70db0                                 fn_2b70db0
02cb0990: adrp    x0, #0x6266000                             
02cb0994: ldr     x0, [x0, #0xa50]                           M:RemoveAdsPackPopup::OnNoAdsButtonClicked
02cb0998: bl      #0x2b70db0                                 fn_2b70db0
02cb099c: adrp    x0, #0x6266000                             
02cb09a0: ldr     x0, [x0, #0xa58]                           M:RemoveAdsPackPopup::OnSpecialPackButtonClicked
02cb09a4: bl      #0x2b70db0                                 fn_2b70db0
02cb09a8: adrp    x0, #0x6265000                             
02cb09ac: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02cb09b0: bl      #0x2b70db0                                 fn_2b70db0
02cb09b4: mov     w8, #1                                     
02cb09b8: strb    w8, [x20, #0xb69]                          
02cb09bc: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb09c0: bl      #0x3769600                                 fn_3769600
02cb09c4: cbz     x0, #0x2cb0b2c                             
02cb09c8: adrp    x8, #0x6266000                             
02cb09cc: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02cb09d0: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb09d4: bl      #0x3168dd0                                 fn_3168dd0
02cb09d8: mov     x20, x19                                   
02cb09dc: mov     x1, x0                                     
02cb09e0: str     x0, [x20, #0xa8]!                          .dataUser
02cb09e4: mov     x0, x20                                    
02cb09e8: bl      #0x2b70d54                                 fn_2b70d54
02cb09ec: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02cb09f0: cbz     x8, #0x2cb0b2c                             
02cb09f4: ldr     x1, [x8, #0x20]                            S:'inter_ad_capping_time'
02cb09f8: mov     x20, x19                                   
02cb09fc: str     x1, [x20, #0xb0]!                          .dataSaveUser
02cb0a00: mov     x0, x20                                    
02cb0a04: bl      #0x2b70d54                                 fn_2b70d54
02cb0a08: ldur    x8, [x20, #-0x60]                          
02cb0a0c: cbz     x8, #0x2cb0b2c                             
02cb0a10: adrp    x22, #0x6265000                            
02cb0a14: adrp    x21, #0x6266000                            
02cb0a18: ldr     x22, [x22, #0x3f0]                         T:UnityEngine.Events.UnityAction
02cb0a1c: ldr     x21, [x21, #0xa48]                         M:RemoveAdsPackPopup::OnCloseButtonClicked
02cb0a20: ldr     x20, [x8, #0x100]                          M:ForceUpdate::OnClickUpdate
02cb0a24: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02cb0a28: bl      #0x2b7104c                                 fn_2b7104c
02cb0a2c: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb0a30: mov     x1, x19                                    
02cb0a34: mov     x3, xzr                                    
02cb0a38: mov     x21, x0                                    
02cb0a3c: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02cb0a40: cbz     x20, #0x2cb0b2c                            
02cb0a44: mov     x0, x20                                    
02cb0a48: mov     x1, x21                                    
02cb0a4c: mov     x2, xzr                                    
02cb0a50: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02cb0a54: ldr     x8, [x19, #0x58]                           ._noAdsButton
02cb0a58: cbz     x8, #0x2cb0b2c                             
02cb0a5c: adrp    x21, #0x6266000                            
02cb0a60: ldr     x21, [x21, #0xa50]                         M:RemoveAdsPackPopup::OnNoAdsButtonClicked
02cb0a64: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02cb0a68: ldr     x20, [x8, #0x100]                          M:ForceUpdate::OnClickUpdate
02cb0a6c: bl      #0x2b7104c                                 fn_2b7104c
02cb0a70: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb0a74: mov     x1, x19                                    
02cb0a78: mov     x3, xzr                                    
02cb0a7c: mov     x21, x0                                    
02cb0a80: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02cb0a84: cbz     x20, #0x2cb0b2c                            
02cb0a88: mov     x0, x20                                    
02cb0a8c: mov     x1, x21                                    
02cb0a90: mov     x2, xzr                                    
02cb0a94: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02cb0a98: ldr     x8, [x19, #0x60]                           ._specialPackButton
02cb0a9c: cbz     x8, #0x2cb0b2c                             
02cb0aa0: adrp    x21, #0x6266000                            
02cb0aa4: ldr     x21, [x21, #0xa58]                         M:RemoveAdsPackPopup::OnSpecialPackButtonClicked
02cb0aa8: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02cb0aac: ldr     x20, [x8, #0x100]                          M:ForceUpdate::OnClickUpdate
02cb0ab0: bl      #0x2b7104c                                 fn_2b7104c
02cb0ab4: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb0ab8: mov     x1, x19                                    
02cb0abc: mov     x3, xzr                                    
02cb0ac0: mov     x21, x0                                    
02cb0ac4: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02cb0ac8: cbz     x20, #0x2cb0b2c                            
02cb0acc: mov     x0, x20                                    
02cb0ad0: mov     x1, x21                                    
02cb0ad4: mov     x2, xzr                                    
02cb0ad8: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02cb0adc: ldr     x0, [x19, #0x78]                           ._noAdsIcon
02cb0ae0: cbz     x0, #0x2cb0b2c                             
02cb0ae4: mov     x1, xzr                                    
02cb0ae8: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cb0aec: cbz     x0, #0x2cb0b2c                             
02cb0af0: mov     x1, xzr                                    
02cb0af4: bl      #0x5b45c24                                 UnityEngine.Transform::get_localPosition
02cb0af8: ldr     x0, [x19, #0x80]                           ._skinIcon
02cb0afc: stp     s0, s1, [x19, #0xb8]                       ._noAdsIconStartPosition
02cb0b00: cbz     x0, #0x2cb0b2c                             
02cb0b04: mov     x1, xzr                                    
02cb0b08: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cb0b0c: cbz     x0, #0x2cb0b2c                             
02cb0b10: mov     x1, xzr                                    
02cb0b14: bl      #0x5b45c24                                 UnityEngine.Transform::get_localPosition
02cb0b18: stp     s0, s1, [x19, #0xc0]                       ._skinIconStartPosition
02cb0b1c: ldp     x20, x19, [sp, #0x20]                      
02cb0b20: ldp     x22, x21, [sp, #0x10]                      
02cb0b24: ldr     x30, [sp], #0x30                           
02cb0b28: ret                                                
02cb0b2c: bl      #0x2b7105c                                 fn_2b7105c
## OnCloseButtonClicked() -> void
---- RemoveAdsPackPopup::OnCloseButtonClicked 0x2cb0b30
02cb0b30: stp     x30, x19, [sp, #-0x10]!                    
02cb0b34: mov     x19, x0                                    
02cb0b38: mov     x0, xzr                                    
02cb0b3c: bl      #0x2d6ff04                                 Framework.AudioHelper::PlayClickSound
02cb0b40: ldr     x8, [x19]                                  
02cb0b44: mov     x0, x19                                    
02cb0b48: ldp     x2, x1, [x8, #0x198]                       
02cb0b4c: ldp     x30, x19, [sp], #0x10                      
02cb0b50: br      x2                                         
## OnNoAdsButtonClicked() -> void
---- RemoveAdsPackPopup::OnNoAdsButtonClicked 0x2cb0b54
02cb0b54: stp     x30, x23, [sp, #-0x30]!                    
02cb0b58: stp     x22, x21, [sp, #0x10]                      
02cb0b5c: stp     x20, x19, [sp, #0x20]                      
02cb0b60: adrp    x23, #0x662f000                            
02cb0b64: adrp    x22, #0x6264000                            
02cb0b68: adrp    x20, #0x6264000                            
02cb0b6c: adrp    x21, #0x6266000                            
02cb0b70: ldr     x22, [x22, #0xfa8]                         MS:WejoyService.Singleton`1::get_Instance
02cb0b74: ldrb    w8, [x23, #0xb6a]                          
02cb0b78: ldr     x20, [x20, #0xf90]                         T:System.Action
02cb0b7c: ldr     x21, [x21, #0xa60]                         M:RemoveAdsPackPopup::<OnNoAdsButtonClicked>b__20_0
02cb0b80: mov     x19, x0                                    
02cb0b84: tbnz    w8, #0, #0x2cb0bb4                         
02cb0b88: adrp    x0, #0x6264000                             
02cb0b8c: ldr     x0, [x0, #0xf90]                           T:System.Action
02cb0b90: bl      #0x2b70db0                                 fn_2b70db0
02cb0b94: adrp    x0, #0x6266000                             
02cb0b98: ldr     x0, [x0, #0xa60]                           M:RemoveAdsPackPopup::<OnNoAdsButtonClicked>b__20_0
02cb0b9c: bl      #0x2b70db0                                 fn_2b70db0
02cb0ba0: adrp    x0, #0x6264000                             
02cb0ba4: ldr     x0, [x0, #0xfa8]                           MS:WejoyService.Singleton`1::get_Instance
02cb0ba8: bl      #0x2b70db0                                 fn_2b70db0
02cb0bac: mov     w8, #1                                     
02cb0bb0: strb    w8, [x23, #0xb6a]                          
02cb0bb4: mov     x0, xzr                                    
02cb0bb8: bl      #0x2d6ff04                                 Framework.AudioHelper::PlayClickSound
02cb0bbc: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cb0bc0: bl      #0x3be7218                                 fn_3be7218
02cb0bc4: ldr     x8, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cb0bc8: mov     x20, x0                                    
02cb0bcc: mov     x0, x8                                     
02cb0bd0: bl      #0x2b7104c                                 fn_2b7104c
02cb0bd4: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb0bd8: mov     x1, x19                                    
02cb0bdc: mov     x3, xzr                                    
02cb0be0: mov     x21, x0                                    
02cb0be4: bl      #0x4d8ddbc                                 System.Action::.ctor
02cb0be8: cbz     x20, #0x2cb0c0c                            
02cb0bec: mov     x0, x20                                    
02cb0bf0: mov     x2, x21                                    
02cb0bf4: mov     w1, wzr                                    
02cb0bf8: ldp     x20, x19, [sp, #0x20]                      
02cb0bfc: mov     x3, xzr                                    
02cb0c00: ldp     x22, x21, [sp, #0x10]                      
02cb0c04: ldp     x30, x23, [sp], #0x30                      
02cb0c08: b       #0x2ca6df8                                 IAPManager::BuyProduct
02cb0c0c: bl      #0x2b7105c                                 fn_2b7105c
## OnSpecialPackButtonClicked() -> void
---- RemoveAdsPackPopup::OnSpecialPackButtonClicked 0x2cb0c10
02cb0c10: stp     x30, x23, [sp, #-0x30]!                    
02cb0c14: stp     x22, x21, [sp, #0x10]                      
02cb0c18: stp     x20, x19, [sp, #0x20]                      
02cb0c1c: adrp    x23, #0x662f000                            
02cb0c20: adrp    x22, #0x6264000                            
02cb0c24: adrp    x20, #0x6264000                            
02cb0c28: adrp    x21, #0x6266000                            
02cb0c2c: ldr     x22, [x22, #0xfa8]                         MS:WejoyService.Singleton`1::get_Instance
02cb0c30: ldrb    w8, [x23, #0xb6b]                          
02cb0c34: ldr     x20, [x20, #0xf90]                         T:System.Action
02cb0c38: ldr     x21, [x21, #0xa68]                         M:RemoveAdsPackPopup::<OnSpecialPackButtonClicked>b__21_0
02cb0c3c: mov     x19, x0                                    
02cb0c40: tbnz    w8, #0, #0x2cb0c70                         
02cb0c44: adrp    x0, #0x6264000                             
02cb0c48: ldr     x0, [x0, #0xf90]                           T:System.Action
02cb0c4c: bl      #0x2b70db0                                 fn_2b70db0
02cb0c50: adrp    x0, #0x6266000                             
02cb0c54: ldr     x0, [x0, #0xa68]                           M:RemoveAdsPackPopup::<OnSpecialPackButtonClicked>b__21_0
02cb0c58: bl      #0x2b70db0                                 fn_2b70db0
02cb0c5c: adrp    x0, #0x6264000                             
02cb0c60: ldr     x0, [x0, #0xfa8]                           MS:WejoyService.Singleton`1::get_Instance
02cb0c64: bl      #0x2b70db0                                 fn_2b70db0
02cb0c68: mov     w8, #1                                     
02cb0c6c: strb    w8, [x23, #0xb6b]                          
02cb0c70: mov     x0, xzr                                    
02cb0c74: bl      #0x2d6ff04                                 Framework.AudioHelper::PlayClickSound
02cb0c78: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cb0c7c: bl      #0x3be7218                                 fn_3be7218
02cb0c80: ldr     x8, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cb0c84: mov     x20, x0                                    
02cb0c88: mov     x0, x8                                     
02cb0c8c: bl      #0x2b7104c                                 fn_2b7104c
02cb0c90: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb0c94: mov     x1, x19                                    
02cb0c98: mov     x3, xzr                                    
02cb0c9c: mov     x21, x0                                    
02cb0ca0: bl      #0x4d8ddbc                                 System.Action::.ctor
02cb0ca4: cbz     x20, #0x2cb0cc8                            
02cb0ca8: mov     x0, x20                                    
02cb0cac: mov     x2, x21                                    
02cb0cb0: mov     w1, #1                                     
02cb0cb4: ldp     x20, x19, [sp, #0x20]                      
02cb0cb8: mov     x3, xzr                                    
02cb0cbc: ldp     x22, x21, [sp, #0x10]                      
02cb0cc0: ldp     x30, x23, [sp], #0x30                      
02cb0cc4: b       #0x2ca6df8                                 IAPManager::BuyProduct
02cb0cc8: bl      #0x2b7105c                                 fn_2b7105c
## OnInit(UIManager uiManager) -> void
---- RemoveAdsPackPopup::OnInit 0x2cb0ccc
02cb0ccc: str     x30, [sp, #-0x30]!                         
02cb0cd0: stp     x22, x21, [sp, #0x10]                      
02cb0cd4: stp     x20, x19, [sp, #0x20]                      
02cb0cd8: adrp    x22, #0x662f000                            
02cb0cdc: adrp    x21, #0x6264000                            
02cb0ce0: mov     x20, x1                                    
02cb0ce4: ldrb    w8, [x22, #0xb6c]                          
02cb0ce8: ldr     x21, [x21, #0xfa8]                         MS:WejoyService.Singleton`1::get_Instance
02cb0cec: mov     x19, x0                                    
02cb0cf0: tbnz    w8, #0, #0x2cb0d08                         
02cb0cf4: adrp    x0, #0x6264000                             
02cb0cf8: ldr     x0, [x0, #0xfa8]                           MS:WejoyService.Singleton`1::get_Instance
02cb0cfc: bl      #0x2b70db0                                 fn_2b70db0
02cb0d00: mov     w8, #1                                     
02cb0d04: strb    w8, [x22, #0xb6c]                          
02cb0d08: mov     x0, x19                                    
02cb0d0c: mov     x1, x20                                    
02cb0d10: mov     x2, xzr                                    
02cb0d14: bl      #0x2cdd3c4                                 UIBase::OnInit
02cb0d18: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cb0d1c: ldr     x20, [x19, #0x98]                          ._txtPriceNormal
02cb0d20: bl      #0x3be7218                                 fn_3be7218
02cb0d24: cbz     x0, #0x2cb0d8c                             
02cb0d28: mov     w1, wzr                                    
02cb0d2c: bl      #0x2ca7000                                 IAPManager::GetProductPrice
02cb0d30: cbz     x20, #0x2cb0d8c                            
02cb0d34: ldr     x8, [x20]                                  
02cb0d38: mov     x1, x0                                     
02cb0d3c: mov     x0, x20                                    
02cb0d40: ldr     x9, [x8, #0x558]                           
02cb0d44: ldr     x2, [x8, #0x560]                           
02cb0d48: blr     x9                                         
02cb0d4c: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cb0d50: ldr     x19, [x19, #0xa0]                          ._txtPriceSpecial
02cb0d54: bl      #0x3be7218                                 fn_3be7218
02cb0d58: cbz     x0, #0x2cb0d8c                             
02cb0d5c: mov     w1, #1                                     
02cb0d60: bl      #0x2ca7000                                 IAPManager::GetProductPrice
02cb0d64: cbz     x19, #0x2cb0d8c                            
02cb0d68: ldr     x8, [x19]                                  
02cb0d6c: mov     x1, x0                                     
02cb0d70: mov     x0, x19                                    
02cb0d74: ldp     x20, x19, [sp, #0x20]                      
02cb0d78: ldp     x22, x21, [sp, #0x10]                      
02cb0d7c: ldr     x2, [x8, #0x560]                           
02cb0d80: ldr     x3, [x8, #0x558]                           
02cb0d84: ldr     x30, [sp], #0x30                           
02cb0d88: br      x3                                         
02cb0d8c: bl      #0x2b7105c                                 fn_2b7105c
## OnShow() -> void
---- RemoveAdsPackPopup::OnShow 0x2cb0d90
02cb0d90: str     d8, [sp, #-0x30]!                          
02cb0d94: str     x30, [sp, #8]                              
02cb0d98: stp     x22, x21, [sp, #0x10]                      
02cb0d9c: stp     x20, x19, [sp, #0x20]                      
02cb0da0: adrp    x20, #0x662f000                            
02cb0da4: mov     x19, x0                                    
02cb0da8: ldrb    w8, [x20, #0xb6d]                          
02cb0dac: tbnz    w8, #0, #0x2cb0df4                         
02cb0db0: adrp    x0, #0x6264000                             
02cb0db4: ldr     x0, [x0, #0x8f8]                           T:UnityEngine.RectTransform
02cb0db8: bl      #0x2b70db0                                 fn_2b70db0
02cb0dbc: adrp    x0, #0x6266000                             
02cb0dc0: ldr     x0, [x0, #0xa70]                           MS:DG.Tweening.TweenSettingsExtensions::From
02cb0dc4: bl      #0x2b70db0                                 fn_2b70db0
02cb0dc8: adrp    x0, #0x6266000                             
02cb0dcc: ldr     x0, [x0, #0xa18]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02cb0dd0: bl      #0x2b70db0                                 fn_2b70db0
02cb0dd4: adrp    x0, #0x6266000                             
02cb0dd8: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02cb0ddc: bl      #0x2b70db0                                 fn_2b70db0
02cb0de0: adrp    x0, #0x6266000                             
02cb0de4: ldr     x0, [x0, #0xa78]                           MS:DG.Tweening.TweenSettingsExtensions::SetRelative
02cb0de8: bl      #0x2b70db0                                 fn_2b70db0
02cb0dec: mov     w8, #1                                     
02cb0df0: strb    w8, [x20, #0xb6d]                          
02cb0df4: mov     x0, x19                                    
02cb0df8: mov     x1, xzr                                    
02cb0dfc: bl      #0x2cdd6b8                                 UIBase::OnShow
02cb0e00: ldr     x0, [x19, #0x68]                           ._contentGroup
02cb0e04: cbz     x0, #0x2cb0f64                             
02cb0e08: fmov    s0, #1.00000000                            
02cb0e0c: mov     x1, xzr                                    
02cb0e10: bl      #0x5e45108                                 UnityEngine.CanvasGroup::set_alpha
02cb0e14: ldr     x0, [x19, #0x70]                           ._effectGroup
02cb0e18: cbz     x0, #0x2cb0f64                             
02cb0e1c: movi    d0, #0000000000000000                      
02cb0e20: mov     x1, xzr                                    
02cb0e24: bl      #0x5e45108                                 UnityEngine.CanvasGroup::set_alpha
02cb0e28: ldr     x0, [x19, #0x68]                           ._contentGroup
02cb0e2c: cbz     x0, #0x2cb0f64                             
02cb0e30: adrp    x20, #0x6266000                            
02cb0e34: adrp    x21, #0x6266000                            
02cb0e38: adrp    x22, #0x6266000                            
02cb0e3c: ldr     x20, [x20, #0xa70]                         MS:DG.Tweening.TweenSettingsExtensions::From
02cb0e40: ldr     x21, [x21, #0xa18]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02cb0e44: ldr     x22, [x22, #0xa78]                         MS:DG.Tweening.TweenSettingsExtensions::SetRelative
02cb0e48: mov     w1, #1                                     
02cb0e4c: mov     x2, xzr                                    
02cb0e50: bl      #0x5e45290                                 UnityEngine.CanvasGroup::set_interactable
02cb0e54: adrp    x9, #0x1084000                             
02cb0e58: mov     w8, #0x42c00000                            
02cb0e5c: ldr     x0, [x19, #0x38]                           ._packRect
02cb0e60: ldr     s8, [x9, #0xe60]                           [1084e60]=bc8efa353eb33333 f=0.35,-0.0174533
02cb0e64: fmov    s0, w8                                     
02cb0e68: mov     w1, wzr                                    
02cb0e6c: mov     x2, xzr                                    
02cb0e70: fmov    s1, s8                                     
02cb0e74: bl      #0x2c79c1c                                 DG.Tweening.DOTweenModuleUI::DOAnchorPosY
02cb0e78: ldr     x2, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb0e7c: mov     w1, #1                                     
02cb0e80: bl      #0x336f090                                 fn_336f090
02cb0e84: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb0e88: mov     w1, #0x1b                                  
02cb0e8c: bl      #0x336fa0c                                 fn_336fa0c
02cb0e90: ldr     x2, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb0e94: mov     w1, #1                                     
02cb0e98: bl      #0x336ff30                                 fn_336ff30
02cb0e9c: ldr     x0, [x19, #0x50]                           ._closeButton
02cb0ea0: cbz     x0, #0x2cb0f64                             
02cb0ea4: adrp    x20, #0x6266000                            
02cb0ea8: mov     x1, xzr                                    
02cb0eac: ldr     x20, [x20, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02cb0eb0: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cb0eb4: fmov    s1, s8                                     
02cb0eb8: fmov    s0, #1.00000000                            
02cb0ebc: mov     x1, xzr                                    
02cb0ec0: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02cb0ec4: movi    d0, #0000000000000000                      
02cb0ec8: mov     w1, #1                                     
02cb0ecc: mov     w2, wzr                                    
02cb0ed0: mov     x3, xzr                                    
02cb0ed4: bl      #0x2da0560                                 DG.Tweening.TweenSettingsExtensions::From
02cb0ed8: ldr     x2, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb0edc: mov     w1, #0x1b                                  
02cb0ee0: bl      #0x336fa0c                                 fn_336fa0c
02cb0ee4: ldr     x8, [x19, #0xb0]                           .dataSaveUser
02cb0ee8: cbz     x8, #0x2cb0f64                             
02cb0eec: ldrb    w8, [x8, #0x10]                            
02cb0ef0: cbz     w8, #0x2cb0f50                             
02cb0ef4: ldr     x0, [x19, #0x40]                           .noAdsPack
02cb0ef8: cbz     x0, #0x2cb0f64                             
02cb0efc: mov     w1, wzr                                    
02cb0f00: mov     x2, xzr                                    
02cb0f04: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02cb0f08: ldr     x0, [x19, #0x48]                           .specialPack
02cb0f0c: cbz     x0, #0x2cb0f64                             
02cb0f10: mov     x1, xzr                                    
02cb0f14: bl      #0x5b368f0                                 UnityEngine.GameObject::get_transform
02cb0f18: cbz     x0, #0x2cb0f34                             
02cb0f1c: adrp    x8, #0x6264000                             
02cb0f20: ldr     x8, [x8, #0x8f8]                           T:UnityEngine.RectTransform
02cb0f24: ldr     x9, [x0]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb0f28: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cb0f2c: cmp     x9, x8                                     
02cb0f30: csel    x0, x0, xzr, eq                            
02cb0f34: ldp     x20, x19, [sp, #0x20]                      
02cb0f38: movi    d0, #0000000000000000                      
02cb0f3c: ldp     x22, x21, [sp, #0x10]                      
02cb0f40: mov     x1, xzr                                    
02cb0f44: ldr     x30, [sp, #8]                              
02cb0f48: ldr     d8, [sp], #0x30                            
02cb0f4c: b       #0x2dbf2c4                                 Redcode.Extensions.RectTransformExtensions::SetAnchoredPositionX
02cb0f50: ldp     x20, x19, [sp, #0x20]                      
02cb0f54: ldr     x30, [sp, #8]                              
02cb0f58: ldp     x22, x21, [sp, #0x10]                      
02cb0f5c: ldr     d8, [sp], #0x30                            
02cb0f60: ret                                                
02cb0f64: bl      #0x2b7105c                                 fn_2b7105c
## OnHide() -> void
---- RemoveAdsPackPopup::OnHide 0x2cb0f68
02cb0f68: mov     x1, xzr                                    
02cb0f6c: b       #0x2cddc10                                 UIBase::OnHide
## PlayEarnNoAdsAnimation() -> void
---- RemoveAdsPackPopup::PlayEarnNoAdsAnimation 0x2cb0f70
02cb0f70: stp     x30, x25, [sp, #-0x40]!                    
02cb0f74: stp     x24, x23, [sp, #0x10]                      
02cb0f78: stp     x22, x21, [sp, #0x20]                      
02cb0f7c: stp     x20, x19, [sp, #0x30]                      
02cb0f80: adrp    x20, #0x662f000                            
02cb0f84: mov     x19, x0                                    
02cb0f88: ldrb    w8, [x20, #0xb6e]                          
02cb0f8c: tbnz    w8, #0, #0x2cb0fe0                         
02cb0f90: adrp    x0, #0x6266000                             
02cb0f94: ldr     x0, [x0, #0xa80]                           M:RemoveAdsPackPopup::<PlayEarnNoAdsAnimation>b__25_0
02cb0f98: bl      #0x2b70db0                                 fn_2b70db0
02cb0f9c: adrp    x0, #0x6264000                             
02cb0fa0: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02cb0fa4: bl      #0x2b70db0                                 fn_2b70db0
02cb0fa8: adrp    x0, #0x6266000                             
02cb0fac: ldr     x0, [x0, #0xa88]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02cb0fb0: bl      #0x2b70db0                                 fn_2b70db0
02cb0fb4: adrp    x0, #0x6266000                             
02cb0fb8: ldr     x0, [x0, #0xa90]                           MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02cb0fbc: bl      #0x2b70db0                                 fn_2b70db0
02cb0fc0: adrp    x0, #0x6264000                             
02cb0fc4: ldr     x0, [x0, #0x100]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02cb0fc8: bl      #0x2b70db0                                 fn_2b70db0
02cb0fcc: adrp    x0, #0x6266000                             
02cb0fd0: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02cb0fd4: bl      #0x2b70db0                                 fn_2b70db0
02cb0fd8: mov     w8, #1                                     
02cb0fdc: strb    w8, [x20, #0xb6e]                          
02cb0fe0: fmov    s0, #1.00000000                            
02cb0fe4: ldr     x0, [x19, #0x78]                           ._noAdsIcon
02cb0fe8: mov     x1, xzr                                    
02cb0fec: bl      #0x2cb8cf4                                 Framework.ImageExtension::SetAlpha
02cb0ff0: ldr     x0, [x19, #0x78]                           ._noAdsIcon
02cb0ff4: cbz     x0, #0x2cb112c                             
02cb0ff8: mov     x1, xzr                                    
02cb0ffc: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cb1000: cbz     x0, #0x2cb112c                             
02cb1004: movi    d2, #0000000000000000                      
02cb1008: ldp     s0, s1, [x19, #0xb8]                       ._noAdsIconStartPosition
02cb100c: mov     x1, xzr                                    
02cb1010: bl      #0x5b45cec                                 UnityEngine.Transform::set_localPosition
02cb1014: ldr     x0, [x19, #0x78]                           ._noAdsIcon
02cb1018: cbz     x0, #0x2cb112c                             
02cb101c: adrp    x20, #0x6266000                            
02cb1020: mov     x1, xzr                                    
02cb1024: ldr     x20, [x20, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02cb1028: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cb102c: adrp    x8, #0x1084000                             
02cb1030: fmov    s0, #1.00000000                            
02cb1034: mov     x1, xzr                                    
02cb1038: ldr     s1, [x8, #0xe60]                           [1084e60]=bc8efa353eb33333 f=0.35,-0.0174533
02cb103c: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02cb1040: movi    d0, #0000000000000000                      
02cb1044: mov     w1, #1                                     
02cb1048: mov     w2, wzr                                    
02cb104c: mov     x3, xzr                                    
02cb1050: bl      #0x2da0560                                 DG.Tweening.TweenSettingsExtensions::From
02cb1054: ldr     x2, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb1058: mov     w1, #0x1b                                  
02cb105c: bl      #0x336fa0c                                 fn_336fa0c
02cb1060: ldr     x0, [x19, #0x78]                           ._noAdsIcon
02cb1064: cbz     x0, #0x2cb112c                             
02cb1068: mov     x1, xzr                                    
02cb106c: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cb1070: ldr     x8, [x19, #0x88]                           ._noAdsPosition
02cb1074: cbz     x8, #0x2cb112c                             
02cb1078: adrp    x21, #0x6266000                            
02cb107c: adrp    x23, #0x6264000                            
02cb1080: adrp    x24, #0x6264000                            
02cb1084: adrp    x25, #0x6266000                            
02cb1088: adrp    x22, #0x6266000                            
02cb108c: mov     x20, x0                                    
02cb1090: ldr     x21, [x21, #0xa90]                         MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02cb1094: ldr     x23, [x23, #0x100]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02cb1098: ldr     x24, [x24, #0xe8]                          T:DG.Tweening.TweenCallback
02cb109c: ldr     x25, [x25, #0xa80]                         M:RemoveAdsPackPopup::<PlayEarnNoAdsAnimation>b__25_0
02cb10a0: ldr     x22, [x22, #0xa88]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02cb10a4: mov     x0, x8                                     
02cb10a8: mov     x1, xzr                                    
02cb10ac: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02cb10b0: fmov    s3, #-1.50000000                           
02cb10b4: fmov    s4, #1.00000000                            
02cb10b8: mov     x0, x20                                    
02cb10bc: mov     w1, #1                                     
02cb10c0: mov     w2, wzr                                    
02cb10c4: mov     x3, xzr                                    
02cb10c8: bl      #0x2d9abb0                                 DG.Tweening.ShortcutExtensions::DOJump
02cb10cc: adrp    x8, #0x1084000                             
02cb10d0: ldr     x1, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb10d4: ldr     s0, [x8, #0xfac]                           [1084fac]=3ecccccd3f333333 f=0.7,0.4
02cb10d8: bl      #0x336f7fc                                 fn_336f7fc
02cb10dc: ldr     x2, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cb10e0: mov     w1, #5                                     
02cb10e4: bl      #0x336fa0c                                 fn_336fa0c
02cb10e8: ldr     x8, [x24]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cb10ec: mov     x20, x0                                    
02cb10f0: mov     x0, x8                                     
02cb10f4: bl      #0x2b7104c                                 fn_2b7104c
02cb10f8: ldr     x2, [x25]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb10fc: mov     x1, x19                                    
02cb1100: mov     x3, xzr                                    
02cb1104: mov     x21, x0                                    
02cb1108: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02cb110c: ldr     x2, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb1110: mov     x0, x20                                    
02cb1114: mov     x1, x21                                    
02cb1118: ldp     x20, x19, [sp, #0x30]                      
02cb111c: ldp     x22, x21, [sp, #0x20]                      
02cb1120: ldp     x24, x23, [sp, #0x10]                      
02cb1124: ldp     x30, x25, [sp], #0x40                      
02cb1128: b       #0x336f26c                                 
02cb112c: bl      #0x2b7105c                                 fn_2b7105c
## PlayEarnSkinAnimation() -> void
---- RemoveAdsPackPopup::PlayEarnSkinAnimation 0x2cb1130
02cb1130: stp     x30, x25, [sp, #-0x40]!                    
02cb1134: stp     x24, x23, [sp, #0x10]                      
02cb1138: stp     x22, x21, [sp, #0x20]                      
02cb113c: stp     x20, x19, [sp, #0x30]                      
02cb1140: adrp    x20, #0x662f000                            
02cb1144: mov     x19, x0                                    
02cb1148: ldrb    w8, [x20, #0xb6f]                          
02cb114c: tbnz    w8, #0, #0x2cb11a0                         
02cb1150: adrp    x0, #0x6266000                             
02cb1154: ldr     x0, [x0, #0xa98]                           M:RemoveAdsPackPopup::<PlayEarnSkinAnimation>b__26_0
02cb1158: bl      #0x2b70db0                                 fn_2b70db0
02cb115c: adrp    x0, #0x6264000                             
02cb1160: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02cb1164: bl      #0x2b70db0                                 fn_2b70db0
02cb1168: adrp    x0, #0x6266000                             
02cb116c: ldr     x0, [x0, #0xa88]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02cb1170: bl      #0x2b70db0                                 fn_2b70db0
02cb1174: adrp    x0, #0x6266000                             
02cb1178: ldr     x0, [x0, #0xa90]                           MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02cb117c: bl      #0x2b70db0                                 fn_2b70db0
02cb1180: adrp    x0, #0x6264000                             
02cb1184: ldr     x0, [x0, #0x100]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02cb1188: bl      #0x2b70db0                                 fn_2b70db0
02cb118c: adrp    x0, #0x6266000                             
02cb1190: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02cb1194: bl      #0x2b70db0                                 fn_2b70db0
02cb1198: mov     w8, #1                                     
02cb119c: strb    w8, [x20, #0xb6f]                          
02cb11a0: fmov    s0, #1.00000000                            
02cb11a4: ldr     x0, [x19, #0x80]                           ._skinIcon
02cb11a8: mov     x1, xzr                                    
02cb11ac: bl      #0x2cb8cf4                                 Framework.ImageExtension::SetAlpha
02cb11b0: ldr     x0, [x19, #0x80]                           ._skinIcon
02cb11b4: cbz     x0, #0x2cb12d4                             
02cb11b8: mov     x1, xzr                                    
02cb11bc: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cb11c0: cbz     x0, #0x2cb12d4                             
02cb11c4: movi    d2, #0000000000000000                      
02cb11c8: ldp     s0, s1, [x19, #0xc0]                       ._skinIconStartPosition
02cb11cc: mov     x1, xzr                                    
02cb11d0: bl      #0x5b45cec                                 UnityEngine.Transform::set_localPosition
02cb11d4: ldr     x0, [x19, #0x80]                           ._skinIcon
02cb11d8: cbz     x0, #0x2cb12d4                             
02cb11dc: adrp    x20, #0x6266000                            
02cb11e0: mov     x1, xzr                                    
02cb11e4: ldr     x20, [x20, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02cb11e8: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cb11ec: adrp    x8, #0x1084000                             
02cb11f0: fmov    s0, #1.00000000                            
02cb11f4: mov     x1, xzr                                    
02cb11f8: ldr     s1, [x8, #0xe60]                           [1084e60]=bc8efa353eb33333 f=0.35,-0.0174533
02cb11fc: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02cb1200: ldr     x2, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb1204: mov     w1, #0x1b                                  
02cb1208: bl      #0x336fa0c                                 fn_336fa0c
02cb120c: ldr     x0, [x19, #0x80]                           ._skinIcon
02cb1210: cbz     x0, #0x2cb12d4                             
02cb1214: mov     x1, xzr                                    
02cb1218: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cb121c: ldr     x8, [x19, #0x90]                           ._skinPosition
02cb1220: cbz     x8, #0x2cb12d4                             
02cb1224: adrp    x21, #0x6266000                            
02cb1228: adrp    x23, #0x6264000                            
02cb122c: adrp    x24, #0x6264000                            
02cb1230: adrp    x25, #0x6266000                            
02cb1234: adrp    x22, #0x6266000                            
02cb1238: mov     x20, x0                                    
02cb123c: ldr     x21, [x21, #0xa90]                         MS:DG.Tweening.TweenSettingsExtensions::SetDelay
02cb1240: ldr     x23, [x23, #0x100]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02cb1244: ldr     x24, [x24, #0xe8]                          T:DG.Tweening.TweenCallback
02cb1248: ldr     x25, [x25, #0xa98]                         M:RemoveAdsPackPopup::<PlayEarnSkinAnimation>b__26_0
02cb124c: ldr     x22, [x22, #0xa88]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02cb1250: mov     x0, x8                                     
02cb1254: mov     x1, xzr                                    
02cb1258: bl      #0x5b467ac                                 UnityEngine.Transform::get_position
02cb125c: fmov    s3, #-1.50000000                           
02cb1260: fmov    s4, #1.00000000                            
02cb1264: mov     x0, x20                                    
02cb1268: mov     w1, #1                                     
02cb126c: mov     w2, wzr                                    
02cb1270: mov     x3, xzr                                    
02cb1274: bl      #0x2d9abb0                                 DG.Tweening.ShortcutExtensions::DOJump
02cb1278: fmov    s0, #0.50000000                            
02cb127c: ldr     x1, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb1280: bl      #0x336f7fc                                 fn_336f7fc
02cb1284: ldr     x2, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cb1288: mov     w1, #5                                     
02cb128c: bl      #0x336fa0c                                 fn_336fa0c
02cb1290: ldr     x8, [x24]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cb1294: mov     x20, x0                                    
02cb1298: mov     x0, x8                                     
02cb129c: bl      #0x2b7104c                                 fn_2b7104c
02cb12a0: ldr     x2, [x25]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb12a4: mov     x1, x19                                    
02cb12a8: mov     x3, xzr                                    
02cb12ac: mov     x21, x0                                    
02cb12b0: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02cb12b4: ldr     x2, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb12b8: mov     x0, x20                                    
02cb12bc: mov     x1, x21                                    
02cb12c0: ldp     x20, x19, [sp, #0x30]                      
02cb12c4: ldp     x22, x21, [sp, #0x20]                      
02cb12c8: ldp     x24, x23, [sp, #0x10]                      
02cb12cc: ldp     x30, x25, [sp], #0x40                      
02cb12d0: b       #0x336f26c                                 
02cb12d4: bl      #0x2b7105c                                 fn_2b7105c
## HandleStartShowEarnAnimation() -> void
---- RemoveAdsPackPopup::HandleStartShowEarnAnimation 0x2cb12d8
02cb12d8: str     d8, [sp, #-0x20]!                          
02cb12dc: stp     x30, x19, [sp, #0x10]                      
02cb12e0: movi    d1, #0000000000000000                      
02cb12e4: movi    d2, #0000000000000000                      
02cb12e8: mov     x19, x0                                    
02cb12ec: fmov    s0, #1.00000000                            
02cb12f0: mov     w0, #0x2f                                  
02cb12f4: mov     w1, wzr                                    
02cb12f8: mov     w2, wzr                                    
02cb12fc: mov     x3, xzr                                    
02cb1300: bl      #0x2d84264                                 Framework.AudioHelper::PlaySound
02cb1304: ldr     x0, [x19, #0x68]                           ._contentGroup
02cb1308: cbz     x0, #0x2cb1350                             
02cb130c: mov     w1, wzr                                    
02cb1310: mov     x2, xzr                                    
02cb1314: bl      #0x5e45290                                 UnityEngine.CanvasGroup::set_interactable
02cb1318: adrp    x8, #0x1084000                             
02cb131c: movi    d0, #0000000000000000                      
02cb1320: ldr     x0, [x19, #0x68]                           ._contentGroup
02cb1324: ldr     s8, [x8, #0xe60]                           [1084e60]=bc8efa353eb33333 f=0.35,-0.0174533
02cb1328: mov     x1, xzr                                    
02cb132c: fmov    s1, s8                                     
02cb1330: bl      #0x2c78338                                 DG.Tweening.DOTweenModuleUI::DOFade
02cb1334: ldr     x0, [x19, #0x70]                           ._effectGroup
02cb1338: ldp     x30, x19, [sp, #0x10]                      
02cb133c: fmov    s0, #1.00000000                            
02cb1340: fmov    s1, s8                                     
02cb1344: mov     x1, xzr                                    
02cb1348: ldr     d8, [sp], #0x20                            
02cb134c: b       #0x2c78338                                 DG.Tweening.DOTweenModuleUI::DOFade
02cb1350: bl      #0x2b7105c                                 fn_2b7105c
## HandleSuccessPurchase() -> void
---- RemoveAdsPackPopup::HandleSuccessPurchase 0x2cb1354
02cb1354: stp     x30, x21, [sp, #-0x20]!                    
02cb1358: stp     x20, x19, [sp, #0x10]                      
02cb135c: adrp    x20, #0x662f000                            
02cb1360: adrp    x21, #0x6264000                            
02cb1364: mov     x19, x0                                    
02cb1368: ldrb    w8, [x20, #0xb70]                          
02cb136c: ldr     x21, [x21, #0xe8]                          T:DG.Tweening.TweenCallback
02cb1370: tbnz    w8, #0, #0x2cb1388                         
02cb1374: adrp    x0, #0x6264000                             
02cb1378: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02cb137c: bl      #0x2b70db0                                 fn_2b70db0
02cb1380: mov     w8, #1                                     
02cb1384: strb    w8, [x20, #0xb70]                          
02cb1388: ldr     x0, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02cb138c: bl      #0x2b7104c                                 fn_2b7104c
02cb1390: cbz     x19, #0x2cb13c8                            
02cb1394: ldr     x8, [x19]                                  
02cb1398: mov     x1, x19                                    
02cb139c: mov     x3, xzr                                    
02cb13a0: mov     x20, x0                                    
02cb13a4: ldr     x2, [x8, #0x1a0]                           
02cb13a8: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02cb13ac: mov     x0, x20                                    
02cb13b0: ldp     x20, x19, [sp, #0x10]                      
02cb13b4: fmov    s0, #3.00000000                            
02cb13b8: mov     w1, #1                                     
02cb13bc: mov     x2, xzr                                    
02cb13c0: ldp     x30, x21, [sp], #0x20                      
02cb13c4: b       #0x2d8f37c                                 DG.Tweening.DOVirtual::DelayedCall
02cb13c8: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- RemoveAdsPackPopup::.ctor 0x2cb13cc
02cb13cc: mov     x1, xzr                                    
02cb13d0: b       #0x2cddba8                                 PopupBase::.ctor
## <OnNoAdsButtonClicked>b__20_0() -> void
---- RemoveAdsPackPopup::<OnNoAdsButtonClicked>b__20_0 0x2cb13d4
02cb13d4: stp     x30, x21, [sp, #-0x20]!                    
02cb13d8: stp     x20, x19, [sp, #0x10]                      
02cb13dc: adrp    x20, #0x662f000                            
02cb13e0: adrp    x21, #0x6265000                            
02cb13e4: mov     x19, x0                                    
02cb13e8: ldrb    w8, [x20, #0xb71]                          
02cb13ec: ldr     x21, [x21, #0x310]                         MS:WejoyService.Singleton`1::get_Instance
02cb13f0: tbnz    w8, #0, #0x2cb1414                         
02cb13f4: adrp    x0, #0x6266000                             
02cb13f8: ldr     x0, [x0, #0xaa0]                           MS:MonoSingleton`1::get_Instance
02cb13fc: bl      #0x2b70db0                                 fn_2b70db0
02cb1400: adrp    x0, #0x6265000                             
02cb1404: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02cb1408: bl      #0x2b70db0                                 fn_2b70db0
02cb140c: mov     w8, #1                                     
02cb1410: strb    w8, [x20, #0xb71]                          
02cb1414: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02cb1418: bl      #0x3be7218                                 fn_3be7218
02cb141c: cbz     x0, #0x2cb1498                             
02cb1420: adrp    x20, #0x6266000                            
02cb1424: mov     x1, xzr                                    
02cb1428: ldr     x20, [x20, #0xaa0]                         MS:MonoSingleton`1::get_Instance
02cb142c: bl      #0x2c88d70                                 AdsManager::RemoveAds
02cb1430: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb1434: bl      #0x3769600                                 fn_3769600
02cb1438: cbz     x0, #0x2cb1498                             
02cb143c: mov     w1, #0x1f4                                 
02cb1440: mov     w2, #0xa                                   
02cb1444: mov     x3, xzr                                    
02cb1448: mov     x4, xzr                                    
02cb144c: bl      #0x2cdaf30                                 MoneyManager::CollectMoney
02cb1450: ldr     x0, [x19, #0xa8]                           .dataUser
02cb1454: cbz     x0, #0x2cb1498                             
02cb1458: ldr     x8, [x0, #0x20]                            S:'dev log AdsManager show app open ad'
02cb145c: cbz     x8, #0x2cb1498                             
02cb1460: mov     w9, #1                                     
02cb1464: strb    w9, [x8, #0x10]                            
02cb1468: ldr     x8, [x0]                                   M:AdsManager::<OnApplicationPause>b__26_0
02cb146c: ldr     x9, [x8, #0x258]                           
02cb1470: ldr     x1, [x8, #0x260]                           
02cb1474: blr     x9                                         
02cb1478: mov     x0, x19                                    
02cb147c: bl      #0x2cb12d8                                 RemoveAdsPackPopup::HandleStartShowEarnAnimation
02cb1480: mov     x0, x19                                    
02cb1484: bl      #0x2cb0f70                                 RemoveAdsPackPopup::PlayEarnNoAdsAnimation
02cb1488: mov     x0, x19                                    
02cb148c: ldp     x20, x19, [sp, #0x10]                      
02cb1490: ldp     x30, x21, [sp], #0x20                      
02cb1494: b       #0x2cb1354                                 RemoveAdsPackPopup::HandleSuccessPurchase
02cb1498: bl      #0x2b7105c                                 fn_2b7105c
## <OnSpecialPackButtonClicked>b__21_0() -> void
---- RemoveAdsPackPopup::<OnSpecialPackButtonClicked>b__21_0 0x2cb149c
02cb149c: stp     x30, x21, [sp, #-0x20]!                    
02cb14a0: stp     x20, x19, [sp, #0x10]                      
02cb14a4: adrp    x20, #0x662f000                            
02cb14a8: adrp    x21, #0x6265000                            
02cb14ac: mov     x19, x0                                    
02cb14b0: ldrb    w8, [x20, #0xb72]                          
02cb14b4: ldr     x21, [x21, #0x310]                         MS:WejoyService.Singleton`1::get_Instance
02cb14b8: tbnz    w8, #0, #0x2cb14dc                         
02cb14bc: adrp    x0, #0x6266000                             
02cb14c0: ldr     x0, [x0, #0xaa0]                           MS:MonoSingleton`1::get_Instance
02cb14c4: bl      #0x2b70db0                                 fn_2b70db0
02cb14c8: adrp    x0, #0x6265000                             
02cb14cc: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02cb14d0: bl      #0x2b70db0                                 fn_2b70db0
02cb14d4: mov     w8, #1                                     
02cb14d8: strb    w8, [x20, #0xb72]                          
02cb14dc: ldr     x0, [x21]                                  M:AdsManager::<OnApplicationPause>b__26_0
02cb14e0: bl      #0x3be7218                                 fn_3be7218
02cb14e4: cbz     x0, #0x2cb1568                             
02cb14e8: adrp    x20, #0x6266000                            
02cb14ec: mov     x1, xzr                                    
02cb14f0: ldr     x20, [x20, #0xaa0]                         MS:MonoSingleton`1::get_Instance
02cb14f4: bl      #0x2c88d70                                 AdsManager::RemoveAds
02cb14f8: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb14fc: bl      #0x3769600                                 fn_3769600
02cb1500: cbz     x0, #0x2cb1568                             
02cb1504: mov     w1, #0x2710                                
02cb1508: mov     w2, #0xa                                   
02cb150c: mov     x3, xzr                                    
02cb1510: mov     x4, xzr                                    
02cb1514: bl      #0x2cdaf30                                 MoneyManager::CollectMoney
02cb1518: ldr     x0, [x19, #0xa8]                           .dataUser
02cb151c: cbz     x0, #0x2cb1568                             
02cb1520: ldr     x8, [x0, #0x20]                            S:'dev log AdsManager show app open ad'
02cb1524: cbz     x8, #0x2cb1568                             
02cb1528: mov     w9, #0x101                                 
02cb152c: strh    w9, [x8, #0x10]                            
02cb1530: ldr     x8, [x0]                                   M:AdsManager::<OnApplicationPause>b__26_0
02cb1534: ldr     x9, [x8, #0x258]                           
02cb1538: ldr     x1, [x8, #0x260]                           
02cb153c: blr     x9                                         
02cb1540: mov     x0, x19                                    
02cb1544: bl      #0x2cb12d8                                 RemoveAdsPackPopup::HandleStartShowEarnAnimation
02cb1548: mov     x0, x19                                    
02cb154c: bl      #0x2cb0f70                                 RemoveAdsPackPopup::PlayEarnNoAdsAnimation
02cb1550: mov     x0, x19                                    
02cb1554: bl      #0x2cb1130                                 RemoveAdsPackPopup::PlayEarnSkinAnimation
02cb1558: mov     x0, x19                                    
02cb155c: ldp     x20, x19, [sp, #0x10]                      
02cb1560: ldp     x30, x21, [sp], #0x20                      
02cb1564: b       #0x2cb1354                                 RemoveAdsPackPopup::HandleSuccessPurchase
02cb1568: bl      #0x2b7105c                                 fn_2b7105c
## <PlayEarnNoAdsAnimation>b__25_0() -> void
---- RemoveAdsPackPopup::<PlayEarnNoAdsAnimation>b__25_0 0x2cb156c
02cb156c: str     d8, [sp, #-0x20]!                          
02cb1570: stp     x30, x19, [sp, #0x10]                      
02cb1574: mov     x19, x0                                    
02cb1578: ldr     x0, [x0, #0x78]                            ._noAdsIcon
02cb157c: cbz     x0, #0x2cb15c0                             
02cb1580: mov     x1, xzr                                    
02cb1584: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cb1588: adrp    x9, #0x1084000                             
02cb158c: adrp    x8, #0x1084000                             
02cb1590: mov     x1, xzr                                    
02cb1594: ldr     s8, [x9, #0xdd8]                           [1084dd8]=3f7333333e4ccccd f=0.2,0.95
02cb1598: ldr     s0, [x8, #0xcf4]                           [1084cf4]=431d80003f99999a f=1.2,157.5
02cb159c: fmov    s1, s8                                     
02cb15a0: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02cb15a4: ldr     x0, [x19, #0x78]                           ._noAdsIcon
02cb15a8: ldp     x30, x19, [sp, #0x10]                      
02cb15ac: movi    d0, #0000000000000000                      
02cb15b0: fmov    s1, s8                                     
02cb15b4: mov     x1, xzr                                    
02cb15b8: ldr     d8, [sp], #0x20                            
02cb15bc: b       #0x2c789b8                                 DG.Tweening.DOTweenModuleUI::DOFade
02cb15c0: bl      #0x2b7105c                                 fn_2b7105c
## <PlayEarnSkinAnimation>b__26_0() -> void
---- RemoveAdsPackPopup::<PlayEarnSkinAnimation>b__26_0 0x2cb15c4
02cb15c4: str     d8, [sp, #-0x20]!                          
02cb15c8: stp     x30, x19, [sp, #0x10]                      
02cb15cc: mov     x19, x0                                    
02cb15d0: ldr     x0, [x0, #0x80]                            ._skinIcon
02cb15d4: cbz     x0, #0x2cb1618                             
02cb15d8: mov     x1, xzr                                    
02cb15dc: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02cb15e0: adrp    x9, #0x1084000                             
02cb15e4: adrp    x8, #0x1084000                             
02cb15e8: mov     x1, xzr                                    
02cb15ec: ldr     s8, [x9, #0xdd8]                           [1084dd8]=3f7333333e4ccccd f=0.2,0.95
02cb15f0: ldr     s0, [x8, #0xcf4]                           [1084cf4]=431d80003f99999a f=1.2,157.5
02cb15f4: fmov    s1, s8                                     
02cb15f8: bl      #0x2d98c98                                 DG.Tweening.ShortcutExtensions::DOScale
02cb15fc: ldr     x0, [x19, #0x80]                           ._skinIcon
02cb1600: ldp     x30, x19, [sp, #0x10]                      
02cb1604: movi    d0, #0000000000000000                      
02cb1608: fmov    s1, s8                                     
02cb160c: mov     x1, xzr                                    
02cb1610: ldr     d8, [sp], #0x20                            
02cb1614: b       #0x2c789b8                                 DG.Tweening.DOTweenModuleUI::DOFade
02cb1618: bl      #0x2b7105c                                 fn_2b7105c
