#### CLASS Blindbag.StoreScreen parent= ScreenBase
#   field _itemCountText                 TMPro.TextMeshProUGUI                              off=0x38 attr=1 SerializeField
#   field _priceText                     TMPro.TextMeshProUGUI                              off=0x40 attr=1 SerializeField
#   field _confirmOrderButton            Blindbag.MarketButton                              off=0x48 attr=1 SerializeField
#   field _confirmBuyButton              Blindbag.MarketButton                              off=0x50 attr=1 SerializeField
#   field _closeButton                   UnityEngine.UI.Button                              off=0x58 attr=1 SerializeField
#   field _bottomPanel                   UnityEngine.GameObject                             off=0x60 attr=1 SerializeField
#   field _blockScreen                   UnityEngine.GameObject                             off=0x68 attr=1 SerializeField
#   field _cartFullNotiCanvas            Blindbag.NotiCanvas                                off=0x70 attr=1 SerializeField
#   field _itemCounterRectTransform      UnityEngine.RectTransform                          off=0x78 attr=1 SerializeField
#   field _totalPriceRectTransform       UnityEngine.RectTransform                          off=0x80 attr=1 SerializeField
#   field _closeButtonTransform          UnityEngine.RectTransform                          off=0x88 attr=1 SerializeField
#   field _moneyRectTransform            UnityEngine.RectTransform                          off=0x90 attr=1 SerializeField
#   field _confirmOrderRectTransform     UnityEngine.RectTransform                          off=0x98 attr=1 SerializeField
#   field OnMoveLeftClicked              UnityEngine.Events.UnityAction                     off=0xa0 attr=6 
#   field OnMoveRightClicked             UnityEngine.Events.UnityAction                     off=0xa8 attr=6 
#   field OnOrderButtonClicked           UnityEngine.Events.UnityAction                     off=0xb0 attr=6 
#   field OnBuyButtonClicked             UnityEngine.Events.UnityAction                     off=0xb8 attr=6 
## SetActiveShoppingUI(bool enable) -> void
---- Blindbag.StoreScreen::SetActiveShoppingUI 0x2d5201c
02d5201c: ldr     x0, [x0, #0x60]                            ._bottomPanel
02d52020: cbz     x0, #0x2d52030                             
02d52024: and     w1, w1, #1                                 
02d52028: mov     x2, xzr                                    
02d5202c: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d52030: str     x30, [sp, #-0x10]!                         
02d52034: bl      #0x2b7105c                                 fn_2b7105c
## ShowCartFullNotification(float duration) -> void
---- Blindbag.StoreScreen::ShowCartFullNotification 0x2d50fd8
02d50fd8: str     d8, [sp, #-0x20]!                          
02d50fdc: stp     x30, x19, [sp, #0x10]                      
02d50fe0: mov     x19, x0                                    
02d50fe4: ldr     x0, [x0, #0x70]                            ._cartFullNotiCanvas
02d50fe8: cbz     x0, #0x2d51010                             
02d50fec: fmov    s8, s0                                     
02d50ff0: bl      #0x2d57d2c                                 Blindbag.NotiCanvas::ResetItem
02d50ff4: ldr     x0, [x19, #0x70]                           ._cartFullNotiCanvas
02d50ff8: cbz     x0, #0x2d51010                             
02d50ffc: ldp     x30, x19, [sp, #0x10]                      
02d51000: fmov    s0, s8                                     
02d51004: mov     x1, xzr                                    
02d51008: ldr     d8, [sp], #0x20                            
02d5100c: b       #0x2d57ba4                                 Blindbag.NotiCanvas::Show
02d51010: bl      #0x2b7105c                                 fn_2b7105c
## SetActiveBuyButton(bool active) -> void
---- Blindbag.StoreScreen::SetActiveBuyButton 0x2d57df8
02d57df8: str     x30, [sp, #-0x30]!                         
02d57dfc: stp     x22, x21, [sp, #0x10]                      
02d57e00: stp     x20, x19, [sp, #0x20]                      
02d57e04: mov     x19, x0                                    
02d57e08: ldr     x0, [x0, #0x50]                            ._confirmBuyButton
02d57e0c: cbz     x0, #0x2d57efc                             
02d57e10: mov     w20, w1                                    
02d57e14: mov     x1, xzr                                    
02d57e18: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d57e1c: cbz     x0, #0x2d57efc                             
02d57e20: and     w1, w20, #1                                
02d57e24: mov     x2, xzr                                    
02d57e28: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d57e2c: ldr     x0, [x19, #0x50]                           ._confirmBuyButton
02d57e30: cbz     x0, #0x2d57efc                             
02d57e34: mov     x1, xzr                                    
02d57e38: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d57e3c: adrp    x21, #0x662f000                            
02d57e40: mov     x20, x0                                    
02d57e44: ldrb    w8, [x21, #0x91a]                          
02d57e48: cbnz    w8, #0x2d57e60                             
02d57e4c: adrp    x0, #0x6264000                             
02d57e50: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d57e54: bl      #0x2b70db0                                 fn_2b70db0
02d57e58: mov     w8, #1                                     
02d57e5c: strb    w8, [x21, #0x91a]                          
02d57e60: cbz     x20, #0x2d57efc                            
02d57e64: adrp    x21, #0x6264000                            
02d57e68: mov     x0, x20                                    
02d57e6c: mov     x1, xzr                                    
02d57e70: ldr     x21, [x21, #0xd8]                          T:UnityEngine.Vector3
02d57e74: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d57e78: ldr     x8, [x8, #0xb8]                            
02d57e7c: ldp     s1, s2, [x8, #4]                           
02d57e80: ldr     s0, [x8]                                   
02d57e84: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d57e88: ldr     x0, [x19, #0x50]                           ._confirmBuyButton
02d57e8c: cbz     x0, #0x2d57efc                             
02d57e90: mov     x1, xzr                                    
02d57e94: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d57e98: adrp    x22, #0x662f000                            
02d57e9c: mov     x20, x0                                    
02d57ea0: ldrb    w8, [x22, #0xa74]                          
02d57ea4: cbnz    w8, #0x2d57ebc                             
02d57ea8: adrp    x0, #0x6264000                             
02d57eac: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d57eb0: bl      #0x2b70db0                                 fn_2b70db0
02d57eb4: mov     w8, #1                                     
02d57eb8: strb    w8, [x22, #0xa74]                          
02d57ebc: ldr     x8, [x21]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d57ec0: mov     x0, x20                                    
02d57ec4: mov     x1, xzr                                    
02d57ec8: ldr     x8, [x8, #0xb8]                            
02d57ecc: ldp     s0, s1, [x8, #0xc]                         
02d57ed0: ldr     s2, [x8, #0x14]                            
02d57ed4: adrp    x8, #0x1084000                             
02d57ed8: ldr     s3, [x8, #0xe60]                           [1084e60]=bc8efa353eb33333 f=0.35,-0.0174533
02d57edc: bl      #0x2d98af8                                 DG.Tweening.ShortcutExtensions::DOScale
02d57ee0: ldr     x0, [x19, #0x50]                           ._confirmBuyButton
02d57ee4: cbz     x0, #0x2d57efc                             
02d57ee8: ldp     x20, x19, [sp, #0x20]                      
02d57eec: mov     w1, #1                                     
02d57ef0: ldp     x22, x21, [sp, #0x10]                      
02d57ef4: ldr     x30, [sp], #0x30                           
02d57ef8: b       #0x2d57b24                                 Blindbag.MarketButton::EnableState
02d57efc: bl      #0x2b7105c                                 fn_2b7105c
## OnInit(UIManager uiManager) -> void
---- Blindbag.StoreScreen::OnInit 0x2d57f00
02d57f00: str     x30, [sp, #-0x30]!                         
02d57f04: stp     x22, x21, [sp, #0x10]                      
02d57f08: stp     x20, x19, [sp, #0x20]                      
02d57f0c: adrp    x21, #0x6630000                            
02d57f10: mov     x20, x1                                    
02d57f14: mov     x19, x0                                    
02d57f18: ldrb    w8, [x21, #0x299]                          
02d57f1c: tbnz    w8, #0, #0x2d57f58                         
02d57f20: adrp    x0, #0x626b000                             
02d57f24: ldr     x0, [x0, #0xa88]                           M:Blindbag.StoreScreen::<OnInit>b__20_0
02d57f28: bl      #0x2b70db0                                 fn_2b70db0
02d57f2c: adrp    x0, #0x626b000                             
02d57f30: ldr     x0, [x0, #0xa90]                           M:Blindbag.StoreScreen::<OnInit>b__20_1
02d57f34: bl      #0x2b70db0                                 fn_2b70db0
02d57f38: adrp    x0, #0x626b000                             
02d57f3c: ldr     x0, [x0, #0xa98]                           M:Blindbag.StoreScreen::<OnInit>b__20_2
02d57f40: bl      #0x2b70db0                                 fn_2b70db0
02d57f44: adrp    x0, #0x6265000                             
02d57f48: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d57f4c: bl      #0x2b70db0                                 fn_2b70db0
02d57f50: mov     w8, #1                                     
02d57f54: strb    w8, [x21, #0x299]                          
02d57f58: mov     x0, x19                                    
02d57f5c: mov     x1, x20                                    
02d57f60: mov     x2, xzr                                    
02d57f64: bl      #0x2cdd3c4                                 UIBase::OnInit
02d57f68: ldr     x8, [x19, #0x48]                           ._confirmOrderButton
02d57f6c: cbz     x8, #0x2d5806c                             
02d57f70: adrp    x22, #0x6265000                            
02d57f74: adrp    x21, #0x626b000                            
02d57f78: ldr     x22, [x22, #0x3f0]                         T:UnityEngine.Events.UnityAction
02d57f7c: ldr     x21, [x21, #0xa88]                         M:Blindbag.StoreScreen::<OnInit>b__20_0
02d57f80: ldr     x20, [x8, #0x20]                           
02d57f84: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d57f88: bl      #0x2b7104c                                 fn_2b7104c
02d57f8c: ldr     x2, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d57f90: mov     x1, x19                                    
02d57f94: mov     x3, xzr                                    
02d57f98: mov     x21, x0                                    
02d57f9c: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d57fa0: cbz     x20, #0x2d5806c                            
02d57fa4: mov     x0, x20                                    
02d57fa8: mov     x1, x21                                    
02d57fac: mov     x2, xzr                                    
02d57fb0: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d57fb4: ldr     x8, [x19, #0x50]                           ._confirmBuyButton
02d57fb8: cbz     x8, #0x2d5806c                             
02d57fbc: adrp    x21, #0x626b000                            
02d57fc0: ldr     x21, [x21, #0xa90]                         M:Blindbag.StoreScreen::<OnInit>b__20_1
02d57fc4: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d57fc8: ldr     x20, [x8, #0x20]                           
02d57fcc: bl      #0x2b7104c                                 fn_2b7104c
02d57fd0: ldr     x2, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d57fd4: mov     x1, x19                                    
02d57fd8: mov     x3, xzr                                    
02d57fdc: mov     x21, x0                                    
02d57fe0: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d57fe4: cbz     x20, #0x2d5806c                            
02d57fe8: mov     x0, x20                                    
02d57fec: mov     x1, x21                                    
02d57ff0: mov     x2, xzr                                    
02d57ff4: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d57ff8: ldr     x8, [x19, #0x58]                           ._closeButton
02d57ffc: cbz     x8, #0x2d5806c                             
02d58000: adrp    x21, #0x626b000                            
02d58004: ldr     x21, [x21, #0xa98]                         M:Blindbag.StoreScreen::<OnInit>b__20_2
02d58008: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d5800c: ldr     x20, [x8, #0x100]                          
02d58010: bl      #0x2b7104c                                 fn_2b7104c
02d58014: ldr     x2, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d58018: mov     x1, x19                                    
02d5801c: mov     x3, xzr                                    
02d58020: mov     x21, x0                                    
02d58024: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d58028: cbz     x20, #0x2d5806c                            
02d5802c: mov     x0, x20                                    
02d58030: mov     x1, x21                                    
02d58034: mov     x2, xzr                                    
02d58038: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d5803c: ldr     x0, [x19, #0x68]                           ._blockScreen
02d58040: cbz     x0, #0x2d5806c                             
02d58044: mov     w1, wzr                                    
02d58048: mov     x2, xzr                                    
02d5804c: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d58050: adrp    x8, #0x1084000                             
02d58054: mov     x0, x19                                    
02d58058: ldp     x20, x19, [sp, #0x20]                      
02d5805c: ldr     s0, [x8, #0xeec]                           [1084eec]=457ff0003dcccccd f=0.1,4095
02d58060: ldp     x22, x21, [sp, #0x10]                      
02d58064: ldr     x30, [sp], #0x30                           
02d58068: b       #0x2d58070                                 Blindbag.StoreScreen::OnHideButtons
02d5806c: bl      #0x2b7105c                                 fn_2b7105c
## OnShow() -> void
---- Blindbag.StoreScreen::OnShow 0x2d58180
02d58180: str     x30, [sp, #-0x20]!                         
02d58184: stp     x20, x19, [sp, #0x10]                      
02d58188: adrp    x20, #0x6630000                            
02d5818c: mov     x19, x0                                    
02d58190: ldrb    w8, [x20, #0x29a]                          
02d58194: tbnz    w8, #0, #0x2d581b8                         
02d58198: adrp    x0, #0x6266000                             
02d5819c: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d581a0: bl      #0x2b70db0                                 fn_2b70db0
02d581a4: adrp    x0, #0x6266000                             
02d581a8: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d581ac: bl      #0x2b70db0                                 fn_2b70db0
02d581b0: mov     w8, #1                                     
02d581b4: strb    w8, [x20, #0x29a]                          
02d581b8: mov     x0, x19                                    
02d581bc: mov     x1, xzr                                    
02d581c0: bl      #0x2cdd6b8                                 UIBase::OnShow
02d581c4: ldr     x0, [x19, #0x48]                           ._confirmOrderButton
02d581c8: cbz     x0, #0x2d58250                             
02d581cc: adrp    x20, #0x6266000                            
02d581d0: mov     w1, wzr                                    
02d581d4: ldr     x20, [x20, #0x658]                         MS:MonoSingleton`1::get_Instance
02d581d8: bl      #0x2d57b24                                 Blindbag.MarketButton::EnableState
02d581dc: adrp    x8, #0x1084000                             
02d581e0: mov     x0, x19                                    
02d581e4: ldr     s0, [x8, #0xe60]                           [1084e60]=bc8efa353eb33333 f=0.35,-0.0174533
02d581e8: bl      #0x2d58254                                 Blindbag.StoreScreen::OnShowButtons
02d581ec: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d581f0: bl      #0x3769600                                 fn_3769600
02d581f4: cbz     x0, #0x2d58250                             
02d581f8: adrp    x8, #0x6266000                             
02d581fc: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02d58200: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d58204: bl      #0x3168dd0                                 fn_3168dd0
02d58208: cbz     x0, #0x2d58250                             
02d5820c: ldr     x8, [x0, #0x20]                            S:'inter_ad_capping_time'
02d58210: cbz     x8, #0x2d58250                             
02d58214: ldrb    w8, [x8, #0x45]                            
02d58218: cbz     w8, #0x2d58228                             
02d5821c: ldp     x20, x19, [sp, #0x10]                      
02d58220: ldr     x30, [sp], #0x20                           
02d58224: ret                                                
02d58228: ldr     x0, [x19, #0x58]                           ._closeButton
02d5822c: cbz     x0, #0x2d58250                             
02d58230: mov     x1, xzr                                    
02d58234: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d58238: cbz     x0, #0x2d58250                             
02d5823c: ldp     x20, x19, [sp, #0x10]                      
02d58240: mov     w1, wzr                                    
02d58244: mov     x2, xzr                                    
02d58248: ldr     x30, [sp], #0x20                           
02d5824c: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d58250: bl      #0x2b7105c                                 fn_2b7105c
## SetItemCounter(int value) -> void
---- Blindbag.StoreScreen::SetItemCounter 0x2d51bd0
02d51bd0: sub     sp, sp, #0x30                              
02d51bd4: stp     x30, x21, [sp, #0x10]                      
02d51bd8: stp     x20, x19, [sp, #0x20]                      
02d51bdc: adrp    x21, #0x6630000                            
02d51be0: adrp    x20, #0x626b000                            
02d51be4: mov     x19, x0                                    
02d51be8: ldrb    w8, [x21, #0x29b]                          
02d51bec: ldr     x20, [x20, #0x8c8]                         S:'/5'
02d51bf0: str     w1, [sp, #0xc]                             
02d51bf4: tbnz    w8, #0, #0x2d51c0c                         
02d51bf8: adrp    x0, #0x626b000                             
02d51bfc: ldr     x0, [x0, #0x8c8]                           S:'/5'
02d51c00: bl      #0x2b70db0                                 fn_2b70db0
02d51c04: mov     w8, #1                                     
02d51c08: strb    w8, [x21, #0x29b]                          
02d51c0c: ldr     x19, [x19, #0x38]                          ._itemCountText
02d51c10: add     x0, sp, #0xc                               
02d51c14: mov     x1, xzr                                    
02d51c18: bl      #0x4e0ea3c                                 System.Int32::ToString
02d51c1c: ldr     x1, [x20]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d51c20: mov     x2, xzr                                    
02d51c24: bl      #0x4c9c514                                 System.String::Concat
02d51c28: cbz     x19, #0x2d51c54                            
02d51c2c: ldr     x8, [x19]                                  
02d51c30: mov     x1, x0                                     
02d51c34: mov     x0, x19                                    
02d51c38: ldr     x9, [x8, #0x558]                           
02d51c3c: ldr     x2, [x8, #0x560]                           
02d51c40: blr     x9                                         
02d51c44: ldp     x20, x19, [sp, #0x20]                      
02d51c48: ldp     x30, x21, [sp, #0x10]                      
02d51c4c: add     sp, sp, #0x30                              
02d51c50: ret                                                
02d51c54: bl      #0x2b7105c                                 fn_2b7105c
## SetPrice(int price) -> void
---- Blindbag.StoreScreen::SetPrice 0x2d51c58
02d51c58: sub     sp, sp, #0x20                              
02d51c5c: stp     x30, x19, [sp, #0x10]                      
02d51c60: ldr     x19, [x0, #0x40]                           ._priceText
02d51c64: str     w1, [sp, #0xc]                             
02d51c68: add     x0, sp, #0xc                               
02d51c6c: mov     x1, xzr                                    
02d51c70: bl      #0x4e0ea3c                                 System.Int32::ToString
02d51c74: cbz     x19, #0x2d51c9c                            
02d51c78: ldr     x8, [x19]                                  
02d51c7c: mov     x1, x0                                     
02d51c80: mov     x0, x19                                    
02d51c84: ldr     x9, [x8, #0x558]                           
02d51c88: ldr     x2, [x8, #0x560]                           
02d51c8c: blr     x9                                         
02d51c90: ldp     x30, x19, [sp, #0x10]                      
02d51c94: add     sp, sp, #0x20                              
02d51c98: ret                                                
02d51c9c: bl      #0x2b7105c                                 fn_2b7105c
## EnableConfirmOrderButton(bool value) -> void
---- Blindbag.StoreScreen::EnableConfirmOrderButton 0x2d51bb8
02d51bb8: ldr     x0, [x0, #0x48]                            ._confirmOrderButton
02d51bbc: cbz     x0, #0x2d51bc8                             
02d51bc0: and     w1, w1, #1                                 
02d51bc4: b       #0x2d57b24                                 Blindbag.MarketButton::EnableState
02d51bc8: str     x30, [sp, #-0x10]!                         
02d51bcc: bl      #0x2b7105c                                 fn_2b7105c
## OnHideButtons(float duration) -> void
---- Blindbag.StoreScreen::OnHideButtons 0x2d58070
02d58070: stp     d9, d8, [sp, #-0x30]!                      
02d58074: stp     x30, x21, [sp, #0x10]                      
02d58078: stp     x20, x19, [sp, #0x20]                      
02d5807c: fmov    s8, s0                                     
02d58080: adrp    x21, #0x6630000                            
02d58084: adrp    x20, #0x6266000                            
02d58088: ldrb    w8, [x21, #0x29c]                          
02d5808c: ldr     x20, [x20, #0xa18]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d58090: mov     x19, x0                                    
02d58094: tbnz    w8, #0, #0x2d580ac                         
02d58098: adrp    x0, #0x6266000                             
02d5809c: ldr     x0, [x0, #0xa18]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d580a0: bl      #0x2b70db0                                 fn_2b70db0
02d580a4: mov     w8, #1                                     
02d580a8: strb    w8, [x21, #0x29c]                          
02d580ac: mov     w8, #-0x3c380000                           
02d580b0: fmov    s1, s8                                     
02d580b4: ldr     x0, [x19, #0x78]                           ._itemCounterRectTransform
02d580b8: fmov    s9, w8                                     
02d580bc: mov     w1, wzr                                    
02d580c0: mov     x2, xzr                                    
02d580c4: fmov    s0, s9                                     
02d580c8: bl      #0x2c79a70                                 DG.Tweening.DOTweenModuleUI::DOAnchorPosX
02d580cc: ldr     x2, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d580d0: mov     w1, #0x1a                                  
02d580d4: bl      #0x336fa0c                                 fn_336fa0c
02d580d8: fmov    s0, s9                                     
02d580dc: fmov    s1, s8                                     
02d580e0: ldr     x0, [x19, #0x80]                           ._totalPriceRectTransform
02d580e4: mov     w1, wzr                                    
02d580e8: mov     x2, xzr                                    
02d580ec: bl      #0x2c79a70                                 DG.Tweening.DOTweenModuleUI::DOAnchorPosX
02d580f0: ldr     x2, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d580f4: mov     w1, #0x1a                                  
02d580f8: bl      #0x336fa0c                                 fn_336fa0c
02d580fc: mov     w8, #0x43160000                            
02d58100: fmov    s1, s8                                     
02d58104: ldr     x0, [x19, #0x88]                           ._closeButtonTransform
02d58108: fmov    s0, w8                                     
02d5810c: mov     w1, wzr                                    
02d58110: mov     x2, xzr                                    
02d58114: bl      #0x2c79c1c                                 DG.Tweening.DOTweenModuleUI::DOAnchorPosY
02d58118: ldr     x2, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5811c: mov     w1, #0x1a                                  
02d58120: bl      #0x336fa0c                                 fn_336fa0c
02d58124: mov     w8, #0x42c80000                            
02d58128: fmov    s1, s8                                     
02d5812c: ldr     x0, [x19, #0x90]                           ._moneyRectTransform
02d58130: fmov    s0, w8                                     
02d58134: mov     w1, wzr                                    
02d58138: mov     x2, xzr                                    
02d5813c: bl      #0x2c79c1c                                 DG.Tweening.DOTweenModuleUI::DOAnchorPosY
02d58140: ldr     x2, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d58144: mov     w1, #0x1a                                  
02d58148: bl      #0x336fa0c                                 fn_336fa0c
02d5814c: mov     w8, #0x43480000                            
02d58150: fmov    s1, s8                                     
02d58154: ldr     x0, [x19, #0x98]                           ._confirmOrderRectTransform
02d58158: fmov    s0, w8                                     
02d5815c: mov     w1, wzr                                    
02d58160: mov     x2, xzr                                    
02d58164: bl      #0x2c79a70                                 DG.Tweening.DOTweenModuleUI::DOAnchorPosX
02d58168: ldr     x2, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5816c: ldp     x20, x19, [sp, #0x20]                      
02d58170: ldp     x30, x21, [sp, #0x10]                      
02d58174: mov     w1, #0x1a                                  
02d58178: ldp     d9, d8, [sp], #0x30                        
02d5817c: b       #0x336fa0c                                 
## OnShowButtons(float duration) -> void
---- Blindbag.StoreScreen::OnShowButtons 0x2d58254
02d58254: stp     d9, d8, [sp, #-0x30]!                      
02d58258: stp     x30, x21, [sp, #0x10]                      
02d5825c: stp     x20, x19, [sp, #0x20]                      
02d58260: fmov    s8, s0                                     
02d58264: adrp    x21, #0x6630000                            
02d58268: adrp    x20, #0x6266000                            
02d5826c: ldrb    w8, [x21, #0x29d]                          
02d58270: ldr     x20, [x20, #0xa18]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d58274: mov     x19, x0                                    
02d58278: tbnz    w8, #0, #0x2d58290                         
02d5827c: adrp    x0, #0x6266000                             
02d58280: ldr     x0, [x0, #0xa18]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d58284: bl      #0x2b70db0                                 fn_2b70db0
02d58288: mov     w8, #1                                     
02d5828c: strb    w8, [x21, #0x29d]                          
02d58290: mov     w8, #0x42200000                            
02d58294: fmov    s1, s8                                     
02d58298: ldr     x0, [x19, #0x78]                           ._itemCounterRectTransform
02d5829c: fmov    s9, w8                                     
02d582a0: mov     w1, wzr                                    
02d582a4: mov     x2, xzr                                    
02d582a8: fmov    s0, s9                                     
02d582ac: bl      #0x2c79a70                                 DG.Tweening.DOTweenModuleUI::DOAnchorPosX
02d582b0: ldr     x2, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d582b4: mov     w1, #0x1b                                  
02d582b8: bl      #0x336fa0c                                 fn_336fa0c
02d582bc: fmov    s0, s9                                     
02d582c0: fmov    s1, s8                                     
02d582c4: ldr     x0, [x19, #0x80]                           ._totalPriceRectTransform
02d582c8: mov     w1, wzr                                    
02d582cc: mov     x2, xzr                                    
02d582d0: bl      #0x2c79a70                                 DG.Tweening.DOTweenModuleUI::DOAnchorPosX
02d582d4: ldr     x2, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d582d8: mov     w1, #0x1b                                  
02d582dc: bl      #0x336fa0c                                 fn_336fa0c
02d582e0: mov     w8, #-0x3de00000                           
02d582e4: fmov    s1, s8                                     
02d582e8: ldr     x0, [x19, #0x88]                           ._closeButtonTransform
02d582ec: fmov    s0, w8                                     
02d582f0: mov     w1, wzr                                    
02d582f4: mov     x2, xzr                                    
02d582f8: bl      #0x2c79c1c                                 DG.Tweening.DOTweenModuleUI::DOAnchorPosY
02d582fc: ldr     x2, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d58300: mov     w1, #0x1b                                  
02d58304: bl      #0x336fa0c                                 fn_336fa0c
02d58308: mov     w8, #-0x3d380000                           
02d5830c: fmov    s1, s8                                     
02d58310: ldr     x0, [x19, #0x90]                           ._moneyRectTransform
02d58314: fmov    s0, w8                                     
02d58318: mov     w1, wzr                                    
02d5831c: mov     x2, xzr                                    
02d58320: bl      #0x2c79c1c                                 DG.Tweening.DOTweenModuleUI::DOAnchorPosY
02d58324: ldr     x2, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d58328: mov     w1, #0x1b                                  
02d5832c: bl      #0x336fa0c                                 fn_336fa0c
02d58330: mov     w8, #-0x3cf40000                           
02d58334: fmov    s1, s8                                     
02d58338: ldr     x0, [x19, #0x98]                           ._confirmOrderRectTransform
02d5833c: fmov    s0, w8                                     
02d58340: mov     w1, wzr                                    
02d58344: mov     x2, xzr                                    
02d58348: bl      #0x2c79a70                                 DG.Tweening.DOTweenModuleUI::DOAnchorPosX
02d5834c: ldr     x2, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d58350: ldp     x20, x19, [sp, #0x20]                      
02d58354: ldp     x30, x21, [sp, #0x10]                      
02d58358: mov     w1, #0x1b                                  
02d5835c: ldp     d9, d8, [sp], #0x30                        
02d58360: b       #0x336fa0c                                 
## ShowLockScreen(bool isShow) -> void
---- Blindbag.StoreScreen::ShowLockScreen 0x2d51ddc
02d51ddc: ldr     x0, [x0, #0x68]                            ._blockScreen
02d51de0: cbz     x0, #0x2d51df0                             
02d51de4: and     w1, w1, #1                                 
02d51de8: mov     x2, xzr                                    
02d51dec: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d51df0: str     x30, [sp, #-0x10]!                         
02d51df4: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Blindbag.StoreScreen::.ctor 0x2d58364
02d58364: mov     x1, xzr                                    
02d58368: b       #0x2cde678                                 ScreenBase::.ctor
## <OnInit>b__20_0() -> void
---- Blindbag.StoreScreen::<OnInit>b__20_0 0x2d5836c
02d5836c: str     d8, [sp, #-0x40]!                          
02d58370: str     x30, [sp, #8]                              
02d58374: stp     x24, x23, [sp, #0x10]                      
02d58378: stp     x22, x21, [sp, #0x20]                      
02d5837c: stp     x20, x19, [sp, #0x30]                      
02d58380: adrp    x20, #0x6630000                            
02d58384: mov     x19, x0                                    
02d58388: ldrb    w8, [x20, #0x29e]                          
02d5838c: tbnz    w8, #0, #0x2d583c8                         
02d58390: adrp    x0, #0x6266000                             
02d58394: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d58398: bl      #0x2b70db0                                 fn_2b70db0
02d5839c: adrp    x0, #0x6265000                             
02d583a0: ldr     x0, [x0, #0xb38]                           T:DevTrack
02d583a4: bl      #0x2b70db0                                 fn_2b70db0
02d583a8: adrp    x0, #0x6266000                             
02d583ac: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d583b0: bl      #0x2b70db0                                 fn_2b70db0
02d583b4: adrp    x0, #0x6266000                             
02d583b8: ldr     x0, [x0, #0xb48]                           MS:MonoSingleton`1::get_Instance
02d583bc: bl      #0x2b70db0                                 fn_2b70db0
02d583c0: mov     w8, #1                                     
02d583c4: strb    w8, [x20, #0x29e]                          
02d583c8: mov     x0, xzr                                    
02d583cc: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d583d0: cbz     x0, #0x2d5854c                             
02d583d4: movi    d1, #0000000000000000                      
02d583d8: movi    d2, #0000000000000000                      
02d583dc: mov     w1, #1                                     
02d583e0: fmov    s0, #1.00000000                            
02d583e4: mov     w2, wzr                                    
02d583e8: mov     w3, wzr                                    
02d583ec: mov     x4, xzr                                    
02d583f0: bl      #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d583f4: ldr     x0, [x19, #0x60]                           ._bottomPanel
02d583f8: cbz     x0, #0x2d5854c                             
02d583fc: adrp    x20, #0x6266000                            
02d58400: mov     w1, wzr                                    
02d58404: mov     x2, xzr                                    
02d58408: ldr     x20, [x20, #0x658]                         MS:MonoSingleton`1::get_Instance
02d5840c: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d58410: ldr     x8, [x19, #0xb0]                           .OnOrderButtonClicked
02d58414: cbz     x8, #0x2d58428                             
02d58418: ldr     x9, [x8, #0x18]                            
02d5841c: ldr     x0, [x8, #0x40]                            
02d58420: ldr     x1, [x8, #0x28]                            
02d58424: blr     x9                                         
02d58428: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5842c: bl      #0x3769600                                 fn_3769600
02d58430: cbz     x0, #0x2d5854c                             
02d58434: adrp    x8, #0x6266000                             
02d58438: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02d5843c: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d58440: bl      #0x3168dd0                                 fn_3168dd0
02d58444: cbz     x0, #0x2d5854c                             
02d58448: ldr     x8, [x0, #0x20]                            S:'inter_ad_capping_time'
02d5844c: cbz     x8, #0x2d5854c                             
02d58450: adrp    x23, #0x6266000                            
02d58454: ldr     x23, [x23, #0xb48]                         MS:MonoSingleton`1::get_Instance
02d58458: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5845c: bl      #0x3769600                                 fn_3769600
02d58460: cbz     x0, #0x2d5854c                             
02d58464: ldr     x19, [x0, #0x30]                           S:'popup_rate_on_off'
02d58468: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5846c: bl      #0x3769600                                 fn_3769600
02d58470: cbz     x0, #0x2d5854c                             
02d58474: adrp    x24, #0x6265000                            
02d58478: mov     x8, x0                                     
02d5847c: ldr     x24, [x24, #0xb38]                         T:DevTrack
02d58480: ldr     w20, [x8, #0x3c]                           [626603c]=0 f=0,0
02d58484: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d58488: ldr     w9, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d5848c: cbnz    w9, #0x2d58498                             
02d58490: bl      #0x2b70f30                                 fn_2b70f30
02d58494: ldr     x0, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d58498: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time' .OnBuyButtonClicked
02d5849c: mov     x0, xzr                                    
02d584a0: ldr     x21, [x8, #0x2a8]                          T:UnityEngine.Purchasing.ICart
02d584a4: ldr     w22, [x8, #0x2d4]                          [62662d4]=0 f=0,0
02d584a8: bl      #0x5b432fc                                 UnityEngine.Time::get_time
02d584ac: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d584b0: fmov    s8, s0                                     
02d584b4: bl      #0x3769600                                 fn_3769600
02d584b8: cbz     x0, #0x2d5854c                             
02d584bc: ldr     s0, [x0, #0x38]                            S:'native_collap_id' ._itemCountText
02d584c0: mov     x0, x19                                    
02d584c4: mov     w1, w20                                    
02d584c8: mov     x2, x21                                    
02d584cc: mov     w3, w22                                    
02d584d0: mov     x4, xzr                                    
02d584d4: fsub    s0, s8, s0                                 
02d584d8: bl      #0x2c9c898                                 DevTrack::GameModeStepComplete
02d584dc: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d584e0: bl      #0x3769600                                 fn_3769600
02d584e4: cbz     x0, #0x2d5854c                             
02d584e8: ldr     x19, [x0, #0x30]                           S:'popup_rate_on_off'
02d584ec: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d584f0: bl      #0x3769600                                 fn_3769600
02d584f4: cbz     x0, #0x2d5854c                             
02d584f8: ldr     x8, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d584fc: ldr     w1, [x0, #0x3c]                            [626603c]=0 f=0,0
02d58500: mov     x0, x19                                    
02d58504: mov     x4, xzr                                    
02d58508: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02d5850c: ldr     x2, [x8, #0x2b0]                           T:type11754(k15)
02d58510: ldr     w3, [x8, #0x2d8]                           MS:System.Nullable`1::GetValueOrDefault
02d58514: bl      #0x2c9c714                                 DevTrack::GameModeStepEnter
02d58518: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d5851c: bl      #0x3769600                                 fn_3769600
02d58520: cbz     x0, #0x2d5854c                             
02d58524: ldr     x8, [x24]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d58528: ldp     x20, x19, [sp, #0x30]                      
02d5852c: ldp     x22, x21, [sp, #0x20]                      
02d58530: ldr     x30, [sp, #8]                              
02d58534: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02d58538: ldp     x24, x23, [sp, #0x10]                      
02d5853c: ldr     x1, [x8, #0x2b0]                           T:type11754(k15)
02d58540: str     x1, [x0, #0x40]!                           ._priceText
02d58544: ldr     d8, [sp], #0x40                            
02d58548: b       #0x2b70d54                                 
02d5854c: bl      #0x2b7105c                                 fn_2b7105c
## <OnInit>b__20_1() -> void
---- Blindbag.StoreScreen::<OnInit>b__20_1 0x2d58550
02d58550: stp     x30, x19, [sp, #-0x10]!                    
02d58554: movi    d1, #0000000000000000                      
02d58558: movi    d2, #0000000000000000                      
02d5855c: mov     x19, x0                                    
02d58560: fmov    s0, #1.00000000                            
02d58564: mov     w0, #0x2f                                  
02d58568: mov     w1, wzr                                    
02d5856c: mov     w2, wzr                                    
02d58570: mov     x3, xzr                                    
02d58574: bl      #0x2d84264                                 Framework.AudioHelper::PlaySound
02d58578: ldr     x0, [x19, #0x50]                           ._confirmBuyButton
02d5857c: cbz     x0, #0x2d585bc                             
02d58580: mov     x1, xzr                                    
02d58584: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d58588: cbz     x0, #0x2d585bc                             
02d5858c: mov     w1, wzr                                    
02d58590: mov     x2, xzr                                    
02d58594: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d58598: ldr     x8, [x19, #0xb8]                           .OnBuyButtonClicked
02d5859c: cbz     x8, #0x2d585b4                             
02d585a0: ldr     x0, [x8, #0x40]                            
02d585a4: ldr     x1, [x8, #0x28]                            
02d585a8: ldr     x2, [x8, #0x18]                            
02d585ac: ldp     x30, x19, [sp], #0x10                      
02d585b0: br      x2                                         
02d585b4: ldp     x30, x19, [sp], #0x10                      
02d585b8: ret                                                
02d585bc: bl      #0x2b7105c                                 fn_2b7105c
## <OnInit>b__20_2() -> void
---- Blindbag.StoreScreen::<OnInit>b__20_2 0x2d585c0
02d585c0: stp     x30, x23, [sp, #-0x30]!                    
02d585c4: stp     x22, x21, [sp, #0x10]                      
02d585c8: stp     x20, x19, [sp, #0x20]                      
02d585cc: adrp    x23, #0x6630000                            
02d585d0: adrp    x22, #0x6265000                            
02d585d4: adrp    x20, #0x6264000                            
02d585d8: adrp    x21, #0x626b000                            
02d585dc: ldr     x22, [x22, #0x310]                         MS:WejoyService.Singleton`1::get_Instance
02d585e0: ldrb    w8, [x23, #0x29f]                          
02d585e4: ldr     x20, [x20, #0xf90]                         T:System.Action
02d585e8: ldr     x21, [x21, #0xaa0]                         M:Blindbag.StoreScreen::<OnInit>b__20_3
02d585ec: mov     x19, x0                                    
02d585f0: tbnz    w8, #0, #0x2d5862c                         
02d585f4: adrp    x0, #0x6264000                             
02d585f8: ldr     x0, [x0, #0xf90]                           T:System.Action
02d585fc: bl      #0x2b70db0                                 fn_2b70db0
02d58600: adrp    x0, #0x6265000                             
02d58604: ldr     x0, [x0, #0x310]                           MS:WejoyService.Singleton`1::get_Instance
02d58608: bl      #0x2b70db0                                 fn_2b70db0
02d5860c: adrp    x0, #0x626b000                             
02d58610: ldr     x0, [x0, #0xaa0]                           M:Blindbag.StoreScreen::<OnInit>b__20_3
02d58614: bl      #0x2b70db0                                 fn_2b70db0
02d58618: adrp    x0, #0x6269000                             
02d5861c: ldr     x0, [x0, #0xd88]                           S:'blind_bag_back_click'
02d58620: bl      #0x2b70db0                                 fn_2b70db0
02d58624: mov     w8, #1                                     
02d58628: strb    w8, [x23, #0x29f]                          
02d5862c: movi    d1, #0000000000000000                      
02d58630: movi    d2, #0000000000000000                      
02d58634: mov     w0, #1                                     
02d58638: fmov    s0, #1.00000000                            
02d5863c: mov     w1, wzr                                    
02d58640: mov     w2, wzr                                    
02d58644: mov     x3, xzr                                    
02d58648: bl      #0x2d84264                                 Framework.AudioHelper::PlaySound
02d5864c: ldr     x0, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d58650: bl      #0x3be7218                                 fn_3be7218
02d58654: ldr     x8, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d58658: mov     x20, x0                                    
02d5865c: mov     x0, x8                                     
02d58660: bl      #0x2b7104c                                 fn_2b7104c
02d58664: ldr     x2, [x21]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d58668: mov     x1, x19                                    
02d5866c: mov     x3, xzr                                    
02d58670: mov     x21, x0                                    
02d58674: bl      #0x4d8ddbc                                 System.Action::.ctor
02d58678: cbz     x20, #0x2d586a8                            
02d5867c: adrp    x8, #0x6269000                             
02d58680: mov     x0, x20                                    
02d58684: mov     x2, x21                                    
02d58688: ldr     x8, [x8, #0xd88]                           S:'blind_bag_back_click'
02d5868c: ldp     x20, x19, [sp, #0x20]                      
02d58690: ldp     x22, x21, [sp, #0x10]                      
02d58694: mov     w3, #1                                     
02d58698: ldr     x1, [x8]                                   T:Trading.TradingSession/<>c__DisplayClass56_0
02d5869c: mov     x4, xzr                                    
02d586a0: ldp     x30, x23, [sp], #0x30                      
02d586a4: b       #0x2c89698                                 AdsManager::ShowInter
02d586a8: bl      #0x2b7105c                                 fn_2b7105c
## <OnInit>b__20_3() -> void
---- Blindbag.StoreScreen::<OnInit>b__20_3 0x2d586ac
02d586ac: str     x30, [sp, #-0x20]!                         
02d586b0: stp     x20, x19, [sp, #0x10]                      
02d586b4: adrp    x20, #0x6630000                            
02d586b8: mov     x19, x0                                    
02d586bc: ldrb    w8, [x20, #0x2a0]                          
02d586c0: tbnz    w8, #0, #0x2d586d8                         
02d586c4: adrp    x0, #0x626a000                             
02d586c8: ldr     x0, [x0, #0xc08]                           MS:UIManager::ShowPopup
02d586cc: bl      #0x2b70db0                                 fn_2b70db0
02d586d0: mov     w8, #1                                     
02d586d4: strb    w8, [x20, #0x2a0]                          
02d586d8: ldr     x0, [x19, #0x30]                           
02d586dc: cbz     x0, #0x2d586f8                             
02d586e0: adrp    x8, #0x626a000                             
02d586e4: ldr     x8, [x8, #0xc08]                           MS:UIManager::ShowPopup
02d586e8: ldp     x20, x19, [sp, #0x10]                      
02d586ec: ldr     x1, [x8]                                   T:type56879(k15)
02d586f0: ldr     x30, [sp], #0x20                           
02d586f4: b       #0x33fbfac                                 
02d586f8: bl      #0x2b7105c                                 fn_2b7105c
