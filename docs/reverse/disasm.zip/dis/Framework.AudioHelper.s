#### CLASS Framework.AudioHelper parent= object
## PlayRandomSound(Framework.ESound[] sounds) -> void
---- Framework.AudioHelper::PlayRandomSound 0x2d840d4
02d840d4: str     x30, [sp, #-0x20]!                         
02d840d8: stp     x20, x19, [sp, #0x10]                      
02d840dc: mov     x20, x0                                    
02d840e0: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d840e4: cbz     x20, #0x2d84138                            
02d840e8: ldr     w1, [x20, #0x18]                           
02d840ec: mov     x19, x0                                    
02d840f0: mov     w0, wzr                                    
02d840f4: mov     x2, xzr                                    
02d840f8: bl      #0x5b2e000                                 UnityEngine.Random::Range
02d840fc: ldr     w8, [x20, #0x18]                           
02d84100: cmp     w0, w8                                     
02d84104: b.hs    #0x2d8413c                                 
02d84108: cbz     x19, #0x2d84138                            
02d8410c: add     x8, x20, w0, sxtw #2                       
02d84110: mov     x0, x19                                    
02d84114: movi    d1, #0000000000000000                      
02d84118: ldp     x20, x19, [sp, #0x10]                      
02d8411c: movi    d2, #0000000000000000                      
02d84120: ldr     w1, [x8, #0x20]                            
02d84124: fmov    s0, #1.00000000                            
02d84128: mov     w2, wzr                                    
02d8412c: mov     w3, wzr                                    
02d84130: ldr     x30, [sp], #0x20                           
02d84134: b       #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d84138: bl      #0x2b7105c                                 fn_2b7105c
02d8413c: bl      #0x2b71064                                 fn_2b71064
## PlaySoundIfNotPlaying(Framework.ESound soundKey) -> void
---- Framework.AudioHelper::PlaySoundIfNotPlaying 0x2d84140
02d84140: stp     x30, x19, [sp, #-0x10]!                    
02d84144: mov     w19, w0                                    
02d84148: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d8414c: cbz     x0, #0x2d8418c                             
02d84150: mov     w1, w19                                    
02d84154: bl      #0x2d84190                                 Framework.AudioManager::IsSoundPlaying
02d84158: tbz     w0, #0, #0x2d84164                         
02d8415c: ldp     x30, x19, [sp], #0x10                      
02d84160: ret                                                
02d84164: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d84168: cbz     x0, #0x2d8418c                             
02d8416c: movi    d1, #0000000000000000                      
02d84170: movi    d2, #0000000000000000                      
02d84174: mov     w1, w19                                    
02d84178: fmov    s0, #1.00000000                            
02d8417c: mov     w2, wzr                                    
02d84180: mov     w3, wzr                                    
02d84184: ldp     x30, x19, [sp], #0x10                      
02d84188: b       #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d8418c: bl      #0x2b7105c                                 fn_2b7105c
## PlayClickSound() -> void
---- Framework.AudioHelper::PlayClickSound 0x2d6ff04
02d6ff04: str     x30, [sp, #-0x20]!                         
02d6ff08: stp     x20, x19, [sp, #0x10]                      
02d6ff0c: adrp    x19, #0x6630000                            
02d6ff10: adrp    x20, #0x6266000                            
02d6ff14: ldrb    w8, [x19, #0x46a]                          
02d6ff18: ldr     x20, [x20, #0x658]                         MS:MonoSingleton`1::get_Instance
02d6ff1c: tbnz    w8, #0, #0x2d6ff40                         
02d6ff20: adrp    x0, #0x6266000                             
02d6ff24: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d6ff28: bl      #0x2b70db0                                 fn_2b70db0
02d6ff2c: adrp    x0, #0x6266000                             
02d6ff30: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d6ff34: bl      #0x2b70db0                                 fn_2b70db0
02d6ff38: mov     w8, #1                                     
02d6ff3c: strb    w8, [x19, #0x46a]                          
02d6ff40: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6ff44: bl      #0x3769600                                 fn_3769600
02d6ff48: cbz     x0, #0x2d6ffa4                             
02d6ff4c: adrp    x8, #0x6266000                             
02d6ff50: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02d6ff54: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d6ff58: bl      #0x3168dd0                                 fn_3168dd0
02d6ff5c: cbz     x0, #0x2d6ffa4                             
02d6ff60: mov     x1, xzr                                    
02d6ff64: bl      #0x2cab9b8                                 DataUser::HasSound
02d6ff68: tbz     w0, #0, #0x2d6ff98                         
02d6ff6c: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d6ff70: cbz     x0, #0x2d6ffa4                             
02d6ff74: ldp     x20, x19, [sp, #0x10]                      
02d6ff78: movi    d1, #0000000000000000                      
02d6ff7c: movi    d2, #0000000000000000                      
02d6ff80: fmov    s0, #1.00000000                            
02d6ff84: mov     w1, #1                                     
02d6ff88: mov     w2, wzr                                    
02d6ff8c: mov     w3, wzr                                    
02d6ff90: ldr     x30, [sp], #0x20                           
02d6ff94: b       #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d6ff98: ldp     x20, x19, [sp, #0x10]                      
02d6ff9c: ldr     x30, [sp], #0x20                           
02d6ffa0: ret                                                
02d6ffa4: bl      #0x2b7105c                                 fn_2b7105c
## PlaySound(Framework.ESound soundKey, float volume, float delay, bool isLoop, bool isSetTimeStop, float timeStop) -> void
---- Framework.AudioHelper::PlaySound 0x2d84264
02d84264: str     d10, [sp, #-0x50]!                         
02d84268: stp     d9, d8, [sp, #0x10]                        
02d8426c: stp     x30, x23, [sp, #0x20]                      
02d84270: stp     x22, x21, [sp, #0x30]                      
02d84274: stp     x20, x19, [sp, #0x40]                      
02d84278: fmov    s8, s2                                     
02d8427c: fmov    s9, s1                                     
02d84280: adrp    x22, #0x6630000                            
02d84284: fmov    s10, s0                                    
02d84288: adrp    x23, #0x6266000                            
02d8428c: ldrb    w8, [x22, #0x46b]                          
02d84290: ldr     x23, [x23, #0x658]                         MS:MonoSingleton`1::get_Instance
02d84294: mov     w19, w2                                    
02d84298: mov     w20, w1                                    
02d8429c: mov     w21, w0                                    
02d842a0: tbnz    w8, #0, #0x2d842c4                         
02d842a4: adrp    x0, #0x6266000                             
02d842a8: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d842ac: bl      #0x2b70db0                                 fn_2b70db0
02d842b0: adrp    x0, #0x6266000                             
02d842b4: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d842b8: bl      #0x2b70db0                                 fn_2b70db0
02d842bc: mov     w8, #1                                     
02d842c0: strb    w8, [x22, #0x46b]                          
02d842c4: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d842c8: bl      #0x3769600                                 fn_3769600
02d842cc: cbz     x0, #0x2d84340                             
02d842d0: adrp    x8, #0x6266000                             
02d842d4: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02d842d8: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d842dc: bl      #0x3168dd0                                 fn_3168dd0
02d842e0: cbz     x0, #0x2d84340                             
02d842e4: mov     x1, xzr                                    
02d842e8: bl      #0x2cab9b8                                 DataUser::HasSound
02d842ec: tbz     w0, #0, #0x2d84328                         
02d842f0: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d842f4: cbz     x0, #0x2d84340                             
02d842f8: and     w2, w20, #1                                
02d842fc: and     w3, w19, #1                                
02d84300: mov     w1, w21                                    
02d84304: fmov    s1, s9                                     
02d84308: fmov    s2, s8                                     
02d8430c: fmov    s0, s10                                    
02d84310: ldp     x20, x19, [sp, #0x40]                      
02d84314: ldp     x22, x21, [sp, #0x30]                      
02d84318: ldp     x30, x23, [sp, #0x20]                      
02d8431c: ldp     d9, d8, [sp, #0x10]                        
02d84320: ldr     d10, [sp], #0x50                           
02d84324: b       #0x2d6f03c                                 Framework.AudioManager::PlaySound
02d84328: ldp     x20, x19, [sp, #0x40]                      
02d8432c: ldp     x22, x21, [sp, #0x30]                      
02d84330: ldp     x30, x23, [sp, #0x20]                      
02d84334: ldp     d9, d8, [sp, #0x10]                        
02d84338: ldr     d10, [sp], #0x50                           
02d8433c: ret                                                
02d84340: bl      #0x2b7105c                                 fn_2b7105c
## StopSound(Framework.ESound soundKey) -> void
---- Framework.AudioHelper::StopSound 0x2d84344
02d84344: stp     x30, x19, [sp, #-0x10]!                    
02d84348: mov     w19, w0                                    
02d8434c: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d84350: cbz     x0, #0x2d84360                             
02d84354: mov     w1, w19                                    
02d84358: ldp     x30, x19, [sp], #0x10                      
02d8435c: b       #0x2d84364                                 Framework.AudioManager::StopSound
02d84360: bl      #0x2b7105c                                 fn_2b7105c
## StopMusic(Framework.EMusic soundKey) -> void
---- Framework.AudioHelper::StopMusic 0x2d84534
02d84534: stp     x30, x19, [sp, #-0x10]!                    
02d84538: mov     w19, w0                                    
02d8453c: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d84540: cbz     x0, #0x2d84550                             
02d84544: mov     w1, w19                                    
02d84548: ldp     x30, x19, [sp], #0x10                      
02d8454c: b       #0x2d84554                                 Framework.AudioManager::StopMusic
02d84550: bl      #0x2b7105c                                 fn_2b7105c
## PlayMusic(Framework.EMusic key) -> void
---- Framework.AudioHelper::PlayMusic 0x2d84640
02d84640: stp     x30, x21, [sp, #-0x20]!                    
02d84644: stp     x20, x19, [sp, #0x10]                      
02d84648: adrp    x20, #0x6630000                            
02d8464c: adrp    x21, #0x6266000                            
02d84650: mov     w19, w0                                    
02d84654: ldrb    w8, [x20, #0x46c]                          
02d84658: ldr     x21, [x21, #0x658]                         MS:MonoSingleton`1::get_Instance
02d8465c: tbnz    w8, #0, #0x2d84680                         
02d84660: adrp    x0, #0x6266000                             
02d84664: ldr     x0, [x0, #0x750]                           MS:DataManager::GetData
02d84668: bl      #0x2b70db0                                 fn_2b70db0
02d8466c: adrp    x0, #0x6266000                             
02d84670: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d84674: bl      #0x2b70db0                                 fn_2b70db0
02d84678: mov     w8, #1                                     
02d8467c: strb    w8, [x20, #0x46c]                          
02d84680: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d84684: bl      #0x3769600                                 fn_3769600
02d84688: cbz     x0, #0x2d846d4                             
02d8468c: adrp    x8, #0x6266000                             
02d84690: ldr     x8, [x8, #0x750]                           MS:DataManager::GetData
02d84694: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d84698: bl      #0x3168dd0                                 fn_3168dd0
02d8469c: cbz     x0, #0x2d846d4                             
02d846a0: mov     x1, xzr                                    
02d846a4: bl      #0x2cab978                                 DataUser::HasMusic
02d846a8: tbz     w0, #0, #0x2d846c8                         
02d846ac: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02d846b0: cbz     x0, #0x2d846d4                             
02d846b4: mov     w1, w19                                    
02d846b8: ldp     x20, x19, [sp, #0x10]                      
02d846bc: fmov    s0, #1.00000000                            
02d846c0: ldp     x30, x21, [sp], #0x20                      
02d846c4: b       #0x2d846d8                                 Framework.AudioManager::PlayMusic
02d846c8: ldp     x20, x19, [sp, #0x10]                      
02d846cc: ldp     x30, x21, [sp], #0x20                      
02d846d0: ret                                                
02d846d4: bl      #0x2b7105c                                 fn_2b7105c
