#### CLASS Framework.DateTimeExtension parent= object
## ChangeTime(System.DateTime dateTime, int hours, int minutes, int seconds, int milliseconds) -> System.DateTime
---- Framework.DateTimeExtension::ChangeTime 0x2cb88d8
02cb88d8: sub     sp, sp, #0x60                              
02cb88dc: stp     x30, x25, [sp, #0x20]                      
02cb88e0: stp     x24, x23, [sp, #0x30]                      
02cb88e4: stp     x22, x21, [sp, #0x40]                      
02cb88e8: stp     x20, x19, [sp, #0x50]                      
02cb88ec: adrp    x23, #0x662f000                            
02cb88f0: adrp    x24, #0x6266000                            
02cb88f4: mov     w19, w4                                    
02cb88f8: ldrb    w8, [x23, #0xbe3]                          
02cb88fc: ldr     x24, [x24, #0x128]                         T:System.DateTime
02cb8900: mov     w20, w3                                    
02cb8904: mov     w21, w2                                    
02cb8908: mov     w22, w1                                    
02cb890c: str     x0, [sp, #0x10]                            
02cb8910: tbnz    w8, #0, #0x2cb8928                         
02cb8914: adrp    x0, #0x6266000                             
02cb8918: ldr     x0, [x0, #0x128]                           T:System.DateTime
02cb891c: bl      #0x2b70db0                                 fn_2b70db0
02cb8920: mov     w8, #1                                     
02cb8924: strb    w8, [x23, #0xbe3]                          
02cb8928: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cb892c: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02cb8930: cbnz    w8, #0x2cb8938                             
02cb8934: bl      #0x2b70f30                                 fn_2b70f30
02cb8938: add     x0, sp, #0x10                              
02cb893c: mov     x1, xzr                                    
02cb8940: bl      #0x4df28bc                                 System.DateTime::get_Year
02cb8944: mov     w23, w0                                    
02cb8948: add     x0, sp, #0x10                              
02cb894c: mov     x1, xzr                                    
02cb8950: bl      #0x4df2570                                 System.DateTime::get_Month
02cb8954: mov     w24, w0                                    
02cb8958: add     x0, sp, #0x10                              
02cb895c: mov     x1, xzr                                    
02cb8960: bl      #0x4df21c4                                 System.DateTime::get_Day
02cb8964: mov     w25, w0                                    
02cb8968: add     x0, sp, #0x10                              
02cb896c: mov     x1, xzr                                    
02cb8970: bl      #0x4df23ec                                 System.DateTime::get_Kind
02cb8974: mov     w8, w0                                     
02cb8978: add     x0, sp, #0x18                              
02cb897c: mov     w1, w23                                    
02cb8980: mov     w2, w24                                    
02cb8984: mov     w3, w25                                    
02cb8988: mov     w4, w22                                    
02cb898c: mov     w5, w21                                    
02cb8990: mov     w6, w20                                    
02cb8994: mov     w7, w19                                    
02cb8998: str     xzr, [sp, #0x18]                           
02cb899c: str     xzr, [sp, #8]                              
02cb89a0: str     w8, [sp]                                   
02cb89a4: bl      #0x4df0580                                 System.DateTime::.ctor
02cb89a8: ldp     x20, x19, [sp, #0x50]                      
02cb89ac: ldr     x0, [sp, #0x18]                            
02cb89b0: ldp     x22, x21, [sp, #0x40]                      
02cb89b4: ldp     x24, x23, [sp, #0x30]                      
02cb89b8: ldp     x30, x25, [sp, #0x20]                      
02cb89bc: add     sp, sp, #0x60                              
02cb89c0: ret                                                
