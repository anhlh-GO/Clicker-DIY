#### CLASS Livestream.LivestreamPanel/<>c__DisplayClass10_0 parent= object
#   field previousView                   int                                                off=0x10 attr=6 
#   field <>4__this                      Livestream.LivestreamPanel                         off=0x18 attr=6 
## .ctor() -> void
---- Livestream.LivestreamPanel/<>c__DisplayClass10_0::.ctor 0x2d11f40
02d11f40: mov     x1, xzr                                    
02d11f44: b       #0x4e53e9c                                 System.Object::.ctor
## <OnUpdateView>b__0() -> int
---- Livestream.LivestreamPanel/<>c__DisplayClass10_0::<OnUpdateView>b__0 0x2d11f80
02d11f80: ldr     w0, [x0, #0x10]                            .previousView
02d11f84: ret                                                
## <OnUpdateView>b__1(int x) -> void
---- Livestream.LivestreamPanel/<>c__DisplayClass10_0::<OnUpdateView>b__1 0x2d11f88
02d11f88: sub     sp, sp, #0x20                              
02d11f8c: stp     x30, x19, [sp, #0x10]                      
02d11f90: ldr     x8, [x0, #0x18]                            .<>4__this
02d11f94: str     w1, [sp, #0xc]                             
02d11f98: cbz     x8, #0x2d11fd4                             
02d11f9c: ldr     x19, [x8, #0x20]                           
02d11fa0: add     x0, sp, #0xc                               
02d11fa4: mov     x1, xzr                                    
02d11fa8: bl      #0x4e0ea3c                                 System.Int32::ToString
02d11fac: cbz     x19, #0x2d11fd4                            
02d11fb0: ldr     x8, [x19]                                  
02d11fb4: mov     x1, x0                                     
02d11fb8: mov     x0, x19                                    
02d11fbc: ldr     x9, [x8, #0x558]                           
02d11fc0: ldr     x2, [x8, #0x560]                           
02d11fc4: blr     x9                                         
02d11fc8: ldp     x30, x19, [sp, #0x10]                      
02d11fcc: add     sp, sp, #0x20                              
02d11fd0: ret                                                
02d11fd4: bl      #0x2b7105c                                 fn_2b7105c
## <OnUpdateView>b__2() -> void
---- Livestream.LivestreamPanel/<>c__DisplayClass10_0::<OnUpdateView>b__2 0x2d11fd8
02d11fd8: stp     x30, x19, [sp, #-0x10]!                    
02d11fdc: mov     x19, x0                                    
02d11fe0: ldr     x0, [x0, #0x18]                            .<>4__this
02d11fe4: cbz     x0, #0x2d1202c                             
02d11fe8: mov     x1, xzr                                    
02d11fec: str     xzr, [x0, #0x30]!                          
02d11ff0: bl      #0x2b70d54                                 fn_2b70d54
02d11ff4: ldr     x8, [x19, #0x18]                           .<>4__this
02d11ff8: cbz     x8, #0x2d1202c                             
02d11ffc: ldr     x19, [x8, #0x20]                           
02d12000: add     x0, x8, #0x28                              
02d12004: mov     x1, xzr                                    
02d12008: bl      #0x4e0ea3c                                 System.Int32::ToString
02d1200c: cbz     x19, #0x2d1202c                            
02d12010: ldr     x8, [x19]                                  
02d12014: mov     x1, x0                                     
02d12018: mov     x0, x19                                    
02d1201c: ldr     x2, [x8, #0x560]                           
02d12020: ldr     x3, [x8, #0x558]                           
02d12024: ldp     x30, x19, [sp], #0x10                      
02d12028: br      x3                                         
02d1202c: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS Livestream.LivestreamPanel/<UpdateView>d__9 parent= object
#   field <>1__state                     int                                                off=0x10 attr=1 
#   field <>2__current                   object                                             off=0x18 attr=1 
#   field <>4__this                      Livestream.LivestreamPanel                         off=0x20 attr=6 
## .ctor(int <>1__state) -> void
---- Livestream.LivestreamPanel/<UpdateView>d__9::.ctor 0x2d11d08
02d11d08: str     x30, [sp, #-0x20]!                         
02d11d0c: stp     x20, x19, [sp, #0x10]                      
02d11d10: mov     w19, w1                                    
02d11d14: mov     x1, xzr                                    
02d11d18: mov     x20, x0                                    
02d11d1c: bl      #0x4e53e9c                                 System.Object::.ctor
02d11d20: str     w19, [x20, #0x10]                          .<>1__state
02d11d24: ldp     x20, x19, [sp, #0x10]                      
02d11d28: ldr     x30, [sp], #0x20                           
02d11d2c: ret                                                
## System.IDisposable.Dispose() -> void
---- Livestream.LivestreamPanel/<UpdateView>d__9::System.IDisposable.Dispose 0x2d12030
02d12030: ret                                                
## MoveNext() -> bool
---- Livestream.LivestreamPanel/<UpdateView>d__9::MoveNext 0x2d12034
02d12034: str     d8, [sp, #-0x20]!                          
02d12038: str     x30, [sp, #8]                              
02d1203c: stp     x20, x19, [sp, #0x10]                      
02d12040: adrp    x20, #0x662f000                            
02d12044: mov     x19, x0                                    
02d12048: ldrb    w8, [x20, #0xfbc]                          
02d1204c: tbnz    w8, #0, #0x2d12064                         
02d12050: adrp    x0, #0x6264000                             
02d12054: ldr     x0, [x0, #0xf58]                           T:UnityEngine.WaitForSeconds
02d12058: bl      #0x2b70db0                                 fn_2b70db0
02d1205c: mov     w8, #1                                     
02d12060: strb    w8, [x20, #0xfbc]                          
02d12064: ldr     w8, [x19, #0x10]                           .<>1__state
02d12068: cmp     w8, #1                                     
02d1206c: b.eq    #0x2d12080                                 
02d12070: cbnz    w8, #0x2d120e4                             
02d12074: mov     w8, #-1                                    
02d12078: str     w8, [x19, #0x10]                           .<>1__state
02d1207c: b       #0x2d12094                                 
02d12080: ldr     x0, [x19, #0x20]                           .<>4__this
02d12084: mov     w8, #-1                                    
02d12088: str     w8, [x19, #0x10]                           .<>1__state
02d1208c: cbz     x0, #0x2d120f8                             
02d12090: bl      #0x2d11d30                                 Livestream.LivestreamPanel::OnUpdateView
02d12094: fmov    s0, #1.00000000                            
02d12098: fmov    s1, #2.00000000                            
02d1209c: adrp    x20, #0x6264000                            
02d120a0: ldr     x20, [x20, #0xf58]                         T:UnityEngine.WaitForSeconds
02d120a4: mov     x0, xzr                                    
02d120a8: bl      #0x5b2dfc0                                 UnityEngine.Random::Range
02d120ac: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d120b0: fmov    s8, s0                                     
02d120b4: bl      #0x2b7104c                                 fn_2b7104c
02d120b8: fmov    s0, s8                                     
02d120bc: mov     x1, xzr                                    
02d120c0: mov     x20, x0                                    
02d120c4: bl      #0x5b3e5e8                                 UnityEngine.WaitForSeconds::.ctor
02d120c8: str     x20, [x19, #0x18]!                         .<>2__current
02d120cc: mov     x0, x19                                    
02d120d0: mov     x1, x20                                    
02d120d4: bl      #0x2b70d54                                 fn_2b70d54
02d120d8: mov     w0, #1                                     
02d120dc: stur    w0, [x19, #-8]                             
02d120e0: b       #0x2d120e8                                 
02d120e4: mov     w0, wzr                                    
02d120e8: ldp     x20, x19, [sp, #0x10]                      
02d120ec: ldr     x30, [sp, #8]                              
02d120f0: ldr     d8, [sp], #0x20                            
02d120f4: ret                                                
02d120f8: bl      #0x2b7105c                                 fn_2b7105c
## System.Collections.Generic.IEnumerator<System.Object>.get_Current() -> object
---- Livestream.LivestreamPanel/<UpdateView>d__9::System.Collections.Generic.IEnumerator<System.Object>.get_Current 0x2d120fc
02d120fc: ldr     x0, [x0, #0x18]                            .<>2__current
02d12100: ret                                                
## System.Collections.IEnumerator.Reset() -> void
---- Livestream.LivestreamPanel/<UpdateView>d__9::System.Collections.IEnumerator.Reset 0x2d12104
02d12104: stp     x30, x19, [sp, #-0x10]!                    
02d12108: adrp    x0, #0x6264000                             
02d1210c: ldr     x0, [x0, #0xf60]                           T:System.NotSupportedException
02d12110: bl      #0x2b70dc4                                 fn_2b70dc4
02d12114: bl      #0x2b7104c                                 fn_2b7104c
02d12118: mov     x1, xzr                                    
02d1211c: mov     x19, x0                                    
02d12120: bl      #0x4e14238                                 System.NotSupportedException::.ctor
02d12124: adrp    x0, #0x6269000                             
02d12128: ldr     x0, [x0, #0x7e8]                           M:Livestream.LivestreamPanel/<UpdateView>d__9::System.Collections.IEnumerator.Reset
02d1212c: bl      #0x2b70dc4                                 fn_2b70dc4
02d12130: mov     x1, x0                                     
02d12134: mov     x0, x19                                    
02d12138: bl      #0x2b70f20                                 fn_2b70f20
## System.Collections.IEnumerator.get_Current() -> object
---- Livestream.LivestreamPanel/<UpdateView>d__9::System.Collections.IEnumerator.get_Current 0x2d1213c
02d1213c: ldr     x0, [x0, #0x18]                            .<>2__current
02d12140: ret                                                
#### CLASS Livestream.LivestreamPanel parent= UnityEngine.MonoBehaviour
#   field _txtViewCount                  TMPro.TextMeshProUGUI                              off=0x20 attr=1 SerializeField
#   field _currentView                   int                                                off=0x28 attr=1 
#   field _viewTween                     DG.Tweening.Tween                                  off=0x30 attr=1 
## get_CurrentView() -> int
---- Livestream.LivestreamPanel::get_CurrentView 0x2d11b94
02d11b94: ldr     w0, [x0, #0x28]                            ._currentView
02d11b98: ret                                                
## Initialized() -> void
---- Livestream.LivestreamPanel::Initialized 0x2d11b9c
02d11b9c: ret                                                
## OnShow() -> void
---- Livestream.LivestreamPanel::OnShow 0x2d11ba0
02d11ba0: str     x30, [sp, #-0x20]!                         
02d11ba4: stp     x20, x19, [sp, #0x10]                      
02d11ba8: mov     x19, x0                                    
02d11bac: bl      #0x2d11c08                                 Livestream.LivestreamPanel::SetRandomView
02d11bb0: mov     x8, x19                                    
02d11bb4: mov     x1, xzr                                    
02d11bb8: str     w0, [x8, #0x28]!                           
02d11bbc: ldur    x20, [x8, #-8]                             
02d11bc0: mov     x0, x8                                     
02d11bc4: bl      #0x4e0ea3c                                 System.Int32::ToString
02d11bc8: cbz     x20, #0x2d11c04                            
02d11bcc: ldr     x8, [x20]                                  
02d11bd0: mov     x1, x0                                     
02d11bd4: mov     x0, x20                                    
02d11bd8: ldr     x9, [x8, #0x558]                           
02d11bdc: ldr     x2, [x8, #0x560]                           
02d11be0: blr     x9                                         
02d11be4: mov     x0, x19                                    
02d11be8: bl      #0x2d11c70                                 Livestream.LivestreamPanel::UpdateView
02d11bec: mov     x1, x0                                     
02d11bf0: mov     x0, x19                                    
02d11bf4: mov     x2, xzr                                    
02d11bf8: ldp     x20, x19, [sp, #0x10]                      
02d11bfc: ldr     x30, [sp], #0x20                           
02d11c00: b       #0x5b389f0                                 UnityEngine.MonoBehaviour::StartCoroutine
02d11c04: bl      #0x2b7105c                                 fn_2b7105c
## SetRandomView() -> int
---- Livestream.LivestreamPanel::SetRandomView 0x2d11c08
02d11c08: stp     x30, x21, [sp, #-0x20]!                    
02d11c0c: stp     x20, x19, [sp, #0x10]                      
02d11c10: adrp    x21, #0x662f000                            
02d11c14: adrp    x20, #0x6266000                            
02d11c18: mov     x19, x0                                    
02d11c1c: ldrb    w8, [x21, #0xfb9]                          
02d11c20: ldr     x20, [x20, #0x5e0]                         T:GameConfig
02d11c24: tbnz    w8, #0, #0x2d11c3c                         
02d11c28: adrp    x0, #0x6266000                             
02d11c2c: ldr     x0, [x0, #0x5e0]                           T:GameConfig
02d11c30: bl      #0x2b70db0                                 fn_2b70db0
02d11c34: mov     w8, #1                                     
02d11c38: strb    w8, [x21, #0xfb9]                          
02d11c3c: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d11c40: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02d11c44: cbnz    w8, #0x2d11c50                             
02d11c48: bl      #0x2b70f30                                 fn_2b70f30
02d11c4c: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d11c50: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time'
02d11c54: mov     x2, xzr                                    
02d11c58: ldp     w0, w1, [x8, #0x58]                        
02d11c5c: bl      #0x5b2e000                                 UnityEngine.Random::Range
02d11c60: str     w0, [x19, #0x28]                           ._currentView
02d11c64: ldp     x20, x19, [sp, #0x10]                      
02d11c68: ldp     x30, x21, [sp], #0x20                      
02d11c6c: ret                                                
## OnHide() -> void
---- Livestream.LivestreamPanel::OnHide 0x2d11cdc
02d11cdc: stp     x30, x19, [sp, #-0x10]!                    
02d11ce0: mov     x19, x0                                    
02d11ce4: ldr     x0, [x0, #0x30]                            ._viewTween
02d11ce8: cbz     x0, #0x2d11cf8                             
02d11cec: mov     w1, wzr                                    
02d11cf0: mov     x2, xzr                                    
02d11cf4: bl      #0x2d8fe94                                 DG.Tweening.TweenExtensions::Kill
02d11cf8: mov     x0, x19                                    
02d11cfc: mov     x1, xzr                                    
02d11d00: ldp     x30, x19, [sp], #0x10                      
02d11d04: b       #0x5b38f60                                 UnityEngine.MonoBehaviour::StopAllCoroutines
## UpdateView() -> System.Collections.IEnumerator
---- Livestream.LivestreamPanel::UpdateView 0x2d11c70
02d11c70: stp     x30, x21, [sp, #-0x20]!                    
02d11c74: stp     x20, x19, [sp, #0x10]                      
02d11c78: adrp    x20, #0x662f000                            
02d11c7c: adrp    x21, #0x6269000                            
02d11c80: mov     x19, x0                                    
02d11c84: ldrb    w8, [x20, #0xfba]                          
02d11c88: ldr     x21, [x21, #0x7b8]                         T:Livestream.LivestreamPanel/<UpdateView>d__9
02d11c8c: tbnz    w8, #0, #0x2d11ca4                         
02d11c90: adrp    x0, #0x6269000                             
02d11c94: ldr     x0, [x0, #0x7b8]                           T:Livestream.LivestreamPanel/<UpdateView>d__9
02d11c98: bl      #0x2b70db0                                 fn_2b70db0
02d11c9c: mov     w8, #1                                     
02d11ca0: strb    w8, [x20, #0xfba]                          
02d11ca4: ldr     x0, [x21]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d11ca8: bl      #0x2b7104c                                 fn_2b7104c
02d11cac: mov     x1, xzr                                    
02d11cb0: mov     x20, x0                                    
02d11cb4: bl      #0x4e53e9c                                 System.Object::.ctor
02d11cb8: mov     x0, x20                                    
02d11cbc: mov     x1, x19                                    
02d11cc0: str     wzr, [x20, #0x10]                          
02d11cc4: str     x19, [x0, #0x20]!                          ._txtViewCount
02d11cc8: bl      #0x2b70d54                                 fn_2b70d54
02d11ccc: mov     x0, x20                                    
02d11cd0: ldp     x20, x19, [sp, #0x10]                      
02d11cd4: ldp     x30, x21, [sp], #0x20                      
02d11cd8: ret                                                
## OnUpdateView() -> void
---- Livestream.LivestreamPanel::OnUpdateView 0x2d11d30
02d11d30: stp     x29, x30, [sp, #-0x60]!                    
02d11d34: stp     x28, x27, [sp, #0x10]                      
02d11d38: stp     x26, x25, [sp, #0x20]                      
02d11d3c: stp     x24, x23, [sp, #0x30]                      
02d11d40: stp     x22, x21, [sp, #0x40]                      
02d11d44: stp     x20, x19, [sp, #0x50]                      
02d11d48: adrp    x20, #0x662f000                            
02d11d4c: adrp    x21, #0x6269000                            
02d11d50: mov     x19, x0                                    
02d11d54: ldrb    w8, [x20, #0xfbb]                          
02d11d58: ldr     x21, [x21, #0x7c0]                         T:Livestream.LivestreamPanel/<>c__DisplayClass10_0
02d11d5c: tbnz    w8, #0, #0x2d11dd4                         
02d11d60: adrp    x0, #0x6264000                             
02d11d64: ldr     x0, [x0, #0x6b0]                           T:type8523(k15)
02d11d68: bl      #0x2b70db0                                 fn_2b70db0
02d11d6c: adrp    x0, #0x6264000                             
02d11d70: ldr     x0, [x0, #0x6b8]                           T:type8545(k15)
02d11d74: bl      #0x2b70db0                                 fn_2b70db0
02d11d78: adrp    x0, #0x6263000                             
02d11d7c: ldr     x0, [x0, #0xfd0]                           T:DG.Tweening.DOTween
02d11d80: bl      #0x2b70db0                                 fn_2b70db0
02d11d84: adrp    x0, #0x6264000                             
02d11d88: ldr     x0, [x0, #0xe8]                            T:DG.Tweening.TweenCallback
02d11d8c: bl      #0x2b70db0                                 fn_2b70db0
02d11d90: adrp    x0, #0x6269000                             
02d11d94: ldr     x0, [x0, #0x7c8]                           MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d11d98: bl      #0x2b70db0                                 fn_2b70db0
02d11d9c: adrp    x0, #0x6269000                             
02d11da0: ldr     x0, [x0, #0x7d0]                           M:Livestream.LivestreamPanel/<>c__DisplayClass10_0::<OnUpdateView>b__0
02d11da4: bl      #0x2b70db0                                 fn_2b70db0
02d11da8: adrp    x0, #0x6269000                             
02d11dac: ldr     x0, [x0, #0x7d8]                           M:Livestream.LivestreamPanel/<>c__DisplayClass10_0::<OnUpdateView>b__1
02d11db0: bl      #0x2b70db0                                 fn_2b70db0
02d11db4: adrp    x0, #0x6269000                             
02d11db8: ldr     x0, [x0, #0x7e0]                           M:Livestream.LivestreamPanel/<>c__DisplayClass10_0::<OnUpdateView>b__2
02d11dbc: bl      #0x2b70db0                                 fn_2b70db0
02d11dc0: adrp    x0, #0x6269000                             
02d11dc4: ldr     x0, [x0, #0x7c0]                           T:Livestream.LivestreamPanel/<>c__DisplayClass10_0
02d11dc8: bl      #0x2b70db0                                 fn_2b70db0
02d11dcc: mov     w8, #1                                     
02d11dd0: strb    w8, [x20, #0xfbb]                          
02d11dd4: ldr     x0, [x21]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d11dd8: bl      #0x2b7104c                                 fn_2b7104c
02d11ddc: mov     x1, xzr                                    
02d11de0: mov     x20, x0                                    
02d11de4: bl      #0x4e53e9c                                 System.Object::.ctor
02d11de8: cbz     x20, #0x2d11f3c                            
02d11dec: adrp    x29, #0x6264000                            
02d11df0: adrp    x22, #0x6269000                            
02d11df4: adrp    x28, #0x6264000                            
02d11df8: adrp    x23, #0x6269000                            
02d11dfc: adrp    x25, #0x6263000                            
02d11e00: mov     x21, x20                                   
02d11e04: ldr     x29, [x29, #0x6b0]                         T:type8523(k15)
02d11e08: ldr     x22, [x22, #0x7d0]                         M:Livestream.LivestreamPanel/<>c__DisplayClass10_0::<OnUpdateView>b__0
02d11e0c: ldr     x28, [x28, #0x6b8]                         T:type8545(k15)
02d11e10: ldr     x23, [x23, #0x7d8]                         M:Livestream.LivestreamPanel/<>c__DisplayClass10_0::<OnUpdateView>b__1
02d11e14: ldr     x25, [x25, #0xfd0]                         T:DG.Tweening.DOTween
02d11e18: mov     x1, x19                                    
02d11e1c: str     x19, [x21, #0x18]!                         
02d11e20: mov     x0, x21                                    
02d11e24: bl      #0x2b70d54                                 fn_2b70d54
02d11e28: ldr     w24, [x19, #0x28]                          ._currentView
02d11e2c: mov     w0, #-0x1f4                                
02d11e30: mov     w1, #0x1f4                                 
02d11e34: mov     x2, xzr                                    
02d11e38: stur    w24, [x21, #-8]                            
02d11e3c: bl      #0x5b2e000                                 UnityEngine.Random::Range
02d11e40: mov     x21, x19                                   
02d11e44: mov     w8, w0                                     
02d11e48: ldr     x0, [x21, #0x30]!                          MS:System.Collections.Generic.Dictionary`2::set_Item ._viewTween
02d11e4c: add     w8, w8, w24                                
02d11e50: str     w8, [x19, #0x28]                           ._currentView
02d11e54: cbz     x0, #0x2d11e64                             
02d11e58: mov     w1, wzr                                    
02d11e5c: mov     x2, xzr                                    
02d11e60: bl      #0x2d8fe94                                 DG.Tweening.TweenExtensions::Kill
02d11e64: adrp    x27, #0x6264000                            
02d11e68: adrp    x26, #0x6269000                            
02d11e6c: adrp    x24, #0x6269000                            
02d11e70: ldr     x27, [x27, #0xe8]                          T:DG.Tweening.TweenCallback
02d11e74: ldr     x26, [x26, #0x7e0]                         M:Livestream.LivestreamPanel/<>c__DisplayClass10_0::<OnUpdateView>b__2
02d11e78: ldr     x24, [x24, #0x7c8]                         MS:DG.Tweening.TweenSettingsExtensions::OnComplete
02d11e7c: ldr     x0, [x29]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d11e80: bl      #0x2b7104c                                 fn_2b7104c
02d11e84: ldr     x2, [x22]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d11e88: mov     x1, x20                                    
02d11e8c: mov     x3, xzr                                    
02d11e90: mov     x22, x0                                    
02d11e94: bl      #0x445323c                                 fn_445323c
02d11e98: ldr     x0, [x28]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d11e9c: bl      #0x2b7104c                                 fn_2b7104c
02d11ea0: ldr     x2, [x23]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d11ea4: mov     x1, x20                                    
02d11ea8: mov     x3, xzr                                    
02d11eac: mov     x23, x0                                    
02d11eb0: bl      #0x4454208                                 fn_4454208
02d11eb4: ldr     x0, [x25]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d11eb8: ldr     w19, [x19, #0x28]                          ._currentView
02d11ebc: ldr     w8, [x0, #0xe4]                            [62690e4]=0 f=0,0
02d11ec0: cbnz    w8, #0x2d11ec8                             
02d11ec4: bl      #0x2b70f30                                 fn_2b70f30
02d11ec8: fmov    s0, #1.00000000                            
02d11ecc: mov     x0, x22                                    
02d11ed0: mov     x1, x23                                    
02d11ed4: mov     w2, w19                                    
02d11ed8: mov     x3, xzr                                    
02d11edc: bl      #0x2d8b4e4                                 DG.Tweening.DOTween::To
02d11ee0: ldr     x8, [x27]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d11ee4: mov     x19, x0                                    
02d11ee8: mov     x0, x8                                     
02d11eec: bl      #0x2b7104c                                 fn_2b7104c
02d11ef0: ldr     x2, [x26]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d11ef4: mov     x1, x20                                    
02d11ef8: mov     x3, xzr                                    
02d11efc: mov     x22, x0                                    
02d11f00: bl      #0x2d89dc4                                 DG.Tweening.TweenCallback::.ctor
02d11f04: ldr     x2, [x24]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d11f08: mov     x0, x19                                    
02d11f0c: mov     x1, x22                                    
02d11f10: bl      #0x336f26c                                 fn_336f26c
02d11f14: mov     x1, x0                                     
02d11f18: mov     x0, x21                                    
02d11f1c: str     x1, [x21]                                  
02d11f20: ldp     x20, x19, [sp, #0x50]                      
02d11f24: ldp     x22, x21, [sp, #0x40]                      
02d11f28: ldp     x24, x23, [sp, #0x30]                      
02d11f2c: ldp     x26, x25, [sp, #0x20]                      
02d11f30: ldp     x28, x27, [sp, #0x10]                      
02d11f34: ldp     x29, x30, [sp], #0x60                      
02d11f38: b       #0x2b70d54                                 
02d11f3c: bl      #0x2b7105c                                 fn_2b7105c
## OnDisable() -> void
---- Livestream.LivestreamPanel::OnDisable 0x2d11f48
02d11f48: ldr     x0, [x0, #0x30]                            ._viewTween
02d11f4c: cbz     x0, #0x2d11f5c                             
02d11f50: mov     w1, wzr                                    
02d11f54: mov     x2, xzr                                    
02d11f58: b       #0x2d8fe94                                 DG.Tweening.TweenExtensions::Kill
02d11f5c: ret                                                
## OnDestroy() -> void
---- Livestream.LivestreamPanel::OnDestroy 0x2d11f60
02d11f60: ldr     x0, [x0, #0x30]                            ._viewTween
02d11f64: cbz     x0, #0x2d11f74                             
02d11f68: mov     w1, wzr                                    
02d11f6c: mov     x2, xzr                                    
02d11f70: b       #0x2d8fe94                                 DG.Tweening.TweenExtensions::Kill
02d11f74: ret                                                
## .ctor() -> void
---- Livestream.LivestreamPanel::.ctor 0x2d11f78
02d11f78: mov     x1, xzr                                    
02d11f7c: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
