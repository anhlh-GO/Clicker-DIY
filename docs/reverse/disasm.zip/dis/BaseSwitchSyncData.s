#### CLASS BaseSwitchSyncData parent= object
#   field ShowIndex                      string                                             off=0x10 attr=6 
#   field SpriteName                     string                                             off=0x18 attr=6 
#   field LockType                       string                                             off=0x20 attr=6 
#   field value                          int                                                off=0x28 attr=6 
## .ctor() -> void
---- BaseSwitchSyncData::.ctor 0x2ca8488
02ca8488: mov     x1, xzr                                    
02ca848c: b       #0x4e53e9c                                 System.Object::.ctor
