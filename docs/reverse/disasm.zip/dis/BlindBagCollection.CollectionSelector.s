#### CLASS BlindBagCollection.CollectionSelector parent= UnityEngine.MonoBehaviour
#   field _boxSpacing                    float                                              off=0x20 attr=1 HeaderAttribute,SerializeField
#   field _moveSpeed                     float                                              off=0x24 attr=1 SerializeField
#   field _collectionBoxes               System.Collections.Generic.List`1<BlindBagCollection.CollectionBox> off=0x28 attr=1 SpaceAttribute,HeaderAttribute,SerializeField
#   field _previousButton                BlindBagCollection.CollectionNaviagationButton     off=0x30 attr=1 SerializeField
#   field _nextButton                    BlindBagCollection.CollectionNaviagationButton     off=0x38 attr=1 SerializeField
#   field _pivot                         UnityEngine.Transform                              off=0x40 attr=1 SerializeField
#   field _pagesScrollVisual             PagesScrollVisual                                  off=0x48 attr=1 SerializeField
#   field _currentBoxIndex               int                                                off=0x50 attr=1 
#   field _currentBox                    BlindBagCollection.CollectionBox                   off=0x58 attr=1 
#   field _moveTween                     DG.Tweening.Tween                                  off=0x60 attr=1 
## GetCurrentItemPosition() -> UnityEngine.Vector2
---- BlindBagCollection.CollectionSelector::GetCurrentItemPosition 0x2d37044
02d37044: ldr     x0, [x0, #0x58]                            ._currentBox
02d37048: cbz     x0, #0x2d37050                             
02d3704c: b       #0x2d39230                                 BlindBagCollection.CollectionBox::GetCurrentItemPosition
02d37050: str     x30, [sp, #-0x10]!                         
02d37054: bl      #0x2b7105c                                 fn_2b7105c
## GetCurrentBox() -> BlindBagCollection.CollectionBox
---- BlindBagCollection.CollectionSelector::GetCurrentBox 0x2d3af88
02d3af88: ldr     x0, [x0, #0x58]                            ._currentBox
02d3af8c: ret                                                
## Awake() -> void
---- BlindBagCollection.CollectionSelector::Awake 0x2d3af90
02d3af90: stp     x30, x25, [sp, #-0x40]!                    
02d3af94: stp     x24, x23, [sp, #0x10]                      
02d3af98: stp     x22, x21, [sp, #0x20]                      
02d3af9c: stp     x20, x19, [sp, #0x30]                      
02d3afa0: adrp    x20, #0x6630000                            
02d3afa4: adrp    x23, #0x6264000                            
02d3afa8: adrp    x21, #0x626a000                            
02d3afac: ldrb    w8, [x20, #0x14b]                          
02d3afb0: ldr     x23, [x23, #0xf90]                         T:System.Action
02d3afb4: ldr     x21, [x21, #0xcd8]                         M:BlindBagCollection.CollectionSelector::OnPreviousButtonClicked
02d3afb8: mov     x19, x0                                    
02d3afbc: tbnz    w8, #0, #0x2d3b034                         
02d3afc0: adrp    x0, #0x626a000                             
02d3afc4: ldr     x0, [x0, #0xb20]                           T:type53138(k15)
02d3afc8: bl      #0x2b70db0                                 fn_2b70db0
02d3afcc: adrp    x0, #0x6264000                             
02d3afd0: ldr     x0, [x0, #0xf90]                           T:System.Action
02d3afd4: bl      #0x2b70db0                                 fn_2b70db0
02d3afd8: adrp    x0, #0x626a000                             
02d3afdc: ldr     x0, [x0, #0xb18]                           T:BlindBagCollection.BlindbagDragController
02d3afe0: bl      #0x2b70db0                                 fn_2b70db0
02d3afe4: adrp    x0, #0x626a000                             
02d3afe8: ldr     x0, [x0, #0xce0]                           M:BlindBagCollection.CollectionSelector::OnDragEndHandler
02d3afec: bl      #0x2b70db0                                 fn_2b70db0
02d3aff0: adrp    x0, #0x626a000                             
02d3aff4: ldr     x0, [x0, #0xce8]                           M:BlindBagCollection.CollectionSelector::OnDragStartHandler
02d3aff8: bl      #0x2b70db0                                 fn_2b70db0
02d3affc: adrp    x0, #0x626a000                             
02d3b000: ldr     x0, [x0, #0xcf0]                           M:BlindBagCollection.CollectionSelector::OnNextButtonClicked
02d3b004: bl      #0x2b70db0                                 fn_2b70db0
02d3b008: adrp    x0, #0x626a000                             
02d3b00c: ldr     x0, [x0, #0xcd8]                           M:BlindBagCollection.CollectionSelector::OnPreviousButtonClicked
02d3b010: bl      #0x2b70db0                                 fn_2b70db0
02d3b014: adrp    x0, #0x626a000                             
02d3b018: ldr     x0, [x0, #0xcf8]                           MS:System.Collections.Generic.List`1::get_Count
02d3b01c: bl      #0x2b70db0                                 fn_2b70db0
02d3b020: adrp    x0, #0x626a000                             
02d3b024: ldr     x0, [x0, #0xd00]                           MS:System.Collections.Generic.List`1::get_Item
02d3b028: bl      #0x2b70db0                                 fn_2b70db0
02d3b02c: mov     w8, #1                                     
02d3b030: strb    w8, [x20, #0x14b]                          
02d3b034: ldr     x0, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d3b038: ldr     x20, [x19, #0x30]                          ._previousButton
02d3b03c: bl      #0x2b7104c                                 fn_2b7104c
02d3b040: ldr     x2, [x21]                                  T:type56879(k15)
02d3b044: mov     x1, x19                                    
02d3b048: mov     x3, xzr                                    
02d3b04c: mov     x21, x0                                    
02d3b050: bl      #0x4d8ddbc                                 System.Action::.ctor
02d3b054: cbz     x20, #0x2d3b258                            
02d3b058: adrp    x22, #0x626a000                            
02d3b05c: mov     x1, x21                                    
02d3b060: ldr     x22, [x22, #0xcf0]                         M:BlindBagCollection.CollectionSelector::OnNextButtonClicked
02d3b064: str     x21, [x20, #0x20]!                         ._boxSpacing
02d3b068: mov     x0, x20                                    
02d3b06c: bl      #0x2b70d54                                 fn_2b70d54
02d3b070: ldr     x0, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d3b074: ldr     x20, [x19, #0x38]                          ._nextButton
02d3b078: bl      #0x2b7104c                                 fn_2b7104c
02d3b07c: ldr     x2, [x22]                                  T:type56879(k15)
02d3b080: mov     x1, x19                                    
02d3b084: mov     x3, xzr                                    
02d3b088: mov     x21, x0                                    
02d3b08c: bl      #0x4d8ddbc                                 System.Action::.ctor
02d3b090: cbz     x20, #0x2d3b258                            
02d3b094: adrp    x24, #0x626a000                            
02d3b098: adrp    x22, #0x626a000                            
02d3b09c: adrp    x25, #0x626a000                            
02d3b0a0: ldr     x24, [x24, #0xb18]                         T:BlindBagCollection.BlindbagDragController
02d3b0a4: ldr     x22, [x22, #0xb20]                         T:type53138(k15)
02d3b0a8: ldr     x25, [x25, #0xce8]                         M:BlindBagCollection.CollectionSelector::OnDragStartHandler
02d3b0ac: str     x21, [x20, #0x20]!                         ._boxSpacing
02d3b0b0: mov     x0, x20                                    
02d3b0b4: mov     x1, x21                                    
02d3b0b8: bl      #0x2b70d54                                 fn_2b70d54
02d3b0bc: ldr     x8, [x24]                                  T:type56879(k15)
02d3b0c0: ldr     x0, [x22]                                  T:type56879(k15)
02d3b0c4: ldr     x8, [x8, #0xb8]                            
02d3b0c8: ldr     x20, [x8]                                  
02d3b0cc: bl      #0x2b7104c                                 fn_2b7104c
02d3b0d0: ldr     x2, [x25]                                  T:type56879(k15)
02d3b0d4: mov     x1, x19                                    
02d3b0d8: mov     x3, xzr                                    
02d3b0dc: mov     x21, x0                                    
02d3b0e0: bl      #0x453418c                                 fn_453418c
02d3b0e4: mov     x0, x20                                    
02d3b0e8: mov     x1, x21                                    
02d3b0ec: mov     x2, xzr                                    
02d3b0f0: bl      #0x4e570ac                                 System.Delegate::Combine
02d3b0f4: cbz     x0, #0x2d3b13c                             
02d3b0f8: ldr     x21, [x22]                                 T:type56879(k15)
02d3b0fc: mov     x20, x0                                    
02d3b100: mov     x1, x21                                    
02d3b104: bl      #0x2b70f34                                 fn_2b70f34
02d3b108: cbz     x0, #0x2d3b25c                             
02d3b10c: ldr     x8, [x24]                                  T:type56879(k15)
02d3b110: ldr     x8, [x8, #0xb8]                            
02d3b114: str     x0, [x8]                                   
02d3b118: mov     x0, x20                                    
02d3b11c: ldr     x8, [x24]                                  T:type56879(k15)
02d3b120: ldr     x22, [x22]                                 T:type56879(k15)
02d3b124: ldr     x21, [x8, #0xb8]                           
02d3b128: mov     x1, x22                                    
02d3b12c: bl      #0x2b70f34                                 fn_2b70f34
02d3b130: cbz     x0, #0x2d3b268                             
02d3b134: mov     x1, x0                                     
02d3b138: b       #0x2d3b154                                 
02d3b13c: ldr     x8, [x24]                                  T:type56879(k15)
02d3b140: mov     x1, xzr                                    
02d3b144: ldr     x8, [x8, #0xb8]                            
02d3b148: str     xzr, [x8]                                  
02d3b14c: ldr     x8, [x24]                                  T:type56879(k15)
02d3b150: ldr     x21, [x8, #0xb8]                           
02d3b154: adrp    x22, #0x626a000                            
02d3b158: mov     x0, x21                                    
02d3b15c: ldr     x22, [x22, #0xce0]                         M:BlindBagCollection.CollectionSelector::OnDragEndHandler
02d3b160: bl      #0x2b70d54                                 fn_2b70d54
02d3b164: ldr     x8, [x24]                                  T:type56879(k15)
02d3b168: ldr     x0, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d3b16c: ldr     x8, [x8, #0xb8]                            
02d3b170: ldr     x20, [x8, #8]                              
02d3b174: bl      #0x2b7104c                                 fn_2b7104c
02d3b178: ldr     x2, [x22]                                  T:type56879(k15)
02d3b17c: mov     x1, x19                                    
02d3b180: mov     x3, xzr                                    
02d3b184: mov     x21, x0                                    
02d3b188: bl      #0x4d8ddbc                                 System.Action::.ctor
02d3b18c: mov     x0, x20                                    
02d3b190: mov     x1, x21                                    
02d3b194: mov     x2, xzr                                    
02d3b198: bl      #0x4e570ac                                 System.Delegate::Combine
02d3b19c: mov     x8, x0                                     
02d3b1a0: cbz     x0, #0x2d3b1d4                             
02d3b1a4: ldr     x1, [x23]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d3b1a8: ldr     x9, [x8]                                   
02d3b1ac: cmp     x9, x1                                     
02d3b1b0: b.ne    #0x2d3b1cc                                 
02d3b1b4: ldr     x9, [x24]                                  T:type56879(k15)
02d3b1b8: ldr     x0, [x9, #0xb8]                            
02d3b1bc: str     x8, [x0, #8]!                              
02d3b1c0: ldr     x9, [x8]                                   
02d3b1c4: cmp     x9, x1                                     
02d3b1c8: b.eq    #0x2d3b1e0                                 
02d3b1cc: mov     x0, x8                                     
02d3b1d0: bl      #0x2b713dc                                 fn_2b713dc
02d3b1d4: ldr     x9, [x24]                                  T:type56879(k15)
02d3b1d8: ldr     x0, [x9, #0xb8]                            
02d3b1dc: str     xzr, [x0, #8]!                             
02d3b1e0: mov     x1, x8                                     
02d3b1e4: bl      #0x2b70d54                                 fn_2b70d54
02d3b1e8: ldr     x0, [x19, #0x28]                           ._collectionBoxes
02d3b1ec: cbz     x0, #0x2d3b258                             
02d3b1f0: adrp    x8, #0x626a000                             
02d3b1f4: ldr     x8, [x8, #0xd00]                           MS:System.Collections.Generic.List`1::get_Item
02d3b1f8: ldr     w1, [x19, #0x50]                           ._currentBoxIndex
02d3b1fc: ldr     x2, [x8]                                   T:type56879(k15)
02d3b200: bl      #0x35a8f3c                                 fn_35a8f3c
02d3b204: mov     x20, x19                                   
02d3b208: mov     x1, x0                                     
02d3b20c: str     x0, [x20, #0x58]!                          ._currentBox
02d3b210: mov     x0, x20                                    
02d3b214: bl      #0x2b70d54                                 fn_2b70d54
02d3b218: ldur    x8, [x20, #-0x30]                          
02d3b21c: cbz     x8, #0x2d3b258                             
02d3b220: ldur    x0, [x20, #-0x10]                          
02d3b224: cbz     x0, #0x2d3b258                             
02d3b228: ldr     w1, [x8, #0x18]                            MS:System.Collections.Generic.List`1::Add
02d3b22c: mov     x2, xzr                                    
02d3b230: bl      #0x2cae2e0                                 PagesScrollVisual::SetPages
02d3b234: ldr     x0, [x19, #0x48]                           ._pagesScrollVisual
02d3b238: cbz     x0, #0x2d3b258                             
02d3b23c: ldr     w1, [x19, #0x50]                           ._currentBoxIndex
02d3b240: ldp     x20, x19, [sp, #0x30]                      
02d3b244: ldp     x22, x21, [sp, #0x20]                      
02d3b248: mov     x2, xzr                                    
02d3b24c: ldp     x24, x23, [sp, #0x10]                      
02d3b250: ldp     x30, x25, [sp], #0x40                      
02d3b254: b       #0x2cae3ec                                 PagesScrollVisual::HighlightPage
02d3b258: bl      #0x2b7105c                                 fn_2b7105c
02d3b25c: mov     x0, x20                                    
02d3b260: mov     x1, x21                                    
02d3b264: bl      #0x2b713dc                                 fn_2b713dc
02d3b268: mov     x0, x20                                    
02d3b26c: mov     x1, x22                                    
02d3b270: bl      #0x2b713dc                                 fn_2b713dc
## OnDestroy() -> void
---- BlindBagCollection.CollectionSelector::OnDestroy 0x2d3b274
02d3b274: str     x30, [sp, #-0x40]!                         
02d3b278: stp     x24, x23, [sp, #0x10]                      
02d3b27c: stp     x22, x21, [sp, #0x20]                      
02d3b280: stp     x20, x19, [sp, #0x30]                      
02d3b284: adrp    x20, #0x6630000                            
02d3b288: adrp    x23, #0x626a000                            
02d3b28c: adrp    x22, #0x626a000                            
02d3b290: adrp    x21, #0x626a000                            
02d3b294: ldr     x23, [x23, #0xb18]                         T:BlindBagCollection.BlindbagDragController
02d3b298: ldrb    w8, [x20, #0x14c]                          
02d3b29c: ldr     x22, [x22, #0xb20]                         T:type53138(k15)
02d3b2a0: ldr     x21, [x21, #0xce8]                         M:BlindBagCollection.CollectionSelector::OnDragStartHandler
02d3b2a4: mov     x19, x0                                    
02d3b2a8: tbnz    w8, #0, #0x2d3b2f0                         
02d3b2ac: adrp    x0, #0x626a000                             
02d3b2b0: ldr     x0, [x0, #0xb20]                           T:type53138(k15)
02d3b2b4: bl      #0x2b70db0                                 fn_2b70db0
02d3b2b8: adrp    x0, #0x6264000                             
02d3b2bc: ldr     x0, [x0, #0xf90]                           T:System.Action
02d3b2c0: bl      #0x2b70db0                                 fn_2b70db0
02d3b2c4: adrp    x0, #0x626a000                             
02d3b2c8: ldr     x0, [x0, #0xb18]                           T:BlindBagCollection.BlindbagDragController
02d3b2cc: bl      #0x2b70db0                                 fn_2b70db0
02d3b2d0: adrp    x0, #0x626a000                             
02d3b2d4: ldr     x0, [x0, #0xce0]                           M:BlindBagCollection.CollectionSelector::OnDragEndHandler
02d3b2d8: bl      #0x2b70db0                                 fn_2b70db0
02d3b2dc: adrp    x0, #0x626a000                             
02d3b2e0: ldr     x0, [x0, #0xce8]                           M:BlindBagCollection.CollectionSelector::OnDragStartHandler
02d3b2e4: bl      #0x2b70db0                                 fn_2b70db0
02d3b2e8: mov     w8, #1                                     
02d3b2ec: strb    w8, [x20, #0x14c]                          
02d3b2f0: ldr     x8, [x23]                                  T:type56879(k15)
02d3b2f4: ldr     x0, [x22]                                  T:type56879(k15)
02d3b2f8: ldr     x8, [x8, #0xb8]                            
02d3b2fc: ldr     x20, [x8]                                  
02d3b300: bl      #0x2b7104c                                 fn_2b7104c
02d3b304: ldr     x2, [x21]                                  T:type56879(k15)
02d3b308: mov     x1, x19                                    
02d3b30c: mov     x3, xzr                                    
02d3b310: mov     x21, x0                                    
02d3b314: bl      #0x453418c                                 fn_453418c
02d3b318: mov     x0, x20                                    
02d3b31c: mov     x1, x21                                    
02d3b320: mov     x2, xzr                                    
02d3b324: bl      #0x4e57298                                 System.Delegate::Remove
02d3b328: cbz     x0, #0x2d3b370                             
02d3b32c: ldr     x21, [x22]                                 T:type56879(k15)
02d3b330: mov     x20, x0                                    
02d3b334: mov     x1, x21                                    
02d3b338: bl      #0x2b70f34                                 fn_2b70f34
02d3b33c: cbz     x0, #0x2d3b434                             
02d3b340: ldr     x8, [x23]                                  T:type56879(k15)
02d3b344: ldr     x8, [x8, #0xb8]                            
02d3b348: str     x0, [x8]                                   
02d3b34c: mov     x0, x20                                    
02d3b350: ldr     x8, [x23]                                  T:type56879(k15)
02d3b354: ldr     x22, [x22]                                 T:type56879(k15)
02d3b358: ldr     x21, [x8, #0xb8]                           
02d3b35c: mov     x1, x22                                    
02d3b360: bl      #0x2b70f34                                 fn_2b70f34
02d3b364: cbz     x0, #0x2d3b440                             
02d3b368: mov     x1, x0                                     
02d3b36c: b       #0x2d3b388                                 
02d3b370: ldr     x8, [x23]                                  T:type56879(k15)
02d3b374: mov     x1, xzr                                    
02d3b378: ldr     x8, [x8, #0xb8]                            
02d3b37c: str     xzr, [x8]                                  
02d3b380: ldr     x8, [x23]                                  T:type56879(k15)
02d3b384: ldr     x21, [x8, #0xb8]                           
02d3b388: adrp    x22, #0x6264000                            
02d3b38c: adrp    x24, #0x626a000                            
02d3b390: mov     x0, x21                                    
02d3b394: ldr     x22, [x22, #0xf90]                         T:System.Action
02d3b398: ldr     x24, [x24, #0xce0]                         M:BlindBagCollection.CollectionSelector::OnDragEndHandler
02d3b39c: bl      #0x2b70d54                                 fn_2b70d54
02d3b3a0: ldr     x8, [x23]                                  T:type56879(k15)
02d3b3a4: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d3b3a8: ldr     x8, [x8, #0xb8]                            
02d3b3ac: ldr     x20, [x8, #8]                              
02d3b3b0: bl      #0x2b7104c                                 fn_2b7104c
02d3b3b4: ldr     x2, [x24]                                  T:type56879(k15)
02d3b3b8: mov     x1, x19                                    
02d3b3bc: mov     x3, xzr                                    
02d3b3c0: mov     x21, x0                                    
02d3b3c4: bl      #0x4d8ddbc                                 System.Action::.ctor
02d3b3c8: mov     x0, x20                                    
02d3b3cc: mov     x1, x21                                    
02d3b3d0: mov     x2, xzr                                    
02d3b3d4: bl      #0x4e57298                                 System.Delegate::Remove
02d3b3d8: mov     x8, x0                                     
02d3b3dc: cbz     x0, #0x2d3b410                             
02d3b3e0: ldr     x1, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d3b3e4: ldr     x9, [x8]                                   
02d3b3e8: cmp     x9, x1                                     
02d3b3ec: b.ne    #0x2d3b408                                 
02d3b3f0: ldr     x9, [x23]                                  T:type56879(k15)
02d3b3f4: ldr     x0, [x9, #0xb8]                            
02d3b3f8: str     x8, [x0, #8]!                              
02d3b3fc: ldr     x9, [x8]                                   
02d3b400: cmp     x9, x1                                     
02d3b404: b.eq    #0x2d3b41c                                 
02d3b408: mov     x0, x8                                     
02d3b40c: bl      #0x2b713dc                                 fn_2b713dc
02d3b410: ldr     x9, [x23]                                  T:type56879(k15)
02d3b414: ldr     x0, [x9, #0xb8]                            
02d3b418: str     xzr, [x0, #8]!                             
02d3b41c: ldp     x20, x19, [sp, #0x30]                      
02d3b420: mov     x1, x8                                     
02d3b424: ldp     x22, x21, [sp, #0x20]                      
02d3b428: ldp     x24, x23, [sp, #0x10]                      
02d3b42c: ldr     x30, [sp], #0x40                           
02d3b430: b       #0x2b70d54                                 
02d3b434: mov     x0, x20                                    
02d3b438: mov     x1, x21                                    
02d3b43c: bl      #0x2b713dc                                 fn_2b713dc
02d3b440: mov     x0, x20                                    
02d3b444: mov     x1, x22                                    
02d3b448: bl      #0x2b713dc                                 fn_2b713dc
## OnDragEndHandler() -> void
---- BlindBagCollection.CollectionSelector::OnDragEndHandler 0x2d3b44c
02d3b44c: stp     x30, x19, [sp, #-0x10]!                    
02d3b450: mov     x19, x0                                    
02d3b454: ldr     x0, [x0, #0x58]                            ._currentBox
02d3b458: cbz     x0, #0x2d3b460                             
02d3b45c: bl      #0x2d394d4                                 BlindBagCollection.CollectionBox::DisableHighlight
02d3b460: ldr     x8, [x19, #0x30]                           ._previousButton
02d3b464: cbz     x8, #0x2d3b484                             
02d3b468: ldr     x9, [x19, #0x38]                           ._nextButton
02d3b46c: mov     w10, #1                                    
02d3b470: strb    w10, [x8, #0x28]                           
02d3b474: cbz     x9, #0x2d3b484                             
02d3b478: strb    w10, [x9, #0x28]                           
02d3b47c: ldp     x30, x19, [sp], #0x10                      
02d3b480: ret                                                
02d3b484: bl      #0x2b7105c                                 fn_2b7105c
## OnDragStartHandler(BlindBagCollection.ItemDraggable item) -> void
---- BlindBagCollection.CollectionSelector::OnDragStartHandler 0x2d3b488
02d3b488: str     x30, [sp, #-0x30]!                         
02d3b48c: stp     x22, x21, [sp, #0x10]                      
02d3b490: stp     x20, x19, [sp, #0x20]                      
02d3b494: adrp    x21, #0x6630000                            
02d3b498: mov     x20, x1                                    
02d3b49c: mov     x19, x0                                    
02d3b4a0: ldrb    w8, [x21, #0x14d]                          
02d3b4a4: tbnz    w8, #0, #0x2d3b4c8                         
02d3b4a8: adrp    x0, #0x626a000                             
02d3b4ac: ldr     x0, [x0, #0xcf8]                           MS:System.Collections.Generic.List`1::get_Count
02d3b4b0: bl      #0x2b70db0                                 fn_2b70db0
02d3b4b4: adrp    x0, #0x626a000                             
02d3b4b8: ldr     x0, [x0, #0xd00]                           MS:System.Collections.Generic.List`1::get_Item
02d3b4bc: bl      #0x2b70db0                                 fn_2b70db0
02d3b4c0: mov     w8, #1                                     
02d3b4c4: strb    w8, [x21, #0x14d]                          
02d3b4c8: ldr     x0, [x19, #0x28]                           ._collectionBoxes
02d3b4cc: cbz     x0, #0x2d3b518                             
02d3b4d0: adrp    x22, #0x626a000                            
02d3b4d4: mov     w21, wzr                                   
02d3b4d8: ldr     x22, [x22, #0xd00]                         MS:System.Collections.Generic.List`1::get_Item
02d3b4dc: ldr     w8, [x0, #0x18]                            MS:System.Collections.Generic.List`1::Add
02d3b4e0: cmp     w21, w8                                    
02d3b4e4: b.ge    #0x2d3b55c                                 
02d3b4e8: ldr     x2, [x22]                                  T:type56879(k15)
02d3b4ec: mov     w1, w21                                    
02d3b4f0: bl      #0x35a8f3c                                 fn_35a8f3c
02d3b4f4: cbz     x0, #0x2d3b518                             
02d3b4f8: cbz     x20, #0x2d3b518                            
02d3b4fc: ldr     w8, [x0, #0x20]                            M:Decor.DataDecor/<>c__DisplayClass8_0::<NewData>b__0 ._boxSpacing
02d3b500: ldr     w9, [x20, #0x24]                           ._moveSpeed
02d3b504: cmp     w9, w8                                     
02d3b508: b.eq    #0x2d3b51c                                 
02d3b50c: ldr     x0, [x19, #0x28]                           ._collectionBoxes
02d3b510: add     w21, w21, #1                               
02d3b514: cbnz    x0, #0x2d3b4dc                             
02d3b518: bl      #0x2b7105c                                 fn_2b7105c
02d3b51c: ldr     x0, [x19, #0x48]                           ._pagesScrollVisual
02d3b520: str     w21, [x19, #0x50]                          ._currentBoxIndex
02d3b524: cbz     x0, #0x2d3b518                             
02d3b528: mov     w1, w21                                    
02d3b52c: mov     x2, xzr                                    
02d3b530: bl      #0x2cae3ec                                 PagesScrollVisual::HighlightPage
02d3b534: ldr     x0, [x19, #0x28]                           ._collectionBoxes
02d3b538: cbz     x0, #0x2d3b518                             
02d3b53c: ldr     x2, [x22]                                  T:type56879(k15)
02d3b540: mov     w1, w21                                    
02d3b544: bl      #0x35a8f3c                                 fn_35a8f3c
02d3b548: cbz     x0, #0x2d3b518                             
02d3b54c: ldr     w1, [x20, #0x20]                           ._boxSpacing
02d3b550: bl      #0x2d39274                                 BlindBagCollection.CollectionBox::SetHighlight
02d3b554: mov     x0, x19                                    
02d3b558: bl      #0x2d3b594                                 BlindBagCollection.CollectionSelector::UpdateCurrentBox
02d3b55c: ldr     x8, [x19, #0x30]                           ._previousButton
02d3b560: cbz     x8, #0x2d3b518                             
02d3b564: ldr     x9, [x19, #0x38]                           ._nextButton
02d3b568: strb    wzr, [x8, #0x28]                           
02d3b56c: cbz     x9, #0x2d3b518                             
02d3b570: ldp     x20, x19, [sp, #0x20]                      
02d3b574: strb    wzr, [x9, #0x28]                           
02d3b578: ldp     x22, x21, [sp, #0x10]                      
02d3b57c: ldr     x30, [sp], #0x30                           
02d3b580: ret                                                
## OnPreviousButtonClicked() -> void
---- BlindBagCollection.CollectionSelector::OnPreviousButtonClicked 0x2d3b708
02d3b708: stp     x30, x19, [sp, #-0x10]!                    
02d3b70c: movi    d1, #0000000000000000                      
02d3b710: movi    d2, #0000000000000000                      
02d3b714: mov     x19, x0                                    
02d3b718: fmov    s0, #1.00000000                            
02d3b71c: mov     w0, #1                                     
02d3b720: mov     w1, wzr                                    
02d3b724: mov     w2, wzr                                    
02d3b728: mov     x3, xzr                                    
02d3b72c: bl      #0x2d84264                                 Framework.AudioHelper::PlaySound
02d3b730: ldr     w8, [x19, #0x50]                           ._currentBoxIndex
02d3b734: subs    w1, w8, #1                                 
02d3b738: b.lt    #0x2d3b75c                                 
02d3b73c: ldr     x0, [x19, #0x48]                           ._pagesScrollVisual
02d3b740: str     w1, [x19, #0x50]                           ._currentBoxIndex
02d3b744: cbz     x0, #0x2d3b764                             
02d3b748: mov     x2, xzr                                    
02d3b74c: bl      #0x2cae3ec                                 PagesScrollVisual::HighlightPage
02d3b750: mov     x0, x19                                    
02d3b754: ldp     x30, x19, [sp], #0x10                      
02d3b758: b       #0x2d3b594                                 BlindBagCollection.CollectionSelector::UpdateCurrentBox
02d3b75c: ldp     x30, x19, [sp], #0x10                      
02d3b760: ret                                                
02d3b764: bl      #0x2b7105c                                 fn_2b7105c
## OnNextButtonClicked() -> void
---- BlindBagCollection.CollectionSelector::OnNextButtonClicked 0x2d3b768
02d3b768: str     x30, [sp, #-0x20]!                         
02d3b76c: stp     x20, x19, [sp, #0x10]                      
02d3b770: adrp    x20, #0x6630000                            
02d3b774: mov     x19, x0                                    
02d3b778: ldrb    w8, [x20, #0x14e]                          
02d3b77c: tbnz    w8, #0, #0x2d3b794                         
02d3b780: adrp    x0, #0x626a000                             
02d3b784: ldr     x0, [x0, #0xcf8]                           MS:System.Collections.Generic.List`1::get_Count
02d3b788: bl      #0x2b70db0                                 fn_2b70db0
02d3b78c: mov     w8, #1                                     
02d3b790: strb    w8, [x20, #0x14e]                          
02d3b794: movi    d1, #0000000000000000                      
02d3b798: movi    d2, #0000000000000000                      
02d3b79c: mov     w0, #1                                     
02d3b7a0: fmov    s0, #1.00000000                            
02d3b7a4: mov     w1, wzr                                    
02d3b7a8: mov     w2, wzr                                    
02d3b7ac: mov     x3, xzr                                    
02d3b7b0: bl      #0x2d84264                                 Framework.AudioHelper::PlaySound
02d3b7b4: ldr     x8, [x19, #0x28]                           ._collectionBoxes
02d3b7b8: cbz     x8, #0x2d3b804                             
02d3b7bc: ldr     w9, [x8, #0x18]                            
02d3b7c0: ldr     w8, [x19, #0x50]                           ._currentBoxIndex
02d3b7c4: sub     w9, w9, #1                                 
02d3b7c8: cmp     w8, w9                                     
02d3b7cc: b.ge    #0x2d3b7f8                                 
02d3b7d0: ldr     x0, [x19, #0x48]                           ._pagesScrollVisual
02d3b7d4: add     w1, w8, #1                                 
02d3b7d8: str     w1, [x19, #0x50]                           ._currentBoxIndex
02d3b7dc: cbz     x0, #0x2d3b804                             
02d3b7e0: mov     x2, xzr                                    
02d3b7e4: bl      #0x2cae3ec                                 PagesScrollVisual::HighlightPage
02d3b7e8: mov     x0, x19                                    
02d3b7ec: ldp     x20, x19, [sp, #0x10]                      
02d3b7f0: ldr     x30, [sp], #0x20                           
02d3b7f4: b       #0x2d3b594                                 BlindBagCollection.CollectionSelector::UpdateCurrentBox
02d3b7f8: ldp     x20, x19, [sp, #0x10]                      
02d3b7fc: ldr     x30, [sp], #0x20                           
02d3b800: ret                                                
02d3b804: bl      #0x2b7105c                                 fn_2b7105c
## UnlockCurrentItemInBoxset() -> void
---- BlindBagCollection.CollectionSelector::UnlockCurrentItemInBoxset 0x2d373e4
02d373e4: ldr     x0, [x0, #0x58]                            ._currentBox
02d373e8: cbz     x0, #0x2d373f0                             
02d373ec: b       #0x2d39538                                 BlindBagCollection.CollectionBox::UnlockCurrentBox
02d373f0: ret                                                
## UpdateCurrentBox() -> void
---- BlindBagCollection.CollectionSelector::UpdateCurrentBox 0x2d3b594
02d3b594: str     d8, [sp, #-0x40]!                          
02d3b598: stp     x30, x23, [sp, #0x10]                      
02d3b59c: stp     x22, x21, [sp, #0x20]                      
02d3b5a0: stp     x20, x19, [sp, #0x30]                      
02d3b5a4: adrp    x20, #0x6630000                            
02d3b5a8: mov     x19, x0                                    
02d3b5ac: ldrb    w8, [x20, #0x14f]                          
02d3b5b0: tbnz    w8, #0, #0x2d3b5ec                         
02d3b5b4: adrp    x0, #0x626a000                             
02d3b5b8: ldr     x0, [x0, #0xcf8]                           MS:System.Collections.Generic.List`1::get_Count
02d3b5bc: bl      #0x2b70db0                                 fn_2b70db0
02d3b5c0: adrp    x0, #0x626a000                             
02d3b5c4: ldr     x0, [x0, #0xd00]                           MS:System.Collections.Generic.List`1::get_Item
02d3b5c8: bl      #0x2b70db0                                 fn_2b70db0
02d3b5cc: adrp    x0, #0x6266000                             
02d3b5d0: ldr     x0, [x0, #0x880]                           MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d3b5d4: bl      #0x2b70db0                                 fn_2b70db0
02d3b5d8: adrp    x0, #0x626a000                             
02d3b5dc: ldr     x0, [x0, #0xd08]                           MS:DG.Tweening.TweenSettingsExtensions::SetSpeedBased
02d3b5e0: bl      #0x2b70db0                                 fn_2b70db0
02d3b5e4: mov     w8, #1                                     
02d3b5e8: strb    w8, [x20, #0x14f]                          
02d3b5ec: ldr     x0, [x19, #0x28]                           ._collectionBoxes
02d3b5f0: cbz     x0, #0x2d3b704                             
02d3b5f4: adrp    x8, #0x626a000                             
02d3b5f8: ldr     x8, [x8, #0xd00]                           MS:System.Collections.Generic.List`1::get_Item
02d3b5fc: ldr     w1, [x19, #0x50]                           ._currentBoxIndex
02d3b600: ldr     x2, [x8]                                   T:type56879(k15)
02d3b604: bl      #0x35a8f3c                                 fn_35a8f3c
02d3b608: mov     x20, x19                                   
02d3b60c: mov     x1, x0                                     
02d3b610: str     x0, [x20, #0x58]!                          ._currentBox
02d3b614: mov     x0, x20                                    
02d3b618: bl      #0x2b70d54                                 fn_2b70d54
02d3b61c: ldur    x0, [x20, #-0x28]                          
02d3b620: cbz     x0, #0x2d3b704                             
02d3b624: mov     x1, xzr                                    
02d3b628: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d3b62c: cbz     x0, #0x2d3b704                             
02d3b630: ldr     w8, [x19, #0x50]                           ._currentBoxIndex
02d3b634: mov     x2, xzr                                    
02d3b638: cmp     w8, #0                                     
02d3b63c: cset    w1, gt                                     
02d3b640: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d3b644: ldr     x0, [x19, #0x38]                           ._nextButton
02d3b648: cbz     x0, #0x2d3b704                             
02d3b64c: mov     x1, xzr                                    
02d3b650: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d3b654: ldr     x8, [x19, #0x28]                           ._collectionBoxes
02d3b658: cbz     x8, #0x2d3b704                             
02d3b65c: cbz     x0, #0x2d3b704                             
02d3b660: ldr     w8, [x8, #0x18]                            MS:System.Collections.Generic.List`1::Add
02d3b664: ldr     w9, [x19, #0x50]                           ._currentBoxIndex
02d3b668: adrp    x22, #0x626a000                            
02d3b66c: adrp    x21, #0x6266000                            
02d3b670: ldr     x22, [x22, #0xd08]                         MS:DG.Tweening.TweenSettingsExtensions::SetSpeedBased
02d3b674: mov     x2, xzr                                    
02d3b678: sub     w8, w8, #1                                 
02d3b67c: ldr     x21, [x21, #0x880]                         MS:DG.Tweening.TweenSettingsExtensions::SetEase
02d3b680: cmp     w9, w8                                     
02d3b684: cset    w1, lt                                     
02d3b688: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d3b68c: mov     x20, x19                                   
02d3b690: ldr     x0, [x20, #0x60]!                          ._moveTween
02d3b694: ldur    w23, [x20, #-0x10]                         
02d3b698: ldur    s8, [x20, #-0x40]                          
02d3b69c: cbz     x0, #0x2d3b6ac                             
02d3b6a0: mov     w1, wzr                                    
02d3b6a4: mov     x2, xzr                                    
02d3b6a8: bl      #0x2d8fe94                                 DG.Tweening.TweenExtensions::Kill
02d3b6ac: neg     w8, w23                                    
02d3b6b0: ldr     x0, [x19, #0x40]                           ._pivot
02d3b6b4: ldr     s1, [x19, #0x24]                           ._moveSpeed
02d3b6b8: scvtf   s0, w8                                     
02d3b6bc: mov     w1, wzr                                    
02d3b6c0: mov     x2, xzr                                    
02d3b6c4: fmul    s0, s8, s0                                 
02d3b6c8: bl      #0x2d97eac                                 DG.Tweening.ShortcutExtensions::DOLocalMoveX
02d3b6cc: ldr     x2, [x22]                                  T:type56879(k15)
02d3b6d0: mov     w1, #1                                     
02d3b6d4: bl      #0x336ff88                                 fn_336ff88
02d3b6d8: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d3b6dc: mov     w1, #6                                     
02d3b6e0: bl      #0x336fa0c                                 fn_336fa0c
02d3b6e4: mov     x1, x0                                     
02d3b6e8: mov     x0, x20                                    
02d3b6ec: str     x1, [x19, #0x60]                           ._moveTween
02d3b6f0: ldp     x20, x19, [sp, #0x30]                      
02d3b6f4: ldp     x22, x21, [sp, #0x20]                      
02d3b6f8: ldp     x30, x23, [sp, #0x10]                      
02d3b6fc: ldr     d8, [sp], #0x40                            
02d3b700: b       #0x2b70d54                                 
02d3b704: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- BlindBagCollection.CollectionSelector::.ctor 0x2d3b808
02d3b808: adrp    x8, #0x1040000                             
02d3b80c: mov     x1, xzr                                    
02d3b810: ldr     d0, [x8, #0x820]                           [1040820]=41a0000041880000 f=17,20
02d3b814: str     d0, [x0, #0x20]                            ._boxSpacing
02d3b818: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
