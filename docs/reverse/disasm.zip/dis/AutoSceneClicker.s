#### CLASS AutoSceneClicker parent= UnityEngine.MonoBehaviour
## Start() -> void
---- AutoSceneClicker::Start 0x2cde3c4
02cde3c4: stp     x30, x19, [sp, #-0x10]!                    
02cde3c8: adrp    x19, #0x662f000                            
02cde3cc: ldrb    w8, [x19, #0xd8d]                          
02cde3d0: tbnz    w8, #0, #0x2cde3f4                         
02cde3d4: adrp    x0, #0x6267000                             
02cde3d8: ldr     x0, [x0, #0xbd0]                           MS:MonoSingleton`1::get_Instance
02cde3dc: bl      #0x2b70db0                                 fn_2b70db0
02cde3e0: adrp    x0, #0x6267000                             
02cde3e4: ldr     x0, [x0, #0xda0]                           MS:UIManager::ShowScreen
02cde3e8: bl      #0x2b70db0                                 fn_2b70db0
02cde3ec: mov     w8, #1                                     
02cde3f0: strb    w8, [x19, #0xd8d]                          
02cde3f4: mov     x0, xzr                                    
02cde3f8: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02cde3fc: cbz     x0, #0x2cde44c                             
02cde400: mov     x1, xzr                                    
02cde404: bl      #0x2d85084                                 Framework.AudioManager::StopAllMusic
02cde408: mov     x0, xzr                                    
02cde40c: bl      #0x2d6eec8                                 Framework.AudioManager::get_Instance
02cde410: cbz     x0, #0x2cde44c                             
02cde414: fmov    s0, #1.00000000                            
02cde418: adrp    x19, #0x6267000                            
02cde41c: mov     w1, #4                                     
02cde420: ldr     x19, [x19, #0xbd0]                         MS:MonoSingleton`1::get_Instance
02cde424: mov     x2, xzr                                    
02cde428: bl      #0x2d846d8                                 Framework.AudioManager::PlayMusic
02cde42c: ldr     x0, [x19]                                  S:'didu'
02cde430: bl      #0x3769600                                 fn_3769600
02cde434: cbz     x0, #0x2cde44c                             
02cde438: adrp    x8, #0x6267000                             
02cde43c: ldr     x8, [x8, #0xda0]                           MS:UIManager::ShowScreen
02cde440: ldr     x1, [x8]                                   S:'didu'
02cde444: ldp     x30, x19, [sp], #0x10                      
02cde448: b       #0x33fc0e8                                 
02cde44c: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- AutoSceneClicker::.ctor 0x2cde450
02cde450: mov     x1, xzr                                    
02cde454: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
