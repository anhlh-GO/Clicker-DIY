#### CLASS GameData/<ProcessData>d__8 parent= object
#   field <>1__state                     int                                                off=0x10 attr=1 
#   field <>2__current                   object                                             off=0x18 attr=1 
## .ctor(int <>1__state) -> void
---- GameData/<ProcessData>d__8::.ctor 0x2cac7c4
02cac7c4: str     x30, [sp, #-0x20]!                         
02cac7c8: stp     x20, x19, [sp, #0x10]                      
02cac7cc: mov     w19, w1                                    
02cac7d0: mov     x1, xzr                                    
02cac7d4: mov     x20, x0                                    
02cac7d8: bl      #0x4e53e9c                                 System.Object::.ctor
02cac7dc: str     w19, [x20, #0x10]                          .<>1__state
02cac7e0: ldp     x20, x19, [sp, #0x10]                      
02cac7e4: ldr     x30, [sp], #0x20                           
02cac7e8: ret                                                
## System.IDisposable.Dispose() -> void
---- GameData/<ProcessData>d__8::System.IDisposable.Dispose 0x2cac814
02cac814: ret                                                
## MoveNext() -> bool
---- GameData/<ProcessData>d__8::MoveNext 0x2cac818
02cac818: str     x30, [sp, #-0x20]!                         
02cac81c: stp     x20, x19, [sp, #0x10]                      
02cac820: ldr     w20, [x0, #0x10]                           .<>1__state
02cac824: mov     x19, x0                                    
02cac828: cbz     w20, #0x2cac83c                            
02cac82c: cmp     w20, #1                                    
02cac830: b.ne    #0x2cac85c                                 
02cac834: mov     w8, #-1                                    
02cac838: b       #0x2cac858                                 
02cac83c: mov     x0, x19                                    
02cac840: mov     w8, #-1                                    
02cac844: mov     x1, xzr                                    
02cac848: str     xzr, [x0, #0x18]!                          .<>2__current
02cac84c: stur    w8, [x0, #-8]                              
02cac850: bl      #0x2b70d54                                 fn_2b70d54
02cac854: mov     w8, #1                                     
02cac858: str     w8, [x19, #0x10]                           .<>1__state
02cac85c: cmp     w20, #0                                    
02cac860: ldp     x20, x19, [sp, #0x10]                      
02cac864: cset    w0, eq                                     
02cac868: ldr     x30, [sp], #0x20                           
02cac86c: ret                                                
## System.Collections.Generic.IEnumerator<System.Object>.get_Current() -> object
---- GameData/<ProcessData>d__8::System.Collections.Generic.IEnumerator<System.Object>.get_Current 0x2cac870
02cac870: ldr     x0, [x0, #0x18]                            .<>2__current
02cac874: ret                                                
## System.Collections.IEnumerator.Reset() -> void
---- GameData/<ProcessData>d__8::System.Collections.IEnumerator.Reset 0x2cac878
02cac878: stp     x30, x19, [sp, #-0x10]!                    
02cac87c: adrp    x0, #0x6264000                             
02cac880: ldr     x0, [x0, #0xf60]                           T:System.NotSupportedException
02cac884: bl      #0x2b70dc4                                 fn_2b70dc4
02cac888: bl      #0x2b7104c                                 fn_2b7104c
02cac88c: mov     x1, xzr                                    
02cac890: mov     x19, x0                                    
02cac894: bl      #0x4e14238                                 System.NotSupportedException::.ctor
02cac898: adrp    x0, #0x6266000                             
02cac89c: ldr     x0, [x0, #0x860]                           M:GameData/<ProcessData>d__8::System.Collections.IEnumerator.Reset
02cac8a0: bl      #0x2b70dc4                                 fn_2b70dc4
02cac8a4: mov     x1, x0                                     
02cac8a8: mov     x0, x19                                    
02cac8ac: bl      #0x2b70f20                                 fn_2b70f20
## System.Collections.IEnumerator.get_Current() -> object
---- GameData/<ProcessData>d__8::System.Collections.IEnumerator.get_Current 0x2cac8b0
02cac8b0: ldr     x0, [x0, #0x18]                            .<>2__current
02cac8b4: ret                                                
#### CLASS GameData parent= UnityEngine.MonoBehaviour
## Initiate() -> void
---- GameData::Initiate 0x2cac6dc
02cac6dc: ret                                                
## NewData() -> void
---- GameData::NewData 0x2cac6e0
02cac6e0: ret                                                
## UpdateData() -> void
---- GameData::UpdateData 0x2cac6e4
02cac6e4: ret                                                
## Delete() -> void
---- GameData::Delete 0x2cac6e8
02cac6e8: ret                                                
## SaveData() -> void
---- GameData::SaveData 0x2cac6ec
02cac6ec: ret                                                
## LoadData() -> void
---- GameData::LoadData 0x2cac6f0
02cac6f0: ret                                                
## HasData() -> bool
---- GameData::HasData 0x2cac6f4
02cac6f4: stp     x30, x21, [sp, #-0x20]!                    
02cac6f8: stp     x20, x19, [sp, #0x10]                      
02cac6fc: adrp    x20, #0x662f000                            
02cac700: adrp    x21, #0x6266000                            
02cac704: mov     x19, x0                                    
02cac708: ldrb    w8, [x20, #0xb33]                          
02cac70c: ldr     x21, [x21, #0x658]                         MS:MonoSingleton`1::get_Instance
02cac710: tbnz    w8, #0, #0x2cac728                         
02cac714: adrp    x0, #0x6266000                             
02cac718: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02cac71c: bl      #0x2b70db0                                 fn_2b70db0
02cac720: mov     w8, #1                                     
02cac724: strb    w8, [x20, #0xb33]                          
02cac728: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cac72c: bl      #0x3769600                                 fn_3769600
02cac730: ldr     x8, [x19]                                  
02cac734: mov     x20, x0                                    
02cac738: mov     x0, x19                                    
02cac73c: ldr     x9, [x8, #0x2a8]                           
02cac740: ldr     x1, [x8, #0x2b0]                           
02cac744: blr     x9                                         
02cac748: cbz     x20, #0x2cac760                            
02cac74c: mov     x1, x0                                     
02cac750: mov     x0, x20                                    
02cac754: ldp     x20, x19, [sp, #0x10]                      
02cac758: ldp     x30, x21, [sp], #0x20                      
02cac75c: b       #0x2caa69c                                 DataManager::HasData
02cac760: bl      #0x2b7105c                                 fn_2b7105c
## HasUpdateData() -> bool
---- GameData::HasUpdateData 0x2cac764
02cac764: mov     w0, wzr                                    
02cac768: ret                                                
## ProcessData() -> System.Collections.IEnumerator
---- GameData::ProcessData 0x2cac76c
02cac76c: str     x30, [sp, #-0x20]!                         
02cac770: stp     x20, x19, [sp, #0x10]                      
02cac774: adrp    x19, #0x662f000                            
02cac778: adrp    x20, #0x6266000                            
02cac77c: ldrb    w8, [x19, #0xb34]                          
02cac780: ldr     x20, [x20, #0x858]                         T:GameData/<ProcessData>d__8
02cac784: tbnz    w8, #0, #0x2cac79c                         
02cac788: adrp    x0, #0x6266000                             
02cac78c: ldr     x0, [x0, #0x858]                           T:GameData/<ProcessData>d__8
02cac790: bl      #0x2b70db0                                 fn_2b70db0
02cac794: mov     w8, #1                                     
02cac798: strb    w8, [x19, #0xb34]                          
02cac79c: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cac7a0: bl      #0x2b7104c                                 fn_2b7104c
02cac7a4: mov     x1, xzr                                    
02cac7a8: mov     x19, x0                                    
02cac7ac: bl      #0x4e53e9c                                 System.Object::.ctor
02cac7b0: mov     x0, x19                                    
02cac7b4: str     wzr, [x19, #0x10]                          
02cac7b8: ldp     x20, x19, [sp, #0x10]                      
02cac7bc: ldr     x30, [sp], #0x20                           
02cac7c0: ret                                                
## GetName() -> string
---- GameData::GetName 0x2cac7ec
02cac7ec: str     x30, [sp, #-0x10]!                         
02cac7f0: mov     x1, xzr                                    
02cac7f4: bl      #0x4e54610                                 System.Object::GetType
02cac7f8: cbz     x0, #0x2cac810                             
02cac7fc: ldr     x8, [x0]                                   
02cac800: ldr     x1, [x8, #0x300]                           
02cac804: ldr     x2, [x8, #0x2f8]                           
02cac808: ldr     x30, [sp], #0x10                           
02cac80c: br      x2                                         
02cac810: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- GameData::.ctor 0x2ca9988
02ca9988: mov     x1, xzr                                    
02ca998c: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
