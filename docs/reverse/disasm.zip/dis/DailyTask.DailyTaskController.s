#### CLASS DailyTask.DailyTaskController/<>c__DisplayClass23_0 parent= object
#   field taskId                         int                                                off=0x10 attr=6 
## .ctor() -> void
---- DailyTask.DailyTaskController/<>c__DisplayClass23_0::.ctor 0x2d2b094
02d2b094: mov     x1, xzr                                    
02d2b098: b       #0x4e53e9c                                 System.Object::.ctor
## <CompleteTask>b__0(DailyTask.DataDailyTask/TaskProgress task) -> bool
---- DailyTask.DailyTaskController/<>c__DisplayClass23_0::<CompleteTask>b__0 0x2d2bc04
02d2bc04: cbz     x1, #0x2d2bc1c                             
02d2bc08: ldr     w8, [x1, #0x10]                            
02d2bc0c: ldr     w9, [x0, #0x10]                            .taskId
02d2bc10: cmp     w8, w9                                     
02d2bc14: cset    w0, eq                                     
02d2bc18: ret                                                
02d2bc1c: str     x30, [sp, #-0x10]!                         
02d2bc20: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS DailyTask.DailyTaskController/<>c__DisplayClass24_0 parent= object
#   field taskId                         int                                                off=0x10 attr=6 
## .ctor() -> void
---- DailyTask.DailyTaskController/<>c__DisplayClass24_0::.ctor 0x2d2b264
02d2b264: mov     x1, xzr                                    
02d2b268: b       #0x4e53e9c                                 System.Object::.ctor
## <ProgressTask>b__0(DailyTask.DataDailyTask/TaskProgress task) -> bool
---- DailyTask.DailyTaskController/<>c__DisplayClass24_0::<ProgressTask>b__0 0x2d2bc24
02d2bc24: cbz     x1, #0x2d2bc3c                             
02d2bc28: ldr     w8, [x1, #0x10]                            
02d2bc2c: ldr     w9, [x0, #0x10]                            .taskId
02d2bc30: cmp     w8, w9                                     
02d2bc34: cset    w0, eq                                     
02d2bc38: ret                                                
02d2bc3c: str     x30, [sp, #-0x10]!                         
02d2bc40: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS DailyTask.DailyTaskController/<>c__DisplayClass26_0 parent= object
#   field taskId                         int                                                off=0x10 attr=6 
## .ctor() -> void
---- DailyTask.DailyTaskController/<>c__DisplayClass26_0::.ctor 0x2d2b6f4
02d2b6f4: mov     x1, xzr                                    
02d2b6f8: b       #0x4e53e9c                                 System.Object::.ctor
## <IsTaskClaimable>b__0(DailyTask.DataDailyTask/TaskProgress task) -> bool
---- DailyTask.DailyTaskController/<>c__DisplayClass26_0::<IsTaskClaimable>b__0 0x2d2bc44
02d2bc44: cbz     x1, #0x2d2bc5c                             
02d2bc48: ldr     w8, [x1, #0x10]                            
02d2bc4c: ldr     w9, [x0, #0x10]                            .taskId
02d2bc50: cmp     w8, w9                                     
02d2bc54: cset    w0, eq                                     
02d2bc58: ret                                                
02d2bc5c: str     x30, [sp, #-0x10]!                         
02d2bc60: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS DailyTask.DailyTaskController/<>c__DisplayClass28_0 parent= object
#   field taskId                         int                                                off=0x10 attr=6 
## .ctor() -> void
---- DailyTask.DailyTaskController/<>c__DisplayClass28_0::.ctor 0x2d2ba04
02d2ba04: mov     x1, xzr                                    
02d2ba08: b       #0x4e53e9c                                 System.Object::.ctor
## <GetRewardForTask>b__0(DailyTask.DataDailyTask/TaskProgress task) -> bool
---- DailyTask.DailyTaskController/<>c__DisplayClass28_0::<GetRewardForTask>b__0 0x2d2bc64
02d2bc64: cbz     x1, #0x2d2bc7c                             
02d2bc68: ldr     w8, [x1, #0x10]                            
02d2bc6c: ldr     w9, [x0, #0x10]                            .taskId
02d2bc70: cmp     w8, w9                                     
02d2bc74: cset    w0, eq                                     
02d2bc78: ret                                                
02d2bc7c: str     x30, [sp, #-0x10]!                         
02d2bc80: bl      #0x2b7105c                                 fn_2b7105c
#### CLASS DailyTask.DailyTaskController parent= MonoSingleton`1<DailyTask.DailyTaskController>
#   field OnAllTasksCompleted            UnityEngine.Events.UnityAction                     off=0x20 attr=1 CompilerGeneratedAttribute
#   field OnTaskCompleted                UnityEngine.Events.UnityAction`1<int>              off=0x28 attr=1 CompilerGeneratedAttribute
#   field OnTaskProgressed               UnityEngine.Events.UnityAction`1<int>              off=0x30 attr=1 CompilerGeneratedAttribute
#   field MISSIONS_PER_DAY               int                                                off=0x0 attr=8051 
#   field _dataDailyTask                 DailyTask.DataDailyTask                            off=0x38 attr=1 
#   field _dailyTaskSO                   DailyTask.DailyTaskSO                              off=0x40 attr=1 
#   field _currentDailyTasks             System.Collections.Generic.List`1<DailyTask.DataDailyTask/TaskProgress> off=0x48 attr=1 
## add_OnAllTasksCompleted(UnityEngine.Events.UnityAction value) -> void
---- DailyTask.DailyTaskController::add_OnAllTasksCompleted 0x2d29b24
02d29b24: str     x30, [sp, #-0x30]!                         
02d29b28: stp     x22, x21, [sp, #0x10]                      
02d29b2c: stp     x20, x19, [sp, #0x20]                      
02d29b30: adrp    x21, #0x6630000                            
02d29b34: mov     x19, x1                                    
02d29b38: mov     x20, x0                                    
02d29b3c: ldrb    w8, [x21, #0xa9]                           
02d29b40: tbnz    w8, #0, #0x2d29b58                         
02d29b44: adrp    x0, #0x6265000                             
02d29b48: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d29b4c: bl      #0x2b70db0                                 fn_2b70db0
02d29b50: mov     w8, #1                                     
02d29b54: strb    w8, [x21, #0xa9]                           
02d29b58: adrp    x22, #0x6265000                            
02d29b5c: ldr     x22, [x22, #0x3f0]                         T:UnityEngine.Events.UnityAction
02d29b60: ldr     x21, [x20, #0x20]!                         .OnAllTasksCompleted
02d29b64: mov     x0, x21                                    
02d29b68: mov     x1, x19                                    
02d29b6c: mov     x2, xzr                                    
02d29b70: bl      #0x4e570ac                                 System.Delegate::Combine
02d29b74: mov     x8, x0                                     
02d29b78: cbz     x0, #0x2d29b8c                             
02d29b7c: ldr     x1, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d29b80: ldr     x9, [x8]                                   
02d29b84: cmp     x9, x1                                     
02d29b88: b.ne    #0x2d29bb8                                 
02d29b8c: mov     x0, x20                                    
02d29b90: mov     x1, x8                                     
02d29b94: mov     x2, x21                                    
02d29b98: bl      #0x2ba9880                                 fn_2ba9880
02d29b9c: cmp     x0, x21                                    
02d29ba0: mov     x21, x0                                    
02d29ba4: b.ne    #0x2d29b64                                 
02d29ba8: ldp     x20, x19, [sp, #0x20]                      
02d29bac: ldp     x22, x21, [sp, #0x10]                      
02d29bb0: ldr     x30, [sp], #0x30                           
02d29bb4: ret                                                
02d29bb8: mov     x0, x8                                     
02d29bbc: bl      #0x2b713dc                                 fn_2b713dc
## remove_OnAllTasksCompleted(UnityEngine.Events.UnityAction value) -> void
---- DailyTask.DailyTaskController::remove_OnAllTasksCompleted 0x2d29bc0
02d29bc0: str     x30, [sp, #-0x30]!                         
02d29bc4: stp     x22, x21, [sp, #0x10]                      
02d29bc8: stp     x20, x19, [sp, #0x20]                      
02d29bcc: adrp    x21, #0x6630000                            
02d29bd0: mov     x19, x1                                    
02d29bd4: mov     x20, x0                                    
02d29bd8: ldrb    w8, [x21, #0xaa]                           
02d29bdc: tbnz    w8, #0, #0x2d29bf4                         
02d29be0: adrp    x0, #0x6265000                             
02d29be4: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d29be8: bl      #0x2b70db0                                 fn_2b70db0
02d29bec: mov     w8, #1                                     
02d29bf0: strb    w8, [x21, #0xaa]                           
02d29bf4: adrp    x22, #0x6265000                            
02d29bf8: ldr     x22, [x22, #0x3f0]                         T:UnityEngine.Events.UnityAction
02d29bfc: ldr     x21, [x20, #0x20]!                         .OnAllTasksCompleted
02d29c00: mov     x0, x21                                    
02d29c04: mov     x1, x19                                    
02d29c08: mov     x2, xzr                                    
02d29c0c: bl      #0x4e57298                                 System.Delegate::Remove
02d29c10: mov     x8, x0                                     
02d29c14: cbz     x0, #0x2d29c28                             
02d29c18: ldr     x1, [x22]                                  M:AdsManager::<OnApplicationPause>b__26_0
02d29c1c: ldr     x9, [x8]                                   
02d29c20: cmp     x9, x1                                     
02d29c24: b.ne    #0x2d29c54                                 
02d29c28: mov     x0, x20                                    
02d29c2c: mov     x1, x8                                     
02d29c30: mov     x2, x21                                    
02d29c34: bl      #0x2ba9880                                 fn_2ba9880
02d29c38: cmp     x0, x21                                    
02d29c3c: mov     x21, x0                                    
02d29c40: b.ne    #0x2d29c00                                 
02d29c44: ldp     x20, x19, [sp, #0x20]                      
02d29c48: ldp     x22, x21, [sp, #0x10]                      
02d29c4c: ldr     x30, [sp], #0x30                           
02d29c50: ret                                                
02d29c54: mov     x0, x8                                     
02d29c58: bl      #0x2b713dc                                 fn_2b713dc
## add_OnTaskCompleted(UnityEngine.Events.UnityAction`1<int> value) -> void
---- DailyTask.DailyTaskController::add_OnTaskCompleted 0x2d29c5c
02d29c5c: str     x30, [sp, #-0x40]!                         
02d29c60: stp     x24, x23, [sp, #0x10]                      
02d29c64: stp     x22, x21, [sp, #0x20]                      
02d29c68: stp     x20, x19, [sp, #0x30]                      
02d29c6c: adrp    x21, #0x6630000                            
02d29c70: mov     x19, x1                                    
02d29c74: mov     x20, x0                                    
02d29c78: ldrb    w8, [x21, #0xab]                           
02d29c7c: tbnz    w8, #0, #0x2d29c94                         
02d29c80: adrp    x0, #0x6269000                             
02d29c84: ldr     x0, [x0, #0xa68]                           T:type19683(k15)
02d29c88: bl      #0x2b70db0                                 fn_2b70db0
02d29c8c: mov     w8, #1                                     
02d29c90: strb    w8, [x21, #0xab]                           
02d29c94: adrp    x24, #0x6269000                            
02d29c98: ldr     x24, [x24, #0xa68]                         T:type19683(k15)
02d29c9c: ldr     x21, [x20, #0x28]!                         .OnTaskCompleted
02d29ca0: mov     x0, x21                                    
02d29ca4: mov     x1, x19                                    
02d29ca8: mov     x2, xzr                                    
02d29cac: bl      #0x4e570ac                                 System.Delegate::Combine
02d29cb0: cbz     x0, #0x2d29cd0                             
02d29cb4: ldr     x23, [x24]                                 T:Trading.TradingSession/<>c__DisplayClass56_0
02d29cb8: mov     x22, x0                                    
02d29cbc: mov     x1, x23                                    
02d29cc0: bl      #0x2b70f34                                 fn_2b70f34
02d29cc4: mov     x1, x0                                     
02d29cc8: cbnz    x0, #0x2d29cd4                             
02d29ccc: b       #0x2d29d00                                 
02d29cd0: mov     x1, xzr                                    
02d29cd4: mov     x0, x20                                    
02d29cd8: mov     x2, x21                                    
02d29cdc: bl      #0x2ba9880                                 fn_2ba9880
02d29ce0: cmp     x0, x21                                    
02d29ce4: mov     x21, x0                                    
02d29ce8: b.ne    #0x2d29ca0                                 
02d29cec: ldp     x20, x19, [sp, #0x30]                      
02d29cf0: ldp     x22, x21, [sp, #0x20]                      
02d29cf4: ldp     x24, x23, [sp, #0x10]                      
02d29cf8: ldr     x30, [sp], #0x40                           
02d29cfc: ret                                                
02d29d00: mov     x0, x22                                    
02d29d04: mov     x1, x23                                    
02d29d08: bl      #0x2b713dc                                 fn_2b713dc
## remove_OnTaskCompleted(UnityEngine.Events.UnityAction`1<int> value) -> void
---- DailyTask.DailyTaskController::remove_OnTaskCompleted 0x2d29d0c
02d29d0c: str     x30, [sp, #-0x40]!                         
02d29d10: stp     x24, x23, [sp, #0x10]                      
02d29d14: stp     x22, x21, [sp, #0x20]                      
02d29d18: stp     x20, x19, [sp, #0x30]                      
02d29d1c: adrp    x21, #0x6630000                            
02d29d20: mov     x19, x1                                    
02d29d24: mov     x20, x0                                    
02d29d28: ldrb    w8, [x21, #0xac]                           
02d29d2c: tbnz    w8, #0, #0x2d29d44                         
02d29d30: adrp    x0, #0x6269000                             
02d29d34: ldr     x0, [x0, #0xa68]                           T:type19683(k15)
02d29d38: bl      #0x2b70db0                                 fn_2b70db0
02d29d3c: mov     w8, #1                                     
02d29d40: strb    w8, [x21, #0xac]                           
02d29d44: adrp    x24, #0x6269000                            
02d29d48: ldr     x24, [x24, #0xa68]                         T:type19683(k15)
02d29d4c: ldr     x21, [x20, #0x28]!                         .OnTaskCompleted
02d29d50: mov     x0, x21                                    
02d29d54: mov     x1, x19                                    
02d29d58: mov     x2, xzr                                    
02d29d5c: bl      #0x4e57298                                 System.Delegate::Remove
02d29d60: cbz     x0, #0x2d29d80                             
02d29d64: ldr     x23, [x24]                                 T:Trading.TradingSession/<>c__DisplayClass56_0
02d29d68: mov     x22, x0                                    
02d29d6c: mov     x1, x23                                    
02d29d70: bl      #0x2b70f34                                 fn_2b70f34
02d29d74: mov     x1, x0                                     
02d29d78: cbnz    x0, #0x2d29d84                             
02d29d7c: b       #0x2d29db0                                 
02d29d80: mov     x1, xzr                                    
02d29d84: mov     x0, x20                                    
02d29d88: mov     x2, x21                                    
02d29d8c: bl      #0x2ba9880                                 fn_2ba9880
02d29d90: cmp     x0, x21                                    
02d29d94: mov     x21, x0                                    
02d29d98: b.ne    #0x2d29d50                                 
02d29d9c: ldp     x20, x19, [sp, #0x30]                      
02d29da0: ldp     x22, x21, [sp, #0x20]                      
02d29da4: ldp     x24, x23, [sp, #0x10]                      
02d29da8: ldr     x30, [sp], #0x40                           
02d29dac: ret                                                
02d29db0: mov     x0, x22                                    
02d29db4: mov     x1, x23                                    
02d29db8: bl      #0x2b713dc                                 fn_2b713dc
## add_OnTaskProgressed(UnityEngine.Events.UnityAction`1<int> value) -> void
---- DailyTask.DailyTaskController::add_OnTaskProgressed 0x2d29dbc
02d29dbc: str     x30, [sp, #-0x40]!                         
02d29dc0: stp     x24, x23, [sp, #0x10]                      
02d29dc4: stp     x22, x21, [sp, #0x20]                      
02d29dc8: stp     x20, x19, [sp, #0x30]                      
02d29dcc: adrp    x21, #0x6630000                            
02d29dd0: mov     x19, x1                                    
02d29dd4: mov     x20, x0                                    
02d29dd8: ldrb    w8, [x21, #0xad]                           
02d29ddc: tbnz    w8, #0, #0x2d29df4                         
02d29de0: adrp    x0, #0x6269000                             
02d29de4: ldr     x0, [x0, #0xa68]                           T:type19683(k15)
02d29de8: bl      #0x2b70db0                                 fn_2b70db0
02d29dec: mov     w8, #1                                     
02d29df0: strb    w8, [x21, #0xad]                           
02d29df4: adrp    x24, #0x6269000                            
02d29df8: ldr     x24, [x24, #0xa68]                         T:type19683(k15)
02d29dfc: ldr     x21, [x20, #0x30]!                         .OnTaskProgressed
02d29e00: mov     x0, x21                                    
02d29e04: mov     x1, x19                                    
02d29e08: mov     x2, xzr                                    
02d29e0c: bl      #0x4e570ac                                 System.Delegate::Combine
02d29e10: cbz     x0, #0x2d29e30                             
02d29e14: ldr     x23, [x24]                                 T:Trading.TradingSession/<>c__DisplayClass56_0
02d29e18: mov     x22, x0                                    
02d29e1c: mov     x1, x23                                    
02d29e20: bl      #0x2b70f34                                 fn_2b70f34
02d29e24: mov     x1, x0                                     
02d29e28: cbnz    x0, #0x2d29e34                             
02d29e2c: b       #0x2d29e60                                 
02d29e30: mov     x1, xzr                                    
02d29e34: mov     x0, x20                                    
02d29e38: mov     x2, x21                                    
02d29e3c: bl      #0x2ba9880                                 fn_2ba9880
02d29e40: cmp     x0, x21                                    
02d29e44: mov     x21, x0                                    
02d29e48: b.ne    #0x2d29e00                                 
02d29e4c: ldp     x20, x19, [sp, #0x30]                      
02d29e50: ldp     x22, x21, [sp, #0x20]                      
02d29e54: ldp     x24, x23, [sp, #0x10]                      
02d29e58: ldr     x30, [sp], #0x40                           
02d29e5c: ret                                                
02d29e60: mov     x0, x22                                    
02d29e64: mov     x1, x23                                    
02d29e68: bl      #0x2b713dc                                 fn_2b713dc
## remove_OnTaskProgressed(UnityEngine.Events.UnityAction`1<int> value) -> void
---- DailyTask.DailyTaskController::remove_OnTaskProgressed 0x2d29e6c
02d29e6c: str     x30, [sp, #-0x40]!                         
02d29e70: stp     x24, x23, [sp, #0x10]                      
02d29e74: stp     x22, x21, [sp, #0x20]                      
02d29e78: stp     x20, x19, [sp, #0x30]                      
02d29e7c: adrp    x21, #0x6630000                            
02d29e80: mov     x19, x1                                    
02d29e84: mov     x20, x0                                    
02d29e88: ldrb    w8, [x21, #0xae]                           
02d29e8c: tbnz    w8, #0, #0x2d29ea4                         
02d29e90: adrp    x0, #0x6269000                             
02d29e94: ldr     x0, [x0, #0xa68]                           T:type19683(k15)
02d29e98: bl      #0x2b70db0                                 fn_2b70db0
02d29e9c: mov     w8, #1                                     
02d29ea0: strb    w8, [x21, #0xae]                           
02d29ea4: adrp    x24, #0x6269000                            
02d29ea8: ldr     x24, [x24, #0xa68]                         T:type19683(k15)
02d29eac: ldr     x21, [x20, #0x30]!                         .OnTaskProgressed
02d29eb0: mov     x0, x21                                    
02d29eb4: mov     x1, x19                                    
02d29eb8: mov     x2, xzr                                    
02d29ebc: bl      #0x4e57298                                 System.Delegate::Remove
02d29ec0: cbz     x0, #0x2d29ee0                             
02d29ec4: ldr     x23, [x24]                                 T:Trading.TradingSession/<>c__DisplayClass56_0
02d29ec8: mov     x22, x0                                    
02d29ecc: mov     x1, x23                                    
02d29ed0: bl      #0x2b70f34                                 fn_2b70f34
02d29ed4: mov     x1, x0                                     
02d29ed8: cbnz    x0, #0x2d29ee4                             
02d29edc: b       #0x2d29f10                                 
02d29ee0: mov     x1, xzr                                    
02d29ee4: mov     x0, x20                                    
02d29ee8: mov     x2, x21                                    
02d29eec: bl      #0x2ba9880                                 fn_2ba9880
02d29ef0: cmp     x0, x21                                    
02d29ef4: mov     x21, x0                                    
02d29ef8: b.ne    #0x2d29eb0                                 
02d29efc: ldp     x20, x19, [sp, #0x30]                      
02d29f00: ldp     x22, x21, [sp, #0x20]                      
02d29f04: ldp     x24, x23, [sp, #0x10]                      
02d29f08: ldr     x30, [sp], #0x40                           
02d29f0c: ret                                                
02d29f10: mov     x0, x22                                    
02d29f14: mov     x1, x23                                    
02d29f18: bl      #0x2b713dc                                 fn_2b713dc
## get_DataDailyTask() -> DailyTask.DataDailyTask
---- DailyTask.DailyTaskController::get_DataDailyTask 0x2d29f1c
02d29f1c: ldr     x0, [x0, #0x38]                            ._dataDailyTask
02d29f20: ret                                                
## get_DailyTaskSO() -> DailyTask.DailyTaskSO
---- DailyTask.DailyTaskController::get_DailyTaskSO 0x2d29f24
02d29f24: ldr     x0, [x0, #0x40]                            ._dailyTaskSO
02d29f28: ret                                                
## get_CurrentDailyTasks() -> System.Collections.Generic.List`1<DailyTask.DataDailyTask/TaskProgress>
---- DailyTask.DailyTaskController::get_CurrentDailyTasks 0x2d29f2c
02d29f2c: ldr     x0, [x0, #0x48]                            ._currentDailyTasks
02d29f30: ret                                                
## Start() -> void
---- DailyTask.DailyTaskController::Start 0x2d29f34
02d29f34: stp     x30, x21, [sp, #-0x20]!                    
02d29f38: stp     x20, x19, [sp, #0x10]                      
02d29f3c: adrp    x21, #0x6630000                            
02d29f40: adrp    x20, #0x6266000                            
02d29f44: mov     x19, x0                                    
02d29f48: ldrb    w8, [x21, #0xaf]                           
02d29f4c: ldr     x20, [x20, #0x658]                         MS:MonoSingleton`1::get_Instance
02d29f50: tbnz    w8, #0, #0x2d29f80                         
02d29f54: adrp    x0, #0x626a000                             
02d29f58: ldr     x0, [x0, #0x2b8]                           MS:DataManager::GetAsset
02d29f5c: bl      #0x2b70db0                                 fn_2b70db0
02d29f60: adrp    x0, #0x626a000                             
02d29f64: ldr     x0, [x0, #0x2c0]                           MS:DataManager::GetData
02d29f68: bl      #0x2b70db0                                 fn_2b70db0
02d29f6c: adrp    x0, #0x6266000                             
02d29f70: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02d29f74: bl      #0x2b70db0                                 fn_2b70db0
02d29f78: mov     w8, #1                                     
02d29f7c: strb    w8, [x21, #0xaf]                           
02d29f80: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d29f84: bl      #0x3769600                                 fn_3769600
02d29f88: cbz     x0, #0x2d29ff0                             
02d29f8c: adrp    x8, #0x626a000                             
02d29f90: ldr     x8, [x8, #0x2b8]                           MS:DataManager::GetAsset
02d29f94: ldr     x1, [x8]                                   T:type56879(k15)
02d29f98: bl      #0x3168af0                                 fn_3168af0
02d29f9c: mov     x1, x0                                     
02d29fa0: mov     x0, x19                                    
02d29fa4: str     x1, [x0, #0x40]!                           ._dailyTaskSO
02d29fa8: bl      #0x2b70d54                                 fn_2b70d54
02d29fac: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d29fb0: bl      #0x3769600                                 fn_3769600
02d29fb4: cbz     x0, #0x2d29ff0                             
02d29fb8: adrp    x8, #0x626a000                             
02d29fbc: ldr     x8, [x8, #0x2c0]                           MS:DataManager::GetData
02d29fc0: ldr     x1, [x8]                                   T:type56879(k15)
02d29fc4: bl      #0x3168dd0                                 fn_3168dd0
02d29fc8: mov     x1, x0                                     
02d29fcc: mov     x0, x19                                    
02d29fd0: str     x1, [x0, #0x38]!                           ._dataDailyTask
02d29fd4: bl      #0x2b70d54                                 fn_2b70d54
02d29fd8: mov     x0, x19                                    
02d29fdc: bl      #0x2d29ff4                                 DailyTask.DailyTaskController::CheckValidTask
02d29fe0: mov     x0, x19                                    
02d29fe4: ldp     x20, x19, [sp, #0x10]                      
02d29fe8: ldp     x30, x21, [sp], #0x20                      
02d29fec: b       #0x2d2a024                                 DailyTask.DailyTaskController::CheckForNewDay
02d29ff0: bl      #0x2b7105c                                 fn_2b7105c
## CheckValidTask() -> void
---- DailyTask.DailyTaskController::CheckValidTask 0x2d29ff4
02d29ff4: stp     x30, x19, [sp, #-0x10]!                    
02d29ff8: mov     x19, x0                                    
02d29ffc: ldr     x0, [x0, #0x38]                            ._dataDailyTask
02d2a000: cbz     x0, #0x2d2a020                             
02d2a004: bl      #0x2d2a168                                 DailyTask.DataDailyTask::IsTaskTodayHaveSomethingWrong
02d2a008: tbz     w0, #0, #0x2d2a018                         
02d2a00c: mov     x0, x19                                    
02d2a010: ldp     x30, x19, [sp], #0x10                      
02d2a014: b       #0x2d2a38c                                 DailyTask.DailyTaskController::GenerateNewDailyMissions
02d2a018: ldp     x30, x19, [sp], #0x10                      
02d2a01c: ret                                                
02d2a020: bl      #0x2b7105c                                 fn_2b7105c
## CheckForNewDay() -> void
---- DailyTask.DailyTaskController::CheckForNewDay 0x2d2a024
02d2a024: sub     sp, sp, #0x30                              
02d2a028: stp     x30, x21, [sp, #0x10]                      
02d2a02c: stp     x20, x19, [sp, #0x20]                      
02d2a030: adrp    x20, #0x6630000                            
02d2a034: mov     x19, x0                                    
02d2a038: ldrb    w8, [x20, #0xb0]                           
02d2a03c: tbnz    w8, #0, #0x2d2a078                         
02d2a040: adrp    x0, #0x6266000                             
02d2a044: ldr     x0, [x0, #0x128]                           T:System.DateTime
02d2a048: bl      #0x2b70db0                                 fn_2b70db0
02d2a04c: adrp    x0, #0x6263000                             
02d2a050: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02d2a054: bl      #0x2b70db0                                 fn_2b70db0
02d2a058: adrp    x0, #0x626a000                             
02d2a05c: ldr     x0, [x0, #0x2c8]                           S:'🎉 A new day has started! Generating new Tasks.'
02d2a060: bl      #0x2b70db0                                 fn_2b70db0
02d2a064: adrp    x0, #0x626a000                             
02d2a068: ldr     x0, [x0, #0x2d0]                           S:"Welcome back! Loading today's missions."
02d2a06c: bl      #0x2b70db0                                 fn_2b70db0
02d2a070: mov     w8, #1                                     
02d2a074: strb    w8, [x20, #0xb0]                           
02d2a078: ldr     x0, [x19, #0x38]                           ._dataDailyTask
02d2a07c: str     xzr, [sp, #8]                              
02d2a080: cbz     x0, #0x2d2a164                             
02d2a084: adrp    x20, #0x6266000                            
02d2a088: adrp    x21, #0x6263000                            
02d2a08c: ldr     x20, [x20, #0x128]                         T:System.DateTime
02d2a090: ldr     x21, [x21, #0x928]                         T:UnityEngine.Debug
02d2a094: bl      #0x2d2a50c                                 DailyTask.DataDailyTask::GetLastLoginDate
02d2a098: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d2a09c: str     x0, [sp, #8]                               
02d2a0a0: ldr     w9, [x8, #0xe4]                            
02d2a0a4: cbnz    w9, #0x2d2a0b0                             
02d2a0a8: mov     x0, x8                                     
02d2a0ac: bl      #0x2b70f30                                 fn_2b70f30
02d2a0b0: add     x0, sp, #8                                 
02d2a0b4: mov     x1, xzr                                    
02d2a0b8: bl      #0x4df1f38                                 System.DateTime::get_Date
02d2a0bc: mov     x20, x0                                    
02d2a0c0: mov     x0, xzr                                    
02d2a0c4: bl      #0x4df285c                                 System.DateTime::get_Today
02d2a0c8: mov     x1, x0                                     
02d2a0cc: mov     x0, x20                                    
02d2a0d0: mov     x2, xzr                                    
02d2a0d4: bl      #0x4df40ec                                 System.DateTime::op_LessThan
02d2a0d8: mov     w8, w0                                     
02d2a0dc: ldr     x0, [x21]                                  &2c5bbd4(=a9bd7bfdd503233f)
02d2a0e0: ldr     w9, [x0, #0xe4]                            [626a0e4]=0 f=0,0
02d2a0e4: tbz     w8, #0, #0x2d2a11c                         
02d2a0e8: cbnz    w9, #0x2d2a0f0                             
02d2a0ec: bl      #0x2b70f30                                 fn_2b70f30
02d2a0f0: adrp    x8, #0x626a000                             
02d2a0f4: mov     x1, xzr                                    
02d2a0f8: ldr     x8, [x8, #0x2c8]                           S:'🎉 A new day has started! Generating new Tasks.'
02d2a0fc: ldr     x0, [x8]                                   T:type56879(k15)
02d2a100: bl      #0x5af2840                                 UnityEngine.Debug::LogError
02d2a104: mov     x0, x19                                    
02d2a108: bl      #0x2d2a38c                                 DailyTask.DailyTaskController::GenerateNewDailyMissions
02d2a10c: ldr     x0, [x19, #0x38]                           ._dataDailyTask
02d2a110: cbz     x0, #0x2d2a164                             
02d2a114: bl      #0x2d2a5bc                                 DailyTask.DataDailyTask::SaveLastLoginDate
02d2a118: b       #0x2d2a138                                 
02d2a11c: cbnz    w9, #0x2d2a124                             
02d2a120: bl      #0x2b70f30                                 fn_2b70f30
02d2a124: adrp    x8, #0x626a000                             
02d2a128: mov     x1, xzr                                    
02d2a12c: ldr     x8, [x8, #0x2d0]                           S:"Welcome back! Loading today's missions."
02d2a130: ldr     x0, [x8]                                   T:type56879(k15)
02d2a134: bl      #0x5af2840                                 UnityEngine.Debug::LogError
02d2a138: ldr     x0, [x19, #0x38]                           ._dataDailyTask
02d2a13c: cbz     x0, #0x2d2a164                             
02d2a140: bl      #0x2d2a660                                 DailyTask.DataDailyTask::GetCurrentDailyTasks
02d2a144: mov     x1, x0                                     
02d2a148: str     x0, [x19, #0x48]!                          ._currentDailyTasks
02d2a14c: mov     x0, x19                                    
02d2a150: bl      #0x2b70d54                                 fn_2b70d54
02d2a154: ldp     x20, x19, [sp, #0x20]                      
02d2a158: ldp     x30, x21, [sp, #0x10]                      
02d2a15c: add     sp, sp, #0x30                              
02d2a160: ret                                                
02d2a164: bl      #0x2b7105c                                 fn_2b7105c
## GenerateNewDailyMissions() -> void
---- DailyTask.DailyTaskController::GenerateNewDailyMissions 0x2d2a38c
02d2a38c: str     x30, [sp, #-0x60]!                         
02d2a390: stp     x28, x27, [sp, #0x10]                      
02d2a394: stp     x26, x25, [sp, #0x20]                      
02d2a398: stp     x24, x23, [sp, #0x30]                      
02d2a39c: stp     x22, x21, [sp, #0x40]                      
02d2a3a0: stp     x20, x19, [sp, #0x50]                      
02d2a3a4: adrp    x20, #0x6630000                            
02d2a3a8: mov     x19, x0                                    
02d2a3ac: ldrb    w8, [x20, #0xb1]                           
02d2a3b0: tbnz    w8, #0, #0x2d2a404                         
02d2a3b4: adrp    x0, #0x626a000                             
02d2a3b8: ldr     x0, [x0, #0x2f8]                           MS:System.Collections.Generic.List`1::RemoveAt
02d2a3bc: bl      #0x2b70db0                                 fn_2b70db0
02d2a3c0: adrp    x0, #0x626a000                             
02d2a3c4: ldr     x0, [x0, #0x300]                           MS:System.Collections.Generic.List`1::.ctor
02d2a3c8: bl      #0x2b70db0                                 fn_2b70db0
02d2a3cc: adrp    x0, #0x626a000                             
02d2a3d0: ldr     x0, [x0, #0x308]                           MS:System.Collections.Generic.List`1::get_Count
02d2a3d4: bl      #0x2b70db0                                 fn_2b70db0
02d2a3d8: adrp    x0, #0x626a000                             
02d2a3dc: ldr     x0, [x0, #0x310]                           MS:System.Collections.Generic.List`1::get_Item
02d2a3e0: bl      #0x2b70db0                                 fn_2b70db0
02d2a3e4: adrp    x0, #0x626a000                             
02d2a3e8: ldr     x0, [x0, #0x318]                           MS:System.Collections.Generic.List`1::get_Item
02d2a3ec: bl      #0x2b70db0                                 fn_2b70db0
02d2a3f0: adrp    x0, #0x626a000                             
02d2a3f4: ldr     x0, [x0, #0x320]                           T:type56760(k15)
02d2a3f8: bl      #0x2b70db0                                 fn_2b70db0
02d2a3fc: mov     w8, #1                                     
02d2a400: strb    w8, [x20, #0xb1]                           
02d2a404: ldr     x0, [x19, #0x38]                           ._dataDailyTask
02d2a408: cbz     x0, #0x2d2a508                             
02d2a40c: bl      #0x2d2a8b0                                 DailyTask.DataDailyTask::ResetForNewDay
02d2a410: ldr     x8, [x19, #0x40]                           ._dailyTaskSO
02d2a414: cbz     x8, #0x2d2a508                             
02d2a418: adrp    x9, #0x626a000                             
02d2a41c: adrp    x20, #0x626a000                            
02d2a420: ldr     x9, [x9, #0x320]                           T:type56760(k15)
02d2a424: ldr     x20, [x20, #0x300]                         MS:System.Collections.Generic.List`1::.ctor
02d2a428: ldr     x21, [x8, #0x18]                           
02d2a42c: ldr     x0, [x9]                                   T:type56879(k15)
02d2a430: bl      #0x2b7104c                                 fn_2b7104c
02d2a434: ldr     x2, [x20]                                  T:type56879(k15)
02d2a438: mov     x1, x21                                    
02d2a43c: mov     x20, x0                                    
02d2a440: bl      #0x35a8ae0                                 fn_35a8ae0
02d2a444: bl      #0x2d2a9c0                                 DailyTask.DailyTaskController::GenerateRewardNumbers
02d2a448: cbz     x20, #0x2d2a508                            
02d2a44c: adrp    x26, #0x626a000                            
02d2a450: adrp    x27, #0x626a000                            
02d2a454: adrp    x28, #0x626a000                            
02d2a458: ldr     x26, [x26, #0x318]                         MS:System.Collections.Generic.List`1::get_Item
02d2a45c: ldr     x27, [x27, #0x310]                         MS:System.Collections.Generic.List`1::get_Item
02d2a460: ldr     x28, [x28, #0x2f8]                         MS:System.Collections.Generic.List`1::RemoveAt
02d2a464: mov     x21, x0                                    
02d2a468: mov     w22, wzr                                   
02d2a46c: ldr     w1, [x20, #0x18]                           MS:System.Collections.Generic.List`1::Add
02d2a470: cmp     w1, #0                                     
02d2a474: b.le    #0x2d2a4ec                                 
02d2a478: mov     w0, wzr                                    
02d2a47c: mov     x2, xzr                                    
02d2a480: bl      #0x5b2e000                                 UnityEngine.Random::Range
02d2a484: ldr     x2, [x26]                                  T:type56879(k15)
02d2a488: mov     w23, w0                                    
02d2a48c: mov     x0, x20                                    
02d2a490: mov     w1, w23                                    
02d2a494: bl      #0x35a8f3c                                 fn_35a8f3c
02d2a498: cbz     x0, #0x2d2a508                             
02d2a49c: cbz     x21, #0x2d2a508                            
02d2a4a0: ldr     x2, [x27]                                  T:type56879(k15)
02d2a4a4: ldr     x24, [x19, #0x38]                          ._dataDailyTask
02d2a4a8: mov     w1, w22                                    
02d2a4ac: ldr     w25, [x0, #0x10]                           T:Decor.DataDecor/CategoryData
02d2a4b0: mov     x0, x21                                    
02d2a4b4: bl      #0x3569920                                 fn_3569920
02d2a4b8: cbz     x24, #0x2d2a508                            
02d2a4bc: mov     w3, w0                                     
02d2a4c0: mov     x0, x24                                    
02d2a4c4: mov     w1, w25                                    
02d2a4c8: mov     w2, wzr                                    
02d2a4cc: bl      #0x2d2adc8                                 DailyTask.DataDailyTask::AddInProgressTask
02d2a4d0: ldr     x2, [x28]                                  T:type56879(k15)
02d2a4d4: mov     x0, x20                                    
02d2a4d8: mov     w1, w23                                    
02d2a4dc: bl      #0x35aaa5c                                 fn_35aaa5c
02d2a4e0: add     w22, w22, #1                               
02d2a4e4: cmp     w22, #3                                    
02d2a4e8: b.ne    #0x2d2a46c                                 
02d2a4ec: ldp     x20, x19, [sp, #0x50]                      
02d2a4f0: ldp     x22, x21, [sp, #0x40]                      
02d2a4f4: ldp     x24, x23, [sp, #0x30]                      
02d2a4f8: ldp     x26, x25, [sp, #0x20]                      
02d2a4fc: ldp     x28, x27, [sp, #0x10]                      
02d2a500: ldr     x30, [sp], #0x60                           
02d2a504: ret                                                
02d2a508: bl      #0x2b7105c                                 fn_2b7105c
## CompleteTask(int taskId) -> void
---- DailyTask.DailyTaskController::CompleteTask 0x2d2aef0
02d2aef0: stp     x30, x23, [sp, #-0x30]!                    
02d2aef4: stp     x22, x21, [sp, #0x10]                      
02d2aef8: stp     x20, x19, [sp, #0x20]                      
02d2aefc: adrp    x21, #0x6630000                            
02d2af00: adrp    x22, #0x626a000                            
02d2af04: mov     w20, w1                                    
02d2af08: ldrb    w8, [x21, #0xb2]                           
02d2af0c: ldr     x22, [x22, #0x360]                         T:DailyTask.DailyTaskController/<>c__DisplayClass23_0
02d2af10: mov     x19, x0                                    
02d2af14: tbnz    w8, #0, #0x2d2af74                         
02d2af18: adrp    x0, #0x6263000                             
02d2af1c: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02d2af20: bl      #0x2b70db0                                 fn_2b70db0
02d2af24: adrp    x0, #0x626a000                             
02d2af28: ldr     x0, [x0, #0x228]                           MS:System.Collections.Generic.List`1::Exists
02d2af2c: bl      #0x2b70db0                                 fn_2b70db0
02d2af30: adrp    x0, #0x626a000                             
02d2af34: ldr     x0, [x0, #0x368]                           MS:System.Collections.Generic.List`1::get_Count
02d2af38: bl      #0x2b70db0                                 fn_2b70db0
02d2af3c: adrp    x0, #0x626a000                             
02d2af40: ldr     x0, [x0, #0x230]                           T:type57305(k15)
02d2af44: bl      #0x2b70db0                                 fn_2b70db0
02d2af48: adrp    x0, #0x626a000                             
02d2af4c: ldr     x0, [x0, #0x370]                           M:DailyTask.DailyTaskController/<>c__DisplayClass23_0::<CompleteTask>b__0
02d2af50: bl      #0x2b70db0                                 fn_2b70db0
02d2af54: adrp    x0, #0x626a000                             
02d2af58: ldr     x0, [x0, #0x360]                           T:DailyTask.DailyTaskController/<>c__DisplayClass23_0
02d2af5c: bl      #0x2b70db0                                 fn_2b70db0
02d2af60: adrp    x0, #0x626a000                             
02d2af64: ldr     x0, [x0, #0x378]                           S:'All daily tasks completed for today!'
02d2af68: bl      #0x2b70db0                                 fn_2b70db0
02d2af6c: mov     w8, #1                                     
02d2af70: strb    w8, [x21, #0xb2]                           
02d2af74: ldr     x0, [x22]                                  T:type56879(k15)
02d2af78: bl      #0x2b7104c                                 fn_2b7104c
02d2af7c: mov     x1, xzr                                    
02d2af80: mov     x21, x0                                    
02d2af84: bl      #0x4e53e9c                                 System.Object::.ctor
02d2af88: cbz     x21, #0x2d2b090                            
02d2af8c: adrp    x8, #0x626a000                             
02d2af90: adrp    x23, #0x626a000                            
02d2af94: ldr     x8, [x8, #0x230]                           T:type57305(k15)
02d2af98: ldr     x23, [x23, #0x370]                         M:DailyTask.DailyTaskController/<>c__DisplayClass23_0::<CompleteTask>b__0
02d2af9c: ldr     x22, [x19, #0x48]                          ._currentDailyTasks
02d2afa0: str     w20, [x21, #0x10]                          
02d2afa4: ldr     x0, [x8]                                   T:type56879(k15)
02d2afa8: bl      #0x2b7104c                                 fn_2b7104c
02d2afac: ldr     x2, [x23]                                  T:type56879(k15)
02d2afb0: mov     x1, x21                                    
02d2afb4: mov     x3, xzr                                    
02d2afb8: mov     x20, x0                                    
02d2afbc: bl      #0x399ba10                                 fn_399ba10
02d2afc0: cbz     x22, #0x2d2b090                            
02d2afc4: adrp    x8, #0x626a000                             
02d2afc8: mov     x0, x22                                    
02d2afcc: mov     x1, x20                                    
02d2afd0: ldr     x8, [x8, #0x228]                           MS:System.Collections.Generic.List`1::Exists
02d2afd4: ldr     x2, [x8]                                   T:type56879(k15)
02d2afd8: bl      #0x35a9844                                 fn_35a9844
02d2afdc: tbz     w0, #0, #0x2d2b080                         
02d2afe0: ldr     x0, [x19, #0x38]                           ._dataDailyTask
02d2afe4: cbz     x0, #0x2d2b090                             
02d2afe8: ldr     w1, [x21, #0x10]                           
02d2afec: bl      #0x2d2b09c                                 DailyTask.DataDailyTask::AddCompletedTask
02d2aff0: ldr     x8, [x19, #0x28]                           .OnTaskCompleted
02d2aff4: cbz     x8, #0x2d2b00c                             
02d2aff8: ldr     w1, [x21, #0x10]                           
02d2affc: ldr     x9, [x8, #0x18]                            MS:System.Collections.Generic.List`1::Add
02d2b000: ldr     x0, [x8, #0x40]                            MS:System.Collections.Generic.List`1::IndexOf
02d2b004: ldr     x2, [x8, #0x28]                            T:Decor.DataDecor/<>c__DisplayClass8_0
02d2b008: blr     x9                                         
02d2b00c: ldr     x8, [x19, #0x38]                           ._dataDailyTask
02d2b010: cbz     x8, #0x2d2b090                             
02d2b014: ldr     x8, [x8, #0x20]                            M:Decor.DataDecor/<>c__DisplayClass8_0::<NewData>b__0
02d2b018: cbz     x8, #0x2d2b090                             
02d2b01c: ldr     x8, [x8, #0x20]                            M:Decor.DataDecor/<>c__DisplayClass8_0::<NewData>b__0
02d2b020: cbz     x8, #0x2d2b090                             
02d2b024: ldr     w8, [x8, #0x18]                            MS:System.Collections.Generic.List`1::Add
02d2b028: cmp     w8, #3                                     
02d2b02c: b.lt    #0x2d2b080                                 
02d2b030: adrp    x8, #0x6263000                             
02d2b034: ldr     x8, [x8, #0x928]                           T:UnityEngine.Debug
02d2b038: ldr     x0, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02d2b03c: ldr     w8, [x0, #0xe4]                            [626a0e4]=0 f=0,0
02d2b040: cbnz    w8, #0x2d2b048                             
02d2b044: bl      #0x2b70f30                                 fn_2b70f30
02d2b048: adrp    x8, #0x626a000                             
02d2b04c: mov     x1, xzr                                    
02d2b050: ldr     x8, [x8, #0x378]                           S:'All daily tasks completed for today!'
02d2b054: ldr     x0, [x8]                                   T:type56879(k15)
02d2b058: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02d2b05c: ldr     x8, [x19, #0x20]                           .OnAllTasksCompleted
02d2b060: cbz     x8, #0x2d2b080                             
02d2b064: ldp     x20, x19, [sp, #0x20]                      
02d2b068: ldr     x0, [x8, #0x40]                            MS:System.Collections.Generic.List`1::IndexOf
02d2b06c: ldp     x22, x21, [sp, #0x10]                      
02d2b070: ldr     x1, [x8, #0x28]                            T:Decor.DataDecor/<>c__DisplayClass8_0
02d2b074: ldr     x2, [x8, #0x18]                            MS:System.Collections.Generic.List`1::Add
02d2b078: ldp     x30, x23, [sp], #0x30                      
02d2b07c: br      x2                                         
02d2b080: ldp     x20, x19, [sp, #0x20]                      
02d2b084: ldp     x22, x21, [sp, #0x10]                      
02d2b088: ldp     x30, x23, [sp], #0x30                      
02d2b08c: ret                                                
02d2b090: bl      #0x2b7105c                                 fn_2b7105c
## ProgressTask(int taskId, int progressValue) -> void
---- DailyTask.DailyTaskController::ProgressTask 0x2d28eec
02d28eec: sub     sp, sp, #0x50                              
02d28ef0: str     x30, [sp, #0x10]                           
02d28ef4: stp     x24, x23, [sp, #0x20]                      
02d28ef8: stp     x22, x21, [sp, #0x30]                      
02d28efc: stp     x20, x19, [sp, #0x40]                      
02d28f00: adrp    x21, #0x6630000                            
02d28f04: adrp    x23, #0x626a000                            
02d28f08: mov     w20, w2                                    
02d28f0c: ldrb    w8, [x21, #0xb3]                           
02d28f10: ldr     x23, [x23, #0x220]                         T:DailyTask.DailyTaskController/<>c__DisplayClass24_0
02d28f14: mov     w22, w1                                    
02d28f18: mov     x19, x0                                    
02d28f1c: tbnz    w8, #0, #0x2d28f70                         
02d28f20: adrp    x0, #0x6263000                             
02d28f24: ldr     x0, [x0, #0x928]                           T:UnityEngine.Debug
02d28f28: bl      #0x2b70db0                                 fn_2b70db0
02d28f2c: adrp    x0, #0x626a000                             
02d28f30: ldr     x0, [x0, #0x228]                           MS:System.Collections.Generic.List`1::Exists
02d28f34: bl      #0x2b70db0                                 fn_2b70db0
02d28f38: adrp    x0, #0x626a000                             
02d28f3c: ldr     x0, [x0, #0x230]                           T:type57305(k15)
02d28f40: bl      #0x2b70db0                                 fn_2b70db0
02d28f44: adrp    x0, #0x626a000                             
02d28f48: ldr     x0, [x0, #0x238]                           M:DailyTask.DailyTaskController/<>c__DisplayClass24_0::<ProgressTask>b__0
02d28f4c: bl      #0x2b70db0                                 fn_2b70db0
02d28f50: adrp    x0, #0x626a000                             
02d28f54: ldr     x0, [x0, #0x220]                           T:DailyTask.DailyTaskController/<>c__DisplayClass24_0
02d28f58: bl      #0x2b70db0                                 fn_2b70db0
02d28f5c: adrp    x0, #0x626a000                             
02d28f60: ldr     x0, [x0, #0x240]                           S:'Task {0} progressed by {1}. Current progress: {2}'
02d28f64: bl      #0x2b70db0                                 fn_2b70db0
02d28f68: mov     w8, #1                                     
02d28f6c: strb    w8, [x21, #0xb3]                           
02d28f70: ldr     x0, [x23]                                  T:type56879(k15)
02d28f74: bl      #0x2b7104c                                 fn_2b7104c
02d28f78: mov     x1, xzr                                    
02d28f7c: mov     x21, x0                                    
02d28f80: bl      #0x4e53e9c                                 System.Object::.ctor
02d28f84: cbz     x21, #0x2d290f4                            
02d28f88: adrp    x8, #0x626a000                             
02d28f8c: adrp    x24, #0x626a000                            
02d28f90: ldr     x8, [x8, #0x230]                           T:type57305(k15)
02d28f94: ldr     x24, [x24, #0x238]                         M:DailyTask.DailyTaskController/<>c__DisplayClass24_0::<ProgressTask>b__0
02d28f98: ldr     x23, [x19, #0x48]                          ._currentDailyTasks
02d28f9c: str     w22, [x21, #0x10]                          
02d28fa0: ldr     x0, [x8]                                   T:type56879(k15)
02d28fa4: bl      #0x2b7104c                                 fn_2b7104c
02d28fa8: ldr     x2, [x24]                                  T:type56879(k15)
02d28fac: mov     x1, x21                                    
02d28fb0: mov     x3, xzr                                    
02d28fb4: mov     x22, x0                                    
02d28fb8: bl      #0x399ba10                                 fn_399ba10
02d28fbc: cbz     x23, #0x2d290f4                            
02d28fc0: adrp    x8, #0x626a000                             
02d28fc4: mov     x0, x23                                    
02d28fc8: mov     x1, x22                                    
02d28fcc: ldr     x8, [x8, #0x228]                           MS:System.Collections.Generic.List`1::Exists
02d28fd0: ldr     x2, [x8]                                   T:type56879(k15)
02d28fd4: bl      #0x35a9844                                 fn_35a9844
02d28fd8: tbz     w0, #0, #0x2d290dc                         
02d28fdc: ldr     x0, [x19, #0x38]                           ._dataDailyTask
02d28fe0: cbz     x0, #0x2d290f4                             
02d28fe4: ldr     w1, [x21, #0x10]                           
02d28fe8: bl      #0x2d2b26c                                 DailyTask.DataDailyTask::IsTaskCompleted
02d28fec: tbnz    w0, #0, #0x2d290dc                         
02d28ff0: ldr     w1, [x21, #0x10]                           
02d28ff4: mov     x0, x19                                    
02d28ff8: bl      #0x2d2b34c                                 DailyTask.DailyTaskController::IsTaskClaimable
02d28ffc: tbnz    w0, #0, #0x2d290dc                         
02d29000: ldr     x0, [x19, #0x38]                           ._dataDailyTask
02d29004: cbz     x0, #0x2d290f4                             
02d29008: ldr     w1, [x21, #0x10]                           
02d2900c: mov     w2, w20                                    
02d29010: bl      #0x2d2b480                                 DailyTask.DataDailyTask::UpdateInProgressTask
02d29014: ldr     x8, [x19, #0x30]                           .OnTaskProgressed
02d29018: cbz     x8, #0x2d29030                             
02d2901c: ldr     w1, [x21, #0x10]                           
02d29020: ldr     x9, [x8, #0x18]                            MS:System.Collections.Generic.List`1::Add
02d29024: ldr     x0, [x8, #0x40]                            MS:System.Collections.Generic.List`1::IndexOf
02d29028: ldr     x2, [x8, #0x28]                            T:Decor.DataDecor/<>c__DisplayClass8_0
02d2902c: blr     x9                                         
02d29030: adrp    x23, #0x6263000                            
02d29034: add     x1, sp, #0x1c                              
02d29038: ldr     x23, [x23, #0x970]                         &6645c70(=0)
02d2903c: ldr     w8, [x21, #0x10]                           
02d29040: ldr     x0, [x23, #0x48]                           &6263098(=0)
02d29044: str     w8, [sp, #0x1c]                            
02d29048: bl      #0x2b70f38                                 fn_2b70f38
02d2904c: mov     x22, x0                                    
02d29050: ldr     x0, [x23, #0x48]                           &6263098(=0)
02d29054: add     x1, sp, #0x18                              
02d29058: str     w20, [sp, #0x18]                           
02d2905c: bl      #0x2b70f38                                 fn_2b70f38
02d29060: ldr     x8, [x19, #0x38]                           ._dataDailyTask
02d29064: cbz     x8, #0x2d290f4                             
02d29068: ldr     w1, [x21, #0x10]                           
02d2906c: mov     x19, x0                                    
02d29070: mov     x0, x8                                     
02d29074: bl      #0x2d2b5a8                                 DailyTask.DataDailyTask::GetProgressOfTask
02d29078: ldr     x8, [x23, #0x48]                           &6263098(=0)
02d2907c: str     w0, [sp, #0xc]                             
02d29080: add     x1, sp, #0xc                               
02d29084: mov     x0, x8                                     
02d29088: bl      #0x2b70f38                                 fn_2b70f38
02d2908c: adrp    x8, #0x626a000                             
02d29090: mov     x3, x0                                     
02d29094: mov     x1, x22                                    
02d29098: ldr     x8, [x8, #0x240]                           S:'Task {0} progressed by {1}. Current progress: {2}'
02d2909c: mov     x2, x19                                    
02d290a0: mov     x4, xzr                                    
02d290a4: ldr     x8, [x8]                                   T:type56879(k15)
02d290a8: mov     x0, x8                                     
02d290ac: bl      #0x4ca7764                                 System.String::Format
02d290b0: adrp    x8, #0x6263000                             
02d290b4: mov     x19, x0                                    
02d290b8: ldr     x8, [x8, #0x928]                           T:UnityEngine.Debug
02d290bc: ldr     x8, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02d290c0: ldr     w9, [x8, #0xe4]                            [62630e4]=0 f=0,0
02d290c4: cbnz    w9, #0x2d290d0                             
02d290c8: mov     x0, x8                                     
02d290cc: bl      #0x2b70f30                                 fn_2b70f30
02d290d0: mov     x0, x19                                    
02d290d4: mov     x1, xzr                                    
02d290d8: bl      #0x5af21f4                                 UnityEngine.Debug::Log
02d290dc: ldp     x20, x19, [sp, #0x40]                      
02d290e0: ldr     x30, [sp, #0x10]                           
02d290e4: ldp     x22, x21, [sp, #0x30]                      
02d290e8: ldp     x24, x23, [sp, #0x20]                      
02d290ec: add     sp, sp, #0x50                              
02d290f0: ret                                                
02d290f4: bl      #0x2b7105c                                 fn_2b7105c
## IsCompletedAllTasks() -> bool
---- DailyTask.DailyTaskController::IsCompletedAllTasks 0x2d2b694
02d2b694: str     x30, [sp, #-0x20]!                         
02d2b698: stp     x20, x19, [sp, #0x10]                      
02d2b69c: adrp    x20, #0x6630000                            
02d2b6a0: mov     x19, x0                                    
02d2b6a4: ldrb    w8, [x20, #0xb4]                           
02d2b6a8: tbnz    w8, #0, #0x2d2b6c0                         
02d2b6ac: adrp    x0, #0x626a000                             
02d2b6b0: ldr     x0, [x0, #0x368]                           MS:System.Collections.Generic.List`1::get_Count
02d2b6b4: bl      #0x2b70db0                                 fn_2b70db0
02d2b6b8: mov     w8, #1                                     
02d2b6bc: strb    w8, [x20, #0xb4]                           
02d2b6c0: ldr     x8, [x19, #0x38]                           ._dataDailyTask
02d2b6c4: cbz     x8, #0x2d2b6f0                             
02d2b6c8: ldr     x8, [x8, #0x20]                            
02d2b6cc: cbz     x8, #0x2d2b6f0                             
02d2b6d0: ldr     x8, [x8, #0x20]                            
02d2b6d4: cbz     x8, #0x2d2b6f0                             
02d2b6d8: ldr     w8, [x8, #0x18]                            
02d2b6dc: ldp     x20, x19, [sp, #0x10]                      
02d2b6e0: cmp     w8, #2                                     
02d2b6e4: cset    w0, gt                                     
02d2b6e8: ldr     x30, [sp], #0x20                           
02d2b6ec: ret                                                
02d2b6f0: bl      #0x2b7105c                                 fn_2b7105c
## IsTaskClaimable(int taskId) -> bool
---- DailyTask.DailyTaskController::IsTaskClaimable 0x2d2b34c
02d2b34c: stp     x30, x23, [sp, #-0x30]!                    
02d2b350: stp     x22, x21, [sp, #0x10]                      
02d2b354: stp     x20, x19, [sp, #0x20]                      
02d2b358: adrp    x20, #0x6630000                            
02d2b35c: adrp    x22, #0x626a000                            
02d2b360: mov     w21, w1                                    
02d2b364: ldrb    w8, [x20, #0xb5]                           
02d2b368: ldr     x22, [x22, #0x3b0]                         T:DailyTask.DailyTaskController/<>c__DisplayClass26_0
02d2b36c: mov     x19, x0                                    
02d2b370: tbnz    w8, #0, #0x2d2b3ac                         
02d2b374: adrp    x0, #0x626a000                             
02d2b378: ldr     x0, [x0, #0x228]                           MS:System.Collections.Generic.List`1::Exists
02d2b37c: bl      #0x2b70db0                                 fn_2b70db0
02d2b380: adrp    x0, #0x626a000                             
02d2b384: ldr     x0, [x0, #0x230]                           T:type57305(k15)
02d2b388: bl      #0x2b70db0                                 fn_2b70db0
02d2b38c: adrp    x0, #0x626a000                             
02d2b390: ldr     x0, [x0, #0x3b8]                           M:DailyTask.DailyTaskController/<>c__DisplayClass26_0::<IsTaskClaimable>b__0
02d2b394: bl      #0x2b70db0                                 fn_2b70db0
02d2b398: adrp    x0, #0x626a000                             
02d2b39c: ldr     x0, [x0, #0x3b0]                           T:DailyTask.DailyTaskController/<>c__DisplayClass26_0
02d2b3a0: bl      #0x2b70db0                                 fn_2b70db0
02d2b3a4: mov     w8, #1                                     
02d2b3a8: strb    w8, [x20, #0xb5]                           
02d2b3ac: ldr     x0, [x22]                                  T:type56879(k15)
02d2b3b0: bl      #0x2b7104c                                 fn_2b7104c
02d2b3b4: mov     x1, xzr                                    
02d2b3b8: mov     x20, x0                                    
02d2b3bc: bl      #0x4e53e9c                                 System.Object::.ctor
02d2b3c0: cbz     x20, #0x2d2b47c                            
02d2b3c4: adrp    x8, #0x626a000                             
02d2b3c8: adrp    x23, #0x626a000                            
02d2b3cc: ldr     x8, [x8, #0x230]                           T:type57305(k15)
02d2b3d0: ldr     x23, [x23, #0x3b8]                         M:DailyTask.DailyTaskController/<>c__DisplayClass26_0::<IsTaskClaimable>b__0
02d2b3d4: ldr     x22, [x19, #0x48]                          ._currentDailyTasks
02d2b3d8: str     w21, [x20, #0x10]                          
02d2b3dc: ldr     x0, [x8]                                   T:type56879(k15)
02d2b3e0: bl      #0x2b7104c                                 fn_2b7104c
02d2b3e4: ldr     x2, [x23]                                  T:type56879(k15)
02d2b3e8: mov     x1, x20                                    
02d2b3ec: mov     x3, xzr                                    
02d2b3f0: mov     x21, x0                                    
02d2b3f4: bl      #0x399ba10                                 fn_399ba10
02d2b3f8: cbz     x22, #0x2d2b47c                            
02d2b3fc: adrp    x8, #0x626a000                             
02d2b400: mov     x0, x22                                    
02d2b404: mov     x1, x21                                    
02d2b408: ldr     x8, [x8, #0x228]                           MS:System.Collections.Generic.List`1::Exists
02d2b40c: ldr     x2, [x8]                                   T:type56879(k15)
02d2b410: bl      #0x35a9844                                 fn_35a9844
02d2b414: tbz     w0, #0, #0x2d2b42c                         
02d2b418: ldr     x0, [x19, #0x38]                           ._dataDailyTask
02d2b41c: cbz     x0, #0x2d2b47c                             
02d2b420: ldr     w1, [x20, #0x10]                           
02d2b424: bl      #0x2d2b26c                                 DailyTask.DataDailyTask::IsTaskCompleted
02d2b428: tbz     w0, #0, #0x2d2b434                         
02d2b42c: mov     w0, wzr                                    
02d2b430: b       #0x2d2b46c                                 
02d2b434: ldr     x0, [x19, #0x38]                           ._dataDailyTask
02d2b438: cbz     x0, #0x2d2b47c                             
02d2b43c: ldr     w1, [x20, #0x10]                           
02d2b440: bl      #0x2d2b5a8                                 DailyTask.DataDailyTask::GetProgressOfTask
02d2b444: ldr     x8, [x19, #0x40]                           ._dailyTaskSO
02d2b448: cbz     x8, #0x2d2b47c                             
02d2b44c: ldr     w1, [x20, #0x10]                           
02d2b450: mov     w19, w0                                    
02d2b454: mov     x0, x8                                     
02d2b458: bl      #0x2d2b6fc                                 DailyTask.DailyTaskSO::GetMissionById
02d2b45c: cbz     x0, #0x2d2b47c                             
02d2b460: ldr     w8, [x0, #0x30]                            S:'======================================================  i : ' .OnTaskProgressed
02d2b464: cmp     w19, w8                                    
02d2b468: cset    w0, ge                                     
02d2b46c: ldp     x20, x19, [sp, #0x20]                      
02d2b470: ldp     x22, x21, [sp, #0x10]                      
02d2b474: ldp     x30, x23, [sp], #0x30                      
02d2b478: ret                                                
02d2b47c: bl      #0x2b7105c                                 fn_2b7105c
## AnyTaskClaimable() -> bool
---- DailyTask.DailyTaskController::AnyTaskClaimable 0x2d2b7d4
02d2b7d4: sub     sp, sp, #0x60                              
02d2b7d8: str     x30, [sp, #0x30]                           
02d2b7dc: stp     x22, x21, [sp, #0x40]                      
02d2b7e0: stp     x20, x19, [sp, #0x50]                      
02d2b7e4: adrp    x20, #0x6630000                            
02d2b7e8: mov     x19, x0                                    
02d2b7ec: ldrb    w8, [x20, #0xb6]                           
02d2b7f0: tbnz    w8, #0, #0x2d2b82c                         
02d2b7f4: adrp    x0, #0x626a000                             
02d2b7f8: ldr     x0, [x0, #0x2d8]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d2b7fc: bl      #0x2b70db0                                 fn_2b70db0
02d2b800: adrp    x0, #0x626a000                             
02d2b804: ldr     x0, [x0, #0x2e0]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d2b808: bl      #0x2b70db0                                 fn_2b70db0
02d2b80c: adrp    x0, #0x626a000                             
02d2b810: ldr     x0, [x0, #0x2e8]                           MS:System.Collections.Generic.List`1/Enumerator::get_Current
02d2b814: bl      #0x2b70db0                                 fn_2b70db0
02d2b818: adrp    x0, #0x626a000                             
02d2b81c: ldr     x0, [x0, #0x2f0]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d2b820: bl      #0x2b70db0                                 fn_2b70db0
02d2b824: mov     w8, #1                                     
02d2b828: strb    w8, [x20, #0xb6]                           
02d2b82c: ldr     x0, [x19, #0x48]                           ._currentDailyTasks
02d2b830: stp     xzr, xzr, [sp, #0x18]                      
02d2b834: str     xzr, [sp, #0x28]                           
02d2b838: cbz     x0, #0x2d2b8bc                             
02d2b83c: adrp    x8, #0x626a000                             
02d2b840: adrp    x22, #0x626a000                            
02d2b844: adrp    x21, #0x626a000                            
02d2b848: ldr     x8, [x8, #0x2f0]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d2b84c: ldr     x22, [x22, #0x2e0]                         MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d2b850: ldr     x21, [x21, #0x2d8]                         MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d2b854: add     x20, sp, #0x18                             
02d2b858: ldr     x1, [x8]                                   T:type56879(k15)
02d2b85c: add     x8, sp, #0x18                              
02d2b860: bl      #0x35a9d9c                                 fn_35a9d9c
02d2b864: stp     xzr, x20, [sp, #8]                         
02d2b868: ldr     x1, [x22]                                  T:type56879(k15)
02d2b86c: add     x0, sp, #0x18                              
02d2b870: bl      #0x4690474                                 fn_4690474
02d2b874: mov     w20, w0                                    
02d2b878: tbz     w0, #0, #0x2d2b894                         
02d2b87c: ldr     x8, [sp, #0x28]                            
02d2b880: cbz     x8, #0x2d2b8b8                             
02d2b884: ldr     w1, [x8, #0x10]                            T:Decor.DataDecor/CategoryData
02d2b888: mov     x0, x19                                    
02d2b88c: bl      #0x2d2b34c                                 DailyTask.DailyTaskController::IsTaskClaimable
02d2b890: tbz     w0, #0, #0x2d2b868                         
02d2b894: ldr     x1, [x21]                                  T:type56879(k15)
02d2b898: add     x0, sp, #0x18                              
02d2b89c: bl      #0x4690470                                 fn_4690470
02d2b8a0: and     w0, w20, #1                                
02d2b8a4: ldp     x20, x19, [sp, #0x50]                      
02d2b8a8: ldp     x22, x21, [sp, #0x40]                      
02d2b8ac: ldr     x30, [sp, #0x30]                           
02d2b8b0: add     sp, sp, #0x60                              
02d2b8b4: ret                                                
02d2b8b8: bl      #0x2b7105c                                 fn_2b7105c
02d2b8bc: bl      #0x2b7105c                                 fn_2b7105c
02d2b8c0: b       #0x2d2b8c8                                 
02d2b8c4: b       #0x2d2b8c8                                 
02d2b8c8: mov     x19, x0                                    
02d2b8cc: cmp     w1, #1                                     
02d2b8d0: b.ne    #0x2d2b90c                                 
02d2b8d4: mov     x0, x19                                    
02d2b8d8: bl      #0x5e90260                                 fn_5e90260
02d2b8dc: ldr     x19, [x0]                                  T:type56879(k15)
02d2b8e0: str     x19, [sp, #8]                              
02d2b8e4: bl      #0x5e90270                                 fn_5e90270
02d2b8e8: ldr     x0, [sp, #0x10]                            
02d2b8ec: ldr     x1, [x21]                                  T:type56879(k15)
02d2b8f0: bl      #0x4690470                                 fn_4690470
02d2b8f4: cbnz    x19, #0x2d2b900                            
02d2b8f8: mov     w20, wzr                                   
02d2b8fc: b       #0x2d2b8a0                                 
02d2b900: mov     x0, x19                                    
02d2b904: bl      #0x2b71054                                 fn_2b71054
02d2b908: mov     x19, x0                                    
02d2b90c: add     x0, sp, #8                                 
02d2b910: bl      #0x2738168                                 fn_2738168
02d2b914: mov     x0, x19                                    
02d2b918: bl      #0x2c6051c                                 fn_2c6051c
02d2b91c: bl      #0x27369b8                                 fn_27369b8
## GetRewardForTask(int taskId) -> int
---- DailyTask.DailyTaskController::GetRewardForTask 0x2d2b920
02d2b920: str     x30, [sp, #-0x30]!                         
02d2b924: stp     x22, x21, [sp, #0x10]                      
02d2b928: stp     x20, x19, [sp, #0x20]                      
02d2b92c: adrp    x21, #0x6630000                            
02d2b930: adrp    x22, #0x626a000                            
02d2b934: mov     w19, w1                                    
02d2b938: ldrb    w8, [x21, #0xb7]                           
02d2b93c: ldr     x22, [x22, #0x400]                         T:DailyTask.DailyTaskController/<>c__DisplayClass28_0
02d2b940: mov     x20, x0                                    
02d2b944: tbnz    w8, #0, #0x2d2b980                         
02d2b948: adrp    x0, #0x626a000                             
02d2b94c: ldr     x0, [x0, #0x388]                           MS:System.Collections.Generic.List`1::Find
02d2b950: bl      #0x2b70db0                                 fn_2b70db0
02d2b954: adrp    x0, #0x626a000                             
02d2b958: ldr     x0, [x0, #0x230]                           T:type57305(k15)
02d2b95c: bl      #0x2b70db0                                 fn_2b70db0
02d2b960: adrp    x0, #0x626a000                             
02d2b964: ldr     x0, [x0, #0x408]                           M:DailyTask.DailyTaskController/<>c__DisplayClass28_0::<GetRewardForTask>b__0
02d2b968: bl      #0x2b70db0                                 fn_2b70db0
02d2b96c: adrp    x0, #0x626a000                             
02d2b970: ldr     x0, [x0, #0x400]                           T:DailyTask.DailyTaskController/<>c__DisplayClass28_0
02d2b974: bl      #0x2b70db0                                 fn_2b70db0
02d2b978: mov     w8, #1                                     
02d2b97c: strb    w8, [x21, #0xb7]                           
02d2b980: ldr     x0, [x22]                                  T:type56879(k15)
02d2b984: bl      #0x2b7104c                                 fn_2b7104c
02d2b988: mov     x1, xzr                                    
02d2b98c: mov     x21, x0                                    
02d2b990: bl      #0x4e53e9c                                 System.Object::.ctor
02d2b994: cbz     x21, #0x2d2ba00                            
02d2b998: adrp    x8, #0x626a000                             
02d2b99c: adrp    x22, #0x626a000                            
02d2b9a0: ldr     x8, [x8, #0x230]                           T:type57305(k15)
02d2b9a4: ldr     x22, [x22, #0x408]                         M:DailyTask.DailyTaskController/<>c__DisplayClass28_0::<GetRewardForTask>b__0
02d2b9a8: ldr     x20, [x20, #0x48]                          ._currentDailyTasks
02d2b9ac: str     w19, [x21, #0x10]                          
02d2b9b0: ldr     x0, [x8]                                   T:type56879(k15)
02d2b9b4: bl      #0x2b7104c                                 fn_2b7104c
02d2b9b8: ldr     x2, [x22]                                  T:type56879(k15)
02d2b9bc: mov     x1, x21                                    
02d2b9c0: mov     x3, xzr                                    
02d2b9c4: mov     x19, x0                                    
02d2b9c8: bl      #0x399ba10                                 fn_399ba10
02d2b9cc: cbz     x20, #0x2d2ba00                            
02d2b9d0: adrp    x8, #0x626a000                             
02d2b9d4: mov     x0, x20                                    
02d2b9d8: mov     x1, x19                                    
02d2b9dc: ldr     x8, [x8, #0x388]                           MS:System.Collections.Generic.List`1::Find
02d2b9e0: ldr     x2, [x8]                                   T:type56879(k15)
02d2b9e4: bl      #0x35a9868                                 fn_35a9868
02d2b9e8: cbz     x0, #0x2d2ba00                             
02d2b9ec: ldp     x20, x19, [sp, #0x20]                      
02d2b9f0: ldr     w0, [x0, #0x18]                            MS:System.Collections.Generic.List`1::Add
02d2b9f4: ldp     x22, x21, [sp, #0x10]                      
02d2b9f8: ldr     x30, [sp], #0x30                           
02d2b9fc: ret                                                
02d2ba00: bl      #0x2b7105c                                 fn_2b7105c
## GetTotalRewardCompletedTasks() -> int
---- DailyTask.DailyTaskController::GetTotalRewardCompletedTasks 0x2d2ba0c
02d2ba0c: sub     sp, sp, #0x60                              
02d2ba10: stp     x30, x23, [sp, #0x30]                      
02d2ba14: stp     x22, x21, [sp, #0x40]                      
02d2ba18: stp     x20, x19, [sp, #0x50]                      
02d2ba1c: adrp    x19, #0x6630000                            
02d2ba20: mov     x20, x0                                    
02d2ba24: ldrb    w8, [x19, #0xb8]                           
02d2ba28: tbnz    w8, #0, #0x2d2ba64                         
02d2ba2c: adrp    x0, #0x626a000                             
02d2ba30: ldr     x0, [x0, #0x2d8]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d2ba34: bl      #0x2b70db0                                 fn_2b70db0
02d2ba38: adrp    x0, #0x626a000                             
02d2ba3c: ldr     x0, [x0, #0x2e0]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d2ba40: bl      #0x2b70db0                                 fn_2b70db0
02d2ba44: adrp    x0, #0x626a000                             
02d2ba48: ldr     x0, [x0, #0x2e8]                           MS:System.Collections.Generic.List`1/Enumerator::get_Current
02d2ba4c: bl      #0x2b70db0                                 fn_2b70db0
02d2ba50: adrp    x0, #0x626a000                             
02d2ba54: ldr     x0, [x0, #0x2f0]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d2ba58: bl      #0x2b70db0                                 fn_2b70db0
02d2ba5c: mov     w8, #1                                     
02d2ba60: strb    w8, [x19, #0xb8]                           
02d2ba64: ldr     x0, [x20, #0x48]                           ._currentDailyTasks
02d2ba68: stp     xzr, xzr, [sp, #0x18]                      
02d2ba6c: str     xzr, [sp, #0x28]                           
02d2ba70: cbz     x0, #0x2d2bb08                             
02d2ba74: adrp    x8, #0x626a000                             
02d2ba78: adrp    x22, #0x626a000                            
02d2ba7c: adrp    x21, #0x626a000                            
02d2ba80: ldr     x8, [x8, #0x2f0]                           MS:System.Collections.Generic.List`1::GetEnumerator
02d2ba84: ldr     x22, [x22, #0x2e0]                         MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02d2ba88: ldr     x21, [x21, #0x2d8]                         MS:System.Collections.Generic.List`1/Enumerator::Dispose
02d2ba8c: add     x23, sp, #0x18                             
02d2ba90: ldr     x1, [x8]                                   T:type56879(k15)
02d2ba94: add     x8, sp, #0x18                              
02d2ba98: bl      #0x35a9d9c                                 fn_35a9d9c
02d2ba9c: mov     w19, wzr                                   
02d2baa0: stp     xzr, x23, [sp, #8]                         
02d2baa4: ldr     x1, [x22]                                  T:type56879(k15)
02d2baa8: add     x0, sp, #0x18                              
02d2baac: bl      #0x4690474                                 fn_4690474
02d2bab0: tbz     w0, #0, #0x2d2badc                         
02d2bab4: ldr     x23, [sp, #0x28]                           
02d2bab8: cbz     x23, #0x2d2bb00                            
02d2babc: ldr     x0, [x20, #0x38]                           ._dataDailyTask
02d2bac0: cbz     x0, #0x2d2bb04                             
02d2bac4: ldr     w1, [x23, #0x10]                           
02d2bac8: bl      #0x2d2b26c                                 DailyTask.DataDailyTask::IsTaskCompleted
02d2bacc: tbz     w0, #0, #0x2d2baa4                         
02d2bad0: ldr     w8, [x23, #0x18]                           
02d2bad4: add     w19, w8, w19                               
02d2bad8: b       #0x2d2baa4                                 
02d2badc: ldr     x1, [x21]                                  T:type56879(k15)
02d2bae0: add     x0, sp, #0x18                              
02d2bae4: bl      #0x4690470                                 fn_4690470
02d2bae8: mov     w0, w19                                    
02d2baec: ldp     x20, x19, [sp, #0x50]                      
02d2baf0: ldp     x22, x21, [sp, #0x40]                      
02d2baf4: ldp     x30, x23, [sp, #0x30]                      
02d2baf8: add     sp, sp, #0x60                              
02d2bafc: ret                                                
02d2bb00: bl      #0x2b7105c                                 fn_2b7105c
02d2bb04: bl      #0x2b7105c                                 fn_2b7105c
02d2bb08: bl      #0x2b7105c                                 fn_2b7105c
02d2bb0c: b       #0x2d2bb18                                 
02d2bb10: b       #0x2d2bb18                                 
02d2bb14: b       #0x2d2bb18                                 
02d2bb18: mov     x20, x0                                    
02d2bb1c: cmp     w1, #1                                     
02d2bb20: b.ne    #0x2d2bb54                                 
02d2bb24: mov     x0, x20                                    
02d2bb28: bl      #0x5e90260                                 fn_5e90260
02d2bb2c: ldr     x20, [x0]                                  T:type56879(k15)
02d2bb30: str     x20, [sp, #8]                              
02d2bb34: bl      #0x5e90270                                 fn_5e90270
02d2bb38: ldr     x0, [sp, #0x10]                            
02d2bb3c: ldr     x1, [x21]                                  T:type56879(k15)
02d2bb40: bl      #0x4690470                                 fn_4690470
02d2bb44: cbz     x20, #0x2d2bae8                            
02d2bb48: mov     x0, x20                                    
02d2bb4c: bl      #0x2b71054                                 fn_2b71054
02d2bb50: mov     x20, x0                                    
02d2bb54: add     x0, sp, #8                                 
02d2bb58: bl      #0x2738168                                 fn_2738168
02d2bb5c: mov     x0, x20                                    
02d2bb60: bl      #0x2c6051c                                 fn_2c6051c
02d2bb64: bl      #0x27369b8                                 fn_27369b8
## GenerateRewardNumbers() -> System.Collections.Generic.List`1<int>
---- DailyTask.DailyTaskController::GenerateRewardNumbers 0x2d2a9c0
02d2a9c0: stp     x30, x27, [sp, #-0x50]!                    
02d2a9c4: stp     x26, x25, [sp, #0x10]                      
02d2a9c8: stp     x24, x23, [sp, #0x20]                      
02d2a9cc: stp     x22, x21, [sp, #0x30]                      
02d2a9d0: stp     x20, x19, [sp, #0x40]                      
02d2a9d4: adrp    x19, #0x6630000                            
02d2a9d8: adrp    x25, #0x6266000                            
02d2a9dc: adrp    x24, #0x6266000                            
02d2a9e0: ldrb    w8, [x19, #0xb9]                           
02d2a9e4: ldr     x25, [x25, #0x648]                         T:type15061(k15)
02d2a9e8: ldr     x24, [x24, #0x650]                         MS:System.Collections.Generic.List`1::.ctor
02d2a9ec: tbnz    w8, #0, #0x2d2aa40                         
02d2a9f0: adrp    x0, #0x6266000                             
02d2a9f4: ldr     x0, [x0, #0x818]                           MS:System.Collections.Generic.List`1::Add
02d2a9f8: bl      #0x2b70db0                                 fn_2b70db0
02d2a9fc: adrp    x0, #0x6266000                             
02d2aa00: ldr     x0, [x0, #0x650]                           MS:System.Collections.Generic.List`1::.ctor
02d2aa04: bl      #0x2b70db0                                 fn_2b70db0
02d2aa08: adrp    x0, #0x6268000                             
02d2aa0c: ldr     x0, [x0, #0xea8]                           MS:System.Collections.Generic.List`1::get_Count
02d2aa10: bl      #0x2b70db0                                 fn_2b70db0
02d2aa14: adrp    x0, #0x626a000                             
02d2aa18: ldr     x0, [x0, #0x310]                           MS:System.Collections.Generic.List`1::get_Item
02d2aa1c: bl      #0x2b70db0                                 fn_2b70db0
02d2aa20: adrp    x0, #0x626a000                             
02d2aa24: ldr     x0, [x0, #0x350]                           MS:System.Collections.Generic.List`1::set_Item
02d2aa28: bl      #0x2b70db0                                 fn_2b70db0
02d2aa2c: adrp    x0, #0x6266000                             
02d2aa30: ldr     x0, [x0, #0x648]                           T:type15061(k15)
02d2aa34: bl      #0x2b70db0                                 fn_2b70db0
02d2aa38: mov     w8, #1                                     
02d2aa3c: strb    w8, [x19, #0xb9]                           
02d2aa40: mov     w0, wzr                                    
02d2aa44: mov     w1, #0x29                                  
02d2aa48: mov     x2, xzr                                    
02d2aa4c: mov     w19, #0x29                                 
02d2aa50: bl      #0x5b2e000                                 UnityEngine.Random::Range
02d2aa54: mov     w20, w0                                    
02d2aa58: sub     w1, w19, w0                                
02d2aa5c: mov     w0, wzr                                    
02d2aa60: mov     x2, xzr                                    
02d2aa64: bl      #0x5b2e000                                 UnityEngine.Random::Range
02d2aa68: ldr     x8, [x25]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d2aa6c: mov     w21, w0                                    
02d2aa70: mov     x0, x8                                     
02d2aa74: bl      #0x2b7104c                                 fn_2b7104c
02d2aa78: ldr     x1, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d2aa7c: mov     x19, x0                                    
02d2aa80: bl      #0x3569388                                 fn_3569388
02d2aa84: cbz     x19, #0x2d2adc4                            
02d2aa88: adrp    x23, #0x6266000                            
02d2aa8c: ldr     x23, [x23, #0x818]                         MS:System.Collections.Generic.List`1::Add
02d2aa90: ldr     w10, [x19, #0x1c]                          
02d2aa94: ldr     x8, [x19, #0x10]                           
02d2aa98: ldr     x9, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d2aa9c: add     w10, w10, #1                               
02d2aaa0: str     w10, [x19, #0x1c]                          
02d2aaa4: cbz     x8, #0x2d2adc4                             
02d2aaa8: ldrsw   x10, [x19, #0x18]                          
02d2aaac: ldr     w11, [x8, #0x18]                           
02d2aab0: cmp     w10, w11                                   
02d2aab4: b.hs    #0x2d2aad8                                 
02d2aab8: add     w11, w10, #1                               
02d2aabc: add     x10, x8, x10, lsl #2                       
02d2aac0: str     w11, [x19, #0x18]                          
02d2aac4: str     w20, [x10, #0x20]                          
02d2aac8: ldr     w10, [x19, #0x1c]                          
02d2aacc: add     w10, w10, #1                               
02d2aad0: str     w10, [x19, #0x1c]                          
02d2aad4: b       #0x2d2ab08                                 
02d2aad8: ldr     x8, [x9, #0x20]                            
02d2aadc: mov     x0, x19                                    
02d2aae0: mov     w1, w20                                    
02d2aae4: ldr     x8, [x8, #0xc0]                            
02d2aae8: ldr     x2, [x8, #0x70]                            
02d2aaec: bl      #0x3569c18                                 fn_3569c18
02d2aaf0: ldr     w10, [x19, #0x1c]                          
02d2aaf4: ldr     x8, [x19, #0x10]                           
02d2aaf8: ldr     x9, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d2aafc: add     w10, w10, #1                               
02d2ab00: str     w10, [x19, #0x1c]                          
02d2ab04: cbz     x8, #0x2d2adc4                             
02d2ab08: ldrsw   x10, [x19, #0x18]                          
02d2ab0c: ldr     w11, [x8, #0x18]                           
02d2ab10: cmp     w10, w11                                   
02d2ab14: b.hs    #0x2d2ab38                                 
02d2ab18: add     w11, w10, #1                               
02d2ab1c: add     x10, x8, x10, lsl #2                       
02d2ab20: str     w11, [x19, #0x18]                          
02d2ab24: str     w21, [x10, #0x20]                          
02d2ab28: ldr     w10, [x19, #0x1c]                          
02d2ab2c: add     w10, w10, #1                               
02d2ab30: str     w10, [x19, #0x1c]                          
02d2ab34: b       #0x2d2ab68                                 
02d2ab38: ldr     x8, [x9, #0x20]                            
02d2ab3c: mov     x0, x19                                    
02d2ab40: mov     w1, w21                                    
02d2ab44: ldr     x8, [x8, #0xc0]                            
02d2ab48: ldr     x2, [x8, #0x70]                            
02d2ab4c: bl      #0x3569c18                                 fn_3569c18
02d2ab50: ldr     w10, [x19, #0x1c]                          
02d2ab54: ldr     x8, [x19, #0x10]                           
02d2ab58: ldr     x9, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d2ab5c: add     w10, w10, #1                               
02d2ab60: str     w10, [x19, #0x1c]                          
02d2ab64: cbz     x8, #0x2d2adc4                             
02d2ab68: ldrsw   x10, [x19, #0x18]                          
02d2ab6c: ldr     w11, [x8, #0x18]                           
02d2ab70: mov     w12, #0x28                                 
02d2ab74: sub     w12, w12, w20                              
02d2ab78: cmp     w10, w11                                   
02d2ab7c: sub     w1, w12, w21                               
02d2ab80: b.hs    #0x2d2ab98                                 
02d2ab84: add     x8, x8, x10, lsl #2                        
02d2ab88: add     w9, w10, #1                                
02d2ab8c: str     w9, [x19, #0x18]                           
02d2ab90: str     w1, [x8, #0x20]                            
02d2ab94: b       #0x2d2abac                                 
02d2ab98: ldr     x8, [x9, #0x20]                            
02d2ab9c: mov     x0, x19                                    
02d2aba0: ldr     x8, [x8, #0xc0]                            
02d2aba4: ldr     x2, [x8, #0x70]                            
02d2aba8: bl      #0x3569c18                                 fn_3569c18
02d2abac: ldr     w8, [x19, #0x18]                           
02d2abb0: adrp    x26, #0x626a000                            
02d2abb4: ldr     x26, [x26, #0x310]                         MS:System.Collections.Generic.List`1::get_Item
02d2abb8: cmp     w8, #1                                     
02d2abbc: b.lt    #0x2d2ac3c                                 
02d2abc0: adrp    x27, #0x626a000                            
02d2abc4: mov     w20, wzr                                   
02d2abc8: ldr     x27, [x27, #0x350]                         MS:System.Collections.Generic.List`1::set_Item
02d2abcc: ldr     x2, [x26]                                  T:type56879(k15)
02d2abd0: mov     x0, x19                                    
02d2abd4: mov     w1, w20                                    
02d2abd8: bl      #0x3569920                                 fn_3569920
02d2abdc: ldr     w1, [x19, #0x18]                           
02d2abe0: mov     w21, w0                                    
02d2abe4: mov     w0, w20                                    
02d2abe8: mov     x2, xzr                                    
02d2abec: bl      #0x5b2e000                                 UnityEngine.Random::Range
02d2abf0: ldr     x2, [x26]                                  T:type56879(k15)
02d2abf4: mov     w22, w0                                    
02d2abf8: mov     x0, x19                                    
02d2abfc: mov     w1, w22                                    
02d2ac00: bl      #0x3569920                                 fn_3569920
02d2ac04: ldr     x3, [x27]                                  T:type56879(k15)
02d2ac08: mov     w2, w0                                     
02d2ac0c: mov     x0, x19                                    
02d2ac10: mov     w1, w20                                    
02d2ac14: bl      #0x3569974                                 fn_3569974
02d2ac18: ldr     x3, [x27]                                  T:type56879(k15)
02d2ac1c: mov     x0, x19                                    
02d2ac20: mov     w1, w22                                    
02d2ac24: mov     w2, w21                                    
02d2ac28: bl      #0x3569974                                 fn_3569974
02d2ac2c: ldr     w8, [x19, #0x18]                           
02d2ac30: add     w20, w20, #1                               
02d2ac34: cmp     w20, w8                                    
02d2ac38: b.lt    #0x2d2abcc                                 
02d2ac3c: ldr     x2, [x26]                                  T:type56879(k15)
02d2ac40: mov     x0, x19                                    
02d2ac44: mov     w1, wzr                                    
02d2ac48: bl      #0x3569920                                 fn_3569920
02d2ac4c: ldr     x2, [x26]                                  T:type56879(k15)
02d2ac50: mov     w22, w0                                    
02d2ac54: mov     x0, x19                                    
02d2ac58: mov     w1, #1                                     
02d2ac5c: bl      #0x3569920                                 fn_3569920
02d2ac60: ldr     x2, [x26]                                  T:type56879(k15)
02d2ac64: mov     w21, w0                                    
02d2ac68: mov     x0, x19                                    
02d2ac6c: mov     w1, #2                                     
02d2ac70: bl      #0x3569920                                 fn_3569920
02d2ac74: ldr     x8, [x25]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d2ac78: mov     w20, w0                                    
02d2ac7c: mov     x0, x8                                     
02d2ac80: bl      #0x2b7104c                                 fn_2b7104c
02d2ac84: ldr     x1, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d2ac88: mov     x19, x0                                    
02d2ac8c: bl      #0x3569388                                 fn_3569388
02d2ac90: cbz     x19, #0x2d2adc4                            
02d2ac94: ldr     w10, [x19, #0x1c]                          
02d2ac98: ldr     x8, [x19, #0x10]                           
02d2ac9c: ldr     x9, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d2aca0: add     w10, w10, #1                               
02d2aca4: str     w10, [x19, #0x1c]                          
02d2aca8: cbz     x8, #0x2d2adc4                             
02d2acac: ldrsw   x10, [x19, #0x18]                          
02d2acb0: ldr     w11, [x8, #0x18]                           
02d2acb4: add     w1, w22, #0x14                             
02d2acb8: cmp     w10, w11                                   
02d2acbc: b.hs    #0x2d2ace0                                 
02d2acc0: add     w11, w10, #1                               
02d2acc4: add     x10, x8, x10, lsl #2                       
02d2acc8: str     w11, [x19, #0x18]                          
02d2accc: str     w1, [x10, #0x20]                           
02d2acd0: ldr     w10, [x19, #0x1c]                          
02d2acd4: add     w10, w10, #1                               
02d2acd8: str     w10, [x19, #0x1c]                          
02d2acdc: b       #0x2d2ad0c                                 
02d2ace0: ldr     x8, [x9, #0x20]                            
02d2ace4: mov     x0, x19                                    
02d2ace8: ldr     x8, [x8, #0xc0]                            
02d2acec: ldr     x2, [x8, #0x70]                            
02d2acf0: bl      #0x3569c18                                 fn_3569c18
02d2acf4: ldr     w10, [x19, #0x1c]                          
02d2acf8: ldr     x8, [x19, #0x10]                           
02d2acfc: ldr     x9, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d2ad00: add     w10, w10, #1                               
02d2ad04: str     w10, [x19, #0x1c]                          
02d2ad08: cbz     x8, #0x2d2adc4                             
02d2ad0c: ldrsw   x10, [x19, #0x18]                          
02d2ad10: ldr     w11, [x8, #0x18]                           
02d2ad14: add     w1, w21, #0x14                             
02d2ad18: cmp     w10, w11                                   
02d2ad1c: b.hs    #0x2d2ad40                                 
02d2ad20: add     w11, w10, #1                               
02d2ad24: add     x10, x8, x10, lsl #2                       
02d2ad28: str     w11, [x19, #0x18]                          
02d2ad2c: str     w1, [x10, #0x20]                           
02d2ad30: ldr     w10, [x19, #0x1c]                          
02d2ad34: add     w10, w10, #1                               
02d2ad38: str     w10, [x19, #0x1c]                          
02d2ad3c: b       #0x2d2ad6c                                 
02d2ad40: ldr     x8, [x9, #0x20]                            
02d2ad44: mov     x0, x19                                    
02d2ad48: ldr     x8, [x8, #0xc0]                            
02d2ad4c: ldr     x2, [x8, #0x70]                            
02d2ad50: bl      #0x3569c18                                 fn_3569c18
02d2ad54: ldr     w10, [x19, #0x1c]                          
02d2ad58: ldr     x8, [x19, #0x10]                           
02d2ad5c: ldr     x9, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02d2ad60: add     w10, w10, #1                               
02d2ad64: str     w10, [x19, #0x1c]                          
02d2ad68: cbz     x8, #0x2d2adc4                             
02d2ad6c: ldrsw   x10, [x19, #0x18]                          
02d2ad70: ldr     w11, [x8, #0x18]                           
02d2ad74: add     w1, w20, #0x14                             
02d2ad78: cmp     w10, w11                                   
02d2ad7c: b.hs    #0x2d2ad94                                 
02d2ad80: add     x8, x8, x10, lsl #2                        
02d2ad84: add     w9, w10, #1                                
02d2ad88: str     w9, [x19, #0x18]                           
02d2ad8c: str     w1, [x8, #0x20]                            
02d2ad90: b       #0x2d2ada8                                 
02d2ad94: ldr     x8, [x9, #0x20]                            
02d2ad98: mov     x0, x19                                    
02d2ad9c: ldr     x8, [x8, #0xc0]                            
02d2ada0: ldr     x2, [x8, #0x70]                            
02d2ada4: bl      #0x3569c18                                 fn_3569c18
02d2ada8: mov     x0, x19                                    
02d2adac: ldp     x20, x19, [sp, #0x40]                      
02d2adb0: ldp     x22, x21, [sp, #0x30]                      
02d2adb4: ldp     x24, x23, [sp, #0x20]                      
02d2adb8: ldp     x26, x25, [sp, #0x10]                      
02d2adbc: ldp     x30, x27, [sp], #0x50                      
02d2adc0: ret                                                
02d2adc4: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- DailyTask.DailyTaskController::.ctor 0x2d2bb68
02d2bb68: stp     x30, x23, [sp, #-0x30]!                    
02d2bb6c: stp     x22, x21, [sp, #0x10]                      
02d2bb70: stp     x20, x19, [sp, #0x20]                      
02d2bb74: adrp    x22, #0x6630000                            
02d2bb78: adrp    x23, #0x626a000                            
02d2bb7c: adrp    x20, #0x626a000                            
02d2bb80: adrp    x21, #0x626a000                            
02d2bb84: ldr     x23, [x23, #0x328]                         T:type15589(k15)
02d2bb88: ldrb    w8, [x22, #0xba]                           
02d2bb8c: ldr     x20, [x20, #0x330]                         MS:System.Collections.Generic.List`1::.ctor
02d2bb90: ldr     x21, [x21, #0x410]                         MS:MonoSingleton`1::.ctor
02d2bb94: mov     x19, x0                                    
02d2bb98: tbnz    w8, #0, #0x2d2bbc8                         
02d2bb9c: adrp    x0, #0x626a000                             
02d2bba0: ldr     x0, [x0, #0x330]                           MS:System.Collections.Generic.List`1::.ctor
02d2bba4: bl      #0x2b70db0                                 fn_2b70db0
02d2bba8: adrp    x0, #0x626a000                             
02d2bbac: ldr     x0, [x0, #0x328]                           T:type15589(k15)
02d2bbb0: bl      #0x2b70db0                                 fn_2b70db0
02d2bbb4: adrp    x0, #0x626a000                             
02d2bbb8: ldr     x0, [x0, #0x410]                           MS:MonoSingleton`1::.ctor
02d2bbbc: bl      #0x2b70db0                                 fn_2b70db0
02d2bbc0: mov     w8, #1                                     
02d2bbc4: strb    w8, [x22, #0xba]                           
02d2bbc8: ldr     x0, [x23]                                  T:type56879(k15)
02d2bbcc: bl      #0x2b7104c                                 fn_2b7104c
02d2bbd0: ldr     x1, [x20]                                  T:type56879(k15)
02d2bbd4: mov     x20, x0                                    
02d2bbd8: bl      #0x35a89a4                                 fn_35a89a4
02d2bbdc: mov     x0, x19                                    
02d2bbe0: mov     x1, x20                                    
02d2bbe4: str     x20, [x0, #0x48]!                          ._currentDailyTasks
02d2bbe8: bl      #0x2b70d54                                 fn_2b70d54
02d2bbec: ldr     x1, [x21]                                  T:type56879(k15)
02d2bbf0: mov     x0, x19                                    
02d2bbf4: ldp     x20, x19, [sp, #0x20]                      
02d2bbf8: ldp     x22, x21, [sp, #0x10]                      
02d2bbfc: ldp     x30, x23, [sp], #0x30                      
02d2bc00: b       #0x3769e18                                 
