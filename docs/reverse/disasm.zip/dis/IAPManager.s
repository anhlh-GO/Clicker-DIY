#### CLASS IAPManager/<InitIAP>d__16 parent= System.ValueType
#   field <>1__state                     int                                                off=0x10 attr=6 
#   field <>t__builder                   System.Runtime.CompilerServices.AsyncTaskMethodBuilder off=0x18 attr=6 
#   field <>4__this                      IAPManager                                         off=0x30 attr=6 
#   field <>u__1                         System.Runtime.CompilerServices.TaskAwaiter        off=0x38 attr=1 
## MoveNext() -> void
---- IAPManager/<InitIAP>d__16::MoveNext 0x2ca7454
02ca7454: sub     sp, sp, #0x60                              
02ca7458: str     x30, [sp, #0x20]                           
02ca745c: stp     x24, x23, [sp, #0x30]                      
02ca7460: stp     x22, x21, [sp, #0x40]                      
02ca7464: stp     x20, x19, [sp, #0x50]                      
02ca7468: adrp    x20, #0x662f000                            
02ca746c: mov     x19, x0                                    
02ca7470: ldrb    w8, [x20, #0xae7]                          
02ca7474: tbnz    w8, #0, #0x2ca75a0                         
02ca7478: adrp    x0, #0x6266000                             
02ca747c: ldr     x0, [x0, #0x470]                           T:type6787(k15)
02ca7480: bl      #0x2b70db0                                 fn_2b70db0
02ca7484: adrp    x0, #0x6266000                             
02ca7488: ldr     x0, [x0, #0x478]                           T:type6981(k15)
02ca748c: bl      #0x2b70db0                                 fn_2b70db0
02ca7490: adrp    x0, #0x6266000                             
02ca7494: ldr     x0, [x0, #0x480]                           T:type6992(k15)
02ca7498: bl      #0x2b70db0                                 fn_2b70db0
02ca749c: adrp    x0, #0x6266000                             
02ca74a0: ldr     x0, [x0, #0x488]                           T:type6872(k15)
02ca74a4: bl      #0x2b70db0                                 fn_2b70db0
02ca74a8: adrp    x0, #0x6266000                             
02ca74ac: ldr     x0, [x0, #0x490]                           T:type6974(k15)
02ca74b0: bl      #0x2b70db0                                 fn_2b70db0
02ca74b4: adrp    x0, #0x6266000                             
02ca74b8: ldr     x0, [x0, #0x498]                           T:type6977(k15)
02ca74bc: bl      #0x2b70db0                                 fn_2b70db0
02ca74c0: adrp    x0, #0x6266000                             
02ca74c4: ldr     x0, [x0, #0x4a0]                           T:type6895(k15)
02ca74c8: bl      #0x2b70db0                                 fn_2b70db0
02ca74cc: adrp    x0, #0x6266000                             
02ca74d0: ldr     x0, [x0, #0x4a8]                           T:type6995(k15)
02ca74d4: bl      #0x2b70db0                                 fn_2b70db0
02ca74d8: adrp    x0, #0x6266000                             
02ca74dc: ldr     x0, [x0, #0x4b0]                           T:type7023(k15)
02ca74e0: bl      #0x2b70db0                                 fn_2b70db0
02ca74e4: adrp    x0, #0x6266000                             
02ca74e8: ldr     x0, [x0, #0x4b8]                           MS:System.Runtime.CompilerServices.AsyncTaskMethodBuilder::AwaitUnsafeOnCompleted
02ca74ec: bl      #0x2b70db0                                 fn_2b70db0
02ca74f0: adrp    x0, #0x6264000                             
02ca74f4: ldr     x0, [x0, #0x808]                           T:System.Runtime.CompilerServices.AsyncTaskMethodBuilder
02ca74f8: bl      #0x2b70db0                                 fn_2b70db0
02ca74fc: adrp    x0, #0x6266000                             
02ca7500: ldr     x0, [x0, #0x4c0]                           M:IAPManager::OnProductsFetchFailed
02ca7504: bl      #0x2b70db0                                 fn_2b70db0
02ca7508: adrp    x0, #0x6266000                             
02ca750c: ldr     x0, [x0, #0x4c8]                           M:IAPManager::OnProductsFetched
02ca7510: bl      #0x2b70db0                                 fn_2b70db0
02ca7514: adrp    x0, #0x6266000                             
02ca7518: ldr     x0, [x0, #0x4d0]                           M:IAPManager::OnPurchaseConfirmed
02ca751c: bl      #0x2b70db0                                 fn_2b70db0
02ca7520: adrp    x0, #0x6266000                             
02ca7524: ldr     x0, [x0, #0x4d8]                           M:IAPManager::OnPurchaseDeferred
02ca7528: bl      #0x2b70db0                                 fn_2b70db0
02ca752c: adrp    x0, #0x6266000                             
02ca7530: ldr     x0, [x0, #0x4e0]                           M:IAPManager::OnPurchaseFailed
02ca7534: bl      #0x2b70db0                                 fn_2b70db0
02ca7538: adrp    x0, #0x6266000                             
02ca753c: ldr     x0, [x0, #0x4e8]                           M:IAPManager::OnPurchasePending
02ca7540: bl      #0x2b70db0                                 fn_2b70db0
02ca7544: adrp    x0, #0x6266000                             
02ca7548: ldr     x0, [x0, #0x4f0]                           M:IAPManager::OnPurchasesFetchFailed
02ca754c: bl      #0x2b70db0                                 fn_2b70db0
02ca7550: adrp    x0, #0x6266000                             
02ca7554: ldr     x0, [x0, #0x4f8]                           M:IAPManager::OnPurchasesFetched
02ca7558: bl      #0x2b70db0                                 fn_2b70db0
02ca755c: adrp    x0, #0x6266000                             
02ca7560: ldr     x0, [x0, #0x500]                           M:IAPManager::OnStoreDisconnected
02ca7564: bl      #0x2b70db0                                 fn_2b70db0
02ca7568: adrp    x0, #0x6266000                             
02ca756c: ldr     x0, [x0, #0x508]                           T:Unity.Services.Core.InitializationOptions
02ca7570: bl      #0x2b70db0                                 fn_2b70db0
02ca7574: adrp    x0, #0x6266000                             
02ca7578: ldr     x0, [x0, #0x198]                           T:LogTags
02ca757c: bl      #0x2b70db0                                 fn_2b70db0
02ca7580: adrp    x0, #0x6266000                             
02ca7584: ldr     x0, [x0, #0x510]                           T:Unity.Services.Core.UnityServices
02ca7588: bl      #0x2b70db0                                 fn_2b70db0
02ca758c: adrp    x0, #0x6266000                             
02ca7590: ldr     x0, [x0, #0x518]                           S:'Unity Services initialised.'
02ca7594: bl      #0x2b70db0                                 fn_2b70db0
02ca7598: mov     w8, #1                                     
02ca759c: strb    w8, [x20, #0xae7]                          
02ca75a0: adrp    x24, #0x6264000                            
02ca75a4: ldr     x24, [x24, #0x808]                         T:System.Runtime.CompilerServices.AsyncTaskMethodBuilder
02ca75a8: ldr     w8, [x19]                                  
02ca75ac: ldr     x20, [x19, #0x20]                          
02ca75b0: str     xzr, [sp, #0x28]                           
02ca75b4: str     wzr, [sp, #0x18]                           
02ca75b8: cbz     w8, #0x2ca75dc                             
02ca75bc: cmp     w8, #1                                     
02ca75c0: b.ne    #0x2ca75f4                                 
02ca75c4: ldr     x8, [x19, #0x28]                           
02ca75c8: mov     w9, #-1                                    
02ca75cc: str     xzr, [x19, #0x28]                          
02ca75d0: str     w9, [x19]                                  
02ca75d4: str     x8, [sp, #0x28]                            
02ca75d8: b       #0x2ca7964                                 
02ca75dc: ldr     x8, [x19, #0x28]                           
02ca75e0: mov     w9, #-1                                    
02ca75e4: str     xzr, [x19, #0x28]                          
02ca75e8: str     w9, [x19]                                  
02ca75ec: str     x8, [sp, #0x28]                            
02ca75f0: b       #0x2ca766c                                 
02ca75f4: adrp    x8, #0x6266000                             
02ca75f8: ldr     x8, [x8, #0x508]                           T:Unity.Services.Core.InitializationOptions
02ca75fc: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca7600: bl      #0x2b7104c                                 fn_2b7104c
02ca7604: mov     x1, xzr                                    
02ca7608: mov     x21, x0                                    
02ca760c: bl      #0x5a1d594                                 Unity.Services.Core.InitializationOptions::.ctor
02ca7610: cbz     x20, #0x2ca7aa0                            
02ca7614: ldr     x1, [x20, #0x28]                           [662f028]=6000015 f=2.40742e-35,0
02ca7618: mov     x0, x21                                    
02ca761c: mov     x2, xzr                                    
02ca7620: bl      #0x5a20e78                                 Unity.Services.Core.Environments.EnvironmentsOptionsExtensions::SetEnvironmentName
02ca7624: adrp    x8, #0x6266000                             
02ca7628: mov     x21, x0                                    
02ca762c: ldr     x8, [x8, #0x510]                           T:Unity.Services.Core.UnityServices
02ca7630: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca7634: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02ca7638: cbnz    w8, #0x2ca7640                             
02ca763c: bl      #0x2b70f30                                 fn_2b70f30
02ca7640: mov     x0, x21                                    
02ca7644: mov     x1, xzr                                    
02ca7648: bl      #0x5a1ead4                                 Unity.Services.Core.UnityServices::InitializeAsync
02ca764c: cbz     x0, #0x2ca7aa4                             
02ca7650: mov     x1, xzr                                    
02ca7654: bl      #0x4e85740                                 System.Threading.Tasks.Task::GetAwaiter
02ca7658: str     x0, [sp, #0x28]                            
02ca765c: add     x0, sp, #0x28                              
02ca7660: mov     x1, xzr                                    
02ca7664: bl      #0x4d43364                                 System.Runtime.CompilerServices.TaskAwaiter::get_IsCompleted
02ca7668: tbz     w0, #0, #0x2ca7a0c                         
02ca766c: add     x0, sp, #0x28                              
02ca7670: mov     x1, xzr                                    
02ca7674: bl      #0x4d4342c                                 System.Runtime.CompilerServices.TaskAwaiter::GetResult
02ca7678: adrp    x21, #0x6266000                            
02ca767c: ldr     x21, [x21, #0x198]                         T:LogTags
02ca7680: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca7684: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02ca7688: cbnz    w8, #0x2ca7694                             
02ca768c: bl      #0x2b70f30                                 fn_2b70f30
02ca7690: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca7694: adrp    x9, #0x6266000                             
02ca7698: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time'
02ca769c: ldr     x9, [x9, #0x518]                           S:'Unity Services initialised.'
02ca76a0: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca76a4: ldr     x1, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca76a8: bl      #0x2ca4738                                 WLog::Log
02ca76ac: mov     x0, xzr                                    
02ca76b0: mov     x1, xzr                                    
02ca76b4: bl      #0x571a730                                 UnityEngine.Purchasing.UnityIAPServices::StoreController
02ca76b8: mov     x1, x0                                     
02ca76bc: cbz     x20, #0x2ca7a70                            
02ca76c0: mov     x21, x20                                   
02ca76c4: str     x1, [x21, #0x38]!                          .<>u__1
02ca76c8: mov     x0, x21                                    
02ca76cc: bl      #0x2b70d54                                 fn_2b70d54
02ca76d0: adrp    x8, #0x6266000                             
02ca76d4: ldr     x8, [x8, #0x4b0]                           T:type7023(k15)
02ca76d8: ldr     x22, [x21]                                 M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca76dc: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca76e0: bl      #0x2b7104c                                 fn_2b7104c
02ca76e4: adrp    x8, #0x6266000                             
02ca76e8: mov     x23, x0                                    
02ca76ec: ldr     x8, [x8, #0x500]                           M:IAPManager::OnStoreDisconnected
02ca76f0: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca76f4: mov     x1, x20                                    
02ca76f8: mov     x3, xzr                                    
02ca76fc: bl      #0x453418c                                 fn_453418c
02ca7700: cbz     x22, #0x2ca7a74                            
02ca7704: mov     x0, x22                                    
02ca7708: mov     x1, x23                                    
02ca770c: mov     x2, xzr                                    
02ca7710: bl      #0x5718ba8                                 UnityEngine.Purchasing.StoreController::add_OnStoreDisconnected
02ca7714: adrp    x8, #0x6266000                             
02ca7718: ldr     x8, [x8, #0x470]                           T:type6787(k15)
02ca771c: ldr     x22, [x21]                                 M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca7720: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca7724: bl      #0x2b7104c                                 fn_2b7104c
02ca7728: adrp    x8, #0x6266000                             
02ca772c: mov     x23, x0                                    
02ca7730: ldr     x8, [x8, #0x4c8]                           M:IAPManager::OnProductsFetched
02ca7734: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca7738: mov     x1, x20                                    
02ca773c: mov     x3, xzr                                    
02ca7740: bl      #0x453418c                                 fn_453418c
02ca7744: cbz     x22, #0x2ca7a78                            
02ca7748: mov     x0, x22                                    
02ca774c: mov     x1, x23                                    
02ca7750: mov     x2, xzr                                    
02ca7754: bl      #0x5719a70                                 UnityEngine.Purchasing.StoreController::add_OnProductsFetched
02ca7758: adrp    x8, #0x6266000                             
02ca775c: ldr     x8, [x8, #0x480]                           T:type6992(k15)
02ca7760: ldr     x22, [x21]                                 M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca7764: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca7768: bl      #0x2b7104c                                 fn_2b7104c
02ca776c: adrp    x8, #0x6266000                             
02ca7770: mov     x23, x0                                    
02ca7774: ldr     x8, [x8, #0x4c0]                           M:IAPManager::OnProductsFetchFailed
02ca7778: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca777c: mov     x1, x20                                    
02ca7780: mov     x3, xzr                                    
02ca7784: bl      #0x453418c                                 fn_453418c
02ca7788: cbz     x22, #0x2ca7a7c                            
02ca778c: mov     x0, x22                                    
02ca7790: mov     x1, x23                                    
02ca7794: mov     x2, xzr                                    
02ca7798: bl      #0x5719bc8                                 UnityEngine.Purchasing.StoreController::add_OnProductsFetchFailed
02ca779c: adrp    x8, #0x6266000                             
02ca77a0: ldr     x8, [x8, #0x498]                           T:type6977(k15)
02ca77a4: ldr     x22, [x21]                                 M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca77a8: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca77ac: bl      #0x2b7104c                                 fn_2b7104c
02ca77b0: adrp    x8, #0x6266000                             
02ca77b4: mov     x23, x0                                    
02ca77b8: ldr     x8, [x8, #0x4f8]                           M:IAPManager::OnPurchasesFetched
02ca77bc: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca77c0: mov     x1, x20                                    
02ca77c4: mov     x3, xzr                                    
02ca77c8: bl      #0x453418c                                 fn_453418c
02ca77cc: cbz     x22, #0x2ca7a80                            
02ca77d0: mov     x0, x22                                    
02ca77d4: mov     x1, x23                                    
02ca77d8: mov     x2, xzr                                    
02ca77dc: bl      #0x57195bc                                 UnityEngine.Purchasing.StoreController::add_OnPurchasesFetched
02ca77e0: adrp    x8, #0x6266000                             
02ca77e4: ldr     x8, [x8, #0x4a8]                           T:type6995(k15)
02ca77e8: ldr     x22, [x21]                                 M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca77ec: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca77f0: bl      #0x2b7104c                                 fn_2b7104c
02ca77f4: adrp    x8, #0x6266000                             
02ca77f8: mov     x23, x0                                    
02ca77fc: ldr     x8, [x8, #0x4f0]                           M:IAPManager::OnPurchasesFetchFailed
02ca7800: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca7804: mov     x1, x20                                    
02ca7808: mov     x3, xzr                                    
02ca780c: bl      #0x453418c                                 fn_453418c
02ca7810: cbz     x22, #0x2ca7a84                            
02ca7814: mov     x0, x22                                    
02ca7818: mov     x1, x23                                    
02ca781c: mov     x2, xzr                                    
02ca7820: bl      #0x5719714                                 UnityEngine.Purchasing.StoreController::add_OnPurchasesFetchFailed
02ca7824: adrp    x8, #0x6266000                             
02ca7828: ldr     x8, [x8, #0x478]                           T:type6981(k15)
02ca782c: ldr     x22, [x21]                                 M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca7830: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca7834: bl      #0x2b7104c                                 fn_2b7104c
02ca7838: adrp    x8, #0x6266000                             
02ca783c: mov     x23, x0                                    
02ca7840: ldr     x8, [x8, #0x4e8]                           M:IAPManager::OnPurchasePending
02ca7844: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca7848: mov     x1, x20                                    
02ca784c: mov     x3, xzr                                    
02ca7850: bl      #0x453418c                                 fn_453418c
02ca7854: cbz     x22, #0x2ca7a88                            
02ca7858: mov     x0, x22                                    
02ca785c: mov     x1, x23                                    
02ca7860: mov     x2, xzr                                    
02ca7864: bl      #0x571905c                                 UnityEngine.Purchasing.StoreController::add_OnPurchasePending
02ca7868: adrp    x8, #0x6266000                             
02ca786c: ldr     x8, [x8, #0x490]                           T:type6974(k15)
02ca7870: ldr     x22, [x21]                                 M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca7874: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca7878: bl      #0x2b7104c                                 fn_2b7104c
02ca787c: adrp    x8, #0x6266000                             
02ca7880: mov     x23, x0                                    
02ca7884: ldr     x8, [x8, #0x4d0]                           M:IAPManager::OnPurchaseConfirmed
02ca7888: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca788c: mov     x1, x20                                    
02ca7890: mov     x3, xzr                                    
02ca7894: bl      #0x453418c                                 fn_453418c
02ca7898: cbz     x22, #0x2ca7a8c                            
02ca789c: mov     x0, x22                                    
02ca78a0: mov     x1, x23                                    
02ca78a4: mov     x2, xzr                                    
02ca78a8: bl      #0x57191b4                                 UnityEngine.Purchasing.StoreController::add_OnPurchaseConfirmed
02ca78ac: adrp    x8, #0x6266000                             
02ca78b0: ldr     x8, [x8, #0x4a0]                           T:type6895(k15)
02ca78b4: ldr     x22, [x21]                                 M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca78b8: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca78bc: bl      #0x2b7104c                                 fn_2b7104c
02ca78c0: adrp    x8, #0x6266000                             
02ca78c4: mov     x23, x0                                    
02ca78c8: ldr     x8, [x8, #0x4e0]                           M:IAPManager::OnPurchaseFailed
02ca78cc: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca78d0: mov     x1, x20                                    
02ca78d4: mov     x3, xzr                                    
02ca78d8: bl      #0x453418c                                 fn_453418c
02ca78dc: cbz     x22, #0x2ca7a90                            
02ca78e0: mov     x0, x22                                    
02ca78e4: mov     x1, x23                                    
02ca78e8: mov     x2, xzr                                    
02ca78ec: bl      #0x571930c                                 UnityEngine.Purchasing.StoreController::add_OnPurchaseFailed
02ca78f0: adrp    x8, #0x6266000                             
02ca78f4: ldr     x8, [x8, #0x488]                           T:type6872(k15)
02ca78f8: ldr     x22, [x21]                                 M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca78fc: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca7900: bl      #0x2b7104c                                 fn_2b7104c
02ca7904: adrp    x8, #0x6266000                             
02ca7908: mov     x23, x0                                    
02ca790c: ldr     x8, [x8, #0x4d8]                           M:IAPManager::OnPurchaseDeferred
02ca7910: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca7914: mov     x1, x20                                    
02ca7918: mov     x3, xzr                                    
02ca791c: bl      #0x453418c                                 fn_453418c
02ca7920: cbz     x22, #0x2ca7a94                            
02ca7924: mov     x0, x22                                    
02ca7928: mov     x1, x23                                    
02ca792c: mov     x2, xzr                                    
02ca7930: bl      #0x5719464                                 UnityEngine.Purchasing.StoreController::add_OnPurchaseDeferred
02ca7934: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca7938: cbz     x0, #0x2ca7a98                             
02ca793c: mov     x1, xzr                                    
02ca7940: bl      #0x5719d20                                 UnityEngine.Purchasing.StoreController::Connect
02ca7944: cbz     x0, #0x2ca7a9c                             
02ca7948: mov     x1, xzr                                    
02ca794c: bl      #0x4e85740                                 System.Threading.Tasks.Task::GetAwaiter
02ca7950: str     x0, [sp, #0x28]                            
02ca7954: add     x0, sp, #0x28                              
02ca7958: mov     x1, xzr                                    
02ca795c: bl      #0x4d43364                                 System.Runtime.CompilerServices.TaskAwaiter::get_IsCompleted
02ca7960: tbz     w0, #0, #0x2ca79c0                         
02ca7964: add     x0, sp, #0x28                              
02ca7968: mov     x1, xzr                                    
02ca796c: bl      #0x4d4342c                                 System.Runtime.CompilerServices.TaskAwaiter::GetResult
02ca7970: cbz     x20, #0x2ca7a68                            
02ca7974: ldr     x21, [x20, #0x38]                          [662f038]=6000016 f=2.40742e-35,0 .<>u__1
02ca7978: mov     x0, x20                                    
02ca797c: bl      #0x2ca4dd8                                 IAPManager::BuildProductDefinitions
02ca7980: mov     x1, x0                                     
02ca7984: cbz     x21, #0x2ca7a6c                            
02ca7988: mov     x0, x21                                    
02ca798c: mov     x2, xzr                                    
02ca7990: mov     x3, xzr                                    
02ca7994: bl      #0x5719fc0                                 UnityEngine.Purchasing.StoreController::FetchProducts
02ca7998: ldr     x0, [x24]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca799c: mov     w9, #-2                                    
02ca79a0: str     w9, [x19], #8                              
02ca79a4: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02ca79a8: cbnz    w8, #0x2ca79b0                             
02ca79ac: bl      #0x2b70f30                                 fn_2b70f30
02ca79b0: mov     x0, x19                                    
02ca79b4: mov     x1, xzr                                    
02ca79b8: bl      #0x4d44198                                 System.Runtime.CompilerServices.AsyncTaskMethodBuilder::SetResult
02ca79bc: b       #0x2ca7a50                                 
02ca79c0: ldr     x9, [sp, #0x28]                            
02ca79c4: mov     w8, #1                                     
02ca79c8: mov     x0, x19                                    
02ca79cc: str     w8, [x19]                                  
02ca79d0: str     x9, [x0, #0x28]!                           
02ca79d4: mov     x1, xzr                                    
02ca79d8: bl      #0x2b70d54                                 fn_2b70d54
02ca79dc: ldr     x0, [x24]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca79e0: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02ca79e4: cbnz    w8, #0x2ca79ec                             
02ca79e8: bl      #0x2b70f30                                 fn_2b70f30
02ca79ec: adrp    x8, #0x6266000                             
02ca79f0: ldr     x8, [x8, #0x4b8]                           MS:System.Runtime.CompilerServices.AsyncTaskMethodBuilder::AwaitUnsafeOnCompleted
02ca79f4: ldr     x3, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca79f8: add     x0, x19, #8                                
02ca79fc: add     x1, sp, #0x28                              
02ca7a00: mov     x2, x19                                    
02ca7a04: bl      #0x30a8d0c                                 fn_30a8d0c
02ca7a08: b       #0x2ca7a50                                 
02ca7a0c: ldr     x8, [sp, #0x28]                            
02ca7a10: mov     x0, x19                                    
02ca7a14: str     wzr, [x19]                                 
02ca7a18: str     x8, [x0, #0x28]!                           
02ca7a1c: mov     x1, xzr                                    
02ca7a20: bl      #0x2b70d54                                 fn_2b70d54
02ca7a24: ldr     x0, [x24]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca7a28: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02ca7a2c: cbnz    w8, #0x2ca7a34                             
02ca7a30: bl      #0x2b70f30                                 fn_2b70f30
02ca7a34: adrp    x8, #0x6266000                             
02ca7a38: ldr     x8, [x8, #0x4b8]                           MS:System.Runtime.CompilerServices.AsyncTaskMethodBuilder::AwaitUnsafeOnCompleted
02ca7a3c: ldr     x3, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca7a40: add     x0, x19, #8                                
02ca7a44: add     x1, sp, #0x28                              
02ca7a48: mov     x2, x19                                    
02ca7a4c: bl      #0x30a8d0c                                 fn_30a8d0c
02ca7a50: ldp     x20, x19, [sp, #0x50]                      
02ca7a54: ldr     x30, [sp, #0x20]                           
02ca7a58: ldp     x22, x21, [sp, #0x40]                      
02ca7a5c: ldp     x24, x23, [sp, #0x30]                      
02ca7a60: add     sp, sp, #0x60                              
02ca7a64: ret                                                
02ca7a68: bl      #0x2b7105c                                 fn_2b7105c
02ca7a6c: bl      #0x2b7105c                                 fn_2b7105c
02ca7a70: bl      #0x2b7105c                                 fn_2b7105c
02ca7a74: bl      #0x2b7105c                                 fn_2b7105c
02ca7a78: bl      #0x2b7105c                                 fn_2b7105c
02ca7a7c: bl      #0x2b7105c                                 fn_2b7105c
02ca7a80: bl      #0x2b7105c                                 fn_2b7105c
02ca7a84: bl      #0x2b7105c                                 fn_2b7105c
02ca7a88: bl      #0x2b7105c                                 fn_2b7105c
02ca7a8c: bl      #0x2b7105c                                 fn_2b7105c
02ca7a90: bl      #0x2b7105c                                 fn_2b7105c
02ca7a94: bl      #0x2b7105c                                 fn_2b7105c
02ca7a98: bl      #0x2b7105c                                 fn_2b7105c
02ca7a9c: bl      #0x2b7105c                                 fn_2b7105c
02ca7aa0: bl      #0x2b7105c                                 fn_2b7105c
02ca7aa4: bl      #0x2b7105c                                 fn_2b7105c
02ca7aa8: b       #0x2ca7b10                                 
02ca7aac: b       #0x2ca7b10                                 
02ca7ab0: b       #0x2ca7b10                                 
02ca7ab4: b       #0x2ca7b10                                 
02ca7ab8: b       #0x2ca7b10                                 
02ca7abc: b       #0x2ca7b10                                 
02ca7ac0: b       #0x2ca7b10                                 
02ca7ac4: b       #0x2ca7b10                                 
02ca7ac8: b       #0x2ca7b10                                 
02ca7acc: b       #0x2ca7b10                                 
02ca7ad0: b       #0x2ca7b10                                 
02ca7ad4: b       #0x2ca7b10                                 
02ca7ad8: b       #0x2ca7b10                                 
02ca7adc: b       #0x2ca7b10                                 
02ca7ae0: b       #0x2ca7b10                                 
02ca7ae4: b       #0x2ca7b10                                 
02ca7ae8: b       #0x2ca7b10                                 
02ca7aec: b       #0x2ca7b10                                 
02ca7af0: b       #0x2ca7b10                                 
02ca7af4: b       #0x2ca7b10                                 
02ca7af8: b       #0x2ca7b10                                 
02ca7afc: b       #0x2ca7b10                                 
02ca7b00: b       #0x2ca7b10                                 
02ca7b04: b       #0x2ca7b10                                 
02ca7b08: b       #0x2ca7b10                                 
02ca7b0c: b       #0x2ca7b10                                 
02ca7b10: mov     x20, x0                                    
02ca7b14: cmp     w1, #1                                     
02ca7b18: b.ne    #0x2ca7c3c                                 
02ca7b1c: mov     x0, x20                                    
02ca7b20: bl      #0x5e90260                                 fn_5e90260
02ca7b24: mov     x20, x0                                    
02ca7b28: adrp    x0, #0x6263000                             
02ca7b2c: ldr     x0, [x0, #0xae0]                           T:System.Exception
02ca7b30: bl      #0x2b70dc4                                 fn_2b70dc4
02ca7b34: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02ca7b38: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca7b3c: bl      #0x2b71464                                 fn_2b71464
02ca7b40: tbz     w0, #0, #0x2ca7bec                         
02ca7b44: ldrsw   x23, [sp, #0x18]                           
02ca7b48: ldr     x20, [x20]                                 &2b706c4(=eb01011ff9400808)
02ca7b4c: add     x8, sp, #8                                 
02ca7b50: str     x20, [x8, x23, lsl #3]                     
02ca7b54: add     w8, w23, #1                                
02ca7b58: str     w8, [sp, #0x18]                            
02ca7b5c: bl      #0x5e90270                                 fn_5e90270
02ca7b60: adrp    x0, #0x6266000                             
02ca7b64: ldr     x0, [x0, #0x198]                           T:LogTags
02ca7b68: bl      #0x2b70dc4                                 fn_2b70dc4
02ca7b6c: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02ca7b70: cbnz    w8, #0x2ca7b78                             
02ca7b74: bl      #0x2b70f30                                 fn_2b70f30
02ca7b78: adrp    x0, #0x6266000                             
02ca7b7c: ldr     x0, [x0, #0x198]                           T:LogTags
02ca7b80: bl      #0x2b70dc4                                 fn_2b70dc4
02ca7b84: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time'
02ca7b88: ldr     x21, [x8]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca7b8c: cbz     x20, #0x2ca7bb8                            
02ca7b90: adrp    x0, #0x6266000                             
02ca7b94: ldr     x0, [x0, #0x520]                           S:'Initialisation error: '
02ca7b98: bl      #0x2b70dc4                                 fn_2b70dc4
02ca7b9c: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02ca7ba0: mov     x22, x0                                    
02ca7ba4: ldp     x9, x1, [x8, #0x168]                       
02ca7ba8: mov     x0, x20                                    
02ca7bac: blr     x9                                         
02ca7bb0: mov     x1, x0                                     
02ca7bb4: b       #0x2ca7bcc                                 
02ca7bb8: adrp    x0, #0x6266000                             
02ca7bbc: ldr     x0, [x0, #0x520]                           S:'Initialisation error: '
02ca7bc0: bl      #0x2b70dc4                                 fn_2b70dc4
02ca7bc4: mov     x22, x0                                    
02ca7bc8: mov     x1, xzr                                    
02ca7bcc: mov     x0, x22                                    
02ca7bd0: mov     x2, xzr                                    
02ca7bd4: bl      #0x4c9c514                                 System.String::Concat
02ca7bd8: mov     x1, x0                                     
02ca7bdc: mov     x0, x21                                    
02ca7be0: bl      #0x2ca47ec                                 WLog::LogError
02ca7be4: str     w23, [sp, #0x18]                           
02ca7be8: b       #0x2ca7998                                 
02ca7bec: mov     w0, #8                                     
02ca7bf0: bl      #0x5e90290                                 fn_5e90290
02ca7bf4: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02ca7bf8: str     x8, [x0]                                   
02ca7bfc: adrp    x1, #0x5e96000                             
02ca7c00: add     x1, x1, #0x758                             &5e96758
02ca7c04: mov     x2, xzr                                    
02ca7c08: bl      #0x5e902a0                                 fn_5e902a0
02ca7c0c: b       #0x2ca7ce4                                 
02ca7c10: b       #0x2ca7c24                                 
02ca7c14: b       #0x2ca7c24                                 
02ca7c18: b       #0x2ca7c24                                 
02ca7c1c: b       #0x2ca7c24                                 
02ca7c20: b       #0x2ca7c24                                 
02ca7c24: mov     x20, x0                                    
02ca7c28: b       #0x2ca7c3c                                 
02ca7c2c: mov     x21, x1                                    
02ca7c30: mov     x20, x0                                    
02ca7c34: bl      #0x5e90270                                 fn_5e90270
02ca7c38: mov     w1, w21                                    
02ca7c3c: mov     w8, #1                                     
02ca7c40: cmp     w1, w8                                     
02ca7c44: b.ne    #0x2ca7cec                                 
02ca7c48: mov     x0, x20                                    
02ca7c4c: bl      #0x5e90260                                 fn_5e90260
02ca7c50: mov     x20, x0                                    
02ca7c54: adrp    x0, #0x6263000                             
02ca7c58: ldr     x0, [x0, #0xae0]                           T:System.Exception
02ca7c5c: bl      #0x2b70dc4                                 fn_2b70dc4
02ca7c60: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02ca7c64: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca7c68: bl      #0x2b71464                                 fn_2b71464
02ca7c6c: tbz     w0, #0, #0x2ca7cc4                         
02ca7c70: ldrsw   x21, [sp, #0x18]                           
02ca7c74: ldr     x20, [x20]                                 &2b706c4(=eb01011ff9400808)
02ca7c78: add     x8, sp, #8                                 
02ca7c7c: str     x20, [x8, x21, lsl #3]                     
02ca7c80: add     w8, w21, #1                                
02ca7c84: str     w8, [sp, #0x18]                            
02ca7c88: bl      #0x5e90270                                 fn_5e90270
02ca7c8c: mov     w8, #-2                                    
02ca7c90: adrp    x0, #0x6264000                             
02ca7c94: str     w8, [x19], #8                              
02ca7c98: ldr     x0, [x0, #0x808]                           T:System.Runtime.CompilerServices.AsyncTaskMethodBuilder
02ca7c9c: bl      #0x2b70dc4                                 fn_2b70dc4
02ca7ca0: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca7ca4: cbnz    w8, #0x2ca7cac                             
02ca7ca8: bl      #0x2b70f30                                 fn_2b70f30
02ca7cac: mov     x0, x19                                    
02ca7cb0: mov     x1, x20                                    
02ca7cb4: mov     x2, xzr                                    
02ca7cb8: bl      #0x4d4423c                                 System.Runtime.CompilerServices.AsyncTaskMethodBuilder::SetException
02ca7cbc: str     w21, [sp, #0x18]                           
02ca7cc0: b       #0x2ca7a50                                 
02ca7cc4: mov     w0, #8                                     
02ca7cc8: bl      #0x5e90290                                 fn_5e90290
02ca7ccc: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02ca7cd0: str     x8, [x0]                                   
02ca7cd4: adrp    x1, #0x5e96000                             
02ca7cd8: add     x1, x1, #0x758                             &5e96758
02ca7cdc: mov     x2, xzr                                    
02ca7ce0: bl      #0x5e902a0                                 fn_5e902a0
02ca7ce4: mov     x20, x0                                    
02ca7ce8: bl      #0x5e90270                                 fn_5e90270
02ca7cec: mov     x0, x20                                    
02ca7cf0: bl      #0x2c6051c                                 fn_2c6051c
02ca7cf4: bl      #0x27369b8                                 fn_27369b8
02ca7cf8: mov     x20, x0                                    
02ca7cfc: b       #0x2ca7b14                                 
## SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine stateMachine) -> void
---- IAPManager/<InitIAP>d__16::SetStateMachine 0x2ca7d00
02ca7d00: str     x30, [sp, #-0x30]!                         
02ca7d04: stp     x22, x21, [sp, #0x10]                      
02ca7d08: stp     x20, x19, [sp, #0x20]                      
02ca7d0c: adrp    x21, #0x662f000                            
02ca7d10: adrp    x22, #0x6264000                            
02ca7d14: mov     x19, x1                                    
02ca7d18: ldrb    w8, [x21, #0xae8]                          
02ca7d1c: ldr     x22, [x22, #0x808]                         T:System.Runtime.CompilerServices.AsyncTaskMethodBuilder
02ca7d20: mov     x20, x0                                    
02ca7d24: tbnz    w8, #0, #0x2ca7d3c                         
02ca7d28: adrp    x0, #0x6264000                             
02ca7d2c: ldr     x0, [x0, #0x808]                           T:System.Runtime.CompilerServices.AsyncTaskMethodBuilder
02ca7d30: bl      #0x2b70db0                                 fn_2b70db0
02ca7d34: mov     w8, #1                                     
02ca7d38: strb    w8, [x21, #0xae8]                          
02ca7d3c: ldr     x0, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca7d40: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca7d44: cbnz    w8, #0x2ca7d4c                             
02ca7d48: bl      #0x2b70f30                                 fn_2b70f30
02ca7d4c: add     x0, x20, #8                                
02ca7d50: mov     x1, x19                                    
02ca7d54: mov     x2, xzr                                    
02ca7d58: ldp     x20, x19, [sp, #0x20]                      
02ca7d5c: ldp     x22, x21, [sp, #0x10]                      
02ca7d60: ldr     x30, [sp], #0x30                           
02ca7d64: b       #0x4d440b0                                 System.Runtime.CompilerServices.AsyncTaskMethodBuilder::SetStateMachine
#### CLASS IAPManager/<Start>d__15 parent= System.ValueType
#   field <>1__state                     int                                                off=0x10 attr=6 
#   field <>t__builder                   System.Runtime.CompilerServices.AsyncVoidMethodBuilder off=0x18 attr=6 
#   field <>4__this                      IAPManager                                         off=0x38 attr=6 
#   field <>u__1                         System.Runtime.CompilerServices.TaskAwaiter        off=0x40 attr=1 
## MoveNext() -> void
---- IAPManager/<Start>d__15::MoveNext 0x2ca7d68
02ca7d68: sub     sp, sp, #0x40                              
02ca7d6c: stp     x30, x21, [sp, #0x20]                      
02ca7d70: stp     x20, x19, [sp, #0x30]                      
02ca7d74: adrp    x20, #0x662f000                            
02ca7d78: mov     x19, x0                                    
02ca7d7c: ldrb    w8, [x20, #0xae9]                          
02ca7d80: tbnz    w8, #0, #0x2ca7d98                         
02ca7d84: adrp    x0, #0x6266000                             
02ca7d88: ldr     x0, [x0, #0x528]                           MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::AwaitUnsafeOnCompleted
02ca7d8c: bl      #0x2b70db0                                 fn_2b70db0
02ca7d90: mov     w8, #1                                     
02ca7d94: strb    w8, [x20, #0xae9]                          
02ca7d98: ldr     w8, [x19]                                  
02ca7d9c: str     xzr, [sp, #0x18]                           
02ca7da0: str     wzr, [sp, #0x10]                           
02ca7da4: cbz     w8, #0x2ca7e0c                             
02ca7da8: ldr     x0, [x19, #0x28]                           
02ca7dac: cbz     x0, #0x2ca7e50                             
02ca7db0: bl      #0x2ca4d00                                 IAPManager::InitIAP
02ca7db4: cbz     x0, #0x2ca7e54                             
02ca7db8: mov     x1, xzr                                    
02ca7dbc: bl      #0x4e85740                                 System.Threading.Tasks.Task::GetAwaiter
02ca7dc0: str     x0, [sp, #0x18]                            
02ca7dc4: add     x0, sp, #0x18                              
02ca7dc8: mov     x1, xzr                                    
02ca7dcc: bl      #0x4d43364                                 System.Runtime.CompilerServices.TaskAwaiter::get_IsCompleted
02ca7dd0: tbnz    w0, #0, #0x2ca7e20                         
02ca7dd4: ldr     x8, [sp, #0x18]                            
02ca7dd8: mov     x0, x19                                    
02ca7ddc: str     wzr, [x19]                                 
02ca7de0: str     x8, [x0, #0x30]!                           
02ca7de4: mov     x1, xzr                                    
02ca7de8: bl      #0x2b70d54                                 fn_2b70d54
02ca7dec: adrp    x8, #0x6266000                             
02ca7df0: ldr     x8, [x8, #0x528]                           MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::AwaitUnsafeOnCompleted
02ca7df4: ldr     x3, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca7df8: add     x0, x19, #8                                
02ca7dfc: add     x1, sp, #0x18                              
02ca7e00: mov     x2, x19                                    
02ca7e04: bl      #0x30be058                                 fn_30be058
02ca7e08: b       #0x2ca7e40                                 
02ca7e0c: ldr     x8, [x19, #0x30]                           
02ca7e10: mov     w9, #-1                                    
02ca7e14: str     xzr, [x19, #0x30]                          
02ca7e18: str     w9, [x19]                                  
02ca7e1c: str     x8, [sp, #0x18]                            
02ca7e20: add     x0, sp, #0x18                              
02ca7e24: mov     x1, xzr                                    
02ca7e28: bl      #0x4d4342c                                 System.Runtime.CompilerServices.TaskAwaiter::GetResult
02ca7e2c: mov     w8, #-2                                    
02ca7e30: mov     x1, xzr                                    
02ca7e34: str     w8, [x19], #8                              
02ca7e38: mov     x0, x19                                    
02ca7e3c: bl      #0x4d43b50                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::SetResult
02ca7e40: ldp     x20, x19, [sp, #0x30]                      
02ca7e44: ldp     x30, x21, [sp, #0x20]                      
02ca7e48: add     sp, sp, #0x40                              
02ca7e4c: ret                                                
02ca7e50: bl      #0x2b7105c                                 fn_2b7105c
02ca7e54: bl      #0x2b7105c                                 fn_2b7105c
02ca7e58: b       #0x2ca7e70                                 
02ca7e5c: b       #0x2ca7e70                                 
02ca7e60: b       #0x2ca7e70                                 
02ca7e64: b       #0x2ca7e70                                 
02ca7e68: b       #0x2ca7e70                                 
02ca7e6c: b       #0x2ca7e70                                 
02ca7e70: mov     x20, x0                                    
02ca7e74: cmp     w1, #1                                     
02ca7e78: b.ne    #0x2ca7f08                                 
02ca7e7c: mov     x0, x20                                    
02ca7e80: bl      #0x5e90260                                 fn_5e90260
02ca7e84: mov     x20, x0                                    
02ca7e88: adrp    x0, #0x6263000                             
02ca7e8c: ldr     x0, [x0, #0xae0]                           T:System.Exception
02ca7e90: bl      #0x2b70dc4                                 fn_2b70dc4
02ca7e94: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02ca7e98: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca7e9c: bl      #0x2b71464                                 fn_2b71464
02ca7ea0: tbz     w0, #0, #0x2ca7ee0                         
02ca7ea4: ldrsw   x21, [sp, #0x10]                           
02ca7ea8: ldr     x20, [x20]                                 &2b706c4(=eb01011ff9400808)
02ca7eac: add     x8, sp, #8                                 
02ca7eb0: str     x20, [x8, x21, lsl #3]                     
02ca7eb4: add     w8, w21, #1                                
02ca7eb8: str     w8, [sp, #0x10]                            
02ca7ebc: bl      #0x5e90270                                 fn_5e90270
02ca7ec0: mov     w8, #-2                                    
02ca7ec4: mov     x1, x20                                    
02ca7ec8: mov     x2, xzr                                    
02ca7ecc: str     w8, [x19], #8                              
02ca7ed0: mov     x0, x19                                    
02ca7ed4: bl      #0x4d43cc0                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::SetException
02ca7ed8: str     w21, [sp, #0x10]                           
02ca7edc: b       #0x2ca7e40                                 
02ca7ee0: mov     w0, #8                                     
02ca7ee4: bl      #0x5e90290                                 fn_5e90290
02ca7ee8: ldr     x8, [x20]                                  &2b706c4(=eb01011ff9400808)
02ca7eec: str     x8, [x0]                                   
02ca7ef0: adrp    x1, #0x5e96000                             
02ca7ef4: add     x1, x1, #0x758                             &5e96758
02ca7ef8: mov     x2, xzr                                    
02ca7efc: bl      #0x5e902a0                                 fn_5e902a0
02ca7f00: mov     x20, x0                                    
02ca7f04: bl      #0x5e90270                                 fn_5e90270
02ca7f08: mov     x0, x20                                    
02ca7f0c: bl      #0x2c6051c                                 fn_2c6051c
02ca7f10: bl      #0x27369b8                                 fn_27369b8
## SetStateMachine(System.Runtime.CompilerServices.IAsyncStateMachine stateMachine) -> void
---- IAPManager/<Start>d__15::SetStateMachine 0x2ca7f14
02ca7f14: add     x0, x0, #8                                 
02ca7f18: mov     x2, xzr                                    
02ca7f1c: b       #0x4d43a8c                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::SetStateMachine
#### CLASS IAPManager parent= WejoyService.Singleton`1<IAPManager>
#   field _iAPProductSO                  IAPProductSO                                       off=0x20 attr=1 SerializeField
#   field _environment                   string                                             off=0x28 attr=1 SerializeField
#   field _isInit                        bool                                               off=0x30 attr=1 
#   field _storeController               UnityEngine.Purchasing.StoreController             off=0x38 attr=1 
#   field _purchasedProductIds           System.Collections.Generic.HashSet`1<string>       off=0x40 attr=21 
#   field OnIAPReady                     System.Action                                      off=0x48 attr=1 CompilerGeneratedAttribute
#   field OnProductPurchased             System.Action`2<IAPKey,int>                        off=0x50 attr=1 CompilerGeneratedAttribute
#   field _pendingSuccessCallbacks       System.Collections.Generic.Dictionary`2<string,System.Action> off=0x58 attr=21 
#   field _pendingFailCallback           System.Action                                      off=0x60 attr=1 
## get_StoreReady() -> bool
---- IAPManager::get_StoreReady 0x2ca49b8
02ca49b8: ldrb    w0, [x0, #0x30]                            ._isInit
02ca49bc: ret                                                
## add_OnIAPReady(System.Action value) -> void
---- IAPManager::add_OnIAPReady 0x2ca49c0
02ca49c0: str     x30, [sp, #-0x30]!                         
02ca49c4: stp     x22, x21, [sp, #0x10]                      
02ca49c8: stp     x20, x19, [sp, #0x20]                      
02ca49cc: adrp    x21, #0x662f000                            
02ca49d0: mov     x19, x1                                    
02ca49d4: mov     x20, x0                                    
02ca49d8: ldrb    w8, [x21, #0xacf]                          
02ca49dc: tbnz    w8, #0, #0x2ca49f4                         
02ca49e0: adrp    x0, #0x6264000                             
02ca49e4: ldr     x0, [x0, #0xf90]                           T:System.Action
02ca49e8: bl      #0x2b70db0                                 fn_2b70db0
02ca49ec: mov     w8, #1                                     
02ca49f0: strb    w8, [x21, #0xacf]                          
02ca49f4: adrp    x22, #0x6264000                            
02ca49f8: ldr     x22, [x22, #0xf90]                         T:System.Action
02ca49fc: ldr     x21, [x20, #0x48]!                         .OnIAPReady
02ca4a00: mov     x0, x21                                    
02ca4a04: mov     x1, x19                                    
02ca4a08: mov     x2, xzr                                    
02ca4a0c: bl      #0x4e570ac                                 System.Delegate::Combine
02ca4a10: mov     x8, x0                                     
02ca4a14: cbz     x0, #0x2ca4a28                             
02ca4a18: ldr     x1, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca4a1c: ldr     x9, [x8]                                   
02ca4a20: cmp     x9, x1                                     
02ca4a24: b.ne    #0x2ca4a54                                 
02ca4a28: mov     x0, x20                                    
02ca4a2c: mov     x1, x8                                     
02ca4a30: mov     x2, x21                                    
02ca4a34: bl      #0x2ba9880                                 fn_2ba9880
02ca4a38: cmp     x0, x21                                    
02ca4a3c: mov     x21, x0                                    
02ca4a40: b.ne    #0x2ca4a00                                 
02ca4a44: ldp     x20, x19, [sp, #0x20]                      
02ca4a48: ldp     x22, x21, [sp, #0x10]                      
02ca4a4c: ldr     x30, [sp], #0x30                           
02ca4a50: ret                                                
02ca4a54: mov     x0, x8                                     
02ca4a58: bl      #0x2b713dc                                 fn_2b713dc
## remove_OnIAPReady(System.Action value) -> void
---- IAPManager::remove_OnIAPReady 0x2ca4a5c
02ca4a5c: str     x30, [sp, #-0x30]!                         
02ca4a60: stp     x22, x21, [sp, #0x10]                      
02ca4a64: stp     x20, x19, [sp, #0x20]                      
02ca4a68: adrp    x21, #0x662f000                            
02ca4a6c: mov     x19, x1                                    
02ca4a70: mov     x20, x0                                    
02ca4a74: ldrb    w8, [x21, #0xad0]                          
02ca4a78: tbnz    w8, #0, #0x2ca4a90                         
02ca4a7c: adrp    x0, #0x6264000                             
02ca4a80: ldr     x0, [x0, #0xf90]                           T:System.Action
02ca4a84: bl      #0x2b70db0                                 fn_2b70db0
02ca4a88: mov     w8, #1                                     
02ca4a8c: strb    w8, [x21, #0xad0]                          
02ca4a90: adrp    x22, #0x6264000                            
02ca4a94: ldr     x22, [x22, #0xf90]                         T:System.Action
02ca4a98: ldr     x21, [x20, #0x48]!                         .OnIAPReady
02ca4a9c: mov     x0, x21                                    
02ca4aa0: mov     x1, x19                                    
02ca4aa4: mov     x2, xzr                                    
02ca4aa8: bl      #0x4e57298                                 System.Delegate::Remove
02ca4aac: mov     x8, x0                                     
02ca4ab0: cbz     x0, #0x2ca4ac4                             
02ca4ab4: ldr     x1, [x22]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca4ab8: ldr     x9, [x8]                                   
02ca4abc: cmp     x9, x1                                     
02ca4ac0: b.ne    #0x2ca4af0                                 
02ca4ac4: mov     x0, x20                                    
02ca4ac8: mov     x1, x8                                     
02ca4acc: mov     x2, x21                                    
02ca4ad0: bl      #0x2ba9880                                 fn_2ba9880
02ca4ad4: cmp     x0, x21                                    
02ca4ad8: mov     x21, x0                                    
02ca4adc: b.ne    #0x2ca4a9c                                 
02ca4ae0: ldp     x20, x19, [sp, #0x20]                      
02ca4ae4: ldp     x22, x21, [sp, #0x10]                      
02ca4ae8: ldr     x30, [sp], #0x30                           
02ca4aec: ret                                                
02ca4af0: mov     x0, x8                                     
02ca4af4: bl      #0x2b713dc                                 fn_2b713dc
## add_OnProductPurchased(System.Action`2<IAPKey,int> value) -> void
---- IAPManager::add_OnProductPurchased 0x2ca4af8
02ca4af8: str     x30, [sp, #-0x40]!                         
02ca4afc: stp     x24, x23, [sp, #0x10]                      
02ca4b00: stp     x22, x21, [sp, #0x20]                      
02ca4b04: stp     x20, x19, [sp, #0x30]                      
02ca4b08: adrp    x21, #0x662f000                            
02ca4b0c: mov     x19, x1                                    
02ca4b10: mov     x20, x0                                    
02ca4b14: ldrb    w8, [x21, #0xad1]                          
02ca4b18: tbnz    w8, #0, #0x2ca4b30                         
02ca4b1c: adrp    x0, #0x6266000                             
02ca4b20: ldr     x0, [x0, #0x1d0]                           T:type7137(k15)
02ca4b24: bl      #0x2b70db0                                 fn_2b70db0
02ca4b28: mov     w8, #1                                     
02ca4b2c: strb    w8, [x21, #0xad1]                          
02ca4b30: adrp    x24, #0x6266000                            
02ca4b34: ldr     x24, [x24, #0x1d0]                         T:type7137(k15)
02ca4b38: ldr     x21, [x20, #0x50]!                         .OnProductPurchased
02ca4b3c: mov     x0, x21                                    
02ca4b40: mov     x1, x19                                    
02ca4b44: mov     x2, xzr                                    
02ca4b48: bl      #0x4e570ac                                 System.Delegate::Combine
02ca4b4c: cbz     x0, #0x2ca4b6c                             
02ca4b50: ldr     x23, [x24]                                 M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca4b54: mov     x22, x0                                    
02ca4b58: mov     x1, x23                                    
02ca4b5c: bl      #0x2b70f34                                 fn_2b70f34
02ca4b60: mov     x1, x0                                     
02ca4b64: cbnz    x0, #0x2ca4b70                             
02ca4b68: b       #0x2ca4b9c                                 
02ca4b6c: mov     x1, xzr                                    
02ca4b70: mov     x0, x20                                    
02ca4b74: mov     x2, x21                                    
02ca4b78: bl      #0x2ba9880                                 fn_2ba9880
02ca4b7c: cmp     x0, x21                                    
02ca4b80: mov     x21, x0                                    
02ca4b84: b.ne    #0x2ca4b3c                                 
02ca4b88: ldp     x20, x19, [sp, #0x30]                      
02ca4b8c: ldp     x22, x21, [sp, #0x20]                      
02ca4b90: ldp     x24, x23, [sp, #0x10]                      
02ca4b94: ldr     x30, [sp], #0x40                           
02ca4b98: ret                                                
02ca4b9c: mov     x0, x22                                    
02ca4ba0: mov     x1, x23                                    
02ca4ba4: bl      #0x2b713dc                                 fn_2b713dc
## remove_OnProductPurchased(System.Action`2<IAPKey,int> value) -> void
---- IAPManager::remove_OnProductPurchased 0x2ca4ba8
02ca4ba8: str     x30, [sp, #-0x40]!                         
02ca4bac: stp     x24, x23, [sp, #0x10]                      
02ca4bb0: stp     x22, x21, [sp, #0x20]                      
02ca4bb4: stp     x20, x19, [sp, #0x30]                      
02ca4bb8: adrp    x21, #0x662f000                            
02ca4bbc: mov     x19, x1                                    
02ca4bc0: mov     x20, x0                                    
02ca4bc4: ldrb    w8, [x21, #0xad2]                          
02ca4bc8: tbnz    w8, #0, #0x2ca4be0                         
02ca4bcc: adrp    x0, #0x6266000                             
02ca4bd0: ldr     x0, [x0, #0x1d0]                           T:type7137(k15)
02ca4bd4: bl      #0x2b70db0                                 fn_2b70db0
02ca4bd8: mov     w8, #1                                     
02ca4bdc: strb    w8, [x21, #0xad2]                          
02ca4be0: adrp    x24, #0x6266000                            
02ca4be4: ldr     x24, [x24, #0x1d0]                         T:type7137(k15)
02ca4be8: ldr     x21, [x20, #0x50]!                         .OnProductPurchased
02ca4bec: mov     x0, x21                                    
02ca4bf0: mov     x1, x19                                    
02ca4bf4: mov     x2, xzr                                    
02ca4bf8: bl      #0x4e57298                                 System.Delegate::Remove
02ca4bfc: cbz     x0, #0x2ca4c1c                             
02ca4c00: ldr     x23, [x24]                                 M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca4c04: mov     x22, x0                                    
02ca4c08: mov     x1, x23                                    
02ca4c0c: bl      #0x2b70f34                                 fn_2b70f34
02ca4c10: mov     x1, x0                                     
02ca4c14: cbnz    x0, #0x2ca4c20                             
02ca4c18: b       #0x2ca4c4c                                 
02ca4c1c: mov     x1, xzr                                    
02ca4c20: mov     x0, x20                                    
02ca4c24: mov     x2, x21                                    
02ca4c28: bl      #0x2ba9880                                 fn_2ba9880
02ca4c2c: cmp     x0, x21                                    
02ca4c30: mov     x21, x0                                    
02ca4c34: b.ne    #0x2ca4bec                                 
02ca4c38: ldp     x20, x19, [sp, #0x30]                      
02ca4c3c: ldp     x22, x21, [sp, #0x20]                      
02ca4c40: ldp     x24, x23, [sp, #0x10]                      
02ca4c44: ldr     x30, [sp], #0x40                           
02ca4c48: ret                                                
02ca4c4c: mov     x0, x22                                    
02ca4c50: mov     x1, x23                                    
02ca4c54: bl      #0x2b713dc                                 fn_2b713dc
## Start() -> void
---- IAPManager::Start 0x2ca4c58
02ca4c58: sub     sp, sp, #0x80                              
02ca4c5c: stp     x30, x21, [sp, #0x60]                      
02ca4c60: stp     x20, x19, [sp, #0x70]                      
02ca4c64: adrp    x21, #0x662f000                            
02ca4c68: adrp    x20, #0x6266000                            
02ca4c6c: mov     x19, x0                                    
02ca4c70: ldrb    w8, [x21, #0xad3]                          
02ca4c74: ldr     x20, [x20, #0x1d8]                         MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::Start
02ca4c78: tbnz    w8, #0, #0x2ca4c90                         
02ca4c7c: adrp    x0, #0x6266000                             
02ca4c80: ldr     x0, [x0, #0x1d8]                           MS:System.Runtime.CompilerServices.AsyncVoidMethodBuilder::Start
02ca4c84: bl      #0x2b70db0                                 fn_2b70db0
02ca4c88: mov     w8, #1                                     
02ca4c8c: strb    w8, [x21, #0xad3]                          
02ca4c90: movi    v0.2d, #0000000000000000                   
02ca4c94: mov     x8, sp                                     
02ca4c98: mov     x0, xzr                                    
02ca4c9c: str     xzr, [sp, #0x50]                           
02ca4ca0: stp     q0, q0, [sp, #0x30]                        
02ca4ca4: str     q0, [sp, #0x20]                            
02ca4ca8: bl      #0x4d43a24                                 System.Runtime.CompilerServices.AsyncVoidMethodBuilder::Create
02ca4cac: ldp     q0, q1, [sp]                               
02ca4cb0: add     x21, sp, #0x20                             
02ca4cb4: orr     x0, x21, #8                                
02ca4cb8: mov     x1, xzr                                    
02ca4cbc: stur    q0, [sp, #0x28]                            
02ca4cc0: stur    q1, [sp, #0x38]                            
02ca4cc4: bl      #0x2b70d54                                 fn_2b70d54
02ca4cc8: add     x0, x21, #0x28                             &662f028
02ca4ccc: mov     x1, x19                                    
02ca4cd0: str     x19, [sp, #0x48]                           
02ca4cd4: bl      #0x2b70d54                                 fn_2b70d54
02ca4cd8: ldr     x2, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca4cdc: mov     w8, #-1                                    
02ca4ce0: orr     x0, x21, #8                                
02ca4ce4: add     x1, sp, #0x20                              
02ca4ce8: str     w8, [sp, #0x20]                            
02ca4cec: bl      #0x30c7ab0                                 fn_30c7ab0
02ca4cf0: ldp     x20, x19, [sp, #0x70]                      
02ca4cf4: ldp     x30, x21, [sp, #0x60]                      
02ca4cf8: add     sp, sp, #0x80                              
02ca4cfc: ret                                                
## InitIAP() -> System.Threading.Tasks.Task
---- IAPManager::InitIAP 0x2ca4d00
02ca4d00: sub     sp, sp, #0x70                              
02ca4d04: stp     x30, x21, [sp, #0x50]                      
02ca4d08: stp     x20, x19, [sp, #0x60]                      
02ca4d0c: adrp    x21, #0x662f000                            
02ca4d10: adrp    x20, #0x6264000                            
02ca4d14: mov     x19, x0                                    
02ca4d18: ldrb    w8, [x21, #0xad4]                          
02ca4d1c: ldr     x20, [x20, #0x808]                         T:System.Runtime.CompilerServices.AsyncTaskMethodBuilder
02ca4d20: tbnz    w8, #0, #0x2ca4d44                         
02ca4d24: adrp    x0, #0x6266000                             
02ca4d28: ldr     x0, [x0, #0x1e0]                           MS:System.Runtime.CompilerServices.AsyncTaskMethodBuilder::Start
02ca4d2c: bl      #0x2b70db0                                 fn_2b70db0
02ca4d30: adrp    x0, #0x6264000                             
02ca4d34: ldr     x0, [x0, #0x808]                           T:System.Runtime.CompilerServices.AsyncTaskMethodBuilder
02ca4d38: bl      #0x2b70db0                                 fn_2b70db0
02ca4d3c: mov     w8, #1                                     
02ca4d40: strb    w8, [x21, #0xad4]                          
02ca4d44: movi    v0.2d, #0000000000000000                   
02ca4d48: ldr     x0, [x20]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02ca4d4c: adrp    x20, #0x6266000                            
02ca4d50: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02ca4d54: str     q0, [sp, #0x40]                            
02ca4d58: ldr     x20, [x20, #0x1e0]                         MS:System.Runtime.CompilerServices.AsyncTaskMethodBuilder::Start
02ca4d5c: stp     q0, q0, [sp, #0x20]                        
02ca4d60: cbnz    w8, #0x2ca4d68                             
02ca4d64: bl      #0x2b70f30                                 fn_2b70f30
02ca4d68: add     x8, sp, #8                                 
02ca4d6c: mov     x0, xzr                                    
02ca4d70: bl      #0x4d440a4                                 System.Runtime.CompilerServices.AsyncTaskMethodBuilder::Create
02ca4d74: ldur    q0, [sp, #8]                               
02ca4d78: ldr     x8, [sp, #0x18]                            
02ca4d7c: add     x21, sp, #0x20                             
02ca4d80: orr     x0, x21, #8                                
02ca4d84: mov     x1, xzr                                    
02ca4d88: stur    q0, [sp, #0x28]                            
02ca4d8c: str     x8, [sp, #0x38]                            
02ca4d90: bl      #0x2b70d54                                 fn_2b70d54
02ca4d94: add     x0, x21, #0x20                             &662f020
02ca4d98: mov     x1, x19                                    
02ca4d9c: str     x19, [sp, #0x40]                           
02ca4da0: bl      #0x2b70d54                                 fn_2b70d54
02ca4da4: ldr     x2, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca4da8: mov     w8, #-1                                    
02ca4dac: orr     x0, x21, #8                                
02ca4db0: add     x1, sp, #0x20                              
02ca4db4: str     w8, [sp, #0x20]                            
02ca4db8: bl      #0x30ad49c                                 fn_30ad49c
02ca4dbc: orr     x0, x21, #8                                
02ca4dc0: mov     x1, xzr                                    
02ca4dc4: bl      #0x4d4412c                                 System.Runtime.CompilerServices.AsyncTaskMethodBuilder::get_Task
02ca4dc8: ldp     x20, x19, [sp, #0x60]                      
02ca4dcc: ldp     x30, x21, [sp, #0x50]                      
02ca4dd0: add     sp, sp, #0x70                              
02ca4dd4: ret                                                
## BuildProductDefinitions() -> System.Collections.Generic.List`1<UnityEngine.Purchasing.ProductDefinition>
---- IAPManager::BuildProductDefinitions 0x2ca4dd8
02ca4dd8: sub     sp, sp, #0xb0                              
02ca4ddc: stp     x29, x30, [sp, #0x50]                      
02ca4de0: stp     x28, x27, [sp, #0x60]                      
02ca4de4: stp     x26, x25, [sp, #0x70]                      
02ca4de8: stp     x24, x23, [sp, #0x80]                      
02ca4dec: stp     x22, x21, [sp, #0x90]                      
02ca4df0: stp     x20, x19, [sp, #0xa0]                      
02ca4df4: adrp    x21, #0x662f000                            
02ca4df8: adrp    x19, #0x6263000                            
02ca4dfc: mov     x20, x0                                    
02ca4e00: ldrb    w8, [x21, #0xad5]                          
02ca4e04: ldr     x19, [x19, #0x918]                         T:UnityEngine.Object
02ca4e08: tbnz    w8, #0, #0x2ca4ed4                         
02ca4e0c: adrp    x0, #0x6266000                             
02ca4e10: ldr     x0, [x0, #0x1e8]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02ca4e14: bl      #0x2b70db0                                 fn_2b70db0
02ca4e18: adrp    x0, #0x6266000                             
02ca4e1c: ldr     x0, [x0, #0x1f0]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02ca4e20: bl      #0x2b70db0                                 fn_2b70db0
02ca4e24: adrp    x0, #0x6266000                             
02ca4e28: ldr     x0, [x0, #0x1f8]                           MS:System.Collections.Generic.List`1/Enumerator::get_Current
02ca4e2c: bl      #0x2b70db0                                 fn_2b70db0
02ca4e30: adrp    x0, #0x6266000                             
02ca4e34: ldr     x0, [x0, #0x200]                           T:IAPKey
02ca4e38: bl      #0x2b70db0                                 fn_2b70db0
02ca4e3c: adrp    x0, #0x6266000                             
02ca4e40: ldr     x0, [x0, #0x208]                           MS:System.Collections.Generic.List`1::Add
02ca4e44: bl      #0x2b70db0                                 fn_2b70db0
02ca4e48: adrp    x0, #0x6266000                             
02ca4e4c: ldr     x0, [x0, #0x210]                           MS:System.Collections.Generic.List`1::GetEnumerator
02ca4e50: bl      #0x2b70db0                                 fn_2b70db0
02ca4e54: adrp    x0, #0x6266000                             
02ca4e58: ldr     x0, [x0, #0x218]                           MS:System.Collections.Generic.List`1::.ctor
02ca4e5c: bl      #0x2b70db0                                 fn_2b70db0
02ca4e60: adrp    x0, #0x6266000                             
02ca4e64: ldr     x0, [x0, #0x220]                           MS:System.Collections.Generic.List`1::get_Count
02ca4e68: bl      #0x2b70db0                                 fn_2b70db0
02ca4e6c: adrp    x0, #0x6266000                             
02ca4e70: ldr     x0, [x0, #0x228]                           T:type15233(k15)
02ca4e74: bl      #0x2b70db0                                 fn_2b70db0
02ca4e78: adrp    x0, #0x6266000                             
02ca4e7c: ldr     x0, [x0, #0x198]                           T:LogTags
02ca4e80: bl      #0x2b70db0                                 fn_2b70db0
02ca4e84: adrp    x0, #0x6263000                             
02ca4e88: ldr     x0, [x0, #0x918]                           T:UnityEngine.Object
02ca4e8c: bl      #0x2b70db0                                 fn_2b70db0
02ca4e90: adrp    x0, #0x6266000                             
02ca4e94: ldr     x0, [x0, #0x230]                           T:UnityEngine.Purchasing.ProductDefinition
02ca4e98: bl      #0x2b70db0                                 fn_2b70db0
02ca4e9c: adrp    x0, #0x6266000                             
02ca4ea0: ldr     x0, [x0, #0x238]                           S:"Product '"
02ca4ea4: bl      #0x2b70db0                                 fn_2b70db0
02ca4ea8: adrp    x0, #0x6266000                             
02ca4eac: ldr     x0, [x0, #0x240]                           S:'Registering {0} product(s) with the store.'
02ca4eb0: bl      #0x2b70db0                                 fn_2b70db0
02ca4eb4: adrp    x0, #0x6266000                             
02ca4eb8: ldr     x0, [x0, #0x248]                           S:'Product is not assigned! Assign it in the Inspector.'
02ca4ebc: bl      #0x2b70db0                                 fn_2b70db0
02ca4ec0: adrp    x0, #0x6266000                             
02ca4ec4: ldr     x0, [x0, #0x250]                           S:"' has an empty productId – skipped."
02ca4ec8: bl      #0x2b70db0                                 fn_2b70db0
02ca4ecc: mov     w8, #1                                     
02ca4ed0: strb    w8, [x21, #0xad5]                          
02ca4ed4: ldr     x0, [x19]                                  &2c5bbd4(=a9bd7bfdd503233f)
02ca4ed8: ldr     x19, [x20, #0x20]                          ._iAPProductSO
02ca4edc: stp     xzr, xzr, [sp, #0x30]                      
02ca4ee0: str     xzr, [sp, #0x40]                           
02ca4ee4: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02ca4ee8: cbnz    w8, #0x2ca4ef0                             
02ca4eec: bl      #0x2b70f30                                 fn_2b70f30
02ca4ef0: mov     x0, x19                                    
02ca4ef4: mov     x1, xzr                                    
02ca4ef8: mov     x2, xzr                                    
02ca4efc: bl      #0x5b37d84                                 UnityEngine.Object::op_Equality
02ca4f00: tbz     w0, #0, #0x2ca4f60                         
02ca4f04: adrp    x19, #0x6266000                            
02ca4f08: ldr     x19, [x19, #0x198]                         T:LogTags
02ca4f0c: ldr     x0, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca4f10: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02ca4f14: cbnz    w8, #0x2ca4f20                             
02ca4f18: bl      #0x2b70f30                                 fn_2b70f30
02ca4f1c: ldr     x0, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca4f20: adrp    x9, #0x6266000                             
02ca4f24: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time'
02ca4f28: ldr     x9, [x9, #0x248]                           S:'Product is not assigned! Assign it in the Inspector.'
02ca4f2c: ldr     x0, [x8]                                   
02ca4f30: ldr     x1, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca4f34: bl      #0x2ca47ec                                 WLog::LogError
02ca4f38: adrp    x8, #0x6266000                             
02ca4f3c: ldr     x8, [x8, #0x228]                           T:type15233(k15)
02ca4f40: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca4f44: bl      #0x2b7104c                                 fn_2b7104c
02ca4f48: adrp    x8, #0x6266000                             
02ca4f4c: mov     x19, x0                                    
02ca4f50: ldr     x8, [x8, #0x218]                           MS:System.Collections.Generic.List`1::.ctor
02ca4f54: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca4f58: bl      #0x35a89a4                                 fn_35a89a4
02ca4f5c: b       #0x2ca51b0                                 
02ca4f60: adrp    x8, #0x6266000                             
02ca4f64: ldr     x8, [x8, #0x228]                           T:type15233(k15)
02ca4f68: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca4f6c: bl      #0x2b7104c                                 fn_2b7104c
02ca4f70: adrp    x8, #0x6266000                             
02ca4f74: mov     x19, x0                                    
02ca4f78: ldr     x8, [x8, #0x218]                           MS:System.Collections.Generic.List`1::.ctor
02ca4f7c: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca4f80: bl      #0x35a89a4                                 fn_35a89a4
02ca4f84: ldr     x8, [x20, #0x20]                           ._iAPProductSO
02ca4f88: cbz     x8, #0x2ca51dc                             
02ca4f8c: ldr     x0, [x8, #0x18]                            S:'level_show_popuprate'
02ca4f90: cbz     x0, #0x2ca51dc                             
02ca4f94: adrp    x8, #0x6266000                             
02ca4f98: ldr     x8, [x8, #0x210]                           MS:System.Collections.Generic.List`1::GetEnumerator
02ca4f9c: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca4fa0: add     x8, sp, #0x18                              
02ca4fa4: bl      #0x35a9d9c                                 fn_35a9d9c
02ca4fa8: adrp    x24, #0x6266000                            
02ca4fac: adrp    x25, #0x6266000                            
02ca4fb0: adrp    x26, #0x6266000                            
02ca4fb4: ldr     x24, [x24, #0x1f0]                         MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02ca4fb8: ldur    q0, [sp, #0x18]                            
02ca4fbc: ldr     x25, [x25, #0x200]                         T:IAPKey
02ca4fc0: ldr     x8, [sp, #0x28]                            
02ca4fc4: adrp    x27, #0x6266000                            
02ca4fc8: adrp    x28, #0x6266000                            
02ca4fcc: str     q0, [sp, #0x30]                            
02ca4fd0: adrp    x29, #0x6266000                            
02ca4fd4: mov     x23, #-1                                   
02ca4fd8: ldr     x26, [x26, #0x238]                         S:"Product '"
02ca4fdc: str     x8, [sp, #0x40]                            
02ca4fe0: add     x8, sp, #0x30                              
02ca4fe4: ldr     x27, [x27, #0x250]                         S:"' has an empty productId – skipped."
02ca4fe8: ldr     x28, [x28, #0x230]                         T:UnityEngine.Purchasing.ProductDefinition
02ca4fec: ldr     x29, [x29, #0x208]                         MS:System.Collections.Generic.List`1::Add
02ca4ff0: stp     xzr, x8, [sp, #8]                          
02ca4ff4: ldr     x1, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca4ff8: add     x0, sp, #0x30                              
02ca4ffc: bl      #0x4690474                                 fn_4690474
02ca5000: tbz     w0, #0, #0x2ca5128                         
02ca5004: ldr     x22, [sp, #0x40]                           
02ca5008: cbz     x22, #0x2ca51d4                            
02ca500c: ldr     x8, [x25]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca5010: ldr     w9, [x22, #0x10]                           
02ca5014: stp     x8, x23, [sp, #0x18]                       
02ca5018: str     w9, [sp, #0x28]                            
02ca501c: add     x0, sp, #0x18                              
02ca5020: mov     x1, xzr                                    
02ca5024: bl      #0x4e47e48                                 System.Enum::ToString
02ca5028: mov     x1, xzr                                    
02ca502c: bl      #0x4ca6234                                 System.String::IsNullOrEmpty
02ca5030: tbz     w0, #0, #0x2ca5084                         
02ca5034: adrp    x8, #0x6266000                             
02ca5038: ldr     x8, [x8, #0x198]                           T:LogTags
02ca503c: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca5040: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02ca5044: cbnz    w8, #0x2ca5058                             
02ca5048: bl      #0x2b70f30                                 fn_2b70f30
02ca504c: adrp    x8, #0x6266000                             
02ca5050: ldr     x8, [x8, #0x198]                           T:LogTags
02ca5054: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca5058: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time'
02ca505c: ldr     x1, [x22, #0x18]                           
02ca5060: ldr     x0, [x26]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca5064: ldr     x2, [x27]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca5068: ldr     x20, [x8]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca506c: mov     x3, xzr                                    
02ca5070: bl      #0x4ca6dbc                                 System.String::Concat
02ca5074: mov     x1, x0                                     
02ca5078: mov     x0, x20                                    
02ca507c: bl      #0x2ca47ec                                 WLog::LogError
02ca5080: b       #0x2ca4ff4                                 
02ca5084: ldr     x8, [x25]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca5088: ldr     w9, [x22, #0x10]                           
02ca508c: stp     x8, x23, [sp, #0x18]                       
02ca5090: str     w9, [sp, #0x28]                            
02ca5094: add     x0, sp, #0x18                              
02ca5098: mov     x1, xzr                                    
02ca509c: bl      #0x4e47e48                                 System.Enum::ToString
02ca50a0: mov     x21, x0                                    
02ca50a4: ldr     w22, [x22, #0x14]                          
02ca50a8: ldr     x0, [x28]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca50ac: bl      #0x2b7104c                                 fn_2b7104c
02ca50b0: mov     x1, x21                                    
02ca50b4: mov     w2, w22                                    
02ca50b8: mov     x3, xzr                                    
02ca50bc: mov     x20, x0                                    
02ca50c0: bl      #0x57eda00                                 UnityEngine.Purchasing.ProductDefinition::.ctor
02ca50c4: cbz     x19, #0x2ca51d8                            
02ca50c8: ldr     w10, [x19, #0x1c]                          [626601c]=0 f=0,0
02ca50cc: ldr     x8, [x19, #0x10]                           S:'mrec_ad_on_off'
02ca50d0: ldr     x9, [x29]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca50d4: add     w10, w10, #1                               
02ca50d8: str     w10, [x19, #0x1c]                          
02ca50dc: cbz     x8, #0x2ca51d8                             
02ca50e0: ldrsw   x10, [x19, #0x18]                          
02ca50e4: ldr     w11, [x8, #0x18]                           S:'level_show_popuprate'
02ca50e8: cmp     w10, w11                                   
02ca50ec: b.hs    #0x2ca510c                                 
02ca50f0: add     x0, x8, x10, lsl #3                        &6266000
02ca50f4: add     w9, w10, #1                                
02ca50f8: str     w9, [x19, #0x18]                           
02ca50fc: str     x20, [x0, #0x20]!                          ._iAPProductSO
02ca5100: mov     x1, x20                                    
02ca5104: bl      #0x2b70d54                                 fn_2b70d54
02ca5108: b       #0x2ca4ff4                                 
02ca510c: ldr     x8, [x9, #0x20]                            S:'inter_ad_capping_time'
02ca5110: ldr     x8, [x8, #0xc0]                            T:Firebase.RemoteConfig.ConfigValue
02ca5114: ldr     x2, [x8, #0x70]                            S:'open_ad_id'
02ca5118: mov     x0, x19                                    
02ca511c: mov     x1, x20                                    
02ca5120: bl      #0x35a920c                                 fn_35a920c
02ca5124: b       #0x2ca4ff4                                 
02ca5128: adrp    x8, #0x6266000                             
02ca512c: add     x0, sp, #0x30                              
02ca5130: ldr     x8, [x8, #0x1e8]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02ca5134: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca5138: bl      #0x4690470                                 fn_4690470
02ca513c: adrp    x8, #0x6266000                             
02ca5140: ldr     x8, [x8, #0x198]                           T:LogTags
02ca5144: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca5148: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02ca514c: cbnz    w8, #0x2ca5154                             
02ca5150: bl      #0x2b70f30                                 fn_2b70f30
02ca5154: cbz     x19, #0x2ca51dc                            
02ca5158: adrp    x8, #0x6266000                             
02ca515c: adrp    x9, #0x6263000                             
02ca5160: add     x1, sp, #0x18                              
02ca5164: ldr     x8, [x8, #0x198]                           T:LogTags
02ca5168: ldr     x8, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca516c: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02ca5170: ldr     x9, [x9, #0x970]                           &6645c70(=0)
02ca5174: ldr     w10, [x19, #0x18]                          S:'level_show_popuprate'
02ca5178: ldr     x0, [x9, #0x48]                            &6263098(=0)
02ca517c: ldr     x20, [x8]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca5180: str     w10, [sp, #0x18]                           
02ca5184: bl      #0x2b70f38                                 fn_2b70f38
02ca5188: adrp    x8, #0x6266000                             
02ca518c: mov     x1, x0                                     
02ca5190: mov     x2, xzr                                    
02ca5194: ldr     x8, [x8, #0x240]                           S:'Registering {0} product(s) with the store.'
02ca5198: ldr     x8, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca519c: mov     x0, x8                                     
02ca51a0: bl      #0x4c9d0ec                                 System.String::Format
02ca51a4: mov     x1, x0                                     
02ca51a8: mov     x0, x20                                    
02ca51ac: bl      #0x2ca4738                                 WLog::Log
02ca51b0: mov     x0, x19                                    
02ca51b4: ldp     x20, x19, [sp, #0xa0]                      
02ca51b8: ldp     x22, x21, [sp, #0x90]                      
02ca51bc: ldp     x24, x23, [sp, #0x80]                      
02ca51c0: ldp     x26, x25, [sp, #0x70]                      
02ca51c4: ldp     x28, x27, [sp, #0x60]                      
02ca51c8: ldp     x29, x30, [sp, #0x50]                      
02ca51cc: add     sp, sp, #0xb0                              
02ca51d0: ret                                                
02ca51d4: bl      #0x2b7105c                                 fn_2b7105c
02ca51d8: bl      #0x2b7105c                                 fn_2b7105c
02ca51dc: bl      #0x2b7105c                                 fn_2b7105c
02ca51e0: b       #0x2ca5200                                 
02ca51e4: b       #0x2ca5200                                 
02ca51e8: b       #0x2ca5200                                 
02ca51ec: b       #0x2ca5200                                 
02ca51f0: b       #0x2ca5200                                 
02ca51f4: b       #0x2ca5200                                 
02ca51f8: b       #0x2ca5200                                 
02ca51fc: b       #0x2ca5200                                 
02ca5200: mov     x20, x0                                    
02ca5204: cmp     w1, #1                                     
02ca5208: b.ne    #0x2ca5244                                 
02ca520c: mov     x0, x20                                    
02ca5210: bl      #0x5e90260                                 fn_5e90260
02ca5214: ldr     x20, [x0]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca5218: str     x20, [sp, #8]                              
02ca521c: bl      #0x5e90270                                 fn_5e90270
02ca5220: adrp    x8, #0x6266000                             
02ca5224: ldr     x8, [x8, #0x1e8]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02ca5228: ldr     x0, [sp, #0x10]                            
02ca522c: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca5230: bl      #0x4690470                                 fn_4690470
02ca5234: cbz     x20, #0x2ca513c                            
02ca5238: mov     x0, x20                                    
02ca523c: bl      #0x2b71054                                 fn_2b71054
02ca5240: mov     x20, x0                                    
02ca5244: add     x0, sp, #8                                 
02ca5248: bl      #0x2736e74                                 fn_2736e74
02ca524c: mov     x0, x20                                    
02ca5250: bl      #0x2c6051c                                 fn_2c6051c
02ca5254: bl      #0x27369b8                                 fn_27369b8
## OnProductsFetched(System.Collections.Generic.List`1<UnityEngine.Purchasing.Product> products) -> void
---- IAPManager::OnProductsFetched 0x2ca5258
02ca5258: sub     sp, sp, #0xa0                              
02ca525c: str     x30, [sp, #0x40]                           
02ca5260: stp     x28, x27, [sp, #0x50]                      
02ca5264: stp     x26, x25, [sp, #0x60]                      
02ca5268: stp     x24, x23, [sp, #0x70]                      
02ca526c: stp     x22, x21, [sp, #0x80]                      
02ca5270: stp     x20, x19, [sp, #0x90]                      
02ca5274: adrp    x21, #0x662f000                            
02ca5278: adrp    x24, #0x6266000                            
02ca527c: mov     x20, x1                                    
02ca5280: ldrb    w8, [x21, #0xad6]                          
02ca5284: ldr     x24, [x24, #0x198]                         T:LogTags
02ca5288: mov     x19, x0                                    
02ca528c: tbnz    w8, #0, #0x2ca5304                         
02ca5290: adrp    x0, #0x6266000                             
02ca5294: ldr     x0, [x0, #0x258]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02ca5298: bl      #0x2b70db0                                 fn_2b70db0
02ca529c: adrp    x0, #0x6266000                             
02ca52a0: ldr     x0, [x0, #0x260]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02ca52a4: bl      #0x2b70db0                                 fn_2b70db0
02ca52a8: adrp    x0, #0x6266000                             
02ca52ac: ldr     x0, [x0, #0x268]                           MS:System.Collections.Generic.List`1/Enumerator::get_Current
02ca52b0: bl      #0x2b70db0                                 fn_2b70db0
02ca52b4: adrp    x0, #0x6266000                             
02ca52b8: ldr     x0, [x0, #0x270]                           MS:System.Collections.Generic.List`1::GetEnumerator
02ca52bc: bl      #0x2b70db0                                 fn_2b70db0
02ca52c0: adrp    x0, #0x6266000                             
02ca52c4: ldr     x0, [x0, #0x278]                           MS:System.Collections.Generic.List`1::get_Count
02ca52c8: bl      #0x2b70db0                                 fn_2b70db0
02ca52cc: adrp    x0, #0x6266000                             
02ca52d0: ldr     x0, [x0, #0x198]                           T:LogTags
02ca52d4: bl      #0x2b70db0                                 fn_2b70db0
02ca52d8: adrp    x0, #0x6266000                             
02ca52dc: ldr     x0, [x0, #0x280]                           S:'  - '
02ca52e0: bl      #0x2b70db0                                 fn_2b70db0
02ca52e4: adrp    x0, #0x6266000                             
02ca52e8: ldr     x0, [x0, #0x288]                           S:' | '
02ca52ec: bl      #0x2b70db0                                 fn_2b70db0
02ca52f0: adrp    x0, #0x6266000                             
02ca52f4: ldr     x0, [x0, #0x290]                           S:'{0} products fetched from store.'
02ca52f8: bl      #0x2b70db0                                 fn_2b70db0
02ca52fc: mov     w8, #1                                     
02ca5300: strb    w8, [x21, #0xad6]                          
02ca5304: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca5308: stp     xzr, xzr, [sp, #0x20]                      
02ca530c: str     xzr, [sp, #0x30]                           
02ca5310: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02ca5314: cbnz    w8, #0x2ca531c                             
02ca5318: bl      #0x2b70f30                                 fn_2b70f30
02ca531c: cbz     x20, #0x2ca5488                            
02ca5320: adrp    x22, #0x6266000                            
02ca5324: adrp    x28, #0x6266000                            
02ca5328: adrp    x25, #0x6266000                            
02ca532c: adrp    x26, #0x6266000                            
02ca5330: ldr     x22, [x22, #0x290]                         S:'{0} products fetched from store.'
02ca5334: ldr     x28, [x28, #0x270]                         MS:System.Collections.Generic.List`1::GetEnumerator
02ca5338: ldr     x25, [x25, #0x260]                         MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02ca533c: ldr     x26, [x26, #0x280]                         S:'  - '
02ca5340: ldr     x8, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca5344: adrp    x27, #0x6266000                            
02ca5348: adrp    x9, #0x6263000                             
02ca534c: adrp    x23, #0x6266000                            
02ca5350: ldr     x27, [x27, #0x288]                         S:' | '
02ca5354: ldr     x8, [x8, #0xb8]                            
02ca5358: ldr     x9, [x9, #0x970]                           &6645c70(=0)
02ca535c: ldr     x23, [x23, #0x258]                         MS:System.Collections.Generic.List`1/Enumerator::Dispose
02ca5360: ldr     w10, [x20, #0x18]                          
02ca5364: add     x1, sp, #0x4c                              
02ca5368: ldr     x0, [x9, #0x48]                            &6263098(=0)
02ca536c: ldr     x21, [x8]                                  
02ca5370: str     w10, [sp, #0x4c]                           
02ca5374: bl      #0x2b70f38                                 fn_2b70f38
02ca5378: ldr     x8, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca537c: mov     x1, x0                                     
02ca5380: mov     x2, xzr                                    
02ca5384: mov     x0, x8                                     
02ca5388: bl      #0x4c9d0ec                                 System.String::Format
02ca538c: mov     x1, x0                                     
02ca5390: mov     x0, x21                                    
02ca5394: bl      #0x2ca4738                                 WLog::Log
02ca5398: ldr     x1, [x28]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca539c: add     x8, sp, #8                                 
02ca53a0: mov     x0, x20                                    
02ca53a4: bl      #0x35a9d9c                                 fn_35a9d9c
02ca53a8: ldr     x8, [sp, #0x18]                            
02ca53ac: ldur    q0, [sp, #8]                               
02ca53b0: str     x8, [sp, #0x30]                            
02ca53b4: add     x8, sp, #0x20                              
02ca53b8: str     q0, [sp, #0x20]                            
02ca53bc: stp     xzr, x8, [sp, #8]                          
02ca53c0: ldr     x1, [x25]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca53c4: add     x0, sp, #0x20                              
02ca53c8: bl      #0x4690474                                 fn_4690474
02ca53cc: tbz     w0, #0, #0x2ca5440                         
02ca53d0: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca53d4: ldr     x21, [sp, #0x30]                           
02ca53d8: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02ca53dc: cbnz    w8, #0x2ca53e8                             
02ca53e0: bl      #0x2b70f30                                 fn_2b70f30
02ca53e4: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca53e8: cbz     x21, #0x2ca5480                            
02ca53ec: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time'
02ca53f0: mov     x0, x21                                    
02ca53f4: mov     x1, xzr                                    
02ca53f8: ldr     x20, [x8]                                  
02ca53fc: bl      #0x57edb20                                 UnityEngine.Purchasing.Product::get_definition
02ca5400: cbz     x0, #0x2ca5484                             
02ca5404: ldr     x22, [x0, #0x18]                           S:'level_show_popuprate'
02ca5408: mov     x0, x21                                    
02ca540c: mov     x1, xzr                                    
02ca5410: bl      #0x57edb38                                 UnityEngine.Purchasing.Product::get_metadata
02ca5414: cbz     x0, #0x2ca547c                             
02ca5418: ldr     x3, [x0, #0x10]                            S:'mrec_ad_on_off'
02ca541c: ldr     x0, [x26]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca5420: ldr     x2, [x27]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca5424: mov     x1, x22                                    
02ca5428: mov     x4, xzr                                    
02ca542c: bl      #0x4ca7320                                 System.String::Concat
02ca5430: mov     x1, x0                                     
02ca5434: mov     x0, x20                                    
02ca5438: bl      #0x2ca4738                                 WLog::Log
02ca543c: b       #0x2ca53c0                                 
02ca5440: ldr     x1, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca5444: add     x0, sp, #0x20                              
02ca5448: bl      #0x4690470                                 fn_4690470
02ca544c: ldr     x0, [x19, #0x38]                           ._storeController
02ca5450: cbz     x0, #0x2ca5488                             
02ca5454: mov     x1, xzr                                    
02ca5458: bl      #0x571a3d0                                 UnityEngine.Purchasing.StoreController::FetchPurchases
02ca545c: ldp     x20, x19, [sp, #0x90]                      
02ca5460: ldr     x30, [sp, #0x40]                           
02ca5464: ldp     x22, x21, [sp, #0x80]                      
02ca5468: ldp     x24, x23, [sp, #0x70]                      
02ca546c: ldp     x26, x25, [sp, #0x60]                      
02ca5470: ldp     x28, x27, [sp, #0x50]                      
02ca5474: add     sp, sp, #0xa0                              
02ca5478: ret                                                
02ca547c: bl      #0x2b7105c                                 fn_2b7105c
02ca5480: bl      #0x2b7105c                                 fn_2b7105c
02ca5484: bl      #0x2b7105c                                 fn_2b7105c
02ca5488: bl      #0x2b7105c                                 fn_2b7105c
02ca548c: b       #0x2ca54a8                                 
02ca5490: b       #0x2ca54a8                                 
02ca5494: b       #0x2ca54a8                                 
02ca5498: b       #0x2ca54a8                                 
02ca549c: b       #0x2ca54a8                                 
02ca54a0: b       #0x2ca54a8                                 
02ca54a4: b       #0x2ca54a8                                 
02ca54a8: mov     x20, x0                                    
02ca54ac: cmp     w1, #1                                     
02ca54b0: b.ne    #0x2ca54e4                                 
02ca54b4: mov     x0, x20                                    
02ca54b8: bl      #0x5e90260                                 fn_5e90260
02ca54bc: ldr     x20, [x0]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca54c0: str     x20, [sp, #8]                              
02ca54c4: bl      #0x5e90270                                 fn_5e90270
02ca54c8: ldr     x0, [sp, #0x10]                            
02ca54cc: ldr     x1, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca54d0: bl      #0x4690470                                 fn_4690470
02ca54d4: cbz     x20, #0x2ca544c                            
02ca54d8: mov     x0, x20                                    
02ca54dc: bl      #0x2b71054                                 fn_2b71054
02ca54e0: mov     x20, x0                                    
02ca54e4: add     x0, sp, #8                                 
02ca54e8: bl      #0x2736ea4                                 fn_2736ea4
02ca54ec: mov     x0, x20                                    
02ca54f0: bl      #0x2c6051c                                 fn_2c6051c
02ca54f4: bl      #0x27369b8                                 fn_27369b8
## OnPurchasesFetched(UnityEngine.Purchasing.Orders orders) -> void
---- IAPManager::OnPurchasesFetched 0x2ca54f8
02ca54f8: sub     sp, sp, #0xa0                              
02ca54fc: stp     x29, x30, [sp, #0x40]                      
02ca5500: stp     x28, x27, [sp, #0x50]                      
02ca5504: stp     x26, x25, [sp, #0x60]                      
02ca5508: stp     x24, x23, [sp, #0x70]                      
02ca550c: stp     x22, x21, [sp, #0x80]                      
02ca5510: stp     x20, x19, [sp, #0x90]                      
02ca5514: adrp    x21, #0x662f000                            
02ca5518: adrp    x24, #0x6266000                            
02ca551c: mov     x20, x1                                    
02ca5520: ldrb    w8, [x21, #0xad7]                          
02ca5524: ldr     x24, [x24, #0x198]                         T:LogTags
02ca5528: mov     x19, x0                                    
02ca552c: tbnz    w8, #0, #0x2ca5610                         
02ca5530: adrp    x0, #0x6266000                             
02ca5534: ldr     x0, [x0, #0x298]                           MS:System.Collections.Generic.HashSet`1::Add
02ca5538: bl      #0x2b70db0                                 fn_2b70db0
02ca553c: adrp    x0, #0x6266000                             
02ca5540: ldr     x0, [x0, #0x2a0]                           MS:System.Collections.Generic.HashSet`1::Clear
02ca5544: bl      #0x2b70db0                                 fn_2b70db0
02ca5548: adrp    x0, #0x6266000                             
02ca554c: ldr     x0, [x0, #0x2a8]                           T:UnityEngine.Purchasing.ICart
02ca5550: bl      #0x2b70db0                                 fn_2b70db0
02ca5554: adrp    x0, #0x6263000                             
02ca5558: ldr     x0, [x0, #0x980]                           T:System.IDisposable
02ca555c: bl      #0x2b70db0                                 fn_2b70db0
02ca5560: adrp    x0, #0x6266000                             
02ca5564: ldr     x0, [x0, #0x2b0]                           T:type11754(k15)
02ca5568: bl      #0x2b70db0                                 fn_2b70db0
02ca556c: adrp    x0, #0x6266000                             
02ca5570: ldr     x0, [x0, #0x2b8]                           T:type55989(k15)
02ca5574: bl      #0x2b70db0                                 fn_2b70db0
02ca5578: adrp    x0, #0x6266000                             
02ca557c: ldr     x0, [x0, #0x2c0]                           T:type56094(k15)
02ca5580: bl      #0x2b70db0                                 fn_2b70db0
02ca5584: adrp    x0, #0x6266000                             
02ca5588: ldr     x0, [x0, #0x2c8]                           T:type56097(k15)
02ca558c: bl      #0x2b70db0                                 fn_2b70db0
02ca5590: adrp    x0, #0x6263000                             
02ca5594: ldr     x0, [x0, #0xa58]                           T:System.Collections.IEnumerator
02ca5598: bl      #0x2b70db0                                 fn_2b70db0
02ca559c: adrp    x0, #0x6266000                             
02ca55a0: ldr     x0, [x0, #0x2d0]                           T:type56243(k15)
02ca55a4: bl      #0x2b70db0                                 fn_2b70db0
02ca55a8: adrp    x0, #0x6266000                             
02ca55ac: ldr     x0, [x0, #0x198]                           T:LogTags
02ca55b0: bl      #0x2b70db0                                 fn_2b70db0
02ca55b4: adrp    x0, #0x6266000                             
02ca55b8: ldr     x0, [x0, #0x2d8]                           MS:System.Nullable`1::GetValueOrDefault
02ca55bc: bl      #0x2b70db0                                 fn_2b70db0
02ca55c0: adrp    x0, #0x6266000                             
02ca55c4: ldr     x0, [x0, #0x2e0]                           MS:System.Nullable`1::.ctor
02ca55c8: bl      #0x2b70db0                                 fn_2b70db0
02ca55cc: adrp    x0, #0x6266000                             
02ca55d0: ldr     x0, [x0, #0x2e8]                           T:UnityEngine.Purchasing.ProductType
02ca55d4: bl      #0x2b70db0                                 fn_2b70db0
02ca55d8: adrp    x0, #0x6266000                             
02ca55dc: ldr     x0, [x0, #0x2f0]                           S:'Owned non-consumable products: '
02ca55e0: bl      #0x2b70db0                                 fn_2b70db0
02ca55e4: adrp    x0, #0x6266000                             
02ca55e8: ldr     x0, [x0, #0x2f8]                           S:', '
02ca55ec: bl      #0x2b70db0                                 fn_2b70db0
02ca55f0: adrp    x0, #0x6266000                             
02ca55f4: ldr     x0, [x0, #0x300]                           S:'Restored product: {0} | type: {1}'
02ca55f8: bl      #0x2b70db0                                 fn_2b70db0
02ca55fc: adrp    x0, #0x6266000                             
02ca5600: ldr     x0, [x0, #0x308]                           S:'Purchases fetched - confirmed orders: {0}.'
02ca5604: bl      #0x2b70db0                                 fn_2b70db0
02ca5608: mov     w8, #1                                     
02ca560c: strb    w8, [x21, #0xad7]                          
02ca5610: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca5614: adrp    x21, #0x6266000                            
02ca5618: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02ca561c: ldr     x21, [x21, #0x308]                         S:'Purchases fetched - confirmed orders: {0}.'
02ca5620: stp     xzr, xzr, [sp, #0x30]                      
02ca5624: cbnz    w8, #0x2ca5630                             
02ca5628: bl      #0x2b70f30                                 fn_2b70f30
02ca562c: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca5630: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time'
02ca5634: ldr     x23, [x21]                                 M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca5638: ldr     x22, [x8]                                  
02ca563c: cbz     x20, #0x2ca569c                            
02ca5640: ldr     x21, [x20, #0x10]                          
02ca5644: cmp     x21, #0                                    
02ca5648: csel    x25, xzr, x22, eq                          
02ca564c: csel    x26, xzr, x23, eq                          
02ca5650: cbz     x21, #0x2ca569c                            
02ca5654: adrp    x10, #0x6266000                            
02ca5658: ldr     x8, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca565c: ldr     x10, [x10, #0x2d0]                         T:type56243(k15)
02ca5660: ldrh    w9, [x8, #0x12e]                           
02ca5664: ldr     x1, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca5668: cbz     x9, #0x2ca568c                             
02ca566c: ldr     x10, [x8, #0xb0]                           
02ca5670: add     x10, x10, #8                               &6266008
02ca5674: ldur    x11, [x10, #-8]                            
02ca5678: cmp     x11, x1                                    
02ca567c: b.eq    #0x2ca56a4                                 
02ca5680: subs    x9, x9, #1                                 
02ca5684: add     x10, x10, #0x10                            &6266010
02ca5688: b.ne    #0x2ca5674                                 
02ca568c: mov     x0, x21                                    
02ca5690: mov     w2, wzr                                    
02ca5694: bl      #0x2baa05c                                 fn_2baa05c
02ca5698: b       #0x2ca56b0                                 
02ca569c: mov     x8, xzr                                    
02ca56a0: b       #0x2ca56e4                                 
02ca56a4: ldrsw   x9, [x10]                                  
02ca56a8: add     x8, x8, x9, lsl #4                         
02ca56ac: add     x0, x8, #0x138                             
02ca56b0: ldp     x8, x1, [x0]                               
02ca56b4: mov     x0, x21                                    
02ca56b8: blr     x8                                         
02ca56bc: adrp    x8, #0x6266000                             
02ca56c0: mov     w1, w0                                     
02ca56c4: add     x0, sp, #0x20                              
02ca56c8: ldr     x8, [x8, #0x2e0]                           MS:System.Nullable`1::.ctor
02ca56cc: str     xzr, [sp, #0x20]                           
02ca56d0: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca56d4: bl      #0x38ea674                                 fn_38ea674
02ca56d8: ldr     x8, [sp, #0x20]                            
02ca56dc: mov     x22, x25                                   
02ca56e0: mov     x23, x26                                   
02ca56e4: adrp    x9, #0x6263000                             
02ca56e8: lsr     x8, x8, #0x20                              
02ca56ec: add     x1, sp, #0x20                              
02ca56f0: ldr     x9, [x9, #0x970]                           &6645c70(=0)
02ca56f4: str     w8, [sp, #0x20]                            
02ca56f8: ldr     x0, [x9, #0x48]                            &6263098(=0)
02ca56fc: bl      #0x2b70f38                                 fn_2b70f38
02ca5700: mov     x1, x0                                     
02ca5704: mov     x0, x23                                    
02ca5708: mov     x2, xzr                                    
02ca570c: bl      #0x4c9d0ec                                 System.String::Format
02ca5710: mov     x1, x0                                     
02ca5714: mov     x0, x22                                    
02ca5718: bl      #0x2ca4738                                 WLog::Log
02ca571c: ldr     x0, [x19, #0x40]                           ._purchasedProductIds
02ca5720: cbz     x0, #0x2ca5d54                             
02ca5724: adrp    x8, #0x6266000                             
02ca5728: ldr     x8, [x8, #0x2a0]                           MS:System.Collections.Generic.HashSet`1::Clear
02ca572c: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca5730: bl      #0x4986f8c                                 fn_4986f8c
02ca5734: cbz     x20, #0x2ca5c9c                            
02ca5738: ldr     x20, [x20, #0x10]                          
02ca573c: cbz     x20, #0x2ca5c9c                            
02ca5740: adrp    x10, #0x6266000                            
02ca5744: ldr     x8, [x20]                                  
02ca5748: ldr     x10, [x10, #0x2b8]                         T:type55989(k15)
02ca574c: ldrh    w9, [x8, #0x12e]                           
02ca5750: ldr     x1, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca5754: cbz     x9, #0x2ca5778                             
02ca5758: ldr     x10, [x8, #0xb0]                           S:'native_banner_ad_on_off'
02ca575c: add     x10, x10, #8                               &6266008
02ca5760: ldur    x11, [x10, #-8]                            
02ca5764: cmp     x11, x1                                    
02ca5768: b.eq    #0x2ca5788                                 
02ca576c: subs    x9, x9, #1                                 
02ca5770: add     x10, x10, #0x10                            &6266010
02ca5774: b.ne    #0x2ca5760                                 
02ca5778: mov     x0, x20                                    
02ca577c: mov     w2, wzr                                    
02ca5780: bl      #0x2baa05c                                 fn_2baa05c
02ca5784: b       #0x2ca5794                                 
02ca5788: ldrsw   x9, [x10]                                  
02ca578c: add     x8, x8, x9, lsl #4                         &6266000
02ca5790: add     x0, x8, #0x138                             &6266138
02ca5794: ldp     x8, x1, [x0]                               
02ca5798: mov     x0, x20                                    
02ca579c: blr     x8                                         
02ca57a0: add     x8, sp, #0x38                              
02ca57a4: str     x0, [sp, #0x38]                            
02ca57a8: stp     xzr, x8, [sp, #0x20]                       
02ca57ac: cbz     x0, #0x2ca5d38                             
02ca57b0: adrp    x22, #0x6263000                            
02ca57b4: adrp    x28, #0x6266000                            
02ca57b8: adrp    x29, #0x6266000                            
02ca57bc: adrp    x27, #0x6266000                            
02ca57c0: adrp    x23, #0x6266000                            
02ca57c4: ldr     x22, [x22, #0xa58]                         T:System.Collections.IEnumerator
02ca57c8: ldr     x28, [x28, #0x2c0]                         T:type56094(k15)
02ca57cc: ldr     x29, [x29, #0x2e8]                         T:UnityEngine.Purchasing.ProductType
02ca57d0: ldr     x27, [x27, #0x300]                         S:'Restored product: {0} | type: {1}'
02ca57d4: ldr     x23, [x23, #0x298]                         MS:System.Collections.Generic.HashSet`1::Add
02ca57d8: mov     x20, x0                                    
02ca57dc: add     x25, sp, #0x30                             
02ca57e0: ldr     x8, [x20]                                  
02ca57e4: ldr     x1, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02ca57e8: ldrh    w9, [x8, #0x12e]                           
02ca57ec: cbz     x9, #0x2ca5810                             
02ca57f0: ldr     x10, [x8, #0xb0]                           S:'native_banner_ad_on_off'
02ca57f4: add     x10, x10, #8                               &6266008
02ca57f8: ldur    x11, [x10, #-8]                            
02ca57fc: cmp     x11, x1                                    
02ca5800: b.eq    #0x2ca5820                                 
02ca5804: subs    x9, x9, #1                                 
02ca5808: add     x10, x10, #0x10                            &6266010
02ca580c: b.ne    #0x2ca57f8                                 
02ca5810: mov     x0, x20                                    
02ca5814: mov     w2, wzr                                    
02ca5818: bl      #0x2baa05c                                 fn_2baa05c
02ca581c: b       #0x2ca582c                                 
02ca5820: ldrsw   x9, [x10]                                  
02ca5824: add     x8, x8, x9, lsl #4                         &6266000
02ca5828: add     x0, x8, #0x138                             &6266138
02ca582c: ldp     x8, x1, [x0]                               
02ca5830: mov     x0, x20                                    
02ca5834: blr     x8                                         
02ca5838: tbz     w0, #0, #0x2ca5c18                         
02ca583c: ldr     x20, [sp, #0x38]                           
02ca5840: cbz     x20, #0x2ca5d3c                            
02ca5844: ldr     x8, [x20]                                  
02ca5848: adrp    x10, #0x6266000                            
02ca584c: ldrh    w9, [x8, #0x12e]                           
02ca5850: ldr     x10, [x10, #0x2c8]                         T:type56097(k15)
02ca5854: ldr     x1, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca5858: cbz     x9, #0x2ca587c                             
02ca585c: ldr     x10, [x8, #0xb0]                           S:'native_banner_ad_on_off'
02ca5860: add     x10, x10, #8                               &6266008
02ca5864: ldur    x11, [x10, #-8]                            
02ca5868: cmp     x11, x1                                    
02ca586c: b.eq    #0x2ca588c                                 
02ca5870: subs    x9, x9, #1                                 
02ca5874: add     x10, x10, #0x10                            &6266010
02ca5878: b.ne    #0x2ca5864                                 
02ca587c: mov     x0, x20                                    
02ca5880: mov     w2, wzr                                    
02ca5884: bl      #0x2baa05c                                 fn_2baa05c
02ca5888: b       #0x2ca5898                                 
02ca588c: ldrsw   x9, [x10]                                  
02ca5890: add     x8, x8, x9, lsl #4                         &6266000
02ca5894: add     x0, x8, #0x138                             &6266138
02ca5898: ldp     x8, x1, [x0]                               
02ca589c: mov     x0, x20                                    
02ca58a0: blr     x8                                         
02ca58a4: cbz     x0, #0x2ca5d44                             
02ca58a8: ldr     x20, [x0, #0x10]                           S:'mrec_ad_on_off'
02ca58ac: cbz     x20, #0x2ca5d48                            
02ca58b0: ldr     x8, [x20]                                  
02ca58b4: adrp    x10, #0x6266000                            
02ca58b8: ldrh    w9, [x8, #0x12e]                           
02ca58bc: ldr     x10, [x10, #0x2a8]                         T:UnityEngine.Purchasing.ICart
02ca58c0: ldr     x1, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca58c4: cbz     x9, #0x2ca58e8                             
02ca58c8: ldr     x10, [x8, #0xb0]                           S:'native_banner_ad_on_off'
02ca58cc: add     x10, x10, #8                               &6266008
02ca58d0: ldur    x11, [x10, #-8]                            
02ca58d4: cmp     x11, x1                                    
02ca58d8: b.eq    #0x2ca58f8                                 
02ca58dc: subs    x9, x9, #1                                 
02ca58e0: add     x10, x10, #0x10                            &6266010
02ca58e4: b.ne    #0x2ca58d0                                 
02ca58e8: mov     x0, x20                                    
02ca58ec: mov     w2, wzr                                    
02ca58f0: bl      #0x2baa05c                                 fn_2baa05c
02ca58f4: b       #0x2ca5904                                 
02ca58f8: ldrsw   x9, [x10]                                  
02ca58fc: add     x8, x8, x9, lsl #4                         &6266000
02ca5900: add     x0, x8, #0x138                             &6266138
02ca5904: ldp     x8, x1, [x0]                               
02ca5908: mov     x0, x20                                    
02ca590c: blr     x8                                         
02ca5910: mov     x20, x0                                    
02ca5914: cbz     x0, #0x2ca5d40                             
02ca5918: ldr     x8, [x20]                                  
02ca591c: adrp    x10, #0x6266000                            
02ca5920: ldrh    w9, [x8, #0x12e]                           
02ca5924: ldr     x10, [x10, #0x2b0]                         T:type11754(k15)
02ca5928: ldr     x1, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca592c: cbz     x9, #0x2ca5950                             
02ca5930: ldr     x10, [x8, #0xb0]                           S:'native_banner_ad_on_off'
02ca5934: add     x10, x10, #8                               &6266008
02ca5938: ldur    x11, [x10, #-8]                            
02ca593c: cmp     x11, x1                                    
02ca5940: b.eq    #0x2ca5960                                 
02ca5944: subs    x9, x9, #1                                 
02ca5948: add     x10, x10, #0x10                            &6266010
02ca594c: b.ne    #0x2ca5938                                 
02ca5950: mov     x0, x20                                    
02ca5954: mov     w2, wzr                                    
02ca5958: bl      #0x2baa05c                                 fn_2baa05c
02ca595c: b       #0x2ca596c                                 
02ca5960: ldrsw   x9, [x10]                                  
02ca5964: add     x8, x8, x9, lsl #4                         &6266000
02ca5968: add     x0, x8, #0x138                             &6266138
02ca596c: ldp     x8, x1, [x0]                               
02ca5970: mov     x0, x20                                    
02ca5974: blr     x8                                         
02ca5978: mov     x20, x0                                    
02ca597c: str     x0, [sp, #0x30]                            
02ca5980: stp     xzr, x25, [sp, #0x10]                      
02ca5984: cbz     x0, #0x2ca5af0                             
02ca5988: ldr     x8, [x20]                                  
02ca598c: ldr     x1, [x22]                                  &2c5bbd4(=a9bd7bfdd503233f)
02ca5990: ldrh    w9, [x8, #0x12e]                           
02ca5994: cbz     x9, #0x2ca59b8                             
02ca5998: ldr     x10, [x8, #0xb0]                           S:'native_banner_ad_on_off'
02ca599c: add     x10, x10, #8                               &6266008
02ca59a0: ldur    x11, [x10, #-8]                            
02ca59a4: cmp     x11, x1                                    
02ca59a8: b.eq    #0x2ca59c8                                 
02ca59ac: subs    x9, x9, #1                                 
02ca59b0: add     x10, x10, #0x10                            &6266010
02ca59b4: b.ne    #0x2ca59a0                                 
02ca59b8: mov     x0, x20                                    
02ca59bc: mov     w2, wzr                                    
02ca59c0: bl      #0x2baa05c                                 fn_2baa05c
02ca59c4: b       #0x2ca59d4                                 
02ca59c8: ldrsw   x9, [x10]                                  
02ca59cc: add     x8, x8, x9, lsl #4                         &6266000
02ca59d0: add     x0, x8, #0x138                             &6266138
02ca59d4: ldp     x8, x1, [x0]                               
02ca59d8: mov     x0, x20                                    
02ca59dc: blr     x8                                         
02ca59e0: tbz     w0, #0, #0x2ca5af8                         
02ca59e4: ldr     x20, [sp, #0x30]                           
02ca59e8: cbz     x20, #0x2ca5b90                            
02ca59ec: ldr     x8, [x20]                                  
02ca59f0: ldr     x1, [x28]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca59f4: ldrh    w9, [x8, #0x12e]                           
02ca59f8: cbz     x9, #0x2ca5a1c                             
02ca59fc: ldr     x10, [x8, #0xb0]                           S:'native_banner_ad_on_off'
02ca5a00: add     x10, x10, #8                               &6266008
02ca5a04: ldur    x11, [x10, #-8]                            
02ca5a08: cmp     x11, x1                                    
02ca5a0c: b.eq    #0x2ca5a2c                                 
02ca5a10: subs    x9, x9, #1                                 
02ca5a14: add     x10, x10, #0x10                            &6266010
02ca5a18: b.ne    #0x2ca5a04                                 
02ca5a1c: mov     x0, x20                                    
02ca5a20: mov     w2, wzr                                    
02ca5a24: bl      #0x2baa05c                                 fn_2baa05c
02ca5a28: b       #0x2ca5a38                                 
02ca5a2c: ldrsw   x9, [x10]                                  
02ca5a30: add     x8, x8, x9, lsl #4                         &6266000
02ca5a34: add     x0, x8, #0x138                             &6266138
02ca5a38: ldp     x8, x1, [x0]                               
02ca5a3c: mov     x0, x20                                    
02ca5a40: blr     x8                                         
02ca5a44: mov     x20, x0                                    
02ca5a48: cbz     x0, #0x2ca5b80                             
02ca5a4c: ldr     x0, [x20, #0x10]                           
02ca5a50: cbz     x0, #0x2ca5b88                             
02ca5a54: mov     x1, xzr                                    
02ca5a58: bl      #0x57edb20                                 UnityEngine.Purchasing.Product::get_definition
02ca5a5c: cbz     x0, #0x2ca5b78                             
02ca5a60: ldr     x8, [x20, #0x10]                           
02ca5a64: cbz     x8, #0x2ca5b98                             
02ca5a68: ldr     x20, [x0, #0x18]                           S:'level_show_popuprate'
02ca5a6c: mov     x0, x8                                     
02ca5a70: mov     x1, xzr                                    
02ca5a74: bl      #0x57edb20                                 UnityEngine.Purchasing.Product::get_definition
02ca5a78: mov     x8, x0                                     
02ca5a7c: cbz     x0, #0x2ca5ba0                             
02ca5a80: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca5a84: ldr     w26, [x8, #0x28]                           S:'banner_ad_on_off'
02ca5a88: ldr     w9, [x0, #0xe4]                            [62660e4]=0 f=0,0
02ca5a8c: cbnz    w9, #0x2ca5a98                             
02ca5a90: bl      #0x2b70f30                                 fn_2b70f30
02ca5a94: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca5a98: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time'
02ca5a9c: ldr     x0, [x29]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca5aa0: str     w26, [sp, #0xc]                            
02ca5aa4: ldr     x21, [x8]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca5aa8: add     x1, sp, #0xc                               
02ca5aac: bl      #0x2b70f38                                 fn_2b70f38
02ca5ab0: mov     x2, x0                                     
02ca5ab4: ldr     x0, [x27]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca5ab8: mov     x1, x20                                    
02ca5abc: mov     x3, xzr                                    
02ca5ac0: bl      #0x4ca7720                                 System.String::Format
02ca5ac4: mov     x1, x0                                     
02ca5ac8: mov     x0, x21                                    
02ca5acc: bl      #0x2ca4738                                 WLog::Log
02ca5ad0: cbz     w26, #0x2ca5ae8                            
02ca5ad4: ldr     x0, [x19, #0x40]                           ._purchasedProductIds
02ca5ad8: cbz     x0, #0x2ca5ba8                             
02ca5adc: ldr     x2, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca5ae0: mov     x1, x20                                    
02ca5ae4: bl      #0x4987adc                                 fn_4987adc
02ca5ae8: ldr     x20, [sp, #0x30]                           
02ca5aec: cbnz    x20, #0x2ca5988                            
02ca5af0: bl      #0x2b7105c                                 fn_2b7105c
02ca5af4: b       #0x2ca5d5c                                 
02ca5af8: mov     x20, xzr                                   
02ca5afc: add     x8, sp, #0x30                              
02ca5b00: ldr     x21, [x8]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca5b04: cbz     x21, #0x2ca5b68                            
02ca5b08: ldr     x8, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca5b0c: adrp    x10, #0x6263000                            
02ca5b10: ldrh    w9, [x8, #0x12e]                           
02ca5b14: ldr     x10, [x10, #0x980]                         T:System.IDisposable
02ca5b18: ldr     x1, [x10]                                  &2c5bbd4(=a9bd7bfdd503233f)
02ca5b1c: cbz     x9, #0x2ca5b40                             
02ca5b20: ldr     x10, [x8, #0xb0]                           S:'native_banner_ad_on_off'
02ca5b24: add     x10, x10, #8                               &6263008
02ca5b28: ldur    x11, [x10, #-8]                            
02ca5b2c: cmp     x11, x1                                    
02ca5b30: b.eq    #0x2ca5b50                                 
02ca5b34: subs    x9, x9, #1                                 
02ca5b38: add     x10, x10, #0x10                            &6263010
02ca5b3c: b.ne    #0x2ca5b28                                 
02ca5b40: mov     x0, x21                                    
02ca5b44: mov     w2, wzr                                    
02ca5b48: bl      #0x2baa05c                                 fn_2baa05c
02ca5b4c: b       #0x2ca5b5c                                 
02ca5b50: ldrsw   x9, [x10]                                  
02ca5b54: add     x8, x8, x9, lsl #4                         &6266000
02ca5b58: add     x0, x8, #0x138                             &6266138
02ca5b5c: ldp     x8, x1, [x0]                               
02ca5b60: mov     x0, x21                                    
02ca5b64: blr     x8                                         
02ca5b68: cbnz    x20, #0x2ca5d4c                            
02ca5b6c: ldr     x20, [sp, #0x38]                           
02ca5b70: cbnz    x20, #0x2ca57e0                            
02ca5b74: b       #0x2ca5d38                                 
02ca5b78: bl      #0x2b7105c                                 fn_2b7105c
02ca5b7c: b       #0x2ca5d5c                                 
02ca5b80: bl      #0x2b7105c                                 fn_2b7105c
02ca5b84: b       #0x2ca5d5c                                 
02ca5b88: bl      #0x2b7105c                                 fn_2b7105c
02ca5b8c: b       #0x2ca5d5c                                 
02ca5b90: bl      #0x2b7105c                                 fn_2b7105c
02ca5b94: b       #0x2ca5d5c                                 
02ca5b98: bl      #0x2b7105c                                 fn_2b7105c
02ca5b9c: b       #0x2ca5d5c                                 
02ca5ba0: bl      #0x2b7105c                                 fn_2b7105c
02ca5ba4: b       #0x2ca5d5c                                 
02ca5ba8: bl      #0x2b7105c                                 fn_2b7105c
02ca5bac: b       #0x2ca5d5c                                 
02ca5bb0: b       #0x2ca5bec                                 
02ca5bb4: b       #0x2ca5bec                                 
02ca5bb8: b       #0x2ca5bec                                 
02ca5bbc: b       #0x2ca5bec                                 
02ca5bc0: b       #0x2ca5bec                                 
02ca5bc4: b       #0x2ca5bec                                 
02ca5bc8: b       #0x2ca5bec                                 
02ca5bcc: b       #0x2ca5bec                                 
02ca5bd0: b       #0x2ca5bec                                 
02ca5bd4: b       #0x2ca5bec                                 
02ca5bd8: b       #0x2ca5bec                                 
02ca5bdc: b       #0x2ca5bec                                 
02ca5be0: b       #0x2ca5bec                                 
02ca5be4: b       #0x2ca5bec                                 
02ca5be8: b       #0x2ca5bec                                 
02ca5bec: mov     x20, x1                                    
02ca5bf0: mov     x21, x0                                    
02ca5bf4: cmp     w20, #1                                    
02ca5bf8: b.ne    #0x2ca5d64                                 
02ca5bfc: mov     x0, x21                                    
02ca5c00: bl      #0x5e90260                                 fn_5e90260
02ca5c04: ldr     x20, [x0]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca5c08: str     x20, [sp, #0x10]                           
02ca5c0c: bl      #0x5e90270                                 fn_5e90270
02ca5c10: ldr     x8, [sp, #0x18]                            
02ca5c14: b       #0x2ca5b00                                 
02ca5c18: mov     w21, #7                                    
02ca5c1c: ldr     x8, [sp, #0x28]                            
02ca5c20: ldr     x20, [x8]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca5c24: cbz     x20, #0x2ca5c88                            
02ca5c28: adrp    x10, #0x6263000                            
02ca5c2c: ldr     x8, [x20]                                  
02ca5c30: ldr     x10, [x10, #0x980]                         T:System.IDisposable
02ca5c34: ldrh    w9, [x8, #0x12e]                           
02ca5c38: ldr     x1, [x10]                                  &2c5bbd4(=a9bd7bfdd503233f)
02ca5c3c: cbz     x9, #0x2ca5c60                             
02ca5c40: ldr     x10, [x8, #0xb0]                           S:'native_banner_ad_on_off'
02ca5c44: add     x10, x10, #8                               &6263008
02ca5c48: ldur    x11, [x10, #-8]                            
02ca5c4c: cmp     x11, x1                                    
02ca5c50: b.eq    #0x2ca5c70                                 
02ca5c54: subs    x9, x9, #1                                 
02ca5c58: add     x10, x10, #0x10                            &6263010
02ca5c5c: b.ne    #0x2ca5c48                                 
02ca5c60: mov     x0, x20                                    
02ca5c64: mov     w2, wzr                                    
02ca5c68: bl      #0x2baa05c                                 fn_2baa05c
02ca5c6c: b       #0x2ca5c7c                                 
02ca5c70: ldrsw   x9, [x10]                                  
02ca5c74: add     x8, x8, x9, lsl #4                         &6266000
02ca5c78: add     x0, x8, #0x138                             &6266138
02ca5c7c: ldp     x8, x1, [x0]                               
02ca5c80: mov     x0, x20                                    
02ca5c84: blr     x8                                         
02ca5c88: ldr     x0, [sp, #0x20]                            
02ca5c8c: cbnz    x0, #0x2ca5d58                             
02ca5c90: cmp     w21, #7                                    
02ca5c94: b.eq    #0x2ca5c9c                                 
02ca5c98: cbnz    w21, #0x2ca5d18                            
02ca5c9c: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca5ca0: adrp    x22, #0x6266000                            
02ca5ca4: adrp    x21, #0x6266000                            
02ca5ca8: ldr     x22, [x22, #0x2f8]                         S:', '
02ca5cac: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02ca5cb0: ldr     x21, [x21, #0x2f0]                         S:'Owned non-consumable products: '
02ca5cb4: cbnz    w8, #0x2ca5cc0                             
02ca5cb8: bl      #0x2b70f30                                 fn_2b70f30
02ca5cbc: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca5cc0: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time'
02ca5cc4: ldr     x1, [x19, #0x40]                           ._purchasedProductIds
02ca5cc8: mov     x2, xzr                                    
02ca5ccc: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca5cd0: ldr     x20, [x8]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca5cd4: bl      #0x4ca7bdc                                 System.String::Join
02ca5cd8: ldr     x8, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca5cdc: mov     x1, x0                                     
02ca5ce0: mov     x2, xzr                                    
02ca5ce4: mov     x0, x8                                     
02ca5ce8: bl      #0x4c9c514                                 System.String::Concat
02ca5cec: mov     x1, x0                                     
02ca5cf0: mov     x0, x20                                    
02ca5cf4: bl      #0x2ca4738                                 WLog::Log
02ca5cf8: ldr     x8, [x19, #0x48]                           .OnIAPReady
02ca5cfc: mov     w9, #1                                     
02ca5d00: strb    w9, [x19, #0x30]                           ._isInit
02ca5d04: cbz     x8, #0x2ca5d18                             
02ca5d08: ldr     x9, [x8, #0x18]                            S:'level_show_popuprate'
02ca5d0c: ldr     x0, [x8, #0x40]                            S:'native_collap_ad_on_off'
02ca5d10: ldr     x1, [x8, #0x28]                            S:'banner_ad_on_off'
02ca5d14: blr     x9                                         
02ca5d18: ldp     x20, x19, [sp, #0x90]                      
02ca5d1c: ldp     x22, x21, [sp, #0x80]                      
02ca5d20: ldp     x24, x23, [sp, #0x70]                      
02ca5d24: ldp     x26, x25, [sp, #0x60]                      
02ca5d28: ldp     x28, x27, [sp, #0x50]                      
02ca5d2c: ldp     x29, x30, [sp, #0x40]                      
02ca5d30: add     sp, sp, #0xa0                              
02ca5d34: ret                                                
02ca5d38: bl      #0x2b7105c                                 fn_2b7105c
02ca5d3c: bl      #0x2b7105c                                 fn_2b7105c
02ca5d40: bl      #0x2b7105c                                 fn_2b7105c
02ca5d44: bl      #0x2b7105c                                 fn_2b7105c
02ca5d48: bl      #0x2b7105c                                 fn_2b7105c
02ca5d4c: mov     x0, x20                                    
02ca5d50: bl      #0x2b71054                                 fn_2b71054
02ca5d54: bl      #0x2b7105c                                 fn_2b7105c
02ca5d58: bl      #0x2b71054                                 fn_2b71054
02ca5d5c: mov     x20, x1                                    
02ca5d60: mov     x21, x0                                    
02ca5d64: add     x0, sp, #0x10                              
02ca5d68: bl      #0x27369c4                                 fn_27369c4
02ca5d6c: b       #0x2ca5da0                                 
02ca5d70: b       #0x2ca5d98                                 
02ca5d74: b       #0x2ca5d98                                 
02ca5d78: b       #0x2ca5d98                                 
02ca5d7c: b       #0x2ca5d98                                 
02ca5d80: b       #0x2ca5d98                                 
02ca5d84: b       #0x2ca5d98                                 
02ca5d88: b       #0x2ca5d98                                 
02ca5d8c: b       #0x2ca5d98                                 
02ca5d90: b       #0x2ca5d98                                 
02ca5d94: b       #0x2ca5d98                                 
02ca5d98: mov     x20, x1                                    
02ca5d9c: mov     x21, x0                                    
02ca5da0: cmp     w20, #1                                    
02ca5da4: b.ne    #0x2ca5dc8                                 
02ca5da8: mov     x0, x21                                    
02ca5dac: bl      #0x5e90260                                 fn_5e90260
02ca5db0: ldr     x8, [x0]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca5db4: str     x8, [sp, #0x20]                            
02ca5db8: bl      #0x5e90270                                 fn_5e90270
02ca5dbc: mov     w21, wzr                                   
02ca5dc0: b       #0x2ca5c1c                                 
02ca5dc4: mov     x21, x0                                    
02ca5dc8: add     x0, sp, #0x20                              
02ca5dcc: bl      #0x27369c4                                 fn_27369c4
02ca5dd0: mov     x0, x21                                    
02ca5dd4: bl      #0x2c6051c                                 fn_2c6051c
02ca5dd8: bl      #0x27369b8                                 fn_27369b8
## OnPurchaseConfirmed(UnityEngine.Purchasing.Order order) -> void
---- IAPManager::OnPurchaseConfirmed 0x2ca5ddc
02ca5ddc: sub     sp, sp, #0x50                              
02ca5de0: str     x30, [sp, #0x10]                           
02ca5de4: stp     x24, x23, [sp, #0x20]                      
02ca5de8: stp     x22, x21, [sp, #0x30]                      
02ca5dec: stp     x20, x19, [sp, #0x40]                      
02ca5df0: adrp    x21, #0x662f000                            
02ca5df4: mov     x20, x1                                    
02ca5df8: mov     x19, x0                                    
02ca5dfc: ldrb    w8, [x21, #0xad8]                          
02ca5e00: tbnz    w8, #0, #0x2ca5e84                         
02ca5e04: adrp    x0, #0x6266000                             
02ca5e08: ldr     x0, [x0, #0x310]                           MS:System.Enum::TryParse
02ca5e0c: bl      #0x2b70db0                                 fn_2b70db0
02ca5e10: adrp    x0, #0x6266000                             
02ca5e14: ldr     x0, [x0, #0x298]                           MS:System.Collections.Generic.HashSet`1::Add
02ca5e18: bl      #0x2b70db0                                 fn_2b70db0
02ca5e1c: adrp    x0, #0x6266000                             
02ca5e20: ldr     x0, [x0, #0x318]                           T:UnityEngine.Purchasing.IOrderInfo
02ca5e24: bl      #0x2b70db0                                 fn_2b70db0
02ca5e28: adrp    x0, #0x6266000                             
02ca5e2c: ldr     x0, [x0, #0x320]                           T:UnityEngine.Purchasing.IPurchasedProductInfo
02ca5e30: bl      #0x2b70db0                                 fn_2b70db0
02ca5e34: adrp    x0, #0x6266000                             
02ca5e38: ldr     x0, [x0, #0x328]                           MS:System.Collections.Generic.List`1::get_Count
02ca5e3c: bl      #0x2b70db0                                 fn_2b70db0
02ca5e40: adrp    x0, #0x6266000                             
02ca5e44: ldr     x0, [x0, #0x330]                           MS:System.Collections.Generic.List`1::get_Item
02ca5e48: bl      #0x2b70db0                                 fn_2b70db0
02ca5e4c: adrp    x0, #0x6266000                             
02ca5e50: ldr     x0, [x0, #0x198]                           T:LogTags
02ca5e54: bl      #0x2b70db0                                 fn_2b70db0
02ca5e58: adrp    x0, #0x6266000                             
02ca5e5c: ldr     x0, [x0, #0x338]                           S:'Purchase confirmed: {0} x{1}'
02ca5e60: bl      #0x2b70db0                                 fn_2b70db0
02ca5e64: adrp    x0, #0x6266000                             
02ca5e68: ldr     x0, [x0, #0x340]                           S:"'."
02ca5e6c: bl      #0x2b70db0                                 fn_2b70db0
02ca5e70: adrp    x0, #0x6266000                             
02ca5e74: ldr     x0, [x0, #0x348]                           S:"Unknown productId '"
02ca5e78: bl      #0x2b70db0                                 fn_2b70db0
02ca5e7c: mov     w8, #1                                     
02ca5e80: strb    w8, [x21, #0xad8]                          
02ca5e84: str     wzr, [sp, #0x1c]                           
02ca5e88: str     wzr, [sp, #8]                              
02ca5e8c: cbz     x20, #0x2ca6194                            
02ca5e90: ldr     x21, [x20, #0x18]                          
02ca5e94: cbz     x21, #0x2ca6194                            
02ca5e98: adrp    x22, #0x6266000                            
02ca5e9c: ldr     x8, [x21]                                  &2b706c4(=eb01011ff9400808)
02ca5ea0: ldr     x22, [x22, #0x318]                         T:UnityEngine.Purchasing.IOrderInfo
02ca5ea4: ldrh    w9, [x8, #0x12e]                           
02ca5ea8: ldr     x1, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca5eac: cbz     x9, #0x2ca5ed0                             
02ca5eb0: ldr     x10, [x8, #0xb0]                           
02ca5eb4: add     x10, x10, #8                               
02ca5eb8: ldur    x11, [x10, #-8]                            
02ca5ebc: cmp     x11, x1                                    
02ca5ec0: b.eq    #0x2ca5ee0                                 
02ca5ec4: subs    x9, x9, #1                                 
02ca5ec8: add     x10, x10, #0x10                            
02ca5ecc: b.ne    #0x2ca5eb8                                 
02ca5ed0: mov     x0, x21                                    
02ca5ed4: mov     w2, #3                                     
02ca5ed8: bl      #0x2baa05c                                 fn_2baa05c
02ca5edc: b       #0x2ca5ef0                                 
02ca5ee0: ldr     w9, [x10]                                  
02ca5ee4: add     w9, w9, #3                                 
02ca5ee8: add     x8, x8, w9, sxtw #4                        
02ca5eec: add     x0, x8, #0x138                             
02ca5ef0: ldp     x8, x1, [x0]                               
02ca5ef4: mov     x0, x21                                    
02ca5ef8: blr     x8                                         
02ca5efc: cbz     x0, #0x2ca6194                             
02ca5f00: ldr     x21, [x20, #0x18]                          
02ca5f04: cbz     x21, #0x2ca61ac                            
02ca5f08: ldr     x8, [x21]                                  &2b706c4(=eb01011ff9400808)
02ca5f0c: ldr     x1, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca5f10: ldrh    w9, [x8, #0x12e]                           
02ca5f14: cbz     x9, #0x2ca5f38                             
02ca5f18: ldr     x10, [x8, #0xb0]                           
02ca5f1c: add     x10, x10, #8                               
02ca5f20: ldur    x11, [x10, #-8]                            
02ca5f24: cmp     x11, x1                                    
02ca5f28: b.eq    #0x2ca5f48                                 
02ca5f2c: subs    x9, x9, #1                                 
02ca5f30: add     x10, x10, #0x10                            
02ca5f34: b.ne    #0x2ca5f20                                 
02ca5f38: mov     x0, x21                                    
02ca5f3c: mov     w2, #3                                     
02ca5f40: bl      #0x2baa05c                                 fn_2baa05c
02ca5f44: b       #0x2ca5f58                                 
02ca5f48: ldr     w9, [x10]                                  
02ca5f4c: add     w9, w9, #3                                 
02ca5f50: add     x8, x8, w9, sxtw #4                        
02ca5f54: add     x0, x8, #0x138                             
02ca5f58: ldp     x8, x1, [x0]                               
02ca5f5c: mov     x0, x21                                    
02ca5f60: blr     x8                                         
02ca5f64: cbz     x0, #0x2ca61ac                             
02ca5f68: ldr     w8, [x0, #0x18]                            S:'level_show_popuprate'
02ca5f6c: cbz     w8, #0x2ca6194                             
02ca5f70: ldr     x21, [x20, #0x18]                          
02ca5f74: cbz     x21, #0x2ca61ac                            
02ca5f78: ldr     x8, [x21]                                  &2b706c4(=eb01011ff9400808)
02ca5f7c: ldr     x1, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca5f80: ldrh    w9, [x8, #0x12e]                           
02ca5f84: cbz     x9, #0x2ca5fa8                             
02ca5f88: ldr     x10, [x8, #0xb0]                           
02ca5f8c: add     x10, x10, #8                               
02ca5f90: ldur    x11, [x10, #-8]                            
02ca5f94: cmp     x11, x1                                    
02ca5f98: b.eq    #0x2ca5fb8                                 
02ca5f9c: subs    x9, x9, #1                                 
02ca5fa0: add     x10, x10, #0x10                            
02ca5fa4: b.ne    #0x2ca5f90                                 
02ca5fa8: mov     x0, x21                                    
02ca5fac: mov     w2, #3                                     
02ca5fb0: bl      #0x2baa05c                                 fn_2baa05c
02ca5fb4: b       #0x2ca5fc8                                 
02ca5fb8: ldr     w9, [x10]                                  
02ca5fbc: add     w9, w9, #3                                 
02ca5fc0: add     x8, x8, w9, sxtw #4                        
02ca5fc4: add     x0, x8, #0x138                             
02ca5fc8: ldp     x8, x1, [x0]                               
02ca5fcc: mov     x0, x21                                    
02ca5fd0: blr     x8                                         
02ca5fd4: cbz     x0, #0x2ca61ac                             
02ca5fd8: adrp    x8, #0x6266000                             
02ca5fdc: mov     w1, wzr                                    
02ca5fe0: ldr     x8, [x8, #0x330]                           MS:System.Collections.Generic.List`1::get_Item
02ca5fe4: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca5fe8: bl      #0x35a8f3c                                 fn_35a8f3c
02ca5fec: cbz     x0, #0x2ca61ac                             
02ca5ff0: adrp    x10, #0x6266000                            
02ca5ff4: ldr     x8, [x0]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca5ff8: mov     x21, x0                                    
02ca5ffc: ldr     x10, [x10, #0x320]                         T:UnityEngine.Purchasing.IPurchasedProductInfo
02ca6000: ldrh    w9, [x8, #0x12e]                           
02ca6004: ldr     x1, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca6008: cbz     x9, #0x2ca602c                             
02ca600c: ldr     x10, [x8, #0xb0]                           S:'native_banner_ad_on_off'
02ca6010: add     x10, x10, #8                               &6266008
02ca6014: ldur    x11, [x10, #-8]                            
02ca6018: cmp     x11, x1                                    
02ca601c: b.eq    #0x2ca603c                                 
02ca6020: subs    x9, x9, #1                                 
02ca6024: add     x10, x10, #0x10                            &6266010
02ca6028: b.ne    #0x2ca6014                                 
02ca602c: mov     x0, x21                                    
02ca6030: mov     w2, wzr                                    
02ca6034: bl      #0x2baa05c                                 fn_2baa05c
02ca6038: b       #0x2ca6048                                 
02ca603c: ldrsw   x9, [x10]                                  
02ca6040: add     x8, x8, x9, lsl #4                         &6266000
02ca6044: add     x0, x8, #0x138                             &6266138
02ca6048: ldp     x8, x1, [x0]                               
02ca604c: mov     x0, x21                                    
02ca6050: blr     x8                                         
02ca6054: mov     x21, x0                                    
02ca6058: mov     x0, x20                                    
02ca605c: bl      #0x2ca6290                                 IAPManager::ParseQuantity
02ca6060: adrp    x23, #0x6266000                            
02ca6064: mov     w20, w0                                    
02ca6068: ldr     x23, [x23, #0x198]                         T:LogTags
02ca606c: ldr     x8, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca6070: ldr     w9, [x8, #0xe4]                            [62660e4]=0 f=0,0
02ca6074: cbnz    w9, #0x2ca6084                             
02ca6078: mov     x0, x8                                     
02ca607c: bl      #0x2b70f30                                 fn_2b70f30
02ca6080: ldr     x8, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca6084: adrp    x24, #0x6263000                            
02ca6088: ldr     x8, [x8, #0xb8]                            S:'banner_native_refresh_time'
02ca608c: add     x1, sp, #0x18                              
02ca6090: ldr     x24, [x24, #0x970]                         &6645c70(=0)
02ca6094: str     w20, [sp, #0x18]                           
02ca6098: ldr     x22, [x8]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca609c: ldr     x0, [x24, #0x48]                           &6263098(=0)
02ca60a0: bl      #0x2b70f38                                 fn_2b70f38
02ca60a4: adrp    x8, #0x6266000                             
02ca60a8: mov     x2, x0                                     
02ca60ac: mov     x1, x21                                    
02ca60b0: ldr     x8, [x8, #0x338]                           S:'Purchase confirmed: {0} x{1}'
02ca60b4: mov     x3, xzr                                    
02ca60b8: ldr     x8, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca60bc: mov     x0, x8                                     
02ca60c0: bl      #0x4ca7720                                 System.String::Format
02ca60c4: mov     x1, x0                                     
02ca60c8: mov     x0, x22                                    
02ca60cc: bl      #0x2ca4738                                 WLog::Log
02ca60d0: ldr     x0, [x24, #0x98]                           [6263098]=0 f=0,0
02ca60d4: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02ca60d8: cbnz    w8, #0x2ca60e0                             
02ca60dc: bl      #0x2b70f30                                 fn_2b70f30
02ca60e0: adrp    x8, #0x6266000                             
02ca60e4: add     x1, sp, #0x1c                              
02ca60e8: mov     x0, x21                                    
02ca60ec: ldr     x8, [x8, #0x310]                           MS:System.Enum::TryParse
02ca60f0: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca60f4: bl      #0x31788a0                                 fn_31788a0
02ca60f8: tbz     w0, #0, #0x2ca613c                         
02ca60fc: ldr     x0, [x19, #0x40]                           ._purchasedProductIds
02ca6100: cbz     x0, #0x2ca61ac                             
02ca6104: adrp    x8, #0x6266000                             
02ca6108: mov     x1, x21                                    
02ca610c: ldr     x8, [x8, #0x298]                           MS:System.Collections.Generic.HashSet`1::Add
02ca6110: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca6114: bl      #0x4987adc                                 fn_4987adc
02ca6118: ldr     x8, [x19, #0x50]                           .OnProductPurchased
02ca611c: cbz     x8, #0x2ca6188                             
02ca6120: ldr     w1, [sp, #0x1c]                            
02ca6124: ldr     x0, [x8, #0x40]                            S:'native_collap_ad_on_off'
02ca6128: ldr     x9, [x8, #0x18]                            S:'level_show_popuprate'
02ca612c: ldr     x3, [x8, #0x28]                            S:'banner_ad_on_off'
02ca6130: mov     w2, w20                                    
02ca6134: blr     x9                                         
02ca6138: b       #0x2ca6188                                 
02ca613c: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca6140: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02ca6144: cbnz    w8, #0x2ca6150                             
02ca6148: bl      #0x2b70f30                                 fn_2b70f30
02ca614c: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca6150: adrp    x8, #0x6266000                             
02ca6154: adrp    x10, #0x6266000                            
02ca6158: mov     x1, x21                                    
02ca615c: ldr     x8, [x8, #0x348]                           S:"Unknown productId '"
02ca6160: ldr     x9, [x0, #0xb8]                            S:'banner_native_refresh_time'
02ca6164: ldr     x10, [x10, #0x340]                         S:"'."
02ca6168: mov     x3, xzr                                    
02ca616c: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca6170: ldr     x2, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca6174: ldr     x20, [x9]                                  
02ca6178: bl      #0x4ca6dbc                                 System.String::Concat
02ca617c: mov     x1, x0                                     
02ca6180: mov     x0, x20                                    
02ca6184: bl      #0x2ca47ec                                 WLog::LogError
02ca6188: mov     x0, x19                                    
02ca618c: mov     x1, x21                                    
02ca6190: bl      #0x2ca6520                                 IAPManager::FireSuccessCallback
02ca6194: ldp     x20, x19, [sp, #0x40]                      
02ca6198: ldr     x30, [sp, #0x10]                           
02ca619c: ldp     x22, x21, [sp, #0x30]                      
02ca61a0: ldp     x24, x23, [sp, #0x20]                      
02ca61a4: add     sp, sp, #0x50                              
02ca61a8: ret                                                
02ca61ac: bl      #0x2b7105c                                 fn_2b7105c
02ca61b0: cmp     w1, #1                                     
02ca61b4: mov     x20, x0                                    
02ca61b8: b.ne    #0x2ca6284                                 
02ca61bc: mov     x0, x20                                    
02ca61c0: bl      #0x5e90260                                 fn_5e90260
02ca61c4: mov     x20, x0                                    
02ca61c8: adrp    x0, #0x6263000                             
02ca61cc: ldr     x0, [x0, #0xae0]                           T:System.Exception
02ca61d0: bl      #0x2b70dc4                                 fn_2b70dc4
02ca61d4: ldr     x8, [x20]                                  
02ca61d8: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca61dc: bl      #0x2b71464                                 fn_2b71464
02ca61e0: tbz     w0, #0, #0x2ca625c                         
02ca61e4: ldrsw   x23, [sp, #8]                              
02ca61e8: ldr     x20, [x20]                                 
02ca61ec: mov     x8, sp                                     
02ca61f0: str     x20, [x8, x23, lsl #3]                     
02ca61f4: add     w8, w23, #1                                
02ca61f8: str     w8, [sp, #8]                               
02ca61fc: bl      #0x5e90270                                 fn_5e90270
02ca6200: adrp    x0, #0x6266000                             
02ca6204: ldr     x0, [x0, #0x198]                           T:LogTags
02ca6208: bl      #0x2b70dc4                                 fn_2b70dc4
02ca620c: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02ca6210: cbnz    w8, #0x2ca6218                             
02ca6214: bl      #0x2b70f30                                 fn_2b70f30
02ca6218: adrp    x0, #0x6266000                             
02ca621c: ldr     x0, [x0, #0x198]                           T:LogTags
02ca6220: bl      #0x2b70dc4                                 fn_2b70dc4
02ca6224: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time'
02ca6228: adrp    x0, #0x6266000                             
02ca622c: ldr     x22, [x8]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca6230: ldr     x0, [x0, #0x350]                           S:"OnProductPurchased handler error for '{0}': {1}"
02ca6234: bl      #0x2b70dc4                                 fn_2b70dc4
02ca6238: mov     x1, x21                                    
02ca623c: mov     x2, x20                                    
02ca6240: mov     x3, xzr                                    
02ca6244: bl      #0x4ca7720                                 System.String::Format
02ca6248: mov     x1, x0                                     
02ca624c: mov     x0, x22                                    
02ca6250: bl      #0x2ca47ec                                 WLog::LogError
02ca6254: str     w23, [sp, #8]                              
02ca6258: b       #0x2ca6188                                 
02ca625c: mov     w0, #8                                     
02ca6260: bl      #0x5e90290                                 fn_5e90290
02ca6264: ldr     x8, [x20]                                  
02ca6268: str     x8, [x0]                                   
02ca626c: adrp    x1, #0x5e96000                             
02ca6270: add     x1, x1, #0x758                             &5e96758
02ca6274: mov     x2, xzr                                    
02ca6278: bl      #0x5e902a0                                 fn_5e902a0
02ca627c: mov     x20, x0                                    
02ca6280: bl      #0x5e90270                                 fn_5e90270
02ca6284: mov     x0, x20                                    
02ca6288: bl      #0x2c6051c                                 fn_2c6051c
02ca628c: bl      #0x27369b8                                 fn_27369b8
## OnPurchasePending(UnityEngine.Purchasing.PendingOrder order) -> void
---- IAPManager::OnPurchasePending 0x2ca673c
02ca673c: stp     x30, x23, [sp, #-0x30]!                    
02ca6740: stp     x22, x21, [sp, #0x10]                      
02ca6744: stp     x20, x19, [sp, #0x20]                      
02ca6748: adrp    x21, #0x662f000                            
02ca674c: mov     x19, x1                                    
02ca6750: mov     x20, x0                                    
02ca6754: ldrb    w8, [x21, #0xad9]                          
02ca6758: tbnz    w8, #0, #0x2ca67b8                         
02ca675c: adrp    x0, #0x6266000                             
02ca6760: ldr     x0, [x0, #0x318]                           T:UnityEngine.Purchasing.IOrderInfo
02ca6764: bl      #0x2b70db0                                 fn_2b70db0
02ca6768: adrp    x0, #0x6266000                             
02ca676c: ldr     x0, [x0, #0x320]                           T:UnityEngine.Purchasing.IPurchasedProductInfo
02ca6770: bl      #0x2b70db0                                 fn_2b70db0
02ca6774: adrp    x0, #0x6266000                             
02ca6778: ldr     x0, [x0, #0x328]                           MS:System.Collections.Generic.List`1::get_Count
02ca677c: bl      #0x2b70db0                                 fn_2b70db0
02ca6780: adrp    x0, #0x6266000                             
02ca6784: ldr     x0, [x0, #0x330]                           MS:System.Collections.Generic.List`1::get_Item
02ca6788: bl      #0x2b70db0                                 fn_2b70db0
02ca678c: adrp    x0, #0x6266000                             
02ca6790: ldr     x0, [x0, #0x198]                           T:LogTags
02ca6794: bl      #0x2b70db0                                 fn_2b70db0
02ca6798: adrp    x0, #0x6266000                             
02ca679c: ldr     x0, [x0, #0x3a0]                           S:'unknown'
02ca67a0: bl      #0x2b70db0                                 fn_2b70db0
02ca67a4: adrp    x0, #0x6266000                             
02ca67a8: ldr     x0, [x0, #0x3a8]                           S:'Purchase pending: '
02ca67ac: bl      #0x2b70db0                                 fn_2b70db0
02ca67b0: mov     w8, #1                                     
02ca67b4: strb    w8, [x21, #0xad9]                          
02ca67b8: cbz     x19, #0x2ca689c                            
02ca67bc: ldr     x21, [x19, #0x18]                          
02ca67c0: cbz     x21, #0x2ca689c                            
02ca67c4: adrp    x10, #0x6266000                            
02ca67c8: ldr     x8, [x21]                                  &2b706c4(=eb01011ff9400808)
02ca67cc: ldr     x10, [x10, #0x318]                         T:UnityEngine.Purchasing.IOrderInfo
02ca67d0: ldrh    w9, [x8, #0x12e]                           
02ca67d4: ldr     x1, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca67d8: cbz     x9, #0x2ca67fc                             
02ca67dc: ldr     x10, [x8, #0xb0]                           
02ca67e0: add     x10, x10, #8                               &6266008
02ca67e4: ldur    x11, [x10, #-8]                            
02ca67e8: cmp     x11, x1                                    
02ca67ec: b.eq    #0x2ca680c                                 
02ca67f0: subs    x9, x9, #1                                 
02ca67f4: add     x10, x10, #0x10                            &6266010
02ca67f8: b.ne    #0x2ca67e4                                 
02ca67fc: mov     x0, x21                                    
02ca6800: mov     w2, #3                                     
02ca6804: bl      #0x2baa05c                                 fn_2baa05c
02ca6808: b       #0x2ca681c                                 
02ca680c: ldr     w9, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca6810: add     w9, w9, #3                                 
02ca6814: add     x8, x8, w9, sxtw #4                        
02ca6818: add     x0, x8, #0x138                             
02ca681c: ldp     x8, x1, [x0]                               
02ca6820: mov     x0, x21                                    
02ca6824: blr     x8                                         
02ca6828: cbz     x0, #0x2ca689c                             
02ca682c: ldr     w8, [x0, #0x18]                            S:'level_show_popuprate'
02ca6830: cmp     w8, #0                                     
02ca6834: b.le    #0x2ca689c                                 
02ca6838: adrp    x8, #0x6266000                             
02ca683c: mov     w1, wzr                                    
02ca6840: ldr     x8, [x8, #0x330]                           MS:System.Collections.Generic.List`1::get_Item
02ca6844: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca6848: bl      #0x35a8f3c                                 fn_35a8f3c
02ca684c: cbz     x0, #0x2ca6930                             
02ca6850: adrp    x10, #0x6266000                            
02ca6854: ldr     x8, [x0]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca6858: mov     x21, x0                                    
02ca685c: ldr     x10, [x10, #0x320]                         T:UnityEngine.Purchasing.IPurchasedProductInfo
02ca6860: ldrh    w9, [x8, #0x12e]                           
02ca6864: ldr     x1, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca6868: cbz     x9, #0x2ca688c                             
02ca686c: ldr     x10, [x8, #0xb0]                           S:'native_banner_ad_on_off'
02ca6870: add     x10, x10, #8                               &6266008
02ca6874: ldur    x11, [x10, #-8]                            
02ca6878: cmp     x11, x1                                    
02ca687c: b.eq    #0x2ca6910                                 
02ca6880: subs    x9, x9, #1                                 
02ca6884: add     x10, x10, #0x10                            &6266010
02ca6888: b.ne    #0x2ca6874                                 
02ca688c: mov     x0, x21                                    
02ca6890: mov     w2, wzr                                    
02ca6894: bl      #0x2baa05c                                 fn_2baa05c
02ca6898: b       #0x2ca691c                                 
02ca689c: adrp    x8, #0x6266000                             
02ca68a0: ldr     x8, [x8, #0x3a0]                           S:'unknown'
02ca68a4: ldr     x21, [x8]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca68a8: adrp    x22, #0x6266000                            
02ca68ac: adrp    x23, #0x6266000                            
02ca68b0: ldr     x22, [x22, #0x198]                         T:LogTags
02ca68b4: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca68b8: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02ca68bc: ldr     x23, [x23, #0x3a8]                         S:'Purchase pending: '
02ca68c0: cbnz    w8, #0x2ca68cc                             
02ca68c4: bl      #0x2b70f30                                 fn_2b70f30
02ca68c8: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca68cc: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time'
02ca68d0: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca68d4: mov     x1, x21                                    
02ca68d8: mov     x2, xzr                                    
02ca68dc: ldr     x22, [x8]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca68e0: bl      #0x4c9c514                                 System.String::Concat
02ca68e4: mov     x1, x0                                     
02ca68e8: mov     x0, x22                                    
02ca68ec: bl      #0x2ca4738                                 WLog::Log
02ca68f0: ldr     x0, [x20, #0x38]                           ._storeController
02ca68f4: cbz     x0, #0x2ca6930                             
02ca68f8: mov     x1, x19                                    
02ca68fc: ldp     x20, x19, [sp, #0x20]                      
02ca6900: ldp     x22, x21, [sp, #0x10]                      
02ca6904: mov     x2, xzr                                    
02ca6908: ldp     x30, x23, [sp], #0x30                      
02ca690c: b       #0x571a324                                 UnityEngine.Purchasing.StoreController::ConfirmPurchase
02ca6910: ldrsw   x9, [x10]                                  
02ca6914: add     x8, x8, x9, lsl #4                         &6266000
02ca6918: add     x0, x8, #0x138                             &6266138
02ca691c: ldp     x8, x1, [x0]                               
02ca6920: mov     x0, x21                                    
02ca6924: blr     x8                                         
02ca6928: mov     x21, x0                                    
02ca692c: b       #0x2ca68a8                                 
02ca6930: bl      #0x2b7105c                                 fn_2b7105c
## OnPurchaseFailed(UnityEngine.Purchasing.FailedOrder failedOrder) -> void
---- IAPManager::OnPurchaseFailed 0x2ca6934
02ca6934: sub     sp, sp, #0x50                              
02ca6938: str     x30, [sp, #0x20]                           
02ca693c: stp     x22, x21, [sp, #0x30]                      
02ca6940: stp     x20, x19, [sp, #0x40]                      
02ca6944: adrp    x21, #0x662f000                            
02ca6948: mov     x20, x1                                    
02ca694c: mov     x19, x0                                    
02ca6950: ldrb    w8, [x21, #0xada]                          
02ca6954: tbnz    w8, #0, #0x2ca699c                         
02ca6958: adrp    x0, #0x6266000                             
02ca695c: ldr     x0, [x0, #0x3b0]                           MS:System.Collections.Generic.Dictionary`2::Clear
02ca6960: bl      #0x2b70db0                                 fn_2b70db0
02ca6964: adrp    x0, #0x6266000                             
02ca6968: ldr     x0, [x0, #0x198]                           T:LogTags
02ca696c: bl      #0x2b70db0                                 fn_2b70db0
02ca6970: adrp    x0, #0x6266000                             
02ca6974: ldr     x0, [x0, #0x3b8]                           T:UnityEngine.Purchasing.PurchaseFailureReason
02ca6978: bl      #0x2b70db0                                 fn_2b70db0
02ca697c: adrp    x0, #0x6266000                             
02ca6980: ldr     x0, [x0, #0x3c0]                           S:'Purchase failed: '
02ca6984: bl      #0x2b70db0                                 fn_2b70db0
02ca6988: adrp    x0, #0x6266000                             
02ca698c: ldr     x0, [x0, #0x3c8]                           S:'Unknown'
02ca6990: bl      #0x2b70db0                                 fn_2b70db0
02ca6994: mov     w8, #1                                     
02ca6998: strb    w8, [x21, #0xada]                          
02ca699c: adrp    x22, #0x6266000                            
02ca69a0: adrp    x21, #0x6266000                            
02ca69a4: ldr     x22, [x22, #0x3c8]                         S:'Unknown'
02ca69a8: ldr     x21, [x21, #0x198]                         T:LogTags
02ca69ac: cbz     x20, #0x2ca69e0                            
02ca69b0: adrp    x8, #0x6266000                             
02ca69b4: mov     x10, #-1                                   
02ca69b8: add     x0, sp, #8                                 
02ca69bc: ldr     x8, [x8, #0x3b8]                           T:UnityEngine.Purchasing.PurchaseFailureReason
02ca69c0: ldr     w9, [x20, #0x20]                           ._iAPProductSO
02ca69c4: mov     x1, xzr                                    
02ca69c8: ldr     x8, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca69cc: str     w9, [sp, #0x18]                            
02ca69d0: stp     x8, x10, [sp, #8]                          
02ca69d4: bl      #0x4e47e48                                 System.Enum::ToString
02ca69d8: mov     x8, x0                                     
02ca69dc: b       #0x2ca69e4                                 
02ca69e0: mov     x8, xzr                                    
02ca69e4: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca69e8: ldr     x9, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca69ec: adrp    x22, #0x6266000                            
02ca69f0: cmp     x8, #0                                     
02ca69f4: ldr     w10, [x0, #0xe4]                           [62660e4]=0 f=0,0
02ca69f8: ldr     x22, [x22, #0x3c0]                         S:'Purchase failed: '
02ca69fc: csel    x20, x9, x8, eq                            
02ca6a00: cbnz    w10, #0x2ca6a0c                            
02ca6a04: bl      #0x2b70f30                                 fn_2b70f30
02ca6a08: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca6a0c: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time'
02ca6a10: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca6a14: mov     x1, x20                                    
02ca6a18: mov     x2, xzr                                    
02ca6a1c: ldr     x21, [x8]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca6a20: bl      #0x4c9c514                                 System.String::Concat
02ca6a24: mov     x1, x0                                     
02ca6a28: mov     x0, x21                                    
02ca6a2c: bl      #0x2ca47ec                                 WLog::LogError
02ca6a30: ldr     x0, [x19, #0x58]                           ._pendingSuccessCallbacks
02ca6a34: cbz     x0, #0x2ca6a64                             
02ca6a38: adrp    x8, #0x6266000                             
02ca6a3c: ldr     x8, [x8, #0x3b0]                           MS:System.Collections.Generic.Dictionary`2::Clear
02ca6a40: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca6a44: bl      #0x452c7a4                                 fn_452c7a4
02ca6a48: mov     x0, x19                                    
02ca6a4c: bl      #0x2ca6a68                                 IAPManager::FireFailCallback
02ca6a50: ldp     x20, x19, [sp, #0x40]                      
02ca6a54: ldr     x30, [sp, #0x20]                           
02ca6a58: ldp     x22, x21, [sp, #0x30]                      
02ca6a5c: add     sp, sp, #0x50                              
02ca6a60: ret                                                
02ca6a64: bl      #0x2b7105c                                 fn_2b7105c
## OnPurchaseDeferred(UnityEngine.Purchasing.DeferredOrder deferredOrder) -> void
---- IAPManager::OnPurchaseDeferred 0x2ca6b68
02ca6b68: stp     x30, x21, [sp, #-0x20]!                    
02ca6b6c: stp     x20, x19, [sp, #0x10]                      
02ca6b70: adrp    x21, #0x662f000                            
02ca6b74: adrp    x20, #0x6266000                            
02ca6b78: mov     x19, x1                                    
02ca6b7c: ldrb    w8, [x21, #0xadb]                          
02ca6b80: ldr     x20, [x20, #0x198]                         T:LogTags
02ca6b84: tbnz    w8, #0, #0x2ca6ba8                         
02ca6b88: adrp    x0, #0x6266000                             
02ca6b8c: ldr     x0, [x0, #0x198]                           T:LogTags
02ca6b90: bl      #0x2b70db0                                 fn_2b70db0
02ca6b94: adrp    x0, #0x6266000                             
02ca6b98: ldr     x0, [x0, #0x3d8]                           S:'Purchase deferred: {0}'
02ca6b9c: bl      #0x2b70db0                                 fn_2b70db0
02ca6ba0: mov     w8, #1                                     
02ca6ba4: strb    w8, [x21, #0xadb]                          
02ca6ba8: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca6bac: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02ca6bb0: cbnz    w8, #0x2ca6bbc                             
02ca6bb4: bl      #0x2b70f30                                 fn_2b70f30
02ca6bb8: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca6bbc: ldr     x9, [x0, #0xb8]                            S:'banner_native_refresh_time'
02ca6bc0: adrp    x8, #0x6266000                             
02ca6bc4: ldr     x8, [x8, #0x3d8]                           S:'Purchase deferred: {0}'
02ca6bc8: ldr     x20, [x9]                                  
02ca6bcc: cbz     x19, #0x2ca6bd8                            
02ca6bd0: ldr     x1, [x19, #0x18]                           
02ca6bd4: b       #0x2ca6bdc                                 
02ca6bd8: mov     x1, xzr                                    
02ca6bdc: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca6be0: mov     x2, xzr                                    
02ca6be4: bl      #0x4c9d0ec                                 System.String::Format
02ca6be8: mov     x1, x0                                     
02ca6bec: mov     x0, x20                                    
02ca6bf0: ldp     x20, x19, [sp, #0x10]                      
02ca6bf4: ldp     x30, x21, [sp], #0x20                      
02ca6bf8: b       #0x2ca4738                                 WLog::Log
## OnProductsFetchFailed(UnityEngine.Purchasing.ProductFetchFailed failed) -> void
---- IAPManager::OnProductsFetchFailed 0x2ca6bfc
02ca6bfc: stp     x30, x21, [sp, #-0x20]!                    
02ca6c00: stp     x20, x19, [sp, #0x10]                      
02ca6c04: adrp    x21, #0x662f000                            
02ca6c08: adrp    x20, #0x6266000                            
02ca6c0c: mov     x19, x1                                    
02ca6c10: ldrb    w8, [x21, #0xadc]                          
02ca6c14: ldr     x20, [x20, #0x198]                         T:LogTags
02ca6c18: tbnz    w8, #0, #0x2ca6c3c                         
02ca6c1c: adrp    x0, #0x6266000                             
02ca6c20: ldr     x0, [x0, #0x198]                           T:LogTags
02ca6c24: bl      #0x2b70db0                                 fn_2b70db0
02ca6c28: adrp    x0, #0x6266000                             
02ca6c2c: ldr     x0, [x0, #0x3e0]                           S:'Products fetch failed: '
02ca6c30: bl      #0x2b70db0                                 fn_2b70db0
02ca6c34: mov     w8, #1                                     
02ca6c38: strb    w8, [x21, #0xadc]                          
02ca6c3c: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca6c40: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02ca6c44: cbnz    w8, #0x2ca6c4c                             
02ca6c48: bl      #0x2b70f30                                 fn_2b70f30
02ca6c4c: cbz     x19, #0x2ca6c88                            
02ca6c50: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca6c54: adrp    x9, #0x6266000                             
02ca6c58: mov     x2, xzr                                    
02ca6c5c: ldr     x9, [x9, #0x3e0]                           S:'Products fetch failed: '
02ca6c60: ldr     x1, [x19, #0x18]                           
02ca6c64: ldr     x8, [x8, #0xb8]                            
02ca6c68: ldr     x0, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca6c6c: ldr     x20, [x8]                                  
02ca6c70: bl      #0x4c9c514                                 System.String::Concat
02ca6c74: mov     x1, x0                                     
02ca6c78: mov     x0, x20                                    
02ca6c7c: ldp     x20, x19, [sp, #0x10]                      
02ca6c80: ldp     x30, x21, [sp], #0x20                      
02ca6c84: b       #0x2ca47ec                                 WLog::LogError
02ca6c88: bl      #0x2b7105c                                 fn_2b7105c
## OnPurchasesFetchFailed(UnityEngine.Purchasing.PurchasesFetchFailureDescription description) -> void
---- IAPManager::OnPurchasesFetchFailed 0x2ca6c8c
02ca6c8c: sub     sp, sp, #0x30                              
02ca6c90: stp     x30, x21, [sp, #0x10]                      
02ca6c94: stp     x20, x19, [sp, #0x20]                      
02ca6c98: adrp    x21, #0x662f000                            
02ca6c9c: adrp    x20, #0x6266000                            
02ca6ca0: mov     x19, x1                                    
02ca6ca4: ldrb    w8, [x21, #0xadd]                          
02ca6ca8: ldr     x20, [x20, #0x198]                         T:LogTags
02ca6cac: tbnz    w8, #0, #0x2ca6cdc                         
02ca6cb0: adrp    x0, #0x6266000                             
02ca6cb4: ldr     x0, [x0, #0x198]                           T:LogTags
02ca6cb8: bl      #0x2b70db0                                 fn_2b70db0
02ca6cbc: adrp    x0, #0x6266000                             
02ca6cc0: ldr     x0, [x0, #0x3e8]                           T:UnityEngine.Purchasing.PurchasesFetchFailureReason
02ca6cc4: bl      #0x2b70db0                                 fn_2b70db0
02ca6cc8: adrp    x0, #0x6266000                             
02ca6ccc: ldr     x0, [x0, #0x3f0]                           S:'Purchases fetch failed: {0}'
02ca6cd0: bl      #0x2b70db0                                 fn_2b70db0
02ca6cd4: mov     w8, #1                                     
02ca6cd8: strb    w8, [x21, #0xadd]                          
02ca6cdc: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca6ce0: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02ca6ce4: cbnz    w8, #0x2ca6cec                             
02ca6ce8: bl      #0x2b70f30                                 fn_2b70f30
02ca6cec: cbz     x19, #0x2ca6d50                            
02ca6cf0: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca6cf4: adrp    x9, #0x6266000                             
02ca6cf8: adrp    x20, #0x6266000                            
02ca6cfc: ldr     x9, [x9, #0x3e8]                           T:UnityEngine.Purchasing.PurchasesFetchFailureReason
02ca6d00: add     x1, sp, #0xc                               
02ca6d04: ldr     x8, [x8, #0xb8]                            
02ca6d08: ldr     x20, [x20, #0x3f0]                         S:'Purchases fetch failed: {0}'
02ca6d0c: ldr     w10, [x19, #0x10]                          
02ca6d10: ldr     x0, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca6d14: ldr     x19, [x8]                                  
02ca6d18: str     w10, [sp, #0xc]                            
02ca6d1c: bl      #0x2b70f38                                 fn_2b70f38
02ca6d20: ldr     x8, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca6d24: mov     x1, x0                                     
02ca6d28: mov     x2, xzr                                    
02ca6d2c: mov     x0, x8                                     
02ca6d30: bl      #0x4c9d0ec                                 System.String::Format
02ca6d34: mov     x1, x0                                     
02ca6d38: mov     x0, x19                                    
02ca6d3c: bl      #0x2ca47ec                                 WLog::LogError
02ca6d40: ldp     x20, x19, [sp, #0x20]                      
02ca6d44: ldp     x30, x21, [sp, #0x10]                      
02ca6d48: add     sp, sp, #0x30                              
02ca6d4c: ret                                                
02ca6d50: bl      #0x2b7105c                                 fn_2b7105c
## OnStoreDisconnected(UnityEngine.Purchasing.StoreConnectionFailureDescription description) -> void
---- IAPManager::OnStoreDisconnected 0x2ca6d54
02ca6d54: str     x30, [sp, #-0x30]!                         
02ca6d58: stp     x22, x21, [sp, #0x10]                      
02ca6d5c: stp     x20, x19, [sp, #0x20]                      
02ca6d60: adrp    x22, #0x662f000                            
02ca6d64: adrp    x21, #0x6266000                            
02ca6d68: mov     x20, x1                                    
02ca6d6c: ldrb    w8, [x22, #0xade]                          
02ca6d70: ldr     x21, [x21, #0x198]                         T:LogTags
02ca6d74: mov     x19, x0                                    
02ca6d78: tbnz    w8, #0, #0x2ca6d9c                         
02ca6d7c: adrp    x0, #0x6266000                             
02ca6d80: ldr     x0, [x0, #0x198]                           T:LogTags
02ca6d84: bl      #0x2b70db0                                 fn_2b70db0
02ca6d88: adrp    x0, #0x6266000                             
02ca6d8c: ldr     x0, [x0, #0x3f8]                           S:'Store disconnected: '
02ca6d90: bl      #0x2b70db0                                 fn_2b70db0
02ca6d94: mov     w8, #1                                     
02ca6d98: strb    w8, [x22, #0xade]                          
02ca6d9c: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca6da0: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02ca6da4: cbnz    w8, #0x2ca6dac                             
02ca6da8: bl      #0x2b70f30                                 fn_2b70f30
02ca6dac: cbz     x20, #0x2ca6df4                            
02ca6db0: ldr     x8, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca6db4: adrp    x9, #0x6266000                             
02ca6db8: mov     x2, xzr                                    
02ca6dbc: ldr     x9, [x9, #0x3f8]                           S:'Store disconnected: '
02ca6dc0: ldr     x1, [x20, #0x10]                           
02ca6dc4: ldr     x8, [x8, #0xb8]                            
02ca6dc8: ldr     x0, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca6dcc: ldr     x21, [x8]                                  
02ca6dd0: bl      #0x4c9c514                                 System.String::Concat
02ca6dd4: mov     x1, x0                                     
02ca6dd8: mov     x0, x21                                    
02ca6ddc: bl      #0x2ca47ec                                 WLog::LogError
02ca6de0: strb    wzr, [x19, #0x30]                          ._isInit
02ca6de4: ldp     x20, x19, [sp, #0x20]                      
02ca6de8: ldp     x22, x21, [sp, #0x10]                      
02ca6dec: ldr     x30, [sp], #0x30                           
02ca6df0: ret                                                
02ca6df4: bl      #0x2b7105c                                 fn_2b7105c
## BuyProduct(IAPKey key, System.Action onSuccess, System.Action onFail) -> void
---- IAPManager::BuyProduct 0x2ca6df8
02ca6df8: sub     sp, sp, #0x60                              
02ca6dfc: str     x30, [sp, #0x20]                           
02ca6e00: stp     x24, x23, [sp, #0x30]                      
02ca6e04: stp     x22, x21, [sp, #0x40]                      
02ca6e08: stp     x20, x19, [sp, #0x50]                      
02ca6e0c: adrp    x23, #0x662f000                            
02ca6e10: adrp    x24, #0x6266000                            
02ca6e14: mov     x19, x3                                    
02ca6e18: ldrb    w8, [x23, #0xadf]                          
02ca6e1c: ldr     x24, [x24, #0x200]                         T:IAPKey
02ca6e20: mov     x20, x2                                    
02ca6e24: mov     w22, w1                                    
02ca6e28: mov     x21, x0                                    
02ca6e2c: tbnz    w8, #0, #0x2ca6e74                         
02ca6e30: adrp    x0, #0x6266000                             
02ca6e34: ldr     x0, [x0, #0x380]                           MS:System.Collections.Generic.Dictionary`2::Remove
02ca6e38: bl      #0x2b70db0                                 fn_2b70db0
02ca6e3c: adrp    x0, #0x6266000                             
02ca6e40: ldr     x0, [x0, #0x400]                           MS:System.Collections.Generic.Dictionary`2::set_Item
02ca6e44: bl      #0x2b70db0                                 fn_2b70db0
02ca6e48: adrp    x0, #0x6266000                             
02ca6e4c: ldr     x0, [x0, #0x200]                           T:IAPKey
02ca6e50: bl      #0x2b70db0                                 fn_2b70db0
02ca6e54: adrp    x0, #0x6266000                             
02ca6e58: ldr     x0, [x0, #0x198]                           T:LogTags
02ca6e5c: bl      #0x2b70db0                                 fn_2b70db0
02ca6e60: adrp    x0, #0x6266000                             
02ca6e64: ldr     x0, [x0, #0x408]                           S:'BuyProduct called before IAP is ready.'
02ca6e68: bl      #0x2b70db0                                 fn_2b70db0
02ca6e6c: mov     w8, #1                                     
02ca6e70: strb    w8, [x23, #0xadf]                          
02ca6e74: ldr     x8, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca6e78: mov     x9, #-1                                    
02ca6e7c: add     x0, sp, #8                                 
02ca6e80: mov     x1, xzr                                    
02ca6e84: str     w22, [sp, #0x18]                           
02ca6e88: stp     x8, x9, [sp, #8]                           
02ca6e8c: bl      #0x4e47e48                                 System.Enum::ToString
02ca6e90: ldrb    w8, [x21, #0x30]                           ._isInit
02ca6e94: cbz     w8, #0x2ca6f0c                             
02ca6e98: ldr     x8, [x21, #0x38]                           ._storeController
02ca6e9c: cbz     x8, #0x2ca6f0c                             
02ca6ea0: mov     x22, x0                                    
02ca6ea4: ldr     x0, [x21, #0x58]                           ._pendingSuccessCallbacks
02ca6ea8: cbz     x0, #0x2ca6f6c                             
02ca6eac: adrp    x8, #0x6266000                             
02ca6eb0: mov     x1, x22                                    
02ca6eb4: ldr     x8, [x8, #0x380]                           MS:System.Collections.Generic.Dictionary`2::Remove
02ca6eb8: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca6ebc: bl      #0x452db38                                 fn_452db38
02ca6ec0: mov     x0, x21                                    
02ca6ec4: mov     x1, x19                                    
02ca6ec8: str     x19, [x0, #0x60]!                          ._pendingFailCallback
02ca6ecc: bl      #0x2b70d54                                 fn_2b70d54
02ca6ed0: cbz     x20, #0x2ca6ef4                            
02ca6ed4: ldr     x0, [x21, #0x58]                           ._pendingSuccessCallbacks
02ca6ed8: cbz     x0, #0x2ca6f6c                             
02ca6edc: adrp    x8, #0x6266000                             
02ca6ee0: mov     x1, x22                                    
02ca6ee4: mov     x2, x20                                    
02ca6ee8: ldr     x8, [x8, #0x400]                           MS:System.Collections.Generic.Dictionary`2::set_Item
02ca6eec: ldr     x3, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca6ef0: bl      #0x452c608                                 fn_452c608
02ca6ef4: ldr     x0, [x21, #0x38]                           ._storeController
02ca6ef8: cbz     x0, #0x2ca6f6c                             
02ca6efc: mov     x1, x22                                    
02ca6f00: mov     x2, xzr                                    
02ca6f04: bl      #0x571a670                                 UnityEngine.Purchasing.StoreController::PurchaseProduct
02ca6f08: b       #0x2ca6f54                                 
02ca6f0c: adrp    x21, #0x6266000                            
02ca6f10: adrp    x20, #0x6266000                            
02ca6f14: ldr     x21, [x21, #0x198]                         T:LogTags
02ca6f18: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca6f1c: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02ca6f20: ldr     x20, [x20, #0x408]                         S:'BuyProduct called before IAP is ready.'
02ca6f24: cbnz    w8, #0x2ca6f30                             
02ca6f28: bl      #0x2b70f30                                 fn_2b70f30
02ca6f2c: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca6f30: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time'
02ca6f34: ldr     x1, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca6f38: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca6f3c: bl      #0x2ca47ec                                 WLog::LogError
02ca6f40: cbz     x19, #0x2ca6f54                            
02ca6f44: ldr     x8, [x19, #0x18]                           
02ca6f48: ldr     x0, [x19, #0x40]                           ._purchasedProductIds
02ca6f4c: ldr     x1, [x19, #0x28]                           ._environment
02ca6f50: blr     x8                                         
02ca6f54: ldp     x20, x19, [sp, #0x50]                      
02ca6f58: ldr     x30, [sp, #0x20]                           
02ca6f5c: ldp     x22, x21, [sp, #0x40]                      
02ca6f60: ldp     x24, x23, [sp, #0x30]                      
02ca6f64: add     sp, sp, #0x60                              
02ca6f68: ret                                                
02ca6f6c: bl      #0x2b7105c                                 fn_2b7105c
## RestoreAllPurchases() -> void
---- IAPManager::RestoreAllPurchases 0x2ca6f70
02ca6f70: str     x30, [sp, #-0x30]!                         
02ca6f74: stp     x22, x21, [sp, #0x10]                      
02ca6f78: stp     x20, x19, [sp, #0x20]                      
02ca6f7c: adrp    x20, #0x662f000                            
02ca6f80: adrp    x22, #0x6266000                            
02ca6f84: adrp    x21, #0x6266000                            
02ca6f88: ldrb    w8, [x20, #0xae0]                          
02ca6f8c: ldr     x22, [x22, #0x410]                         T:type7126(k15)
02ca6f90: ldr     x21, [x21, #0x418]                         M:IAPManager::<RestoreAllPurchases>b__28_0
02ca6f94: mov     x19, x0                                    
02ca6f98: tbnz    w8, #0, #0x2ca6fbc                         
02ca6f9c: adrp    x0, #0x6266000                             
02ca6fa0: ldr     x0, [x0, #0x410]                           T:type7126(k15)
02ca6fa4: bl      #0x2b70db0                                 fn_2b70db0
02ca6fa8: adrp    x0, #0x6266000                             
02ca6fac: ldr     x0, [x0, #0x418]                           M:IAPManager::<RestoreAllPurchases>b__28_0
02ca6fb0: bl      #0x2b70db0                                 fn_2b70db0
02ca6fb4: mov     w8, #1                                     
02ca6fb8: strb    w8, [x20, #0xae0]                          
02ca6fbc: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca6fc0: ldr     x20, [x19, #0x38]                          ._storeController
02ca6fc4: bl      #0x2b7104c                                 fn_2b7104c
02ca6fc8: ldr     x2, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca6fcc: mov     x1, x19                                    
02ca6fd0: mov     x3, xzr                                    
02ca6fd4: mov     x21, x0                                    
02ca6fd8: bl      #0x453bda8                                 fn_453bda8
02ca6fdc: cbz     x20, #0x2ca6ffc                            
02ca6fe0: mov     x0, x20                                    
02ca6fe4: mov     x1, x21                                    
02ca6fe8: mov     x2, xzr                                    
02ca6fec: ldp     x20, x19, [sp, #0x20]                      
02ca6ff0: ldp     x22, x21, [sp, #0x10]                      
02ca6ff4: ldr     x30, [sp], #0x30                           
02ca6ff8: b       #0x571a520                                 UnityEngine.Purchasing.StoreController::RestoreTransactions
02ca6ffc: bl      #0x2b7105c                                 fn_2b7105c
## GetProductPrice(IAPKey key) -> string
---- IAPManager::GetProductPrice 0x2ca7000
02ca7000: sub     sp, sp, #0x70                              
02ca7004: str     x30, [sp, #0x40]                           
02ca7008: stp     x22, x21, [sp, #0x50]                      
02ca700c: stp     x20, x19, [sp, #0x60]                      
02ca7010: mrs     x21, tpidr_el0                             
02ca7014: adrp    x22, #0x662f000                            
02ca7018: mov     w19, w1                                    
02ca701c: ldr     x8, [x21, #0x28]                           ._environment
02ca7020: mov     x20, x0                                    
02ca7024: str     x8, [sp, #0x38]                            
02ca7028: ldrb    w8, [x22, #0xae1]                          
02ca702c: tbnz    w8, #0, #0x2ca7068                         
02ca7030: adrp    x0, #0x6263000                             
02ca7034: ldr     x0, [x0, #0xa60]                           T:System.Decimal
02ca7038: bl      #0x2b70db0                                 fn_2b70db0
02ca703c: adrp    x0, #0x6266000                             
02ca7040: ldr     x0, [x0, #0x200]                           T:IAPKey
02ca7044: bl      #0x2b70db0                                 fn_2b70db0
02ca7048: adrp    x0, #0x6266000                             
02ca704c: ldr     x0, [x0, #0x420]                           S:'---'
02ca7050: bl      #0x2b70db0                                 fn_2b70db0
02ca7054: adrp    x0, #0x6265000                             
02ca7058: ldr     x0, [x0, #0x260]                           S:' '
02ca705c: bl      #0x2b70db0                                 fn_2b70db0
02ca7060: mov     w8, #1                                     
02ca7064: strb    w8, [x22, #0xae1]                          
02ca7068: ldr     x20, [x20, #0x38]                          ._storeController
02ca706c: stp     xzr, xzr, [sp, #0x20]                      
02ca7070: cbz     x20, #0x2ca7120                            
02ca7074: adrp    x8, #0x6266000                             
02ca7078: mov     x9, #-1                                    
02ca707c: add     x0, sp, #8                                 
02ca7080: ldr     x8, [x8, #0x200]                           T:IAPKey
02ca7084: mov     x1, xzr                                    
02ca7088: str     w19, [sp, #0x18]                           
02ca708c: ldr     x8, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca7090: stp     x8, x9, [sp, #8]                           
02ca7094: bl      #0x4e47e48                                 System.Enum::ToString
02ca7098: mov     x1, x0                                     
02ca709c: mov     x0, x20                                    
02ca70a0: mov     x2, xzr                                    
02ca70a4: bl      #0x571a120                                 UnityEngine.Purchasing.StoreController::GetProductById
02ca70a8: cbz     x0, #0x2ca7120                             
02ca70ac: mov     x1, xzr                                    
02ca70b0: mov     x19, x0                                    
02ca70b4: bl      #0x57edb38                                 UnityEngine.Purchasing.Product::get_metadata
02ca70b8: cbz     x0, #0x2ca7150                             
02ca70bc: adrp    x9, #0x6263000                             
02ca70c0: mov     x8, x0                                     
02ca70c4: ldr     x9, [x9, #0xa60]                           T:System.Decimal
02ca70c8: ldr     q0, [x8, #0x30]                            S:'popup_rate_on_off'
02ca70cc: ldr     x0, [x9]                                   &2c5bbd4(=a9bd7bfdd503233f)
02ca70d0: str     q0, [sp, #0x20]                            
02ca70d4: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02ca70d8: cbnz    w8, #0x2ca70e0                             
02ca70dc: bl      #0x2b70f30                                 fn_2b70f30
02ca70e0: add     x0, sp, #0x20                              
02ca70e4: mov     x1, xzr                                    
02ca70e8: bl      #0x4e6dcac                                 System.Decimal::ToString
02ca70ec: mov     x20, x0                                    
02ca70f0: mov     x0, x19                                    
02ca70f4: mov     x1, xzr                                    
02ca70f8: bl      #0x57edb38                                 UnityEngine.Purchasing.Product::get_metadata
02ca70fc: cbz     x0, #0x2ca7150                             
02ca7100: adrp    x8, #0x6265000                             
02ca7104: mov     x3, xzr                                    
02ca7108: ldr     x8, [x8, #0x260]                           S:' '
02ca710c: ldr     x2, [x0, #0x28]                            T:AdsManager/<ISetAOAInterval>d__33 ._environment
02ca7110: mov     x0, x20                                    
02ca7114: ldr     x1, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02ca7118: bl      #0x4ca6dbc                                 System.String::Concat
02ca711c: b       #0x2ca712c                                 
02ca7120: adrp    x8, #0x6266000                             
02ca7124: ldr     x8, [x8, #0x420]                           S:'---'
02ca7128: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca712c: ldr     x8, [x21, #0x28]                           ._environment
02ca7130: ldr     x9, [sp, #0x38]                            
02ca7134: cmp     x8, x9                                     
02ca7138: b.ne    #0x2ca7164                                 
02ca713c: ldp     x20, x19, [sp, #0x60]                      
02ca7140: ldr     x30, [sp, #0x40]                           
02ca7144: ldp     x22, x21, [sp, #0x50]                      
02ca7148: add     sp, sp, #0x70                              
02ca714c: ret                                                
02ca7150: ldr     x8, [x21, #0x28]                           ._environment
02ca7154: ldr     x9, [sp, #0x38]                            
02ca7158: cmp     x8, x9                                     
02ca715c: b.ne    #0x2ca7164                                 
02ca7160: bl      #0x2b7105c                                 fn_2b7105c
02ca7164: bl      #0x5e902d0                                 fn_5e902d0
## IsPurchased(IAPKey key, System.Action`1<bool> callback) -> void
---- IAPManager::IsPurchased 0x2ca7168
02ca7168: cbz     x2, #0x2ca7194                             
02ca716c: stp     x30, x19, [sp, #-0x10]!                    
02ca7170: mov     x19, x2                                    
02ca7174: bl      #0x2ca7198                                 IAPManager::IsPurchased
02ca7178: ldr     x8, [x19, #0x40]                           ._purchasedProductIds
02ca717c: ldr     x2, [x19, #0x28]                           ._environment
02ca7180: and     w1, w0, #1                                 
02ca7184: ldr     x3, [x19, #0x18]                           
02ca7188: mov     x0, x8                                     
02ca718c: ldp     x30, x19, [sp], #0x10                      
02ca7190: br      x3                                         
02ca7194: ret                                                
## IsPurchased(IAPKey key) -> bool
---- IAPManager::IsPurchased 0x2ca7198
02ca7198: sub     sp, sp, #0x40                              
02ca719c: stp     x30, x21, [sp, #0x20]                      
02ca71a0: stp     x20, x19, [sp, #0x30]                      
02ca71a4: adrp    x21, #0x662f000                            
02ca71a8: mov     w19, w1                                    
02ca71ac: mov     x20, x0                                    
02ca71b0: ldrb    w8, [x21, #0xae2]                          
02ca71b4: tbnz    w8, #0, #0x2ca71d8                         
02ca71b8: adrp    x0, #0x6266000                             
02ca71bc: ldr     x0, [x0, #0x428]                           MS:System.Collections.Generic.HashSet`1::Contains
02ca71c0: bl      #0x2b70db0                                 fn_2b70db0
02ca71c4: adrp    x0, #0x6266000                             
02ca71c8: ldr     x0, [x0, #0x200]                           T:IAPKey
02ca71cc: bl      #0x2b70db0                                 fn_2b70db0
02ca71d0: mov     w8, #1                                     
02ca71d4: strb    w8, [x21, #0xae2]                          
02ca71d8: ldrb    w8, [x20, #0x30]                           ._isInit
02ca71dc: cbz     w8, #0x2ca7230                             
02ca71e0: ldr     x8, [x20, #0x38]                           ._storeController
02ca71e4: cbz     x8, #0x2ca7230                             
02ca71e8: adrp    x8, #0x6266000                             
02ca71ec: mov     x9, #-1                                    
02ca71f0: add     x0, sp, #8                                 
02ca71f4: ldr     x8, [x8, #0x200]                           T:IAPKey
02ca71f8: ldr     x20, [x20, #0x40]                          ._purchasedProductIds
02ca71fc: mov     x1, xzr                                    
02ca7200: str     w19, [sp, #0x18]                           
02ca7204: ldr     x8, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca7208: stp     x8, x9, [sp, #8]                           
02ca720c: bl      #0x4e47e48                                 System.Enum::ToString
02ca7210: cbz     x20, #0x2ca7248                            
02ca7214: adrp    x8, #0x6266000                             
02ca7218: mov     x1, x0                                     
02ca721c: mov     x0, x20                                    
02ca7220: ldr     x8, [x8, #0x428]                           MS:System.Collections.Generic.HashSet`1::Contains
02ca7224: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca7228: bl      #0x4986fec                                 fn_4986fec
02ca722c: b       #0x2ca7234                                 
02ca7230: mov     w0, wzr                                    
02ca7234: ldp     x20, x19, [sp, #0x30]                      
02ca7238: and     w0, w0, #1                                 
02ca723c: ldp     x30, x21, [sp, #0x20]                      
02ca7240: add     sp, sp, #0x40                              
02ca7244: ret                                                
02ca7248: bl      #0x2b7105c                                 fn_2b7105c
## FireSuccessCallback(string productId) -> void
---- IAPManager::FireSuccessCallback 0x2ca6520
02ca6520: sub     sp, sp, #0x40                              
02ca6524: stp     x30, x21, [sp, #0x20]                      
02ca6528: stp     x20, x19, [sp, #0x30]                      
02ca652c: adrp    x21, #0x662f000                            
02ca6530: mov     x19, x1                                    
02ca6534: mov     x20, x0                                    
02ca6538: ldrb    w8, [x21, #0xae3]                          
02ca653c: tbnz    w8, #0, #0x2ca6584                         
02ca6540: adrp    x0, #0x6266000                             
02ca6544: ldr     x0, [x0, #0x380]                           MS:System.Collections.Generic.Dictionary`2::Remove
02ca6548: bl      #0x2b70db0                                 fn_2b70db0
02ca654c: adrp    x0, #0x6266000                             
02ca6550: ldr     x0, [x0, #0x388]                           MS:System.Collections.Generic.Dictionary`2::TryGetValue
02ca6554: bl      #0x2b70db0                                 fn_2b70db0
02ca6558: adrp    x0, #0x6266000                             
02ca655c: ldr     x0, [x0, #0x198]                           T:LogTags
02ca6560: bl      #0x2b70db0                                 fn_2b70db0
02ca6564: adrp    x0, #0x6266000                             
02ca6568: ldr     x0, [x0, #0x340]                           S:"'."
02ca656c: bl      #0x2b70db0                                 fn_2b70db0
02ca6570: adrp    x0, #0x6266000                             
02ca6574: ldr     x0, [x0, #0x390]                           S:"No pending success callback for '"
02ca6578: bl      #0x2b70db0                                 fn_2b70db0
02ca657c: mov     w8, #1                                     
02ca6580: strb    w8, [x21, #0xae3]                          
02ca6584: ldr     x0, [x20, #0x58]                           ._pendingSuccessCallbacks
02ca6588: str     xzr, [sp, #0x18]                           
02ca658c: str     wzr, [sp, #0x10]                           
02ca6590: cbz     x0, #0x2ca665c                             
02ca6594: adrp    x8, #0x6266000                             
02ca6598: add     x2, sp, #0x18                              
02ca659c: mov     x1, x19                                    
02ca65a0: ldr     x8, [x8, #0x388]                           MS:System.Collections.Generic.Dictionary`2::TryGetValue
02ca65a4: ldr     x3, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca65a8: bl      #0x452e184                                 fn_452e184
02ca65ac: tbz     w0, #0, #0x2ca65f8                         
02ca65b0: ldr     x0, [x20, #0x58]                           ._pendingSuccessCallbacks
02ca65b4: cbz     x0, #0x2ca665c                             
02ca65b8: adrp    x8, #0x6266000                             
02ca65bc: mov     x1, x19                                    
02ca65c0: ldr     x8, [x8, #0x380]                           MS:System.Collections.Generic.Dictionary`2::Remove
02ca65c4: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca65c8: bl      #0x452db38                                 fn_452db38
02ca65cc: str     xzr, [x20, #0x60]!                         ._pendingFailCallback
02ca65d0: mov     x0, x20                                    
02ca65d4: mov     x1, xzr                                    
02ca65d8: bl      #0x2b70d54                                 fn_2b70d54
02ca65dc: ldr     x8, [sp, #0x18]                            
02ca65e0: cbz     x8, #0x2ca664c                             
02ca65e4: ldr     x0, [x8, #0x40]                            S:'native_collap_ad_on_off'
02ca65e8: ldr     x1, [x8, #0x28]                            S:'banner_ad_on_off'
02ca65ec: ldr     x9, [x8, #0x18]                            S:'level_show_popuprate'
02ca65f0: blr     x9                                         
02ca65f4: b       #0x2ca664c                                 
02ca65f8: adrp    x20, #0x6266000                            
02ca65fc: ldr     x20, [x20, #0x198]                         T:LogTags
02ca6600: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca6604: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02ca6608: cbnz    w8, #0x2ca6614                             
02ca660c: bl      #0x2b70f30                                 fn_2b70f30
02ca6610: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca6614: adrp    x8, #0x6266000                             
02ca6618: adrp    x10, #0x6266000                            
02ca661c: mov     x1, x19                                    
02ca6620: ldr     x8, [x8, #0x390]                           S:"No pending success callback for '"
02ca6624: ldr     x9, [x0, #0xb8]                            S:'banner_native_refresh_time'
02ca6628: ldr     x10, [x10, #0x340]                         S:"'."
02ca662c: mov     x3, xzr                                    
02ca6630: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca6634: ldr     x2, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca6638: ldr     x20, [x9]                                  
02ca663c: bl      #0x4ca6dbc                                 System.String::Concat
02ca6640: mov     x1, x0                                     
02ca6644: mov     x0, x20                                    
02ca6648: bl      #0x2ca4738                                 WLog::Log
02ca664c: ldp     x20, x19, [sp, #0x30]                      
02ca6650: ldp     x30, x21, [sp, #0x20]                      
02ca6654: add     sp, sp, #0x40                              
02ca6658: ret                                                
02ca665c: bl      #0x2b7105c                                 fn_2b7105c
02ca6660: cmp     w1, #1                                     
02ca6664: mov     x19, x0                                    
02ca6668: b.ne    #0x2ca6730                                 
02ca666c: mov     x0, x19                                    
02ca6670: bl      #0x5e90260                                 fn_5e90260
02ca6674: mov     x19, x0                                    
02ca6678: adrp    x0, #0x6263000                             
02ca667c: ldr     x0, [x0, #0xae0]                           T:System.Exception
02ca6680: bl      #0x2b70dc4                                 fn_2b70dc4
02ca6684: ldr     x8, [x19]                                  
02ca6688: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca668c: bl      #0x2b71464                                 fn_2b71464
02ca6690: tbz     w0, #0, #0x2ca6708                         
02ca6694: ldrsw   x21, [sp, #0x10]                           
02ca6698: ldr     x19, [x19]                                 
02ca669c: add     x8, sp, #8                                 
02ca66a0: str     x19, [x8, x21, lsl #3]                     
02ca66a4: add     w8, w21, #1                                
02ca66a8: str     w8, [sp, #0x10]                            
02ca66ac: bl      #0x5e90270                                 fn_5e90270
02ca66b0: adrp    x0, #0x6266000                             
02ca66b4: ldr     x0, [x0, #0x198]                           T:LogTags
02ca66b8: bl      #0x2b70dc4                                 fn_2b70dc4
02ca66bc: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02ca66c0: cbnz    w8, #0x2ca66c8                             
02ca66c4: bl      #0x2b70f30                                 fn_2b70f30
02ca66c8: adrp    x0, #0x6266000                             
02ca66cc: ldr     x0, [x0, #0x198]                           T:LogTags
02ca66d0: bl      #0x2b70dc4                                 fn_2b70dc4
02ca66d4: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time'
02ca66d8: adrp    x0, #0x6266000                             
02ca66dc: ldr     x20, [x8]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca66e0: ldr     x0, [x0, #0x398]                           S:'Success callback error: {0}'
02ca66e4: bl      #0x2b70dc4                                 fn_2b70dc4
02ca66e8: mov     x1, x19                                    
02ca66ec: mov     x2, xzr                                    
02ca66f0: bl      #0x4c9d0ec                                 System.String::Format
02ca66f4: mov     x1, x0                                     
02ca66f8: mov     x0, x20                                    
02ca66fc: bl      #0x2ca47ec                                 WLog::LogError
02ca6700: str     w21, [sp, #0x10]                           
02ca6704: b       #0x2ca664c                                 
02ca6708: mov     w0, #8                                     
02ca670c: bl      #0x5e90290                                 fn_5e90290
02ca6710: ldr     x8, [x19]                                  
02ca6714: str     x8, [x0]                                   
02ca6718: adrp    x1, #0x5e96000                             
02ca671c: add     x1, x1, #0x758                             &5e96758
02ca6720: mov     x2, xzr                                    
02ca6724: bl      #0x5e902a0                                 fn_5e902a0
02ca6728: mov     x19, x0                                    
02ca672c: bl      #0x5e90270                                 fn_5e90270
02ca6730: mov     x0, x19                                    
02ca6734: bl      #0x2c6051c                                 fn_2c6051c
02ca6738: bl      #0x27369b8                                 fn_27369b8
## FireFailCallback() -> void
---- IAPManager::FireFailCallback 0x2ca6a68
02ca6a68: str     x30, [sp, #-0x20]!                         
02ca6a6c: stp     x20, x19, [sp, #0x10]                      
02ca6a70: mov     x1, xzr                                    
02ca6a74: ldr     x19, [x0, #0x60]!                          ._pendingFailCallback
02ca6a78: str     xzr, [x0]                                  
02ca6a7c: bl      #0x2b70d54                                 fn_2b70d54
02ca6a80: cbz     x19, #0x2ca6a94                            
02ca6a84: ldr     x0, [x19, #0x40]                           ._purchasedProductIds
02ca6a88: ldr     x1, [x19, #0x28]                           ._environment
02ca6a8c: ldr     x8, [x19, #0x18]                           
02ca6a90: blr     x8                                         
02ca6a94: ldp     x20, x19, [sp, #0x10]                      
02ca6a98: ldr     x30, [sp], #0x20                           
02ca6a9c: ret                                                
02ca6aa0: cmp     w1, #1                                     
02ca6aa4: mov     x19, x0                                    
02ca6aa8: b.ne    #0x2ca6b5c                                 
02ca6aac: mov     x0, x19                                    
02ca6ab0: bl      #0x5e90260                                 fn_5e90260
02ca6ab4: mov     x19, x0                                    
02ca6ab8: adrp    x0, #0x6263000                             
02ca6abc: ldr     x0, [x0, #0xae0]                           T:System.Exception
02ca6ac0: bl      #0x2b70dc4                                 fn_2b70dc4
02ca6ac4: ldr     x8, [x19]                                  
02ca6ac8: ldr     x1, [x8]                                   
02ca6acc: bl      #0x2b71464                                 fn_2b71464
02ca6ad0: tbz     w0, #0, #0x2ca6b34                         
02ca6ad4: ldr     x19, [x19]                                 
02ca6ad8: bl      #0x5e90270                                 fn_5e90270
02ca6adc: adrp    x0, #0x6266000                             
02ca6ae0: ldr     x0, [x0, #0x198]                           T:LogTags
02ca6ae4: bl      #0x2b70dc4                                 fn_2b70dc4
02ca6ae8: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02ca6aec: cbnz    w8, #0x2ca6af4                             
02ca6af0: bl      #0x2b70f30                                 fn_2b70f30
02ca6af4: adrp    x0, #0x6266000                             
02ca6af8: ldr     x0, [x0, #0x198]                           T:LogTags
02ca6afc: bl      #0x2b70dc4                                 fn_2b70dc4
02ca6b00: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time'
02ca6b04: adrp    x0, #0x6266000                             
02ca6b08: ldr     x20, [x8]                                  
02ca6b0c: ldr     x0, [x0, #0x3d0]                           S:'Fail callback error: {0}'
02ca6b10: bl      #0x2b70dc4                                 fn_2b70dc4
02ca6b14: mov     x1, x19                                    
02ca6b18: mov     x2, xzr                                    
02ca6b1c: bl      #0x4c9d0ec                                 System.String::Format
02ca6b20: mov     x1, x0                                     
02ca6b24: mov     x0, x20                                    
02ca6b28: ldp     x20, x19, [sp, #0x10]                      
02ca6b2c: ldr     x30, [sp], #0x20                           
02ca6b30: b       #0x2ca47ec                                 WLog::LogError
02ca6b34: mov     w0, #8                                     
02ca6b38: bl      #0x5e90290                                 fn_5e90290
02ca6b3c: ldr     x8, [x19]                                  
02ca6b40: str     x8, [x0]                                   
02ca6b44: adrp    x1, #0x5e96000                             
02ca6b48: add     x1, x1, #0x758                             &5e96758
02ca6b4c: mov     x2, xzr                                    
02ca6b50: bl      #0x5e902a0                                 fn_5e902a0
02ca6b54: mov     x19, x0                                    
02ca6b58: bl      #0x5e90270                                 fn_5e90270
02ca6b5c: mov     x0, x19                                    
02ca6b60: bl      #0x2c6051c                                 fn_2c6051c
02ca6b64: bl      #0x27369b8                                 fn_27369b8
## ParseQuantity(UnityEngine.Purchasing.Order order) -> int
---- IAPManager::ParseQuantity 0x2ca6290
02ca6290: str     x30, [sp, #-0x20]!                         
02ca6294: stp     x20, x19, [sp, #0x10]                      
02ca6298: adrp    x20, #0x662f000                            
02ca629c: mov     x19, x0                                    
02ca62a0: ldrb    w8, [x20, #0xae4]                          
02ca62a4: tbnz    w8, #0, #0x2ca62ec                         
02ca62a8: adrp    x0, #0x6266000                             
02ca62ac: ldr     x0, [x0, #0x318]                           T:UnityEngine.Purchasing.IOrderInfo
02ca62b0: bl      #0x2b70db0                                 fn_2b70db0
02ca62b4: adrp    x0, #0x6266000                             
02ca62b8: ldr     x0, [x0, #0x358]                           MS:UnityEngine.JsonUtility::FromJson
02ca62bc: bl      #0x2b70db0                                 fn_2b70db0
02ca62c0: adrp    x0, #0x6266000                             
02ca62c4: ldr     x0, [x0, #0x360]                           MS:UnityEngine.JsonUtility::FromJson
02ca62c8: bl      #0x2b70db0                                 fn_2b70db0
02ca62cc: adrp    x0, #0x6266000                             
02ca62d0: ldr     x0, [x0, #0x368]                           MS:UnityEngine.JsonUtility::FromJson
02ca62d4: bl      #0x2b70db0                                 fn_2b70db0
02ca62d8: adrp    x0, #0x6266000                             
02ca62dc: ldr     x0, [x0, #0x370]                           S:'fake'
02ca62e0: bl      #0x2b70db0                                 fn_2b70db0
02ca62e4: mov     w8, #1                                     
02ca62e8: strb    w8, [x20, #0xae4]                          
02ca62ec: cbz     x19, #0x2ca6408                            
02ca62f0: ldr     x19, [x19, #0x18]                          
02ca62f4: cbz     x19, #0x2ca640c                            
02ca62f8: adrp    x10, #0x6266000                            
02ca62fc: ldr     x8, [x19]                                  
02ca6300: ldr     x10, [x10, #0x318]                         T:UnityEngine.Purchasing.IOrderInfo
02ca6304: ldrh    w9, [x8, #0x12e]                           
02ca6308: ldr     x1, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca630c: cbz     x9, #0x2ca6330                             
02ca6310: ldr     x10, [x8, #0xb0]                           
02ca6314: add     x10, x10, #8                               &6266008
02ca6318: ldur    x11, [x10, #-8]                            
02ca631c: cmp     x11, x1                                    
02ca6320: b.eq    #0x2ca6340                                 
02ca6324: subs    x9, x9, #1                                 
02ca6328: add     x10, x10, #0x10                            &6266010
02ca632c: b.ne    #0x2ca6318                                 
02ca6330: mov     x0, x19                                    
02ca6334: mov     w2, #5                                     
02ca6338: bl      #0x2baa05c                                 fn_2baa05c
02ca633c: b       #0x2ca6350                                 
02ca6340: ldr     w9, [x10]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca6344: add     w9, w9, #5                                 
02ca6348: add     x8, x8, w9, sxtw #4                        
02ca634c: add     x0, x8, #0x138                             
02ca6350: ldp     x8, x1, [x0]                               
02ca6354: mov     x0, x19                                    
02ca6358: blr     x8                                         
02ca635c: mov     x1, xzr                                    
02ca6360: mov     x19, x0                                    
02ca6364: bl      #0x4ca6234                                 System.String::IsNullOrEmpty
02ca6368: tbnz    w0, #0, #0x2ca64d8                         
02ca636c: adrp    x8, #0x6266000                             
02ca6370: ldr     x8, [x8, #0x358]                           MS:UnityEngine.JsonUtility::FromJson
02ca6374: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca6378: mov     x0, x19                                    
02ca637c: bl      #0x3224ff4                                 fn_3224ff4
02ca6380: mov     x19, x0                                    
02ca6384: cbz     x0, #0x2ca64d8                             
02ca6388: adrp    x8, #0x6266000                             
02ca638c: ldr     x8, [x8, #0x370]                           S:'fake'
02ca6390: ldr     x0, [x19, #0x18]                           
02ca6394: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca6398: mov     x2, xzr                                    
02ca639c: bl      #0x4ca52b8                                 System.String::op_Equality
02ca63a0: tbnz    w0, #0, #0x2ca64d8                         
02ca63a4: ldr     x0, [x19, #0x10]                           
02ca63a8: mov     x1, xzr                                    
02ca63ac: bl      #0x4ca6234                                 System.String::IsNullOrEmpty
02ca63b0: tbnz    w0, #0, #0x2ca64d8                         
02ca63b4: adrp    x8, #0x6266000                             
02ca63b8: ldr     x8, [x8, #0x368]                           MS:UnityEngine.JsonUtility::FromJson
02ca63bc: ldr     x0, [x19, #0x10]                           
02ca63c0: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca63c4: bl      #0x3224ff4                                 fn_3224ff4
02ca63c8: mov     x19, x0                                    
02ca63cc: cbz     x0, #0x2ca64d8                             
02ca63d0: ldr     x0, [x19, #0x10]                           
02ca63d4: mov     x1, xzr                                    
02ca63d8: bl      #0x4ca6234                                 System.String::IsNullOrEmpty
02ca63dc: tbnz    w0, #0, #0x2ca64d8                         
02ca63e0: adrp    x8, #0x6266000                             
02ca63e4: ldr     x8, [x8, #0x360]                           MS:UnityEngine.JsonUtility::FromJson
02ca63e8: ldr     x0, [x19, #0x10]                           
02ca63ec: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca63f0: bl      #0x3224ff4                                 fn_3224ff4
02ca63f4: cbz     x0, #0x2ca64d8                             
02ca63f8: ldr     w8, [x0, #0x40]                            S:'native_collap_ad_on_off' ._purchasedProductIds
02ca63fc: cmp     w8, #1                                     
02ca6400: csinc   w0, w8, wzr, gt                            
02ca6404: b       #0x2ca64dc                                 
02ca6408: bl      #0x2b7105c                                 fn_2b7105c
02ca640c: bl      #0x2b7105c                                 fn_2b7105c
02ca6410: b       #0x2ca6434                                 
02ca6414: b       #0x2ca6434                                 
02ca6418: b       #0x2ca6434                                 
02ca641c: b       #0x2ca6434                                 
02ca6420: b       #0x2ca6434                                 
02ca6424: b       #0x2ca6434                                 
02ca6428: b       #0x2ca6434                                 
02ca642c: b       #0x2ca6434                                 
02ca6430: b       #0x2ca6434                                 
02ca6434: mov     x19, x0                                    
02ca6438: cmp     w1, #1                                     
02ca643c: b.ne    #0x2ca6514                                 
02ca6440: mov     x0, x19                                    
02ca6444: bl      #0x5e90260                                 fn_5e90260
02ca6448: mov     x19, x0                                    
02ca644c: adrp    x0, #0x6263000                             
02ca6450: ldr     x0, [x0, #0xae0]                           T:System.Exception
02ca6454: bl      #0x2b70dc4                                 fn_2b70dc4
02ca6458: ldr     x8, [x19]                                  
02ca645c: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca6460: bl      #0x2b71464                                 fn_2b71464
02ca6464: tbz     w0, #0, #0x2ca64e8                         
02ca6468: ldr     x19, [x19]                                 
02ca646c: bl      #0x5e90270                                 fn_5e90270
02ca6470: adrp    x0, #0x6266000                             
02ca6474: ldr     x0, [x0, #0x198]                           T:LogTags
02ca6478: bl      #0x2b70dc4                                 fn_2b70dc4
02ca647c: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02ca6480: cbnz    w8, #0x2ca6488                             
02ca6484: bl      #0x2b70f30                                 fn_2b70f30
02ca6488: adrp    x0, #0x6266000                             
02ca648c: ldr     x0, [x0, #0x198]                           T:LogTags
02ca6490: bl      #0x2b70dc4                                 fn_2b70dc4
02ca6494: cbz     x19, #0x2ca6508                            
02ca6498: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time'
02ca649c: ldr     x9, [x19]                                  
02ca64a0: mov     x0, x19                                    
02ca64a4: ldr     x20, [x8]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca64a8: ldp     x8, x1, [x9, #0x188]                       
02ca64ac: blr     x8                                         
02ca64b0: mov     x19, x0                                    
02ca64b4: adrp    x0, #0x6266000                             
02ca64b8: ldr     x0, [x0, #0x378]                           S:'ParseQuantity failed, default to 1: '
02ca64bc: bl      #0x2b70dc4                                 fn_2b70dc4
02ca64c0: mov     x1, x19                                    
02ca64c4: mov     x2, xzr                                    
02ca64c8: bl      #0x4c9c514                                 System.String::Concat
02ca64cc: mov     x1, x0                                     
02ca64d0: mov     x0, x20                                    
02ca64d4: bl      #0x2ca47ec                                 WLog::LogError
02ca64d8: mov     w0, #1                                     
02ca64dc: ldp     x20, x19, [sp, #0x10]                      
02ca64e0: ldr     x30, [sp], #0x20                           
02ca64e4: ret                                                
02ca64e8: mov     w0, #8                                     
02ca64ec: bl      #0x5e90290                                 fn_5e90290
02ca64f0: ldr     x8, [x19]                                  
02ca64f4: str     x8, [x0]                                   
02ca64f8: adrp    x1, #0x5e96000                             
02ca64fc: add     x1, x1, #0x758                             &5e96758
02ca6500: mov     x2, xzr                                    
02ca6504: bl      #0x5e902a0                                 fn_5e902a0
02ca6508: bl      #0x2b7105c                                 fn_2b7105c
02ca650c: mov     x19, x0                                    
02ca6510: bl      #0x5e90270                                 fn_5e90270
02ca6514: mov     x0, x19                                    
02ca6518: bl      #0x2c6051c                                 fn_2c6051c
02ca651c: bl      #0x27369b8                                 fn_27369b8
## .ctor() -> void
---- IAPManager::.ctor 0x2ca724c
02ca724c: str     x30, [sp, #-0x50]!                         
02ca7250: stp     x26, x25, [sp, #0x10]                      
02ca7254: stp     x24, x23, [sp, #0x20]                      
02ca7258: stp     x22, x21, [sp, #0x30]                      
02ca725c: stp     x20, x19, [sp, #0x40]                      
02ca7260: adrp    x25, #0x6266000                            
02ca7264: adrp    x24, #0x6266000                            
02ca7268: adrp    x20, #0x6266000                            
02ca726c: adrp    x26, #0x662f000                            
02ca7270: adrp    x23, #0x6266000                            
02ca7274: adrp    x22, #0x6266000                            
02ca7278: adrp    x21, #0x6266000                            
02ca727c: ldr     x25, [x25, #0x430]                         S:'production'
02ca7280: ldr     x24, [x24, #0x438]                         T:type10840(k15)
02ca7284: ldr     x20, [x20, #0x440]                         MS:System.Collections.Generic.HashSet`1::.ctor
02ca7288: ldr     x23, [x23, #0x448]                         T:type54453(k15)
02ca728c: ldrb    w8, [x26, #0xae5]                          
02ca7290: ldr     x22, [x22, #0x450]                         MS:System.Collections.Generic.Dictionary`2::.ctor
02ca7294: ldr     x21, [x21, #0x458]                         MS:WejoyService.Singleton`1::.ctor
02ca7298: mov     x19, x0                                    
02ca729c: tbnz    w8, #0, #0x2ca72f0                         
02ca72a0: adrp    x0, #0x6266000                             
02ca72a4: ldr     x0, [x0, #0x450]                           MS:System.Collections.Generic.Dictionary`2::.ctor
02ca72a8: bl      #0x2b70db0                                 fn_2b70db0
02ca72ac: adrp    x0, #0x6266000                             
02ca72b0: ldr     x0, [x0, #0x448]                           T:type54453(k15)
02ca72b4: bl      #0x2b70db0                                 fn_2b70db0
02ca72b8: adrp    x0, #0x6266000                             
02ca72bc: ldr     x0, [x0, #0x440]                           MS:System.Collections.Generic.HashSet`1::.ctor
02ca72c0: bl      #0x2b70db0                                 fn_2b70db0
02ca72c4: adrp    x0, #0x6266000                             
02ca72c8: ldr     x0, [x0, #0x438]                           T:type10840(k15)
02ca72cc: bl      #0x2b70db0                                 fn_2b70db0
02ca72d0: adrp    x0, #0x6266000                             
02ca72d4: ldr     x0, [x0, #0x458]                           MS:WejoyService.Singleton`1::.ctor
02ca72d8: bl      #0x2b70db0                                 fn_2b70db0
02ca72dc: adrp    x0, #0x6266000                             
02ca72e0: ldr     x0, [x0, #0x430]                           S:'production'
02ca72e4: bl      #0x2b70db0                                 fn_2b70db0
02ca72e8: mov     w8, #1                                     
02ca72ec: strb    w8, [x26, #0xae5]                          
02ca72f0: ldr     x1, [x25]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca72f4: mov     x0, x19                                    
02ca72f8: str     x1, [x0, #0x28]!                           ._environment
02ca72fc: bl      #0x2b70d54                                 fn_2b70d54
02ca7300: ldr     x0, [x24]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca7304: bl      #0x2b7104c                                 fn_2b7104c
02ca7308: ldr     x1, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca730c: mov     x20, x0                                    
02ca7310: bl      #0x49868e0                                 fn_49868e0
02ca7314: mov     x0, x19                                    
02ca7318: mov     x1, x20                                    
02ca731c: str     x20, [x0, #0x40]!                          ._purchasedProductIds
02ca7320: bl      #0x2b70d54                                 fn_2b70d54
02ca7324: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca7328: bl      #0x2b7104c                                 fn_2b7104c
02ca732c: ldr     x1, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca7330: mov     x20, x0                                    
02ca7334: bl      #0x452b8a0                                 fn_452b8a0
02ca7338: mov     x0, x19                                    
02ca733c: mov     x1, x20                                    
02ca7340: str     x20, [x0, #0x58]!                          ._pendingSuccessCallbacks
02ca7344: bl      #0x2b70d54                                 fn_2b70d54
02ca7348: ldr     x1, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca734c: mov     x0, x19                                    
02ca7350: ldp     x20, x19, [sp, #0x40]                      
02ca7354: ldp     x22, x21, [sp, #0x30]                      
02ca7358: ldp     x24, x23, [sp, #0x20]                      
02ca735c: ldp     x26, x25, [sp, #0x10]                      
02ca7360: ldr     x30, [sp], #0x50                           
02ca7364: b       #0x3be76dc                                 
## <RestoreAllPurchases>b__28_0(bool success, string error) -> void
---- IAPManager::<RestoreAllPurchases>b__28_0 0x2ca7368
02ca7368: stp     x30, x23, [sp, #-0x30]!                    
02ca736c: stp     x22, x21, [sp, #0x10]                      
02ca7370: stp     x20, x19, [sp, #0x20]                      
02ca7374: adrp    x23, #0x662f000                            
02ca7378: adrp    x22, #0x6266000                            
02ca737c: mov     x19, x2                                    
02ca7380: ldrb    w8, [x23, #0xae6]                          
02ca7384: ldr     x22, [x22, #0x198]                         T:LogTags
02ca7388: mov     w21, w1                                    
02ca738c: mov     x20, x0                                    
02ca7390: tbnz    w8, #0, #0x2ca73c0                         
02ca7394: adrp    x0, #0x6266000                             
02ca7398: ldr     x0, [x0, #0x198]                           T:LogTags
02ca739c: bl      #0x2b70db0                                 fn_2b70db0
02ca73a0: adrp    x0, #0x6266000                             
02ca73a4: ldr     x0, [x0, #0x460]                           S:'Restore failed: '
02ca73a8: bl      #0x2b70db0                                 fn_2b70db0
02ca73ac: adrp    x0, #0x6266000                             
02ca73b0: ldr     x0, [x0, #0x468]                           S:'Restore succeeded, refreshing purchases and entitlements.'
02ca73b4: bl      #0x2b70db0                                 fn_2b70db0
02ca73b8: mov     w8, #1                                     
02ca73bc: strb    w8, [x23, #0xae6]                          
02ca73c0: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca73c4: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02ca73c8: tbz     w21, #0, #0x2ca740c                        
02ca73cc: adrp    x19, #0x6266000                            
02ca73d0: ldr     x19, [x19, #0x468]                         S:'Restore succeeded, refreshing purchases and entitlements.'
02ca73d4: cbnz    w8, #0x2ca73e0                             
02ca73d8: bl      #0x2b70f30                                 fn_2b70f30
02ca73dc: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca73e0: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time'
02ca73e4: ldr     x1, [x19]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca73e8: ldr     x0, [x8]                                   
02ca73ec: bl      #0x2ca4738                                 WLog::Log
02ca73f0: ldr     x0, [x20, #0x38]                           ._storeController
02ca73f4: cbz     x0, #0x2ca7450                             
02ca73f8: ldp     x20, x19, [sp, #0x20]                      
02ca73fc: mov     x1, xzr                                    
02ca7400: ldp     x22, x21, [sp, #0x10]                      
02ca7404: ldp     x30, x23, [sp], #0x30                      
02ca7408: b       #0x571a3d0                                 UnityEngine.Purchasing.StoreController::FetchPurchases
02ca740c: adrp    x21, #0x6266000                            
02ca7410: ldr     x21, [x21, #0x460]                         S:'Restore failed: '
02ca7414: cbnz    w8, #0x2ca7420                             
02ca7418: bl      #0x2b70f30                                 fn_2b70f30
02ca741c: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca7420: ldr     x8, [x0, #0xb8]                            S:'banner_native_refresh_time'
02ca7424: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02ca7428: mov     x1, x19                                    
02ca742c: mov     x2, xzr                                    
02ca7430: ldr     x20, [x8]                                  
02ca7434: bl      #0x4c9c514                                 System.String::Concat
02ca7438: mov     x1, x0                                     
02ca743c: mov     x0, x20                                    
02ca7440: ldp     x20, x19, [sp, #0x20]                      
02ca7444: ldp     x22, x21, [sp, #0x10]                      
02ca7448: ldp     x30, x23, [sp], #0x30                      
02ca744c: b       #0x2ca47ec                                 WLog::LogError
02ca7450: bl      #0x2b7105c                                 fn_2b7105c
