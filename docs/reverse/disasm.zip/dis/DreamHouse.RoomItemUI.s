#### CLASS DreamHouse.RoomItemUI/<>c__DisplayClass6_0 parent= object
#   field onSelect                       System.Action`1<DreamHouse.RoomItemUI>             off=0x10 attr=6 
#   field <>4__this                      DreamHouse.RoomItemUI                              off=0x18 attr=6 
## .ctor() -> void
---- DreamHouse.RoomItemUI/<>c__DisplayClass6_0::.ctor 0x2d1c734
02d1c734: mov     x1, xzr                                    
02d1c738: b       #0x4e53e9c                                 System.Object::.ctor
## <OnInit>b__0() -> void
---- DreamHouse.RoomItemUI/<>c__DisplayClass6_0::<OnInit>b__0 0x2d1c744
02d1c744: ldr     x8, [x0, #0x10]                            .onSelect
02d1c748: cbz     x8, #0x2d1c760                             
02d1c74c: ldr     x1, [x0, #0x18]                            .<>4__this
02d1c750: ldr     x0, [x8, #0x40]                            
02d1c754: ldr     x2, [x8, #0x28]                            
02d1c758: ldr     x3, [x8, #0x18]                            
02d1c75c: br      x3                                         
02d1c760: ret                                                
#### CLASS DreamHouse.RoomItemUI parent= UnityEngine.MonoBehaviour
#   field _selectButton                  UnityEngine.UI.Button                              off=0x20 attr=1 SerializeField
#   field _iconImage                     UnityEngine.UI.Image                               off=0x28 attr=1 SerializeField
#   field _lockImage                     UnityEngine.UI.Image                               off=0x30 attr=1 SerializeField
#   field _selectedObject                UnityEngine.GameObject                             off=0x38 attr=1 SerializeField
#   field _roomConfig                    DreamHouse.RoomConfig                              off=0x40 attr=1 
## OnDestroy() -> void
---- DreamHouse.RoomItemUI::OnDestroy 0x2d1c710
02d1c710: str     x30, [sp, #-0x10]!                         
02d1c714: ldr     x8, [x0, #0x20]                            ._selectButton
02d1c718: cbz     x8, #0x2d1c730                             
02d1c71c: ldr     x0, [x8, #0x100]                           
02d1c720: cbz     x0, #0x2d1c730                             
02d1c724: mov     x1, xzr                                    
02d1c728: ldr     x30, [sp], #0x10                           
02d1c72c: b       #0x5b4ce48                                 UnityEngine.Events.UnityEventBase::RemoveAllListeners
02d1c730: bl      #0x2b7105c                                 fn_2b7105c
## OnInit(DreamHouse.RoomConfig roomConfig, System.Action`1<DreamHouse.RoomItemUI> onSelect) -> DreamHouse.RoomItemUI
---- DreamHouse.RoomItemUI::OnInit 0x2d1b8cc
02d1b8cc: stp     x30, x23, [sp, #-0x30]!                    
02d1b8d0: stp     x22, x21, [sp, #0x10]                      
02d1b8d4: stp     x20, x19, [sp, #0x20]                      
02d1b8d8: adrp    x21, #0x6630000                            
02d1b8dc: adrp    x23, #0x6269000                            
02d1b8e0: mov     x22, x2                                    
02d1b8e4: ldrb    w8, [x21, #0x19]                           
02d1b8e8: ldr     x23, [x23, #0xbe0]                         T:DreamHouse.RoomItemUI/<>c__DisplayClass6_0
02d1b8ec: mov     x20, x1                                    
02d1b8f0: mov     x19, x0                                    
02d1b8f4: tbnz    w8, #0, #0x2d1b924                         
02d1b8f8: adrp    x0, #0x6269000                             
02d1b8fc: ldr     x0, [x0, #0xbe8]                           M:DreamHouse.RoomItemUI/<>c__DisplayClass6_0::<OnInit>b__0
02d1b900: bl      #0x2b70db0                                 fn_2b70db0
02d1b904: adrp    x0, #0x6269000                             
02d1b908: ldr     x0, [x0, #0xbe0]                           T:DreamHouse.RoomItemUI/<>c__DisplayClass6_0
02d1b90c: bl      #0x2b70db0                                 fn_2b70db0
02d1b910: adrp    x0, #0x6265000                             
02d1b914: ldr     x0, [x0, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d1b918: bl      #0x2b70db0                                 fn_2b70db0
02d1b91c: mov     w8, #1                                     
02d1b920: strb    w8, [x21, #0x19]                           
02d1b924: ldr     x0, [x23]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1b928: bl      #0x2b7104c                                 fn_2b7104c
02d1b92c: mov     x1, xzr                                    
02d1b930: mov     x21, x0                                    
02d1b934: bl      #0x4e53e9c                                 System.Object::.ctor
02d1b938: cbz     x21, #0x2d1b9fc                            
02d1b93c: mov     x0, x21                                    
02d1b940: mov     x1, x22                                    
02d1b944: str     x22, [x0, #0x10]!                          
02d1b948: bl      #0x2b70d54                                 fn_2b70d54
02d1b94c: mov     x0, x21                                    
02d1b950: mov     x1, x19                                    
02d1b954: str     x19, [x0, #0x18]!                          
02d1b958: bl      #0x2b70d54                                 fn_2b70d54
02d1b95c: mov     x22, x19                                   
02d1b960: mov     x1, x20                                    
02d1b964: str     x20, [x22, #0x40]!                         
02d1b968: mov     x0, x22                                    
02d1b96c: bl      #0x2b70d54                                 fn_2b70d54
02d1b970: ldur    x8, [x22, #-0x20]                          
02d1b974: cbz     x8, #0x2d1b9fc                             
02d1b978: adrp    x9, #0x6265000                             
02d1b97c: adrp    x23, #0x6269000                            
02d1b980: ldr     x9, [x9, #0x3f0]                           T:UnityEngine.Events.UnityAction
02d1b984: ldr     x23, [x23, #0xbe8]                         M:DreamHouse.RoomItemUI/<>c__DisplayClass6_0::<OnInit>b__0
02d1b988: ldr     x22, [x8, #0x100]                          
02d1b98c: ldr     x0, [x9]                                   M:AdsManager::<OnApplicationPause>b__26_0
02d1b990: bl      #0x2b7104c                                 fn_2b7104c
02d1b994: ldr     x2, [x23]                                  T:Trading.TradingSession/<>c__DisplayClass56_0
02d1b998: mov     x1, x21                                    
02d1b99c: mov     x3, xzr                                    
02d1b9a0: mov     x23, x0                                    
02d1b9a4: bl      #0x5b4cf98                                 UnityEngine.Events.UnityAction::.ctor
02d1b9a8: cbz     x22, #0x2d1b9fc                            
02d1b9ac: mov     x0, x22                                    
02d1b9b0: mov     x1, x23                                    
02d1b9b4: mov     x2, xzr                                    
02d1b9b8: bl      #0x5b4d0ac                                 UnityEngine.Events.UnityEvent::AddListener
02d1b9bc: cbz     x20, #0x2d1b9fc                            
02d1b9c0: ldr     x0, [x19, #0x28]                           ._iconImage
02d1b9c4: cbz     x0, #0x2d1b9fc                             
02d1b9c8: ldr     x1, [x20, #0x20]                           ._selectButton
02d1b9cc: mov     x2, xzr                                    
02d1b9d0: bl      #0x5c45aa0                                 UnityEngine.UI.Image::set_sprite
02d1b9d4: ldr     x0, [x19, #0x38]                           ._selectedObject
02d1b9d8: cbz     x0, #0x2d1b9fc                             
02d1b9dc: mov     w1, wzr                                    
02d1b9e0: mov     x2, xzr                                    
02d1b9e4: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d1b9e8: mov     x0, x19                                    
02d1b9ec: ldp     x20, x19, [sp, #0x20]                      
02d1b9f0: ldp     x22, x21, [sp, #0x10]                      
02d1b9f4: ldp     x30, x23, [sp], #0x30                      
02d1b9f8: ret                                                
02d1b9fc: bl      #0x2b7105c                                 fn_2b7105c
## SetUnlocked(bool isUnlocked) -> void
---- DreamHouse.RoomItemUI::SetUnlocked 0x2d1bb30
02d1bb30: stp     x30, x19, [sp, #-0x10]!                    
02d1bb34: mov     x19, x0                                    
02d1bb38: ldr     x0, [x0, #0x30]                            ._lockImage
02d1bb3c: tbz     w1, #0, #0x2d1bb6c                         
02d1bb40: cbz     x0, #0x2d1bba0                             
02d1bb44: mov     x1, xzr                                    
02d1bb48: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d1bb4c: cbz     x0, #0x2d1bba0                             
02d1bb50: mov     w1, wzr                                    
02d1bb54: mov     x2, xzr                                    
02d1bb58: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d1bb5c: ldr     x0, [x19, #0x20]                           ._selectButton
02d1bb60: cbz     x0, #0x2d1bba0                             
02d1bb64: mov     w1, #1                                     
02d1bb68: b       #0x2d1bb94                                 
02d1bb6c: cbz     x0, #0x2d1bba0                             
02d1bb70: mov     x1, xzr                                    
02d1bb74: bl      #0x5b339ec                                 UnityEngine.Component::get_gameObject
02d1bb78: cbz     x0, #0x2d1bba0                             
02d1bb7c: mov     w1, #1                                     
02d1bb80: mov     x2, xzr                                    
02d1bb84: bl      #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d1bb88: ldr     x0, [x19, #0x20]                           ._selectButton
02d1bb8c: cbz     x0, #0x2d1bba0                             
02d1bb90: mov     w1, wzr                                    
02d1bb94: mov     x2, xzr                                    
02d1bb98: ldp     x30, x19, [sp], #0x10                      
02d1bb9c: b       #0x5e662d4                                 UnityEngine.UI.Selectable::set_interactable
02d1bba0: bl      #0x2b7105c                                 fn_2b7105c
## SetSelected(bool isSelected) -> void
---- DreamHouse.RoomItemUI::SetSelected 0x2d1bd10
02d1bd10: ldr     x0, [x0, #0x38]                            ._selectedObject
02d1bd14: cbz     x0, #0x2d1bd24                             
02d1bd18: and     w1, w1, #1                                 
02d1bd1c: mov     x2, xzr                                    
02d1bd20: b       #0x5b36b38                                 UnityEngine.GameObject::SetActive
02d1bd24: str     x30, [sp, #-0x10]!                         
02d1bd28: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- DreamHouse.RoomItemUI::.ctor 0x2d1c73c
02d1c73c: mov     x1, xzr                                    
02d1c740: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
