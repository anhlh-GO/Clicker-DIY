#### CLASS CustomQueue`1 parent= object
#   field list                           System.Collections.Generic.LinkedList`1<T>         off=0x0 attr=1 
##  Enqueue (no body)
##  EnqueueFirst (no body)
##  Dequeue (no body)
##  Peek (no body)
##  Clear (no body)
##  get_Count (no body)
##  .ctor (no body)
