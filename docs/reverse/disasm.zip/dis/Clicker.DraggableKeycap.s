#### CLASS Clicker.DraggableKeycap/<>c parent= object
#   field <>9                            Clicker.DraggableKeycap/<>c                        off=0x0 attr=36 
#   field <>9__0_0                       System.Action`1<UnityEngine.SpriteRenderer>        off=0x8 attr=16 
#   field <>9__2_0                       System.Action`1<UnityEngine.SpriteRenderer>        off=0x10 attr=16 
## .cctor() -> void
---- Clicker.DraggableKeycap/<>c::.cctor 0x2d61c90
02d61c90: str     x30, [sp, #-0x20]!                         
02d61c94: stp     x20, x19, [sp, #0x10]                      
02d61c98: adrp    x19, #0x6630000                            
02d61c9c: adrp    x20, #0x626b000                            
02d61ca0: ldrb    w8, [x19, #0x300]                          
02d61ca4: ldr     x20, [x20, #0xf40]                         T:Clicker.DraggableKeycap/<>c
02d61ca8: tbnz    w8, #0, #0x2d61cc0                         
02d61cac: adrp    x0, #0x626b000                             
02d61cb0: ldr     x0, [x0, #0xf40]                           T:Clicker.DraggableKeycap/<>c
02d61cb4: bl      #0x2b70db0                                 fn_2b70db0
02d61cb8: mov     w8, #1                                     
02d61cbc: strb    w8, [x19, #0x300]                          
02d61cc0: ldr     x0, [x20]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d61cc4: bl      #0x2b7104c                                 fn_2b7104c
02d61cc8: mov     x1, xzr                                    
02d61ccc: mov     x19, x0                                    
02d61cd0: bl      #0x4e53e9c                                 System.Object::.ctor
02d61cd4: ldr     x8, [x20]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d61cd8: mov     x1, x19                                    
02d61cdc: ldr     x8, [x8, #0xb8]                            
02d61ce0: str     x19, [x8]                                  
02d61ce4: ldr     x8, [x20]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d61ce8: ldp     x20, x19, [sp, #0x10]                      
02d61cec: ldr     x0, [x8, #0xb8]                            
02d61cf0: ldr     x30, [sp], #0x20                           
02d61cf4: b       #0x2b70d54                                 
## .ctor() -> void
---- Clicker.DraggableKeycap/<>c::.ctor 0x2d61cf8
02d61cf8: mov     x1, xzr                                    
02d61cfc: b       #0x4e53e9c                                 System.Object::.ctor
## <OnPickUp>b__0_0(UnityEngine.SpriteRenderer x) -> void
---- Clicker.DraggableKeycap/<>c::<OnPickUp>b__0_0 0x2d61d00
02d61d00: movi    d1, #0000000000000000                      
02d61d04: fmov    s0, #1.00000000                            
02d61d08: mov     x0, x1                                     
02d61d0c: mov     x1, xzr                                    
02d61d10: b       #0x2c77d0c                                 DG.Tweening.DOTweenModuleSprite::DOFade
## <OnDropped>b__2_0(UnityEngine.SpriteRenderer x) -> void
---- Clicker.DraggableKeycap/<>c::<OnDropped>b__2_0 0x2d61d14
02d61d14: movi    d0, #0000000000000000                      
02d61d18: movi    d1, #0000000000000000                      
02d61d1c: mov     x0, x1                                     
02d61d20: mov     x1, xzr                                    
02d61d24: b       #0x2c77d0c                                 DG.Tweening.DOTweenModuleSprite::DOFade
#### CLASS Clicker.DraggableKeycap parent= Clicker.DraggableClickerItem
## OnPickUp() -> void
---- Clicker.DraggableKeycap::OnPickUp 0x2d61980
02d61980: stp     x30, x23, [sp, #-0x30]!                    
02d61984: stp     x22, x21, [sp, #0x10]                      
02d61988: stp     x20, x19, [sp, #0x20]                      
02d6198c: adrp    x20, #0x6630000                            
02d61990: adrp    x23, #0x626b000                            
02d61994: mov     x19, x0                                    
02d61998: ldrb    w8, [x20, #0x2fe]                          
02d6199c: ldr     x23, [x23, #0xf40]                         T:Clicker.DraggableKeycap/<>c
02d619a0: tbnz    w8, #0, #0x2d619e8                         
02d619a4: adrp    x0, #0x626a000                             
02d619a8: ldr     x0, [x0, #0xb70]                           T:type53157(k15)
02d619ac: bl      #0x2b70db0                                 fn_2b70db0
02d619b0: adrp    x0, #0x626a000                             
02d619b4: ldr     x0, [x0, #0xb80]                           MS:System.Collections.Generic.List`1::ForEach
02d619b8: bl      #0x2b70db0                                 fn_2b70db0
02d619bc: adrp    x0, #0x626b000                             
02d619c0: ldr     x0, [x0, #0xee0]                           MS:MonoSingleton`1::get_Instance
02d619c4: bl      #0x2b70db0                                 fn_2b70db0
02d619c8: adrp    x0, #0x626b000                             
02d619cc: ldr     x0, [x0, #0xf48]                           M:Clicker.DraggableKeycap/<>c::<OnPickUp>b__0_0
02d619d0: bl      #0x2b70db0                                 fn_2b70db0
02d619d4: adrp    x0, #0x626b000                             
02d619d8: ldr     x0, [x0, #0xf40]                           T:Clicker.DraggableKeycap/<>c
02d619dc: bl      #0x2b70db0                                 fn_2b70db0
02d619e0: mov     w8, #1                                     
02d619e4: strb    w8, [x20, #0x2fe]                          
02d619e8: mov     x0, x19                                    
02d619ec: bl      #0x2d61888                                 Clicker.DraggableClickerItem::OnPickUp
02d619f0: ldr     x0, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d619f4: ldr     x20, [x19, #0x40]                          
02d619f8: ldr     w8, [x0, #0xe4]                            [626b0e4]=0 f=0,0
02d619fc: cbnz    w8, #0x2d61a08                             
02d61a00: bl      #0x2b70f30                                 fn_2b70f30
02d61a04: ldr     x0, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d61a08: ldr     x8, [x0, #0xb8]                            S:'scoop_no_thank'
02d61a0c: ldr     x21, [x8, #8]                              
02d61a10: cbnz    x21, #0x2d61a6c                            
02d61a14: ldr     w9, [x0, #0xe4]                            [626b0e4]=0 f=0,0
02d61a18: cbnz    w9, #0x2d61a28                             
02d61a1c: bl      #0x2b70f30                                 fn_2b70f30
02d61a20: ldr     x8, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d61a24: ldr     x8, [x8, #0xb8]                            
02d61a28: adrp    x9, #0x626a000                             
02d61a2c: ldr     x9, [x9, #0xb70]                           T:type53157(k15)
02d61a30: ldr     x22, [x8]                                  
02d61a34: ldr     x0, [x9]                                   T:type56879(k15)
02d61a38: bl      #0x2b7104c                                 fn_2b7104c
02d61a3c: adrp    x8, #0x626b000                             
02d61a40: mov     x1, x22                                    
02d61a44: mov     x3, xzr                                    
02d61a48: ldr     x8, [x8, #0xf48]                           M:Clicker.DraggableKeycap/<>c::<OnPickUp>b__0_0
02d61a4c: mov     x21, x0                                    
02d61a50: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d61a54: bl      #0x453418c                                 fn_453418c
02d61a58: ldr     x8, [x23]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d61a5c: mov     x1, x21                                    
02d61a60: ldr     x0, [x8, #0xb8]                            S:'scoop_no_thank'
02d61a64: str     x21, [x0, #8]!                             
02d61a68: bl      #0x2b70d54                                 fn_2b70d54
02d61a6c: cbz     x20, #0x2d61ad4                            
02d61a70: adrp    x8, #0x626a000                             
02d61a74: adrp    x22, #0x626b000                            
02d61a78: mov     x0, x20                                    
02d61a7c: ldr     x8, [x8, #0xb80]                           MS:System.Collections.Generic.List`1::ForEach
02d61a80: ldr     x22, [x22, #0xee0]                         MS:MonoSingleton`1::get_Instance
02d61a84: mov     x1, x21                                    
02d61a88: ldr     x2, [x8]                                   T:type56879(k15)
02d61a8c: bl      #0x35a9ce4                                 fn_35a9ce4
02d61a90: ldr     w8, [x19, #0x58]                           
02d61a94: strb    wzr, [x19, #0x48]                          
02d61a98: tbz     w8, #0x1f, #0x2d61aa0                      
02d61a9c: bl      #0x2d61928                                 Clicker.DraggableClickerItem::PlaySoundPickUp
02d61aa0: ldr     x0, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d61aa4: bl      #0x3769600                                 fn_3769600
02d61aa8: cbz     x0, #0x2d61ad4                             
02d61aac: ldr     x0, [x0, #0xa0]                            S:'scoop_get_reward'
02d61ab0: cbz     x0, #0x2d61ad4                             
02d61ab4: ldr     w1, [x19, #0x58]                           
02d61ab8: bl      #0x2d60014                                 Clicker.BaseKeycapObject::PullBackKeycap
02d61abc: mov     w8, #-1                                    
02d61ac0: ldp     x22, x21, [sp, #0x10]                      
02d61ac4: str     w8, [x19, #0x58]                           
02d61ac8: ldp     x20, x19, [sp, #0x20]                      
02d61acc: ldp     x30, x23, [sp], #0x30                      
02d61ad0: ret                                                
02d61ad4: bl      #0x2b7105c                                 fn_2b7105c
## PlaySoundPickUp() -> void
---- Clicker.DraggableKeycap::PlaySoundPickUp 0x2d61aec
02d61aec: ret                                                
## OnDropped(int index) -> void
---- Clicker.DraggableKeycap::OnDropped 0x2d61af0
02d61af0: str     x30, [sp, #-0x30]!                         
02d61af4: stp     x22, x21, [sp, #0x10]                      
02d61af8: stp     x20, x19, [sp, #0x20]                      
02d61afc: adrp    x21, #0x6630000                            
02d61b00: mov     w20, w1                                    
02d61b04: mov     x19, x0                                    
02d61b08: ldrb    w8, [x21, #0x2ff]                          
02d61b0c: tbnz    w8, #0, #0x2d61b48                         
02d61b10: adrp    x0, #0x626a000                             
02d61b14: ldr     x0, [x0, #0xb70]                           T:type53157(k15)
02d61b18: bl      #0x2b70db0                                 fn_2b70db0
02d61b1c: adrp    x0, #0x626a000                             
02d61b20: ldr     x0, [x0, #0xb80]                           MS:System.Collections.Generic.List`1::ForEach
02d61b24: bl      #0x2b70db0                                 fn_2b70db0
02d61b28: adrp    x0, #0x626b000                             
02d61b2c: ldr     x0, [x0, #0xf50]                           M:Clicker.DraggableKeycap/<>c::<OnDropped>b__2_0
02d61b30: bl      #0x2b70db0                                 fn_2b70db0
02d61b34: adrp    x0, #0x626b000                             
02d61b38: ldr     x0, [x0, #0xf40]                           T:Clicker.DraggableKeycap/<>c
02d61b3c: bl      #0x2b70db0                                 fn_2b70db0
02d61b40: mov     w8, #1                                     
02d61b44: strb    w8, [x21, #0x2ff]                          
02d61b48: mov     x0, x19                                    
02d61b4c: mov     x1, xzr                                    
02d61b50: bl      #0x5b3391c                                 UnityEngine.Component::get_transform
02d61b54: adrp    x22, #0x662f000                            
02d61b58: mov     x21, x0                                    
02d61b5c: ldrb    w8, [x22, #0xa74]                          
02d61b60: cbnz    w8, #0x2d61b78                             
02d61b64: adrp    x0, #0x6264000                             
02d61b68: ldr     x0, [x0, #0xd8]                            T:UnityEngine.Vector3
02d61b6c: bl      #0x2b70db0                                 fn_2b70db0
02d61b70: mov     w8, #1                                     
02d61b74: strb    w8, [x22, #0xa74]                          
02d61b78: cbz     x21, #0x2d61c7c                            
02d61b7c: adrp    x8, #0x6264000                             
02d61b80: mov     x0, x21                                    
02d61b84: mov     x1, xzr                                    
02d61b88: ldr     x8, [x8, #0xd8]                            T:UnityEngine.Vector3
02d61b8c: ldr     x8, [x8]                                   M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d61b90: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d61b94: ldp     s1, s2, [x8, #0x10]                        
02d61b98: ldr     s0, [x8, #0xc]                             [626400c]=0 f=0,0
02d61b9c: bl      #0x5b470cc                                 UnityEngine.Transform::set_localScale
02d61ba0: ldrb    w8, [x19, #0x48]                           
02d61ba4: cbz     w8, #0x2d61c58                             
02d61ba8: adrp    x22, #0x626b000                            
02d61bac: ldr     x22, [x22, #0xf40]                         T:Clicker.DraggableKeycap/<>c
02d61bb0: ldr     x21, [x19, #0x40]                          
02d61bb4: str     w20, [x19, #0x58]                          
02d61bb8: ldr     x0, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d61bbc: ldr     w8, [x0, #0xe4]                            [62640e4]=0 f=0,0
02d61bc0: cbnz    w8, #0x2d61bcc                             
02d61bc4: bl      #0x2b70f30                                 fn_2b70f30
02d61bc8: ldr     x0, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d61bcc: ldr     x8, [x0, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d61bd0: ldr     x19, [x8, #0x10]                           M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass2_0::<DOSetFloat>b__0
02d61bd4: cbnz    x19, #0x2d61c30                            
02d61bd8: ldr     w9, [x0, #0xe4]                            [62640e4]=0 f=0,0
02d61bdc: cbnz    w9, #0x2d61bec                             
02d61be0: bl      #0x2b70f30                                 fn_2b70f30
02d61be4: ldr     x8, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d61be8: ldr     x8, [x8, #0xb8]                            MS:DG.Tweening.Core.Extensions::SetSpecialStartupMode
02d61bec: adrp    x9, #0x626a000                             
02d61bf0: ldr     x9, [x9, #0xb70]                           T:type53157(k15)
02d61bf4: ldr     x20, [x8]                                  M:DG.Tweening.DOTweenModuleAudio/<>c__DisplayClass1_0::<DOPitch>b__1
02d61bf8: ldr     x0, [x9]                                   T:type56879(k15)
02d61bfc: bl      #0x2b7104c                                 fn_2b7104c
02d61c00: adrp    x8, #0x626b000                             
02d61c04: mov     x1, x20                                    
02d61c08: mov     x3, xzr                                    
02d61c0c: ldr     x8, [x8, #0xf50]                           M:Clicker.DraggableKeycap/<>c::<OnDropped>b__2_0
02d61c10: mov     x19, x0                                    
02d61c14: ldr     x2, [x8]                                   T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d61c18: bl      #0x453418c                                 fn_453418c
02d61c1c: ldr     x8, [x22]                                  T:ScoopGame.CategoryPanel/<>c__DisplayClass11_0
02d61c20: mov     x1, x19                                    
02d61c24: ldr     x0, [x8, #0xb8]                            S:'scoop_no_thank'
02d61c28: str     x19, [x0, #0x10]!                          
02d61c2c: bl      #0x2b70d54                                 fn_2b70d54
02d61c30: cbz     x21, #0x2d61c7c                            
02d61c34: adrp    x8, #0x626a000                             
02d61c38: mov     x0, x21                                    
02d61c3c: mov     x1, x19                                    
02d61c40: ldr     x8, [x8, #0xb80]                           MS:System.Collections.Generic.List`1::ForEach
02d61c44: ldp     x20, x19, [sp, #0x20]                      
02d61c48: ldp     x22, x21, [sp, #0x10]                      
02d61c4c: ldr     x2, [x8]                                   T:type56879(k15)
02d61c50: ldr     x30, [sp], #0x30                           
02d61c54: b       #0x35a9ce4                                 
02d61c58: ldr     x0, [x19, #0x28]                           
02d61c5c: cbz     x0, #0x2d61c7c                             
02d61c60: ldp     s0, s1, [x19, #0x4c]                       
02d61c64: mov     x1, xzr                                    
02d61c68: ldr     s2, [x19, #0x54]                           
02d61c6c: ldp     x20, x19, [sp, #0x20]                      
02d61c70: ldp     x22, x21, [sp, #0x10]                      
02d61c74: ldr     x30, [sp], #0x30                           
02d61c78: b       #0x5b45cec                                 UnityEngine.Transform::set_localPosition
02d61c7c: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- Clicker.DraggableKeycap::.ctor 0x2d61c80
02d61c80: mov     w8, #-1                                    
02d61c84: mov     x1, xzr                                    
02d61c88: str     w8, [x0, #0x58]                            
02d61c8c: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
