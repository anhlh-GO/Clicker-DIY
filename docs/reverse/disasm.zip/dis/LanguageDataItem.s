#### CLASS LanguageDataItem parent= object
#   field Language                       string                                             off=0x10 attr=6 
#   field RegionName                     string                                             off=0x18 attr=6 
#   field Flag                           UnityEngine.Sprite                                 off=0x20 attr=6 
## .ctor() -> void
---- LanguageDataItem::.ctor 0x2cd95ac
02cd95ac: mov     x1, xzr                                    
02cd95b0: b       #0x4e53e9c                                 System.Object::.ctor
