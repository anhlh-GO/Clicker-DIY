#### CLASS DataUser parent= GameData
#   field dataSave                       DataSaveUser                                       off=0x20 attr=1 SerializeField
## get_DataSave() -> DataSaveUser
---- DataUser::get_DataSave 0x2caaf74
02caaf74: ldr     x0, [x0, #0x20]                            .dataSave
02caaf78: ret                                                
## set_DataSave(DataSaveUser value) -> void
---- DataUser::set_DataSave 0x2caaf7c
02caaf7c: str     x1, [x0, #0x20]!                           .dataSave
02caaf80: b       #0x2b70d54                                 
## get_Tracking() -> TrackingPlayTime
---- DataUser::get_Tracking 0x2caaf84
02caaf84: ldr     x8, [x0, #0x20]                            .dataSave
02caaf88: cbz     x8, #0x2caaf94                             
02caaf8c: ldr     x0, [x8, #0x98]                            
02caaf90: ret                                                
02caaf94: str     x30, [sp, #-0x10]!                         
02caaf98: bl      #0x2b7105c                                 fn_2b7105c
## SaveData() -> void
---- DataUser::SaveData 0x2caaf9c
02caaf9c: stp     x30, x21, [sp, #-0x20]!                    
02caafa0: stp     x20, x19, [sp, #0x10]                      
02caafa4: adrp    x20, #0x662f000                            
02caafa8: adrp    x21, #0x6266000                            
02caafac: mov     x19, x0                                    
02caafb0: ldrb    w8, [x20, #0xb20]                          
02caafb4: ldr     x21, [x21, #0x658]                         MS:MonoSingleton`1::get_Instance
02caafb8: tbnz    w8, #0, #0x2caafdc                         
02caafbc: adrp    x0, #0x6266000                             
02caafc0: ldr     x0, [x0, #0x7f0]                           MS:DataManager::SaveData
02caafc4: bl      #0x2b70db0                                 fn_2b70db0
02caafc8: adrp    x0, #0x6266000                             
02caafcc: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02caafd0: bl      #0x2b70db0                                 fn_2b70db0
02caafd4: mov     w8, #1                                     
02caafd8: strb    w8, [x20, #0xb20]                          
02caafdc: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02caafe0: bl      #0x3769600                                 fn_3769600
02caafe4: ldr     x8, [x19]                                  
02caafe8: mov     x20, x0                                    
02caafec: mov     x0, x19                                    
02caaff0: ldr     x9, [x8, #0x2a8]                           
02caaff4: ldr     x1, [x8, #0x2b0]                           
02caaff8: blr     x9                                         
02caaffc: cbz     x20, #0x2cab024                            
02cab000: adrp    x8, #0x6266000                             
02cab004: mov     x1, x0                                     
02cab008: mov     x0, x20                                    
02cab00c: ldr     x8, [x8, #0x7f0]                           MS:DataManager::SaveData
02cab010: ldr     x2, [x19, #0x20]                           .dataSave
02cab014: ldp     x20, x19, [sp, #0x10]                      
02cab018: ldr     x3, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cab01c: ldp     x30, x21, [sp], #0x20                      
02cab020: b       #0x3169790                                 
02cab024: bl      #0x2b7105c                                 fn_2b7105c
## LoadData() -> void
---- DataUser::LoadData 0x2cab028
02cab028: stp     x30, x21, [sp, #-0x20]!                    
02cab02c: stp     x20, x19, [sp, #0x10]                      
02cab030: adrp    x20, #0x662f000                            
02cab034: adrp    x21, #0x6266000                            
02cab038: mov     x19, x0                                    
02cab03c: ldrb    w8, [x20, #0xb21]                          
02cab040: ldr     x21, [x21, #0x658]                         MS:MonoSingleton`1::get_Instance
02cab044: tbnz    w8, #0, #0x2cab08c                         
02cab048: adrp    x0, #0x6266000                             
02cab04c: ldr     x0, [x0, #0x7f8]                           MS:DataManager::LoadData
02cab050: bl      #0x2b70db0                                 fn_2b70db0
02cab054: adrp    x0, #0x6266000                             
02cab058: ldr     x0, [x0, #0x650]                           MS:System.Collections.Generic.List`1::.ctor
02cab05c: bl      #0x2b70db0                                 fn_2b70db0
02cab060: adrp    x0, #0x6266000                             
02cab064: ldr     x0, [x0, #0x648]                           T:type15061(k15)
02cab068: bl      #0x2b70db0                                 fn_2b70db0
02cab06c: adrp    x0, #0x6266000                             
02cab070: ldr     x0, [x0, #0x658]                           MS:MonoSingleton`1::get_Instance
02cab074: bl      #0x2b70db0                                 fn_2b70db0
02cab078: adrp    x0, #0x6266000                             
02cab07c: ldr     x0, [x0, #0x7e8]                           T:Trading.TradingSaveData
02cab080: bl      #0x2b70db0                                 fn_2b70db0
02cab084: mov     w8, #1                                     
02cab088: strb    w8, [x20, #0xb21]                          
02cab08c: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cab090: bl      #0x3769600                                 fn_3769600
02cab094: ldr     x8, [x19]                                  
02cab098: mov     x20, x0                                    
02cab09c: mov     x0, x19                                    
02cab0a0: ldr     x9, [x8, #0x2a8]                           
02cab0a4: ldr     x1, [x8, #0x2b0]                           
02cab0a8: blr     x9                                         
02cab0ac: cbz     x20, #0x2cab368                            
02cab0b0: adrp    x8, #0x6266000                             
02cab0b4: mov     x1, x0                                     
02cab0b8: mov     x0, x20                                    
02cab0bc: ldr     x8, [x8, #0x7f8]                           MS:DataManager::LoadData
02cab0c0: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cab0c4: bl      #0x31690b0                                 fn_31690b0
02cab0c8: mov     x1, x0                                     
02cab0cc: str     x0, [x19, #0x20]!                          .dataSave
02cab0d0: mov     x0, x19                                    
02cab0d4: bl      #0x2b70d54                                 fn_2b70d54
02cab0d8: ldr     x20, [x19]                                 
02cab0dc: cbz     x20, #0x2cab368                            
02cab0e0: mov     x21, x20                                   
02cab0e4: ldr     x8, [x21, #0x58]!                          S:'inter_ad_on_off'
02cab0e8: cbnz    x8, #0x2cab128                             
02cab0ec: adrp    x8, #0x6266000                             
02cab0f0: ldr     x8, [x8, #0x648]                           T:type15061(k15)
02cab0f4: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cab0f8: bl      #0x2b7104c                                 fn_2b7104c
02cab0fc: adrp    x8, #0x6266000                             
02cab100: mov     x20, x0                                    
02cab104: ldr     x8, [x8, #0x650]                           MS:System.Collections.Generic.List`1::.ctor
02cab108: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cab10c: bl      #0x3569388                                 fn_3569388
02cab110: mov     x0, x21                                    
02cab114: mov     x1, x20                                    
02cab118: str     x20, [x21]                                 
02cab11c: bl      #0x2b70d54                                 fn_2b70d54
02cab120: ldr     x20, [x19]                                 
02cab124: cbz     x20, #0x2cab368                            
02cab128: mov     x21, x20                                   
02cab12c: ldr     x8, [x21, #0x60]!                          S:'open_ad_on_off'
02cab130: cbnz    x8, #0x2cab170                             
02cab134: adrp    x8, #0x6266000                             
02cab138: ldr     x8, [x8, #0x648]                           T:type15061(k15)
02cab13c: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cab140: bl      #0x2b7104c                                 fn_2b7104c
02cab144: adrp    x8, #0x6266000                             
02cab148: mov     x20, x0                                    
02cab14c: ldr     x8, [x8, #0x650]                           MS:System.Collections.Generic.List`1::.ctor
02cab150: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cab154: bl      #0x3569388                                 fn_3569388
02cab158: mov     x0, x21                                    
02cab15c: mov     x1, x20                                    
02cab160: str     x20, [x21]                                 
02cab164: bl      #0x2b70d54                                 fn_2b70d54
02cab168: ldr     x20, [x19]                                 
02cab16c: cbz     x20, #0x2cab368                            
02cab170: mov     x21, x20                                   
02cab174: ldr     x8, [x21, #0x68]!                          S:'native_full_srceen_time_showbtn'
02cab178: cbnz    x8, #0x2cab1b8                             
02cab17c: adrp    x8, #0x6266000                             
02cab180: ldr     x8, [x8, #0x648]                           T:type15061(k15)
02cab184: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cab188: bl      #0x2b7104c                                 fn_2b7104c
02cab18c: adrp    x8, #0x6266000                             
02cab190: mov     x20, x0                                    
02cab194: ldr     x8, [x8, #0x650]                           MS:System.Collections.Generic.List`1::.ctor
02cab198: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cab19c: bl      #0x3569388                                 fn_3569388
02cab1a0: mov     x0, x21                                    
02cab1a4: mov     x1, x20                                    
02cab1a8: str     x20, [x21]                                 
02cab1ac: bl      #0x2b70d54                                 fn_2b70d54
02cab1b0: ldr     x20, [x19]                                 
02cab1b4: cbz     x20, #0x2cab368                            
02cab1b8: mov     x21, x20                                   
02cab1bc: ldr     x8, [x21, #0x70]!                          S:'open_ad_id'
02cab1c0: cbnz    x8, #0x2cab200                             
02cab1c4: adrp    x8, #0x6266000                             
02cab1c8: ldr     x8, [x8, #0x648]                           T:type15061(k15)
02cab1cc: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cab1d0: bl      #0x2b7104c                                 fn_2b7104c
02cab1d4: adrp    x8, #0x6266000                             
02cab1d8: mov     x20, x0                                    
02cab1dc: ldr     x8, [x8, #0x650]                           MS:System.Collections.Generic.List`1::.ctor
02cab1e0: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cab1e4: bl      #0x3569388                                 fn_3569388
02cab1e8: mov     x0, x21                                    
02cab1ec: mov     x1, x20                                    
02cab1f0: str     x20, [x21]                                 
02cab1f4: bl      #0x2b70d54                                 fn_2b70d54
02cab1f8: ldr     x20, [x19]                                 
02cab1fc: cbz     x20, #0x2cab368                            
02cab200: mov     x21, x20                                   
02cab204: ldr     x8, [x21, #0x78]!                          S:'Latest Fetch call still pending.'
02cab208: cbnz    x8, #0x2cab248                             
02cab20c: adrp    x8, #0x6266000                             
02cab210: ldr     x8, [x8, #0x648]                           T:type15061(k15)
02cab214: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cab218: bl      #0x2b7104c                                 fn_2b7104c
02cab21c: adrp    x8, #0x6266000                             
02cab220: mov     x20, x0                                    
02cab224: ldr     x8, [x8, #0x650]                           MS:System.Collections.Generic.List`1::.ctor
02cab228: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cab22c: bl      #0x3569388                                 fn_3569388
02cab230: mov     x0, x21                                    
02cab234: mov     x1, x20                                    
02cab238: str     x20, [x21]                                 
02cab23c: bl      #0x2b70d54                                 fn_2b70d54
02cab240: ldr     x20, [x19]                                 
02cab244: cbz     x20, #0x2cab368                            
02cab248: mov     x21, x20                                   
02cab24c: ldr     x8, [x21, #0x80]!                          S:'Fetch failed.'
02cab250: cbnz    x8, #0x2cab290                             
02cab254: adrp    x8, #0x6266000                             
02cab258: ldr     x8, [x8, #0x648]                           T:type15061(k15)
02cab25c: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cab260: bl      #0x2b7104c                                 fn_2b7104c
02cab264: adrp    x8, #0x6266000                             
02cab268: mov     x20, x0                                    
02cab26c: ldr     x8, [x8, #0x650]                           MS:System.Collections.Generic.List`1::.ctor
02cab270: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cab274: bl      #0x3569388                                 fn_3569388
02cab278: mov     x0, x21                                    
02cab27c: mov     x1, x20                                    
02cab280: str     x20, [x21]                                 
02cab284: bl      #0x2b70d54                                 fn_2b70d54
02cab288: ldr     x20, [x19]                                 
02cab28c: cbz     x20, #0x2cab368                            
02cab290: mov     x21, x20                                   
02cab294: ldr     x8, [x21, #0x88]!                          S:'native_banner_id'
02cab298: cbnz    x8, #0x2cab2d8                             
02cab29c: adrp    x8, #0x6266000                             
02cab2a0: ldr     x8, [x8, #0x648]                           T:type15061(k15)
02cab2a4: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cab2a8: bl      #0x2b7104c                                 fn_2b7104c
02cab2ac: adrp    x8, #0x6266000                             
02cab2b0: mov     x20, x0                                    
02cab2b4: ldr     x8, [x8, #0x650]                           MS:System.Collections.Generic.List`1::.ctor
02cab2b8: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cab2bc: bl      #0x3569388                                 fn_3569388
02cab2c0: mov     x0, x21                                    
02cab2c4: mov     x1, x20                                    
02cab2c8: str     x20, [x21]                                 
02cab2cc: bl      #0x2b70d54                                 fn_2b70d54
02cab2d0: ldr     x20, [x19]                                 
02cab2d4: cbz     x20, #0x2cab368                            
02cab2d8: mov     x21, x20                                   
02cab2dc: ldr     x8, [x21, #0x90]!                          S:'mrec_ad_id'
02cab2e0: cbnz    x8, #0x2cab320                             
02cab2e4: adrp    x8, #0x6266000                             
02cab2e8: ldr     x8, [x8, #0x648]                           T:type15061(k15)
02cab2ec: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cab2f0: bl      #0x2b7104c                                 fn_2b7104c
02cab2f4: adrp    x8, #0x6266000                             
02cab2f8: mov     x20, x0                                    
02cab2fc: ldr     x8, [x8, #0x650]                           MS:System.Collections.Generic.List`1::.ctor
02cab300: ldr     x1, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cab304: bl      #0x3569388                                 fn_3569388
02cab308: mov     x0, x21                                    
02cab30c: mov     x1, x20                                    
02cab310: str     x20, [x21]                                 
02cab314: bl      #0x2b70d54                                 fn_2b70d54
02cab318: ldr     x20, [x19]                                 
02cab31c: cbz     x20, #0x2cab368                            
02cab320: ldr     x8, [x20, #0xa8]!                          [662f0a8]=600001d f=2.40742e-35,0
02cab324: cbz     x8, #0x2cab334                             
02cab328: ldp     x20, x19, [sp, #0x10]                      
02cab32c: ldp     x30, x21, [sp], #0x20                      
02cab330: ret                                                
02cab334: adrp    x8, #0x6266000                             
02cab338: ldr     x8, [x8, #0x7e8]                           T:Trading.TradingSaveData
02cab33c: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cab340: bl      #0x2b7104c                                 fn_2b7104c
02cab344: mov     x1, xzr                                    
02cab348: mov     x19, x0                                    
02cab34c: bl      #0x2d044c0                                 Trading.TradingSaveData::.ctor
02cab350: mov     x0, x20                                    
02cab354: mov     x1, x19                                    
02cab358: str     x19, [x20]                                 
02cab35c: ldp     x20, x19, [sp, #0x10]                      
02cab360: ldp     x30, x21, [sp], #0x20                      
02cab364: b       #0x2b70d54                                 
02cab368: bl      #0x2b7105c                                 fn_2b7105c
## NewData() -> void
---- DataUser::NewData 0x2cab36c
02cab36c: stp     x30, x23, [sp, #-0x30]!                    
02cab370: stp     x22, x21, [sp, #0x10]                      
02cab374: stp     x20, x19, [sp, #0x20]                      
02cab378: adrp    x20, #0x662f000                            
02cab37c: adrp    x21, #0x6266000                            
02cab380: mov     x19, x0                                    
02cab384: ldrb    w8, [x20, #0xb22]                          
02cab388: ldr     x21, [x21, #0x800]                         T:DataSaveUser
02cab38c: tbnz    w8, #0, #0x2cab3ec                         
02cab390: adrp    x0, #0x6266000                             
02cab394: ldr     x0, [x0, #0x800]                           T:DataSaveUser
02cab398: bl      #0x2b70db0                                 fn_2b70db0
02cab39c: adrp    x0, #0x6266000                             
02cab3a0: ldr     x0, [x0, #0x128]                           T:System.DateTime
02cab3a4: bl      #0x2b70db0                                 fn_2b70db0
02cab3a8: adrp    x0, #0x6266000                             
02cab3ac: ldr     x0, [x0, #0x650]                           MS:System.Collections.Generic.List`1::.ctor
02cab3b0: bl      #0x2b70db0                                 fn_2b70db0
02cab3b4: adrp    x0, #0x6266000                             
02cab3b8: ldr     x0, [x0, #0x648]                           T:type15061(k15)
02cab3bc: bl      #0x2b70db0                                 fn_2b70db0
02cab3c0: adrp    x0, #0x6266000                             
02cab3c4: ldr     x0, [x0, #0x808]                           T:TrackingPlayTime
02cab3c8: bl      #0x2b70db0                                 fn_2b70db0
02cab3cc: adrp    x0, #0x6266000                             
02cab3d0: ldr     x0, [x0, #0x7e8]                           T:Trading.TradingSaveData
02cab3d4: bl      #0x2b70db0                                 fn_2b70db0
02cab3d8: adrp    x0, #0x6263000                             
02cab3dc: ldr     x0, [x0, #0xa90]                           S:''
02cab3e0: bl      #0x2b70db0                                 fn_2b70db0
02cab3e4: mov     w8, #1                                     
02cab3e8: strb    w8, [x20, #0xb22]                          
02cab3ec: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cab3f0: bl      #0x2b7104c                                 fn_2b7104c
02cab3f4: mov     x20, x0                                    
02cab3f8: bl      #0x2caacb8                                 DataSaveUser::.ctor
02cab3fc: str     x20, [x19, #0x20]!                         .dataSave
02cab400: mov     x0, x19                                    
02cab404: mov     x1, x20                                    
02cab408: bl      #0x2b70d54                                 fn_2b70d54
02cab40c: ldr     x20, [x19]                                 
02cab410: cbz     x20, #0x2cab69c                            
02cab414: adrp    x8, #0x6266000                             
02cab418: ldr     x8, [x8, #0x128]                           T:System.DateTime
02cab41c: strh    wzr, [x20, #0x10]                          
02cab420: ldr     x0, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cab424: ldr     w8, [x0, #0xe4]                            [62630e4]=0 f=0,0
02cab428: cbnz    w8, #0x2cab430                             
02cab42c: bl      #0x2b70f30                                 fn_2b70f30
02cab430: mov     x0, xzr                                    
02cab434: bl      #0x4df25c8                                 System.DateTime::get_Now
02cab438: str     x0, [x20, #0x18]                           
02cab43c: ldr     x20, [x19]                                 
02cab440: cbz     x20, #0x2cab69c                            
02cab444: add     x0, x20, #0x18                             &662f018
02cab448: mov     x1, xzr                                    
02cab44c: bl      #0x4df3550                                 System.DateTime::ToString
02cab450: mov     x1, x0                                     
02cab454: str     x0, [x20, #0x20]!                          .dataSave
02cab458: mov     x0, x20                                    
02cab45c: bl      #0x2b70d54                                 fn_2b70d54
02cab460: ldr     x0, [x19]                                  
02cab464: cbz     x0, #0x2cab69c                             
02cab468: adrp    x8, #0x6263000                             
02cab46c: adrp    x21, #0x6266000                            
02cab470: ldr     x8, [x8, #0xa90]                           S:''
02cab474: ldr     x1, [x8]                                   &2c5bbd4(=a9bd7bfdd503233f)
02cab478: ldr     x21, [x21, #0x808]                         T:TrackingPlayTime
02cab47c: str     x1, [x0, #0x28]!                           
02cab480: bl      #0x2b70d54                                 fn_2b70d54
02cab484: ldr     x0, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cab488: ldr     x20, [x19]                                 
02cab48c: bl      #0x2b7104c                                 fn_2b7104c
02cab490: mov     x1, xzr                                    
02cab494: mov     x21, x0                                    
02cab498: bl      #0x4e53e9c                                 System.Object::.ctor
02cab49c: str     wzr, [x21, #0x10]                          
02cab4a0: cbz     x20, #0x2cab69c                            
02cab4a4: adrp    x23, #0x6266000                            
02cab4a8: adrp    x22, #0x6266000                            
02cab4ac: mov     x1, x21                                    
02cab4b0: ldr     x23, [x23, #0x648]                         T:type15061(k15)
02cab4b4: ldr     x22, [x22, #0x650]                         MS:System.Collections.Generic.List`1::.ctor
02cab4b8: str     x21, [x20, #0x98]!                         
02cab4bc: mov     x0, x20                                    
02cab4c0: bl      #0x2b70d54                                 fn_2b70d54
02cab4c4: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cab4c8: ldr     x20, [x19]                                 
02cab4cc: bl      #0x2b7104c                                 fn_2b7104c
02cab4d0: ldr     x1, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cab4d4: mov     x21, x0                                    
02cab4d8: bl      #0x3569388                                 fn_3569388
02cab4dc: cbz     x20, #0x2cab69c                            
02cab4e0: str     x21, [x20, #0x58]!                         
02cab4e4: mov     x0, x20                                    
02cab4e8: mov     x1, x21                                    
02cab4ec: bl      #0x2b70d54                                 fn_2b70d54
02cab4f0: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cab4f4: ldr     x20, [x19]                                 
02cab4f8: bl      #0x2b7104c                                 fn_2b7104c
02cab4fc: ldr     x1, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cab500: mov     x21, x0                                    
02cab504: bl      #0x3569388                                 fn_3569388
02cab508: cbz     x20, #0x2cab69c                            
02cab50c: str     x21, [x20, #0x60]!                         
02cab510: mov     x0, x20                                    
02cab514: mov     x1, x21                                    
02cab518: bl      #0x2b70d54                                 fn_2b70d54
02cab51c: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cab520: ldr     x20, [x19]                                 
02cab524: bl      #0x2b7104c                                 fn_2b7104c
02cab528: ldr     x1, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cab52c: mov     x21, x0                                    
02cab530: bl      #0x3569388                                 fn_3569388
02cab534: cbz     x20, #0x2cab69c                            
02cab538: str     x21, [x20, #0x68]!                         
02cab53c: mov     x0, x20                                    
02cab540: mov     x1, x21                                    
02cab544: bl      #0x2b70d54                                 fn_2b70d54
02cab548: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cab54c: ldr     x20, [x19]                                 
02cab550: bl      #0x2b7104c                                 fn_2b7104c
02cab554: ldr     x1, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cab558: mov     x21, x0                                    
02cab55c: bl      #0x3569388                                 fn_3569388
02cab560: cbz     x20, #0x2cab69c                            
02cab564: str     x21, [x20, #0x70]!                         
02cab568: mov     x0, x20                                    
02cab56c: mov     x1, x21                                    
02cab570: bl      #0x2b70d54                                 fn_2b70d54
02cab574: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cab578: ldr     x20, [x19]                                 
02cab57c: bl      #0x2b7104c                                 fn_2b7104c
02cab580: ldr     x1, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cab584: mov     x21, x0                                    
02cab588: bl      #0x3569388                                 fn_3569388
02cab58c: cbz     x20, #0x2cab69c                            
02cab590: str     x21, [x20, #0x78]!                         
02cab594: mov     x0, x20                                    
02cab598: mov     x1, x21                                    
02cab59c: bl      #0x2b70d54                                 fn_2b70d54
02cab5a0: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cab5a4: ldr     x20, [x19]                                 
02cab5a8: bl      #0x2b7104c                                 fn_2b7104c
02cab5ac: ldr     x1, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cab5b0: mov     x21, x0                                    
02cab5b4: bl      #0x3569388                                 fn_3569388
02cab5b8: cbz     x20, #0x2cab69c                            
02cab5bc: str     x21, [x20, #0x80]!                         
02cab5c0: mov     x0, x20                                    
02cab5c4: mov     x1, x21                                    
02cab5c8: bl      #0x2b70d54                                 fn_2b70d54
02cab5cc: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cab5d0: ldr     x20, [x19]                                 
02cab5d4: bl      #0x2b7104c                                 fn_2b7104c
02cab5d8: ldr     x1, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cab5dc: mov     x21, x0                                    
02cab5e0: bl      #0x3569388                                 fn_3569388
02cab5e4: cbz     x20, #0x2cab69c                            
02cab5e8: str     x21, [x20, #0x88]!                         
02cab5ec: mov     x0, x20                                    
02cab5f0: mov     x1, x21                                    
02cab5f4: bl      #0x2b70d54                                 fn_2b70d54
02cab5f8: ldr     x0, [x23]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cab5fc: ldr     x20, [x19]                                 
02cab600: bl      #0x2b7104c                                 fn_2b7104c
02cab604: ldr     x1, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cab608: mov     x21, x0                                    
02cab60c: bl      #0x3569388                                 fn_3569388
02cab610: cbz     x20, #0x2cab69c                            
02cab614: adrp    x22, #0x6266000                            
02cab618: mov     x1, x21                                    
02cab61c: ldr     x22, [x22, #0x7e8]                         T:Trading.TradingSaveData
02cab620: str     x21, [x20, #0x90]!                         
02cab624: mov     x0, x20                                    
02cab628: bl      #0x2b70d54                                 fn_2b70d54
02cab62c: ldr     x0, [x22]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cab630: ldr     x20, [x19]                                 
02cab634: bl      #0x2b7104c                                 fn_2b7104c
02cab638: mov     x1, xzr                                    
02cab63c: mov     x21, x0                                    
02cab640: bl      #0x2d044c0                                 Trading.TradingSaveData::.ctor
02cab644: cbz     x20, #0x2cab69c                            
02cab648: str     x21, [x20, #0xa8]!                         
02cab64c: mov     x0, x20                                    
02cab650: mov     x1, x21                                    
02cab654: bl      #0x2b70d54                                 fn_2b70d54
02cab658: ldr     x8, [x19]                                  
02cab65c: cbz     x8, #0x2cab69c                             
02cab660: adrp    x9, #0x1040000                             
02cab664: ldp     x20, x19, [sp, #0x20]                      
02cab668: ldr     d0, [x9, #0x930]                           [1040930]=101000100010101 f=9.21956e-41,2.36936e-38
02cab66c: adrp    x9, #0x1087000                             
02cab670: str     wzr, [x8, #0xa0]                           
02cab674: ldp     x22, x21, [sp, #0x10]                      
02cab678: str     wzr, [x8, #0x30]                           
02cab67c: stur    d0, [x8, #0x34]                            
02cab680: ldr     q0, [x9, #0x520]                           [1087520]=c8 f=2.8026e-43,0
02cab684: strb    wzr, [x8, #0x40]                           
02cab688: stur    wzr, [x8, #0x41]                           
02cab68c: strb    wzr, [x8, #0x45]                           
02cab690: stur    q0, [x8, #0x48]                            
02cab694: ldp     x30, x23, [sp], #0x30                      
02cab698: ret                                                
02cab69c: bl      #0x2b7105c                                 fn_2b7105c
## GetDaysPassed() -> int
---- DataUser::GetDaysPassed 0x2cab6a0
02cab6a0: sub     sp, sp, #0x40                              
02cab6a4: str     d8, [sp, #0x10]                            
02cab6a8: stp     x30, x21, [sp, #0x20]                      
02cab6ac: stp     x20, x19, [sp, #0x30]                      
02cab6b0: adrp    x20, #0x662f000                            
02cab6b4: mov     x19, x0                                    
02cab6b8: ldrb    w8, [x20, #0xb23]                          
02cab6bc: tbnz    w8, #0, #0x2cab6f8                         
02cab6c0: adrp    x0, #0x6266000                             
02cab6c4: ldr     x0, [x0, #0x128]                           T:System.DateTime
02cab6c8: bl      #0x2b70db0                                 fn_2b70db0
02cab6cc: adrp    x0, #0x6265000                             
02cab6d0: ldr     x0, [x0, #0xb48]                           T:System.Math
02cab6d4: bl      #0x2b70db0                                 fn_2b70db0
02cab6d8: adrp    x0, #0x6265000                             
02cab6dc: ldr     x0, [x0, #0xf98]                           T:System.TimeSpan
02cab6e0: bl      #0x2b70db0                                 fn_2b70db0
02cab6e4: adrp    x0, #0x6266000                             
02cab6e8: ldr     x0, [x0, #0x810]                           S:'o'
02cab6ec: bl      #0x2b70db0                                 fn_2b70db0
02cab6f0: mov     w8, #1                                     
02cab6f4: strb    w8, [x20, #0xb23]                          
02cab6f8: ldr     x8, [x19, #0x20]                           .dataSave
02cab6fc: str     xzr, [sp, #0x18]                           
02cab700: str     xzr, [sp, #8]                              
02cab704: cbz     x8, #0x2cab7f0                             
02cab708: adrp    x20, #0x6266000                            
02cab70c: adrp    x21, #0x6266000                            
02cab710: ldr     x20, [x20, #0x128]                         T:System.DateTime
02cab714: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cab718: ldr     w9, [x0, #0xe4]                            [62660e4]=0 f=0,0
02cab71c: ldr     x21, [x21, #0x810]                         S:'o'
02cab720: ldr     x19, [x8, #0x20]                           
02cab724: cbnz    w9, #0x2cab72c                             
02cab728: bl      #0x2b70f30                                 fn_2b70f30
02cab72c: ldr     x1, [x21]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cab730: add     x4, sp, #0x18                              
02cab734: mov     x0, x19                                    
02cab738: mov     x2, xzr                                    
02cab73c: mov     w3, wzr                                    
02cab740: mov     x5, xzr                                    
02cab744: bl      #0x4df3b04                                 System.DateTime::TryParseExact
02cab748: tbz     w0, #0, #0x2cab7d8                         
02cab74c: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cab750: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02cab754: cbnz    w8, #0x2cab75c                             
02cab758: bl      #0x2b70f30                                 fn_2b70f30
02cab75c: mov     x0, xzr                                    
02cab760: bl      #0x4df25c8                                 System.DateTime::get_Now
02cab764: ldr     x1, [sp, #0x18]                            
02cab768: mov     x2, xzr                                    
02cab76c: bl      #0x4df3fb4                                 System.DateTime::op_Subtraction
02cab770: adrp    x8, #0x6265000                             
02cab774: ldr     x8, [x8, #0xf98]                           T:System.TimeSpan
02cab778: str     x0, [sp, #8]                               
02cab77c: ldr     x8, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02cab780: ldr     w9, [x8, #0xe4]                            [62650e4]=0 f=0,0
02cab784: cbnz    w9, #0x2cab790                             
02cab788: mov     x0, x8                                     
02cab78c: bl      #0x2b70f30                                 fn_2b70f30
02cab790: add     x0, sp, #8                                 
02cab794: mov     x1, xzr                                    
02cab798: bl      #0x4e293bc                                 System.TimeSpan::get_TotalDays
02cab79c: adrp    x8, #0x6265000                             
02cab7a0: fmov    d8, d0                                     
02cab7a4: ldr     x8, [x8, #0xb48]                           T:System.Math
02cab7a8: ldr     x0, [x8]                                   M:AdsManager::<OnApplicationPause>b__26_0
02cab7ac: ldr     w8, [x0, #0xe4]                            [62660e4]=0 f=0,0
02cab7b0: cbnz    w8, #0x2cab7b8                             
02cab7b4: bl      #0x2b70f30                                 fn_2b70f30
02cab7b8: frintm  d0, d8                                     
02cab7bc: mov     x8, #0x7ff0000000000000                    
02cab7c0: fcvtms  w9, d8                                     
02cab7c4: fmov    d1, x8                                     
02cab7c8: mov     w8, #-0xffffffff80000000                   
02cab7cc: fcmp    d0, d1                                     
02cab7d0: csel    w0, w8, w9, eq                             
02cab7d4: b       #0x2cab7dc                                 
02cab7d8: mov     w0, #1                                     
02cab7dc: ldp     x20, x19, [sp, #0x30]                      
02cab7e0: ldr     d8, [sp, #0x10]                            
02cab7e4: ldp     x30, x21, [sp, #0x20]                      
02cab7e8: add     sp, sp, #0x40                              
02cab7ec: ret                                                
02cab7f0: bl      #0x2b7105c                                 fn_2b7105c
## GetLocaleId() -> int
---- DataUser::GetLocaleId 0x2cab7f4
02cab7f4: ldr     x8, [x0, #0x20]                            .dataSave
02cab7f8: cbz     x8, #0x2cab804                             
02cab7fc: ldr     w0, [x8, #0x30]                            
02cab800: ret                                                
02cab804: str     x30, [sp, #-0x10]!                         
02cab808: bl      #0x2b7105c                                 fn_2b7105c
## SetLocaleId(int localeId) -> void
---- DataUser::SetLocaleId 0x2cab80c
02cab80c: ldr     x8, [x0, #0x20]                            .dataSave
02cab810: cbz     x8, #0x2cab828                             
02cab814: str     w1, [x8, #0x30]                            
02cab818: ldr     x8, [x0]                                   
02cab81c: ldr     x1, [x8, #0x260]                           
02cab820: ldr     x2, [x8, #0x258]                           
02cab824: br      x2                                         
02cab828: str     x30, [sp, #-0x10]!                         
02cab82c: bl      #0x2b7105c                                 fn_2b7105c
## GetTimePlayed() -> int
---- DataUser::GetTimePlayed 0x2cab830
02cab830: sub     sp, sp, #0x30                              
02cab834: stp     x30, x21, [sp, #0x10]                      
02cab838: stp     x20, x19, [sp, #0x20]                      
02cab83c: adrp    x21, #0x662f000                            
02cab840: adrp    x20, #0x6266000                            
02cab844: mov     x19, x0                                    
02cab848: ldrb    w8, [x21, #0xb24]                          
02cab84c: ldr     x20, [x20, #0x128]                         T:System.DateTime
02cab850: tbnz    w8, #0, #0x2cab874                         
02cab854: adrp    x0, #0x6266000                             
02cab858: ldr     x0, [x0, #0x128]                           T:System.DateTime
02cab85c: bl      #0x2b70db0                                 fn_2b70db0
02cab860: adrp    x0, #0x6265000                             
02cab864: ldr     x0, [x0, #0xf98]                           T:System.TimeSpan
02cab868: bl      #0x2b70db0                                 fn_2b70db0
02cab86c: mov     w8, #1                                     
02cab870: strb    w8, [x21, #0xb24]                          
02cab874: ldr     x0, [x20]                                  M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cab878: str     xzr, [sp, #8]                              
02cab87c: ldr     w8, [x0, #0xe4]                            [62650e4]=0 f=0,0
02cab880: cbnz    w8, #0x2cab888                             
02cab884: bl      #0x2b70f30                                 fn_2b70f30
02cab888: mov     x0, xzr                                    
02cab88c: bl      #0x4df25c8                                 System.DateTime::get_Now
02cab890: ldr     x8, [x19, #0x20]                           .dataSave
02cab894: cbz     x8, #0x2cab8f4                             
02cab898: adrp    x20, #0x6265000                            
02cab89c: mov     x19, x0                                    
02cab8a0: mov     x1, xzr                                    
02cab8a4: ldr     x20, [x20, #0xf98]                         T:System.TimeSpan
02cab8a8: ldr     x0, [x8, #0x20]                            
02cab8ac: bl      #0x4df2914                                 System.DateTime::Parse
02cab8b0: mov     x1, x0                                     
02cab8b4: mov     x0, x19                                    
02cab8b8: mov     x2, xzr                                    
02cab8bc: bl      #0x4df3fb4                                 System.DateTime::op_Subtraction
02cab8c0: ldr     x8, [x20]                                  M:AdsManager::<OnApplicationPause>b__26_0
02cab8c4: str     x0, [sp, #8]                               
02cab8c8: ldr     w9, [x8, #0xe4]                            
02cab8cc: cbnz    w9, #0x2cab8d8                             
02cab8d0: mov     x0, x8                                     
02cab8d4: bl      #0x2b70f30                                 fn_2b70f30
02cab8d8: add     x0, sp, #8                                 
02cab8dc: mov     x1, xzr                                    
02cab8e0: bl      #0x4e292b8                                 System.TimeSpan::get_Days
02cab8e4: ldp     x20, x19, [sp, #0x20]                      
02cab8e8: ldp     x30, x21, [sp, #0x10]                      
02cab8ec: add     sp, sp, #0x30                              
02cab8f0: ret                                                
02cab8f4: bl      #0x2b7105c                                 fn_2b7105c
## HasNoAd() -> bool
---- DataUser::HasNoAd 0x2cab8f8
02cab8f8: ldr     x8, [x0, #0x20]                            .dataSave
02cab8fc: cbz     x8, #0x2cab908                             
02cab900: ldrb    w0, [x8, #0x10]                            
02cab904: ret                                                
02cab908: str     x30, [sp, #-0x10]!                         
02cab90c: bl      #0x2b7105c                                 fn_2b7105c
## HasSpecialPack() -> bool
---- DataUser::HasSpecialPack 0x2cab910
02cab910: ldr     x8, [x0, #0x20]                            .dataSave
02cab914: cbz     x8, #0x2cab920                             
02cab918: ldrb    w0, [x8, #0x11]                            
02cab91c: ret                                                
02cab920: str     x30, [sp, #-0x10]!                         
02cab924: bl      #0x2b7105c                                 fn_2b7105c
## SetNoAd() -> void
---- DataUser::SetNoAd 0x2cab928
02cab928: ldr     x8, [x0, #0x20]                            .dataSave
02cab92c: cbz     x8, #0x2cab948                             
02cab930: mov     w9, #1                                     
02cab934: strb    w9, [x8, #0x10]                            
02cab938: ldr     x8, [x0]                                   
02cab93c: ldr     x1, [x8, #0x260]                           
02cab940: ldr     x2, [x8, #0x258]                           
02cab944: br      x2                                         
02cab948: str     x30, [sp, #-0x10]!                         
02cab94c: bl      #0x2b7105c                                 fn_2b7105c
## ClaimSpecialPack() -> void
---- DataUser::ClaimSpecialPack 0x2cab950
02cab950: ldr     x8, [x0, #0x20]                            .dataSave
02cab954: cbz     x8, #0x2cab970                             
02cab958: mov     w9, #0x101                                 
02cab95c: strh    w9, [x8, #0x10]                            
02cab960: ldr     x8, [x0]                                   
02cab964: ldr     x1, [x8, #0x260]                           
02cab968: ldr     x2, [x8, #0x258]                           
02cab96c: br      x2                                         
02cab970: str     x30, [sp, #-0x10]!                         
02cab974: bl      #0x2b7105c                                 fn_2b7105c
## HasMusic() -> bool
---- DataUser::HasMusic 0x2cab978
02cab978: ldr     x8, [x0, #0x20]                            .dataSave
02cab97c: cbz     x8, #0x2cab988                             
02cab980: ldrb    w0, [x8, #0x35]                            
02cab984: ret                                                
02cab988: str     x30, [sp, #-0x10]!                         
02cab98c: bl      #0x2b7105c                                 fn_2b7105c
## SetMusic(bool isOn) -> void
---- DataUser::SetMusic 0x2cab990
02cab990: ldr     x8, [x0, #0x20]                            .dataSave
02cab994: cbz     x8, #0x2cab9b0                             
02cab998: and     w9, w1, #1                                 
02cab99c: strb    w9, [x8, #0x35]                            
02cab9a0: ldr     x8, [x0]                                   
02cab9a4: ldr     x1, [x8, #0x260]                           
02cab9a8: ldr     x2, [x8, #0x258]                           
02cab9ac: br      x2                                         
02cab9b0: str     x30, [sp, #-0x10]!                         
02cab9b4: bl      #0x2b7105c                                 fn_2b7105c
## HasSound() -> bool
---- DataUser::HasSound 0x2cab9b8
02cab9b8: ldr     x8, [x0, #0x20]                            .dataSave
02cab9bc: cbz     x8, #0x2cab9c8                             
02cab9c0: ldrb    w0, [x8, #0x36]                            
02cab9c4: ret                                                
02cab9c8: str     x30, [sp, #-0x10]!                         
02cab9cc: bl      #0x2b7105c                                 fn_2b7105c
## SetSound(bool isOn) -> void
---- DataUser::SetSound 0x2cab9d0
02cab9d0: ldr     x8, [x0, #0x20]                            .dataSave
02cab9d4: cbz     x8, #0x2cab9f0                             
02cab9d8: and     w9, w1, #1                                 
02cab9dc: strb    w9, [x8, #0x36]                            
02cab9e0: ldr     x8, [x0]                                   
02cab9e4: ldr     x1, [x8, #0x260]                           
02cab9e8: ldr     x2, [x8, #0x258]                           
02cab9ec: br      x2                                         
02cab9f0: str     x30, [sp, #-0x10]!                         
02cab9f4: bl      #0x2b7105c                                 fn_2b7105c
## HasVibration() -> bool
---- DataUser::HasVibration 0x2cab9f8
02cab9f8: ldr     x8, [x0, #0x20]                            .dataSave
02cab9fc: cbz     x8, #0x2caba08                             
02caba00: ldrb    w0, [x8, #0x34]                            
02caba04: ret                                                
02caba08: str     x30, [sp, #-0x10]!                         
02caba0c: bl      #0x2b7105c                                 fn_2b7105c
## SetVibration(bool isOn) -> void
---- DataUser::SetVibration 0x2caba10
02caba10: ldr     x8, [x0, #0x20]                            .dataSave
02caba14: cbz     x8, #0x2caba30                             
02caba18: and     w9, w1, #1                                 
02caba1c: strb    w9, [x8, #0x34]                            
02caba20: ldr     x8, [x0]                                   
02caba24: ldr     x1, [x8, #0x260]                           
02caba28: ldr     x2, [x8, #0x258]                           
02caba2c: br      x2                                         
02caba30: str     x30, [sp, #-0x10]!                         
02caba34: bl      #0x2b7105c                                 fn_2b7105c
## HasRateUs() -> bool
---- DataUser::HasRateUs 0x2caba38
02caba38: ldr     x8, [x0, #0x20]                            .dataSave
02caba3c: cbz     x8, #0x2caba48                             
02caba40: ldrb    w0, [x8, #0x37]                            
02caba44: ret                                                
02caba48: str     x30, [sp, #-0x10]!                         
02caba4c: bl      #0x2b7105c                                 fn_2b7105c
## SetRateUs(bool isRateUs) -> void
---- DataUser::SetRateUs 0x2caba50
02caba50: ldr     x8, [x0, #0x20]                            .dataSave
02caba54: cbz     x8, #0x2caba70                             
02caba58: and     w9, w1, #1                                 
02caba5c: strb    w9, [x8, #0x37]                            
02caba60: ldr     x8, [x0]                                   
02caba64: ldr     x1, [x8, #0x260]                           
02caba68: ldr     x2, [x8, #0x258]                           
02caba6c: br      x2                                         
02caba70: str     x30, [sp, #-0x10]!                         
02caba74: bl      #0x2b7105c                                 fn_2b7105c
## HasFirstLuckWheel() -> bool
---- DataUser::HasFirstLuckWheel 0x2caba78
02caba78: ldr     x8, [x0, #0x20]                            .dataSave
02caba7c: cbz     x8, #0x2caba88                             
02caba80: ldrb    w0, [x8, #0x38]                            
02caba84: ret                                                
02caba88: str     x30, [sp, #-0x10]!                         
02caba8c: bl      #0x2b7105c                                 fn_2b7105c
## SetFirstLuckWheel(bool isFirstLuckWheel) -> void
---- DataUser::SetFirstLuckWheel 0x2caba90
02caba90: ldr     x8, [x0, #0x20]                            .dataSave
02caba94: cbz     x8, #0x2cabab0                             
02caba98: and     w9, w1, #1                                 
02caba9c: strb    w9, [x8, #0x38]                            
02cabaa0: ldr     x8, [x0]                                   
02cabaa4: ldr     x1, [x8, #0x260]                           
02cabaa8: ldr     x2, [x8, #0x258]                           
02cabaac: br      x2                                         
02cabab0: str     x30, [sp, #-0x10]!                         
02cabab4: bl      #0x2b7105c                                 fn_2b7105c
## HasSelectedLanguage() -> bool
---- DataUser::HasSelectedLanguage 0x2cabab8
02cabab8: ldr     x8, [x0, #0x20]                            .dataSave
02cababc: cbz     x8, #0x2cabac8                             
02cabac0: ldrb    w0, [x8, #0x39]                            
02cabac4: ret                                                
02cabac8: str     x30, [sp, #-0x10]!                         
02cabacc: bl      #0x2b7105c                                 fn_2b7105c
## SetSelectedLanguage(bool isSelectedLanguage) -> void
---- DataUser::SetSelectedLanguage 0x2cabad0
02cabad0: ldr     x8, [x0, #0x20]                            .dataSave
02cabad4: cbz     x8, #0x2cabaf0                             
02cabad8: and     w9, w1, #1                                 
02cabadc: strb    w9, [x8, #0x39]                            
02cabae0: ldr     x8, [x0]                                   
02cabae4: ldr     x1, [x8, #0x260]                           
02cabae8: ldr     x2, [x8, #0x258]                           
02cabaec: br      x2                                         
02cabaf0: str     x30, [sp, #-0x10]!                         
02cabaf4: bl      #0x2b7105c                                 fn_2b7105c
## GetMoney() -> int
---- DataUser::GetMoney 0x2cabaf8
02cabaf8: ldr     x8, [x0, #0x20]                            .dataSave
02cabafc: cbz     x8, #0x2cabb08                             
02cabb00: ldr     w0, [x8, #0x48]                            
02cabb04: ret                                                
02cabb08: str     x30, [sp, #-0x10]!                         
02cabb0c: bl      #0x2b7105c                                 fn_2b7105c
## UpdateMoney(int money) -> void
---- DataUser::UpdateMoney 0x2cabb10
02cabb10: ldr     x8, [x0, #0x20]                            .dataSave
02cabb14: cbz     x8, #0x2cabb2c                             
02cabb18: str     w1, [x8, #0x48]                            
02cabb1c: ldr     x8, [x0]                                   
02cabb20: ldr     x1, [x8, #0x260]                           
02cabb24: ldr     x2, [x8, #0x258]                           
02cabb28: br      x2                                         
02cabb2c: str     x30, [sp, #-0x10]!                         
02cabb30: bl      #0x2b7105c                                 fn_2b7105c
## AddClaimedAchievement(int id) -> void
---- DataUser::AddClaimedAchievement 0x2cabb34
02cabb34: stp     x30, x21, [sp, #-0x20]!                    
02cabb38: stp     x20, x19, [sp, #0x10]                      
02cabb3c: adrp    x21, #0x662f000                            
02cabb40: mov     w20, w1                                    
02cabb44: mov     x19, x0                                    
02cabb48: ldrb    w8, [x21, #0xb25]                          
02cabb4c: tbnz    w8, #0, #0x2cabb70                         
02cabb50: adrp    x0, #0x6266000                             
02cabb54: ldr     x0, [x0, #0x818]                           MS:System.Collections.Generic.List`1::Add
02cabb58: bl      #0x2b70db0                                 fn_2b70db0
02cabb5c: adrp    x0, #0x6266000                             
02cabb60: ldr     x0, [x0, #0x820]                           MS:System.Collections.Generic.List`1::Contains
02cabb64: bl      #0x2b70db0                                 fn_2b70db0
02cabb68: mov     w8, #1                                     
02cabb6c: strb    w8, [x21, #0xb25]                          
02cabb70: ldr     x8, [x19, #0x20]                           .dataSave
02cabb74: cbz     x8, #0x2cabc28                             
02cabb78: ldr     x0, [x8, #0x58]                            
02cabb7c: cbz     x0, #0x2cabc28                             
02cabb80: adrp    x8, #0x6266000                             
02cabb84: mov     w1, w20                                    
02cabb88: ldr     x8, [x8, #0x820]                           MS:System.Collections.Generic.List`1::Contains
02cabb8c: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cabb90: bl      #0x3569f98                                 fn_3569f98
02cabb94: tbz     w0, #0, #0x2cabba4                         
02cabb98: ldp     x20, x19, [sp, #0x10]                      
02cabb9c: ldp     x30, x21, [sp], #0x20                      
02cabba0: ret                                                
02cabba4: ldr     x8, [x19, #0x20]                           .dataSave
02cabba8: cbz     x8, #0x2cabc28                             
02cabbac: ldr     x0, [x8, #0x58]                            S:'inter_ad_on_off'
02cabbb0: cbz     x0, #0x2cabc28                             
02cabbb4: adrp    x9, #0x6266000                             
02cabbb8: ldr     x9, [x9, #0x818]                           MS:System.Collections.Generic.List`1::Add
02cabbbc: ldr     w10, [x0, #0x1c]                           [626601c]=0 f=0,0
02cabbc0: ldr     x8, [x0, #0x10]                            S:'mrec_ad_on_off'
02cabbc4: ldr     x9, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cabbc8: add     w10, w10, #1                               
02cabbcc: str     w10, [x0, #0x1c]                           
02cabbd0: cbz     x8, #0x2cabc28                             
02cabbd4: ldrsw   x10, [x0, #0x18]                           
02cabbd8: ldr     w11, [x8, #0x18]                           S:'level_show_popuprate'
02cabbdc: cmp     w10, w11                                   
02cabbe0: b.hs    #0x2cabbf8                                 
02cabbe4: add     x8, x8, x10, lsl #2                        &6266000
02cabbe8: add     w9, w10, #1                                
02cabbec: str     w9, [x0, #0x18]                            
02cabbf0: str     w20, [x8, #0x20]                           
02cabbf4: b       #0x2cabc0c                                 
02cabbf8: ldr     x8, [x9, #0x20]                            S:'inter_ad_capping_time'
02cabbfc: mov     w1, w20                                    
02cabc00: ldr     x8, [x8, #0xc0]                            T:Firebase.RemoteConfig.ConfigValue
02cabc04: ldr     x2, [x8, #0x70]                            S:'open_ad_id'
02cabc08: bl      #0x3569c18                                 fn_3569c18
02cabc0c: ldr     x8, [x19]                                  
02cabc10: mov     x0, x19                                    
02cabc14: ldp     x20, x19, [sp, #0x10]                      
02cabc18: ldr     x1, [x8, #0x260]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02cabc1c: ldr     x2, [x8, #0x258]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02cabc20: ldp     x30, x21, [sp], #0x20                      
02cabc24: br      x2                                         
02cabc28: bl      #0x2b7105c                                 fn_2b7105c
## UnlockClickerDecor(int id) -> void
---- DataUser::UnlockClickerDecor 0x2cabc2c
02cabc2c: stp     x30, x21, [sp, #-0x20]!                    
02cabc30: stp     x20, x19, [sp, #0x10]                      
02cabc34: adrp    x21, #0x662f000                            
02cabc38: mov     w20, w1                                    
02cabc3c: mov     x19, x0                                    
02cabc40: ldrb    w8, [x21, #0xb26]                          
02cabc44: tbnz    w8, #0, #0x2cabc68                         
02cabc48: adrp    x0, #0x6266000                             
02cabc4c: ldr     x0, [x0, #0x818]                           MS:System.Collections.Generic.List`1::Add
02cabc50: bl      #0x2b70db0                                 fn_2b70db0
02cabc54: adrp    x0, #0x6266000                             
02cabc58: ldr     x0, [x0, #0x820]                           MS:System.Collections.Generic.List`1::Contains
02cabc5c: bl      #0x2b70db0                                 fn_2b70db0
02cabc60: mov     w8, #1                                     
02cabc64: strb    w8, [x21, #0xb26]                          
02cabc68: ldr     x8, [x19, #0x20]                           .dataSave
02cabc6c: cbz     x8, #0x2cabd20                             
02cabc70: ldr     x0, [x8, #0x60]                            
02cabc74: cbz     x0, #0x2cabd20                             
02cabc78: adrp    x8, #0x6266000                             
02cabc7c: mov     w1, w20                                    
02cabc80: ldr     x8, [x8, #0x820]                           MS:System.Collections.Generic.List`1::Contains
02cabc84: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cabc88: bl      #0x3569f98                                 fn_3569f98
02cabc8c: tbz     w0, #0, #0x2cabc9c                         
02cabc90: ldp     x20, x19, [sp, #0x10]                      
02cabc94: ldp     x30, x21, [sp], #0x20                      
02cabc98: ret                                                
02cabc9c: ldr     x8, [x19, #0x20]                           .dataSave
02cabca0: cbz     x8, #0x2cabd20                             
02cabca4: ldr     x0, [x8, #0x60]                            S:'open_ad_on_off'
02cabca8: cbz     x0, #0x2cabd20                             
02cabcac: adrp    x9, #0x6266000                             
02cabcb0: ldr     x9, [x9, #0x818]                           MS:System.Collections.Generic.List`1::Add
02cabcb4: ldr     w10, [x0, #0x1c]                           [626601c]=0 f=0,0
02cabcb8: ldr     x8, [x0, #0x10]                            S:'mrec_ad_on_off'
02cabcbc: ldr     x9, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cabcc0: add     w10, w10, #1                               
02cabcc4: str     w10, [x0, #0x1c]                           
02cabcc8: cbz     x8, #0x2cabd20                             
02cabccc: ldrsw   x10, [x0, #0x18]                           
02cabcd0: ldr     w11, [x8, #0x18]                           S:'level_show_popuprate'
02cabcd4: cmp     w10, w11                                   
02cabcd8: b.hs    #0x2cabcf0                                 
02cabcdc: add     x8, x8, x10, lsl #2                        &6266000
02cabce0: add     w9, w10, #1                                
02cabce4: str     w9, [x0, #0x18]                            
02cabce8: str     w20, [x8, #0x20]                           
02cabcec: b       #0x2cabd04                                 
02cabcf0: ldr     x8, [x9, #0x20]                            S:'inter_ad_capping_time'
02cabcf4: mov     w1, w20                                    
02cabcf8: ldr     x8, [x8, #0xc0]                            T:Firebase.RemoteConfig.ConfigValue
02cabcfc: ldr     x2, [x8, #0x70]                            S:'open_ad_id'
02cabd00: bl      #0x3569c18                                 fn_3569c18
02cabd04: ldr     x8, [x19]                                  
02cabd08: mov     x0, x19                                    
02cabd0c: ldp     x20, x19, [sp, #0x10]                      
02cabd10: ldr     x1, [x8, #0x260]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02cabd14: ldr     x2, [x8, #0x258]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02cabd18: ldp     x30, x21, [sp], #0x20                      
02cabd1c: br      x2                                         
02cabd20: bl      #0x2b7105c                                 fn_2b7105c
## HasUnlockedKeycapDecor(int id) -> bool
---- DataUser::HasUnlockedKeycapDecor 0x2cabd24
02cabd24: stp     x30, x21, [sp, #-0x20]!                    
02cabd28: stp     x20, x19, [sp, #0x10]                      
02cabd2c: adrp    x21, #0x662f000                            
02cabd30: mov     w19, w1                                    
02cabd34: mov     x20, x0                                    
02cabd38: ldrb    w8, [x21, #0xb27]                          
02cabd3c: tbnz    w8, #0, #0x2cabd54                         
02cabd40: adrp    x0, #0x6266000                             
02cabd44: ldr     x0, [x0, #0x820]                           MS:System.Collections.Generic.List`1::Contains
02cabd48: bl      #0x2b70db0                                 fn_2b70db0
02cabd4c: mov     w8, #1                                     
02cabd50: strb    w8, [x21, #0xb27]                          
02cabd54: ldr     x8, [x20, #0x20]                           .dataSave
02cabd58: cbz     x8, #0x2cabd80                             
02cabd5c: ldr     x0, [x8, #0x60]                            
02cabd60: cbz     x0, #0x2cabd80                             
02cabd64: adrp    x8, #0x6266000                             
02cabd68: mov     w1, w19                                    
02cabd6c: ldr     x8, [x8, #0x820]                           MS:System.Collections.Generic.List`1::Contains
02cabd70: ldp     x20, x19, [sp, #0x10]                      
02cabd74: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cabd78: ldp     x30, x21, [sp], #0x20                      
02cabd7c: b       #0x3569f98                                 
02cabd80: bl      #0x2b7105c                                 fn_2b7105c
## UnlockClickerSwitch(int id) -> void
---- DataUser::UnlockClickerSwitch 0x2cabd84
02cabd84: stp     x30, x21, [sp, #-0x20]!                    
02cabd88: stp     x20, x19, [sp, #0x10]                      
02cabd8c: adrp    x21, #0x662f000                            
02cabd90: mov     w20, w1                                    
02cabd94: mov     x19, x0                                    
02cabd98: ldrb    w8, [x21, #0xb28]                          
02cabd9c: tbnz    w8, #0, #0x2cabdc0                         
02cabda0: adrp    x0, #0x6266000                             
02cabda4: ldr     x0, [x0, #0x818]                           MS:System.Collections.Generic.List`1::Add
02cabda8: bl      #0x2b70db0                                 fn_2b70db0
02cabdac: adrp    x0, #0x6266000                             
02cabdb0: ldr     x0, [x0, #0x820]                           MS:System.Collections.Generic.List`1::Contains
02cabdb4: bl      #0x2b70db0                                 fn_2b70db0
02cabdb8: mov     w8, #1                                     
02cabdbc: strb    w8, [x21, #0xb28]                          
02cabdc0: ldr     x8, [x19, #0x20]                           .dataSave
02cabdc4: cbz     x8, #0x2cabe78                             
02cabdc8: ldr     x0, [x8, #0x68]                            
02cabdcc: cbz     x0, #0x2cabe78                             
02cabdd0: adrp    x8, #0x6266000                             
02cabdd4: mov     w1, w20                                    
02cabdd8: ldr     x8, [x8, #0x820]                           MS:System.Collections.Generic.List`1::Contains
02cabddc: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cabde0: bl      #0x3569f98                                 fn_3569f98
02cabde4: tbz     w0, #0, #0x2cabdf4                         
02cabde8: ldp     x20, x19, [sp, #0x10]                      
02cabdec: ldp     x30, x21, [sp], #0x20                      
02cabdf0: ret                                                
02cabdf4: ldr     x8, [x19, #0x20]                           .dataSave
02cabdf8: cbz     x8, #0x2cabe78                             
02cabdfc: ldr     x0, [x8, #0x68]                            S:'native_full_srceen_time_showbtn'
02cabe00: cbz     x0, #0x2cabe78                             
02cabe04: adrp    x9, #0x6266000                             
02cabe08: ldr     x9, [x9, #0x818]                           MS:System.Collections.Generic.List`1::Add
02cabe0c: ldr     w10, [x0, #0x1c]                           [626601c]=0 f=0,0
02cabe10: ldr     x8, [x0, #0x10]                            S:'mrec_ad_on_off'
02cabe14: ldr     x9, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cabe18: add     w10, w10, #1                               
02cabe1c: str     w10, [x0, #0x1c]                           
02cabe20: cbz     x8, #0x2cabe78                             
02cabe24: ldrsw   x10, [x0, #0x18]                           
02cabe28: ldr     w11, [x8, #0x18]                           S:'level_show_popuprate'
02cabe2c: cmp     w10, w11                                   
02cabe30: b.hs    #0x2cabe48                                 
02cabe34: add     x8, x8, x10, lsl #2                        &6266000
02cabe38: add     w9, w10, #1                                
02cabe3c: str     w9, [x0, #0x18]                            
02cabe40: str     w20, [x8, #0x20]                           
02cabe44: b       #0x2cabe5c                                 
02cabe48: ldr     x8, [x9, #0x20]                            S:'inter_ad_capping_time'
02cabe4c: mov     w1, w20                                    
02cabe50: ldr     x8, [x8, #0xc0]                            T:Firebase.RemoteConfig.ConfigValue
02cabe54: ldr     x2, [x8, #0x70]                            S:'open_ad_id'
02cabe58: bl      #0x3569c18                                 fn_3569c18
02cabe5c: ldr     x8, [x19]                                  
02cabe60: mov     x0, x19                                    
02cabe64: ldp     x20, x19, [sp, #0x10]                      
02cabe68: ldr     x1, [x8, #0x260]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02cabe6c: ldr     x2, [x8, #0x258]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02cabe70: ldp     x30, x21, [sp], #0x20                      
02cabe74: br      x2                                         
02cabe78: bl      #0x2b7105c                                 fn_2b7105c
## HasUnlockedClickerSwitch(int id) -> bool
---- DataUser::HasUnlockedClickerSwitch 0x2cabe7c
02cabe7c: stp     x30, x21, [sp, #-0x20]!                    
02cabe80: stp     x20, x19, [sp, #0x10]                      
02cabe84: adrp    x21, #0x662f000                            
02cabe88: mov     w19, w1                                    
02cabe8c: mov     x20, x0                                    
02cabe90: ldrb    w8, [x21, #0xb29]                          
02cabe94: tbnz    w8, #0, #0x2cabeac                         
02cabe98: adrp    x0, #0x6266000                             
02cabe9c: ldr     x0, [x0, #0x820]                           MS:System.Collections.Generic.List`1::Contains
02cabea0: bl      #0x2b70db0                                 fn_2b70db0
02cabea4: mov     w8, #1                                     
02cabea8: strb    w8, [x21, #0xb29]                          
02cabeac: ldr     x8, [x20, #0x20]                           .dataSave
02cabeb0: cbz     x8, #0x2cabed8                             
02cabeb4: ldr     x0, [x8, #0x68]                            
02cabeb8: cbz     x0, #0x2cabed8                             
02cabebc: adrp    x8, #0x6266000                             
02cabec0: mov     w1, w19                                    
02cabec4: ldr     x8, [x8, #0x820]                           MS:System.Collections.Generic.List`1::Contains
02cabec8: ldp     x20, x19, [sp, #0x10]                      
02cabecc: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cabed0: ldp     x30, x21, [sp], #0x20                      
02cabed4: b       #0x3569f98                                 
02cabed8: bl      #0x2b7105c                                 fn_2b7105c
## UnlockClickerBase(int id) -> void
---- DataUser::UnlockClickerBase 0x2cabedc
02cabedc: stp     x30, x21, [sp, #-0x20]!                    
02cabee0: stp     x20, x19, [sp, #0x10]                      
02cabee4: adrp    x21, #0x662f000                            
02cabee8: mov     w20, w1                                    
02cabeec: mov     x19, x0                                    
02cabef0: ldrb    w8, [x21, #0xb2a]                          
02cabef4: tbnz    w8, #0, #0x2cabf18                         
02cabef8: adrp    x0, #0x6266000                             
02cabefc: ldr     x0, [x0, #0x818]                           MS:System.Collections.Generic.List`1::Add
02cabf00: bl      #0x2b70db0                                 fn_2b70db0
02cabf04: adrp    x0, #0x6266000                             
02cabf08: ldr     x0, [x0, #0x820]                           MS:System.Collections.Generic.List`1::Contains
02cabf0c: bl      #0x2b70db0                                 fn_2b70db0
02cabf10: mov     w8, #1                                     
02cabf14: strb    w8, [x21, #0xb2a]                          
02cabf18: ldr     x8, [x19, #0x20]                           .dataSave
02cabf1c: cbz     x8, #0x2cabfd0                             
02cabf20: ldr     x0, [x8, #0x70]                            
02cabf24: cbz     x0, #0x2cabfd0                             
02cabf28: adrp    x8, #0x6266000                             
02cabf2c: mov     w1, w20                                    
02cabf30: ldr     x8, [x8, #0x820]                           MS:System.Collections.Generic.List`1::Contains
02cabf34: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cabf38: bl      #0x3569f98                                 fn_3569f98
02cabf3c: tbz     w0, #0, #0x2cabf4c                         
02cabf40: ldp     x20, x19, [sp, #0x10]                      
02cabf44: ldp     x30, x21, [sp], #0x20                      
02cabf48: ret                                                
02cabf4c: ldr     x8, [x19, #0x20]                           .dataSave
02cabf50: cbz     x8, #0x2cabfd0                             
02cabf54: ldr     x0, [x8, #0x70]                            S:'open_ad_id'
02cabf58: cbz     x0, #0x2cabfd0                             
02cabf5c: adrp    x9, #0x6266000                             
02cabf60: ldr     x9, [x9, #0x818]                           MS:System.Collections.Generic.List`1::Add
02cabf64: ldr     w10, [x0, #0x1c]                           [626601c]=0 f=0,0
02cabf68: ldr     x8, [x0, #0x10]                            S:'mrec_ad_on_off'
02cabf6c: ldr     x9, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cabf70: add     w10, w10, #1                               
02cabf74: str     w10, [x0, #0x1c]                           
02cabf78: cbz     x8, #0x2cabfd0                             
02cabf7c: ldrsw   x10, [x0, #0x18]                           
02cabf80: ldr     w11, [x8, #0x18]                           S:'level_show_popuprate'
02cabf84: cmp     w10, w11                                   
02cabf88: b.hs    #0x2cabfa0                                 
02cabf8c: add     x8, x8, x10, lsl #2                        &6266000
02cabf90: add     w9, w10, #1                                
02cabf94: str     w9, [x0, #0x18]                            
02cabf98: str     w20, [x8, #0x20]                           
02cabf9c: b       #0x2cabfb4                                 
02cabfa0: ldr     x8, [x9, #0x20]                            S:'inter_ad_capping_time'
02cabfa4: mov     w1, w20                                    
02cabfa8: ldr     x8, [x8, #0xc0]                            T:Firebase.RemoteConfig.ConfigValue
02cabfac: ldr     x2, [x8, #0x70]                            S:'open_ad_id'
02cabfb0: bl      #0x3569c18                                 fn_3569c18
02cabfb4: ldr     x8, [x19]                                  
02cabfb8: mov     x0, x19                                    
02cabfbc: ldp     x20, x19, [sp, #0x10]                      
02cabfc0: ldr     x1, [x8, #0x260]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02cabfc4: ldr     x2, [x8, #0x258]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02cabfc8: ldp     x30, x21, [sp], #0x20                      
02cabfcc: br      x2                                         
02cabfd0: bl      #0x2b7105c                                 fn_2b7105c
## HasUnlockedClickerBase(int id) -> bool
---- DataUser::HasUnlockedClickerBase 0x2cabfd4
02cabfd4: stp     x30, x21, [sp, #-0x20]!                    
02cabfd8: stp     x20, x19, [sp, #0x10]                      
02cabfdc: adrp    x21, #0x662f000                            
02cabfe0: mov     w19, w1                                    
02cabfe4: mov     x20, x0                                    
02cabfe8: ldrb    w8, [x21, #0xb2b]                          
02cabfec: tbnz    w8, #0, #0x2cac004                         
02cabff0: adrp    x0, #0x6266000                             
02cabff4: ldr     x0, [x0, #0x820]                           MS:System.Collections.Generic.List`1::Contains
02cabff8: bl      #0x2b70db0                                 fn_2b70db0
02cabffc: mov     w8, #1                                     
02cac000: strb    w8, [x21, #0xb2b]                          
02cac004: ldr     x8, [x20, #0x20]                           .dataSave
02cac008: cbz     x8, #0x2cac030                             
02cac00c: ldr     x0, [x8, #0x70]                            
02cac010: cbz     x0, #0x2cac030                             
02cac014: adrp    x8, #0x6266000                             
02cac018: mov     w1, w19                                    
02cac01c: ldr     x8, [x8, #0x820]                           MS:System.Collections.Generic.List`1::Contains
02cac020: ldp     x20, x19, [sp, #0x10]                      
02cac024: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cac028: ldp     x30, x21, [sp], #0x20                      
02cac02c: b       #0x3569f98                                 
02cac030: bl      #0x2b7105c                                 fn_2b7105c
## UnlockClickerKeycap(int id) -> void
---- DataUser::UnlockClickerKeycap 0x2cac034
02cac034: stp     x30, x21, [sp, #-0x20]!                    
02cac038: stp     x20, x19, [sp, #0x10]                      
02cac03c: adrp    x21, #0x662f000                            
02cac040: mov     w20, w1                                    
02cac044: mov     x19, x0                                    
02cac048: ldrb    w8, [x21, #0xb2c]                          
02cac04c: tbnz    w8, #0, #0x2cac070                         
02cac050: adrp    x0, #0x6266000                             
02cac054: ldr     x0, [x0, #0x818]                           MS:System.Collections.Generic.List`1::Add
02cac058: bl      #0x2b70db0                                 fn_2b70db0
02cac05c: adrp    x0, #0x6266000                             
02cac060: ldr     x0, [x0, #0x820]                           MS:System.Collections.Generic.List`1::Contains
02cac064: bl      #0x2b70db0                                 fn_2b70db0
02cac068: mov     w8, #1                                     
02cac06c: strb    w8, [x21, #0xb2c]                          
02cac070: ldr     x8, [x19, #0x20]                           .dataSave
02cac074: cbz     x8, #0x2cac128                             
02cac078: ldr     x0, [x8, #0x78]                            
02cac07c: cbz     x0, #0x2cac128                             
02cac080: adrp    x8, #0x6266000                             
02cac084: mov     w1, w20                                    
02cac088: ldr     x8, [x8, #0x820]                           MS:System.Collections.Generic.List`1::Contains
02cac08c: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cac090: bl      #0x3569f98                                 fn_3569f98
02cac094: tbz     w0, #0, #0x2cac0a4                         
02cac098: ldp     x20, x19, [sp, #0x10]                      
02cac09c: ldp     x30, x21, [sp], #0x20                      
02cac0a0: ret                                                
02cac0a4: ldr     x8, [x19, #0x20]                           .dataSave
02cac0a8: cbz     x8, #0x2cac128                             
02cac0ac: ldr     x0, [x8, #0x78]                            S:'Latest Fetch call still pending.'
02cac0b0: cbz     x0, #0x2cac128                             
02cac0b4: adrp    x9, #0x6266000                             
02cac0b8: ldr     x9, [x9, #0x818]                           MS:System.Collections.Generic.List`1::Add
02cac0bc: ldr     w10, [x0, #0x1c]                           [626601c]=0 f=0,0
02cac0c0: ldr     x8, [x0, #0x10]                            S:'mrec_ad_on_off'
02cac0c4: ldr     x9, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cac0c8: add     w10, w10, #1                               
02cac0cc: str     w10, [x0, #0x1c]                           
02cac0d0: cbz     x8, #0x2cac128                             
02cac0d4: ldrsw   x10, [x0, #0x18]                           
02cac0d8: ldr     w11, [x8, #0x18]                           S:'level_show_popuprate'
02cac0dc: cmp     w10, w11                                   
02cac0e0: b.hs    #0x2cac0f8                                 
02cac0e4: add     x8, x8, x10, lsl #2                        &6266000
02cac0e8: add     w9, w10, #1                                
02cac0ec: str     w9, [x0, #0x18]                            
02cac0f0: str     w20, [x8, #0x20]                           
02cac0f4: b       #0x2cac10c                                 
02cac0f8: ldr     x8, [x9, #0x20]                            S:'inter_ad_capping_time'
02cac0fc: mov     w1, w20                                    
02cac100: ldr     x8, [x8, #0xc0]                            T:Firebase.RemoteConfig.ConfigValue
02cac104: ldr     x2, [x8, #0x70]                            S:'open_ad_id'
02cac108: bl      #0x3569c18                                 fn_3569c18
02cac10c: ldr     x8, [x19]                                  
02cac110: mov     x0, x19                                    
02cac114: ldp     x20, x19, [sp, #0x10]                      
02cac118: ldr     x1, [x8, #0x260]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02cac11c: ldr     x2, [x8, #0x258]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02cac120: ldp     x30, x21, [sp], #0x20                      
02cac124: br      x2                                         
02cac128: bl      #0x2b7105c                                 fn_2b7105c
## HasUnlockedClickerKeycap(int id) -> bool
---- DataUser::HasUnlockedClickerKeycap 0x2cac12c
02cac12c: stp     x30, x21, [sp, #-0x20]!                    
02cac130: stp     x20, x19, [sp, #0x10]                      
02cac134: adrp    x21, #0x662f000                            
02cac138: mov     w19, w1                                    
02cac13c: mov     x20, x0                                    
02cac140: ldrb    w8, [x21, #0xb2d]                          
02cac144: tbnz    w8, #0, #0x2cac15c                         
02cac148: adrp    x0, #0x6266000                             
02cac14c: ldr     x0, [x0, #0x820]                           MS:System.Collections.Generic.List`1::Contains
02cac150: bl      #0x2b70db0                                 fn_2b70db0
02cac154: mov     w8, #1                                     
02cac158: strb    w8, [x21, #0xb2d]                          
02cac15c: ldr     x8, [x20, #0x20]                           .dataSave
02cac160: cbz     x8, #0x2cac188                             
02cac164: ldr     x0, [x8, #0x78]                            
02cac168: cbz     x0, #0x2cac188                             
02cac16c: adrp    x8, #0x6266000                             
02cac170: mov     w1, w19                                    
02cac174: ldr     x8, [x8, #0x820]                           MS:System.Collections.Generic.List`1::Contains
02cac178: ldp     x20, x19, [sp, #0x10]                      
02cac17c: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cac180: ldp     x30, x21, [sp], #0x20                      
02cac184: b       #0x3569f98                                 
02cac188: bl      #0x2b7105c                                 fn_2b7105c
## UnlockClickerKeychain(int id) -> void
---- DataUser::UnlockClickerKeychain 0x2cac18c
02cac18c: stp     x30, x21, [sp, #-0x20]!                    
02cac190: stp     x20, x19, [sp, #0x10]                      
02cac194: adrp    x21, #0x662f000                            
02cac198: mov     w20, w1                                    
02cac19c: mov     x19, x0                                    
02cac1a0: ldrb    w8, [x21, #0xb2e]                          
02cac1a4: tbnz    w8, #0, #0x2cac1c8                         
02cac1a8: adrp    x0, #0x6266000                             
02cac1ac: ldr     x0, [x0, #0x818]                           MS:System.Collections.Generic.List`1::Add
02cac1b0: bl      #0x2b70db0                                 fn_2b70db0
02cac1b4: adrp    x0, #0x6266000                             
02cac1b8: ldr     x0, [x0, #0x820]                           MS:System.Collections.Generic.List`1::Contains
02cac1bc: bl      #0x2b70db0                                 fn_2b70db0
02cac1c0: mov     w8, #1                                     
02cac1c4: strb    w8, [x21, #0xb2e]                          
02cac1c8: ldr     x8, [x19, #0x20]                           .dataSave
02cac1cc: cbz     x8, #0x2cac280                             
02cac1d0: ldr     x0, [x8, #0x80]                            
02cac1d4: cbz     x0, #0x2cac280                             
02cac1d8: adrp    x8, #0x6266000                             
02cac1dc: mov     w1, w20                                    
02cac1e0: ldr     x8, [x8, #0x820]                           MS:System.Collections.Generic.List`1::Contains
02cac1e4: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cac1e8: bl      #0x3569f98                                 fn_3569f98
02cac1ec: tbz     w0, #0, #0x2cac1fc                         
02cac1f0: ldp     x20, x19, [sp, #0x10]                      
02cac1f4: ldp     x30, x21, [sp], #0x20                      
02cac1f8: ret                                                
02cac1fc: ldr     x8, [x19, #0x20]                           .dataSave
02cac200: cbz     x8, #0x2cac280                             
02cac204: ldr     x0, [x8, #0x80]                            S:'Fetch failed.'
02cac208: cbz     x0, #0x2cac280                             
02cac20c: adrp    x9, #0x6266000                             
02cac210: ldr     x9, [x9, #0x818]                           MS:System.Collections.Generic.List`1::Add
02cac214: ldr     w10, [x0, #0x1c]                           [626601c]=0 f=0,0
02cac218: ldr     x8, [x0, #0x10]                            S:'mrec_ad_on_off'
02cac21c: ldr     x9, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cac220: add     w10, w10, #1                               
02cac224: str     w10, [x0, #0x1c]                           
02cac228: cbz     x8, #0x2cac280                             
02cac22c: ldrsw   x10, [x0, #0x18]                           
02cac230: ldr     w11, [x8, #0x18]                           S:'level_show_popuprate'
02cac234: cmp     w10, w11                                   
02cac238: b.hs    #0x2cac250                                 
02cac23c: add     x8, x8, x10, lsl #2                        &6266000
02cac240: add     w9, w10, #1                                
02cac244: str     w9, [x0, #0x18]                            
02cac248: str     w20, [x8, #0x20]                           
02cac24c: b       #0x2cac264                                 
02cac250: ldr     x8, [x9, #0x20]                            S:'inter_ad_capping_time'
02cac254: mov     w1, w20                                    
02cac258: ldr     x8, [x8, #0xc0]                            T:Firebase.RemoteConfig.ConfigValue
02cac25c: ldr     x2, [x8, #0x70]                            S:'open_ad_id'
02cac260: bl      #0x3569c18                                 fn_3569c18
02cac264: ldr     x8, [x19]                                  
02cac268: mov     x0, x19                                    
02cac26c: ldp     x20, x19, [sp, #0x10]                      
02cac270: ldr     x1, [x8, #0x260]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02cac274: ldr     x2, [x8, #0x258]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02cac278: ldp     x30, x21, [sp], #0x20                      
02cac27c: br      x2                                         
02cac280: bl      #0x2b7105c                                 fn_2b7105c
## HasUnlockedClickerKeychain(int id) -> bool
---- DataUser::HasUnlockedClickerKeychain 0x2cac284
02cac284: stp     x30, x21, [sp, #-0x20]!                    
02cac288: stp     x20, x19, [sp, #0x10]                      
02cac28c: adrp    x21, #0x662f000                            
02cac290: mov     w19, w1                                    
02cac294: mov     x20, x0                                    
02cac298: ldrb    w8, [x21, #0xb2f]                          
02cac29c: tbnz    w8, #0, #0x2cac2b4                         
02cac2a0: adrp    x0, #0x6266000                             
02cac2a4: ldr     x0, [x0, #0x820]                           MS:System.Collections.Generic.List`1::Contains
02cac2a8: bl      #0x2b70db0                                 fn_2b70db0
02cac2ac: mov     w8, #1                                     
02cac2b0: strb    w8, [x21, #0xb2f]                          
02cac2b4: ldr     x8, [x20, #0x20]                           .dataSave
02cac2b8: cbz     x8, #0x2cac2e0                             
02cac2bc: ldr     x0, [x8, #0x80]                            
02cac2c0: cbz     x0, #0x2cac2e0                             
02cac2c4: adrp    x8, #0x6266000                             
02cac2c8: mov     w1, w19                                    
02cac2cc: ldr     x8, [x8, #0x820]                           MS:System.Collections.Generic.List`1::Contains
02cac2d0: ldp     x20, x19, [sp, #0x10]                      
02cac2d4: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cac2d8: ldp     x30, x21, [sp], #0x20                      
02cac2dc: b       #0x3569f98                                 
02cac2e0: bl      #0x2b7105c                                 fn_2b7105c
## AddUnlockGiftBox(int id) -> void
---- DataUser::AddUnlockGiftBox 0x2cac2e4
02cac2e4: stp     x30, x21, [sp, #-0x20]!                    
02cac2e8: stp     x20, x19, [sp, #0x10]                      
02cac2ec: adrp    x21, #0x662f000                            
02cac2f0: mov     w20, w1                                    
02cac2f4: mov     x19, x0                                    
02cac2f8: ldrb    w8, [x21, #0xb30]                          
02cac2fc: tbnz    w8, #0, #0x2cac320                         
02cac300: adrp    x0, #0x6266000                             
02cac304: ldr     x0, [x0, #0x818]                           MS:System.Collections.Generic.List`1::Add
02cac308: bl      #0x2b70db0                                 fn_2b70db0
02cac30c: adrp    x0, #0x6266000                             
02cac310: ldr     x0, [x0, #0x820]                           MS:System.Collections.Generic.List`1::Contains
02cac314: bl      #0x2b70db0                                 fn_2b70db0
02cac318: mov     w8, #1                                     
02cac31c: strb    w8, [x21, #0xb30]                          
02cac320: ldr     x8, [x19, #0x20]                           .dataSave
02cac324: cbz     x8, #0x2cac3d8                             
02cac328: ldr     x0, [x8, #0x88]                            
02cac32c: cbz     x0, #0x2cac3d8                             
02cac330: adrp    x8, #0x6266000                             
02cac334: mov     w1, w20                                    
02cac338: ldr     x8, [x8, #0x820]                           MS:System.Collections.Generic.List`1::Contains
02cac33c: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cac340: bl      #0x3569f98                                 fn_3569f98
02cac344: tbz     w0, #0, #0x2cac354                         
02cac348: ldp     x20, x19, [sp, #0x10]                      
02cac34c: ldp     x30, x21, [sp], #0x20                      
02cac350: ret                                                
02cac354: ldr     x8, [x19, #0x20]                           .dataSave
02cac358: cbz     x8, #0x2cac3d8                             
02cac35c: ldr     x0, [x8, #0x88]                            S:'native_banner_id'
02cac360: cbz     x0, #0x2cac3d8                             
02cac364: adrp    x9, #0x6266000                             
02cac368: ldr     x9, [x9, #0x818]                           MS:System.Collections.Generic.List`1::Add
02cac36c: ldr     w10, [x0, #0x1c]                           [626601c]=0 f=0,0
02cac370: ldr     x8, [x0, #0x10]                            S:'mrec_ad_on_off'
02cac374: ldr     x9, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cac378: add     w10, w10, #1                               
02cac37c: str     w10, [x0, #0x1c]                           
02cac380: cbz     x8, #0x2cac3d8                             
02cac384: ldrsw   x10, [x0, #0x18]                           
02cac388: ldr     w11, [x8, #0x18]                           S:'level_show_popuprate'
02cac38c: cmp     w10, w11                                   
02cac390: b.hs    #0x2cac3a8                                 
02cac394: add     x8, x8, x10, lsl #2                        &6266000
02cac398: add     w9, w10, #1                                
02cac39c: str     w9, [x0, #0x18]                            
02cac3a0: str     w20, [x8, #0x20]                           
02cac3a4: b       #0x2cac3bc                                 
02cac3a8: ldr     x8, [x9, #0x20]                            S:'inter_ad_capping_time'
02cac3ac: mov     w1, w20                                    
02cac3b0: ldr     x8, [x8, #0xc0]                            T:Firebase.RemoteConfig.ConfigValue
02cac3b4: ldr     x2, [x8, #0x70]                            S:'open_ad_id'
02cac3b8: bl      #0x3569c18                                 fn_3569c18
02cac3bc: ldr     x8, [x19]                                  
02cac3c0: mov     x0, x19                                    
02cac3c4: ldp     x20, x19, [sp, #0x10]                      
02cac3c8: ldr     x1, [x8, #0x260]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02cac3cc: ldr     x2, [x8, #0x258]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02cac3d0: ldp     x30, x21, [sp], #0x20                      
02cac3d4: br      x2                                         
02cac3d8: bl      #0x2b7105c                                 fn_2b7105c
## AddUnlockCard(int id) -> void
---- DataUser::AddUnlockCard 0x2cac3dc
02cac3dc: stp     x30, x21, [sp, #-0x20]!                    
02cac3e0: stp     x20, x19, [sp, #0x10]                      
02cac3e4: adrp    x21, #0x662f000                            
02cac3e8: mov     w20, w1                                    
02cac3ec: mov     x19, x0                                    
02cac3f0: ldrb    w8, [x21, #0xb31]                          
02cac3f4: tbnz    w8, #0, #0x2cac418                         
02cac3f8: adrp    x0, #0x6266000                             
02cac3fc: ldr     x0, [x0, #0x818]                           MS:System.Collections.Generic.List`1::Add
02cac400: bl      #0x2b70db0                                 fn_2b70db0
02cac404: adrp    x0, #0x6266000                             
02cac408: ldr     x0, [x0, #0x820]                           MS:System.Collections.Generic.List`1::Contains
02cac40c: bl      #0x2b70db0                                 fn_2b70db0
02cac410: mov     w8, #1                                     
02cac414: strb    w8, [x21, #0xb31]                          
02cac418: ldr     x8, [x19, #0x20]                           .dataSave
02cac41c: cbz     x8, #0x2cac4d0                             
02cac420: ldr     x0, [x8, #0x90]                            
02cac424: cbz     x0, #0x2cac4d0                             
02cac428: adrp    x8, #0x6266000                             
02cac42c: mov     w1, w20                                    
02cac430: ldr     x8, [x8, #0x820]                           MS:System.Collections.Generic.List`1::Contains
02cac434: ldr     x2, [x8]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cac438: bl      #0x3569f98                                 fn_3569f98
02cac43c: tbz     w0, #0, #0x2cac44c                         
02cac440: ldp     x20, x19, [sp, #0x10]                      
02cac444: ldp     x30, x21, [sp], #0x20                      
02cac448: ret                                                
02cac44c: ldr     x8, [x19, #0x20]                           .dataSave
02cac450: cbz     x8, #0x2cac4d0                             
02cac454: ldr     x0, [x8, #0x90]                            S:'mrec_ad_id'
02cac458: cbz     x0, #0x2cac4d0                             
02cac45c: adrp    x9, #0x6266000                             
02cac460: ldr     x9, [x9, #0x818]                           MS:System.Collections.Generic.List`1::Add
02cac464: ldr     w10, [x0, #0x1c]                           [626601c]=0 f=0,0
02cac468: ldr     x8, [x0, #0x10]                            S:'mrec_ad_on_off'
02cac46c: ldr     x9, [x9]                                   M:RemoteConfigManager::<FetchDataRemote>b__85_0
02cac470: add     w10, w10, #1                               
02cac474: str     w10, [x0, #0x1c]                           
02cac478: cbz     x8, #0x2cac4d0                             
02cac47c: ldrsw   x10, [x0, #0x18]                           
02cac480: ldr     w11, [x8, #0x18]                           S:'level_show_popuprate'
02cac484: cmp     w10, w11                                   
02cac488: b.hs    #0x2cac4a0                                 
02cac48c: add     x8, x8, x10, lsl #2                        &6266000
02cac490: add     w9, w10, #1                                
02cac494: str     w9, [x0, #0x18]                            
02cac498: str     w20, [x8, #0x20]                           
02cac49c: b       #0x2cac4b4                                 
02cac4a0: ldr     x8, [x9, #0x20]                            S:'inter_ad_capping_time'
02cac4a4: mov     w1, w20                                    
02cac4a8: ldr     x8, [x8, #0xc0]                            T:Firebase.RemoteConfig.ConfigValue
02cac4ac: ldr     x2, [x8, #0x70]                            S:'open_ad_id'
02cac4b0: bl      #0x3569c18                                 fn_3569c18
02cac4b4: ldr     x8, [x19]                                  
02cac4b8: mov     x0, x19                                    
02cac4bc: ldp     x20, x19, [sp, #0x10]                      
02cac4c0: ldr     x1, [x8, #0x260]                           MS:System.Collections.Generic.List`1/Enumerator::MoveNext
02cac4c4: ldr     x2, [x8, #0x258]                           MS:System.Collections.Generic.List`1/Enumerator::Dispose
02cac4c8: ldp     x30, x21, [sp], #0x20                      
02cac4cc: br      x2                                         
02cac4d0: bl      #0x2b7105c                                 fn_2b7105c
## OnApplicationQuit() -> void
---- DataUser::OnApplicationQuit 0x2cac4d4
02cac4d4: ldr     x8, [x0, #0x20]                            .dataSave
02cac4d8: cbz     x8, #0x2cac4f0                             
02cac4dc: strb    wzr, [x8, #0x39]                           
02cac4e0: ldr     x8, [x0]                                   
02cac4e4: ldr     x1, [x8, #0x260]                           
02cac4e8: ldr     x2, [x8, #0x258]                           
02cac4ec: br      x2                                         
02cac4f0: str     x30, [sp, #-0x10]!                         
02cac4f4: bl      #0x2b7105c                                 fn_2b7105c
## .ctor() -> void
---- DataUser::.ctor 0x2cac4f8
02cac4f8: mov     x1, xzr                                    
02cac4fc: b       #0x5b397b0                                 UnityEngine.MonoBehaviour::.ctor
